package com.xweather.mapsgl.config.weather.account

/**
 * Holds id and secret
 *   @author Jason Suto 03/13/2024
 */
data class XweatherAccount(
    val id: String, val secret: String
)
