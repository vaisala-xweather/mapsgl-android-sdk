package com.xweather.mapsgl.events

/**
 * Eventable.kt
 *
 * A type on which events can be published and subscribed.
 *
 * Based on IOS Version
 *
 * @author Jason Suto 03/22/24
 */
interface Eventable {
    // Storage for Publishers and other Event stuff.
    // Intended to be implemented on conforming types simply with: `val eventDispatcher = EventDispatcher()`
    val eventDispatcher: EventDispatcher
}
