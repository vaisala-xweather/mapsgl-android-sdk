package com.xweather.mapsgl.data.series


import com.xweather.mapsgl.anim.AnimationEvent
import com.xweather.mapsgl.anim.EventDispatcher
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.tiles.TileData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.milliseconds


typealias AnyTimeSeriesAnimator = Any // Replace with the actual type if available


/** Synchronizes a map timeline with the loading state of the individual animators for each animatable layer that is
 * active on a map.
 * @internal
 */
class AnimatorSync(val timeline: Timeline) : EventDispatcher() {

    /** If true, the timeline will be paused while any animators are loading.  */
    var pauseWhileLoading: Boolean = false

    var shouldResumeAfterLoading: Boolean = true

    private val _layers: MutableMap<String, MapLayer<TileData, LayerRenderContext<Any>>> = mutableMapOf()
    private var _pausedForLoading: Boolean = false
    private var debounceJob: Job? = null
    private val debounceDelay = 10.milliseconds

    val isPausedForLoading: Boolean
        get() = _pausedForLoading

    init {
        //if (pr.ON) pr.p(TAG, pr.timeLine, "AnimatorSync init(), timeline.isAnimating? ${timeline.isAnimating}")
        timeline.on(AnimationEvent.play) {
            if (pauseWhileLoading) {
                handleTimelinePlayback()
            }
        }

        //Timeline.times = Timeline.generateHourlyIntervals(timeline.start, timeline.end)
        //timeline.massUpdate(Timeline.times)


        timeline.on(AnimationEvent.range_change) {
            if (pr.ON) pr.p(TAG, pr.interleave, "range_change")
            timeline.stop()
            //println(">> AnimatorSync calling generateHourlyIntervals() from range_change")
            Timeline.generateHourlyIntervals(timeline.start, timeline.end)
            timeline.massUpdate(Timeline.timeStrings)

            if (pr.ON) pr.p(TAG, pr.pastInterval, "RANGE_CHANGE timeLine.times: ${Timeline.timeStrings.size}")
            if (pr.ON) pr.p(
                TAG,
                pr.pastInterval,
                "RANGE_CHANGE timeLine.times: after massUpdate, currentPhaseA${Timeline.currentPhaseA}"
            )

            val sources = _layers.values.fold(mutableListOf<Any>()) { acc, layer ->
                if (!acc.contains(layer.source)) {
                    acc.add(layer.source)
                }
                acc
            }

            // TODO: note from javascript version: move this to MapController.addSource
            //println("AnimatorSync init()  num sources: ${sources.size} ")
            sources.forEach { source ->
                if (source is TileSource<*>) {
                    //source.getMetadata()
                    CoroutineScope(Dispatchers.Main).launch {
                        //todo: get start and end time from timeline... send to fetchMetaData()
                        if (pr.ON) pr.p(
                            TAG,
                            pr.fetchMeta,
                            "AnimatorSync onRangeChange, calling fetchMetadata() for ${source.id} with ${timeline.start}  / ${timeline.end} "
                        )
                        source.metaDataNeeded++
                        source.fetchMetadata(timeline.start, timeline.end)
                    }

                }
            }
            // Time range changed, so tell the animators to update their data.
            setNeedsUpdate()
        }
    }

    suspend fun subscribeToRangeChange() {
    }

    /** Adds a layer to be synced.
     * @param layer -
     */
    fun add(layer: MapLayer<TileData, LayerRenderContext<Any>>) {
        if (pr.ON) pr.p("AnimatorSync", pr.animatorSync, "add(${layer.id}) ")
        if (!_layers.containsKey(layer.id)) {
            _layers[layer.id] = layer

            val provider = layer.animator!!.provider
            if (pr.ON) pr.p("AnimatorSync", pr.animatorSync, "add()  provider is null? ${provider == null} ")

            provider?.on(TimeSeriesEvent.LOAD_START.toString()) {
                if (pr.ON) pr.p(
                    "AnimatorSync",
                    pr.animatorSync,
                    "add() provider?.on(TimeSeriesEvent.LOAD_START.toString()) "
                )
                shouldResumeAfterLoading = !timeline.isPaused
                handleTimelinePlayback()
                provider.on(TimeSeriesEvent.LOAD_COMPLETE.toString()) {
                    handleTimelinePlayback()
                }
            }
        }
    }

    /** Removes a layer from the sync.
     * @param layer -
     */
    fun remove(layer: MapLayer<TileData, LayerRenderContext<Any>>) {
        _layers.remove(layer.id)
    }

    /** Tells the animator data providers to update their data.  */
    fun setNeedsUpdate() {
        _layers.values.forEach { layer ->
            layer.animator?.provider?.setNeedsUpdate()
        }
    }

    private fun handleTimelinePlayback() {
        debounceJob?.cancel()
        debounceJob = CoroutineScope(Dispatchers.Default).launch {
            delay(debounceDelay)
            _handleTimelinePlaybackInternal()
        }
    }

    private fun _handleTimelinePlaybackInternal() {
        val timeline = this.timeline


        if (timeline.isActive && pauseWhileLoading) {
            val loading = getLoadingAnimators()

            if (loading.isNotEmpty()) {
                _pausedForLoading = true

                // Animators are currently loading so pause the timeline
                timeline.pause()
            } else if (_pausedForLoading && shouldResumeAfterLoading) {
                _pausedForLoading = false

                if (timeline.isPaused) {
                    // Animators are not currently loading and the timeline is paused, so resume it.
                    timeline.resume()
                } else {
                    // Animators are not currently loading and the timeline is stopped, so play it.
                    if (pr.ON) pr.p(
                        TAG,
                        pr.layerToAnimation,
                        "_handleTimelinePlaybackInternal() about to call timeline.play()"
                    )
                    timeline.play(startImmediately = true)
                }
            }
        }
    }

    /** Returns an array of animators that are currently loading.   */
    private fun getLoadingAnimators(): List<AnyTimeSeriesAnimator> {
        return _layers.values.mapNotNull { layer ->
            val animator = layer.animator
            val provider = animator?.provider

            if (layer.visible && provider?.isReady == false) {
                animator
            } else {
                null
            }
        }
    }
}