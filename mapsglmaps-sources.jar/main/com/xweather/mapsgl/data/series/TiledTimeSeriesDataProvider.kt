package com.xweather.mapsgl.data.series

import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.data.EncodedTileData
import com.xweather.mapsgl.data.Queue
import com.xweather.mapsgl.data.QueueCollection
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.utils.LRUCache
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.Date
import kotlin.math.ceil
import kotlin.math.floor

const val MAX_REQUEST_INTERVALS = 6;

data class TileInterval(val coord: TileCoord, val intervals: List<TimeInterval>)
typealias TileIntervalsArray = MutableList<TileInterval>

/**
 * Breaks up the intervals into smaller chunks for the requests.
 * @param coordsToRequest - Set of tile coordinates and their data intervals to request.
 * @param maxIntervalsPerRequest - The maximum number of intervals to request per tile which determines the chunk size.
 */
fun createTileIntervalChunks(
    coordsToRequest: MutableList<TileInterval>,
    maxIntervalsPerRequest: Int,
    interleaved: Boolean
): MutableList<MutableList<TileInterval>> {
    val tasks = mutableListOf<MutableList<TileInterval>>()

    coordsToRequest.forEach { (coord, intervals) ->
        val maxIntervals = maxIntervalsPerRequest.coerceAtMost(intervals.size)
        val chunks = mutableListOf<MutableList<TimeInterval>>()
        val totalChunks = ceil(intervals.size.toDouble() / maxIntervals).toInt()

        if (totalChunks > 1) {
            var n = 0
            for (i in intervals.indices) {
                if (chunks.size <= n) {
                    chunks.add(mutableListOf())
                }
                chunks[n].add(intervals[i])

                if (interleaved) {
                    n = (n + 1) % totalChunks
                } else if (chunks[n].size == maxIntervals) {
                    n++
                }
            }
        } else {
            chunks.add(intervals.toMutableList())
        }

        chunks.forEachIndexed { chunkIndex, chunkIntervals ->
            if (tasks.size <= chunkIndex) {
                tasks.addAll(List(chunkIndex - tasks.size + 1) { mutableListOf() }) //Fill in missing indices
            }
            tasks[chunkIndex].add(TileInterval(coord, chunkIntervals))
        }
    }
    return tasks
}

/**
 * Sorts an array of tile interval chunks so that we load those in the middle of each chunk first.
 * @param chunks - The chunks to sort.
 */
fun sortedIntervalChunks(chunks: List<List<TileInterval>>): List<List<TileInterval>> {
    val indexOrder = chunks.indices.toList()

    val sortedIndexOrder = if (chunks.size > 2) {
        indexOrder.sortedWith(compareBy { chunks[it].size / 2.0 })
    } else {
        indexOrder
    }

    return sortedIndexOrder.map { chunks[it] }
}

class Queues(val primary: Queue<Any>, val background: QueueCollection<Any>) {}

/** A `TimeSeriesDataProvider` class that handles loading and configuring time series data for tile layers.
 *
 * This class is designed to work with tile-based data sources and is optimized for loading time series data for
 * individual tiles and tile intervals. It queues requests into a primary queue and a background queue collection so
 * that the primary queue can load the first chunk of data, which is the minimal amount of data required to begin
 * animating. Then the background queue can continue loading the rest of the data in smaller chunks to fill in the gaps
 * while the animation is already playing.
 * @internal
 */
class TiledTimeSeriesDataProvider(override val layer: TileLayer) : TimeSeriesDataProvider<TileLayer>(layer) {

    lateinit var _visibleTileCoords: List<TileCoord>

    //var _intervalTileCache: MutableMap<String, Tile<DataType>> = mutableMapOf();
    lateinit var _intervalTileCache: LRUCache<String, Tile<TileData>>

    lateinit var _visibleTileBounds: TileBounds;
    lateinit var _lastIntervals: MutableList<TimeInterval>

    var queues = Queues(Queue(), QueueCollection())


    fun jTest() {


    }


    override fun dataStateForIntervals(intervals: MutableList<TimeInterval>): Map<String, Boolean> {

        val visibleCoords = this._visibleTileCoords
        val state: MutableMap<String, Boolean> = mutableMapOf()
        val missingData: MutableMap<String, TimeInterval?> = mutableMapOf()

        if (visibleCoords.isNotEmpty()) {
            for (interval in intervals) {
                var missingIntervalData = false
                for (coord in visibleCoords) {
                    val tileData = this.layer.source.getTileData(coord);

                    if ((tileData is EncodedTileData || tileData is BitmapTimeSeriesData<*>)
                    /*&& tileData.series?.hasDataForInterval(interval) == false*/
                    ) {
                        missingIntervalData = true;
                        //if (missingData.containsKey(coord.hash())) { missingData[coord.hash()] = null }
                        missingData[coord.hash()] = interval
                    }
                }
                state[interval.toString()] = !missingIntervalData;
            }
        }

        return state;
    }


    fun loadDataOld(intervals: Array<TimeInterval>) {
        TODO("Not yet implemented")
    }


    /**
     * Updates the visible tile coordinates and bounds for the layer.
     */
    private fun _updateVisibleTileCoordsState() {

        _visibleTileCoords = layer.getVisibleTileCoords()  //.map { it.normalize() }
        _visibleTileBounds = TileBounds.fromCoords(_visibleTileCoords)
    }


    override suspend fun loadData(intervals: MutableList<TimeInterval>) {
        if (intervals.size != this._lastIntervals.size) {
            this.setNeedsUpdate();
        }

        if (!this.isDirty || (intervals.isEmpty())) {
            // console.warn('TiledTimeSeriesDataProvider.loadData', 'no intervals or not dirty', intervals.length, this.isDirty);
            return;
        }

        this._updateVisibleTileCoordsState();
        this._lastIntervals = intervals

        // Iterate through tile coords and determine which intervals data is missing for.
        val coordsToRequest = this.calculateMissingTileIntervals(intervals);
        if (coordsToRequest.size == 0) {
            // this.onReady();
            // console.warn('TiledTimeSeriesDataProvider.loadData', 'no missing data', intervals.length, this._visibleTileCoords.length, coordsToRequest.length);
            return;
        }

        // console.log('TiledTimeSeriesDataProvider.loadData', 'needed', intervals.length, 'request', coordsToRequest.length, coordsToRequest);
        trigger(
            TimeSeriesEvent.DATA_REQUEST,
            intervals,
            0
        ) //extra variable 0 to avoid signature clash after type erasure.


        // Clear all queues that may be loading data from the previous update pass
        this.invalidate();
        this._isDirty = false;
        // this._pending.clear();

        // Break up the intervals into smaller chunks for the requests.
        val taskChunks =
            createTileIntervalChunks(coordsToRequest, this.maxIntervalsPerRequest, this.interleaveRequests);
        if (taskChunks.isEmpty()) {
            // this.onReady(); //commented out in js version
            return;
        }

        // Put the first chunk into the primary queue to load the minimal amount of data required to begin animating.
        val primaryTaskChunk = taskChunks.shift()

        if (primaryTaskChunk != null) {
            for (tileInterval in primaryTaskChunk) {
                enqueueTileRequestIfNeeded(queues.primary, tileInterval.coord, tileInterval.intervals)
            }
        }

        // Put the rest of the chunks into a background queue, sorted starting from the middle out to fill in the data
        // gaps relatively evenly if interleaving is enabled. Otherwise, loading will be in the order of the chunks.

        val sortedTaskChunks = if (interleaveRequests) sortedIntervalChunks(taskChunks) else taskChunks

        for (taskChunk in sortedTaskChunks) {
            val tempQueue = Queue<Any>()
            for (tileInterval in taskChunk) {
                enqueueTileRequestIfNeeded(tempQueue, tileInterval.coord, tileInterval.intervals)
            }
            this.queues.background.push(tempQueue)
        }

        this.queues.primary.start();
    }

    fun <T> MutableList<T>.shift(): T? {
        if (this.isEmpty()) {
            return null
        }
        return this.removeAt(0)
    }

    override fun invalidate() {
        super.invalidate();
        this.queues.primary.cancel();
        this.queues.background.cancel();
    }

    /**
     * Calculates the intervals that are missing data for each visible tile.
     * @param intervals - The time intervals to check for missing data.
     * @returns An array of tile coordinates and their missing intervals.
     */
    private fun calculateMissingTileIntervals(intervals: MutableList<TimeInterval>): TileIntervalsArray {
        val source = this.layer.source;
        val neededIntervals: MutableList<TimeInterval> = intervals;
        val visibleCoords = this._visibleTileCoords;
        val coordsToRequest: TileIntervalsArray = mutableListOf()

        for (coord in visibleCoords) {
            val tileData = this.layer.source.getTileData(coord);
            if (this._intervalTileCache == null) {
                setupCache((visibleCoords.size * 1.25).toInt())
            }
            _intervalTileCache.get(coord.hash()) // this bumps up the item's age in LRU cache if exists

            if (tileData == null) { // No data exists yet for this tile, so we need all intervals

                val requestedCoords = TileInterval(coord, intervals = neededIntervals)
                coordsToRequest.add(requestedCoords)
            } else if (tileData is EncodedTileData || tileData is BitmapTimeSeriesData<*>) {
                val missingIntervals =
                    (tileData as BitmapTimeSeriesData<*>).series.intervalsNeedingData(neededIntervals)
                val missingIntervalsToDownload: MutableList<TimeInterval> = mutableListOf()
                for (missingInterval in missingIntervals) {
                    val isPending = source.tileManager.isPending(coord, missingInterval.toInt())
                    if (!isPending) {
                        missingIntervalsToDownload.add(missingInterval)
                    } else {
                        //don't add item
                    }
                }
                if (missingIntervalsToDownload.size > 0) {
                    coordsToRequest.add(TileInterval(coord, intervals = missingIntervalsToDownload))
                }
            } else {
                coordsToRequest.add(TileInterval(coord, intervals = intervals))
                // console.warn('loadDataIfNeeded: no cached tile data', coord.hash, tileData);
            }
        }
        return coordsToRequest;
    }

    /**
     * Adds a tile request to a queue if needed based on the intervals that are missing data for the tile.
     * @param queue - The queue to add the request to.
     * @param coord - The tile coordinate to request data for.
     * @param intervals - The time intervals to request data for.
     */
    private suspend fun enqueueTileRequestIfNeeded(queue: Queue<Any>, coord: TileCoord, intervals: List<TimeInterval>) {
        // Only enqueue requests for intervals not already pending based on existing requests
        val pending = this.layer.source.tileManager.pending //TODO: need pending to get pending (PendingTileStore in js)
        val store = pending[coord.hash()]
        //TODO: Make sure this works and interval is not truncated, should go up to 2,147,483,647,
        val neededIntervals = intervals.filter { t -> store?.contains(t.toInt()) != true }
        /* // Longer version of the code above
        val neededIntervals: MutableList<TimeInterval> = mutableListOf()
        for (interval in intervals){
            if (store?.contains(interval.toInt()) != true)
            neededIntervals.add(interval)
        }*/

        val currentDateTime = LocalDateTime.now(ZoneOffset.UTC)
        val formattedDateTime =
            currentDateTime.toString().substring(0, 19) + "Z" // Looks like 2024-04-15T19:57:07.951703

        if (pr.ON) pr.p(TAG, pr.partDL2512, "enqueueTileRequestIfNeeded() calling requestTiles with null intervals")
        if (neededIntervals.isNotEmpty()) {
            val requestedTile = layer.source.requestTiles(
                coord,
                TileRequestOptions(
                    //may also need isRadar here...
                    intervals = neededIntervals.map { t -> Date(t) },
                    reload = true,
                    checkPending = false,
                ),
                formattedDateTime,
                true,
                null,
            )

            onLoadProgress(neededIntervals.map { t -> Date(t) }) //FIXME: does this need to be done after enqueue?

            queue.enqueue(
                { requestedTile }
            )
        }
    }

    /** This is commented out in js version  **/
    //fun hasPendingRequest(coord: TileCoord, interval: TimeInterval): Boolean {
    //   val isSourcePending = this.layer.source.tileManager.pending    .isPending(coord, interval);
    //   val isLocalPending = this._pending.isPending(coord, interval);
    //   return isSourcePending || isLocalPending;
    //}

    /**
     * Sets up the LRU cache for restricting how much time series data is cached at once to restrict how much time
     * series data is cached at once to prevent excessive memory usage when animating data. This allows tiles no longer
     * visible and removed from the LRU cache to purge their time series data and WebGL textures from the cache.
     * @param capacity - The maximum number of tiles to cache at once.
     */

    private fun setupCache(capacity: Int) {
        val roundedCapacity = Math.ceil(capacity.toDouble()).toInt() //Kotlin does not have Math.ceil for Int

        _intervalTileCache = LRUCache<String, Tile<TileData>>(
            capacity = roundedCapacity,
            ttl = 0,
            onRemove = { key, value: Tile<TileData> ->

                if (!_visibleTileBounds.contains(value.coord)) {
                    trigger(TimeSeriesEvent.DATA_REMOVE, mapOf("tile" to value))
                }
            }
        )
    }


    // Source event handlers

    private fun onSourceLoadStart(): Unit {}

    private fun onSourceLoadComplete(): Unit {}

    private fun onSourceTileLoadStart(tile: Tile<TileData>? = null) {
        if (_visibleTileBounds == null) {
            _updateVisibleTileCoordsState();
        }

        // Set up LRU cache with a capacity slightly larger than the number of visible tiles since the capacity will
        // vary depending on map viewport size.
        val visibleCoords = this._visibleTileCoords;
        if (this._intervalTileCache.size > 0) {
            this.setupCache((visibleCoords.size * 1.25).toInt())
        }

        // Only cache tiles that are within the current visible bounds which prevents tiles loaded before the cache
        // was cleared from being added to the cache if they aren't within the visible bounds.
        if (tile != null && this._visibleTileBounds.contains(tile.coord)) {
            this._intervalTileCache[tile.coord.hash()] = tile
        }
    }

    private fun onSourceTileLoad(tile: Any? = null): Unit {
        // this.onLoadProgress([]); //commented out in js version
    }

    override fun dispose() {
        this.invalidate()

        val source = this.layer.source;
        val lambda = { _: String -> onSourceLoadStart() }

        //TODO: get .off() function working
        //source.eventDispatcher.off(DataSourceEvents.LoadStart(), lambda.toString())
        //source.eventDispatcher.off(DataSourceEvents.LoadComplete(), onSourceLoadComplete())
        //source.eventDispatcher.off(DataSourceEvents.TileLoadStart(), onSourceTileLoadStart())
        //source.eventDispatcher.off(DataSourceEvents.TileLoad(), onSourceTileLoad())


    }

    /**
     * Sorts an array of tile interval chunks so that we load those in the middle of each chunk first.
     * @param chunks - The chunks to sort.
     */
    fun sortedIntervalChunks(chunks: List<MutableList<MutableList<TileInterval>>>): List<MutableList<MutableList<TileInterval>>> {
        var indexOrder = chunks.mapIndexed { index, _ -> index }.toMutableList()

        if (chunks.size > 2) {
            fun <T> sortByMidpoint(out: MutableList<T>, arr: List<T>) {
                if (arr.size < 3) {
                    arr.forEach { v -> out.add(v) }
                    return
                }

                val mid = floor(arr.size.toDouble() / 2).toInt()
                out.add(arr[mid])
                sortByMidpoint(out, arr.subList(0, mid))
                sortByMidpoint(out, arr.subList(mid + 1, arr.size))
            }

            val sorted = mutableListOf<Int>()
            sortByMidpoint(sorted, indexOrder)
            indexOrder = sorted
        }
        return indexOrder.map { index -> chunks[index] }
    }

}

