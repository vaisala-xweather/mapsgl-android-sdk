package com.xweather.mapsgl.data.series

import android.content.Context
import android.opengl.GLES31
import com.xweather.mapsgl.types.Size
import java.util.UUID

interface Disposable {
    fun dispose()
}

data class Texture(val image: RGBAImage?, var id: Int? = null) : Disposable {
    override fun dispose() {
        id = null // Simulate disposing of the texture
    }
}

data class Framebuffer(var id: Int? = null) : Disposable {
    override fun dispose() {
        id = null // Simulate disposing of the framebuffer
    }
}


interface AnyBitmapDrawable {
    val image: RGBAImage?
    var texture: Texture?
}

data class RGBAImage(val rawData: ByteArray, val width: Int, val height: Int)

class BitmapDrawable(override val image: RGBAImage?, override var texture: Texture?) : AnyBitmapDrawable, Disposable {
    override fun dispose() {
        texture?.dispose()
        texture = null
    }
}

class BitmapTimeSeriesData<Drawable : AnyBitmapDrawable>(
    seriesData: HashMap<TimeIntervalKey, /*TimeSeriesAnimator*/Drawable>?,
    val size: Size,
    validIntervals: List<TimeInterval>
) : Disposable {
    val id: String = UUID.randomUUID().toString()
    val series: TimeSeries<Drawable> = TimeSeries(seriesData) //Todo: make sure this works
    val index: MutableMap<String, Int> = mutableMapOf("current" to -1, "next" to -1)
    val textures: MutableMap<String, Texture?> = mutableMapOf("current" to null, "next" to null)
    val renderTargets: MutableMap<String, Framebuffer?> = mutableMapOf("current" to null, "next" to null)
    var useLinearTextureFilter = false
    private var _validIntervals: List<TimeInterval> = validIntervals.sorted()

    val count: Int get() = series.count
    val validCount: Int get() = series.validCount

    val validIntervals: List<TimeInterval> get() = _validIntervals

    fun setValidIntervals(intervals: List<TimeInterval>) {
        _validIntervals = intervals.sorted()
    }

    /** Returns the bitmap data for the specified time interval in the time series.
     * @param interval - The time interval for which to retrieve the data.
     * @returns The bitmap data for the specified time interval or `undefined` if no data is available for the
     * specified interval.     */
    fun getData(interval: TimeInterval): Drawable?  /*TimeSeriesAnimatorData?*/ = series.dataForTimeInterval(interval)


    /** Sets the bitmap data for the specified time interval in the time series. The data will only be set if the
     * time interval exists in the time series.
     * @param interval - The time interval for which to set the data.
     * @param data - The bitmap data to set for the specified time interval.     */
    fun setData(interval: TimeInterval, data: Drawable) {
        if (data !is BitmapDrawable) {
            throw Error("Invalid data type for time series data")
        }
        series.setDataForInterval(interval, data, true)
    }

    /** Purges the bitmap data for all time intervals in the time series, excluding the specified time interval if
     * provided.
     * @remarks
     * This method will dispose of any textures associated with the data and remove the data for each interval in the
     * time series.
     * @param excludingInterval - The time interval to exclude from the purge operation. If not provided, all data will
     * be purged.     */
    fun purgeData(excludingInterval: TimeInterval = 0) {
        series.intervals.forEach { interval ->
            if (interval != excludingInterval) {
                val data = series.dataForInterval(interval)
                data?.texture?.dispose()
                data?.texture = null
                series.setDataForInterval(interval, null, false)
            }
        }
    }


    fun dataAtIndex(index: Int, closest: Boolean = false): Pair<Drawable?, Int>? {
        if (index < 0 || index >= validIntervals.size) return null

        var result = series.dataForInterval(validIntervals[index])
        if (result != null || !closest) return Pair(result, index)

        var found = -1
        validIntervals.forEachIndexed { i, interval ->
            val data = series.dataForInterval(interval)
            if (data != null && (found == -1 || Math.abs(i - index) < Math.abs(found - index))) {
                result = data
                found = i
            }
        }
        return Pair(result, found)
    }


    fun prepareTextures(context: Context) {
        series.intervals.forEach { interval ->
            val data = series.dataForInterval(interval)
            if (data?.image != null && data.texture == null) {
                val image = data.image!!
                val filter = if (useLinearTextureFilter) GLES31.GL_LINEAR else GLES31.GL_NEAREST
                data.texture = Texture(image)
                //Simulate texture creation with context
            }
        }
    }

    fun updateTextures(context: Context, currentIndex: Int, nextIndex: Int) {
        prepareTextures(context)

        val update = updateTexture(context, currentIndex, "current") || updateTexture(context, nextIndex, "next")

        if (index["current"]!! >= 0 && textures["current"]?.image == null) {
            textures["current"] = null
            textures["next"] = null
            index["current"] = -1
            index["next"] = -1
        }

        if (textures["next"]?.image == null) {
            textures["next"] = textures["current"]
            index["next"] = index["current"]!!
        }
    }


    private fun updateTexture(context: Context, index: Int, textureType: String): Boolean {
        val data = dataAtIndex(index, true) ?: return false
        val (dataValue, adjustedIndex) = data
        if (adjustedIndex == this.index[textureType]!!) return false

        if (dataValue?.texture?.image != null) {
            textures[textureType] = dataValue.texture
            this.index[textureType] = adjustedIndex
            return true
        } else {
            textures[textureType] = null
            this.index[textureType] = -1
            return false
        }
    }


    override fun dispose() {
        series.intervals.forEach { interval ->
            val data = series.dataForInterval(interval)
            //data?.dispose() //todo: fix data.dispose()
        }
        series.invalidate()
        textures["current"] = null
        textures["next"] = null
    }
}