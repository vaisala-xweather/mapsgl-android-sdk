package com.xweather.mapsgl.data

import com.xweather.mapsgl.geo.Geo.TILE_SIZE
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.sources.data.EncodedData
import com.xweather.mapsgl.types.Size

/**
 * Serialized representation of an `EncodedDrawableTile`.
 */
data class SerializedEncodedTileData(
    //val series: Map<String, EncodedDrawable>,
    val size: Size,
    val padding: Int,
    val metadata: Metadata
)

/**
 * Represents encoded time series data for a tile, such as raster image data.
 * @remarks
 * This class is used to store and manage encoded data for a tile at multiple time intervals. It provides
 * methods for accessing and updating the data, as well as managing the textures used to render the data.
 */
class EncodedTileData(
    private val id: String,
    val series: Map<String, ByteArray>,
    size: Size = Size(TILE_SIZE, TILE_SIZE)
) /*: Disposable*/ {
    private var index: Pair<Int, Int> = Pair(-1, -1)
    internal var data: EncodedData? = null

    init {
        if(pr.ON) pr.p("EncodedTileData",pr.bitmapTimeSeries, "init()")
        val seriesData = series.mapValues { (interval, data) ->
            if (data != null) {
                //val encodedData = EncodedData(data, size.width ?: TILE_SIZE, padding)
                // EncodedDrawable(encodedData, null)
            } else {
                null
            }
        }.toMutableMap()
    }

}