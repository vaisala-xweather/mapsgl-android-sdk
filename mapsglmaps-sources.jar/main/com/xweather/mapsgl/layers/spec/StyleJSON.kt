package com.xweather.mapsgl.layers.spec

import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.types.TextJustification
import com.xweather.mapsgl.types.TextTransform

/**
 * Represents a layer style in the Mapbox Style Specification.
 * Reference: https://docs.mapbox.com/style-spec/reference/layers/
 */
class StyleJSON(
    val id: String,
    val type: LayerType,
    val sourceID: String,
    val sourceLayer: String? = null
) {
    enum class LayerType(val rawValue: String) {
        BACKGROUND("background"),
        CIRCLE("circle"),
        FILL("fill"),
        FILL_EXTRUSION("fill-extrusion"),
        HEATMAP("heatmap"),
        HILLSHADE("hillshade"),
        LINE("line"),
        RASTER("raster"),
        SYMBOL("symbol")
    }

    var filter: Expression? = null

    // Fill
    var fillColor: StyleValue<Color>? = null
    var fillOpacity: StyleValue<Double>? = null
    var fillOutlineColor: StyleValue<Color>? = null
    var fillPattern: StyleValue<String>? = null

    // Line
    var lineColor: StyleValue<Color>? = null
    var lineWidth: StyleValue<Double>? = null
    var lineOpacity: StyleValue<Double>? = null
    // var linePattern: Any? = null

    // Circle
    var circleColor: StyleValue<Color>? = null
    var circleOpacity: StyleValue<Double>? = null
    var circleStrokeColor: StyleValue<Color>? = null
    var circleStrokeOpacity: StyleValue<Double>? = null
    var circleStrokeWidth: StyleValue<Double>? = null
    var circleRadius: StyleValue<Double>? = null
    var circleSortKey: StyleValue<Double>? = null

    // Heatmap
    var heatmapColor: StyleValue<Color>? = null
    var heatmapIntensity: StyleValue<Double>? = null
    var heatmapOpacity: StyleValue<Double>? = null
    var heatmapRadius: StyleValue<Double>? = null
    var heatmapWeight: StyleValue<Double>? = null

    // Icon
    var iconAllowOverlap: StyleValue<Boolean>? = null
    var iconAnchor: StyleValue<Anchor>? = null
    var iconColor: StyleValue<Color>? = null
    var iconHaloBlur: StyleValue<Double>? = null
    var iconHaloColor: StyleValue<Color>? = null
    var iconHaloWidth: StyleValue<Double>? = null
    var iconImage: StyleValue<String>? = null
    var iconOffset: StyleValue<AnchorOffset>? = null
    var iconOpacity: StyleValue<Double>? = null
    var iconPadding: StyleValue<Double>? = null
    var iconRotate: StyleValue<Double>? = null
    var iconSize: StyleValue<Double>? = null

    // Text
    var textAllowOverlap: StyleValue<Boolean>? = null
    var textAnchor: StyleValue<Anchor>? = null
    var textColor: StyleValue<Color>? = null
    var textField: StyleValue<String>? = null
    var textFont: StyleValue<String>? = null
    var textHaloBlur: StyleValue<Double>? = null
    var textHaloColor: StyleValue<Color>? = null
    var textHaloWidth: StyleValue<Double>? = null
    var textJustify: StyleValue<TextJustification>? = null
    var textLetterSpacing: StyleValue<Double>? = null
    var textLineHeight: StyleValue<Double>? = null
    var textMaxWidth: StyleValue<Double>? = null
    var textOffset: StyleValue<AnchorOffset>? = null
    var textOpacity: StyleValue<Double>? = null
    var textPadding: StyleValue<Double>? = null
    var textRotate: StyleValue<Double>? = null
    var textSize: StyleValue<Double>? = null
    var textTransform: StyleValue<TextTransform>? = null

    // Symbol

    fun asStyleJSONObject(): Map<String, Any> {
        val json = mutableMapOf<String, Any>(
            "id" to id,
            "type" to type.rawValue,
            "source" to sourceID
        )

        filter?.let {
            json["filter"] = it.toJSONObject() as Any
        }

        sourceLayer?.let {
            json["source-layer"] = it

            val sourceLayerName = it
            if (json["filter"] != null) {
                json["filter"] = listOf("all", listOf("==", "layer", sourceLayerName), it)
            } else {
                json["filter"] = listOf("==", "layer", sourceLayerName)
            }
        }

        val paint = mutableMapOf<String, Any>()
        val layout = mutableMapOf<String, Any>()

        fillColor?.resolvedValue?.let { paint["fill-color"] = it as Any }
        fillOpacity?.resolvedValue?.let { paint["fill-opacity"] = it as Any }
        fillOutlineColor?.resolvedValue?.let { paint["fill-outline-color"] = it as Any }
        fillPattern?.resolvedValue?.let { paint["fill-pattern"] = it as Any }

        lineColor?.resolvedValue?.let { paint["line-color"] = it as Any }
        lineWidth?.resolvedValue?.let { paint["line-width"] = it as Any }
        lineOpacity?.resolvedValue?.let { paint["line-opacity"] = it as Any }
        // linePattern?.resolvedValue?.let { paint["line-pattern"] = it }

        circleColor?.resolvedValue?.let { paint["circle-color"] = it as Any }
        circleOpacity?.resolvedValue?.let { paint["circle-opacity"] = it as Any }
        circleStrokeColor?.resolvedValue?.let { paint["circle-stroke-color"] = it as Any }
        circleStrokeOpacity?.resolvedValue?.let { paint["circle-stroke-opacity"] = it as Any }
        //circleStrokeWidth?.resolvedValue?.let { paint["circle-stroke-width"] = (it as Double) / 2.0 }
        circleStrokeWidth?.resolvedValue?.let {
            val processedValue = when (it) {
                is Double -> it / 2.0 // If it's a Double, divide it by 2
                is ArrayList<*> -> {
                    listOf("*", it, 0.5)
                }

                else -> it
            }
            paint["circle-stroke-width"] = processedValue
        }
        //circleRadius?.resolvedValue?.let { paint["circle-radius"] = it as Any }
        circleRadius?.resolvedValue?.let {
            val processedValue = when (it) {
                is Double -> it / 2.0 // If it's a Double, divide it by 2
                is ArrayList<*> -> {
                    listOf("*", it, 0.5)
                }

                else -> it
            }
            paint["circle-radius"] = processedValue
        }
        circleSortKey?.resolvedValue?.let { layout["circle-sort-key"] = it as Any }

        heatmapColor?.resolvedValue?.let { paint["heatmap-color"] = it as Any }
        heatmapIntensity?.resolvedValue?.let { paint["heatmap-intensity"] = it as Any }
        heatmapOpacity?.resolvedValue?.let { paint["heatmap-opacity"] = it as Any }
        heatmapRadius?.resolvedValue?.let { paint["heatmap-radius"] = it as Any }
        heatmapWeight?.resolvedValue?.let { paint["heatmap-weight"] = it as Any }

        iconAllowOverlap?.resolvedValue?.let { layout["icon-allow-overlap"] = it as Any }
        iconAnchor?.resolvedValue?.let { layout["icon-anchor"] = it as Any }
        iconColor?.resolvedValue?.let { paint["icon-color"] = it as Any }
        iconHaloBlur?.resolvedValue?.let { paint["icon-halo-blur"] = it as Any }
        iconHaloColor?.resolvedValue?.let { paint["icon-halo-color"] = it as Any }
        iconHaloWidth?.resolvedValue?.let { paint["icon-halo-width"] = it as Any }
        iconImage?.resolvedValue?.let { layout["icon-image"] = it as Any }
        iconOffset?.resolvedValue?.let { layout["icon-offset"] = it as Any }
        iconOpacity?.resolvedValue?.let { paint["icon-opacity"] = it as Any }
        iconPadding?.resolvedValue?.let { layout["icon-padding"] = it as Any }
        iconRotate?.resolvedValue?.let { layout["icon-rotate"] = it as Any }
        iconSize?.resolvedValue?.let { layout["icon-size"] = it as Any }

        textAllowOverlap?.resolvedValue?.let { layout["text-allow-overlap"] = it as Any }
        textField?.resolvedValue?.let { layout["text-field"] = it as Any }
        textSize?.resolvedValue?.let { layout["text-size"] = it as Any }
        textFont?.resolvedValue?.let { layout["text-font"] = it as Any }
        // textWeight?.resolvedValue?.let { layout["text-font-weight"] = it as Any }
        textColor?.resolvedValue?.let { paint["text-color"] = it as Any }
        textHaloColor?.resolvedValue?.let { paint["text-halo-color"] = it as Any }
        textHaloBlur?.resolvedValue?.let { paint["text-halo-blur"] = it as Any }
        textHaloWidth?.resolvedValue?.let { paint["text-halo-width"] = it as Any }
        textOpacity?.resolvedValue?.let { paint["text-opacity"] = it as Any }
        textJustify?.resolvedValue?.let { layout["text-justify"] = it as Any }
        textTransform?.resolvedValue?.let { layout["text-transform"] = it as Any }
        textAnchor?.resolvedValue?.let { layout["text-anchor"] = it as Any }
        textOffset?.resolvedValue?.let { layout["text-offset"] = it as Any }
        textPadding?.resolvedValue?.let { layout["text-padding"] = it as Any }
        textRotate?.resolvedValue?.let { layout["text-rotate"] = it as Any }
        textLetterSpacing?.resolvedValue?.let { layout["text-letter-spacing"] = it as Any }
        textLineHeight?.resolvedValue?.let { layout["text-line-height"] = it as Any }
        textMaxWidth?.resolvedValue?.let { layout["text-max-width"] = it as Any }

        if (paint.isNotEmpty()) {
            json["paint"] = paint
        }
        if (layout.isNotEmpty()) {
            json["layout"] = layout
        }

        return json
    }
}
