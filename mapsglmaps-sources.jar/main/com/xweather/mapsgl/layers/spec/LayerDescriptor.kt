package com.xweather.mapsgl.layers.spec

import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.ContourPaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.HeatmapLayerPaint
import com.xweather.mapsgl.style.HeatmapPaint
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.ParticlePaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.RasterPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType

enum class MaskLayerKind {
    NONE,
    LAND,
    WATER
}

interface LayerEventEmitter {
    fun on(eventName: String, callback: (Any?) -> Unit)
    fun off(eventName: String)
    fun trigger(eventName: String, data: Any? = null)
}

class LayerEventManager : LayerEventEmitter {
    private val listeners = mutableMapOf<String, MutableList<(Any?) -> Unit>>()

    override fun on(eventName: String, callback: (Any?) -> Unit) {
        listeners.getOrPut(eventName) { mutableListOf() }.add(callback)
    }

    override fun off(eventName: String) {
        listeners.remove(eventName)
    }

    override fun trigger(eventName: String, data: Any?) {
        listeners[eventName]?.forEach { it(data) }
    }
}

interface LayerDescriptor<P : LayerPaint> : LayerEventEmitter {
    var id: String
    val type: LayerType
    var source: String
    var paint: P//LayerPaint
}

interface BitmapLayerDescriptor<P : LayerPaint> : LayerDescriptor<P> {
    var quality: DataQuality
    var mask: MaskLayerKind
}

interface VectorLayerDescriptor<P : LayerPaint> : LayerDescriptor<P> {
    var sourceLayer: String?
    var filter: Expression?
}

data class RasterLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: RasterLayerPaint = RasterLayerPaint(
        raster = RasterPaint()
    )
) : BitmapLayerDescriptor<RasterLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override var mask: MaskLayerKind = MaskLayerKind.NONE
    override val type: LayerType = LayerType.raster
}

data class SampleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: SampleLayerPaint = SampleLayerPaint(
        sample = SamplePaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE
) : BitmapLayerDescriptor<SampleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.sample

    init {
        // This connects the paint's setter to this descriptor's event bus
        paint.sample.eventEmitter = this

        //println(">>> LayerDescriptor: SampleLayerDescriptor init linked to Emitter!")
    }
}

data class ContourLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: ContourLayerPaint = ContourLayerPaint(
        sample = SamplePaint(),
        contour = ContourPaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE
) : BitmapLayerDescriptor<ContourLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.sample

    init {
        paint.sample.eventEmitter = this
    }
}

data class ParticleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: ParticleLayerPaint = ParticleLayerPaint(
        sample = SamplePaint(),
        particle = ParticlePaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE
) : BitmapLayerDescriptor<ParticleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.particles
}

data class FillLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: FillLayerPaint = FillLayerPaint(
        fill = FillPaint(),
        stroke = StrokePaint()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<FillLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.fill
}

data class LineLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: LineLayerPaint = LineLayerPaint(
        stroke = StrokePaint()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<LineLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.line
}

data class CircleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: CircleLayerPaint = CircleLayerPaint(
        fill = FillPaint(),
        stroke = StrokePaint(),
        circle = CirclePaint()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<CircleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.circle
}

data class SymbolLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: SymbolLayerPaint = SymbolLayerPaint(
        icon = IconPaint(),
        text = emptyList()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<SymbolLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.symbol
}

data class HeatmapLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: HeatmapLayerPaint = HeatmapLayerPaint(
        heatmap = HeatmapPaint()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<HeatmapLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.heatmap
}