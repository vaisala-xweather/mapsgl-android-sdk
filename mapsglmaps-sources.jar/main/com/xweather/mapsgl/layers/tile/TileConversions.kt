package com.xweather.mapsgl.layers.tile

import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import java.lang.Math.toRadians
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.roundToInt
import kotlin.math.tan

class TileConversions {

    companion object{

        fun lonToTileNormalized(lon: Double, zoom: Int, unWrapped: Boolean = false): Int {
            if (unWrapped && lon < -180) {
                var returnTile =
                    ((lon * zoom) / 360.0).roundToInt() // new method to fix drawing to much across antimeridian
                if (lon < -360) returnTile -= 1
                return returnTile
            } else {
                return (((lon + 180.0) / 360.0 * powerTableD[zoom])).toInt()
            }
        }

        fun lonToTileNonNormalized(lon: Double, zoom: Int): Int {
            val tileSize = 256 // Tile size in pixels
            val worldWidth = tileSize * (1 shl zoom) // Width of the world map at the given zoom level
            // Calculate the tile X coordinate without normalization
            val tileX = floor((lon + 180) / 360 * worldWidth / tileSize).toInt()
            return tileX
        }

        fun latToTile(lat: Double, zoom: Int): Int {
            val latRad = toRadians(lat)
            return ((1 - ln(tan(latRad) + 1 / cos(latRad)) / PI) * 0.5 * (1 shl zoom)).toInt()
        }

        fun getLonPixelInTile(lon: Double, zoom: Int, tileSize: Int = 256): Double {
            val worldWidthAtZoom = tileSize * (1 shl zoom) // Equivalent to tileSize * 2.0.pow(zoom)

            // 1. Calculate absolute world pixel X coordinate
            val worldPixelX = (lon + 180.0) / 360.0 * worldWidthAtZoom

            // 2. The pixel X coordinate within the tile is the remainder when divided by tileSize
            // This handles wrapping correctly.
            var pixelXInTile = worldPixelX % tileSize

            // Ensure the result is positive if worldPixelX was negative (for lons < -180 in some contexts)
            // Though for typical lon values (-180 to 180), worldPixelX will be positive.
            if (pixelXInTile < 0) {
                pixelXInTile += tileSize
            }

            return pixelXInTile
        }

        /**
         * Calculates the Y pixel coordinate of a given latitude within its tile.
         *
         * @param lat The latitude in degrees.
         * @param zoom The map zoom level.
         * @param tileSize The size of one side of a map tile in pixels (e.g., 256).
         * @return The Y pixel coordinate (0 to tileSize-1) within the tile.
         */
        fun getLatPixelInTile(lat: Double, zoom: Int, tileSize: Int = 256): Double {
            val worldHeightAtZoom = tileSize * (1 shl zoom) // Equivalent to tileSize * 2.0.pow(zoom)
            val latRad = toRadians(lat)

            // 1. Calculate absolute world pixel Y coordinate
            // Formula for Mercator projection's normalized Y: (1 - (ln(tan(lat_rad) + 1/cos(lat_rad)) / PI)) / 2
            // Or (1 - asinh(tan(latRad)) / PI) / 2.0
            val normalizedY = (1.0 - ln(tan(latRad) + 1.0 / cos(latRad)) / PI) / 2.0
            val worldPixelY = normalizedY * worldHeightAtZoom

            // 2. The pixel Y coordinate within the tile is the remainder when divided by tileSize
            var pixelYInTile = worldPixelY % tileSize

            // Ensure the result is positive if worldPixelY was negative (less likely for typical latitudes)
            if (pixelYInTile < 0) {
                pixelYInTile += tileSize
            }
            return pixelYInTile
        }

    }


}