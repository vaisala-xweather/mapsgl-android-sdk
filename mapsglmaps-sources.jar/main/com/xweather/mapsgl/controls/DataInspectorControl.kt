package com.xweather.mapsgl.controls

import android.view.View
import androidx.constraintlayout.widget.ConstraintLayout
import com.mapbox.geojson.Point
import com.mapbox.maps.ScreenCoordinate
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.events.MapControllerEvents
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.mapbox.MapboxMapController.Companion.TAG
import com.xweather.mapsgl.weather.common.Presentation

/** A data control that queries map layers at a target coordinate and presents a callout.
`DataInspectorControl` owns a `CalloutView` anchored to a point within a host view. It
executes asynchronous feature queries via a `QueryCallback`, coalesces/throttles updates
for animated timelines, and formats results using layer-specific or default presenters.
## Usage
1. Create an instance with a `hostView` and `query` callback.
2. Call `show(point, coordinate)` to display and populate the callout.
3. Call `update()` as the underlying data animates or changes to refresh values.
4. Call `hide()` to remove the callout.
 **/

class DataInspectorControl(mapController: MapController) {
    private val mapView = mapController.mapView
    private var callOut: CalloutView? = CalloutView(mapController)
    internal val dIResult: DataInspectorResult = DataInspectorResult()
    internal val queryResult: DataInspectorResult = DataInspectorResult()
    internal val presentationsByLayerId: HashMap<String, Presentation> = hashMapOf()
    internal var on = false

    internal var targetCoordinate: Point?
        get() = callOut?.currentPoint
        set(value) {
            callOut?.currentPoint = value
        }

    internal val isActive: Boolean
        get() = callOut?.isActive() == true

    internal val hasMoved: Boolean
        get() = callOut?.moved == true

    internal val view: ConstraintLayout?
        get() = callOut?.view

    private val onLayerAdded: (Any?) -> Unit = {
        println { ">>> DataInspectorControl onLayerAdded" }
        val isVector = it as Boolean
        val delay = if (isVector) 500L else 100L

        view?.postDelayed({
            callOut?.update(dIResult)
        }, delay)
    }
    private val onLayerRemoved: (Any?) -> Unit = { // this is in use
        if (pr.ON) pr.p("DataInspectorControl", pr.mapControllerEvent, "on(MapControllerEvents.onLayerRemoved)")
        callOut?.update(dIResult)
    }
    private val onLoadComplete: (Any?) -> Unit = {
        if (pr.ON) pr.p("DataInspectorControl", pr.mapControllerEvent, "on(MapControllerEvents.LOAD COMPLETE)")
        callOut?.update(dIResult)
    }
    private val onVisibilityChanged: (Any?) -> Unit = {
        if (pr.ON) pr.p("DataInspectorControl", pr.mapControllerEvent, "on(MapControllerEvents.VISIBILITY_CHANGED)")
        callOut?.update(dIResult)
    }
    private val onVectorLayerAdded: (Any?) -> Unit = { // this is in use
        if (pr.ON) pr.p("DataInspectorControl", pr.mapControllerEvent, "on(MapControllerEvents.VECTOR_LAYER_ADDED)")
        callOut?.update(dIResult)
    }

    init {
        initializeView(mapController)
        initializeListeners(mapController)
    }

    /** Shows (or updates) the callout at a screen point for a geographic coordinate.
    executes an async query to populate its contents.

    Parameters:
    - point: The anchor point in the host's coordinate system or convertible from its superview/window.
    - coordinate: The WGS‑84 coordinate to query.
     **/
    fun show(point: ScreenCoordinate, coordinate: Point) {
        on = true
        callOut?.setActive(true)
        if (pr.ON) pr.p(TAG, pr.vectorRefactor, "show() calling callout.show()")
        callOut?.show(coordinate, dIResult, point)
    }

    /** Repositions the callout to a new point within the host view bounds.

    If the point falls outside the inset bounds (by the callout corner radius), the callout is hidden.

    - Parameter point: New anchor point in host-view coordinates.
     **/
    fun move(point: ScreenCoordinate) {
        if (pr.ON) pr.p("DataInspectorControl", pr.dIFix, "move() calling callout.moveView()")
        callOut?.moveView(point.x.toFloat(), point.y.toFloat())
    }

    /** Refreshes callout contents for the current `targetCoordinate`.
     **/
    fun update() {
        callOut?.update(dIResult)
    }

    /** Hides and removes the callout and cancels any in-flight query.

    Resets the anchor point and target coordinate.
     **/
    fun hide() {
        on = false
        callOut?.setActive(false)
        targetCoordinate = null

        //currentQueryTask?.cancel()
        //mapView.removeView(view)
        //callOut?.removeFromSuperview()
        //callOut = null
        //callOut = null
        // targetPoint = null
        //targetCoordinate = null
//		isQueryInFlight = false
    }

    /** Registers a presentation for a layer identifier.

    - Parameters:
    - layerId: The unique identifier of the layer.
    - presentation: The presentation rules to apply when formatting values.
     **/
    fun setPresentation(layerId: String, presentation: Presentation) {
        val preexisting: Boolean = presentationsByLayerId[layerId] != null
        presentationsByLayerId[layerId] = presentation
        if (preexisting && targetCoordinate != null) {
            showInternal(targetCoordinate!!)
        }
    }

    /** Removes any custom presentation associated with a layer identifier.

    - Parameter layerId: The unique identifier of the layer.
     **/
    fun removePresentation(layerId: String) {
        presentationsByLayerId.remove(layerId)
    }

    internal fun initializeView(mapController: MapController) {
        mapView.addView(view)
    }

    internal fun initializeListeners(mapController: MapController) {
        mapController.on(MapControllerEvents.LAYER_ADDED, onLayerAdded)
        mapController.on(MapControllerEvents.LAYER_REMOVED, onLayerRemoved) // in use
        //mapController.on(MapControllerEvents.LOAD_COMPLETE, onLoadComplete)
        mapController.on(MapControllerEvents.VISIBILITY_CHANGED, onVisibilityChanged) // in use
        mapController.on(MapControllerEvents.VECTOR_LAYER_ADDED, onVectorLayerAdded) // in use
    }

    internal fun updateVector() {
        updateGridData()
        callOut?.view?.post {
            callOut?.flickerVis = View.VISIBLE
            callOut?.moveView()
        }
    }

    internal fun updateWithSameData() {
        callOut?.update(dIResult, false)
    }

    internal fun showInternal(point: Point) {
        callOut?.setActive(true)
        callOut?.show(point, dIResult)
    }

    private fun updateGridData() {
        callOut?.updateGridData(dIResult)
    }

    internal fun removeEvents(mapController: MapController) {
        mapController.off(MapControllerEvents.LAYER_ADDED, onLayerAdded)
        mapController.off(MapControllerEvents.LAYER_REMOVED, onLayerRemoved)
        //mapController.off(MapControllerEvents.LOAD_COMPLETE, onLoadComplete)
        mapController.off(MapControllerEvents.VISIBILITY_CHANGED, onVisibilityChanged)
        mapController.off(MapControllerEvents.VECTOR_LAYER_ADDED, onVectorLayerAdded) // in use
    }
}