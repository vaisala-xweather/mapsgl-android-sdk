package com.xweather.mapsgl.controls.legend.bar

import android.graphics.Typeface
import androidx.annotation.Keep
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xweather.mapsgl.anim.EasingCurve
import com.xweather.mapsgl.controls.legend.ColorScaleSpecification
import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.LegendDefaults
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.Point.PointLegendItem
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.extensions.Measurement
import com.xweather.mapsgl.extensions.UnitConcentrationMass
import com.xweather.mapsgl.extensions.UnitHeight
import com.xweather.mapsgl.extensions.UnitHeightDifference
import com.xweather.mapsgl.extensions.UnitLength
import com.xweather.mapsgl.extensions.UnitNone
import com.xweather.mapsgl.extensions.UnitProportion
import com.xweather.mapsgl.extensions.UnitSpeed
import com.xweather.mapsgl.extensions.UnitTemperature
import com.xweather.mapsgl.extensions.UnitTemperatureDelta
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.style.ColorScale
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.LayerPaint


/**
 * A lightweight capability interface for legend types that can update their color scale at runtime.
 *
 * Implement this interface when a legend can *apply* a new visual color scale configuration
 * after it has been created (e.g., in response to a style change or layer paint update).
 */
interface ColorScaleUpdatable {
    /**
     * Applies the provided color-scale specification to the implementing legend.
     * @param colorScale A complete color-scale description which may be a single ramp
     *   or a set of per-mask configurations.
     */
    fun apply(colorScale: ColorScaleOptions): Any // Return type is `Any` to accommodate immutable data classes returning a new instance
    fun apply(colorScale: ColorScaleSpecification): Any // Return type is `Any` to accommodate immutable data classes returning a new instance
}

/**
 * Default styling values for a BarLegend.
 */
object BarLegendDefaults {
    val barHeight: Dp = 14.0.dp
    val barMargins: Dp = 4.0.dp // Simplified from CGSize
    const val rounded: Boolean = true
    const val normalized: Boolean = false

    val labelFont: Typeface = android.graphics.Typeface.DEFAULT_BOLD

    //val labelFont: Typeface = android.graphics.Typeface.MONOSPACE
    val labelFontSize: TextUnit = 10.0.sp
    val labelColor: Color = Color.White
    val textStrokeColor: Color = Color(0xFF000000)
    val textStrokeWidth: Float = 2.0f

    // In Compose, a shadow is a single object.
    val textShadow: Shadow = Shadow(
        color = Color(0xFF000000), // Approximating CGColor black: 0.0, alpha: 0.7
        blurRadius = 1.0f
    )
}

/**
 * A `Legend` type that renders a color bar with optional measurement-aware labels.
 * It's a data class to promote immutability, common in Compose.
 *
 * @param UnitType A type representing the unit of measurement (e.g., Temperature, Speed).
 */
@Keep
data class BarLegend<UnitType : Dimension>(
    override val id: String,
    var items: List<BarLegendItem<UnitType>> = emptyList(),
    val resample: EasingCurve? = null,
    override var title: String? = null,
    override var titleFontSize: TextUnit = LegendDefaults.titleFontSize,
    val titleFontWeight: FontWeight = FontWeight.Bold,
    override var titleColorValue: Color = LegendDefaults().titleColor,
    val labelFontSize: TextUnit = BarLegendDefaults.labelFontSize,
    var labelColor: Color = BarLegendDefaults.labelColor,
    val labelFont: Typeface = BarLegendDefaults.labelFont,
    val measurement: MeasurementUnits.MeasurementType? = null,
    override val units: MeasurementUnits = MeasurementUnits.IMPERIAL,
    var currentUnits: UnitType? = units.dimensions(measurement)
) : Legend, ColorScaleUpdatable {

    // Use a computed property to get the currentUnits
    //val currentUnits: UnitType?
    //   get() = units.dimensions(measurement)

    override fun title(newValue: String?): BarLegend<UnitType> = copy(title = newValue)

    fun currentUnits(newValue: UnitType?): BarLegend<UnitType> {
        val updatedItems = this.items.map { item ->
            // Crucial: ensure the labels inside EVERY item are updated
            item.copy(labels = item.labels.copy(currentUnits = newValue))
        }
        return this.copy(currentUnits = newValue, items = updatedItems)
    }

    override fun units(newValue: MeasurementUnits): BarLegend<UnitType> {
        val newCurrentUnits: UnitType? = newValue.dimensions(measurement)
        // Only update children if the new system actually dictates a specific unit
        return this.currentUnits(newCurrentUnits).copy(units = newValue)
    }


    //override fun items(newItems: List<BarLegendItem<UnitConcentrationMass>>) {
    //    items = newItems as List<BarLegendItem<UnitType>>
    // }

    @Suppress("UNCHECKED_CAST")
    override fun items(newItems: List<BarLegendItem<Dimension>>): BarLegend<UnitType> {
        this.items = newItems as List<BarLegendItem<UnitType>>
        return this
    }

    @Suppress("UNCHECKED_CAST")
    fun items(item: BarLegendItem<out Dimension>): BarLegend<UnitType> {
        this.items = listOf(item) as List<BarLegendItem<UnitType>>
        return this
    }

    override fun items(newItems: List<PointLegendItem>): PointLegend {
        TODO("Do not pass PointLegendItems to BarLegend")
    }

    override fun apply(colorScale: ColorScaleSpecification): BarLegend<UnitType> {
        val newItems = when (colorScale) {
            is ColorScaleSpecification.Single -> {
                // This correctly uses the currentUnits of the legend instance

                val newLabels = BarLegendLabels(currentUnits = this.currentUnits)

                val newItem = items.firstOrNull()?.copy(
                    colorScaleOptions = colorScale.scale, labels = newLabels
                ) ?: BarLegendItem(
                    colorScaleOptions = colorScale.scale, labels = newLabels
                )
                listOf(newItem)
            }

            is ColorScaleSpecification.Masked -> {
                colorScale.masks.mapIndexed { index, mask ->
                    val newLabels = BarLegendLabels(currentUnits = this.currentUnits)
                    items.getOrNull(index)?.copy(
                        colorScaleOptions = mask.colorScale, labels = newLabels
                    ) ?: BarLegendItem(
                        colorScaleOptions = mask.colorScale, labels = newLabels
                    )
                }
            }

            else -> emptyList()
        }
        // FIX: Return only the copy. Do not call .units() here as it triggers a recalculation
        return copy(items = newItems)
    }

    override fun apply(colorScale: ColorScaleOptions): Any {
        TODO("Not yet implemented")
        //val newColorScale = ColorScaleSpecification(ColorScaleLegend())
        return 0
    }

    override fun updateFromPaint(paint: LayerPaint): Legend {
        //println(">>> BarLegend.updateFromPaint()")
        return this
    }

}

/**
 * Describes a single color bar rendered by `BarLegend`.
 */
@Keep
data class BarLegendItem<UnitType : Dimension>( // <<< FIX HERE
    val colorScaleOptions: ColorScaleOptions,
    var labels: BarLegendLabels<UnitType>,
    val height: Dp = BarLegendDefaults.barHeight,
    val rounded: Boolean = BarLegendDefaults.rounded,
    val margins: Dp = BarLegendDefaults.barMargins
) {
    var colorScale: ColorScale = ColorScale(options = colorScaleOptions)
}

/**
 * Configures value annotations drawn on a `BarLegend`.
 */
@Keep
data class BarLegendLabels<UnitType : Dimension>(
    var values: Values<UnitType>? = null,
    val placement: Placement = Placement.MIDDLE,
    val textStroke: TextStroke = TextStroke(),
    val textShadow: Shadow = BarLegendDefaults.textShadow,
    var normalized: Boolean = BarLegendDefaults.normalized,
    var currentUnits: UnitType?,
    val formatter: (measurement: Measurement<UnitType>, index: Int) -> String = { measurement, idx ->
        // Use the property directly to avoid capturing an old value
        val targetUnit = currentUnits

        val displayMeasurement = if (targetUnit != null && measurement.unit != targetUnit) {
            measurement.converted(to = targetUnit)
        } else {
            measurement
        }

        val intValue = displayMeasurement.value.toInt()

        // FIX: Resolve the symbol from the converted unit (targetUnit)
        val symbol = targetUnit?.symbol ?: measurement.unit.symbol

        if (idx == 0) "$intValue$symbol" else "$intValue"
    },
) {
    // a helper to ensure we always use the LATEST currentUnits
    fun format(measurement: Measurement<UnitType>, index: Int): String {
        return formatter(measurement, index)
    }


    // Sealed class is more idiomatic for "enum with associated values" in Kotlin
    sealed class Values<UnitType : Dimension> {
        data class FromValues<UnitType : Dimension>(val accessor: (Dimension?) -> List<Double>) : Values<UnitType>()
        data class FromLabels<UnitType : Dimension>(val accessor: (Dimension?) -> List<Pair<Double, String>>) :
            Values<UnitType>()

        //data class Every(val accessor: (Any?) -> Double) : Values<Any>()
        //data class Every<T : Any>(val accessor: (T) -> Double) : Values<T>()
        data class Every<UnitType : Dimension>(val accessor: (Dimension?) -> Double) : Values<UnitType>()
    }

    enum class Placement { TOP, MIDDLE, BOTTOM }

    data class TextStroke(
        val color: Color = BarLegendDefaults.textStrokeColor, val width: Float = BarLegendDefaults.textStrokeWidth
    )
}

// Mock implementation for MeasurementUnits.dimensions - replace with your actual code
private fun <T : Any> MeasurementUnits.dimensions(forType: MeasurementUnits.MeasurementType?): T? {
    val dimension: Dimension? = when (forType) {
        MeasurementUnits.MeasurementType.TEMPERATURE -> {
            when (this) {
                MeasurementUnits.METRIC -> UnitTemperature.celsius
                MeasurementUnits.IMPERIAL -> UnitTemperature.fahrenheit
                else -> {
                    UnitTemperature.celsius
                }
            }
        }

        MeasurementUnits.MeasurementType.TEMPERATURE_DELTA -> {
            when (this) {
                MeasurementUnits.METRIC -> UnitTemperatureDelta.celsius
                MeasurementUnits.IMPERIAL -> UnitTemperatureDelta.fahrenheit
                else -> {
                    UnitTemperatureDelta.celsius
                }
            }
        }

        MeasurementUnits.MeasurementType.SNOWFALL -> {
            when (this) {
                MeasurementUnits.METRIC -> UnitLength.centimeters
                MeasurementUnits.IMPERIAL -> UnitLength.inches
                else -> {
                    UnitLength.centimeters
                }
            }
        }

        MeasurementUnits.MeasurementType.RATIO -> {
            UnitProportion.percent
        }

        MeasurementUnits.MeasurementType.NONE -> {
            UnitNone.none
        }

        MeasurementUnits.MeasurementType.PRECIPITATION -> {
            when (this) {
                MeasurementUnits.METRIC -> UnitLength.millimeters
                MeasurementUnits.IMPERIAL -> UnitLength.inches
                else -> {
                    UnitLength.inches
                }
            }
        }

        MeasurementUnits.MeasurementType.DISTANCE -> {
            when (this) {
                MeasurementUnits.METRIC -> UnitLength.kilometers
                MeasurementUnits.IMPERIAL -> UnitLength.miles
                else -> {
                    UnitLength.kilometers
                }
            }
        }

        MeasurementUnits.MeasurementType.CONCENTRATION -> {
            UnitConcentrationMass.microgramsPerCubicMeter
        }


        MeasurementUnits.MeasurementType.SPEED -> {
            when (this) {
                MeasurementUnits.METRIC -> UnitSpeed.kilometersPerHour
                else -> {
                    UnitSpeed.milesPerHour
                }
            }
        }

        MeasurementUnits.MeasurementType.HEIGHT -> {
            when (this) {
                MeasurementUnits.METRIC -> UnitHeight.meters
                else -> {
                    UnitHeight.feet
                }
            }
        }

        MeasurementUnits.MeasurementType.HEIGHT_DIFFERENCE -> {
            when (this) {
                MeasurementUnits.METRIC -> UnitHeightDifference.meters
                else -> {
                    UnitHeightDifference.feet
                }
            }
        }
        // Add other cases for Precipitation, etc.
        else -> null
    }


    // This cast is inherently unsafe but necessary because of type erasure.
    // We are trusting that the caller (BarLegend<UnitTemperature>) has the correct UnitType.
    @Suppress("UNCHECKED_CAST") return dimension as? T
}