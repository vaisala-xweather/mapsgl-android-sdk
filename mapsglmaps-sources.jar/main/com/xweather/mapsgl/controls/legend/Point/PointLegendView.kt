package com.xweather.mapsgl.controls.legend.Point

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.text.TextPaint
import android.util.AttributeSet
import android.util.TypedValue
import android.view.View
import androidx.compose.ui.graphics.toArgb
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max


// Data classes remain the same
data class Margin(val width: Float, val height: Float) // in dp

private data class ItemLayout(
    val cols: Int,
    val rows: Int,
    val rowHeight: Float,
    val colWidth: Float,
    val totalHeight: Float
)

class PointLegendView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: AttributeSet? = null
) : View(context, defStyleAttr) {

    private val noLegendDataLabel = "No legend data"

    var legend: PointLegend = PointLegend(id = "default")
        set(value) {
            field = value
            // When the legend data changes, invalidate the view to trigger a re-measure and re-draw.
            requestLayout()
            invalidate()
        }

    private val circlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.LEFT
    }
    private val italicTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.LEFT
        typeface = android.graphics.Typeface.create(
            android.graphics.Typeface.DEFAULT,
            android.graphics.Typeface.ITALIC
        )
    }

    init {
        setBackgroundColor(Color.TRANSPARENT)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val availableWidth = MeasureSpec.getSize(widthMeasureSpec).toFloat()
        val calculatedHeight = calculateLegendHeight(availableWidth)
        val resolvedHeight = resolveSize(calculatedHeight.toInt(), heightMeasureSpec)
        setMeasuredDimension(availableWidth.toInt(), resolvedHeight)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (legend.items.isNotEmpty() && legend.items[0].emptyItem) {
            // FIX: Convert SP to PX for font size
            italicTextPaint.color = legend.labelColor.toArgb()
            italicTextPaint.textSize = spToPx(legend.labelFontSize.value)
            val textBounds = Rect()
            italicTextPaint.getTextBounds(noLegendDataLabel, 0, noLegendDataLabel.length, textBounds)
            canvas.drawText(noLegendDataLabel, 0f, textBounds.height().toFloat() - 4f, italicTextPaint)
            return
        }

        val layout = calculateLayout(width.toFloat())
        var itemIndex = 0
        var runningX = 0f
        // FIX: Convert all DP values to PX at the beginning of the function
        val radiusPx = dpToPx(legend.radius.toFloat())
        val marginWidthPx = dpToPx(legend.margins.width)


        textPaint.typeface = if (legend.labelFontWeight == androidx.compose.ui.text.font.FontWeight.Bold) {
            android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
        } else {
            android.graphics.Typeface.DEFAULT
        }


        for (col in 0 until layout.cols) {
            var x = layout.colWidth * col
            for (row in 0 until layout.rows) {
                if (itemIndex >= legend.items.size) break
                val currentItem = legend.items[itemIndex]

                if (layout.rows == 1) {
                    val itemDims = dimensions(
                        currentItem,
                        forWidth = width.toFloat(),
                        includingMargins = false,
                    )
                    x = runningX + radiusPx
                    runningX += itemDims.width + (marginWidthPx * 2)
                }

                val y = layout.rowHeight * row
                drawItem(item = currentItem, canvas = canvas, pos = PointF(x, y), width = width.toFloat())
                itemIndex++
            }
        }
    }

    private fun drawItem(item: PointLegendItem, canvas: Canvas, pos: PointF, width: Float) {
        // FIX: Convert DP values to PX consistently
        val radiusPx = dpToPx(legend.radius.toFloat())
        val marginWidthPx = dpToPx(legend.margins.width)

        val dims = dimensions(
            item,
            forWidth = width,
            includingMargins = false,
        )
        val pointDim = radiusPx * 2f

        val circleY = pos.y + (dims.height - pointDim) / 2f
        circlePaint.color = item.color
        canvas.drawCircle(pos.x + radiusPx /* + marginWidthPx*/, circleY + radiusPx, radiusPx, circlePaint)

        // FIX: Convert SP to PX for font size
        textPaint.color = legend.labelColor.toArgb()
        textPaint.textSize = spToPx(legend.labelFontSize.value)


        val textBounds = Rect()
        textPaint.getTextBounds(item.label, 0, item.label.length, textBounds)
        val labelY = pos.y + (dims.height - textBounds.height()) / 2f + textBounds.height()
        val labelX = pos.x + pointDim + marginWidthPx //+ 4.dp.value

        canvas.drawText(item.label, labelX, labelY, textPaint)
    }

    private fun calculateLayout(forWidth: Float): ItemLayout {
        if (legend.items.isEmpty()) {
            return ItemLayout(0, 0, 0f, 0f, 0f)
        }

        var maxWidth = -1f
        var maxHeight = -1f
        // FIX: Convert DP values to PX for calculations
        val marginWidthPx = dpToPx(legend.margins.width)
        val marginHeightPx = dpToPx(legend.margins.height)

        for (item in legend.items) {
            val dims = dimensions(
                item,
                forWidth = forWidth,
                includingMargins = false,
            )
            maxWidth = max(maxWidth, dims.width + marginWidthPx * 2f)
            maxHeight = max(maxHeight, dims.height + marginHeightPx)
        }

        val cols = max(floor(forWidth / maxWidth).toInt(), 1)
        val rows = max(ceil(legend.items.size.toDouble() / cols.toDouble()).toInt(), 1)
        val colWidth = max(maxWidth, forWidth / cols.toFloat())
        val totalHeight = maxHeight * rows

        return ItemLayout(cols, rows, maxHeight, colWidth, totalHeight)
    }

    private fun calculateLegendHeight(forWidth: Float): Float {
        return calculateLayout(forWidth).totalHeight
    }

    private fun dimensions(item: PointLegendItem, forWidth: Float, includingMargins: Boolean): SizeF {
        // FIX: Convert all units to PX before calculations
        val radiusPx = dpToPx(legend.radius.toFloat())
        val marginWidthPx = dpToPx(legend.margins.width)
        val marginHeightPx = dpToPx(legend.margins.height)
        val textDims = dimensions(
            item.label, forWidth = forWidth,
        )

        val dims = SizeF(
            width = textDims.width + marginWidthPx + radiusPx * 2f,
            height = max(textDims.height, radiusPx * 2f)
        )

        return if (includingMargins) {
            SizeF(width = dims.width + marginWidthPx, height = dims.height + marginHeightPx)
        } else {
            dims
        }
    }

    private fun dimensions(labelText: String, forWidth: Float): SizeF {
        // FIX: Convert SP to PX for font size
        textPaint.textSize = spToPx(legend.labelFontSize.value)
        val textBounds = Rect()
        textPaint.getTextBounds(labelText, 0, labelText.length, textBounds)
        return SizeF(width = textPaint.measureText(labelText), height = textBounds.height().toFloat())
    }

    // --- Utility Functions and Data Classes ---
    // FIX: Removed the redundant dpToPx(Double) and made types consistent
    private fun dpToPx(dp: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, resources.displayMetrics)

    private fun spToPx(sp: Float): Float =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp, resources.displayMetrics)

    // FIX: Simplified data classes to use Float consistently
    private data class PointF(val x: Float, val y: Float)
    private data class SizeF(val width: Float, val height: Float)
}
 