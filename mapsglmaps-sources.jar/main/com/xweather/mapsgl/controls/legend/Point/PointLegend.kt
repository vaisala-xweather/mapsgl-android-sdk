package com.xweather.mapsgl.controls.legend.Point

import androidx.annotation.ColorInt
import androidx.annotation.Keep
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.LegendDefaults
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegendItem
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.style.LayerPaint

/**
 * Default values for the PointLegend.
 */
object PointLegendDefaults {
    val radius = 4.dp
    val labelFontSize: TextUnit = 11.sp
    val labelColor: Color = Color.Black // Equivalent to UIColor.label in light mode
}

/**
 * A placeholder data class for PointLegendItem.
 * This should match the definition used in your PointLegendView.
 */
@Keep
data class PointLegendItem(
    @ColorInt var color: Int,
    val label: String,
    val emptyItem: Boolean = false
) {}

/**
 * Renders a legend composed of labeled point markers.
 *
 * @param id Unique identifier used when registering the legend with a LegendControl.
 * @param title Display title shown above the legend content.
 * @param titleColorValue Color of the legend title.
 * @param labelFontSize Font size for legend item labels.
 * @param labelColor Color of the text labels.
 * @param radius Radius for the circular glyph drawn for each legend item.
 * @param items Static items rendered by the legend when no resolver is provided.
 * @param itemResolver Optional resolver that converts queried features into dynamic legend items.
 * @param layerId Optional layer identifier (or regex) used to scope dynamic legend updates.
 * @param units Units currently applied to any measurement values drawn by the legend.
 */
@Keep
data class PointLegend(
    override val id: String,
    override var title: String? = null,
    val labelFontWeight: FontWeight = FontWeight.Normal, // The missing property
    override var titleFontSize: TextUnit = LegendDefaults.titleFontSize,
    var titleFontWeight: FontWeight = LegendDefaults.titleFontWeight,
    override var titleColorValue: Color = LegendDefaults.titleColor,
    var labelFontSize: TextUnit = PointLegendDefaults.labelFontSize,
    var labelColor: Color = PointLegendDefaults.labelColor,
    var radius: Double = PointLegendDefaults.radius.value.toDouble(),
    var items: List<PointLegendItem> = emptyList(),
    var itemResolver: PointLegendFeatureResolver? = null,
    var layerId: String? = null,
    override var units: MeasurementUnits = MeasurementUnits.IMPERIAL,
    var margins: Margin = Margin(width = 4.dp.value, height = 4.dp.value)
) : Legend {

    val layerIdRegex: Regex?
        get() = layerId?.let {
            try {
                Regex(it)
            } catch (e: Exception) {
                null
            }
        }

    //region Convenience Immutable Setters


    /** Returns a new PointLegend with the updated label font size. */
    fun labelFontSize(newValue: TextUnit) = this.copy(labelFontSize = newValue)

    /** Returns a new PointLegend with the updated label color. */
    fun labelColor(newValue: Color) = this.copy(labelColor = newValue)

    /** Returns a new PointLegend with the updated glyph radius. */
    fun radius(newValue: Double) = this.copy(radius = newValue)

    /** Returns a new PointLegend with the updated items. */
    override fun items(newItems: List<PointLegendItem>): PointLegend {
        return this.copy(items = newItems)
    }

    override fun items(newItems: List<BarLegendItem<Dimension>>): BarLegend<*> {
        TODO("Please do not use BarLegendItems with PointLegend")
    }

    /** Returns a new PointLegend with the updated item resolver. */
    fun itemResolver(newValue: PointLegendFeatureResolver?) = this.copy(itemResolver = newValue)

    /** Returns a new PointLegend with the updated layer ID. */
    fun layerId(newValue: String?) = this.copy(layerId = newValue)
    override fun title(newValue: String?): Legend {
        return this.copy(title = newValue)
    }

    override fun units(newValue: MeasurementUnits): Legend {
        return this.copy(units = newValue)
    }

    override fun updateFromPaint(paint: LayerPaint): Legend {
        println(">>> PointLegend.updateFromPaint()")
        return this
    }

    //endregion
}
