package com.xweather.mapsgl.controls.legend

import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.toColorInt
import com.xweather.mapsgl.anim.Easing
import com.xweather.mapsgl.anim.EasingCurveFactory
import com.xweather.mapsgl.controls.legend.Point.AlertsLegendItemResolver
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.Point.PointLegendItem
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegendItem
import com.xweather.mapsgl.controls.legend.bar.BarLegendLabels
import com.xweather.mapsgl.extensions.Measurement
import com.xweather.mapsgl.extensions.UnitConcentrationMass
import com.xweather.mapsgl.extensions.UnitHeight
import com.xweather.mapsgl.extensions.UnitHeightDifference
import com.xweather.mapsgl.extensions.UnitLength
import com.xweather.mapsgl.extensions.UnitSpeed
import com.xweather.mapsgl.extensions.UnitTemperature
import com.xweather.mapsgl.extensions.UnitTemperatureDelta
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.toColor

/**
 *  NOTE: This file is auto-generated and should not be edited directly!
 *  Last updated: 2025-11-14T18:31:03.868Z
 */
enum class LegendCode(val id: String) {
    ACCUM_PRECIP("accum-precip"), ACCUM_SNOW("accum-snow"), AIR_QUALITY_HEALTH_INDEX("air-quality-health-index"), AIR_QUALITY_INDEX(
        "air-quality-index"
    ),
    AIR_QUALITY_INDEX_CAI("air-quality-index-cai"), AIR_QUALITY_INDEX_CAQI("air-quality-index-caqi"), AIR_QUALITY_INDEX_CATEGORIES(
        "air-quality-index-categories"
    ),
    AIR_QUALITY_INDEX_CHINA("air-quality-index-china"), AIR_QUALITY_INDEX_EAQI("air-quality-index-eaqi"), AIR_QUALITY_INDEX_INDIA(
        "air-quality-index-india"
    ),
    AIR_QUALITY_CO("air-quality-co"), AIR_QUALITY_NO("air-quality-no"), AIR_QUALITY_NO2("air-quality-no2"), AIR_QUALITY_O3(
        "air-quality-o3"
    ),
    AIR_QUALITY_PM10("air-quality-pm10"), AIR_QUALITY_PM2P5("air-quality-pm2p5"), AIR_QUALITY_SO2("air-quality-so2"), ALERTS(
        "alerts"
    ),
    CLOUD_COVER("cloud-cover"), CONVECTIVE("convective"), DEW_POINT("dew-point"), DROUGHT("drought"), EARTHQUAKE("earthquake"), FEELS_LIKE(
        "feels-like"
    ),
    FIRE_OBSERVATION("fire-observation"), FIRE_OUTLOOK("fire-outlook"), FIRES_VPD("fires-vpd"), HAIL_POSH("hail-posh"), HAIL_SIZE(
        "hail-size"
    ),
    HAIL_PROB("hail-prob"),
    HAIL_THREAT("hail-threat"), HEAT_INDEX("heat-index"), HUMIDITY("humidity"), LIGHTNING("lightning"), LIGHTNING_DENSITY(
        "lightning-density"
    ),
    LIGHTNING_THREAT("lightning-threat"), PRESSURE("pressure"), OCEAN_CURRENT("ocean-current"), RADAR("radar"), RIVER_OBSERVATION(
        "river-observation"
    ),
    ROAD_WEATHER_RISK("road-weather-risk"), ROAD_WEATHER_SUMMARY("road-weather-summary"), ROAD_WEATHER_SURFACE("road-weather-surface"), ROAD_WEATHER_TEMPERATURE(
        "road-weather-temperature"
    ),
    ROAD_WEATHER_TEMPERATURE_FREEZE("road-weather-temperature-freeze"), SNOW_DEPTH("snow-depth"), STORM_SURGE("storm-surge"), STORM_CELL(
        "storm-cell"
    ),
    STORM_REPORT("storm-report"), TEMPERATURE("temperature"), TEMPERATURE_CHANGE_1HR("temperature-change-1hr"), TEMPERATURE_CHANGE_24HR(
        "temperature-change-24hr"
    ),
    TIDE_HEIGHT("tide-height"), TROPICAL_BREAKPOINT("tropical-breakpoint"), TROPICAL_CYCLONE("tropical-cyclone"), UVI("uvi"), VISIBILITY(
        "visibility"
    ),
    WAVE_HEIGHT("wave-height"), WAVE_PERIOD("wave-period"), WIND_CHILL("wind-chill"), WIND_SPEED("wind-speed"),
    FIRES_OUTLOOK("fire-outlook");

    fun getLegend(): Legend? {
        return when (this) {
            ACCUM_PRECIP -> {
                BarLegend(
                    id = id,
                    title = "Accumulated Precipitation",
                    measurement = MeasurementUnits.MeasurementType.PRECIPITATION,
                    resample = EasingCurveFactory.curve(Easing.IN_CIRC),

                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(

                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.precip_accum.stops,
                                range = 0.000..0.21167,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                // Set the specific units for this item's labels
                                currentUnits = MeasurementUnits.IMPERIAL.precipitationRate,

                                values = BarLegendLabels.Values.FromLabels { unit ->
                                    when (unit) {
                                        is UnitLength.Inches -> {
                                            val values = listOf(
                                                0.01,
                                                0.1,
                                                0.5,
                                                1.0,
                                                2.0,
                                                3.0,
                                                4.0,
                                                6.0,
                                                8.0,
                                                12.0,
                                                16.0,
                                                18.0,
                                                20.0,
                                                30.0
                                            )
                                            val max = 30.0
                                            values.mapIndexed { index, v ->
                                                val t = v / max
                                                // Apply outCirc: sqrt(1 - (t - 1)^2)
                                                val tMinusOne = t - 1.0
                                                val positionedAt = Math.sqrt(1.0 - (tMinusOne * tMinusOne))

                                                val formattedValue =
                                                    if (v % 1.0 == 0.0) v.toInt().toString() else v.toString()
                                                val label = if (index == 0) {
                                                    "$formattedValue in"
                                                } else {
                                                    formattedValue
                                                }
                                                Pair(positionedAt, label)
                                            }
                                        }

                                        else -> {
                                            val values = listOf(
                                                1,
                                                2,
                                                5,
                                                10,
                                                25,
                                                50,
                                                75,
                                                100,
                                                150,
                                                200,
                                                300,
                                                400,
                                                500,
                                                600,
                                                700
                                            )
                                            val max = 700.0
                                            values.mapIndexed { index, v ->
                                                val t = v / max
                                                // Apply outCirc: sqrt(1 - (t - 1)^2)
                                                val tMinusOne = t - 1.0
                                                val positionedAt = Math.sqrt(1.0 - (tMinusOne * tMinusOne))

                                                val label = if (index == 0) "${v.toInt()} mm" else "${v.toInt()}"
                                                Pair(positionedAt, label)
                                            }
                                        }
                                    }
                                }
                            ),
                        )
                    )
                )
            }

            AIR_QUALITY_INDEX -> {
                BarLegend(
                    id = id,
                    title = "Air Quality Index",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions =
                                ColorScaleOptions(
                                    listOf(
                                        ColorStop(0.0, toColor("#29e11f")),
                                        ColorStop(25.0, toColor("#29e11f")),
                                        ColorStop(75.0, toColor("#f8f92a")),
                                        ColorStop(125.0, toColor("#f9681b")),
                                        ColorStop(175.0, toColor("#f60115")),
                                        ColorStop(251.0, toColor("#7a2c83")),
                                        ColorStop(301.0, toColor("#65001b")),
                                        ColorStop(500.0, toColor("#65001b")),
                                    ),
                                    range = 0.0..500.0,
                                    interval = 0.0,
                                ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.ratio,
                                values = BarLegendLabels.Values.FromLabels { unit ->
                                    listOf(
                                        Pair(0.0, "0"),
                                        Pair(0.1, "50"),
                                        Pair(0.2, "100"),
                                        Pair(0.4, "150"),
                                        Pair(0.6, "200"),
                                        Pair(.8, "300"),
                                        Pair(.95, "400"),
                                        Pair(1.0, "500")
                                    )
                                }
                            ),
                        ),
                    ),
                )
            }

            AIR_QUALITY_HEALTH_INDEX -> PointLegend(
                id = id, title = "Air Quality Health Index (AQHI)", items = listOf(
                    PointLegendItem("#0000ff".toColorInt(), "Low"),
                    PointLegendItem("#00ff00".toColorInt(), "Moderate"),
                    PointLegendItem("#ffff00".toColorInt(), "High"),
                    PointLegendItem("#ff0000".toColorInt(), "Very High")
                )
            )

            AIR_QUALITY_INDEX_CATEGORIES -> PointLegend(
                id = id, title = "Air Quality", items = listOf(
                    PointLegendItem("#29e11f".toColorInt(), "Good"),
                    PointLegendItem("#f8f92a".toColorInt(), "Moderate"),
                    PointLegendItem("#f9681b".toColorInt(), "Sensitive Groups"),
                    PointLegendItem("#f60115".toColorInt(), "Unhealthy"),
                    PointLegendItem("#7a2c83".toColorInt(), "Very Unhealthy"),
                    PointLegendItem("#65001b".toColorInt(), "Hazardous")
                )
            )

            AIR_QUALITY_INDEX_CAI -> PointLegend(
                id = id, title = "Air Quality Index (Korean)", items = listOf(
                    PointLegendItem("#0000ff".toColorInt(), "Good"),
                    PointLegendItem("#00ff00".toColorInt(), "Moderate"),
                    PointLegendItem("#ffff00".toColorInt(), "Unhealthy"),
                    PointLegendItem("#ff0000".toColorInt(), "Very Unhealthy")
                )
            )

            AIR_QUALITY_INDEX_CAQI -> PointLegend(
                id = id, title = "Air Quality Index (Common)", items = listOf(
                    PointLegendItem("#79bc6a".toColorInt(), "Very Low"),
                    PointLegendItem("#bbcf4c".toColorInt(), "Low"),
                    PointLegendItem("#eec20b".toColorInt(), "Medium"),
                    PointLegendItem("#f29305".toColorInt(), "High"),
                    PointLegendItem("#e8416f".toColorInt(), "Very High")
                )
            )

            AIR_QUALITY_INDEX_CHINA -> PointLegend(
                id = id, title = "Air Quality Index (CHINA)", items = listOf(
                    PointLegendItem("#00ff00".toColorInt(), "Excellent"),
                    PointLegendItem("#ffff00".toColorInt(), "Good"),
                    PointLegendItem("#ff9900".toColorInt(), "Lightly Polluted"),
                    PointLegendItem("#ff0000".toColorInt(), "Moderately Polluted"),
                    PointLegendItem("#540099".toColorInt(), "Heavily Polluted"),
                    PointLegendItem("#800000".toColorInt(), "Severely Polluted")
                )
            )

            AIR_QUALITY_INDEX_EAQI -> PointLegend(
                id = id, title = "Air Quality Index (European)", items = listOf(
                    PointLegendItem("#50f0e6".toColorInt(), "Good"),
                    PointLegendItem("#50ccaa".toColorInt(), "Fair"),
                    PointLegendItem("#f0e641".toColorInt(), "Moderate"),
                    PointLegendItem("#ff5050".toColorInt(), "Poor"),
                    PointLegendItem("#960032".toColorInt(), "Very Poor"),
                    PointLegendItem("#7d2181".toColorInt(), "Extremely Poor")
                )
            )

            AIR_QUALITY_INDEX_INDIA -> PointLegend(
                id = id, title = "Air Quality Index (India)", items = listOf(
                    PointLegendItem("#00cc00".toColorInt(), "Good"),
                    PointLegendItem("#66cc00".toColorInt(), "Satisfactory"),
                    PointLegendItem("#ffff00".toColorInt(), "Moderate"),
                    PointLegendItem("#ff9900".toColorInt(), "Poor"),
                    PointLegendItem("#ff0000".toColorInt(), "Severe"),
                    PointLegendItem("#a52a2a".toColorInt(), "Hazardous")
                )
            )

            AIR_QUALITY_CO -> {
                val dataRange = Measurement(0.0, UnitConcentrationMass.microgramsPerCubicMeter)..Measurement(
                    1000.0,
                    UnitConcentrationMass.microgramsPerCubicMeter
                )
                BarLegend(
                    id = id,
                    title = "Carbon Monoxide (CO)",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    resample = EasingCurveFactory.curve(Easing.IN_OUT_SQRT),
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.co.stops,
                                range = 0.0..1000.0, //ColorScales.no.range,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.concentration,
                                values = BarLegendLabels.Values.FromValues { unit ->
                                    listOf(0.0, 125.0, 250.0, 500.0, 750.0, 1000.0) // Default values
                                },
                            ),
                        )
                    )
                )
            }

            AIR_QUALITY_NO -> BarLegend(
                id = id,
                title = "Nitrogen Monoxide(NO)",
                measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                units = MeasurementUnits.IMPERIAL,
                resample = EasingCurveFactory.curve(Easing.IN_SINE),
                items = listOf(
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.no.stops,
                            range = 0.0..100.0,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.concentration,
                            values = BarLegendLabels.Values.FromValues { unit ->
                                listOf(0.0, 5.0, 10.0, 25.0, 50.0, 100.0) // Default values
                            },
                        ),
                    )
                )
            )

            AIR_QUALITY_NO2 -> BarLegend(
                id = id,
                title = "Nitrogen Dioxide(NO2)",
                measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                units = MeasurementUnits.IMPERIAL,
                resample = EasingCurveFactory.curve(Easing.IN_SQRT),
                items = listOf(
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.no2.stops,
                            range = 0.0..100.0,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.concentration,

                            values = BarLegendLabels.Values.FromValues { unit ->
                                listOf(0.0, 10.0, 20.0, 30.0, 50.0, 100.0) // Default values
                            },
                        ),
                    )
                )
            )

            AIR_QUALITY_O3 -> BarLegend(
                id = id,
                title = "Ozone (03)",
                measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                resample = EasingCurveFactory.curve(Easing.IN_SQRT),
                items = listOf(
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.o3.stops,
                            range = 0.0..500.0,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.concentration,

                            values = BarLegendLabels.Values.FromValues { unit ->
                                listOf(0.0, 50.0, 100.0, 150.0, 225.0, 300.0) // Default values
                            },
                        ),
                    )
                )
            )

            AIR_QUALITY_PM10 -> BarLegend(
                id = id,
                title = "Particle Pollution (PM10)",
                measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                resample = EasingCurveFactory.curve(Easing.IN_CUBIC),
                items = listOf(
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.pm10.stops,
                            range = 0.0..1000.0,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.concentration,

                            values = BarLegendLabels.Values.FromValues { unit ->
                                listOf(0.0, 10.0, 25.0, 50.0, 100.0, 250.0, 500.0, 1000.0) // Default values
                            },
                        ),
                    )
                )
            )

            AIR_QUALITY_PM2P5 -> BarLegend(
                id = id,
                title = "Particle Pollution (PM2.5)",
                measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                resample = EasingCurveFactory.cubicBezier(0.65, 0.0, 0.85, 1.0),
                items = listOf(
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.pm25.stops,
                            range = 0.0..300.0,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.concentration,

                            values = BarLegendLabels.Values.FromValues { unit ->
                                listOf(0.0, 10.0, 25.0, 50.0, 100.0, 200.0, 300.0) // Default values
                            },
                        ),
                    )
                )
            )

            AIR_QUALITY_SO2 -> BarLegend(
                id = id,
                title = "Sulfur Dioxide (SO2)",
                measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                resample = EasingCurveFactory.curve(Easing.IN_SQRT),
                items = listOf(
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.so2.stops,
                            range = 0.0..100.0,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.concentration,

                            values = BarLegendLabels.Values.FromValues { unit ->
                                listOf(0.0, 5.0, 10.0, 25.0, 50.0, 100.0) // Default values
                            },
                        ),
                    )
                )
            )

            ALERTS -> PointLegend(
                id = id,
                title = "Alerts",
                layerId = "^alerts(-outline|-short-fuse)?",
                itemResolver = AlertsLegendItemResolver()
            )

            CLOUD_COVER -> {
                BarLegend(
                    id = id,
                    title = "Cloud Cover",
                    measurement = MeasurementUnits.MeasurementType.RATIO,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.sky.stops,
                                range = ColorScales.sky.range, //stops.first().value..ColorScales.sky.stops.last().value,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.ratio,
                                values = BarLegendLabels.Values.Every { 20.0 },
                            ),
                        ),
                    ),
                )
            }

            DEW_POINT -> {
                BarLegend(
                    id = id,
                    title = "Dew Point",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.dewPoint.stops,
                                range = -84.44..32.22,

                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                values = BarLegendLabels.Values.Every { 20.0 },
                            ),
                        ),
                    ),
                )
            }

            DROUGHT -> PointLegend(
                title = "Drought Monitor", layerId = null, id = "drought", items = listOf(
                    PointLegendItem(color = toColor("#ffff00").toArgb(), label = "Abnormally Dry"),
                    PointLegendItem(color = toColor("#fccc66").toArgb(), label = "Moderate"),
                    PointLegendItem(color = toColor("#ff9b00").toArgb(), label = "Severe"),
                    PointLegendItem(color = toColor("#e10000").toArgb(), label = "Extreme"),
                    PointLegendItem(color = toColor("#600000").toArgb(), label = "Exceptional")

                )
            )

            EARTHQUAKE -> PointLegend(
                title = "Earthquakes", layerId = null, id = "earthquake", items = listOf(
                    PointLegendItem(color = toColor("#6fb314").toArgb(), label = "Mini"),
                    PointLegendItem(color = toColor("#dfcb01").toArgb(), label = "Minor"),
                    PointLegendItem(color = toColor("#ce8f00").toArgb(), label = "Light"),
                    PointLegendItem(color = toColor("#ff5d01").toArgb(), label = "Moderate"),
                    PointLegendItem(color = toColor("#e90004").toArgb(), label = "Strong"),
                    PointLegendItem(color = toColor("#ce0052").toArgb(), label = "Major"),
                    PointLegendItem(color = toColor("#b90285").toArgb(), label = "Great"),
                    PointLegendItem(color = toColor("#f500ff").toArgb(), label = "Catastrophic")
                )
            )

            FIRES_OUTLOOK -> PointLegend(
                title = "Fire Outlook",
                layerId = null,
                id = "fire-outlook",
                items = listOf(
                    PointLegendItem(color = toColor("#FFB268").toArgb(), label = "Elevated"),
                    PointLegendItem(color = toColor("#FE666A").toArgb(), label = "Critical"),
                    PointLegendItem(color = toColor("#FE58FF").toArgb(), label = "Extreme")
                )
            )

            FEELS_LIKE -> {
                BarLegend(
                    id = id,
                    title = "Feels Like",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.temperature.stops,
                                range = -62.22..54.44,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                values = BarLegendLabels.Values.Every { 20.0 },
                            ),
                        ),
                    ),
                )
            }

            HEAT_INDEX -> {
                BarLegend(
                    id = id,
                    //  id = "conditions.heat_index.fill",
                    title = "Heat Index",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.temperature.stops,
                                range = 26.66667..54.44,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                values = BarLegendLabels.Values.Every { 10.0 },
                            ),
                        ),
                    ),
                )
            }

            HUMIDITY -> {
                BarLegend(
                    id = id,
                    title = "Humidity",
                    measurement = MeasurementUnits.MeasurementType.RATIO,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.humidity.stops,
                                range = 0.0..100.0,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.ratio,
                                values = BarLegendLabels.Values.Every { 20.0 },
                            ),
                        ),
                    ),
                )
            }

            RADAR -> BarLegend(
                id = id,
                title = "Radar",
                measurement = MeasurementUnits.MeasurementType.NONE,
                units = MeasurementUnits.IMPERIAL,
                items = listOf(
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.radarRain.stops,
                            range = 6.0..87.0,
                            normalized = false,
                            interpolate = true,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.ratio,
                            values = BarLegendLabels.Values.FromLabels {
                                listOf(
                                    0.0 to "Light",
                                    0.5 to "RAIN",
                                    1.0 to "Heavy"
                                )
                            },
                        ),
                    ),
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.radarMix.stops,
                            range = 6.0..87.0,
                            normalized = false,
                            interpolate = true,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.none,
                            values = BarLegendLabels.Values.FromLabels {
                                listOf(
                                    0.0 to "Light",
                                    0.5 to "SNOW",
                                    1.0 to "Heavy"
                                )
                            },
                        ),
                    ),
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.radarSnow.stops,
                            range = 6.0..87.0,
                            normalized = false,
                            interpolate = true,
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.none,
                            values = BarLegendLabels.Values.FromLabels {
                                listOf(
                                    0.0 to "Light",
                                    0.5 to "MIX",
                                    1.0 to "Heavy"
                                )
                            },
                        ),
                    ),
                ),
            )

            SNOW_DEPTH -> {
                BarLegend(
                    id = id,
                    title = "Snow Depth",
                    measurement = MeasurementUnits.MeasurementType.SNOWFALL,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.cubicBezier(0.7, 0.0, 1.0, 0.6),
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.snowdepth.stops,
                                //range = 0.0254..7.9248,  //1 in, in meters to
                                range = 0.0254..7.9248,  //1 in, in meters to
                                //range = 002.54..792.48,  //1 in, in meters to
                                //range = 0.00..0.8,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.snowfall,
                                values = BarLegendLabels.Values.FromValues { unit ->
                                    when (unit) {
                                        is UnitLength.Inches -> listOf(
                                            0.01,
                                            3.0,
                                            6.0,
                                            12.0,
                                            18.0,
                                            24.0,
                                            36.0,
                                            48.0,
                                            72.0,
                                            96.0,
                                            120.0,
                                            168.0,
                                            216.0,
                                            300.0
                                        )

                                        else -> listOf(3.0, 5.0, 10.0, 25.0, 50.0, 100.0, 200.0, 350.0, 700.0)

                                    }
                                }),
                        ),
                    ),
                )
            }

            ACCUM_SNOW -> BarLegend(
                id = id,
                title = "Accumulated Snowfall",
                measurement = MeasurementUnits.MeasurementType.SNOWFALL,
                units = MeasurementUnits.IMPERIAL,
                resample = EasingCurveFactory.cubicBezier(0.55, 0.09, 1.0, 0.75),
                items = listOf(
                    BarLegendItem(
                        colorScaleOptions = ColorScaleOptions(
                            stops = ColorScales.snowdepth.stops,
                            range = 0.0254..1.524,  //1 in, in meters to
                        ),
                        labels = BarLegendLabels(
                            currentUnits = MeasurementUnits.IMPERIAL.snowfall,
                            values = BarLegendLabels.Values.FromValues { unit ->
                                when (unit) {
                                    is UnitLength.Inches -> listOf(
                                        0.1, 1.0, 3.0, 6.0, 12.0, 18.0, 24.0, 36.0, 48.0, 60.0
                                    )

                                    else -> listOf(0.5, 3.0, 5.0, 10.0, 25.0, 50.0, 100.0, 150.0)

                                }
                            }),
                    ),
                ),
            )

            TEMPERATURE -> {
                BarLegend(
                    id = id,
                    title = "Temperature",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(

                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.temperature.stops,
                                range = -62.22..54.44,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                // Set the specific units for this item's labels
                                currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitTemperature.Celsius -> 10.0
                                        is UnitTemperature.Fahrenheit -> 20.0
                                        else -> 1.0 // Default step if unit is neither
                                    }
                                }),
                        )
                    )
                )
            }

            TEMPERATURE_CHANGE_1HR -> {
                BarLegend(
                    id = id,
                    title = "1-Hour Temp Change",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE_DELTA,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(

                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.tempChange1Hour.stops,
                                range = -22.200000000000003..22.200000000000003,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.temperatureDelta,
                                values = BarLegendLabels.Values.Every { 10.0 }),
                        )
                    )
                )
            }

            TEMPERATURE_CHANGE_24HR -> {
                BarLegend(
                    id = id,
                    title = "24-Hour Temp Change",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE_DELTA,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(

                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.tempChange24Hour.stops,
                                range = -27.750000000000004..27.750000000000004,
                                normalized = false,
                                interpolate = true,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.temperatureDelta,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitTemperatureDelta.Celsius -> 10.0
                                        else -> 20.0 // Default step if unit is neither
                                    }
                                }),
                        )
                    )
                )
            }

            UVI -> {
                BarLegend(
                    id = id,
                    title = "Ultra Violet Index (UVI)",
                    measurement = MeasurementUnits.MeasurementType.NONE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.uvi.stops,
                                range = 1.0..12.0,
                                interpolate = false,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.none,
                                values = BarLegendLabels.Values.Every { 1.0 },
                            ),
                        ),
                    ),
                )
            }

            VISIBILITY -> {
                BarLegend(
                    id = id,
                    title = "Visibility",
                    measurement = MeasurementUnits.MeasurementType.DISTANCE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.visibility.stops,
                                range = ColorScales.visibility.range,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.distance,
                                values = BarLegendLabels.Values.Every { 1.0 },
                            ),
                        ),
                    ),
                )
            }

            WIND_SPEED -> {
                //val dataRange = Measurement(0.0, UnitSpeed.metersPerSecond)..Measurement(53.64, UnitSpeed.metersPerSecond)
                BarLegend(
                    id = id,
                    title = "Wind Speeds",
                    measurement = MeasurementUnits.MeasurementType.SPEED,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.windSpeed.stops,
                                range = ColorScales.windSpeed.range!!.start..ColorScales.windSpeed.range.endInclusive - 2.0,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.speed,
                                values = BarLegendLabels.Values.Every { 10.0 },
                            ),
                        ),
                    ),
                )
            }
            // Severe
            LIGHTNING -> PointLegend(
                id = id, title = "Lightning Strikes", items = listOf(
                    PointLegendItem("#eeeeee".toColorInt(), "< 1 minute"),
                    PointLegendItem("#F8E203".toColorInt(), "1-5 minutes"),
                    PointLegendItem("#F97000".toColorInt(), "5-10 minutes"),
                    PointLegendItem("#C4150D".toColorInt(), "> 10 minutes"),
                    PointLegendItem("#999999".toColorInt(), "Intra-cloud")
                )
            )

            LIGHTNING_THREAT -> {
                BarLegend(
                    id = id,
                    title = "Lightning Threats (lead time)",
                    measurement = MeasurementUnits.MeasurementType.DURATION,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.lightningThreat.stops,
                                range = 0.0..70.0,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.duration,
                                values = BarLegendLabels.Values.Every { 10.0 },
                            ),
                        ),
                    ),
                )
            }

            LIGHTNING_DENSITY -> {
                BarLegend(
                    id = id,
                    title = "Lightning Density",
                    measurement = MeasurementUnits.MeasurementType.NONE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.lightningDensity.stops,
                                range = 0.0..10.0,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.none,
                                values = BarLegendLabels.Values.Every { 1.0 },
                            ),
                        ),
                    ),
                )
            }
            // Tropical
            TROPICAL_BREAKPOINT -> PointLegend(
                id = id, title = "Tropical Cyclone Breakpoints", items = listOf(
                    PointLegendItem("#FFE403".toColorInt(), "Tropical Storm Watch"),
                    PointLegendItem("#FF9100".toColorInt(), "Tropical Storm Warning"),
                    PointLegendItem("#FF00D2".toColorInt(), "Hurricane Watch"),
                    PointLegendItem("#FF0018".toColorInt(), "Hurricane Warning"),
                )
            )

            TROPICAL_CYCLONE -> PointLegend(
                id = id, title = "Tropicl Cyclones", items = listOf(
                    PointLegendItem("#4875FB".toColorInt(), "Low"),
                    PointLegendItem("#FFE700".toColorInt(), "Depression"),
                    PointLegendItem("#FEA800".toColorInt(), "Storm"),
                    PointLegendItem("#DD0002".toColorInt(), "Cat 1"),
                    PointLegendItem("#FF0491".toColorInt(), "Cat 2"),
                    PointLegendItem("#DD00FD".toColorInt(), "Cat 3"),
                    PointLegendItem("#FEAFFF".toColorInt(), "Cat 4"),
                    PointLegendItem("#EFEFEF".toColorInt(), "Cat 5"),
                    PointLegendItem("#DD0002".toColorInt(), "Typhoon"),
                    PointLegendItem("#EFEFEF".toColorInt(), "Super Typhoon")
                )
            )

            STORM_CELL -> PointLegend(
                id = id, title = "Storm Cells", items = listOf(
                    PointLegendItem(ColorScales.SevereColors.GENERAL.toColorInt(), "General"),
                    PointLegendItem(ColorScales.SevereColors.HAIL.toColorInt(), "Hail"),
                    PointLegendItem(ColorScales.SevereColors.ROTATING.toColorInt(), "Rotating"),
                    PointLegendItem(ColorScales.SevereColors.TORNADO.toColorInt(), "Tornadic"),
                )
            )

            STORM_REPORT -> PointLegend(
                id = id, title = "Storm Reports", items = listOf(
                    PointLegendItem(ColorScales.StormReports.AVALANCHE.toColorInt(), "Avalanche"),
                    PointLegendItem(ColorScales.StormReports.BLIZZARD.toColorInt(), "Blizzard"),
                    PointLegendItem(ColorScales.StormReports.FIRE.toColorInt(), "Fire"),
                    PointLegendItem(ColorScales.StormReports.FLOOD.toColorInt(), "Flood"),
                    PointLegendItem(ColorScales.StormReports.FOG.toColorInt(), "Fog"),
                    PointLegendItem(ColorScales.StormReports.ICE.toColorInt(), "Ice"),
                    PointLegendItem(ColorScales.StormReports.HAIL.toColorInt(), "Hail"),
                    PointLegendItem(ColorScales.StormReports.LIGHTNING.toColorInt(), "Lightning"),
                    PointLegendItem(ColorScales.StormReports.RAIN.toColorInt(), "Rain"),
                    PointLegendItem(ColorScales.StormReports.SNOW.toColorInt(), "Snow"),
                    PointLegendItem(ColorScales.StormReports.TIDES.toColorInt(), "Tides"),
                    PointLegendItem(ColorScales.StormReports.TORNADO.toColorInt(), "Tornado"),
                    PointLegendItem(ColorScales.StormReports.WIND.toColorInt(), "Wind"),
                    PointLegendItem(ColorScales.StormReports.TROPICAL.toColorInt(), "Tropical"),
                    PointLegendItem(ColorScales.StormReports.OTHER.toColorInt(), "Other")
                )
            )

            STORM_SURGE -> {
                BarLegend(
                    id = id,
                    title = "Storm Surge",
                    measurement = MeasurementUnits.MeasurementType.HEIGHT,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.stormSurge.stops,
                                range = ColorScales.stormSurge.range,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.height,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitHeight.Meters -> 1.0
                                        is UnitHeight.Feet -> 5.0
                                        else -> 1.0
                                    }
                                },
                            ),
                        ),
                    ),
                )
            }

            HAIL_THREAT -> {
                BarLegend(
                    id = id,
                    title = "Hail Threats (lead time)",
                    measurement = MeasurementUnits.MeasurementType.DURATION,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.hailThreat.stops,
                                range = 0.0..70.0,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.duration,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitLength.Millimeters -> 10.0
                                        else -> 10.0
                                    }
                                },
                            ),
                        ),
                    ),
                )
            }

            HAIL_PROB -> {
                BarLegend(
                    id = id,
                    title = "Hail Severe Probability",
                    measurement = MeasurementUnits.MeasurementType.RATIO,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.hailProbability.stops,
                                range = 0.0..100.0,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.ratio,
                                values = BarLegendLabels.Values.FromValues { unit ->
                                    listOf(0.0, 25.0, 50.0, 75.0, 100.0)
                                },
                            ),
                        ),
                    ),
                )
            }

            HAIL_SIZE -> {
                BarLegend(
                    id = id,
                    title = "Hail Size",
                    measurement = MeasurementUnits.MeasurementType.PRECIPITATION,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.hailSizeV.stops,
                                //range = 0.0..25.4, // 1 inch, 25.4 mm
                                //range = 0.0..180.4, // 1 inch, 25.4 mm
                                range = 0.0..125.2
                            ),
                            /*
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.precipitationRate,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitLength.Millimeters -> 10.0
                                        else -> 1.0
                                    }
                                }, */
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.precipitationRate,
                                values = BarLegendLabels.Values.FromLabels { unit ->
                                    when (unit) {
                                        is UnitLength.Millimeters -> listOf(
                                            Pair(0.0, "0 mm"),
                                            Pair(0.1333, "10"),
                                            Pair(0.26666, "20"),
                                            Pair(0.4, "30"),
                                            Pair(0.5333333, "40"),
                                            Pair(.667, "50"),
                                            Pair(.8, "60"),
                                            Pair(.93, "70")
                                        )

                                        else -> listOf(
                                            Pair(0.0, "0 in"),
                                            Pair(0.1666, "0.5"),
                                            Pair(0.333, "1.0"),
                                            Pair(0.5, "1.5"),
                                            Pair(0.666666, "2.0"),
                                            Pair(.83333, "2.5"),
                                        )
                                    }
                                },
                            ),
                        ),
                    ),
                )
            }

            TIDE_HEIGHT -> {
                BarLegend(
                    id = id,
                    title = "Tide Height",
                    measurement = MeasurementUnits.MeasurementType.HEIGHT_DIFFERENCE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.tideHeight.stops,
                                range = -12.192..12.192,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.heightDifference,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitHeightDifference.Meters -> 2.0
                                        else -> 8.0
                                    }
                                },
                            ),
                        ),
                    ),
                )
            }

            WAVE_HEIGHT -> {
                BarLegend(
                    id = id,
                    title = "Wave Height",
                    measurement = MeasurementUnits.MeasurementType.HEIGHT_DIFFERENCE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.waveHeight.stops,
                                range = ColorScales.waveHeight.range,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.heightDifference,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitHeightDifference.Meters -> .5
                                        else -> 2.0
                                    }
                                },
                            ),
                        ),
                    ),
                )
            }

            OCEAN_CURRENT -> {
                BarLegend(
                    id = id,
                    title = "Ocean Currents",
                    measurement = MeasurementUnits.MeasurementType.SPEED,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.oceanCurrent.stops,
                                range = ColorScales.oceanCurrent.range
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.speed,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitSpeed.KilometersPerHour -> 1.0
                                        else -> 1.0
                                    }
                                },
                            ),
                        ),
                    ),
                )
            }

            WIND_CHILL -> {
                BarLegend(
                    id = id,
                    title = "Wind Chill",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    items = listOf(
                        BarLegendItem(
                            colorScaleOptions = ColorScaleOptions(
                                stops = ColorScales.temperature.stops,
                                range = ColorScales.temperature.range,
                            ),
                            labels = BarLegendLabels(
                                currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                values = BarLegendLabels.Values.Every { unit ->
                                    when (unit) {
                                        is UnitTemperature.Celsius -> 10.0
                                        else -> 20.0
                                    }
                                },
                            ),
                        ),
                    ),
                )
            }
            // Default case if a legend is not defined for a code
            else -> null
        }
    }
}
