package com.xweather.mapsgl.sources

import android.graphics.Bitmap
import java.net.URL
import java.util.Date
import com.mapbox.geojson.FeatureCollection
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.coordinates.LatLonBounds
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.Headers
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.utils.Signal
import com.xweather.mapsgl.utils.replaceVars
import com.xweather.mapsgl.weather.Authenticator
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

// TODO: we need GeoJSONSource to subclass TileSource due to hard type constraints in MapController until that can all be refactored
class GeoJSONSource(override val id: String) : TileSource<VectorData>() {
    override val kind: DataSourceKind = DataSourceKind.GEOJSON

    //override val tileCache: TileCache<DataType>
    //    get() = TODO("Not yet implemented")

    override var tileCache: TileCache<DataType> = TileCache()

    override fun getMetadataURL(): URL? {
        TODO("Not yet implemented")
    }

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?
    ): Any {
        return 0
    }

    var url: String? = null
    var data: FeatureCollection? = null
    var attribution: String? = null
    var authenticator: Authenticator? = null
    override var timeRange: ClosedRange<Date>? = null
    var validTimes: List<Date>? = null

    fun makeDataURL(variables: Map<String, Any> = emptyMap()): URL? {
        val url = this.url ?: run {
            println("[MapsGL] Invalid value for `url` in GeoJSON source $id")
            return null
        }

        val mergedVariables = variables.toMutableMap()
        timeRange?.let {
            mergedVariables["startDate"] = it.start
            mergedVariables["endDate"] = it.endInclusive
        }
        val urlString = url.replaceVars(mergedVariables, true)
        //println("GeoJSONSource.url: ${this.url}, $urlString")

        return URL(urlString)
    }

    fun invalidate() {
        // Implementation pending
    }
    
    override fun addConsumer(consumer: DataSourceConsumer) {}

    override fun removeConsumer(layerId: String) {}

    // MARK: Events
    val onLoadStart = Signal.eventOnly<Unit>()
    val onLoadComplete = Signal.eventOnly<Unit>()
    val onMetadataLoadStart = Signal.eventOnly<Unit>()
    val onMetadataLoad = Signal.eventOnly<Unit>()
    val onMetadataError = Signal.eventOnly<Unit>()
    val onDataChange = Signal.eventOnly<Unit>()
}