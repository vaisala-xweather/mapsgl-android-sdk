package com.xweather.mapsgl.sources

import VariableObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import androidx.lifecycle.Observer
import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.TileResponse
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import com.xweather.mapsgl.sources.data.EncodedData
import com.xweather.mapsgl.sources.data.EncodedTimeSeriesData
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileQuadrant
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URL
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.roundToInt

@Suppress("Dokka")
data class RequestOptions(
    val dataSetId: String,
    val dataMin: Double,
    val dataMax: Double,
    val outputMin: Double,
    val outputMax: Double,
    val outputNoDataValue: Double? = null,
    val validTimes: MutableList<Date>? = null
)

const val TAG = "XWeatherEncodedTileSource"
private const val BYTESIZE = 4
var outstandingReq = 0

/**
 *  XweatherEncodedTileSource.kt
 *
 *  A subclass of `EncodedTileSource` that is used to request and process encoded tile data from the MapsGL server.
 *
 *  Based  on the IOS version.
 *  @author Jason Suto 01/08/24
 *
 */

@Suppress("Dokka")
class XweatherEncodedTileSource(
    override var id: String,
    override var authenticator: XweatherAuthenticator?
) : EncodedTileSource("XweatherEncodedTileSource") {

    private val mapPrefixURL = "${mapsGLServer}/tile"
    private val tileByteArraySize = 1048576

    var isStale = false

    enum class Error {
        InvalidData
    }

    companion object {
        var s = 0
        var d = 0
        var stride = 0
        var paddingXByteSize = 0
    }


    override var kind: DataSourceKind = DataSourceKind.AERIS_ENCODED
//    override lateinit var bounds: MapBounds<LatitudeLongitude>
//    override val TileSource<DataType>.bounds: LatLonBounds
//        get() {
//            return this.bounds
//        }

    override var tileCache: TileCache<DataType> = TileCache(sourceID = id)
    override var datasets: List<DatasetType> = listOf()
    override val isEncoded: Boolean = true

    private var requestCount = 0
    var pendingRequestedTiles: MutableList<String> = mutableListOf()
    private val size = DataPool.originalSize
    private val padding = DataPool.padding
    val metadataObserver = VariableObserver()

    lateinit var passedObserver: Observer<String>
    private val dateFormatter: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault())
    private val paddingManager = PaddingManager(size, padding, tileCache, id)
    val threadSafeTileMap = ConcurrentHashMap<String, Tile<DataType>>()
    val threadSafeIntervalMap = ConcurrentHashMap<String, List<String>?>()

    init {
        metadata = SourceMetadata(ImageTileSource.MetadataSchema(), URL(mapsGLServer))
        isReady = false
    }

    private val layerId: String
        get() {
            return this.metadataObserver.layerId
        }

    override fun getMetadataURL(): URL? {
        var urlString = metadataURL ?: return null
        val datasetString = "&data-set-ids=${datasets.joinToString("&data-set-ids=") { it.code }}"

        if (pr.ON) pr.p(
            TAG,
            pr.metadata,
            "getMetadataURL() metadata.data.startDate: ${metadata.data.startDate}, metadata.data.endDate: ${metadata.data.endDate}"
        )

        val beginString = dateFormatter.format(metadata.data.startDate.time)
        val endString = dateFormatter.format(metadata.data.endDate.time)
        urlString = urlString.replace("&{datasets}", datasetString)
        urlString = urlString.replace("{startDate}", beginString).replace("{endDate}", endString)
        if (pr.ON) pr.p(TAG, pr.metadata, "getMetadataURL() returning $urlString ")
        return URL(urlString)
    }

    fun setObserver(observer: Observer<String>, layerID: String) {
        metadataObserver.observeVariableAndQuit(observer, layerID)
        passedObserver = observer
    }

    override suspend fun fetchMetadata(startDate: Date?, endDate: Date?): Result<Unit> {
        authenticator?.authenticate()

        if (startDate != null) {
            metadata.data.startDate = Date(startDate.time - 6 * 3600 * 1000)
        }
        if (endDate != null) {
            metadata.data.endDate = Date(endDate.time + 6 * 3600 * 1000)
        } else {
        }

        val url =
            getMetadataURL() ?: return Result.failure(IllegalStateException("Metadata URL could not be generated."))
        val request = URLRequest(url.toString())

        request.setHeader("Referer", MapController.packageName!!)
        authenticator?.credentials?.let { credentials ->
            request.setAuthorization("Bearer ${credentials.accessToken}")
        }

        withContext(Dispatchers.IO) {
            if (Timeline.sourceTimeHash[id] == null) {
                Timeline.sourceTimeHash[id] = LayerTimeline(id)
            }

            val success = metadata.load(request, metadataObserver.layerId, id)
            minZoom = metadata.data.minZoom
            maxZoom = metadata.data.maxZoom
            if (success) metaDataNeeded--
        }

        if (metaDataNeeded == 0) {
            metadataObserver.updateVariable(metadataObserver.layerId)
        }

        return try {
            // Your logic for fetching data...
            // If it completes without throwing an exception:
            Result.success(Unit)
        } catch (e: Exception) {
            // If any error occurs:
            Log.e(TAG, "Failed to fetch metadata", e)
            Result.failure(e)
        }
    }

    /** Test function to detect color format of image **/
    fun getImageColorFormat(imageBytes: ByteArray): Bitmap.Config? {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, options)
        return options.outConfig
    }

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?,
    ): Any { // Return type might need adjustment if you expect specific results
        //if (pr.ON) pr.p(TAG, pr.tileReq, "requestTiles() entered  ${layerId}")


        val tileUrl = makeTileURL(coord, mutableMapOf("time" to currentDate))
        val urlRequest = URLRequest(tileUrl.toString())
        prepareTileRequest(urlRequest, coord.time, intervals) // Sets body based on intervals

        // --- Tile Cache and State Logic (seems mostly okay) ---
        // Set correct time on coord for cache lookup if multiple intervals are passed
        val primaryLookupTime = intervals?.firstOrNull() ?: coord.time ?: "" // Use first interval or original time
        val coordForLookup = (TileCoord(coord.x, coord.y, coord.z))  // Use a copy for lookup key
        coordForLookup.time = primaryLookupTime
        // Get or create the tile representing this batch (maybe use first interval time?)


        val representativeTile = tileCache[coordForLookup] ?: TileType(coordForLookup).also { newTile ->
            newTile.isEncoded = true
            newTile.coordHash = coordForLookup.hash()
            tileCache.updateTile(newTile, coordForLookup) // Update cache with the representative tile
        }

        // Set pending *before* starting the load operation for this representative coord/interval list
        tileCache.setPending(true, representativeTile)
        representativeTile.state = TileState.Loading
        trigger(DataSourceEvents.TileLoadStart(id, representativeTile)) // Trigger event for the rep tile

        if (pr.ON) pr.p(TAG, pr.tileRequest, "requestTiles() req ${coord.hashShort()} intv: $intervals")

        var keepTrack = 0

        val tileResponse: TileResponse? = try {
            if (intervals != null) {
                for (interval in intervals) {
                    TileList.requestedList.add(this.id, coord.hashShort(), interval)
                    TileList.pendingList.add(this.id, coord.hashShort(), interval)
                }
            }

            if (pr.ON) pr.p(TAG, pr.tileReq, "cordHash:${coord.hashShort()}  ${urlRequest}")

            requestCount++
            pendingRequestedTiles.add(coord.hash())
            keepTrack = requestCount
            if (pr.ON) pr.p(
                TAG,
                pr.tileRequestActual,
                "requestTiles() actually requesting ${coord.hashShort()}   requestCount   $requestCount"
            )
            tileManager.loadTile(coord, urlRequest) // Call the modified suspending function
        } catch (e: Exception) {
            Log.e(TAG, "loadTile failed for ${coord.hashShort()}", e)
            //println("XweatherEncodedTileSource requestTiles() failed for ${coord.hashShort()}")
            requestCount--
            pendingRequestedTiles.remove(coord.hash())
            for (interval in intervals!!) {
                TileList.pendingList.remove(this.id, coord.hashShort(), interval)
                TileList.failedList.add(this.id, coord.hashShort(), interval)
            }
            tileCache.setPending(false, representativeTile) // Ensure pending is cleared on failure
            representativeTile.state = TileState.Failed // Mark as failed
            Timeline.removePendingEncodedDownload(id, coord.hash())
            null // Indicate failure
        }

        // --- Process the result ---
        if (tileResponse != null) {
            if (pr.ON) {
                pr.p(TAG, pr.receivedEnc, "recieved enc data: ${tileResponse.headers}")
            }
            requestCount--
            pendingRequestedTiles.remove(coord.hash())

            //if(pr.ON) pr.p(TAG, pr.tileRequestActual, "requestTiles() actually received ${tileResponse.headers.values}")
            if (pr.ON) pr.p(TAG, pr.tileRequestActual, "requestTiles() requestCount:     $requestCount     $keepTrack")

            for (interval in intervals!!) {
                TileList.pendingList.remove(this.id, coord.hashShort(), interval)
                TileList.readyList.add(this.id, coord.hashShort(), interval)
            }


            representativeTile.data = tileResponse.data
            tileResponse.data = 0
            // coordHash looks like 0:0/0/0/["2025-04-30T14:00:00Z"]

            if (Timeline.movedOnTileLoaded) {
                threadSafeTileMap[representativeTile.coordHash] = representativeTile
                threadSafeIntervalMap[representativeTile.coordHash] = intervals
            } else {
                //println("$TAG requestTiles() BEFORE ontileLoaded $keepTrack")
                onTileLoaded(representativeTile, intervals, 1)
                //println("$TAG requestTiles() AFTER ontileLoaded $keepTrack")
            }

            // onTileLoaded should handle setting state to Ready and clearing pending
        } else {
            // Failure already logged, state set to Failed
            requestCount--
            for (interval in intervals!!) {
                TileList.pendingList.remove(this.id, coord.hashShort(), interval)
                TileList.failedList.add(this.id, coord.hashShort(), interval)
            }

            Timeline.removePendingEncodedDownload(id, coord.hash())
            pendingRequestedTiles.remove(coord.hash())
            Log.w(TAG, "TileResponse was null for ${coord.hash()}, load failed.")
        }
        if (pr.ON) pr.p(TAG, pr.dataPool, "XWeatherEncodedTileSource requestTiles() exited")
        return RequestTileSuccess.alreadyExists // Placeholder, adjust as needed
    }

    private fun convertBitmapToByteArray(bitmap: Bitmap): ByteArray? {
        val byteBuffer = ByteBuffer.allocate(bitmap.byteCount)
        bitmap.copyPixelsToBuffer(byteBuffer)
        byteBuffer.rewind()
        //bitmap.recycle()
        return byteBuffer.array()
    }

    private fun moveBitmapToByteArray(bitmap: Bitmap): ByteArray {
        bitmap.copyPixelsToBuffer(DataPool.byteBuffer)
        DataPool.byteBuffer.rewind()
        //bitmap.recycle()
        return DataPool.byteBuffer.array()
    }


    /**
     * Backfills the edges of the tile with its neighbors' data and vice versa.
     * This mirrors the logic found in the JavaScript SDK for seamless tile stitching.
     */
    suspend fun onTileLoaded(tile: TileType, intervals: List<String>?, mode: Int) {
        // 1. First, perform the standard loading logic (decoding, data chunking, etc.)
        // Note: If you renamed your original function to onTileLoadedOrig, call that first.
        // onTileLoadedOrig(tile, intervals, mode)

        Timeline.totalDownloads++

        isStale = tileCache.isStale(tile)
        if (isStale) {
            tileCache.setStale(false, tile)
            //trigger(DataSourceEvents.TileDiscard(sourceID = id, tile = tile))
            if (pr.ON) pr.p(TAG, pr.flicker, "onTileLoaded() begining, STALE: ${tile.coordHash}")
            return
        } else {
            //todo: IF you remove this, paused dl does not work?
            //if(pr.ON) pr.p(TAG, pr.flicker, "onTileLoaded() begining set pending false: ${tile.coordHash}")
            tileCache.setPending(false, tile)
        }

        val doEdgeBlending = true
        val bitmap = parseTile(tile, (tile.data) as ByteArray, null)
        val tempMultiIntervalByteArray = try {
            if (DataPool.bigImageEnabled) {
                moveBitmapToByteArray(bitmap)
            } else {
                convertBitmapToByteArray(bitmap)
            }
        } finally {
        }

        if (intervals != null) {
            tile.data = null

            // Make a list of missing intervals
            val missingIntervalHash: HashMap<Int, String> = hashMapOf()
            if ((bitmap.byteCount / intervals.size) != tileByteArraySize) {
                for ((missingIndex, interval) in intervals.withIndex()) {
                    // if (!Timeline.sourceTimeHash[id]?.timeStrings?.contains(interval.substring(2,interval.length - 2))!!) // need to test this
                    if (!Timeline.validTimesList[layerId]!!.contains(interval.substring(2, interval.length - 2))) {
                        missingIntervalHash[missingIndex] = interval
                    }
                }
            }

            val dataHash: HashMap<Int, ByteArray?> = hashMapOf()
            var offset = 0
            for ((i, interval) in intervals.withIndex()) {
                val newTile = Tile<DataType>(TileCoord(tile.coord.x, tile.coord.y, tile.coord.z, time = interval))
                //if (pr.ON) pr.p(TAG, pr.validTimes, "   onTileLoaded() checking i:$i vs missingHash keys: ${missingIntervalHash.keys} " )
                if (missingIntervalHash.containsKey(i)) {
                    if (pr.ON) pr.p(TAG, pr.tileReceived, "onTileLoaded() identified missing index $i, skipping", 2)
                    offset++
                } else {
                    newTile.isEncoded = true
                    newTile.time = interval
                    newTile.state = TileState.Processing
                    newTile.data = getByteArrayChunkWidth(
                        tempMultiIntervalByteArray!!,
                        intervals.size - missingIntervalHash.size,
                        i - offset
                    )
                    dataHash[i - offset] = newTile.data as ByteArray
                    if (newTile.data != null) {
                        newTile.encodedData = EncodedData(newTile.data as ByteArray, doEdgeBlending, padding, id)
                        newTile.data = null
                        if (doEdgeBlending) {
                            val neighbors = newTile.coord.getNeighbors()
                            neighbors.forEach { (quadrant, neighborCoord) ->

                                // Normalize coordinates to handle world wraparound (x < 0 or x > max)
                                val normalizedCoord = neighborCoord.normalize()

                                // Check if the neighbor tile exists in our cache
                                val neighborTile = tileCache[normalizedCoord]

                                if (neighborTile?.encodedData?.paddedData == null) {
                                    this.id
                                    if (pr.ON) pr.p(TAG, pr.edgeBlend, "onTileLoaded() neighbor paddedData is null")


                                    if (pr.ON) pr.p(
                                        TAG,
                                        pr.edgeBlend,
                                        " onTileLoaded() trying to GET: ${id}${tile.coordHash}"
                                    )
                                    neighborTile?.encodedData?.paddedData =
                                        tileCache.nativeCache.getData("${id}${neighborTile?.coordHash}")

                                    if (pr.ON) pr.p(
                                        TAG,
                                        pr.edgeBlend,
                                        "onTileLoaded()  found n padTile in cache? ${neighborTile?.encodedData?.paddedData != null}"
                                    )
                                }

                                if (neighborTile?.encodedData?.paddedData != null) {

                                    if (pr.ON) pr.p(
                                        TAG,
                                        pr.edgeBlend,
                                        "     onTileLoaded() quad:$quadrant  neighborCoord: $neighborCoord",
                                    )

                                    // Perform the bidirectional backfill
                                    fillEdge(newTile, neighborTile) //this one works?
                                    fillEdge(neighborTile, newTile) //does not work

                                    // Flag that textures need re-binding since pixels changed
                                    newTile.needsBind = true
                                    neighborTile.needsBind = true


                                    if (!tileCache.bindList.contains(neighborTile.coordHash)) {
                                        tileCache.bindList.add(neighborTile.coordHash)
                                        tileCache.updateTile(neighborTile)
                                        neighborTile.state = TileState.Ready
                                    }
                                } else {
                                    if (quadrant == TileQuadrant.TopCenter) {
                                        //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padUP")
                                        paddingManager.padUp(newTile)
                                    } else if (quadrant == TileQuadrant.BottomCenter) {
                                        //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padDOWN")
                                        paddingManager.padDown(newTile)
                                    } else if (quadrant == TileQuadrant.MiddleLeft) {
                                        //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padLEFT")
                                        paddingManager.padLeft(newTile)
                                    } else if (quadrant == TileQuadrant.MiddleRight) {
                                        // if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padRIGHT")
                                        paddingManager.padRight(newTile)
                                    }
                                    newTile.needsBind = true

                                }
                            }
                        }
                        newTile.needsBind = true
                        tileCache.bindList.add(newTile.coordHash)
                        tileCache.updateTile(newTile)
                        newTile.state = TileState.Ready

                    } else {
                    } // end if (newTile.data != null)
                }
            }

            // Account for missing intervals
            for (key in missingIntervalHash.keys) {
                if (pr.ON) pr.p(
                    TAG,
                    pr.validTimes2,
                    "onTileLoaded() at the end, need to construct data for  missing index $key  -   ${missingIntervalHash[key]}",
                    2
                )
                val newTile = Tile<DataType>(TileCoord(tile.coord.x, tile.coord.y, tile.coord.z, time = intervals[key]))
                newTile.isEncoded = true
                newTile.time = intervals[key]
                newTile.state = TileState.Processing

                if (key != 0 && key != intervals.size - 1) { // blend if possible
                    if (pr.ON) pr.p(TAG, pr.validTimes2, "onTileLoaded() at the end, interval is not endpoint..", 2)
                    if (dataHash[key - 1] != null && dataHash[key + 1] != null) {
                        if (pr.ON) pr.p(
                            TAG,
                            pr.validTimes2,
                            "onTileLoaded() found needed data for blending, sizes ${dataHash[key - 1]!!.size} and ${dataHash[key + 1]!!.size}: ",
                            2
                        )
                        newTile.data = blendByteArrays(dataHash[key - 1]!!, dataHash[key + 1]!!)
                    }
                } else if (key == 0) {
                    newTile.data = dataHash[1]
                } else { //key at last interval
                    newTile.data = dataHash[key - 1]
                }

                try {
                    newTile.encodedData = EncodedData(newTile.data as ByteArray, doEdgeBlending, padding, id)
                    if (doEdgeBlending) {
                        paddingManager.blendEdges(newTile, tileCache, 2)
                    }
                    newTile.needsBind = true
                    tileCache.updateTile(newTile)
                    newTile.state = TileState.Ready
                    newTile.data = null
                } catch (e: NullPointerException) {
                    Log.e("XWeatherEncodedTileSource", "onTileLoaded() newTile.data was null for ${newTile.coordHash}")
                }
            }

            dataHash.clear()
        } // end intervls != null
        else { // intervals == null
            tile.encodedData = EncodedData(tempMultiIntervalByteArray!!, doEdgeBlending, padding, id)
            tile.state = TileState.Processing

            if (doEdgeBlending) {
                paddingManager.blendEdges(tile, tileCache, 3)
            }
            tile.data = null
            tile.state = TileState.Ready
            tile.needsBind = true
            tileCache.updateTile(tile)

            if (tileCache.pendingCount == 0 && _shouldTriggerLoadCompleteEvent) {
                if (pr.ON) pr.p(TAG, pr.groupTrigger, "groupTrigger LoadComplete for id: $id")
                ImageTileSource._apiEvent.value = RasterTileApiEvent.Reload(true) //this is needed
                //trigger(DataSourceEvents.LoadComplete(sourceID = id))
                //_shouldTriggerLoadCompleteEvent = false
            }

            if (tileCache.pendingCount == 0) {
                if (pr.ON) {
                    pr.p(TAG, pr.downloadsDone, "tileCache.pendingCount: 0")
                }
            }
        }

        //TODO: Commenting this out doesn't have as much of an effect as anticipated...
        tileCache.setPending(false, tile) // 'tile' here is the representative tile passed in
    }

    /**
     * Handles the coordinate math and wrapping for a single edge backfill.
     */
    /**
     * Handles the coordinate math and wrapping for a single edge backfill.
     * This version correctly handles Zoom 1 and world wraparound.
     */
    private fun fillEdge(destTile: TileType, sourceTile: TileType) {
        val destCoord = destTile.coord
        val sourceCoord = sourceTile.coord

        val initialDx = sourceCoord.x - destCoord.x
        val dy = sourceCoord.y - destCoord.y
        val dim = 1 shl destCoord.z

        // Case: Same tile (usually Zoom 0 world tile)
        if (initialDx == 0 && dy == 0) {
            if (destCoord.z == 0) {
                val destData = destTile.encodedData
                val sourceData = sourceTile.encodedData
                if (destData != null && sourceData != null) {
                    destData.backfillEdge(sourceData, -1, 0)
                    destData.backfillEdge(sourceData, 1, 0)
                }
            }
            return
        }

        val destData = destTile.encodedData ?: return
        val sourceData = sourceTile.encodedData ?: return

        // 1. Check Direct Neighbor (Distance must be 1)
        if (Math.abs(initialDx) <= 1 && Math.abs(dy) <= 1) {
            destData.backfillEdge(sourceData, initialDx, dy)
        }

        // 2. Check Wraparound Neighbor (Distance must be dim - 1)
        // At Z=1, dim=2, so dim-1 is 1. This means the same tile is both
        // a direct neighbor and a wraparound neighbor.
        if (dim > 1 && Math.abs(dy) <= 1) {
            var wrapDx = initialDx

            if (initialDx == 1 - dim) {
                // Source is 0, Dest is 1 (Z=1) or Source is 0, Dest is Max
                wrapDx = 1
                destData.backfillEdge(sourceData, wrapDx, dy)
            } else if (initialDx == dim - 1) {
                // Source is 1, Dest is 0 (Z=1) or Source is Max, Dest is 0
                wrapDx = -1
                destData.backfillEdge(sourceData, wrapDx, dy)
            }
        }
    }


    private fun fillEdgeOld(destTile: TileType, sourceTile: TileType) {
        var dx = sourceTile.coord.x - destTile.coord.x
        val dy = sourceTile.coord.y - destTile.coord.y
        val dim = Math.pow(2.0, destTile.coord.z.toDouble()).toInt()

        // Case: Same tile (usually Zoom 0 world tile)
        if (dx == 0 && dy == 0) {
            if (destTile.coord.z == 0) {
                val destData = destTile.encodedData
                val sourceData = sourceTile.encodedData
                if (destData != null && sourceData != null) {
                    // For Z0, we wrap the left edge to the right and vice versa
                    destData.backfillEdge(sourceData, -1, 0)
                    destData.backfillEdge(sourceData, 1, 0)

                }
            }
            return
        }

        // Vertical neighbor check
        if (abs(dy) > 1) return

        // Horizontal neighbor check with world wraparound
        if (abs(dx) > 1) {
            if (abs(dx + dim) == 1) {
                dx += dim
            } else if (Math.abs(dx - dim) == 1) {
                dx -= dim
            }
        }
        val destData = destTile.encodedData ?: return
        val sourceData = sourceTile.encodedData ?: return

        // If they are true neighbors (distance 1), perform the pixel copy
        if (abs(dx) <= 1) {
            destData.backfillEdge(sourceData, dx, dy)
        }
    }

    private fun getByteArrayChunkWidth(
        bitmapData: ByteArray,
        imageWidth: Int,
        chunkIndex: Int,
        bytesPerPixel: Int = 4
    ): ByteArray {

        val bytesPerRow = (imageWidth * 512) * bytesPerPixel

        val imageHeight = 512 // bitmapData.size / bytesPerRow
        val chunkWidth = 512

        val outputChunkBytesPerRow = chunkWidth * bytesPerPixel
        val outputChunkSize = outputChunkBytesPerRow * imageHeight
        val outputChunkData = ByteArray(outputChunkSize)

        // Calculate the starting X offset (in bytes) within each row for the desired chunk
        val chunkStartXOffsetBytes = chunkIndex * chunkWidth * bytesPerPixel

        // Copy the relevant segment from each row of the input data to the output data
        for (y in 0 until imageHeight) {
            // Start index of the current row in the input buffer
            val inputRowStartIndex = y * bytesPerRow
            // Start index of the segment to copy within the current input row
            val inputSegmentStartIndex = inputRowStartIndex + chunkStartXOffsetBytes
            // Start index of the current row in the output buffer
            val outputRowStartIndex = y * outputChunkBytesPerRow

            System.arraycopy(
                bitmapData,         // Source array
                inputSegmentStartIndex, // Start position in source
                outputChunkData,    // Destination array
                outputRowStartIndex,  // Start position in destination
                outputChunkBytesPerRow // Number of bytes to copy
            )
        }
        return outputChunkData
    }

    override fun addConsumer(consumer: DataSourceConsumer) {

    }

    /**
     * Removes a consumer
     * @param consumer: The consumer to be removed
     */
    override fun removeConsumer(layerId: String) {}

    fun extractValidTimes(jsonString: String): List<String> {
        val validTimesList = mutableListOf<String>()

        try {
            // 1. Parse the top-level JSON array (e.g., [[...]])
            val topLevelArray = JSONArray(jsonString)

            // 2. Get the inner JSON array (e.g., [{...}, {...}, ...])
            //    We assume the structure always has the inner array at index 0.
            if (topLevelArray.length() > 0) {
                val innerArray = topLevelArray.getJSONArray(0)

                // 3. Get the first JSON object from the inner array
                //    We assume the validTimes are in the first object.
                if (innerArray.length() > 0) {
                    val firstObject: JSONObject = innerArray.getJSONObject(0)

                    // 4. Get the "validTimes" JSON array from the object
                    if (firstObject.has("validTimes")) { // Check if the key exists
                        val timesArray: JSONArray = firstObject.getJSONArray("validTimes")

                        // 5. Iterate through the times array and add strings to our list
                        for (i in 0 until timesArray.length()) {
                            val timeString: String = timesArray.getString(i)
                            validTimesList.add(timeString)
                        }
                    } else {
                        System.err.println("Warning: 'validTimes' key not found in the first object.")
                    }
                } else {
                    System.err.println("Warning: Inner array is empty.")
                }
            } else {
                System.err.println("Warning: Top-level array is empty.")
            }

        } catch (e: JSONException) {
            // Handle potential errors during JSON parsing (e.g., invalid format)
            System.err.println("Error parsing JSON string: ${e.message}")
            e.printStackTrace()
            // Return empty list on error
            return emptyList()
        }

        return validTimesList
    }

    private fun blendByteArrays(
        byteArray1: ByteArray,
        byteArray2: ByteArray,
        blendFactor: Float = 0.5f // Default to a 50% blend
    ): ByteArray {

        // 1. Input Validation
        if (byteArray1.size != byteArray2.size) {
            throw IllegalArgumentException(
                "Input byte arrays must have the same size. " +
                        "byteArray1 size: ${byteArray1.size}, byteArray2 size: ${byteArray2.size}"
            )
        }

        // Ensure blendFactor is within the valid range [0.0, 1.0]
        val clampedBlendFactor = blendFactor.coerceIn(0.0f, 1.0f)
        val baseFactor = 1.0f - clampedBlendFactor

        val size = byteArray1.size
        val result = ByteArray(size) // Create the output array

        // 2. Iterate and Blend Each Byte
        for (i in 0 until size) {
            // Get bytes and treat them as unsigned integers (0-255) for calculation
            val byte1Unsigned = byteArray1[i].toInt() and 0xFF
            val byte2Unsigned = byteArray2[i].toInt() and 0xFF

            // Perform linear interpolation using floating-point math
            val blendedValueFloat = (byte1Unsigned * baseFactor) + (byte2Unsigned * clampedBlendFactor)

            // Round, clamp to valid byte range (0-255), and convert back to Byte
            val blendedByteValue = blendedValueFloat
                .roundToInt()       // Round to nearest integer
                .coerceIn(0, 255) // Clamp to unsigned byte range
                .toByte()           // Convert back to signed Byte type

            result[i] = blendedByteValue
        }
        // 3. Return the Result
        return result
    }
}

typealias DataType = EncodedTimeSeriesData