package com.xweather.mapsgl.sources

import com.xweather.mapsgl.gl.extensions.pr
import java.nio.ByteBuffer

class DataPool {
    companion object {
        var numBigActive = 0
        var totalBig = 0
        var bindCount = 0

        var paddedActive = 0
        var paddedTotal = 0
        var biggestPadded = 0

        val bigImageEnabled = false
        val paddedEnabled = true
        var lastPaddedCount = 0
        val originalSize = 512
        val padding = 8
        val totalSize = originalSize + padding + padding
        var byteBuffer: ByteBuffer
        //var paddedByteBuffer: ByteBuffer

        val freepBBList = mutableListOf<ByteArray>()
        val usedBBList = mutableListOf<ByteArray>()

        init {

            if (bigImageEnabled)
                byteBuffer = ByteBuffer.allocate(1024)
            else
                byteBuffer = ByteBuffer.allocate(0)

            if (false && paddedEnabled) {
                for (i in 0 until 10) {
                    freepBBList.add(ByteBuffer.allocate(totalSize * totalSize * 4).array())
                }
            }
        }

        fun incr() {
            numBigActive++
            totalBig++
        }

        fun decr() {
            numBigActive--
        }

        fun pIncr() {
            paddedActive++
            paddedTotal++
        }

        fun pDecr() {
            paddedActive--
        }

        fun bigStatus() {
            if (pr.ON) pr.p("DataPool", pr.dataPool, "numActive = $numBigActive, total = $totalBig")
        }

        fun paddedStatus(message: String = "") {
            if (lastPaddedCount < usedBBList.size) {
                if (usedBBList.size > biggestPadded) {
                    biggestPadded = usedBBList.size
                }

                if (pr.ON) pr.p(
                    "DataPool",
                    pr.dataPool,
                    "nNumActive = ${usedBBList.size}, free = ${freepBBList.size} total bound: $bindCount | max: $biggestPadded    $message",
                    2
                )

            } else {
                if (pr.ON) pr.p(
                    "DataPool",
                    pr.dataPool,
                    "nNumActive = ${usedBBList.size}, free = ${freepBBList.size} total bound: $bindCount:    $message"
                )
            }
            lastPaddedCount = usedBBList.size
        }
    }
}