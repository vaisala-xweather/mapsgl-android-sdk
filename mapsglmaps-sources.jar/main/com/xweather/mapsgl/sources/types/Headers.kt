package com.xweather.mapsgl.sources.types

/**
//  ImageTileSource.kt
 *
 *  @author by Jason Suto on 01/28/24.
 *  Adapted from IOS version
 *  A wrapper for a `Map<String, String>` where all keys are case-insensitive. */


class Headers : Collection<Map.Entry<String, String>> {
    var _elements: MutableMap<String, String> = mutableMapOf()

    private fun normalizeKey(key: String): String {
        return key.lowercase()
    }

    constructor()


    constructor(elements: Map<String, String>) {
        _elements = elements.mapKeys { (key, _) -> normalizeKey(key) }.toMutableMap()
    }




    operator fun get(key: String): String? {
        return _elements[normalizeKey(key)]
    }

    operator fun set(key: String, value: String?) {
        //TODO: This was commented out to get this class to compile
       // _elements[normalizeKey(key)] = value
    }

    // Collection conformance
    override val size: Int
        get() = _elements.size

    override fun contains(element: Map.Entry<String, String>): Boolean {
        return _elements.entries.any { it.key.equals(normalizeKey(element.key), ignoreCase = true) && it.value == element.value }
    }

    override fun containsAll(elements: Collection<Map.Entry<String, String>>): Boolean {
        return elements.all { contains(it) }
    }

    override fun isEmpty(): Boolean {
        return _elements.isEmpty()
    }

    override fun iterator(): Iterator<Map.Entry<String, String>> {
        return _elements.iterator()
    }



}
/*
fun Headers(response: HttpURLConnection) {
    val headerFields = response.headerFields
    val elements = headerFields.entries.associate { (key, valueList) ->
        key to (valueList?.joinToString(separator = ",") ?: "")
    }
    _elements = elements.mapKeys { (key, _) -> key.lowercase() }.toMutableMap()
}
*/
