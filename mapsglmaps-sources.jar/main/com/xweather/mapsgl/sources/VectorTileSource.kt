package com.xweather.mapsgl.sources

import VariableObserver
import com.mapbox.geojson.Feature
import com.mapbox.geojson.MultiPolygon
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.error.AuthenticationError
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.mapbox.MapboxVectorFeature
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import com.xweather.mapsgl.sources.utils.FeatureCluster
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.Headers
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.utils.formatDateArrayToString
import com.xweather.mapsgl.utils.replaceVars
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import no.ecc.vectortile.VectorTileDecoder
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.logging.Logger
import kotlin.math.max
import kotlin.math.min


class VectorData(
    val validTime: Date,
    val features: MutableList<Feature>
) : TileData {
    override fun init(byteArrayOf: ByteArray) {
        TODO("Not yet implemented")
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is VectorData) return false
        return this.hashCode() == other.hashCode()
    }

    override fun hashCode(): Int {
        // You can customize this to suit your hash requirements.
        // For now, just combine validTime and features size as an example:
        return 31 * validTime.hashCode() + features.hashCode()
    }
}

// TODO: move this into a source transformer
data class XweatherVectorLayerMetadata(
    var layers: List<Layer>,
    var validTimes: List<Date>
) {
    data class Layer(
        val name: String,
        val minZoom: Int,
        val maxZoom: Int,
        val fields: List<String>?
    )
}

class VectorTileSource(override val id: String, open var authenticator: XweatherAuthenticator? = null) :
    TileSource<VectorData>() {

    private val TAG = "VectorTileSource"

    //override var tileManager: /*TileRequestManager<VectorData> = TileRequestManager(this as TileSource<TileData>)
    override var timeRange: ClosedRange<Date>? = null
    var dlCount = 0
    var validTimes: List<Date>? = null
    var validTime: Date = Date()
    val consumers: MutableList<DataSourceConsumer> = mutableListOf()
    private val consumedLayers: MutableMap<String, Int> = mutableMapOf()

    override var tileCache: TileCache<DataType> = TileCache()

    // TODO("Temporary vectorTileCache until base TileSource can be cleaned up")
    private var vectorTileCache: TileCache<VectorData> = TileCache()
    private val dateFormatter: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault())
    val metadataObserver = VariableObserver()
    private var hadLoadedMetadata = false
    private var metadataLoadingTask: Deferred<Any>? = null

    private var invalidateFunction: ((Int, Int, Int) -> Unit)? = null
    private var decoder: VectorTileDecoder = VectorTileDecoder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var isAdminSource = false

    init {
        metadata = SourceMetadata(
            ImageTileSource.MetadataSchema(), URL(
                mapsGLServer
            )
        )

        tileManager = TileRequestManager(this as TileSource<TileData>)
    }

    override fun getMetadataURL(): URL? {
        val url = metadataURL ?: return null
        val variables = emptyMap<String, Any>().toMutableMap()
        timeRange?.let {
            variables.set("startDate", it.start)
            variables.set("endDate", it.endInclusive)
        }
        val urlString = url.replaceVars(variables, true)

        return URL(urlString)
    }

    override suspend fun fetchMetadata(startDate: Date?, endDate: Date?): Result<Unit> {
        val reload = false
        if (hadLoadedMetadata && !reload) return Result.success(Unit)

        authenticator?.authenticate()

        val url =
            getMetadataURL() ?: return Result.failure(IllegalStateException("Metadata URL could not be generated."))

        if (metadataLoadingTask != null) {
            try {
                metadataLoadingTask!!.join()
            } catch (e: Exception) {
                println("Metadata loading task failed: ${e.localizedMessage}")
                return Result.failure(IllegalStateException(e.localizedMessage))
            }
            // return
        }

        metadataLoadingTask = CoroutineScope(Dispatchers.IO).async {
            val request = URLRequest(url.toString())

            authenticator?.credentials?.let { credentials ->
                request.setAuthorization("Bearer ${credentials.accessToken}")
            }

            try {
                val response = request.execute()
                when (response.data) {
                    is JSONObject -> {
                        val json = response.data
                        if (json.keys().hasNext()) {
                            val dataKey = json.keys().next()
                            json.optJSONObject(dataKey)?.let {
                                val layers = emptyList<XweatherVectorLayerMetadata.Layer>().toMutableList()
                                val validTimes = emptyList<Date>().toMutableList()

                                it.optJSONArray("layers")?.let {
                                    for (i in 0 until it.length()) {
                                        val item = it.getJSONObject(i)
                                        val name = item.getString("name")

                                        val minZoom = if (item.has("minZoom")) {
                                            item.getInt("minZoom")
                                        } else {
                                            0
                                        }

                                        val maxZoom = if (item.has("maxZoom")) {
                                            item.getInt("maxZoom")
                                        } else {
                                            21
                                        }

                                        val fields = if (item.has("fields")) {
                                            val fieldsList = mutableListOf<String>()
                                            val fieldsArray = item.optJSONArray("fields")
                                            if (fieldsArray != null) {
                                                for (j in 0 until fieldsArray.length()) {
                                                    fieldsList.add(fieldsArray.optString(j))
                                                }
                                            }
                                            fieldsList
                                        } else {
                                            emptyList()
                                        }

                                        val layer = XweatherVectorLayerMetadata.Layer(
                                            name,
                                            minZoom,
                                            maxZoom,
                                            fields
                                        )
                                        layers.add(layer)
                                    }
                                }
                                // Parse validTimes array into List<Date>
                                it.optJSONArray("validTimes")?.let { validTimesArray ->
                                    val dateFormat =
                                        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
                                    for (i in 0 until validTimesArray.length()) {
                                        val dateStr = validTimesArray.optString(i)
                                        try {
                                            val date = dateFormat.parse(dateStr)
                                            if (date != null) validTimes.add(date)
                                        } catch (e: Exception) {
                                            // Optionally log or handle parse error
                                        }
                                    }
                                }
                                isAdminSource = true
                                val metadata = XweatherVectorLayerMetadata(layers, validTimes)
                                minZoom = metadata.layers.first().minZoom.toFloat()
                                maxZoom = metadata.layers.first().maxZoom.toFloat()
                            }
                        }
                        hadLoadedMetadata = true
                    }
                }
            } catch (e: AuthenticationError) {
                if (e.statusCode == 401) {
                    Logger.getGlobal().severe("Authentication error")
                    throw AuthenticationError(401, "")
                } else {
                    Logger.getGlobal().severe("Unexpected auth error: $e")
                    throw e
                }
            } catch (e: Exception) {
                Logger.getGlobal().severe("Metadata load failed: $e")
                throw e
            } finally {
                metadataLoadingTask = null
            }
        }

        metadataLoadingTask!!.await()
        return Result.success(Unit)
    }

    override fun getTileData(coord: TileCoord): Any? {
        val tile = this.vectorTileCache.tiles[coord.hash()]
        return tile?.data;
    }

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?
    ): Any {
        return 0
    }

    suspend fun requestTile(x: Int, y: Int, z: Int): VectorData? {
        val validTimeStr2 = formatDateArrayToString(listOf(validTime))
        val coord = TileCoord(x, y, z, 0, validTimeStr2)

        var reload = false
        val existing = getTileData(coord)
        val existingTile = tileCache.get(coord)

        if (existing != null && existing is VectorData && existingTile?.state !== TileState.Expired) {
            if (false && existing.validTime != validTime) {
//                options.reload = true
                reload = true
            } else {
                // Tile data already exists in cache, just return it
                return existing
            }
        }

        val url = makeTileURL(coord, mutableMapOf("time" to validTime))
        val urlRequest = URLRequest(url.toString())
        authenticator?.credentials?.let { credentials ->
            urlRequest.setAuthorization("Bearer ${credentials.accessToken}")
        }

        if (vectorTileCache.pendingCount == 0) {
            trigger(DataSourceEvents.LoadStart(sourceID = id))
            _shouldTriggerLoadCompleteEvent = true
        }

        val validTimeStr = formatDateArrayToString(listOf(validTime))
        coord.time = validTimeStr
        val tile = vectorTileCache[coord] ?: Tile<VectorData>(coord).also { newTile ->
            newTile.time = validTimeStr
            newTile.coordHash = coord.hash()
            vectorTileCache.updateTile(newTile, coord)
        }

        vectorTileCache.setPending(true, tile)
        tile.state = TileState.Loading
        //trigger(DataSourceEvents.TileLoadStart(id, null))

        val tileResponse = try {
            tileManager.loadTile(coord, urlRequest /*, options*/)
        } catch (e: Exception) {
            Logger.getGlobal().warning("Failed to load tile $coord: ${e.message}")
            return null
        }

        tile.state = TileState.Ready
        val tileData = tileResponse?.data as ByteArray?

        tileData?.let {
            // Needs to be concurrent
            val deferred = scope.async(Dispatchers.Default) {
                parseVectorTile(tile, tileData, validTime, headers = tileResponse?.headers)
            }
            val result = deferred.await()
            tile.data = result
            tileCache.tiles[coord.hash()] = tile as Tile<DataType>
            //trigger(DataSourceEvents.LoadComplete(id))
            return result

        }
        return null
    }

    fun abortTile(x: Int, y: Int, z: Int) {
        val coord = TileCoord(x, y, z)
//        abortTile(coord)
    }

    fun invalidate() {
        scope.launch {
            try {
                // Snapshot keys to avoid concurrent modification during iteration
                val keys = tileCache.keys.toList()
                for (key in keys) {
                    val coord = TileCoord.fromHash(key) ?: continue
                    val tile = tileCache[coord] ?: continue
                    tile.state = TileState.Expired
                    tileCache.setStale(true, tile)
                    invalidateFunction?.invoke(coord.x, coord.y, coord.z)
                }
            } catch (t: Throwable) {
                android.util.Log.e("VectorTileSource", "invalidate() failed", t)
            }
        }
    }

    fun setInvalidateFunction(invalidateFunction: ((Int, Int, Int) -> Unit)?) {
        this.invalidateFunction = invalidateFunction
    }

    override val kind: DataSourceKind
        get() = DataSourceKind.VECTOR

    override fun addConsumer(consumer: DataSourceConsumer) {
        if (!consumers.contains(consumer)) {
            consumers.add(consumer)
        }

        consumer.sourceLayerId?.let { layerName ->
            val exists = consumedLayers.containsKey(layerName)
            consumedLayers[layerName] = consumedLayers.getOrDefault(layerName, 0) + 1

            // If layerName hasn't been added yet, invalidate so new layer data is parsed next time tiles are requested
            if (!exists) {
                invalidate()
            }
        }
    }

    override fun removeConsumer(layerId: String) {
        val consumer = consumers.firstOrNull { it.layerId == layerId }
        val layerName = consumer?.sourceLayerId
        if (layerName != null) {
            val count = consumedLayers[layerName]
            if (count != null) {
                val newCount = count - 1
                if (newCount <= 0) {
                    consumedLayers.remove(layerName)
                    // We've completely eliminated the need for this layer, so invalidate the source to clear cached data
                    invalidate()
                } else {
                    consumedLayers[layerName] = newCount
                }
            }
        }
        consumers.remove(consumer)
    }

    private suspend fun parseVectorTile(
        tile: Tile<VectorData>,
        data: ByteArray,
        validTime: Date,
        headers: Headers?
    ): VectorData = withContext(Dispatchers.Default) {
        val coord = tile.coord
        if (pr.ON) pr.p(TAG, pr.invVec, "parseVectorTile():  ${coord.hash()}")
        decoder.isAutoScale = false

        val allFeatures = decoder.decode(data)
        val tileLayerNames = allFeatures.layerNames

        if (pr.ON) pr.p(TAG, pr.invVec, "parseVectorTile() consumers count: ${consumers.count()}")

        for (consumer in consumers) {
            if (pr.ON) pr.p(
                TAG,
                pr.invVec,
                "parseVectorTile() consumer: lID ${consumer.layerId}   sLID: ${consumer.sourceLayerId}"
            )
        }

        // Build the list of needed source-layer names based on active consumers
        val neededLayerNames = mutableListOf<String>()
        consumers.forEach { consumer ->
            val sourceLayerId = consumer.sourceLayerId ?: return@forEach
            val tileLayerId = sourceLayerId.removeSuffix("::inverted")
            if (tileLayerNames.contains(tileLayerId)) {
                neededLayerNames += sourceLayerId
            }
        }

        // If no layers provided by any consumers, then default to the first to handle cases where
        // MVT only has a single layer and no `sourceLayer` is necessary
        if (neededLayerNames.isEmpty() && tileLayerNames.isNotEmpty()) {
            neededLayerNames += tileLayerNames.first()
        }

        val features = mutableListOf<Feature>()

        for (layerName in neededLayerNames) {
            val invertFeatures = layerName.endsWith("::inverted")
            val tileLayerName = layerName.removeSuffix("::inverted")

            // Fetch features from the tile layer, convert to Mapbox Features, and tag the layer name
            var layerFeatures: List<Feature> =
                decoder.decode(data, tileLayerName)?.mapNotNull { feature ->
                    // Sometimes properties are stored as dot-notated strings in a flattened dictionary, but styling requires nested structure
                    // So convert the properties to the original nested dictionary structure
                    val properties = nestedDictionary(feature.attributes).toMutableMap()
                    properties["now"] = System.currentTimeMillis() / 1000.0
                    properties["layer"] = layerName
                    MapboxVectorFeature.from(coord, feature, properties)
                } ?: listOf()

            // Optional inversion of polygonal features into a single “inverse” polygon covering the tile
            if (invertFeatures) {
                inverseTileFeatures(layerFeatures, coord)?.let { inverted ->
                    inverted.addStringProperty("layer", layerName)
                    layerFeatures = mutableListOf(inverted)
                }
            }

            features += layerFeatures
        }

        // Optional clustering / de-duplication for dense point-only tiles
        val isAllPoints = features.all { it.geometry() is Point }

        if (isAllPoints && features.size > 3000) {
            val minDistanceKm = 1.0
            val maxDistanceKm = 10.0
            val t = ((10 - coord.z).coerceIn(0, 10)) / 10.0
            val maxDistanceKilometers = minDistanceKm + t * (maxDistanceKm - minDistanceKm)

            val pointClusterer = FeatureCluster()
            val clustered = pointClusterer.deduplicateClosePoints(features, maxDistanceKilometers)
            features.clear()
            features += clustered
        }

        VectorData(validTime, features)
    }

    private fun inverseTileFeatures(features: List<Feature>, tileCoord: TileCoord): Feature {
        var currentBounds = getLatLonBoundsOfTile(tileCoord)

        // Expand bounds to fully contain buffered features
        val allCoords: List<Point> = features
            .mapNotNull { feature ->
                when (val geom = feature.geometry()) {
                    is Polygon -> geom.coordinates().flatten()                  // List<List<Point>> -> List<Point>
                    is MultiPolygon -> geom.coordinates().flatten()
                        .flatten()   // List<List<List<Point>>> -> List<Point>
                    else -> null
                }
            }
            .flatten()

        if (allCoords.isNotEmpty()) {
            val minLat = allCoords.minOfOrNull { it.latitude() }?.let {
                min(currentBounds.southExtent, it)
            } ?: currentBounds.southExtent
            val maxLat = allCoords.maxOfOrNull { it.latitude() }?.let {
                max(currentBounds.northExtent, it)
            } ?: currentBounds.northExtent
            val minLon = allCoords.minOfOrNull { it.longitude() }?.let {
                min(currentBounds.westExtent, it)
            } ?: currentBounds.westExtent
            val maxLon = allCoords.maxOfOrNull { it.longitude() }?.let {
                max(currentBounds.eastExtent, it)
            } ?: currentBounds.eastExtent

            currentBounds = LatLonBounds(
                minLon,
                minLat,
                maxLon,
                maxLat
            )

            if (pr.ON) pr.p(
                TAG,
                pr.invVec2,
                "inverseTileFeatures() db bounds:lon: ${(maxLon - minLon).toInt()} ($minLon / $maxLon)  lat: ${(maxLat - minLat).toInt()}  ($minLat / $maxLat)  ",
            )

            if (pr.ON) for (coord in allCoords) {
                if (pr.ON) pr.p(TAG, pr.invVec2, "   coord:$coord  ")
            }

        }

        //outer ring is CCW
        val outerRing: List<Point> = listOf(
            Point.fromLngLat(currentBounds.westExtent, currentBounds.southExtent),
            Point.fromLngLat(currentBounds.eastExtent, currentBounds.southExtent),
            Point.fromLngLat(currentBounds.eastExtent, currentBounds.northExtent),
            Point.fromLngLat(currentBounds.westExtent, currentBounds.northExtent),
            Point.fromLngLat(currentBounds.westExtent, currentBounds.southExtent)
        ).reversedIfClockwise()

        val holeRings: MutableList<List<Point>> = mutableListOf()

        for (feature in features) {
            when (val geom = feature.geometry()) {
                is Polygon -> {
                    val rings: List<List<Point>> = geom.coordinates()
                    rings.forEachIndexed { index, ring ->
                        val corrected = if (index == 0) {
                            ring.reversedIfClockwise()           // outer -> hole, ensure CCW->CW
                        } else {
                            ring.reversedIfCounterClockwise()     // inner -> outer-of-hole, ensure CW->CCW
                        }
                        holeRings.add(corrected)
                    }
                }

                is MultiPolygon -> {
                    val polys: List<List<List<Point>>> = geom.coordinates()
                    polys.forEach { poly ->
                        poly.forEachIndexed { index, ring ->
                            val corrected = if (index == 0) {
                                ring.reversedIfClockwise()
                            } else {
                                ring.reversedIfCounterClockwise()
                            }
                            holeRings.add(corrected)
                        }
                    }
                }

                else -> {
                    // ignore non-polygonal geometry
                }
            }
        }

        val feature: Feature = if (holeRings.isEmpty()) {
            Feature.fromGeometry(Polygon.fromLngLats(listOf(outerRing)))
        } else {
            val allRings = ArrayList<List<Point>>(1 + holeRings.size)
            allRings.add(outerRing)
            allRings.addAll(holeRings)
            Feature.fromGeometry(Polygon.fromLngLats(allRings))
        }

        feature.addNumberProperty("now", System.currentTimeMillis() / 1000.0)
        feature.addStringProperty("featureType", "Polygon")
        feature.addStringProperty("geometry-type", "Polygon")

        return feature
    }
}

fun nestedDictionary(flat: Map<String, Any>): Map<String, Any> {
    fun insert(target: Any?, keys: List<String>, value: Any): Any {
        if (keys.isEmpty()) return target ?: value

        val key = keys.first()
        val remainingKeys = keys.drop(1)

        return if (key.toIntOrNull() != null) {
            val index = key.toInt()
            val array = (target as? List<Any?>)?.toMutableList() ?: mutableListOf()

            while (array.size <= index) {
                array.add(null)
            }

            array[index] = insert(array[index], remainingKeys, value)
            array
        } else {
            val dict = (target as? Map<*, *>)?.toMutableMap() ?: mutableMapOf()
            dict[key] = insert(dict[key], remainingKeys, value)
            dict
        }
    }

    var result: Any = mutableMapOf<String, Any>()

    for ((flatKey, value) in flat) {
        val keys = flatKey.split(".")
        result = insert(result, keys, value)
    }

    @Suppress("UNCHECKED_CAST")
    return result as? Map<String, Any> ?: emptyMap()
}
