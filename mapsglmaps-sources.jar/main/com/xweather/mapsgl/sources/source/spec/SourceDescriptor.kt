package com.xweather.mapsgl.sources.source.spec

import com.xweather.mapsgl.weather.XweatherAuthenticator
import com.xweather.mapsgl.coordinates.LatLonBounds
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.weather.EncodedDataset

// SourceDescriptor.kt

interface SourceDescriptor {
    val id: String
    val kind: DataSourceKind
}

val SourceDescriptor.type: DataSourceKind
    @Deprecated("Use `kind` instead.")
    get() = kind

data class ImageSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.RASTER
}

data class EncodedSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
    var datasets: List<EncodedDataset>? = null
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.ENCODED
}

data class XweatherEncodedSourceDescriptor(
    override val id: String,
    var url: String?,
    var metadataUrl: String?,
    var minZoom: Float?,
    var maxZoom: Float?,
    var bounds: LatLonBounds?,
    var tileSize: TileSize?,
    var attribution: String?,
    var authenticator: XweatherAuthenticator?,
    var datasets: List<EncodedDataset>?
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.AERIS_ENCODED
}

data class VectorSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.VECTOR
}

data class GeoJSONSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.GEOJSON
}