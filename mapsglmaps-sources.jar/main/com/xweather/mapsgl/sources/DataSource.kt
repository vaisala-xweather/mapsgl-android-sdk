package com.xweather.mapsgl.sources

/**
 *  DataSource.kt
 *  Contains RequestTileSuccess Class
 *
 *  Created by Jason Suto on 12/12/23.
 **/


import com.xweather.mapsgl.events.EventSource
import com.xweather.mapsgl.sources.types.Headers
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import java.util.Date

interface DataSource : EventSource {
    /** The unique identifier for the data source. **/
    val id: String
    /** The map layers that are currently using this data source. **/
    //val consumingLayers: List<DataSourceConsumer>
    /** The type of data source and data it manages. **/
    /** `type` in MapsGL JS **/
    val kind: DataSourceKind

    var timeRange: ClosedRange<Date>?

    /** Indicates whether the data source is ready to be used by consuming layers, which may be `false` if data has not been loaded from a remote source yet or the data has not been fully prepared for rendering. **/
    var isReady: Boolean

    /** Adds a map layer as a consumer of the data source. **/
    fun addConsumer(consumer: DataSourceConsumer)

    /** Removes a map layer as a consumer of the data source. **/
    fun removeConsumer(layerId: String)

}

val DataSource.type: DataSourceKind
    get() = this.kind

open class RequestTileSuccess<DataType : TileData> {
    data class Data<DataType : TileData>(val data: DataType) : RequestTileSuccess<DataType>()

    class AlreadyExists : RequestTileSuccess<TileData>() {
    }

    companion object {
        val alreadyExists: Unit = Unit
    }
}

/** An interface for a structure responsible for parsing and decoding tile data into a specific format required for rendering. **/
interface TileDataParser {
    // TODO - Is this needed? Had to do this to make parseTile() work for subclasses due to generic constraints
    /** Parses and decodes the tile data received from a URL request into a specific format. **/
    suspend fun <T : TileData, U> parse(
        tile: Tile<T>,
        data: ByteArray,
        headers: Headers?,
        metadata: SourceMetadata<SourceMetadataSchema>
    ): T
}