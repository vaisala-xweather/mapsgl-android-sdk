package com.xweather.mapsgl.sources.utils

sealed class Accumulator {
    data class StringValue(val value: String) : Accumulator()
    data class NumberValue(val sum: Double, val count: Int, val min: Double, val max: Double) : Accumulator()
    data class DictionaryValue(val map: MutableMap<String, Accumulator>) : Accumulator()
    data class ArrayValue(val list: MutableList<Accumulator>) : Accumulator()

    companion object {
        fun accumulate(value: Map<String, Any?>): Accumulator? {
            val result = mutableMapOf<String, Accumulator>()
            for ((key, v) in value) {
                val acc = v?.let { accumulateValue(it) }
                if (acc != null) {
                    result[key] = acc
                }
            }
            return DictionaryValue(result)
        }

        fun accumulateValue(value: Any): Accumulator? {
            return when (value) {
                is String -> StringValue(value)
                is Number -> {
                    val d = value.toDouble()
                    NumberValue(sum = d, count = 1, min = d, max = d)
                }
                is Map<*, *> -> {
                    val result = mutableMapOf<String, Accumulator>()
                    for ((k, v) in value) {
                        if (k is String && v != null) {
                            val acc = accumulateValue(v)
                            if (acc != null) result[k] = acc
                        }
                    }
                    DictionaryValue(result)
                }

                is List<*> -> {
                    val list = value.mapNotNull { it?.let { accumulateValue(it) } }.toMutableList()
                    ArrayValue(list)
                }

                else -> null
            }
        }

        fun merge(lhs: Accumulator, rhs: Accumulator): Accumulator {
            return when {
                lhs is NumberValue && rhs is NumberValue ->
                    NumberValue(
                        sum = lhs.sum + rhs.sum,
                        count = lhs.count + rhs.count,
                        min = minOf(lhs.min, rhs.min),
                        max = maxOf(lhs.max, rhs.max)
                    )

                lhs is DictionaryValue && rhs is DictionaryValue -> {
                    val merged = lhs.map.toMutableMap()
                    for ((key, value) in rhs.map) {
                        merged[key] = merged[key]?.let { merge(it, value) } ?: value
                    }
                    DictionaryValue(merged)
                }

                lhs is ArrayValue && rhs is ArrayValue -> {
                    val minSize = minOf(lhs.list.size, rhs.list.size)
                    val mergedList = mutableListOf<Accumulator>()
                    for (i in 0 until minSize) {
                        mergedList.add(merge(lhs.list[i], rhs.list[i]))
                    }
                    ArrayValue(mergedList)
                }

                else -> lhs
            }
        }

        fun finalize(accumulator: Accumulator): Any {
            return when (accumulator) {
                is StringValue -> accumulator.value
                is NumberValue -> accumulator.sum / accumulator.count
                is Accumulator.DictionaryValue -> {
                    val result = mutableMapOf<String, Any>()
                    for ((key, value) in accumulator.map) {
                        when (value) {
                            is NumberValue -> {
                                val average = value.sum / value.count
                                result[key] = average // original property
                                result["${key}_average"] = average
                                result["${key}_min"] = value.min
                                result["${key}_max"] = value.max
                            }
                            else -> result[key] = finalize(value)
                        }
                    }
                    result
                }
                is ArrayValue -> accumulator.list.map { finalize(it) }
            }
        }
    }
}