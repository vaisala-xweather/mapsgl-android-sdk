package com.xweather.mapsgl.style

import LayerEvents
import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.layers.spec.LayerEventEmitter
import com.xweather.mapsgl.layers.spec.StyleJSON
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.ColorSampling
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.TextJustification
import com.xweather.mapsgl.types.TextTransform

// A base interface for paint styles used in individual render passes.
interface Paint

enum class LineJoin(val value: String) {
    MITER("miter"),
    ROUND("round"),
    BEVEL("bevel")
}

enum class LineCap(val value: String) {
    BUTT("butt"),
    ROUND("round"),
    SQUARE("square")
}

// Style options for raster tiles rendered as static images.
//
// This type defines how raster imagery (e.g., PNG or JPG tiles) is displayed.
class RasterPaint : Paint

// Style options for visualizing sampled values from encoded data sources.
//
// Defines interpolation, color mapping, value ranges, and animation blending for encoded datasets.
class SamplePaint(
    override var expression: SampleExpression = SampleExpression.NUMBER,
    override var channel: List<ColorBand> = listOf(ColorBand.red),
    override var quality: DataQuality = DataQuality.exact,
    override var interpolation: InterpolationMode = InterpolationMode.BICUBIC,
    override var smoothing: Float = 0.0f,
    override var offset: Float = 0.0f,
    override var drawRange: ClosedRange<Double>? = null,
    colorScale: ColorScaleOptions = ColorScaleOptions(),
    var multiband: Boolean = false,
    var meld: Boolean = true,
    var eventEmitter: LayerEventEmitter? = null
) : Paint, ColorSampling {

    override var colorScale: ColorScaleOptions = colorScale
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE",
                LayerEvents.SamplePaintChangeEvent(
                    property = "sample.colorscale",
                    value = value
                )
            )
        }
}

class ContourPaint(
    //override var expression: SampleExpression = SampleExpression.NUMBER,
    //override var channel: List<ColorBand> = listOf(ColorBand.red),
    //override var quality: DataQuality = DataQuality.exact,
    //override var interpolation: InterpolationMode = InterpolationMode.BICUBIC,
    //override var smoothing: Float = 0.0f,
    //override var offset: Float = 0.0f,
    //override var drawRange: ClosedRange<Double>? = null,
    colorScale: ColorScaleOptions = ColorScaleOptions(),
    var multiband: Boolean = false,
    var meld: Boolean = true,
    var eventEmitter: LayerEventEmitter? = null,
    var interval: StyleValue<Double> = StyleValue.Constant(2.0),
    var majorInterval: StyleValue<Double> = StyleValue.Constant(10.0),

    var width: StyleValue<Double> = StyleValue.Constant(1.0),
    var majorWidth: StyleValue<Double> = StyleValue.Constant(3.0),
    var scale: StyleValue<Double> = StyleValue.Constant(1.0),
) : Paint {


    /** Determines the value interval for which to draw major, or thicker, contour lines for. If this value is `0`, then
     * major contour lines will not be rendered. This value must be in the same units as the data source. **/


}

// Style options for visualizing vector field data as animated particles.
//
// Supports dense or fixed-count particle rendering with tunable trail, speed, and emission effects.

class ParticlePaint(
    // The visual type of the particle, such as `.circle` or `.arrow`.
    var kind: ParticleKind = ParticleKind.CIRCLE,
    var density: ParticleDensity = ParticleDensity.NORMAL,
    var count: Int = 0,
    /** The size of each individual particle. For wind particles, you only need to set one integer. For
     * wave and swell particles, you can set the width and height individually to create rectangular particles. **/
    var size: Size = Size(2),
    var speed: Double = 1.0,
    var trails: Boolean = true,
    var trailsFade: Double = 0.97,
    var dropRate: Double = 0.01,
    var dropRateBump: Double = 0.01
) : Paint


class FillPaint(
    // 1. Remove 'override val' from here to avoid property collision.
    // This is now just an argument used for initialization.
    color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    var pattern: StyleValue<String>? = null,
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    var eventEmitter: LayerEventEmitter? = null
) : Paint {

    // 2. Define the property manually so we can use a custom setter
    var color: StyleValue<Color> = color
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE",
                LayerEvents.SamplePaintChangeEvent(
                    property = "fill.color",
                    value = value
                )
            )
        }

    /**
     * Custom copy function to replicate data class behavior.
     * Use this to create a new instance with specific property changes.
     */
    fun copy(
        color: StyleValue<Color> = this.color,
        pattern: StyleValue<String>? = this.pattern,
        opacity: StyleValue<Double> = this.opacity,
        eventEmitter: LayerEventEmitter? = this.eventEmitter
    ): FillPaint {
        return FillPaint(
            color = color,
            pattern = pattern,
            opacity = opacity,
            eventEmitter = eventEmitter
        )
    }
}

data class StrokePaint(
    var color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    var thickness: StyleValue<Double> = StyleValue.Constant(2.0),
    var lineJoin: StyleValue<LineJoin> = StyleValue.Constant(LineJoin.ROUND),
    var lineCap: StyleValue<LineCap> = StyleValue.Constant(LineCap.ROUND)
) : Paint

class CirclePaint(
    // Remove var/val from constructor argument to allow manual property definition
    color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    var radius: StyleValue<Double> = StyleValue.Constant(6.0),
    var sortKey: StyleValue<Double>? = null,
    var eventEmitter: LayerEventEmitter? = null
) : Paint {

    // Manual property with setter to trigger the sync event
    var color: StyleValue<Color> = color
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE",
                LayerEvents.SamplePaintChangeEvent(
                    property = "circle.color",
                    value = value
                )
            )
        }

    /**
     * Custom copy function to replicate data class behavior.
     */
    fun copy(
        color: StyleValue<Color> = this.color,
        radius: StyleValue<Double> = this.radius,
        sortKey: StyleValue<Double>? = this.sortKey,
        eventEmitter: LayerEventEmitter? = this.eventEmitter
    ): CirclePaint {
        return CirclePaint(
            color = color,
            radius = radius,
            sortKey = sortKey,
            eventEmitter = eventEmitter
        )

    }
}

data class IconPaint(
    var allowOverlap: StyleValue<Boolean> = StyleValue.Constant(false),
    var image: StyleValue<String>? = null,
    var size: StyleValue<Double>? = null,
    var anchor: StyleValue<Anchor> = StyleValue.Constant(Anchor.CENTER),
    var offset: StyleValue<AnchorOffset> = StyleValue.Constant(AnchorOffset()),
    var padding: StyleValue<Double> = StyleValue.Constant(0.0),
    var rotation: StyleValue<Double> = StyleValue.Constant(0.0)
) : Paint

data class TextPaint(
    var allowOverlap: StyleValue<Boolean> = StyleValue.Constant(false),
    var value: StyleValue<String>,
    var size: StyleValue<Double>? = null,
    var font: StyleValue<List<String>>? = null,
    var weight: StyleValue<String>? = null,
    var color: StyleValue<Color> = StyleValue.Constant(Color.Black),
    var outlineColor: StyleValue<Color>? = null,
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    var align: StyleValue<TextJustification> = StyleValue.Constant(TextJustification.CENTER),
    var transform: StyleValue<TextTransform> = StyleValue.Constant(TextTransform.NONE),
    var anchor: StyleValue<Anchor> = StyleValue.Constant(Anchor.CENTER),
    var offset: StyleValue<AnchorOffset> = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
    var padding: StyleValue<Double> = StyleValue.Constant(0.0),
    var rotation: StyleValue<Double> = StyleValue.Constant(0.0),
    var letterSpacing: StyleValue<Double>? = null,
    var lineHeight: StyleValue<Double>? = null,
    var maxWidth: StyleValue<Double>? = null
) : Paint

data class HeatmapPaint(
    var color: StyleValue<Color> = StyleValue.Expression(
        Expression.interpolate(
            listOf("heatmap-density"),
            listOf(
                0.0 to "rgba(0, 0, 0, 0)",
                0.2 to "rgba(0, 0, 255, 0.2)",
                0.45 to "rgba(0, 255, 0, 0.5)",
                0.85 to "rgba(255, 255, 0, 1)",
                1.0 to "rgba(255, 0, 0, 1)"
            )
        )
    ),
    var intensity: StyleValue<Double> = StyleValue.Constant(2.0),
    var radius: StyleValue<Double> = StyleValue.Constant(20.0),
    var weight: StyleValue<Double> = StyleValue.Constant(2.0)
) : Paint

interface LayerPaint {
    var opacity: Float
}

interface VectorLayerPaint : LayerPaint {
    fun asStyleJSON(id: String, source: String, sourceLayer: String? = null): StyleJSON
}

data class RasterLayerPaint(
    override var opacity: Float = 1.0f,
    var raster: RasterPaint
) : LayerPaint

data class SampleLayerPaint(
    override var opacity: Float = 1.0f,
    var sample: SamplePaint
) : LayerPaint

data class ContourLayerPaint(
    override var opacity: Float = 1.0f,
    var sample: SamplePaint,
    var contour: ContourPaint
) : LayerPaint {

    var interval: StyleValue<Double> = StyleValue.Constant(1.0)


}

data class ParticleLayerPaint(
    override var opacity: Float = 1.0f,
    var sample: SamplePaint,
    var particle: ParticlePaint
) : LayerPaint

data class FillLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint,
    var stroke: StrokePaint = StrokePaint()
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.FILL, source, sourceLayer).apply {
            fillColor = fill.color
            fillOpacity = fill.opacity
            fillOutlineColor = stroke.color
        }
    }
}

data class LineLayerPaint(
    override var opacity: Float = 1.0f,
    var stroke: StrokePaint
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.LINE, source, sourceLayer).apply {
            lineColor = stroke.color
            lineOpacity = stroke.opacity
            lineWidth = stroke.thickness
        }
    }
}

data class CircleLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint = FillPaint(),
    var stroke: StrokePaint = StrokePaint(),
    var circle: CirclePaint
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.CIRCLE, source, sourceLayer).apply {
            circleColor = fill.color
            circleOpacity = fill.opacity
            circleRadius = circle.radius
            circleStrokeColor = stroke.color
            circleStrokeOpacity = stroke.opacity
            circleStrokeWidth = stroke.thickness
            circleSortKey = circle.sortKey
        }
    }
}

data class SymbolLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint? = null,
    var stroke: StrokePaint? = null,
    var icon: IconPaint = IconPaint(),
    var text: List<TextPaint> = emptyList()
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.SYMBOL, source, sourceLayer).apply {
            iconAllowOverlap = icon.allowOverlap
            iconAnchor = icon.anchor
            iconColor = fill?.color
            iconHaloColor = stroke?.color
            iconHaloWidth = stroke?.thickness
            iconImage = icon.image
            iconOffset = icon.offset
            iconOpacity = fill?.opacity
            iconPadding = icon.padding
            iconRotate = icon.rotation
            iconSize = icon.size

            text.firstOrNull()?.let { baseText ->
                textField = if (text.size > 1) {
                    val baseSize = baseText.size?.resolvedValue as? Double ?: 12.0
                    val inputs = text.flatMap {
                        val size = (it.size?.resolvedValue as? Double) ?: 12.0
                        val scale = size / baseSize
                        listOf(
                            it.value to TextFormatOptions(fontScale = scale),
                            StyleValue.Constant("\n") to TextFormatOptions(fontScale = scale)
                        )
                    }
                    StyleValue.Expression(Expression.format(inputs))
                } else {
                    baseText.value
                }
                textAllowOverlap = baseText.allowOverlap
                textAnchor = baseText.anchor
                textColor = baseText.color
                textHaloColor = baseText.outlineColor
                textHaloBlur = StyleValue.Constant(0.5)
                textHaloWidth = stroke?.thickness ?: StyleValue.Constant(1.0)
                textJustify = baseText.align
                textLetterSpacing = baseText.letterSpacing
                textLineHeight = baseText.lineHeight
                textMaxWidth = baseText.maxWidth
                textOffset = baseText.offset
                textOpacity = baseText.opacity
                textPadding = baseText.padding
                textRotate = baseText.rotation
                textSize = baseText.size
                textTransform = baseText.transform
            }
        }
    }
}

data class HeatmapLayerPaint(
    override var opacity: Float = 1.0f,
    var heatmap: HeatmapPaint
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.HEATMAP, source, sourceLayer).apply {
            heatmapColor = heatmap.color
            heatmapIntensity = heatmap.intensity
            heatmapRadius = heatmap.radius
            heatmapOpacity = heatmap.weight
        }
    }
}