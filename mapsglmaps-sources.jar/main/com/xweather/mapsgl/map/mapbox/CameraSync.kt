package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.math.RotateAxis
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera

class CameraSync {
    companion object {
        var mapZoom: Double = 0.0
        lateinit var camera: Camera
        const val WORLD_SIZE = 1024000 // TILE_SIZE * 2000
        const val cameraToCenterDistance = 0f
        const val EARTH_RADIUS = 6371008.8
        const val FOV_ORTHO = 0.1 / 180 * Math.PI; // Mapbox doesn't accept 0 as FOV

        // from Mapbox https://github.com/mapbox/mapbox-gl-js/blob/0063cbd10a97218fb6a0f64c99bf18609b918f4c/src/geo/lng_lat.js#L117
        const val EARTH_CIRCUMFERENCE_EQUATOR = 40075017;

        // const WORLD_SIZE = WORLD_SIZE
        const val PROJECTION_WORLD_SIZE = WORLD_SIZE / (EARTH_RADIUS * Math.PI * 2);
        const val MERCATOR_A = EARTH_RADIUS
        const val DEG2RAD = Math.PI / 180
        const val RAD2DEG = 180 / Math.PI;

        // const EARTH_RADIUS = EARTH_RADIUS;
        const val EARTH_CIRCUMFERENCE = 2 * Math.PI * EARTH_RADIUS; // 40075000, // In meters
                var scaleMatrix: Matrix4 = Matrix4.identity()
        var translationMatrix: Matrix4 = Matrix4.identity()
        var worldMatrix: ProjectionMatrix = ProjectionMatrix()
        var rotScalePitchMatrix: Matrix4

        init {
            rotScalePitchMatrix = Matrix4.identity()
        }


        private fun lon2tile(lon: Double, zoom: Double): Double {
            return (lon + 180.0) / 360.0 * (1 shl zoom.toInt())
        }

        private fun lat2tile(lat: Double, zoom: Double): Double {
            val latRad = Math.toRadians(lat)
            return (1 - Math.log(Math.tan(latRad) + 1 / Math.cos(latRad)) / Math.PI) / 2 * (1 shl zoom.toInt())
        }

        fun calculateCameraMatrixDeg(
            pitch: Float, bearing: Float, translateZ: Matrix4
        ): Matrix4 {
            val returnMatrix = Matrix4()
            returnMatrix.multiply(translateZ, returnMatrix)
            returnMatrix.multiply(Matrix4().rotateInDegrees(RotateAxis.RotateZ, -bearing), returnMatrix)
            returnMatrix.multiply(Matrix4().rotateInDegrees(RotateAxis.RotateX, pitch), returnMatrix)
            return returnMatrix
        }

    }//end companion object

}