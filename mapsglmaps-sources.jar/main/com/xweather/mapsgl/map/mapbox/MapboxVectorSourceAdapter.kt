package com.xweather.mapsgl.map.mapbox

import com.mapbox.maps.CanonicalTileID
import com.mapbox.maps.CustomGeometrySourceOptions
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.TileOptions
import com.mapbox.maps.extension.style.sources.CustomGeometrySource
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCoord
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.logging.Logger

class MapboxVectorSourceAdapter(
    private val source: VectorTileSource,
    private val map: MapboxMap
) {
    suspend fun makeSource(): CustomGeometrySource {
        if (pr.ON) pr.p("MapboxVectorSourceAdapter", pr.adminLayers, "makeSource entered() ")
        withContext(Dispatchers.IO) {
            try {
                source.fetchMetadata(null, null)
                if (pr.ON) pr.p("MapboxVectorSourceAdapter", pr.adminLayers, "fetchTileFunction()called fetchMetaData")
            } catch (e: Exception) {
                if (pr.ON) pr.p(
                    "MapboxVectorSourceAdapter",
                    pr.adminLayers,
                    "fetchTileFunction() tileID: ${e.localizedMessage}"
                )
                println("Failed to fetch metadata for vector tile source: ${e.localizedMessage}")
            }
        }

        return CustomGeometrySource(
            source.id,
            CustomGeometrySourceOptions.Builder()
                .fetchTileFunction { tileID ->

                    if (pr.ON) pr.p("MapboxVectorSourceAdapter", pr.adminLayers, "fetchTileFunction() tileID: $tileID")
                    CoroutineScope(Dispatchers.Default).launch {
                        try {
                            Timeline.incrementPendingVectorDownloads()
                            val data = source.requestTile(
                                tileID.x,
                                tileID.y,
                                tileID.z.toInt(),
                            )
                            val tile = Tile<DataType>(coord = TileCoord(tileID.x, tileID.y, tileID.z.toInt(), 0, ""))
                            tile.data = data

                            data?.let {
                                withContext(Dispatchers.Main) {
                                    map.setStyleCustomGeometrySourceTileData(
                                        source.id,
                                        tileID,
                                        it.features
                                    )
                                }
                            }
                            source.dlCount++
                            Timeline.decrementPendingVectorDownloads()
                        } catch (e: Exception) {
                            Logger.getLogger("MapboxVectorSourceAdapter").severe(e.localizedMessage)
                        }
                    }
                }
                .cancelTileFunction { tileID ->
                    source.abortTile(tileID.x, tileID.y, tileID.z.toInt())
                }
//                .minZoom(source.minZoom.toInt().toByte())
                .minZoom(0)
                .maxZoom(source.maxZoom.toInt().toByte())
                .tileOptions(TileOptions.Builder().build())
                .build()
        )
    }

    fun invalidate(x: Int, y: Int, z: Int) {
        CoroutineScope(Dispatchers.Default).launch(Dispatchers.Main) {
            try {
                val tileID = CanonicalTileID(z.toByte(), x, y)
                map.invalidateStyleCustomGeometrySourceTile(source.id, tileID)
            } catch (e: Exception) {
                Logger.getLogger("MapboxVectorSourceAdapter").severe(e.localizedMessage)
            }
        }
    }
}