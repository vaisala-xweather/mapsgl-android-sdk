package com.xweather.mapsgl.map.mapbox

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.gson.JsonElement
import com.mapbox.bindgen.Value
import com.mapbox.common.Cancelable
import com.mapbox.geojson.Point
import com.mapbox.maps.CameraChangedCallback
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.CoordinateBounds
import com.mapbox.maps.LayerPosition
import com.mapbox.maps.MapIdleCallback
import com.mapbox.maps.MapView
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.QueriedRenderedFeature
import com.mapbox.maps.RenderFrameFinishedCallback
import com.mapbox.maps.RenderedQueryGeometry
import com.mapbox.maps.RenderedQueryOptions
import com.mapbox.maps.ScreenBox
import com.mapbox.maps.ScreenCoordinate
import com.mapbox.maps.Size
import com.mapbox.maps.extension.style.layers.getLayer
import com.mapbox.maps.extension.style.layers.properties.generated.Visibility
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.plugin.gestures.gestures
import com.mapbox.maps.toCameraOptions
import com.xweather.mapsgl.anim.AnimationEvent
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.data.LayerTileList
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.events.MapControllerEvents
import com.xweather.mapsgl.geo.Geo
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.FeatureQueryResult
import com.xweather.mapsgl.layers.QueriedFeature
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.tile.EncodedTileLayer
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.ImageRegisteringMap
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.MaskUtils
import com.xweather.mapsgl.map.MaskUtils.Companion._masks
import com.xweather.mapsgl.map.MaskUtils.Companion.getBackgroundColorRBGStringFromLayer
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.camera
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.mapZoom
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.rotScalePitchMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.scaleMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.translationMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.worldMatrix
import com.xweather.mapsgl.sources.DataSource
import com.xweather.mapsgl.sources.EncodedTileSource
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.VectorLayerPaint
import com.xweather.mapsgl.tiles.GLCoordinate2D
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.types.Coordinate
import com.xweather.mapsgl.utils.parseDateArrayFromString
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.pow

/**
 * The MapboxMapController is a MapController implementation for Mapbox maps.
 *
 * @property mapView The view that contains the map from the activity.
 * @property account Your XweatherAccount that contains your userID and userSecret.
 * @constructor Create [MapboxMapController]
 *
 */

class MapboxMapController : MapController, DefaultLifecycleObserver {
    var mapboxMap: MapboxMap? = null

    private val mapboxCancelables = mutableListOf<Cancelable>()
    internal var i = 0
    internal var i2 = 0

    /** Deprecated as of v1.1.0
     *
     * @param mapView The view that contains the map from the activity.
     * @param baseContext used by OpenGLES for drawing the layers.
     * @param account Your XweatherAccount that contains your userID and userSecret.
     * @params lifecycleOwner: Used by mapsGL to listen for buttons.
     * @deprecated
     **/
    @Deprecated(
        message = "Please use MapboxMapController(mapView: MapView, account: XweatherAccount) instead.",
        level = DeprecationLevel.WARNING
    )
    constructor(
        mapView: MapView,
        baseContext: Context,
        account: XweatherAccount,
        lifecycleOwner: LifecycleOwner,
    ) : this(mapView, account)

    /** MapboxMapController Constructor: mapview, account
     * @param mapView The view that contains the map from the activity.
     * @param account Your XweatherAccount that contains your userID and userSecret.
     * */
    constructor(
        mapView: MapView,
        account: XweatherAccount,
    ) : super(mapView, account) {

        mapView.context.registerComponentCallbacks(this)
        mapboxMap = mapView.mapboxMap
        centerLatLng = Coordinate(mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude())

        setupCamera(true)
        camera.refreshRateFactor = 60f / refreshRate
        /** dpi of 2 results in dpiMult of 1. dpi of 4 results in dpiMult of 2 **/
        camera.dpiMult = mapView.context.resources.displayMetrics.density / 2f
        handleCallbackSubscriptions()
        setupEvents()

        mapView.gestures.addOnMapClickListener(this)

        timeline.on(AnimationEvent.stop) {
            //println("DETECTED EVENT STOP FROM MapBoxMap")
            invalidateVector()
        }

        timeline.on(AnimationEvent.PAUSE) {
            //println("DETECTED EVENT STOP FROM MapboxMap")
            invalidateVector()
        }

        // Example: Tracking the pending list
        TileList.pendingList.listener = object : LayerTileList.TileListListener {
            override fun onListStarted() {
                // UI code: progressBar.visibility = View.VISIBLE
            }

            override fun onListEmpty() {
                // UI code: progressBar.visibility = View.GONE
            }

            override fun onTick() {
                // This prints every 0.5 seconds while items exist in pendingList
            }
        }
    }

    private fun invalidateVector() {
        for (layer in layers) {
            if (layer.value is VectorTileLayer) {
                if (layer.value.source !is GeoJSONSource) {
                    (layer.value.source as VectorTileSource).invalidate()
                } else {
                    // println("Detected event is  GeoJSONSource")
                }
            }
        }
    }

    companion object {
        val TAG = "MapboxMapController"
        const val PERSPECTIVECAMERA = 0
        const val ORTHOCAMERA = 1
    }

    internal val size: Size
        get() = mapboxMap!!.getSize()

    private val cameraChangedCallBack = CameraChangedCallback { event ->

        cameraTriggered = true
        if (timeline.state == AnimationState.playing) {
            Timeline.pausedForMovement = true
        }
        timeline.pause()
        if (pr.ON) pr.p(TAG, pr.autoPlay, "cameraChangedCallback, $event")

        if (mapView.width != lastWidth) { //Detect orientation change, update camera.
            if (lastWidth != 0) {
                setupCamera(false)
                lastWidth = mapView.width
                camera.orientationChanged = true

                for (layer in layers) {
                    if (layer.value.paint is ParticleLayerPaint) {
                        camera.needsRotationHandled = true
                        //(layer.value.paint as ParticleStyle).needsRotationHandled = true
                    }
                }

                CoroutineScope(Dispatchers.Main).launch {
                    updateCamera() //Update matrices based on camera position
                    if (timeline.state != AnimationState.playing /*|| Timeline.pausedForMovement*/) {
                        onMove(cameraTriggered, "from cameraChangeCallback")
                    }
                }
            }
            lastWidth = mapView.width
        }

        debounceMoveEndJob?.cancel()
        debounceMoveEndJob = CoroutineScope(Dispatchers.Main).launch {
            delay(150)

            if (Timeline.pausedForMovement) {
                Timeline.pausedForMovement = false
                timeline.resume()
            }

            updateLegendsForMap()
        }

        if (dataInspector.isActive == true) {
            dataInspector.updateWithSameData()
            if (mapboxMap != null && dataInspector.targetCoordinate != null) {
                dataInspector.move(mapboxMap!!.pixelForCoordinate(dataInspector.targetCoordinate!!))
            }

        }
    }

    /** Called from constuctor **/
    private fun handleCallbackSubscriptions() {

        val mapIdleCallback = MapIdleCallback {
            CoroutineScope(Dispatchers.Main).launch {
                onMoveEnd()
            }

            if (Timeline.pausedForMovement) {
                Timeline.pausedForMovement = false
                timeline.resume()
            }

            if (cameraTriggered) {
                cameraTriggered = false
            } else {
                camera.moveState = Camera.STOPPED
            }
        }

        val renderFrameFinishedCallback = RenderFrameFinishedCallback {
            CoroutineScope(Dispatchers.Main).launch {
                updateCamera() //Update matrices based on camera position
                onMoveNoMove(cameraTriggered, "from cameraChangeCallback")
            }
        }

        mapboxMap?.subscribeRenderFrameFinished(renderFrameFinishedCallback)
        mapboxMap?.subscribeCameraChanged(cameraChangedCallBack)
        mapboxMap?.subscribeMapIdle(mapIdleCallback)
        mapboxMap?.subscribeStyleLoaded {
            updateMaskLayersForMap()
        }
    }

    private fun updateMaskLayersForMap() {
        mapboxMap?.getStyle { style ->
            try {
                MaskUtils._masks.forEach { (kind, maskData) -> // Iterate through your tracked mask layers
                    var sourceLayerIdForColor: String? = null
                    when (kind) {
                        MaskLayerKind.LAND -> {
                            sourceLayerIdForColor = "land"
                        }

                        MaskLayerKind.NONE -> {}
                        MaskLayerKind.WATER -> {}
                    }
                    if (sourceLayerIdForColor != null) {
                        val rgbString = getBackgroundColorRBGStringFromLayer(style, sourceLayerIdForColor)

                        if (rgbString != null) {
                            MaskUtils.changeFillLayerColor(mapboxMap!!, "mask::land", rgbString)
                        }
                    }
                }
            } catch (e: Exception) {
                println("MapMaskUpdate Error updating mask layers: ${e.message}  error: $e")
            }
        }
    }

    /** This is in the CameraSync class in the typescript version */
    private fun updateCamera() {
        mapZoom = mapboxMap!!.cameraState.zoom
        /**Center of viewable map from 0 to 1, top to bottom*/
        val point = viewport.projection.project(getCenter()) //gets center from cameraState
        viewport.centerCoordinate = GLCoordinate2D(point.x, point.y)
        worldSize = densityMult * Geo.TILE_SIZE * 2.0.pow(mapZoom).toFloat()
        zoomInt = mapZoom.toInt() + zoomOffset

        scaleCalc = ((tileSize) / worldSize * 2f.pow(zoomInt)) //this table breaks when set to -1...
        scaleMatrix.elements[0] = scaleCalc
        scaleMatrix.elements[5] = -scaleCalc

        translationCalc = tileSize * 2.0.pow(zoomInt + 1)  // +1 only for Mapbox?
        translationMatrix.elements[12] = (point.x * translationCalc).toFloat()
        translationMatrix.elements[13] = (point.y * translationCalc).toFloat()

        rotScalePitchMatrix = CameraSync.calculateCameraMatrixDeg(
            getPitch().toFloat(), getBearing().toFloat(), scaleMatrix
        )
        worldMatrix.multiply(rotScalePitchMatrix, translationMatrix)
        camera.zoom =
            mapZoom // This is used in render to compare to maxZoom and scale tiles, 4.9999 can turn into 5.0...
        camera.worldMatrix = worldMatrix
        camera.updateMatrixWorld() //  camera.viewMatrix= worldMatrix.invert(), strips translation out of world matrix
    }

    override fun getZoom(): Double {
        mapZoom = mapboxMap!!.cameraState.zoom
        return mapZoom
        // Mapbox zoom is 1 less than normal zoom levels
    }

    override fun setZoom(zoom: Double) {
        mapZoom = zoom
        mapboxMap?.setCamera(CameraOptions.Builder().zoom(zoom).build())
    }

    fun setBearing(bearing: Double) {
        mapboxMap?.setCamera(
            CameraOptions.Builder().bearing(bearing).build()
        )
    }

    fun setPitch(pitch: Double) {
        mapboxMap?.setCamera(
            CameraOptions.Builder().pitch(pitch).build()
        )
    }

    override fun getBearing(): Double {
        return mapboxMap!!.cameraState.bearing
    }

    override fun getPitch(): Double {
        return mapboxMap!!.cameraState.pitch
    }

    override fun getCenter(): Coordinate {
        return Coordinate(
            mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude()
        )
    }

    override fun setCenter(center: Coordinate) {
        centerLatLng = center
        mapboxMap?.setCamera(
            CameraOptions.Builder().center(
                Point.fromLngLat(center.lon, center.lat)
            ).zoom(getZoom()).build()
        )
    }

    /** @return Pair<Coordinate, Coordinate> Ex: (Coordinate(lat=80, lon=32.19), Coordinate(lat=20.0, lon=-31.16))  */
    override fun getBounds(): LatLonBounds {
        val boundingBox = getMapboxBounds()
        return LatLonBounds(boundingBox.west(), boundingBox.south(), boundingBox.east(), boundingBox.north())
    }

    override fun setupEvents() {
        val dpr = mapView.context.resources.displayMetrics.density
        doEnsuringStyleLoaded {
            mapboxMap?.let { map ->
                CoroutineScope(Dispatchers.Main).launch {
                    val registrar = MapboxImageRegistrar(map)
                    service.loadStyles(registrar, dpr)
                }
            }
        }
    }

    override fun onTileLayerEvent(layerId: String, eventType: TileLayer.TileLayerEventType, data: Any?) {
    }


    internal fun testForceClear() {
        for (layer in layers.values) {
            if (layer is EncodedTileLayer) {
                val bounds = layer.getTileBounds()
                println("MapboxMapController n cache size before: ${layer.source.tileCache.nativeCache.getCacheSize()}")

                layer.source.tileCache.clearOutsideBounds(bounds)
                println("MapboxMapController n cache size after: ${layer.source.tileCache.nativeCache.getCacheSize()}")
            }
        }
    }

    override fun onConfigurationChanged(p0: Configuration) {}

    @Deprecated("Deprecated in Java")
    override fun onLowMemory() {
    }

    override fun onTrimMemory(level: Int) {
        // Determine how aggressively to clear caches based on the memory pressure level.
        val aggressive = when (level) {
            // Your app is running, but the device is getting low on memory.
            // A non-aggressive cleanup is appropriate.
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE, ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                if (pr.ON) pr.p(
                    TAG,
                    pr.onMemoryTrim,
                    "onTrimMemory: Foreground memory pressure detected. Performing normal cleanup."
                )
                false
            }

            // This constant is deprecated in API 35 and can be safely removed.
            // The system will no longer send this signal to a foreground app.

            // Your app's UI is no longer visible. A great time to be aggressive with cleanup.
            ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> {
                if (pr.ON) pr.p(TAG, pr.onMemoryTrim, "onTrimMemory: UI is hidden")
                true
            }

            // Your app is in the background and is on the LRU list to be killed.
            // This is your last chance to clean up. This is the same as onLowMemory().
            ComponentCallbacks2.TRIM_MEMORY_COMPLETE, ComponentCallbacks2.TRIM_MEMORY_MODERATE -> {
                if (pr.ON) pr.p(
                    TAG,
                    pr.onMemoryTrim,
                    "onTrimMemory: Background memory pressure is high. Releasing as much as possible."
                )
                true
            }

            else -> false
        }

        for (layer in layers.values) {
            if (layer is EncodedTileLayer) {
                val bounds = layer.getTileBounds()
                //println("MapboxMapController n cache size before: ${ layer.source.tileCache.nativeCache.getCacheSize()}")

                layer.source.tileCache.clearOutsideBounds(bounds)
                //println("MapboxMapController n cache size after: ${ layer.source.tileCache.nativeCache.getCacheSize()}")
            }
        }
    }

    override fun moveLayer(id: String, beforeId: String?) {
        mapboxMap?.moveStyleLayer(id, LayerPosition(null, beforeId, null))
    }

    private fun doEnsuringStyleLoaded(block: () -> Unit) {
        mapboxMap?.let {
            if (it.style != null) {
                block()
            } else {
                val cancelable = it.subscribeStyleLoaded {
                    block()
                }
                mapboxCancelables += cancelable
            }
        }
    }

    private fun getMapboxBounds(): CoordinateBounds {
        return mapboxMap!!.coordinateBoundsForCameraUnwrapped(mapboxMap!!.cameraState.toCameraOptions())
    }

    override fun updateCenterLatLngFromMap() {
        centerLatLng = Coordinate(mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude())
    }

    fun formatDate(date: Date): String {
        val instant = date.toInstant()
        val zonedDateTime = ZonedDateTime.ofInstant(instant, ZoneId.systemDefault()) // detect timezone
        val formatter: DateTimeFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME
        return "${zonedDateTime.format(formatter).substring(0, 19)}Z"
    }

    override fun setLayerVisible(id: String, visible: Boolean) {
        super.setLayerVisible(id, visible)
        layerHosts[id]?.showLayer = visible

        doEnsuringStyleLoaded {
            mapboxMap?.style?.getLayer(id)?.visibility(if (visible) Visibility.VISIBLE else Visibility.NONE)
        }
    }

    override fun setLayerHostToUpdate(layerId: String) {
        layerHosts[layerId]?.setTexturesToBind()
    }

    override fun addToMap(source: DataSource, onSourceAdded: () -> Unit) {
        doEnsuringStyleLoaded {
            if (mapboxMap?.style?.styleSourceExists(source.id) == true) return@doEnsuringStyleLoaded
            if (pr.ON) pr.p("MapboxMapController", pr.adminLayers, "addToMap() 100")
            try {
                when (source) {
                    is VectorTileSource -> {
                        mapboxMap?.let {
                            val adapter = MapboxVectorSourceAdapter(source, it)
                            MainScope().launch {
                                val customSource = adapter.makeSource()
                                source.validTime =
                                    parseDateArrayFromString(Timeline.timeStrings[Timeline.currentPhaseA]).first()
                                source.setInvalidateFunction(adapter::invalidate)
                                mapboxMap?.addSource(customSource)
                                onSourceAdded.invoke()
                            }
                        }
                    }

                    is GeoJSONSource -> {
                        val geoJsonSource = com.mapbox.maps.extension.style.sources.generated.geoJsonSource(source.id) {
                            source.data?.let {
                                featureCollection(it)
                            } ?: source.makeDataURL()?.let {
                                data(it.toString())
                            }
                        }
                        mapboxMap?.style?.addSource(geoJsonSource)
                        onSourceAdded.invoke()
                    }

                    else -> {}
                }
            } catch (e: Exception) {
                println(">>> MapController: Failed to add source to map: ${e.localizedMessage}")
            }
        }
    }

    override fun addToMap(layer: MapLayer<*, *>, beforeId: String?) {
        // This ensures that the code inside only runs after the style is loaded.
        doEnsuringStyleLoaded {
            MainScope().launch {
                while (cameraTriggered) { // Don't add while mapbox is moving. Prevents crashes if added while moving.
                    delay(50)
                }

                val style = mapboxMap?.style ?: return@launch

                when (layer) {
                    is VectorTileLayer -> {
                        if (layer.paint is VectorLayerPaint) {
                            if (style.getLayer(layer.id) != null) return@launch
                            val paintStyle = (layer.paint as VectorLayerPaint).asStyleJSON(
                                id = layer.id, source = layer.source.id, sourceLayer = layer.sourceLayer
                            )
                            paintStyle.filter = layer.filter
                            val styleJSON = paintStyle.asStyleJSONObject()

                            fun addStyleLayer() {
                                mapboxMap?.styleManager?.addPersistentStyleLayer(
                                    Value.valueOf(styleJSON.toValueMap()), LayerPosition(null, beforeId, null)
                                )
                            }

                            if (mapboxMap?.style?.styleSourceExists(layer.source.id) == false) {
                                var job: Job? = null
                                job = onSourceAdded.observe(onEach = {
                                    if (it == layer.source.id) {
                                        addStyleLayer()
                                        job?.cancel()
                                    }
                                })
                            } else {
                                addStyleLayer()
                            }

                            MainScope().launch {
                                delay(1000) // Wait for 1000 milliseconds (1 second)
                                trigger(MapControllerEvents.VECTOR_LAYER_ADDED, "")
                            }
                        }
                    }

                    is TileLayer -> {
                        super.addToMap(layer, beforeId)
                        layer.addTileLayerEventListener(this@MapboxMapController)
                        try {
                            if (!layerHosts.contains(layer.id)) {
                                val layerHost = MapboxLayerHost(mapView.context, layer)
                                startCustomLayerUpdates(layer.paint is ParticleLayerPaint)
                                layerHosts[layer.id] = layerHost
                                layerHost.setLayerHostCamera(camera)
                            }
                        } catch (e: Exception) {
                            println("$TAG Failed to add layer to map: $e")
                        }

                        mapboxMap?.style!!.addPersistentStyleCustomLayer(
                            layer.id, layerHosts[layer.id] as MapboxLayerHost, LayerPosition(null, beforeId, null)
                        )
                    }
                }
            }
        }
    }

    override fun removeFromMap(source: DataSource) {
        super.removeFromMap(source)

        doEnsuringStyleLoaded {
            if (source is VectorTileSource || source is GeoJSONSource) {
                mapboxMap?.style?.let {
                    if (it.styleSourceExists(source.id)) {
                        mapboxMap?.removeStyleSource(source.id)
                    }
                }
            }
        }
    }

    override fun removeFromMap(layer: MapLayer<*, *>) {
        super.removeFromMap(layer)
        if (layer is TileLayer) layer.removeTileLayerEventListener(this)
        doEnsuringStyleLoaded {
            mapboxMap?.style?.let {
                if (it.styleLayerExists(layer.id)) {
                    it.removeStyleLayer(layer.id)
                }
                layerHosts.remove(layer.id)
                //hostLayerIds.remove(layer.id)
            }
        }
    }

    override fun redraw() {
        mapboxMap?.triggerRepaint()
    }


    /** Get DataInspector information from Vector Layers**/
    suspend fun queryFeatures(
        point: Point,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {


        ///println(">>> queryFeatures Entered")
        if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() entered, layerCount: ${vectorLayerList.size}")

        val result: DataInspectorResult? = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector.hasMoved)) {
            val queryGeometry = RenderedQueryGeometry(mapboxMap!!.pixelForCoordinate(point))
            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)
            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result?.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() layer.id: ${layer.id}")
                val featuresForThisLayer = featuresBySourceId[layer.source.id]
                //dataInspector?.dIResult?.queriedFeatures?.add(featuresForThisLayer)
                if (featuresForThisLayer.isNullOrEmpty()) {
                    if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() exiting, features For ${layer.id} is null")
                    continue
                }

                if (pr.ON) pr.p(
                    TAG,
                    pr.fireVector,
                    "queryFeatures() featuresForThisLayer ${layer.id} size: ${featuresForThisLayer.size}"
                )

                val presentation = dataInspector.presentationsByLayerId[layer.id]

                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result?.vectorTitles?.add(presentation.title.toString())
                        result?.vectorLayerIds?.add(layer.id)
                        result?.vectorRawValues?.add(featuresForThisLayer)
                        result?.vectorValues?.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                if (pr.ON) pr.p(
                    TAG,
                    pr.fireVector,
                    "queryFeatures() featuresForThisLayer count: ${featuresForThisLayer.size} "
                )

                for (item in featuresForThisLayer) {
                    // CORRECT: Access the properties and feature through the 'queriedFeature' property of item.
                    val originalProperties = item.queriedFeature.feature.properties()
                    val featureId = item.queriedFeature.feature.id()


                    val myMap: Map<String, Any?>? = originalProperties?.entrySet()?.associate { (key, jsonElement) ->
                        // This is a recursive function defined right where it's used
                        fun toKotlinType(element: JsonElement): Any? {
                            return when {
                                element.isJsonNull -> null
                                element.isJsonPrimitive -> {
                                    val primitive = element.asJsonPrimitive
                                    when {
                                        primitive.isBoolean -> primitive.asBoolean
                                        primitive.isNumber -> primitive.asNumber // Can be Long, Double, etc.
                                        primitive.isString -> primitive.asString
                                        else -> primitive.toString()
                                    }
                                }

                                element.isJsonArray -> {
                                    // Recursively convert each element in the array
                                    element.asJsonArray.map { toKotlinType(it) }
                                }

                                element.isJsonObject -> {
                                    // Recursively convert the nested object to a map
                                    element.asJsonObject.entrySet().associate { (k, v) -> k to toKotlinType(v) }
                                }

                                else -> null
                            }
                        }
                        // Convert the value for the current key
                        key to toKotlinType(jsonElement)
                    }

                    if (myMap == null) {
                        return hashMapOf()
                    }

                    val queriedFeature = QueriedFeature(
                        featureId,
                        layer.source.id,
                        item.queriedFeature.sourceLayer, // Use the sourceLayer from the inner feature
                        myMap // Pass the original properties
                    )
                    queriedFeatureList.add(queriedFeature)
                    if (pr.ON) pr.p(
                        TAG,
                        pr.fireVector,
                        "queryFeatures() adding queried feature: ${queriedFeature.properties}"
                    )

                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult

            }
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            if (i2 > 0) {
                if (pr.ON) pr.p(
                    TAG, pr.flickerFix, "queryFeatures() vectorlist not empty, results found, update trigger vector!"
                )
                this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            }
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() found EMPTY, CLEARING DI Result!")
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
            //}
        }
        return null
    }

    /**
     * Queries features within a rectangular area.
     * @param boxTopLeft The top-left screen coordinate of the rectangle.
     * @param boxBottomRight The bottom-right screen coordinate of the rectangle.
     */
    suspend fun queryFeaturesInBox(
        boxTopLeft: ScreenCoordinate,
        boxBottomRight: ScreenCoordinate,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {

        if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeaturesInBox() entered, layerCount: ${vectorLayerList.size}")

        val result: DataInspectorResult = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector.hasMoved)) {
            // CHANGE: Use ScreenBox instead of pixelForCoordinate(point)
            val screenBox = ScreenBox(boxTopLeft, boxBottomRight)
            val queryGeometry = RenderedQueryGeometry(screenBox)

            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)

            // This call remains the same, but it now uses the geometry containing the ScreenBox
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)

            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                val featuresForThisLayer = featuresBySourceId[layer.source.id]

                if (featuresForThisLayer.isNullOrEmpty()) {
                    continue
                }

                val presentation = dataInspector.presentationsByLayerId[layer.id]
                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result.vectorTitles.add(presentation.title.toString())
                        result.vectorLayerIds.add(layer.id)
                        result.vectorRawValues.add(featuresForThisLayer)
                        result.vectorValues.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                for (item in featuresForThisLayer) {
                    val originalProperties = item.queriedFeature.feature.properties()
                    val featureId = item.queriedFeature.feature.id()

                    val myMap: Map<String, Any?>? = originalProperties?.entrySet()?.associate { (key, jsonElement) ->
                        fun toKotlinType(element: JsonElement): Any? {
                            return when {
                                element.isJsonNull -> null
                                element.isJsonPrimitive -> {
                                    val primitive = element.asJsonPrimitive
                                    when {
                                        primitive.isBoolean -> primitive.asBoolean
                                        primitive.isNumber -> primitive.asNumber
                                        primitive.isString -> primitive.asString
                                        else -> primitive.toString()
                                    }
                                }

                                element.isJsonArray -> element.asJsonArray.map { toKotlinType(it) }
                                element.isJsonObject -> element.asJsonObject.entrySet()
                                    .associate { (k, v) -> k to toKotlinType(v) }

                                else -> null
                            }
                        }
                        key to toKotlinType(jsonElement)
                    }

                    if (myMap != null) {
                        val queriedFeature = QueriedFeature(
                            featureId,
                            layer.source.id,
                            item.queriedFeature.sourceLayer,
                            myMap
                        )
                        queriedFeatureList.add(queriedFeature)
                    }
                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult
            }

            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            if (i2 > 0) {
                this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            }
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
        }
        return null
    }

    /** Get DataInspector information from Vector Layers**/
    suspend fun queryFeaturesOld(
        point: Point,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {
        if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() entered, layerCount: ${vectorLayerList.size}")
        if (dataInspector == null) return null

        val result: DataInspectorResult? = if (onTouch) {
            dataInspector?.dIResult
        } else {
            dataInspector?.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector!!.hasMoved)) {
            val queryGeometry = RenderedQueryGeometry(mapboxMap!!.pixelForCoordinate(point))
            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)
            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result?.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() layer.id: ${layer.id}")
                val featuresForThisLayer = featuresBySourceId[layer.source.id]
                //dataInspector?.dIResult?.queriedFeatures?.add(featuresForThisLayer)
                if (featuresForThisLayer.isNullOrEmpty()) {
                    continue
                }

                val presentation = dataInspector?.presentationsByLayerId?.get(layer.id)
                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result?.vectorTitles?.add(presentation.title.toString())
                        result?.vectorLayerIds?.add(layer.id)
                        result?.vectorRawValues?.add(featuresForThisLayer)
                        result?.vectorValues?.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                for (item in featuresForThisLayer) {
                    val stringValueMapItem = mapOf("layerName" to item)
                    val queriedFeature = QueriedFeature(
                        item.queriedFeature.feature.id(), layer.source.id, item.queriedFeature.sourceLayer,
                        stringValueMapItem
                    )
                    queriedFeatureList.add(queriedFeature)
                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult

            }
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            if (i2 > 0) {
                if (pr.ON) pr.p(
                    TAG, pr.flickerFix, "queryFeatures() vectorlist not empty, results found, update trigger vector!"
                )
                this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            }
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() found EMPTY, CLEARING DI Result!")
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
            //}
        }
        return null
    }

    /**
     * Wraps the callback-based `queryRenderedFeatures` function in a suspending coroutine.
     *
     * This function can be called from within a coroutine scope and will suspend until the
     * query is complete, then return the result or throw an exception.
     *
     * @param queryGeometry The geometry to query.
     * @param queryOptions The options for the query.
     * @return A `List<QueriedRenderedFeature>` containing the query results.
     * @throws Exception if the query fails.
     */
    private suspend fun queryRenderedFeatures(
        queryGeometry: RenderedQueryGeometry, queryOptions: RenderedQueryOptions
    ): List<QueriedRenderedFeature> {
        // This bridges the callback API with the coroutine world.
        // It suspends the coroutine until 'continuation.resume' or 'resumeWithException' is called.
        return suspendCancellableCoroutine { continuation ->
            mapboxMap!!.queryRenderedFeatures(queryGeometry, queryOptions) { result ->
                if (result.isValue) {
                    // On success, resume the coroutine with the list of features.
                    /*
                    continuation.resume(result.value ?: emptyList()) { cause, _, _ ->
                        null
                        (cause)
                    }*/
                    continuation.resume(result.value ?: emptyList()) // older version for compatibility.

                } else {
                    // On failure, resume the coroutine by throwing an exception.
                    continuation.resumeWithException(
                        Exception(result.error ?: "Mapbox queryRenderedFeatures failed with an unknown error.")
                    )
                }
            }
        }
    }

    internal fun showOrHideLandMask(beforeId: String? = null): String? {
        var found = false

        for (layer in layers) {
            val layerValue = layer.value

            if (layerValue is EncodedTileLayer) {
                if (layerValue.visible && layerValue.hasLandMask) { //TODO: better logic to detect...
                    found = true
                }
            }
        }
        val existingMaskData = _masks[MaskLayerKind.LAND] ?: return null // Guard
        setLayerVisible(existingMaskData.layer.id, found)
        MaskUtils.lastVisibleState = found

        if (found) {
            return existingMaskData.layer.id
        }

        return null
    }

    internal fun testGetPendingTiles() {
        for (layer in layers) {
            if (layer.value.source is EncodedTileSource) {
                println("MapboxMapController: waiting on tiles: ${(layer.value.source as XweatherEncodedTileSource).pendingRequestedTiles}")
            }

        }
    }

    internal fun getLog() {
        println("GL1--------------------------------------------------------------")
        println("GL1 pausedForMovement:${Timeline.pausedForMovement}")
        println("GL1 pausedForDownload:${Timeline.pausedForDownload}")
        println("GL1 timeLine State:${timeline.state}")
        println("GL1 Camera MoveState:${camera.moveState}")
        println("GL1 tl.isDownloading: ${Timeline.isDownloading}")
        println("GL1 waitingOnDL: $waitingOnDL")
        println("GL1 wasWaitingOnDL: ${wasWaitingOnDL}")

        for (layer in layers) {
            if (layer.value.visible && layer.value.animator!!.animation.pendingCount != 0) {
                println("GL1 found PendingDL: ${layer.value.id} has ${layer.value.animator!!.animation.pendingCount}")
                println("GL1 tileCache pending: ${layer.value.source.tileCache._pending}")
            }
        }
    }

    fun clearPending() {
        for (layer in layers) {
            if (layer.value is EncodedTileLayer) {
                layer.value.source.tileCache._pending.clear()
                layer.value.animator!!.animation.pendingCount = 0
                (layer.value.source as XweatherEncodedTileSource).pendingRequestedTiles.clear()
                checkDownloadStatus(layer.value.id, 0)
            }

        }

        Timeline.isDownloading = false
        waitingOnDL = false
        wasWaitingOnDL = true
        Timeline.pausedForDownload = false
        //timeline.state = AnimationState.playing
        //trigger(MapControllerEvents.LOAD_COMPLETE, true)

    }
}

// `MapboxImageRegistrar` acts as an adapter between Mapbox and the MapsGL image-loading and registering
// infrastructure used in `WeatherService.loadStyles`
class MapboxImageRegistrar(private val mapboxMap: MapboxMap) : ImageRegisteringMap {
    override fun addImage(id: String, image: Bitmap, sdf: Boolean) {
        mapboxMap.getStyle { style ->
            style.addImage(id, image, sdf)
        }
    }
}

// Utility extension functions to convert Map<String, Any> recursively into HashMap<String, Value>
private fun Any.toValue(): Value {
    return when (this) {
        is Map<*, *> -> {
            val map = HashMap<String, Value>()
            for ((k, v) in this) {
                if (k is String && v != null) {
                    map[k] = v.toValue()
                }
            }
            Value.valueOf(map)
        }

        is List<*> -> Value.valueOf(this.mapNotNull { it?.toValue() })
        is String -> Value.valueOf(this)
        is Int -> Value.valueOf(this.toLong())
        is Double -> Value.valueOf(this)
        is Long -> Value.valueOf(this)
        is Boolean -> Value.valueOf(this)
        else -> Value.nullValue()
    }
}

private fun Map<String, Any>.toValueMap(): HashMap<String, Value> {
    val result = HashMap<String, Value>()
    for ((key, value) in this) {
        result[key] = value.toValue()
    }
    return result
}