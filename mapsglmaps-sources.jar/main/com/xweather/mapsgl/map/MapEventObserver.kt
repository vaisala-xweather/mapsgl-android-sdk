package com.xweather.mapsgl.map

import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController

interface MapEventObserver {
    @Throws(Exception::class)
    fun onAdd()

    @Throws(Exception::class)
    fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController)

    @Throws(Exception::class)
    fun onRemove()

    @Throws(Exception::class)
    suspend fun onMove()

    @Throws(Exception::class)
    suspend fun update()

    @Throws(Exception::class)
    fun onMoveStart()

    @Throws(Exception::class)
    suspend fun onMoveEnd()

    @Throws(Exception::class)
    fun onResize()

    @Throws(Exception::class)
    fun onClick()

    @Throws(Exception::class)
    fun onVisible()

    @Throws(Exception::class)
    fun onHidden()
}