/**
 * MapController.kt
 *
 * Adapted from IOS version
 * Need to reincorporate EncodedSourceDescriptor
 *
 * @author Jason Suto 12/12/23
 *
 **/

package com.xweather.mapsgl.map

import LayerEvents
import android.content.ComponentCallbacks2
import android.content.Context
import android.graphics.RectF
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import androidx.core.view.isVisible
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import com.mapbox.geojson.Point
import com.mapbox.maps.CustomLayerHost
import com.mapbox.maps.MapView
import com.mapbox.maps.extension.style.expressions.dsl.generated.config
import com.mapbox.maps.plugin.gestures.OnMapClickListener
import com.xweather.mapsgl.anim.AnimationEvent
import com.xweather.mapsgl.anim.AnimationOptions
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.anim.Timeline.Companion.timeStrings
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.controls.DataInspectorControl
import com.xweather.mapsgl.controls.legend.LegendControl
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.controls.legend.bar.ColorScaleUpdatable
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.data.series.AnimatorSync
import com.xweather.mapsgl.events.Cancellable
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.MapControllerEvents
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.geo.Viewport
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.gl.worldObjects.cameras.CameraType
import com.xweather.mapsgl.layers.FeatureQueryResult
import com.xweather.mapsgl.layers.QueriedFeature
import com.xweather.mapsgl.layers.spec.ContourLayerDescriptor
import com.xweather.mapsgl.layers.spec.LayerDescriptor
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.RasterLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.layers.spec.VectorLayerDescriptor
import com.xweather.mapsgl.layers.tile.EncodedTileLayer
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileConversions
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.camera
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.mapZoom
import com.xweather.mapsgl.map.mapbox.MapboxLayerHost
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.MapboxMapController.Companion.PERSPECTIVECAMERA
import com.xweather.mapsgl.map.mapbox.MapboxMapController.Companion.TAG
import com.xweather.mapsgl.renderers.ContourRenderer
import com.xweather.mapsgl.renderers.EncodedDataRenderer
import com.xweather.mapsgl.renderers.ParticleRenderer
import com.xweather.mapsgl.renderers.RasterLayerRenderer
import com.xweather.mapsgl.sources.DataSource
import com.xweather.mapsgl.sources.EncodedTileSource
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.ImageTileSource
import com.xweather.mapsgl.sources.RasterTileApiEvent
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.sources.data.EncodedData
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.SourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.VectorLayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.Coordinate
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.MapProvider
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.utils.Signal
import com.xweather.mapsgl.utils.parseDateArrayFromString
import com.xweather.mapsgl.weather.CompositeWeatherLayerConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherConfiguration
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.sql.DriverManager
import kotlin.collections.set
import kotlin.math.atan

internal sealed class MapControllerError : Throwable() {
    data class ALREADY_EXISTS(val desc: String = "already exists") : Error()
    data class INVALID_SOURCE(val desc: String = "invalid source") : Error()
}

/**
 * A MapController class acts as the interface between the map view of a mapping library and MapsGL-specific
 * functionality.
 */
abstract class MapController(val mapView: MapView, val account: XweatherAccount) : MapProvider, ViewModel(),
    DefaultLifecycleObserver, TileLayer.TileLayerEventListener, ComponentCallbacks2, OnMapClickListener {

    internal companion object {
        var packageName: String? = null
    }

    private val listeners: MutableMap<String, MutableList<(Any) -> Unit>> = mutableMapOf()

    lateinit var centerLatLng: Coordinate// = Coordinate(viewport.getCenter().y, viewport.getCenterOffset().x)
    private var sources: MutableMap<String, DataSource> = mutableMapOf()
    var layers: MutableMap<String, MapLayer<*, *>> = mutableMapOf()
    private var layerIdsByWeatherCode: MutableMap<LayerCode, MutableList<String>> = mutableMapOf()
    private var particleLayers: MutableMap<String, MapLayer<*, *>> = mutableMapOf()

    val dataInspector = DataInspectorControl(this)
    private var _legendControl: LegendControl? = null
    var legendControl: LegendControl? = null


    private val downloadTrackingHandler = Handler(Looper.getMainLooper())
    private var downloadStartTime = 0L
    val thisMap = this

    private val downloadTrackingRunnable = object : Runnable {
        override fun run() {
            val elapsedSeconds = (System.currentTimeMillis() - downloadStartTime) / 1000
            //println(">>> MapController: Still waiting for encoded downloads... ($elapsedSeconds seconds elapsed)")

            // --- TIMEOUT LOGIC ---
            if (elapsedSeconds > 125) {
                println(">>> MapController: Download timed out after 125 seconds. Clearing pending downloads.")
                if (thisMap is MapboxMapController) {
                    thisMap.clearPending()
                }
                // Clear the pending downloads
                // The LiveData observer will then see the empty map and stop the handler.
                return // Stop the runnable immediately
            }

            // Schedule next check in 1 second
            downloadTrackingHandler.postDelayed(this, 1000)
        }
    }

    internal val layerHosts: MutableMap<String, MapboxLayerHost> = mutableMapOf()
    private var lastUpdated = 0L
    private var currentTime = 0L
    private val minimumDIUpdateInterval = 60

    /** -1 is fast, 1 is sharper. This is also sent to TileLayer. **/
    internal var zoomOffset = -1 //-1 is quicker to load, less detail, 0 looks sharper.
    internal var animatingTimeline = false
    internal var readyToPlay = true
    private val _onLoadStart = MutableLiveData<Unit>() // Unit signifies no specific data
    var debounceMoveEndJob: Job? = null // Add this property

    /** Fired when loading begins for any data source. **/
    val onLoadStart: LiveData<Unit> = _onLoadStart
    internal fun triggerLoadStart() {
        _onLoadStart.postValue(Unit)
        //this.trigger(MapControllerEvents.LOAD_PROGRESS, true)
        //if (pr.ON) pr.p(TAG, pr.loadTracking, "Loading Started")
    }

    internal fun triggerLoadComplete() {
        _onLoadComplete.postValue(Unit)
        //trigger(MapControllerEvents.LOAD_COMPLETE, true)
        if (pr.ON) pr.p(TAG, pr.loadTracking, "Loading Done")

        // do a final datainspector here
        //if (pr.ON) pr.p("MapController", pr.queryTrack, "onLoadComplete() triggered, doing a query...")
        dataInspector.targetCoordinate?.let { coords ->
            val allLayerIds = layers.values.map { it.id }
            viewModelScope.launch {
                query(coords, allLayerIds, true)
            }
        }
    }

    private val _onLoadComplete = MutableLiveData<Unit>() // Unit signifies no specific data


    /** Fired when all data sources have finished loading. **/
    val onLoadComplete: LiveData<Unit> = _onLoadComplete
    val onSourceAdded = Signal.eventOnly<String>(scope = viewModelScope)
    private val onSourceRemoved = Signal.eventOnly<String>(scope = viewModelScope)
    private val onLayerAdded = Signal.eventOnly<String>(scope = viewModelScope)
    private val onLayerRemoved = Signal.eventOnly<String>(scope = viewModelScope)


    private var customLayerUpdatesHaveStarted = false
    internal val type = PERSPECTIVECAMERA
    private var frameCallback: Choreographer.FrameCallback? = null
    private val choreographer = Choreographer.getInstance()

    //** This may not be needed. onMove was being used in instances other than when the camera moved **/
    internal suspend fun onMoveNoMove(pauseParticles: Boolean = true, tag: String = "empty") {

        //if(pr.ON) pr.p(TAG, pr.onMove, "onMoveNoMove()")
        if (pauseParticles) camera.moveState = Camera.MOVING
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
            }
        }
    }

    internal val eventDispatcher = EventDispatcher()

    /**
     * Configuration options that control the behavior of timeline animations and data preloading.
     *
     * Use this object to modify settings such as playback speed, loop behavior, and
     * whether the system should aggressively pre-fetch tiles ([AnimationOptions.shouldPreloadData])
     * to ensure seamless, buffer-free playback across the active time range.
     */
    val animationOptions: AnimationOptions = AnimationOptions()

    /** instance used for managing animation and time-based data. **/
    val timeline: Timeline = Timeline(animationOptions, this)

    private val animatorSync: AnimatorSync = AnimatorSync(timeline)
    internal val viewport: Viewport = Viewport(this)
    internal val tileSize = 512f
    internal var worldSize = 0f
    internal var cameraTriggered = false

    /** Assigned as "mapZoom.toInt() + zoomOffset" **/
    internal var zoomInt = 0
    internal var densityMult = 1.0f
    internal var scaleCalc = 0f
    internal var translationCalc = 0.0

    /** Keep track of screen size to detect orientation change. **/
    internal var lastWidth = 0

    /**Usually 60, 90, 120 fps **/
    internal var refreshRate: Float

    /**
     * The primary interface for communicating with the Xweather backend.
     *
     * This service handles the construction of API requests, authentication
     * using the provided [account] credentials, and the retrieval of
     * weather data for the various layers and data sources managed by this controller.
     */
    val service: WeatherService = WeatherService(account)

    init {

        // Setup the listener for option changes
        timeline.opts.onPreloadChanged = { isEnabled ->
            if (isEnabled) {
                viewModelScope.launch {
                    preloadVisibleTiles()
                }
            }
        }

        val timelineAdvanceListener: (Any) -> Unit = {
            // This runs on the thread the timeline uses
            //binding.timelineView.timelineControls.setPosition(controller.timeline.position)

            if (dataInspector.isActive == true) {
                currentTime = System.currentTimeMillis()
                if (currentTime - lastUpdated > minimumDIUpdateInterval) {
                    lastUpdated = currentTime
                    val lifecycleOwner = mapView.findViewTreeLifecycleOwner()
                    lifecycleOwner?.lifecycleScope?.launch(Dispatchers.Main) { //260226 was .Main
                        //println(">> CALLING update()")
                        dataInspector.update()
                    }
                }
            }
        }
        timeline.on(AnimationEvent.advance, timelineAdvanceListener)

        packageName = mapView.context.packageName
        setZoom(1.0)
        refreshRate = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R)
            getScreenRefreshRate(mapView.context)
        else 60f

        Timeline.frameRate = refreshRate

        // Update the `timeRange` property on data sources when the timeline range changes
        timeline.on(AnimationEvent.range_change) {
            sources.values.forEach {
                if (it is TileSource<*>) {
                    if (pr.ON) pr.p(TAG, pr.timeLineListener, "range change:")
                    it.timeRange = timeline.start..timeline.end
                }
            }
        }

        timeline.on(AnimationEvent.INTERVAL_CHANGE) {
            layers.forEach {
                val source = it.value.source
                if (source is VectorTileSource) {
                    source.validTime = parseDateArrayFromString(timeStrings[Timeline.currentPhaseA]).first()

                    if (!animatingTimeline) {
                        source.invalidate()
                    }
                }
            }
        }

        Timeline.pendingVectorDownloadsLiveData.observe(
            this.mapView.context as LifecycleOwner
        ) { count ->
            if (count == 0) {
                //println(">> MapController Vector DONE LOADING!!!!!!")
                if (layers.values.any {
                        val source = it.source as? VectorTileSource
                        source?.dlCount == 1
                    }) {
                    if (dataInspector.on) {
                        dataInspector.updateVector()
                    }

                }
                //timeline.setIsDownloading(false)
            }
        }

        Timeline.pendingEncodedDownloadsLiveData.observe(
            mapView.findViewTreeLifecycleOwner() ?: (mapView.context as LifecycleOwner)
        ) { hashMap ->
            if (hashMap.isNotEmpty()) {
                // Start tracking if not already started
                if (downloadStartTime == 0L) {
                    downloadStartTime = System.currentTimeMillis()
                    downloadTrackingHandler.post(downloadTrackingRunnable)
                    if (pr.ON) pr.p(TAG, pr.loadTracking, "Downloads started. Timer initiated.")
                }
                timeline.setIsDownloading(true)
                triggerLoadStart()
            } else {
                // CLEANUP: Stop the timer and reset start time
                downloadTrackingHandler.removeCallbacks(downloadTrackingRunnable)
                val totalSeconds = (System.currentTimeMillis() - downloadStartTime) / 1000
                downloadStartTime = 0L
                //println(">>> MapController: All downloads finished! Total time: $totalSeconds seconds.")
                timeline.setIsDownloading(false)
                triggerLoadComplete()
            }
        }

    } // end init{}

    /**
     * Triggers a manual pre-fetch of tile animation data.
     *
     * This function caches tiles for the visible viewport across the timeline's active
     * time range.
     * This is typically used to ensure smooth playback and minimize loading time
     */
    fun preloadAnimationData() {
        viewModelScope.launch {
            animationOptions.forcePreloadOneTime = true
            preloadVisibleTiles()
            animationOptions.forcePreloadOneTime = false
        }
    }


    /**
     * Activates and initializes the Data Inspector control for the map.
     *
     * This function enables the "pick" or "inspect" mode which allows users to retrieve
     * underlying weather data values from specific coordinates on the map. It ensures
     * that listeners are only initialized once and sets up the synchronization
     * for vector data updates.
     *
     * @param mapView The [MapView] instance where the data inspector UI should be hosted.
     * @return The initialized [DataInspectorControl] instance.
     */
    fun addDataInspectorControl(mapView: MapView): DataInspectorControl {
        if (!dataInspector.on) {
            dataInspector.initializeListeners(this)

            this.on(DataInspectorEvent.VECTOR_UPDATE) {
                //if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() on(DataInspectorEvent.VECTOR_UPDATE)")
                dataInspector.updateVector()
            }
        }

        dataInspector.on = true
        return dataInspector
    }

    /**
     * Deactivates the Data Inspector control and cleans up its associated resources.
     *
     * This function performs the following cleanup steps:
     * 1. Sets the [DataInspectorControl.on] state to `false`.
     * 2. Triggers the UI to hide its overlay/view components.
     * 3. Unregisters all event listeners (such as `VECTOR_UPDATE`) previously attached
     *    to this [MapController] to prevent memory leaks and unnecessary background processing.
     *
     * Call this when the user exits "inspection" or "picker" mode.
     */
    fun removeDataInspectorControl() {
        dataInspector.on = false
        dataInspector.hide()
        dataInspector.removeEvents(this)
        //dataInspector = null
    }

    /**
     * Returns whether the map currently contains a weather layer with the specified identifier.
     * @param layerCode - The enum that matches the weather layer identifier to check for.
     * @returns `true` if the weather layer exists, otherwise `false`
     */
    fun hasWeatherLayer(code: LayerCode): Boolean {
        // If code corresponds to a composite layer, then iterate through the composite's layers and check if all layers exist.
        val config = LayerCode.getConfigurationForLayerCode(code, service)
        if (config is CompositeWeatherLayerConfiguration) {
            val results = config.layers.map { hasWeatherLayer(it.code) }
            return results.all { it }
        }
        return layerIdsByWeatherCode[code] != null
    }

    /**
     *
     * Returns A layer given its LayerCode.
     *
     * example: LayerCode.Temperatures
     *
     * @param layerCode - The enum that matches the weather layer identifier to retrieve.
     * @returns `the Layer if it exists, otherwise `null`
     *
     */
    fun getWeatherLayer(code: LayerCode): MapLayer<*, *>? {
        layerIdsByWeatherCode[code]?.let {
            if (it.size > 1) {
                println(
                    "[MapsGL] There are multiple layers associated with the weather code ${code.value}: ${
                        it.joinToString(
                            ", "
                        )
                    }"
                )
                return null
            }
            return getLayer(it.first())
        }
        return null
    }

    /**
     * Adds a new weather layer to the map.
     * @param layerCode - The enum that matches one of the supported weather layer identifiers.
     * @returns The newly added map layer or an array of layers if the weather layer identifier maps to multiple layers.
     */
    fun addWeatherLayer(layerCode: LayerCode, id: String? = null, beforeId: String? = null): TileLayer? {
        // LayerCode.getConfigurationForLayerCode might return the base WeatherConfiguration.
        // The specific generic type is often known when calling WeatherService.SpecificLayer() directly.
        val configuration = LayerCode.getConfigurationForLayerCode(layerCode, service)
        return addWeatherLayer(configuration, id, beforeId)
    }

    // This function takes the base WeatherConfiguration. We'll need to cast or type check
    // if we need the specific S, LD, P types here.
    // However, the most crucial part is that `config.layer` (which is LayerDescriptor<P>)
    // and `config.layer.paint` (which is P) will be correctly typed if `config`
    // was obtained from a strongly-typed factory method like `WeatherService.WindParticles()`.
    fun addWeatherLayer(
        config: WeatherConfiguration,
        id: String? = null,
        beforeId: String? = null,
        isCompoundLayer: Boolean = false
    ): TileLayer? {
        if (config is CompositeWeatherLayerConfiguration) {
            var addedLayer: TileLayer? = null
            for (subConfig in config.layers) { // subConfig is AnyWeatherLayerConfiguration
                //val subId = if (id != null) "${id}__${subConfig.code.value}" else null // old code, always null
                val subId =
                    if (id != null) "${id}__${subConfig.code.value}" else "${config.code.name}__${subConfig.code.value}"
                // Recursive call, subConfig is still AnyWeatherLayerConfiguration
                val result = addWeatherLayer(subConfig, subId, beforeId, true)
                result?.code = config.code.value // Use the composite's code
                if (addedLayer == null && result != null) {
                    addedLayer = result
                }
            }

            setPresentation(config, addedLayer)
            trigger(MapControllerEvents.LAYER_ADDED, (addedLayer is VectorTileLayer))
            return addedLayer
        }

        // We expect a WeatherLayerConfiguration<S, LD, P> here for individual layers.
        // If LayerCode.getConfigurationForLayerCode returns a non-generic WeatherConfiguration,
        // you might need to reconsider its return type or handle it.
        // For now, let's assume if it's not Composite, it's our generic WeatherLayerConfiguration.
        if (config !is WeatherLayerConfiguration<*, *>) { // Check against the generic form
            println("[MapsGL] Warning: addWeatherLayer received a WeatherConfiguration that is not a WeatherLayerConfiguration for ${config.code.value}. Layer not added.")
            return null
        }
        // Now 'config' is known to be WeatherLayerConfiguration<S, LD, P>
        // S, LD, P are star-projected here but will be specific if the `config` instance was created that way.

        getWeatherLayer(config.code)?.let {
            moveLayer(it.id, beforeId)
            setLayerVisible(it.id, true)
            trigger(MapControllerEvents.VISIBILITY_CHANGED, it.id)
            if (this is MapboxMapController) {
                val maskLayer = this.showOrHideLandMask(beforeId)

                if (maskLayer != null) {
                    moveLayer(it.id, maskLayer)
                }
            }

            if (config.legend != null) {
                legendControl?.add(config.legend!!)
            }

            return it as TileLayer // Assuming all weather layers are TileLayers
        }

        val insertBeforeId: String? = beforeId

        // Add the source from the configuration
        addSource(config.source) // config.source is SourceDescriptor (S)
        val layerDescriptor = config.layer

        // Special handling for EncodedSourceDescriptor and paint properties
        // This section becomes much cleaner as 'layerDescriptor.paint' is now specifically typed.
        if (config.source is EncodedSourceDescriptor) {
            val source = config.source as EncodedSourceDescriptor // Cast for dataset access
            val paint = layerDescriptor.paint

            val channels = when (paint) {
                is SampleLayerPaint -> paint.sample.channel
                is ParticleLayerPaint -> paint.sample.channel
                is ContourLayerPaint -> paint.sample.channel
                else -> emptyList()
            }

            if (channels.isNotEmpty()) {
                val tempRange = source.datasets?.get(channels[0].rawValue)?.dataRange
                when (paint) {
                    is ContourLayerPaint -> {
                        if (pr.ON) pr.p(TAG, pr.contour, "addWeatherLayer() detected contourLayerPaint 300 ")
                        if (paint.sample.colorScale.range == null) {
                            paint.sample.colorScale.range = tempRange
                        }
                        if (paint.sample.expression != SampleExpression.DIFFERENCE) {
                            paint.sample.colorScale.range = tempRange
                        }
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }

                    is SampleLayerPaint -> {
                        if (paint.sample.colorScale.range == null) {
                            paint.sample.colorScale.range = tempRange
                        }
                        if (paint.sample.expression != SampleExpression.DIFFERENCE) {
                            paint.sample.colorScale.range = tempRange
                        }
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }

                    is ParticleLayerPaint -> {
                        paint.sample.colorScale.range = tempRange
                        val tempQuality = paint.sample.quality
                        zoomOffset = 0
                    }
                    // Add other paint types if necessary
                }
            }
        }

        val layer = addLayer(layerDescriptor, insertBeforeId) ?: return null // Pass the correctly typed layerDescriptor

        if (!isCompoundLayer) {
            if (pr.ON) pr.p(TAG, pr.vectorRefactor, "triggering LAYER_ADDED from addweatherLayer() NORMALLY")
            trigger(MapControllerEvents.LAYER_ADDED, (layer is VectorTileLayer))
        }


        if (layerIdsByWeatherCode[config.code] == null) {
            layerIdsByWeatherCode[config.code] = mutableListOf()
        }
        layerIdsByWeatherCode[config.code]?.add(layer.id)
        layer.code = config.code.value

        if (this is MapboxMapController) {
            val maskKindFromDescriptor: MaskLayerKind? = when (layerDescriptor) {
                is SampleLayerDescriptor -> layerDescriptor.mask
                is ParticleLayerDescriptor -> layerDescriptor.mask
                else -> null // Or MaskLayerKind.NONE if that makes more sense to avoid a null check later
            }
            if (maskKindFromDescriptor != null && maskKindFromDescriptor != MaskLayerKind.NONE) {
                val currentMapboxMap = this.mapboxMap!!
                val maskLayer = addMaskLayer(maskKindFromDescriptor, service, this, currentMapboxMap, insertBeforeId)

                if (maskKindFromDescriptor == MaskLayerKind.LAND && layer is EncodedTileLayer) {
                    layer.hasLandMask = true
                }
            }
        }

        addLegend(config)
        if (layer.id == "severe.alerts.fill") {
            CoroutineScope(Dispatchers.Main).launch {
                delay(1500) // Wait for 2 seconds (non-blocking)
                updateLegendsForMap()
                delay(2500) // Wait for 2 seconds (non-blocking)
                updateLegendsForMap()
                //println(">>> MaoController MapsGL: 2 seconds have passed for severe alerts, called updateLegendsForMap")
            }
        }

        setPresentation(config, layer)
        return layer
    }

    fun getConfigForCode(layerCode: LayerCode): WeatherConfiguration {
        return LayerCode.getConfigurationForLayerCode(layerCode, service)
    }


    fun setWeatherLayerVisibility(code: LayerCode, visible: Boolean) {
        // Check if the code corresponds to a composite layer. If so, then iterate through each of its layers and set the visibility.
        val config = LayerCode.getConfigurationForLayerCode(code, service)
        if (config is CompositeWeatherLayerConfiguration) {
            config.layers.forEach { setWeatherLayerVisibility(it.code, visible) }
            trigger(MapControllerEvents.VISIBILITY_CHANGED, config.code)
            return

        }

        getWeatherLayer(code)?.let {
            if (visible) {
                it.show()
            } else {
                it.hide()
                if ((config is WeatherLayerConfiguration<*, *>)) {
                    config.legend?.let { it1 ->
                        legendControl?.removeLegend(it1.id)
                    }
                }
            }

            setLayerVisible(it.id, visible)

            if (this is MapboxMapController) {
                if (pr.ON) pr.p(TAG, pr.maskVisiblity, "setWeatherLayerVisibility() IS MapboxMapController...")
                this.showOrHideLandMask(it.id)
            }
            trigger(MapControllerEvents.VISIBILITY_CHANGED, it.id)
        }
    }

    /** Removes a layer from the map. **/
    fun removeWeatherLayer(code: LayerCode) {
        val config = LayerCode.getConfigurationForLayerCode(code, service)

        if (config is CompositeWeatherLayerConfiguration) {
            for (subConfig in config.layers) {
                removeLayer(subConfig.layer.id, true)
                layerIdsByWeatherCode[subConfig.code]?.let {
                    layerIdsByWeatherCode.remove(subConfig.code)
                }

                subConfig.legend?.let { it1 -> legendControl?.removeLegend(it1.id) }
            }
            trigger(MapControllerEvents.LAYER_REMOVED, config.layers.first().layer.id)
            return
        }

        layerIdsByWeatherCode[code]?.let {
            if (it.size == 0) return
            if (it.size > 1) {
                // TODO: print warning to console that multiple layers exist for the same layer code
                println("Warning: Multiple layers exist for the same layer code: $code")
                return
            }

            val layerId = it.first()
            removeLayer(layerId)
            layerIdsByWeatherCode.remove(code)

            //added to try to fix issue 17 crash
            layerHosts.remove(layerId)
            if (pr.ON) pr.p(TAG, pr.lHost, "removeWeatherlayer() $layerId removed")

            if ((config is WeatherLayerConfiguration<*, *>)) {
                val layerDescriptor = config.layer

                if (this is MapboxMapController) {
                    if (layerDescriptor is SampleLayerDescriptor && layerDescriptor.mask != MaskLayerKind.NONE) {
                        this.showOrHideLandMask()
                    } else if (layerDescriptor is ParticleLayerDescriptor && layerDescriptor.mask != MaskLayerKind.NONE) {
                        this.showOrHideLandMask()
                    }
                }

                config.legend?.let { it1 -> legendControl?.removeLegend(it1.id) }

            }
        }
    }

    private fun setPresentation(config: WeatherConfiguration, layer: TileLayer?) {
        if (layer != null && config is WeatherLayerConfiguration<*, *>) {
            if (config.presentation != null) {
                dataInspector.setPresentation(layer.id, config.presentation!!)
            }
        }
    }

    /**
     * Returns the map's container size.
     */
    override fun getSize(): Size {
        throw Error("Subclasses must override `getSize`")
    }

    /**
     * Returns the map's geographical center coordinate.
     */
    override fun getCenter(): Coordinate {
        throw Error("Subclasses must override `getCenter`")
    }

    /**
     * Sets the map's geographical center coordinate.
     * @param center -
     */
    open fun setCenter(center: Coordinate) {
        throw Error("Subclasses must override `setCenter`")
    }

    /** * @return CoordinateBounds. Ex: (west -155.34224870917907 east: -92.06099932816754 )  */
    override fun getBounds(): LatLonBounds {
        throw Error("Subclasses must override `getBounds`")
    }

    /**
     * Returns the map's current zoom level.
     */
    override fun getZoom(): Double {
        throw Error("Subclasses must override `getZoom`")
        return mapZoom
    }

    /**
     * Sets the map's zoom level.
     * @param zoom - The new zoom level to set.
     */
    open fun setZoom(zoom: Double) {
        throw Error("Subclasses must override `setZoom`")
    }

    /**
     * Returns the map's current rotational bearing in degrees, if supported. A bearing of `0` orients the map so that
     * north is up.
     */
    override fun getBearing(): Double {
        throw Error("Subclasses must override `getBearing`")
    }

    /**
     * Returns the map's current pitch/tilt in degrees, if supported.
     */
    override fun getPitch(): Double {
        throw Error("Subclasses must override `getPitch`")
    }

    /**
     * Returns the map camera's current field-of-view in degrees.
     */
    override fun getFov(): Double {
        throw Error("Subclasses must override `getFov`")
    }

    //==============================================================================================================

    override fun onCreate(owner: LifecycleOwner) {
        // Start observing when the owner is created
        ImageTileSource.apiEvent.observe(owner, ::onRasterTileEvent)
    }

    private fun getScreenRefreshRate(context: Context): Float {
        if (Build.VERSION.SDK_INT >= 30)
            return context.display.refreshRate ?: 60f
        else return 60f
    }

    val metadataObserver = Observer<String> { newValue ->
        CoroutineScope(Dispatchers.Main).launch {
            val layer = layers[newValue]
            if (layer != null) {
                (layer as TileLayer).requestVisibleTiles(getBounds(), true)
            }
        }
    }
    var wasWaitingOnDL = false
    var waitingOnDL = false

    /** Causes render to happen **/
    internal open fun redraw() {
        throw Error("Subclasses must override `redraw`")
    }

    /**  * Sets the value of a paint style property for the specified layer.
     * @param layerId Identifier of the layer to set the paint property on.
     * @param property Paint style property to set as a key path string.
     * @param value New value of the paint style property to set.     */
    fun setPaintProperty(layerId: String, property: String, value: Any) {
        //TODO: implement
    }

    internal open fun updateCenterLatLngFromMap() {
        throw Error("Subclasses must override `updateCenterLatLngFromMap`")
    }

    /** * Performs additional setup for a layer after it has been added to the map, which may be necessary for some
     * third-party mapping libraries.
     *
     * @protected
     * @param layer Layer that was added to the map.
     * @param relativeTo Identifier of an existing layer that the new layer was added relative to.  */
    open fun add(layerID: String, layerHost: CustomLayerHost) {}

    /** Shows or hides the layer with matching id */
    open fun setLayerVisible(id: String, visible: Boolean = true) {
        //if(pr.ON) pr.p(TAG, pr.ordering, "setLayerVisible() id:$id visible:$visible")

        mapZoom = getZoom()
        if (layers[id]?.visible != visible) {
            layers[id]?.visible = visible
            redraw()
        }
    }

    internal open fun addToMap(source: DataSource, onSourceAdded: () -> Unit) {}

    internal open fun addToMap(layer: MapLayer<*, *>, beforeId: String?) {
        if (pr.ON) pr.p(
            "MapController",
            pr.waaveRenderpath,
            ">> addToMap(source: DataSource, onSourceAdded: () -> Unit) {}  ENTERED"
        )
        layers[layer.id] = layer
        if (layer.paint is ParticleLayerPaint) {
            particleLayers[layer.id] = layer
        }
        layer.visible = true
        if (pr.ON) pr.p("MapController", pr.waaveRenderpath, ">> layer.onAdd(context, this controller)")
        layer.onAdd(mapView.context, this)
        CoroutineScope(Dispatchers.Main).launch {
            timeline.updateDataMeld(timeline.state == AnimationState.playing && readyToPlay)
            refreshVisibleLayers()
            redraw()
        }
    }

    internal open fun removeFromMap(source: DataSource) {
    }

    internal open fun removeFromMap(layer: MapLayer<*, *>) {
        layer.visible = false
        particleLayers.remove(layer.id)
        layer.onRemove()
    }

    // ========================================================================================================

    /**
     * Returns whether the map currently contains a data source with the specified identifier.
     *
     * @param id Identifier of the data source to check for.
     * @return True if the map contains the data source, false otherwise.
     */
    fun hasSource(id: String): Boolean {
        return sources[id] != null
    }

    fun hasLayer(id: String): Boolean {
        return layers[id] != null
    }

    fun getSource(id: String): DataSource? {
//        if (sources[id] == null) {
//            return sources.get("source")
//        }
        return sources[id]
    }

    /** Returns the layer associated with the specified identifier if it exists. */
    fun getLayer(id: String): MapLayer<*, *>? {
        return layers[id]
    }

    fun addSource(descriptor: SourceDescriptor): DataSource {
        val id = descriptor.id
        sources[id]?.let { return it }

        val source: DataSource = when (descriptor) {
            is ImageSourceDescriptor -> {
                ImageTileSource(id, id, descriptor.authenticator).apply {
                    tileURL = descriptor.url
                    metadataURL = descriptor.metadataUrl
                    minZoom = descriptor.minZoom ?: 0f
                    maxZoom = descriptor.maxZoom ?: 21f
                    bounds = descriptor.bounds
                    tileSize = descriptor.tileSize ?: TileSize(256)
                }
            }

            is EncodedSourceDescriptor -> {
                val tileSource = sources.getOrPut(id) {
                    XweatherEncodedTileSource(id, descriptor.authenticator).apply {
                        tileURL = descriptor.url
                        metadataURL = descriptor.metadataUrl
                        minZoom = descriptor.minZoom ?: 0f
                        maxZoom = descriptor.maxZoom ?: 21f
                        bounds = descriptor.bounds
                        tileSize = descriptor.tileSize ?: TileSize(512, 512)
                        datasets = descriptor.datasets ?: emptyList()
                    }
                }
                tileSource
            }

            is VectorSourceDescriptor -> {
                if (pr.ON) pr.p("MapController", pr.adminLayers, "addSource() descriptor.id: ${descriptor.id}}")
                val tileSource = sources.getOrPut(id) {
                    VectorTileSource(id, descriptor.authenticator).apply {
                        tileURL = descriptor.url
                        metadataURL = descriptor.metadataUrl
                        minZoom = descriptor.minZoom ?: 0f
                        maxZoom = descriptor.maxZoom ?: 21f
                        bounds = descriptor.bounds
                        tileSize = descriptor.tileSize ?: TileSize(512, 512)
                    }
                }
                tileSource
            }

            is GeoJSONSourceDescriptor -> {
                val dataSource = sources.getOrPut(id) {
                    GeoJSONSource(id).apply {
                        url = descriptor.url
                    }
                }
                dataSource
            }

            else -> throw IllegalArgumentException("Unsupported source descriptor type: ${descriptor::class}")
        }

        source.timeRange = timeline.start..timeline.end
        sources[id] = source

        if (source is VectorTileSource || source is GeoJSONSource) {
            addToMap(source) {
                onSourceAdded.send(source.id)
            }
        } else {
            onSourceAdded.send(source.id)
        }

        return source
    }

    /**
     * Adds a new layer to the map.
     * @param descriptor - The layer descriptor
     * @param id - A unique identifier for the layer.
     * @param config - The configuration options for the layer.
     * @param beforeId - The identifier of an existing map layer to insert the new layer before, which will result in
     * the new layer appearing below the target layer. If not provided, then the new layer will be added to the end of
     * the layer stack and above all other layers.
     * @returns The newly added layer.
     */
    fun <P : LayerPaint> addLayer(
        descriptor: LayerDescriptor<P>,
        beforeID: String?,
    ): TileLayer? {
        val source = getSource(descriptor.source) ?: return null
        //println(">>> MapController addLayer() about to create DataRenderer for ${descriptor.id}")

        val layer: TileLayer? = when {
            source is EncodedTileSource -> {
                when (descriptor) {
                    is SampleLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            EncodedDataRenderer<EncodedData, RenderContext<Any>>(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    is ContourLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            ContourRenderer(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    is ParticleLayerDescriptor -> {
                        EncodedTileLayer(
                            descriptor.id,
                            source as TileSource<TileData>,
                            descriptor.paint,
                            ParticleRenderer(descriptor.id),
                            zoomOffset,
                            viewModelScope,
                            descriptor.quality
                        )
                    }

                    else -> null
                }?.also {
                    (source as XweatherEncodedTileSource).setObserver(metadataObserver, it.id)
                }
            }

            descriptor is RasterLayerDescriptor -> {
                ImageTileSource.setKey(account.id, account.secret)
                TileLayer(
                    descriptor.id,
                    source as TileSource<TileData>,
                    descriptor.paint as RasterLayerPaint,
                    RasterLayerRenderer(),
                    zoomOffset,
                    viewModelScope,
                    descriptor.quality
                )
            }

            descriptor is VectorLayerDescriptor<*> -> {
                VectorTileLayer(
                    descriptor.id,
                    source as TileSource<TileData>,
                    descriptor.paint as VectorLayerPaint,
                    RasterLayerRenderer(),
                    zoomOffset,
                    viewModelScope
                ).apply {
                    sourceLayer = descriptor.sourceLayer
                    filter = descriptor.filter
                }
            }

            else -> null
        }

        if (layer == null) return null

        layer.type = descriptor.type
        layer.animator?.let {
            animatorSync.add(layer)
            timeline.add(it.animation)
            layer.enabled = it.canShowForDate()
        }

        layers[layer.id] = layer
        layer.mapController = this
        if (pr.ON) pr.p("MapController", pr.waaveRenderpath, ">> addLayer() calling: addToMap(layer, beforeId)")
        addToMap(layer, beforeID)

        val sourceConsumer = DataSourceConsumer(layerId = layer.id)
        when (layer) {
            is VectorTileLayer -> {
                sourceConsumer.sourceLayerId = layer.sourceLayer
            }
        }
        layer.source.addConsumer(sourceConsumer)




        onLayerAdded.send(layer.id)
        return layer
    }


    open fun moveLayer(id: String, beforeId: String?) {}

    fun removeSource(id: String) {
        getSource(id)?.let {
            sources.remove(it.id)
            onSourceRemoved.send(it.id)
        }
    }

    fun removeLayer(id: String, isCompounLayer: Boolean = false) {
        getLayer(id)?.let {
            removeFromMap(it)
            layers.remove(it.id)
            it.source.removeConsumer(layerId = it.id)
            onLayerRemoved.send(it.id)
            it.mapController = null

            if (!isCompounLayer) {
                trigger(MapControllerEvents.LAYER_REMOVED, it.id)
            }
        }
    }

    /**
     * Returns the list of layers that are rendered by MapsGL (not layers rendered by Mapbox).
     */
    internal fun getMapsGLRenderedLayers(): List<MapLayer<*, *>> {
        return layers.values.filter { it !is VectorTileLayer }
    }

    internal suspend fun onMoveEnd() {
        camera.moveState = Camera.STOPPED

        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                layer.onMoveEnd()
            }
        }

    }

    internal fun updateTiles(updateCamera: Boolean = false) {
        CoroutineScope(Dispatchers.Main).launch {
            if (updateCamera) {
            } else { //particles use this
                timeline.updateDataMeld(timeline.state == AnimationState.playing && readyToPlay)
                refreshVisibleLayers() //should this be moved outside of else?
            }
            redraw() //This causes render to happen
        }
    }

    internal suspend fun onMove(pauseParticles: Boolean = true, tag: String = "empty") {
        if (pauseParticles) camera.moveState = Camera.MOVING

        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (timeline.state != AnimationState.playing || !pauseParticles || Timeline.pausedForDownload) {
                    layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
                }
            }
        }
    }

    /** Gets visible bounds for visible layers, sets the layers to bind. **/
    private suspend fun refreshVisibleLayers(requestDL: Boolean = true) { //called from updateTiles
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (requestDL) {
                    layer.update() // request download of visible tiles without updating camera
                }
                setLayerHostToUpdate(layer.id)
            }
        }
    }

    /** Sets textures to bind **/
    open fun setLayerHostToUpdate(layerId: String) {}

    /** This functionality needs to be moved to the timeline classes **/
    internal fun startAnimatingTimeline(playPressed: Boolean) {
        if (playPressed) {
            animatingTimeline = true
        } else {
            timeline.seekBarMoved = true
            animatingTimeline = !animatingTimeline
        }

        if (animatingTimeline) {
            startCustomLayerUpdates()
        }
    }

    internal suspend fun preloadVisibleTiles() {
        for (layer in getMapsGLRenderedLayers()) {
            if (layer.visible) {
                if (true) {
                    layer.onMove() // calls:  bounds = mapController?.getBounds()?: return AND requestVisibleTiles(bounds!!)
                }
            }
        }
    }

    internal fun startCustomLayerUpdates(isParticleLayer: Boolean = false) {
        if (!customLayerUpdatesHaveStarted || isParticleLayer) {
            customLayerUpdatesHaveStarted = true

            // This prevents doubling up on animations and also prevents timeline animation states from stopping particles.
            if (isParticleLayer) {
                if (frameCallback != null) {
                    choreographer.removeFrameCallback(frameCallback!!)
                }
                frameCallback = null // Clear the reference
            }

            frameCallback = object : Choreographer.FrameCallback {
                override fun doFrame(frameTimeNanos: Long) {
                    //if(pr.ON) pr.p(TAG, pr.animPart,"startCustomLayerUpdates() isParticleLayer? $isParticleLayer")
                    if (timeline.state == AnimationState.playing || timeline.seekBarMoved || isParticleLayer) {
                        //if(pr.ON) pr.p(TAG, pr.animPart,"startCustomLayerUpdates()  isParticleLayer? $isParticleLayer")
                        updateCustomLayer()
                    }
                    if (timeline.state == AnimationState.paused || timeline.state == AnimationState.loading) {
                    }
                    choreographer.postFrameCallback(this)
                }
            }
            choreographer.postFrameCallback(frameCallback!!)
        }
    }

    private fun updateCustomLayer() {
        if (timeline.state == AnimationState.playing || timeline.seekBarMoved) {
            timeline.seekBarMoved = false
            CoroutineScope(Dispatchers.Main).launch {
                timeline.updateDataMeld(timeline.state == AnimationState.playing && readyToPlay)
                //refreshVisibleLayers() //should this be moved outside of else?
                redraw() //This causes render to happen
            }

        } else if (particleLayers.values.any { it.visible }) {
            CoroutineScope(Dispatchers.Main).launch {
                timeline.updateDataMeld(timeline.state == AnimationState.playing && readyToPlay)
                //refreshVisibleLayers() //should this be moved outside of else?
                redraw() //This causes render to happen
            }
        }
    }

    private fun changeZoomOffset(change: Int) {
        zoomOffset += change
        for (layer in layers) {
            (layer.value as TileLayer).zoomOffset += change
        }
    }

    internal fun setupCamera(initial: Boolean = true) {
        if (pr.ON) pr.p(TAG, pr.rotS, " setupCamera($initial")
        val width = mapView.width.toFloat()
        val height = mapView.height.toFloat()
        densityMult = ((mapView.resources.displayMetrics.density / height) * 800)

        val nz = height * .02f;
        /** from Mapbox https://github.com/mapbox/mapbox-gl-js/blob/main/src/geo/transform.js#L93 **/
        val fov = atan(3f * .25f)
        val pitchAngle = Math.cos((Math.PI * .5) - getPitch())
        val nearZ = Math.max((nz * pitchAngle).toFloat(), nz)
        val farZ = 1e21.toFloat()
        val right = width * .5f
        val left = -right
        val top = height * .5f
        val bottom = -top

        if (type == PERSPECTIVECAMERA) {
            if (initial) {
                camera = Camera(
                    CameraType.Perspective,
                    fov = fov,
                    near = nearZ,
                    far = farZ,
                    bounds = RectF(left, top, right, bottom)
                )
            } else {
                camera.setup(
                    CameraType.Perspective,
                    fov = fov,
                    near = nearZ,
                    far = farZ,
                    bounds = RectF(left, top, right, bottom)
                )
            }

            camera.projectionMatrix = camera.projectionMatrix.perspective(
                Math.toDegrees(fov.toDouble()).toFloat(),
                width / height,
                nearZ,
                farZ
            )
            camera.projectionMatrix.elements[15] = 1200f //fixme: Generate correct value.
        } else { //ORTHOCAMERA
            if (initial) {
                camera = Camera(
                    CameraType.Orthographic,
                    near = nearZ,
                    far = farZ,
                    fov = fov,
                    bounds = RectF(left, top, right, bottom)
                )
            } else {
                camera.setup(
                    CameraType.Orthographic,
                    near = nearZ,
                    far = farZ,
                    fov = fov,
                    bounds = RectF(left, top, right, bottom)
                )
            }
            camera.projectionMatrix = camera.projectionMatrix.orthographic(left, right, top, bottom, nearZ, farZ)
        }
        camera.resX = width.toInt()
        camera.resY = height.toInt()
        camera.aspect = width / height
    }

    private fun onRasterTileEvent(event: RasterTileApiEvent) {
        if (pr.ON) pr.p(TAG, pr.onMove, "onMoveNoMove() onRasterTileEvent ${event}")
        if (pr.ON) pr.p("MapboxMapController", pr.lag, "onRasterTileEvent")
        when (event) {
            is RasterTileApiEvent.Success -> {}
            is RasterTileApiEvent.Error -> DriverManager.println("$TAG event Error")
            is RasterTileApiEvent.Reload -> {
                //updateTiles(false)
                CoroutineScope(Dispatchers.Main).launch {
                    if (pr.ON) pr.p(TAG, pr.onMove, "calling onMoveNoMove() from event")
                    onMoveNoMove(false, tag = "from onRasterTileEvent")
                }
            }
        }
    }

    internal open fun setupEvents() {}

    /**
     * Adds a new weather layer to the map.
     * @param layerCode - An enum of type LayerCode that indicates the desired layer.
     * @returns The newly added map layer
     */
    internal fun checkDownloadStatus(layerID: String, pendingTileNum: Int) {
        val currentLayer = layers[layerID]

        if (currentLayer != null) {
            if (pendingTileNum != 0) {
                if (pr.ON) pr.p(TAG, pr.threadDL, "checkDLStatus() pendingTile: $pendingTileNum")
            }

            val tAnimation = currentLayer.animator!!.animation
            tAnimation.pendingCount = pendingTileNum
            if (pendingTileNum != tAnimation.lastPendingCount) { //change in status
                if (pendingTileNum == 0) {
                    //if(pr.ON) pr.p(TAG, pr.requestTracker,"checkDownloadStatus()  ${currentLayer.id} is done with downloads!")
                } else if (tAnimation.lastPendingCount == 0) {
                    if (pr.ON) pr.p(TAG, pr.threadDL, "checkDLStatus() detected DL start: $pendingTileNum")
                    //if(pr.ON) pr.p(TAG, pr.requestTracker,"checkDownloadStatus()  ${currentLayer.id} is starting to download!")
                    //timeline.setIsDownloading(true)
                    //triggerLoadStart()
                }
            }
            tAnimation.lastPendingCount = tAnimation.pendingCount
        }

        waitingOnDL = false

        for (layer in layers) {
            if (layer.value.visible && layer.value.animator!!.animation.pendingCount != 0) {
                //println("GL1 found PendingDL: ${layer.value.id} has ${layer.value.animator!!.animation.pendingCount}")
                waitingOnDL = true
            }
        }

        if (waitingOnDL) { // if you are waiting on DL and the timeline doesn't know it yet, trigger
            if (!Timeline.isDownloading) {
                Timeline.isDownloading = true
                downloadsStarted()
            }
        } else { // If not waiting on DL, and timeline still thinks it is dl, dl is done.
            if (Timeline.isDownloading) {
                Timeline.isDownloading = false
                downloadsDone()
            }
        }

        if (waitingOnDL != wasWaitingOnDL) { // If you are newly not waiting, make sure to updateTiles() (bind)
            if (pr.ON) pr.p(TAG, pr.blankNonAnim, "checkDownloadStatus()  waitingOnDL: $waitingOnDL")
            if (!waitingOnDL) {
                //updateTiles(false)
                CoroutineScope(Dispatchers.Main).launch {
                    timeline.updateDataMeld(timeline.state == AnimationState.playing && readyToPlay)
                    refreshVisibleLayers() //should this be moved outside of else?
                    redraw() //This causes render to happen
                }
            }
        }

        if (!waitingOnDL) {
            //timeline.setIsDownloading(false)
            //triggerLoadComplete()
            readyToPlay = true
        }

        wasWaitingOnDL = waitingOnDL
    }

    private fun downloadsStarted() {
        if (pr.ON) pr.p(
            TAG,
            pr.threadDL,
            "downloadsStarted() isPlaying: ${timeline.state == AnimationState.playing} --------------------------------"
        )
        if (timeline.state == AnimationState.playing) {
            Timeline.pausedForDownload = true
            timeline.pause()
        }
    }

    private fun downloadsDone() {
        if (pr.ON) pr.p(TAG, pr.autoPlay, "downloadsDone() Timeline.pausedForDownload: $${Timeline.pausedForDownload}")
        if (Timeline.pausedForDownload) {
            Timeline.pausedForDownload = false
            if (pr.ON) pr.p(TAG, pr.autoPlay, "downloadsDone() NOW GOING TO TIMELINE.PLAY() ")
            timeline.play(startImmediately = true)
        }
    }

    /**
     * Uses [com.xweather.mapsgl.weather.common.Presentation.encodedQueryUnit] when a presentation is
     * registered for this layer, else [encodedQueryUnitFallbackForLayerId].
     */
    private fun encodedQueryDisplayUnitForLayer(layer: TileLayer): String? {
        dataInspector.presentationsByLayerId[layer.id]?.encodedQueryUnit?.let { return it }
        return encodedQueryUnitFallbackForLayerId(layer.id)
    }

    /** Get information from Encoded Tile Layers**/
    internal fun query(point: Point, layerList: List<TileLayer>, onTouch: Boolean = true): DataInspectorResult? {
        val zoom = zoomInt + 1
        val zoomVar = (zoom).coerceAtLeast(0)
        val latTile = TileConversions.latToTile(point.latitude(), zoomVar)
        val lonTile = TileConversions.lonToTileNormalized(point.longitude(), zoomVar)
        val latPix = TileConversions.getLatPixelInTile(point.latitude(), zoomVar, 512).toInt()
        val lonPix = TileConversions.getLonPixelInTile(point.longitude(), zoomVar, 512).toInt()
        var i = 0

        if (pr.ON) pr.p(TAG, pr.dIFix, "<< MapController query(): onTouch: $onTouch")

        val result: DataInspectorResult = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        result.clearEncoded()
        var fnVal: String
        for (layer in layerList) {
            val returnVal = layer.queryFeatures(zoomVar, latTile, lonTile, latPix, lonPix)

            if (returnVal != null) {

                val props = encodedQueriedFeatureProperties(returnVal, layer, encodedQueryDisplayUnitForLayer(layer))

                result.queriedFeatures.add(
                    QueriedFeature(
                        null, layer.source.id, null,
                        props,
                        layer.id,
                    )
                )

                val presentation = dataInspector.presentationsByLayerId[layer.id]

                if (presentation != null) {
                    fnVal = presentation.fn(returnVal)
                } else {
                    fnVal = ""
                }
                if (presentation != null) {
                    result.encodedTitles.add(presentation.title.toString())
                    result.encodedLayerIds.add(layer.id)
                }
                result.encodedValues.add(fnVal)
                result.encodedRawValues.add(returnVal)
                i++
            }
        }

        return result
    }


    suspend fun query(
        point: Point,
        layerList: List<String>,
        onTouch: Boolean = false
    ): HashMap<String, FeatureQueryResult> {
        var returnVector: HashMap<String, FeatureQueryResult>? = null

        if (pr.ON) pr.p(TAG, pr.queryNoInsp, "query() entered")

        if (this is MapboxMapController) {
            val vectorLayerList = getVectorLayersById(layerList)
            // Await the result directly, no need for an arbitrary delay
            returnVector = queryFeatures(point, vectorLayerList)
        }

        val result = query(point, getEncodedLayersById(layerList), onTouch)

        if (pr.ON) {
            pr.p("MapController", pr.query11, "<<  query(): encodedLayerIds: ${result?.encodedLayerIds}")
            pr.p("MapController", pr.query11, "<<  query(): encodedRawValues: ${result?.encodedTitles}")
            pr.p("MapController", pr.query11, "<<  query(): encodedRawValues: ${result?.encodedRawValues}")
            pr.p("MapController", pr.query11, "<<  query(): vectorTitles: ${result?.vectorLayerIds}")
            pr.p("MapController", pr.query11, "<<  query(): vectorTitles: ${result?.vectorTitles}")
            pr.p("MapController", pr.query11, "<<  query(): vectorValues: ${result?.vectorValues}|")
        }

        val returnHashMap = hashMapOf<String, FeatureQueryResult>()
        if (result != null) {
            for (item in result.encodedLayerIds) {
                val forLayer =
                    result.queriedFeatures.filter { it.mapLayerId == item }
                returnHashMap[item] = FeatureQueryResult(item, forLayer)
            }

        }

        if (returnVector != null) {
            returnHashMap.putAll(returnVector)
        }
        return returnHashMap

        /*
        return if (result != null) {
            result.toHashMap()
        } else hashMapOf()
        */
    }

    private fun getEncodedLayersById(layerIds: List<String>): List<EncodedTileLayer> {
        return layerIds.mapNotNull { id ->
            layers[id] as? EncodedTileLayer
        }
    }

    private fun getVectorLayersById(layerIds: List<String>): List<VectorTileLayer> {
        return layerIds.mapNotNull { id ->
            layers[id] as? VectorTileLayer
        }
    }

    override fun onMapClick(point: Point): Boolean {
        if (dataInspector.on) {
            dataInspector.showInternal(point)
        }

        return false
    }

    fun trigger(type: String, data: Any? = null) {
        listeners[type]?.let { eventListeners ->
            val listenersToTrigger = ArrayList(eventListeners)
            listenersToTrigger.forEach { listener ->
                try {
                    if (data != null) {
                        listener(data)
                    }

                } catch (e: Exception) {
                    println("Error in event listener for type '$type': ${e.message}")
                }
            }
        }
    }

    override fun on(name: String, callback: (Any) -> Unit) {
        if (!listeners.containsKey(name)) {
            listeners[name] = mutableListOf()
        }
        listeners[name]?.add(callback)
    }

    override fun off(name: String, callback: (Any) -> Unit) {
        listeners[name]?.remove(callback)

    }

    internal class DataInspectorEvent {
        companion object {
            const val VECTOR_UPDATE = "VectorUpdate"
        }
    }

    private val legendControlCancellables = mutableListOf<Cancellable>()

    /**
     * Installs the provided legend control, wiring it to map events and populating initial legends.
     */
    fun add(legendControl: LegendControl?) {
        if (this.legendControl === legendControl) {
            legendControl?.getView()?.isVisible = true
            return
        }

        if (legendControl == null) {
            return
        }

        if (this.legendControl != null) {
            removeLegendControl()
        }

        this.legendControl = legendControl
        legendControl.setup(this.mapView)
        legendControl.getView().isVisible = true
        addLegends(forWeatherLayerCodes = layerIdsByWeatherCode.keys.toList())
        updateLegendsForMap()
    }

    /**
     * Removes the currently installed legend control and clears any associated observers.
     */

    fun removeLegendControl() {
        legendControlCancellables.forEach { it.cancel() }
        legendControlCancellables.clear()

        // 1. Get the view reference before nulling the control
        val viewToRemove = legendControl?.getView()

        // 2. Hide it
        viewToRemove?.isVisible = false

        // 3. CRITICAL: Detach it from whatever parent it currently has (MapView or outerConstraint)
        // (viewToRemove?.parent as? ViewGroup)?.removeView(viewToRemove)

        // 4. Null the reference
        this.legendControl = null
    }

    private fun addLegends(forWeatherLayerCodes: List<LayerCode>) {
        if (pr.ON) pr.p("MapController", pr.legend, "addLegends()")
        val control = legendControl ?: return
        for (layerCode in forWeatherLayerCodes) {
            val config = LayerCode.getConfigurationForLayerCode(layerCode, service) ?: continue

            if (config is CompositeWeatherLayerConfiguration) {
                val compositeLayerCodes = config.layers.map { it.code }
                addLegends(forWeatherLayerCodes = compositeLayerCodes)
                continue
            }

            if (config is WeatherLayerConfiguration<*, *>) {
                if (pr.ON) pr.p("MapController", pr.legend, "addLegends() calling addLegend for ${config.code}")
                addLegend(forConfig = config)
            }
        }
    }

    internal fun updateLegendsForMap() {
        // Launch a coroutine to perform the async update
        CoroutineScope(Dispatchers.Main).launch {
            updateFeatureDrivenPointLegends()
        }
    }

    fun addLegend(forConfig: WeatherLayerConfiguration<*, *>) {
        val legend = forConfig.legend ?: return
        val control = legendControl ?: return

        // For bar legends, update the color scale options to align with the layer's paint configuration
        control.add(legend)
        setupLegendEvents(forConfig)
        control.getLegend(legend.id)?.let { retrievedLegend ->
            val layerDescriptor = forConfig.layer
            if (retrievedLegend is ColorScaleUpdatable && layerDescriptor.paint is SampleLayerPaint) {
                //val updatedLegend = retrievedLegend.apply((layerDescriptor.paint as SampleLayerPaint).sample.colorScale)

                //val colorScaleOptions = (layerDescriptor.paint as SampleLayerPaint).sample.colorScale
                //val colorScaleSpec = ColorScaleSpecification.Single(colorScaleOptions)
                //val updatedLegend = retrievedLegend.apply(colorScaleSpec)
                val updatedLegend = retrievedLegend
                control.update(updatedLegend)
            }
        }
    }

    private suspend fun updateFeatureDrivenPointLegends() {
        val control = legendControl ?: return
        val legends = control.legends.values
        val pointLegends = legends
            .filterIsInstance<PointLegend>()
            .filter { it.layerId != null && it.itemResolver != null }

        for (pointLegend in pointLegends) {
            val layerIdRegex = pointLegend.layerIdRegex ?: continue
            val itemResolver = pointLegend.itemResolver ?: continue

            for (layerCode in layerIdsByWeatherCode.keys) {
                if (layerIdRegex.matches(layerCode.value)) {
                    val vectorLayer = getWeatherLayer(layerCode) as? VectorTileLayer ?: continue
                    val features = vectorLayer.getVisibleFeatures()

                    if (features != null) {
                        val flattenedFeatures: List<QueriedFeature> = features.values.flatMap { it.features }
                        val items = itemResolver.resolveGL(flattenedFeatures)
                        //control.update(pointLegend.items(items))
                        control.update(pointLegend.copy(items = items))
                    }
                }
            }
        }
    }

    /**
     * Sets up event listeners for a weather layer to ensure its legend stays in sync
     * with paint changes and data updates. Only works AFTER the layer has been added to the map.
     */
    private fun setupLegendEvents(config: WeatherLayerConfiguration<*, *>) {
        val layer = config.layer
        layer.on("PAINT_CHANGE") { data ->
            // Cast to our nested class
            val event = data as? LayerEvents.SamplePaintChangeEvent ?: return@on

            if (config.legend is BarLegend<*>) {
                // Check the property name we sent in the trigger
                if (event.property == "sample.colorscale") {
                    syncLegend(config)
                }
            }

            /*
            else if (legend is PointLegend && legend.layerId != null) {
                val sourceId = config.source.id
                // Find the source and listen for data changes to refresh visible features
                getSource(sourceId)?.on("DATA_CHANGE") {
                    updateLegendsForMap()
                }
            }
            */
        }
    }

    /**
     * Helper to trigger a legend sync specifically for a configuration.
     */
    private fun syncLegend(config: WeatherLayerConfiguration<*, *>) {

        val control = legendControl ?: return
        val currentLegend = config.legend ?: return

        // Use the logic that extracts colorScale from SampleLayerPaint
        if (currentLegend is BarLegend<*> && config.layer.paint is SampleLayerPaint) {
            val currentScale = (config.layer.paint as SampleLayerPaint).sample.colorScale

            @Suppress("UNCHECKED_CAST")
            val barLegend = currentLegend as BarLegend<Dimension>
            val updatedLegend = barLegend.copy(
                items = barLegend.items.map { it.copy(colorScaleOptions = currentScale) }
            )

            // Update the control UI
            control.update(updatedLegend)
        }
    }

    override fun onDestroy(owner: LifecycleOwner) {
        downloadTrackingHandler.removeCallbacks(downloadTrackingRunnable)
        super.onDestroy(owner)
    }
}