package com.xweather.mapsgl

/**
 * An interface that describes an object that performs server authentication using a session token or
 * other means.
 *
 * @template Token The type of the authentication token.
 */
interface Authenticator<AccessToken> { //Maybe AccessToken should be Token
    val credentials: AccessToken //Maybe AccessToken should be Token
    val headers: Map<String, String>

    /**
     * Makes the necessary authentication request, such as requesting an access token, and returns
     * the authentication headers to include in data requests.
     */
    suspend fun authenticate(): Map<String, String>
}

/**
 * A type-erased [Authenticator] that can be used to represent any type of authenticator.
 */
typealias AnyAuthenticator = Authenticator<*>
