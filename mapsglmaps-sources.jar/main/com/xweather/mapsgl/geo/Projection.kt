package com.xweather.mapsgl.geo

import com.xweather.mapsgl.types.Coordinate

data class PlotCoordinate(var x: Double, var y: Double, val z:Double)

/**
 * A `Projection` is responsible for projecting geographical coordinates to plot coordinates and vice versa.
 */
interface Projection {
    /**
     * Projects a geographical coordinate to a plot coordinate.
     *
     * @param coord The geographical coordinate to project.
     * @param altitude The altitude of the coordinate in meters.
     */
    fun project(coord: Coordinate, altitude: Double = 0.0): PlotCoordinate

    /**
     * Projects a geographical coordinate to a plot coordinate.
     *
     * @param point The plot coordinate to unproject.
     */
    fun unproject(point: PlotCoordinate): Coordinate

    /**
     * Returns the number of pixels per meter at a given latitude.
     *
     * @param lat The latitude to calculate the number of pixels per meter at.
     * @param worldSize The size of the world in pixels.
     */
    fun pixelsPerMeter(lat: Double, worldSize: Double): Double
}