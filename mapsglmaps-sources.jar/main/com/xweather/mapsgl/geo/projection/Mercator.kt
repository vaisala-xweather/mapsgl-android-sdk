package com.xweather.mapsgl.geo.projection

import com.xweather.mapsgl.geo.Geo.EARTH_CIRCUMFERENCE
import com.xweather.mapsgl.geo.Geo.MAX_MERCATOR_LATITUDE
import com.xweather.mapsgl.geo.Geo.coordToUnit
import com.xweather.mapsgl.geo.PlotCoordinate
import com.xweather.mapsgl.geo.Projection
import com.xweather.mapsgl.gl.math.Vector3
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.types.Coordinate
import com.xweather.mapsgl.types.ElevationScale
import com.xweather.mapsgl.utils.clamp
import kotlin.math.atan
import kotlin.math.exp

class Mercator : Projection {
    fun circumferenceAtLatitude(lat: Double) = EARTH_CIRCUMFERENCE * Math.cos(lat * Math.PI / 180);

    /**
     * Determine the Mercator scale factor for a given latitude.
     * At the equator the scale factor will be 1, which increases at higher latitudes.
     * https://en.wikipedia.org/wiki/Mercator_projection#Scale_factor
     *
     * @param lat
     * @returns
     */
    fun mercatorScale(lat: Double) = 1 / Math.cos(lat * Math.PI / 180);

    fun altitudeFromMercatorZ(z: Double, y: Double): Double {
        return z * circumferenceAtLatitude(mercatorYToLat(y))
    }

    override fun project(coord: Coordinate, altitude: Double): PlotCoordinate {
        coord.lat = clamp(coord.lat, -MAX_MERCATOR_LATITUDE, MAX_MERCATOR_LATITUDE)
        val t = coordToUnit(coord)

        val z = mercatorZfromAltitude(this, altitude, coord.lat)
        return PlotCoordinate(t.x.toDouble(), t.y.toDouble(), z)// TODO: eliminate cast to optimize
    }

    override fun unproject(point: PlotCoordinate): Coordinate {
        val (x, y) = point
        return Coordinate(x, y)
    }

    fun projectTilePoint(x: Double, y: Double): PlotCoordinate {
        return PlotCoordinate(x, y, 0.0)
    }

    override fun pixelsPerMeter(lat: Double, worldSize: Double): Double {
        return mercatorZfromAltitude(this, 1.0, lat) * worldSize
    }

    fun upVector(coord: TileCoord): Vector3 {
        return Vector3(0f, 0f, 1f)
    }

    fun upVectorScale(coord: TileCoord, lat: Double, worldSize: Double): ElevationScale {
        return ElevationScale(1f, 1f)
    }

    companion object {
        fun mercatorZfromAltitude(mercator: Mercator, altitude: Double, lat: Double): Double {
            return altitude / mercator.circumferenceAtLatitude(lat)
        }

        fun latToMercatorY(lat: Double) =
            ((180 - (180 / Math.PI * Math.log(Math.tan(Math.PI / 4 + lat * Math.PI / 360)))) / 360)

        fun lonToMercatorX(lon: Double) = (180 + lon) / 360;

        fun mercatorXToLon(x: Double) = x * 360 - 180;

        fun mercatorYToLat(y: Double): Double {
            val y2 = 180 - y * 360;
            return 360 / Math.PI * atan(exp(y2 * Math.PI / 180)) - 90;
        }
    }
}