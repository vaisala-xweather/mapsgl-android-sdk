package com.xweather.mapsgl
@Suppress("Dokka")
class NativeLibCache(val sourceID: String) {


    // --- Byte Array Cache ---

    /**
     * Stores a copy of the byte array in the native cache under the given key.
     * Replaces any existing data for the same key.
     * @param key The String key to store the data under.
     * @param byteArray The ByteArray data to store.
     */
    external fun putData(key: String, byteArray: ByteArray)

    /**
     * Retrieves a copy of the byte array from the native cache for the given key.
     * @param key The String key to look up.
     * @return The ByteArray data if found, otherwise null.
     */
    external fun getData(key: String): ByteArray?

    external fun getAllCachedKeys(): List<String>? // Or ArrayList<String>?


    /**
     * Checks if the native cache contains an entry for the given key.
     * @param key The String key to check.
     * @return True if the key exists in the cache, false otherwise.
     */
    external fun containsKey(key: String): Boolean

    /**
     * Removes the entry associated with the given key from the native cache.
     * Does nothing if the key is not found.
     * @param key The String key of the entry to remove.
     */
    external fun removeData(key: String)

    /**
     * Removes all entries from the native cache.
     */
    external fun clearCache()

    /**
     * Gets the current number of key-value pairs stored in the native cache.
     * @return The number of items in the cache as a Long.
     */
    external fun getCacheSize(): Long

    // --- Test/Simple Integer Cache ---

    /**
     * Stores a single integer value in the native cache (for testing).
     * @param input The Int value to store.
     */
    external fun putInt(input: Int) // Keep only this one

    /**
     * Retrieves the single integer value stored in the native cache (for testing).
     * @return The stored Int value.
     */
    external fun getInt(): Int

    // --- Companion Object for Loading ---
    companion object {
        // Used to load the 'nativelib' library on application startup.
        init {
            try {
                System.loadLibrary("nativelib") // Use your actual library name here
            } catch (e: UnsatisfiedLinkError) {
                // Log error or handle cases where native lib might not be available
                // (e.g., running on an unsupported ABI)
                System.err.println("Failed to load native library 'nativelib': ${e.message}")
                // Consider throwing an exception or setting a flag
            }
        }
    }
}