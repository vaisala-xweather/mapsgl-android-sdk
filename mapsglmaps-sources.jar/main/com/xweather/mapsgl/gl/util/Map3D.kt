package com.xweather.mapsgl.gl.util

/**
 * Map3D.kt
 *
 *  Used in RenderPass classes to store strings for hashmaps
 *  so that we don't need to create 1-10 new strings every frame
 *  Has not been tested for performance.
 *
 * @author Jason Suto 08/01/24
 *
 */

class Map3D<K, V> {
    private var tempString : String? = null
    private val map: MutableMap<K, MutableMap<K, MutableMap<K, V>>> = mutableMapOf()

    fun put(x: K, y: K, z: K, value: V) {
        if (!map.containsKey(x)) {
            map[x] = mutableMapOf()
        }
        if (!map[x]!!.containsKey(y)) {
            map[x]!![y] = mutableMapOf()
        }
        map[x]!![y]!![z] = value
    }

    fun get(x: K, y: K, z: K): V? {
        return map[x]?.get(y)?.get(z)
    }

    fun remove(x: K, y: K, z: K) {
        map[x]?.get(y)?.remove(z)
        if (map[x]?.get(y)?.isEmpty() == true) {
            map[x]?.remove(y)
        }
        if (map[x]?.isEmpty() == true) {
            map.remove(x)
        }
    }

    fun exists(x: K, y: K, z: K): Boolean {
        return map[x]?.get(y)?.containsKey(z) == true
    }

    fun display() {
        for ((x, yMap) in map) {
            for ((y, zMap) in yMap) {
                for ((z, value) in zMap) {
                    println("[$x, $y, $z] = $value")
                }
            }
        }
    }
}