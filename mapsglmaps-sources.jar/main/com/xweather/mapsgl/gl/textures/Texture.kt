package com.xweather.mapsgl.gl.textures

import android.content.Context
import android.opengl.GLES31
import com.xweather.mapsgl.gl.Resource
import com.xweather.mapsgl.gl.ResourceOptions
import com.xweather.mapsgl.types.Size
import java.nio.IntBuffer


/**
 * Data that can be used to create a texture.
 */
typealias TexImage2DData = Any? // Replace with appropriate type if needed

/**
 * Base texture options.
 * @internal
 */
open class BaseTextureOpts(
    var type: Int? = null,
    val target: Int? = null,
    var size: Size? = null,
    var format: Int? = null,
    var internalFormat: Int? = null,
    var wrapS: Int? = null,
    var wrapT: Int? = null,
    var minFilter: Int? = null,
    var magFilter: Int? = null,
    var premultiplyAlpha: Boolean? = null,
    var unpackAlignment: Int? = null
)

/**
 * Texture options.
 * @internal
 */
data class TextureOpts(
    var image: TexImage2DData? = null,
    var generateMipmaps: Boolean? = null,
    var flipY: Boolean? = null,
    var anisotropy: Int? = null,
    var level: Int? = null,
    var data: Any? = null
) : ResourceOptions, BaseTextureOpts() {
    override val name: String
        get() = TODO("Not yet implemented")
}

/**
 * Texture state.
 * @internal
 */
data class TextureState(
    var image: TexImage2DData,
    var wrapS: Int,
    var wrapT: Int,
    var minFilter: Int,
    var magFilter: Int,
    var premultiplyAlpha: Boolean,
    var unpackAlignment: Int,
    var flipY: Boolean,
    var anisotropy: Int,
    var version: Int
)

fun getTextureDefaults(gl: Context, opts: TextureOpts?): TextureOpts {
    val texOps = TextureOpts(
        generateMipmaps = true,
        flipY = false,
        anisotropy = 0,
        level = 0
    )
    with(texOps) {
        type = GLES31.GL_UNSIGNED_BYTE
        format = GLES31.GL_RGBA
        internalFormat = opts?.format ?: GLES31.GL_RGBA
        wrapS = GLES31.GL_CLAMP_TO_EDGE
        wrapT = GLES31.GL_CLAMP_TO_EDGE
        generateMipmaps = true
        minFilter = if (opts?.generateMipmaps == true) GLES31.GL_LINEAR_MIPMAP_LINEAR else GLES31.GL_LINEAR
        magFilter = GLES31.GL_LINEAR
        premultiplyAlpha = false
        unpackAlignment = 4
        flipY = false
        anisotropy = 0
        level = 0
    }

    return texOps
}

/**
 * Manages a WebGL texture.
 * @internal
 */


open class Texture(context: Context, opts: TextureOpts? = null) :
    Resource()/*(<Texture, TextureOpts>(context, getTextureDefaults(context.gl, opts)).apply { opts?.let { this@apply = it } }), Bindable*/ {


    var intBuffer: IntBuffer = IntBuffer.allocate(1)

    /**
     * An image object.
     */
    var image: TexImage2DData? = opts?.image

    /**
     * Size of the texture.
     */
    var size = Size(0, 0)

    /**
     * Corresponds to the `format`. Default value is `gl.UNSIGNED_BYTE`.
     */
    var type: Int = opts?.type ?: 0

    /**
     * Render format, which defaults to `gl.RGBA`.
     */
    var format: Int = opts?.format ?: 0

    /**
     * Specifies how the data will be stored on the GPU.
     */
    var internalFormat: Int = opts?.internalFormat ?: 0

    /**
     * Defines how the texture is wrapped horizontally and corresponds to U in UV mapping. Default
     * value is `gl.CLAMP_TO_EDGE`.
     */
    var wrapS: Int = opts?.wrapS ?: 0

    /**
     * Defines how the texture is wrapped vertically and corresponds to V in UV mapping. Default
     * value is `gl.CLAMP_TO_EDGE`.
     */
    var wrapT: Int = opts?.wrapT ?: 0

    /**
     * Defines how the texture is sampled when a texel covers less than one pixel. Default value is
     * `gl.LINEAR_MIPMAP_LINEAR`.
     */
    var minFilter: Int = opts?.minFilter ?: 0

    /**
     * Defines how the texture is sampled when a texel covers more than one pixel. Default value is
     * `gl.LINEAR`.
     */
    var magFilter: Int = opts?.magFilter ?: 0

    /**
     * If `true`, the alpha channel is multiplied into the color channels. Default value is
     * `false`.
     */
    var premultiplyAlpha: Boolean = opts?.premultiplyAlpha ?: false

    /**
     * Unpacking of pixel data from memory. Default is `4`. Possible values are `1`, `2`, `4`, or `8`.
     */
    var unpackAlignment: Int = opts?.unpackAlignment ?: 0

    /**
     * If `true`, the texture is flipped along the vertical axis. Default value is `true`.
     */
    var flipY: Boolean = opts?.flipY ?: false

    var anisotropy: Int = opts?.anisotropy ?: 0

    /**
     * Whether to generate mipmaps (if possible) for a texture. Default value is `true`.
     */
    var generateMipmaps: Boolean = opts?.generateMipmaps ?: true

    /**
     * Set this to `true` to trigger an update the next time the texture is used.
     */
    open var needsUpdate: Boolean = false

    /**
     * A callback function that is called when the texture is updated.
     */
    var onUpdate: (() -> Unit)? = null

    /**
     * Counts how many times the texture has been updated.
     */
    val version: Int
        get() = _state.version

    var textureUnit: Int = 0
    private var _state: TextureState = TextureState(
        image = image,
        wrapS = wrapS,
        wrapT = wrapT,
        minFilter = minFilter,
        magFilter = magFilter,
        premultiplyAlpha = premultiplyAlpha,
        unpackAlignment = unpackAlignment,
        flipY = flipY,
        anisotropy = anisotropy,
        version = -1
    )

    protected fun deleteHandle() {
        handle?.let {
            GLES31.glDeleteTextures(it, intBuffer)
            //gl.deleteTexture(it)
            decrementResourceCount()
        }
        _handle = 0 // -1?
    }

    fun dispose() {
        //unbind()
        deleteHandle()
        image = null
        _state.image = null

    }

    override fun toString(): String {
        return "${this::class.simpleName}:$id - size: ${size.width}x${size.height}"
    }

    fun isPowerOfTwo(value: Int): Boolean = (value > 0) && (Math.log(value.toDouble()) / Math.log(2.0) % 1 == 0.0)

}