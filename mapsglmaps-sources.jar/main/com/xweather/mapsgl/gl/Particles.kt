package com.xweather.mapsgl.gl

import com.xweather.mapsgl.gl.worldObjects.Mesh
import java.nio.ByteBuffer
import java.nio.ByteOrder

class Particles(numParticles: Int) {

    /** Checks if a `Mesh` element conforms to the given `GeometryVertexElementLayout`. */
    private fun meshesElementConforms(element: Mesh /*geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
        //return element.geometry.vertexElementLayout == geometryVertexElementLayout
        return true
    }

    /** Checks if all `Mesh` elements conform to the given `GeometryVertexElementLayout`.  */
    private fun meshesElementsConform(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
        //return elements.all { meshesElementConforms(it, geometryVertexElementLayout) }
        return true
    }

    /** Filters out `Mesh` elements that do not conform to the given `GeometryVertexElementLayout`. */
    private fun conformingMeshesElements(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): List<Mesh>? {
        //return elements.filter { meshesElementConforms(it, geometryVertexElementLayout) }
        return null
    }

    private var isInitialized = false
    val particles = Array(numParticles) { Particle() }

    private val numVerts = 2
    private val numFloats = particles.size * numVerts
    private val fArray = FloatArray(numFloats)
    val particleVertexBuffer =
        ByteBuffer.allocateDirect(numFloats * 4).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }

    var time = 0f
    var numSteps = 0

    private val TAG = "RenderPass"
    private val BYTES_PER_FLOAT = 4
    private val COORDS_PER_VERTEX = 2
    private val NUM_TILES = 1
    private val VERTEX_COUNT = NUM_TILES * 4

    private val vertexArray = UnitQuad2DGeometry.genQuad1x1()
    val vertexBuffer =
        ByteBuffer.allocateDirect(VERTEX_COUNT * COORDS_PER_VERTEX * BYTES_PER_FLOAT).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }
    private val textureArray = UnitQuad2DGeometry.genTexCoords1Quad()
    private val textureCoordinatesBuffer = ByteBuffer.allocateDirect(textureArray.size * 4).run {
        order(ByteOrder.nativeOrder())
        asFloatBuffer()
    }

    init {
        vertexBuffer.apply {
            clear()
            put(vertexArray)
            rewind()
        }

        textureCoordinatesBuffer.apply {
            clear()
            put(textureArray)
            rewind()
            // position(0)
        }

        if (!isInitialized) {
            isInitialized = true
            var i = 0
            for (particle in particles) {
                //println("particle x:${particle.x}  y:${particle.y}")
                fArray[i] = particle.x; fArray[i + 1] = particle.y;
                i += numVerts
            }
            particleVertexBuffer.apply {
                clear()
                put(fArray)
                rewind()
            }
            particles
        }
    }
}