package com.xweather.mapsgl.gl.geometries

import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import com.xweather.mapsgl.gl.worldObjects.DrawMode
import com.xweather.mapsgl.gl.math.Vector3
import java.nio.FloatBuffer

class SphereGeometry(
    override val id: Int,
    override var map: HashMap<AttributeKey, IBufferAttribute<*>>,
    override val drawMode: DrawMode? = DrawMode.Triangles,
    override val drawRange: DrawRange? = null,
    override val instanced: Instanced? = null
) :
    AbstractGeometry(/*id, map, drawMode, drawRange, instanced*/),
    Geometry {
    /**
     * Sphere radius. Default value is `1`.
     *
     * @type {number}
     * @memberof SphereGeometryOpts
     */
    var radius: Float

    /**
     * Horizontal starting angle. Default value is `0`.
     *
     * @type {number}
     * @memberof SphereGeometryOpts
     */
    var phiStart: Float

    /**
     * Horizontal sweep angle size. Default value is `Math.PI`.
     *
     * @type {number}
     * @memberof SphereGeometryOpts
     */
    var phiLength: Float

    /**
     * Vertical starting angle. Default value is `0`.
     *
     * @type {number}
     * @memberof SphereGeometryOpts
     */
    var thetaStart: Float

    /**
     * Vertical sweep angle size. Default is `Math.PI`.
     *
     * @type {number}
     * @memberof SphereGeometryOpts
     */
    var thetaLength: Float

    /**
     * Number of horizontal segments. Default value is `1`.
     *
     * @type {number}
     * @memberof PlaneGeometryOps
     */
    var widthSegments: Int = 0

    /**
     * Number of vertical segments. Default value is `1`.
     *
     * @type {number}
     * @memberof PlaneGeometryOps
     */
    var heightSegments: Int = 0

    init {
        var vertices = ArrayList<Float>()
        var normals = ArrayList<Float>()
        var uvs = ArrayList<Float>()
        var indices = ArrayList<Short>()
        var colors = ArrayList<Float>()

        radius = 0.5f
        widthSegments = 16
        heightSegments = Math.ceil(widthSegments * 0.5).toInt()
        phiStart = 0f
        phiLength = (Math.PI * 2).toFloat()
        thetaStart = 0f
        thetaLength = Math.PI.toFloat()

        val wSegs = widthSegments
        val hSegs = heightSegments
        val pStart: Double = phiStart.toDouble()
        val pLength = phiLength
        val tStart: Double = thetaStart.toDouble()
        val tLength = thetaLength
        val tEnd = tStart + tLength

        val grid = ArrayList<ArrayList<Int>>()
        val tmpVec3 = Vector3()

        var i = 0
        var ii = 0
        var iv = 0

        // generate vertices, normals and uvs
        for (iy in 0..hSegs) {
            val vRow = ArrayList<Int>()
            val v = iy.toFloat() / hSegs.toFloat()

            for (ix in 0..wSegs + 1) {
                val u = ix.toFloat() / wSegs.toFloat()
                val x = -radius * Math.cos(pStart + u * pLength) * Math.sin(tStart + v * tLength)
                val y = radius * Math.cos(tStart + v * tLength)
                val z = radius * Math.sin(pStart + u * pLength) * Math.sin(tStart + v * tLength)

                vertices.add(x.toFloat())
                vertices.add(y.toFloat())
                vertices.add(z.toFloat())

                colors.add(x.toFloat())
                colors.add(y.toFloat())
                colors.add(z.toFloat())
                colors.add(1.0f)

                tmpVec3.set(x, y, z).normalize()
                normals.add(tmpVec3.x)
                normals.add(tmpVec3.y)
                normals.add(tmpVec3.z)

                uvs.add(u)
                uvs.add(1f - v)

                iv += 1
                vRow.add(iv)
            }
            grid.add(vRow)
        }

        // indices
        for (iy in 0 until hSegs) {
            for (ix in 0 until wSegs) {

                val a = grid[iy][ix + 1]
                val b = grid[iy][ix]
                val c = grid[iy + 1][ix]
                val d = grid[iy + 1][ix + 1]

                if (iy != 0 || tStart > 0) {
                    indices.add(a.toShort())
                    indices.add(b.toShort())
                    indices.add(d.toShort())
                    ii += 1
                }

                if (iy != hSegs - 1 || tEnd < Math.PI) {
                    indices.add(b.toShort())
                    indices.add(c.toShort())
                    indices.add(d.toShort())
                    ii += 1
                }
            }
        }

        setVertices(vertices.toFloatArray())
        setUVs(uvs.toFloatArray())
        setNormals(normals.toFloatArray())
        setIndices(indices.toShortArray())
        setColor(colors.toFloatArray())
    }

    override val geometryBuffer: FloatBuffer
        get() = TODO("Not yet implemented")
    override val bounds = GeometryBounds()
}