package com.xweather.mapsgl.gl.geometries

import com.xweather.mapsgl.gl.math.Vector3
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import com.xweather.mapsgl.gl.worldObjects.DrawMode
import java.nio.FloatBuffer

// GeometryProvider Protocol equivalent in Kotlin
interface GeometryProvider {
    val vertexCount: Int
    val vertexBuffer: java.nio.ByteBuffer?
}

data class DrawRange(var start: Int = 0, var count: Int = 0)
data class Instanced(var isInstanced: Boolean, var count: Int = 0)
data class GeometryBounds(val test: Int = 1) {
    val min: Vector3 = Vector3()
    val max = Vector3()
    val center = Vector3()
    val scale = Vector3(1f, 1f, 1f)
    val radius = 1f
}

interface Geometry {
    val id: Int
    var map: HashMap<AttributeKey, IBufferAttribute<*>>
    val drawMode: DrawMode?
    val drawRange: DrawRange?
    val instanced: Instanced?
    val geometryBuffer: FloatBuffer
    val bounds: GeometryBounds

    // protected variables
    var nextAttributeId: Int
    fun addAttribute(key: AttributeKey, attr: IBufferAttribute<*>)
    fun getAttribute(key: AttributeKey): IBufferAttribute<*>?
    fun removeAttribute(key: AttributeKey)

    fun setVertices(vertices: FloatArray)
    fun setNormals(normals: FloatArray)
    fun setIndices(indices: ShortArray)
    fun setColor(colors: FloatArray)
    fun setUVs(uvs: FloatArray)
}

