package com.xweather.mapsgl.gl.worldObjects.cameras

import android.graphics.RectF
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.math.Vector3

interface ICamera {
    var type: CameraType
    var near: Float
    var far: Float
    var fov: Float
    var aspect: Float
    var bounds: RectF
    var zoom: Double

    // camera view of the world (ortho/perceptive)
    var projectionMatrix: ProjectionMatrix

    // camera's position
    var viewMatrix: Matrix4

    // camera's position ?
    var worldPosition: Vector3

    fun perspective(fov: Float, aspect: Float, near: Float, far: Float)
    fun orthographic(
        left: Float,
        right: Float,
        top: Float,
        bottom: Float,
        near: Float,
        far: Float,
        zoom: Float
    )

    fun lookAt(target: Vector3): Camera
    fun updateMatrixWorld(): Camera

    fun getViewMatrix(): FloatArray
}

enum class CameraType {
    Orthographic,
    Perspective
}

interface ViewBounds {
    var left: Float
    var right: Float
    var top: Float
    var bottom: Float
}

interface Frustum {
    var left: Float
    var right: Float
    var top: Float
    var bottom: Float
    var near: Float
    var far: Float
}