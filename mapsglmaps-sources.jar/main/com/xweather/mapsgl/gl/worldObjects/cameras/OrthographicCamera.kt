package com.xweather.mapsgl.gl.worldObjects.cameras

import android.graphics.RectF

class OrthographicCamera(
    override var type: CameraType = CameraType.Orthographic,
    override var near: Float,
    override var far: Float,
    override var fov: Float,
    override var aspect: Float,
    override var bounds: RectF,
    override var zoom: Double
) : Camera(type, near, far, fov, aspect, bounds, zoom) {

    /*
     * TODO verify correctness
     */
    constructor(
        left: Float,
        right: Float,
        top: Float,
        bottom: Float,
        near: Float,
        far: Float,
        zoom: Int? = 1
    ) : this(
        CameraType.Orthographic,
        1f,
        1000f,
        45f,
        1f,
        RectF(left, top, right, bottom),
        1.0
    ) {

    }

    fun updateProjectionMatrix() {
        this.projectionMatrix.orthographic(
            bounds.left / zoom.toFloat(),
            bounds.right / zoom.toFloat(),
            bounds.top / zoom.toFloat(),
            bounds.bottom / zoom.toFloat(),
            this.near, this.far
        );
    }
}

