package com.xweather.mapsgl.gl.worldObjects

import com.xweather.mapsgl.gl.math.Euler
import com.xweather.mapsgl.gl.math.QuaternionTC
import com.xweather.mapsgl.gl.math.Vector3

abstract class AbstractObject3D : IObject3D {

    override var visible = true

    override var localMatrix = com.xweather.mapsgl.gl.math.ProjectionMatrix()
    override var worldMatrix = com.xweather.mapsgl.gl.math.ProjectionMatrix()
    override var matrixAutoUpdate = true

    private var parent: AbstractObject3D? = null
    private var children = ArrayList<AbstractObject3D>()
    private var _worldMatrixNeedsUpdate = false

    /** The object's local position. Default is `(0, 0, 0)`. */
    override var position = Vector3()

    // /** The object's local scale. Default is `(1, 1, 1)`. */
    override var scale = Vector3(1f, 1f, 1f)

    // /** The object's local rotation, in radians. */
    override var rotation = Euler()

    // /** The object's local rotation as a quaternion. */
    override var quaternion = QuaternionTC()

    /**
     * Used by the `lookAt` method, for example, to determin the orientation of the result.
     * Default is `(0, 1, 0)`, which is up.
     */
    override var up = Vector3(0f, 1f, 0f)

    override fun lookAt(target: Vector3, invert: Boolean) {
        if (invert) {
            this.localMatrix.lookAt(this.position, target, this.up)
        } else {
            this.localMatrix.lookAt(target, this.position, this.up)
        }

        this.quaternion = this.localMatrix.getRotation()
        this.rotation.fromQuaternion(this.quaternion)
    }

    override fun updateMatrixWorld(force: Boolean) {
        if (this.matrixAutoUpdate) {
            this.updateMatrix()
        }

        var isForced = force
        if (this._worldMatrixNeedsUpdate || force) {

            this.parent?.let {
                this.worldMatrix.multiply(it.worldMatrix, this.localMatrix)

            } ?: this.worldMatrix.copy(this.localMatrix)

            this._worldMatrixNeedsUpdate = false
            isForced = true
        }

        for (i in 0 until children.size) {
            this.children[i].updateMatrixWorld(isForced)
        }
    }

    override fun updateMatrix() {
        this.localMatrix.compose(this.position, this.quaternion, this.scale)
        this._worldMatrixNeedsUpdate = true
    }
}
