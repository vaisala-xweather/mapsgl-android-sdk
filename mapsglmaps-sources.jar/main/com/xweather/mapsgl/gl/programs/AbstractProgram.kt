package com.xweather.mapsgl.gl.programs

import android.opengl.GLES31
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import com.xweather.mapsgl.gl.worldObjects.AbstractObject3D
import com.xweather.mapsgl.gl.worldObjects.IMesh
import com.xweather.mapsgl.gl.worldObjects.cameras.ICamera
import java.nio.ByteBuffer
import java.nio.FloatBuffer
import java.nio.ShortBuffer

abstract class AbstractProgram(vertexShader: Int?, fragmentShader: Int?, compShader: Int?) :
    Program(vertexShader, fragmentShader, compShader) {
    override var handle: Int? = null
    final override var fragmentShader: Int? = null


    fun createHandle() {
        handle = GLES31.glCreateProgram();
        if (handle == 0) {
            throw java.lang.Exception("Failed create program")
        }
    }

    fun deleteHandle() {
        handle?.apply {
            GLES31.glDeleteProgram(this)
            handle = null
        }
    }

    open fun bind(): Boolean {
        handle?.apply {
            GLES31.glUseProgram(this)
            return true
        }
        return false
    }

    open fun unbind() {
        GLES31.glUseProgram(0)
    }

    open fun dispose() {
        unbind()
        deleteHandle()

        vertexShader?.let { GLES31.glDeleteShader(it) }
        vertexShader = null
        fragmentShader?.let { GLES31.glDeleteShader(it) }
        fragmentShader = null
        computeShader?.let { GLES31.glDeleteShader(it) }
        computeShader = null

    }

    override fun setupModelViewProjectMatrix(camera: ICamera, mesh: IMesh) {
        handle?.let { hd ->
            // mesh is our target - origin for now
            camera.lookAt((mesh as AbstractObject3D).position)
            /*
             * TODO simplify camera.getViewMatrix() from animation computation
             */
            val viewMatrixHandle = GLES31.glGetUniformLocation(hd, "CameraViewMatrix")
            GLES31.glUniformMatrix4fv(viewMatrixHandle, 1, false, camera.getViewMatrix(), 0)

            val projectMatrixHandle = GLES31.glGetUniformLocation(hd, "CameraProjectionMatrix")
            GLES31.glUniformMatrix4fv(
                projectMatrixHandle,
                1,
                false,
                camera.projectionMatrix.elements.toFloatArray(),
                0
            )

            val modelMatrixHandle = GLES31.glGetUniformLocation(hd, "ModelMatrix")
            GLES31.glUniformMatrix4fv(
                modelMatrixHandle,
                1,
                false,
                mesh.modelMatrix.elements.toFloatArray(),
                0
            )
        }
    }

    override fun setupShaderInputs(
        map: HashMap<AttributeKey, IBufferAttribute<*>>,
        iResolution: IntArray,
        iChannels: IntArray,
        iChannelResolutions: Array<IntArray>
    ) {
        bind()
        handle?.let { hd ->
            for (key in map.keys) {
                map[key]?.let {
                    val attrHandle = GLES31.glGetAttribLocation(hd, key.toString())
                    GLES31.glEnableVertexAttribArray(attrHandle)
                    GLES31.glVertexAttribPointer(
                        attrHandle,
                        it.stride,
                        it.glType,
                        it.normalized!!,
                        it.stride * it.typeByteWidth,
                        /*
                         * TODO Simply ?
                         */
                        when (key) {
                            AttributeKey.Normal,
                            AttributeKey.Color,
                            AttributeKey.UV,
                            AttributeKey.Position -> it.data as FloatBuffer

                            AttributeKey.Index -> it.data as ShortBuffer
                            else -> it.data as ByteBuffer
                        }
                    )
                }
            }
        }
    }
}