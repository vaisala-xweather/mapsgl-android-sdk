package com.xweather.mapsgl.gl.math

import kotlin.math.abs

class Vector2(var x: Float, var y: Float) : IVector {

    override fun fromArray(array: FloatArray, offset: Int): IVector {
        this.x = array[offset]
        this.y = array[offset + 1]
        return this
    }

    override fun toArray(array: FloatArray, offset: Int): FloatArray {
        array[offset] = this.x
        array[offset + 1] = this.y
        return array
    }

    override fun length(): Float = abs(x - y)

    fun angle(): Float {
        // mag is the product of the magnitudes of a and b
        val v2 = Vector2(1f, 0f)
        val mag =
            Math.sqrt((x * x + y * y).toDouble()) * Math.sqrt((v2.x * v2.x + v2.y * v2.y).toDouble())
        // mag &&.. short circuits if mag == 0
        val cosine = if (mag != 0.0) {
            (x * v2.x + y * v2.y) / mag
        } else {
            1
        }
        val n = Math.max(cosine.toFloat(), -1f)
        val min = Math.min(n, 1f).toDouble()
        return Math.acos(min).toFloat()
    }

    override fun copy(v2: IVector): Vector2 {
        (v2 as Vector2).let {
            this.x = v2.x
            this.y = v2.y
            return this
        }
    }

    override fun clone() = Vector2(x, y)
    override fun add(v2: IVector): Vector2 {
        (v2 as Vector2).let {
            this.x += v2.x
            this.y += v2.y
            return this
        }
    }

    override fun addScalar(s: Float): Vector2 {
        this.x += s
        this.y += s
        return this
    }

    override fun subtract(v2: IVector): Vector2 {
        (v2 as Vector2).let {
            this.x -= v2.x
            this.y -= v2.y
            return this
        }
    }

    override fun subtractScalar(s: Float): Vector2 {
        this.x -= s
        this.y -= s
        return this
    }

    override fun multiply(v2: IVector): Vector2 {
        (v2 as Vector2).let {
            this.x *= v2.x
            this.y *= v2.y
            return this
        }
    }

    override fun multiplyScalar(s: Float): Vector2 {
        this.x *= s
        this.y *= s
        return this
    }

    override fun divide(v2: IVector): Vector2 {
        (v2 as Vector2).let {
            this.x /= v2.x
            this.y /= v2.y
            return this
        }
    }

    /*
     * TODO Verify
     */
    override fun divideScalar(s: Float): Vector2 {
        this.x /= s
        this.y /= s
        return this
    }

    override fun distanceTo(v2: IVector) =
        (v2 as Vector2).let {
            Math.sqrt(
                Math.pow(this.x.toDouble() - v2.x, 2.0) + Math.pow(
                    this.y.toDouble() - v2.y,
                    2.0
                )
            ).toFloat()
        }

    override fun dot(v2: IVector) =
        (v2 as Vector2).let {
            x * v2.x + y * v2.y
        }

    override fun isEqual(v2: IVector) =
        (v2 as Vector2).let {
            this.x == v2.x && this.y == v2.y
        }

    override fun lerp(vector2: IVector, factor: Float): IVector {
        val v = vector2 as Vector2
        return Vector2(
            x + factor * (v.x - x),
            y + factor * (v.y - y),
        )
    }

    override fun normalize(): Vector2 {
        var len: Double = (x * x + y * y).toDouble()
        if (len > 0) {
            //TODO: evaluate use of glm_invsqrt here?
            len = (1.0 / Math.sqrt(len.toDouble()))
        }
        return Vector2(x * len.toFloat(), y * len.toFloat())
    }

    // Transformations

    override fun scale(v: Float) = Vector2(x * v, y * v)

    fun applyMatrix3(m: Matrix3) = Vector2(
        m.elements[0] * x + m.elements[3] * y + m.elements[6],
        m.elements[1] * x + m.elements[4] * y + m.elements[7]
    )

    override fun applyMatrix4(m: Matrix4) = Vector2(
        m.elements[0] * x + m.elements[4] * y + m.elements[12],
        m.elements[1] * x + m.elements[5] * y + m.elements[13]
    )
}