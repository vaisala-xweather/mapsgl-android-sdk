package com.xweather.mapsgl.gl.math

class Vector3(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f) : IVector {

    fun set(x: Float, y: Float, z: Float): Vector3 {
        this.x = x
        this.y = y
        this.z = z
        return this
    }

    fun set(x: Double, y: Double, z: Double): Vector3 {
        this.x = x.toFloat()
        this.y = y.toFloat()
        this.z = z.toFloat()
        return this
    }

    override fun fromArray(array: FloatArray, offset: Int): IVector {
        this.x = array[offset];
        this.y = array[offset + 1];
        this.z = array[offset + 2];
        return this;
    }

    override fun toArray(array: FloatArray, offset: Int): FloatArray {
        array[offset] = this.x
        array[offset + 1] = this.y
        array[offset + 2] = this.z
        return array
    }

    override fun length(): Float =
        Math.sqrt((x * x).toDouble() + (y * y).toDouble() + (z * z).toDouble()).toFloat()

    fun distanceToSquared(v: Vector3) = x * x + y * y + z * z

    fun angle(): Float {
        val v = Vector3(1f, 0f, 0f)
        val mag1 = this.length()
        val mag2 = v.length()
        val mag = mag1 * mag2
        val cosine = if (mag != 0.0f) {
            this.dot(v) / mag
        } else {
            1
        }
        val n = Math.max(cosine.toFloat(), -1f)
        val min = Math.min(n, 1f).toDouble()
        return Math.acos(min).toFloat()
    }

    override fun copy(v3: IVector): Vector3 {
        (v3 as Vector3).let {
            this.x = v3.x
            this.y = v3.y
            this.z = v3.z
            return this
        }
    }

    override fun clone() = Vector3(x, y, z)

    override fun dot(v3: IVector) =
        (v3 as Vector3).let {
            x * v3.x + y * v3.y + z * v3.z
        }

    override fun add(v3: IVector): IVector {
        (v3 as Vector3).let {
            this.x += v3.x
            this.y += v3.y
            this.z += v3.z
            return this
        }
    }

    override fun addScalar(s: Float): IVector {
        this.x += s
        this.y += s
        this.z += s
        return this
    }

    override fun subtract(v3: IVector): IVector {
        (v3 as Vector3).let {
            this.x -= v3.x
            this.y -= v3.y
            this.z -= v3.z
            return this
        }
    }

    override fun subtractScalar(s: Float): IVector {
        this.x -= s
        this.y -= s
        this.z -= s
        return this
    }

    override fun multiply(v3: IVector): IVector {
        (v3 as Vector3).let {
            this.x *= v3.x
            this.y *= v3.y
            this.z *= v3.z
            return this
        }
    }

    override fun multiplyScalar(s: Float): Vector3 {
        this.x *= s
        this.y *= s
        this.z *= s
        return this
    }

    override fun divide(v3: IVector): Vector3 {
        (v3 as Vector3).let {
            this.x /= v3.x
            this.y /= v3.y
            this.z /= v3.z
            return this
        }
    }

    /*
     * TODO Verify
     */
    override fun divideScalar(s: Float): IVector {
        this.x /= s
        this.y /= s
        this.z /= s
        return this
    }

    override fun distanceTo(v3: IVector) = Math.sqrt(
        (v3 as Vector3).let {

            Math.pow(this.x.toDouble() - v3.x, 2.0) + Math.pow(
                this.y.toDouble() - v3.y,
                2.0
            ) + Math.pow(this.z.toDouble() - v3.z, 2.0)
        }
    ).toFloat()


    override fun isEqual(v3: IVector) = (v3 as Vector3).let {
        this.x == v3.x && this.y == v3.y && this.z == v3.z
    }

    override fun lerp(vector3: IVector, factor: Float): IVector {
        val v = vector3 as Vector3
        return Vector3(
            x + factor * (v.x - x),
            y + factor * (v.y - y),
            z + factor * (v.z - z)
        )
    }

    override fun normalize(): Vector3 {
        var len: Double = (x * x + y * y + z * z).toDouble()
        if (len > 0) {
            //TODO: evaluate use of glm_invsqrt here?
            len = (1.0 / Math.sqrt(len.toDouble()))
        }
        return Vector3(x * len.toFloat(), y * len.toFloat(), z * len.toFloat())
    }

    override fun scale(v: Float) = Vector3(x * v, y * v, z * v)

    fun applyEuler(e: Euler): Vector3 {
        val q = QuaternionTC().fromEuler(e);
        return this.applyQuaternion(q);
    }

    fun applyMatrix3(m: Matrix3): Vector3 {
        return Vector3(
            x * m.elements[0] + y * m.elements[3] + z * m.elements[6],
            x * m.elements[1] + y * m.elements[4] + z * m.elements[7],
            x * m.elements[2] + y * m.elements[5] + z * m.elements[8]
        )
    }

    override fun applyMatrix4(m: Matrix4): Vector3 {
        var w = m.elements[3] * x + m.elements[7] * y + m.elements[11] * z + m.elements[15];
        w = if (w != 0f) w else 1.0f

        return Vector3(
            (m.elements[0] * x + m.elements[4] * y + m.elements[8] * z + m.elements[12]) / w,
            (m.elements[1] * x + m.elements[5] * y + m.elements[9] * z + m.elements[13]) / w,
            (m.elements[2] * x + m.elements[6] * y + m.elements[10] * z + m.elements[14]) / w
        )
    }

    fun applyQuaternion(q: QuaternionTC): Vector3 {
        // var qvec = [qx, qy, qz];
        // var uv = vec3.cross([], qvec, a);
        var uvx = q.y * z - q.z * y
        var uvy = q.z * x - q.x * z
        var uvz = q.x * y - q.y * x

        // var uuv = vec3.cross([], qvec, uv);
        var uuvx = q.y * uvz - q.z * uvy
        var uuvy = q.z * uvx - q.x * uvz
        var uuvz = q.x * uvy - q.y * uvx

        // vec3.scale(uv, uv, 2 * w);
        val w2 = q.w * 2
        uvx *= w2
        uvy *= w2;
        uvz *= w2;
        // vec3.scale(uuv, uuv, 2);
        uuvx *= 2;
        uuvy *= 2;
        uuvz *= 2;
        // return vec3.add(out, a, vec3.add(out, uv, uuv));
        return Vector3(
            x + uvx + uuvx,
            y + uvy + uuvy,
            z + uvz + uuvz
        )
    }
}