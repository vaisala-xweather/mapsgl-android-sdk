package com.xweather.mapsgl.gl.math

import android.opengl.Matrix

class ProjectionMatrix : Matrix4(), IMatrix {

    init {
        fromArray(identity().elements, 0)
    }

    fun frustum(
        left: Float, right: Float,
        top: Float, bottom: Float,
        near: Float, far: Float
    ): ProjectionMatrix {
        var m = FloatArray(16)
        Matrix.frustumM(m, 0, left, right, bottom, top, near, far)
        return ProjectionMatrix().fromArray(m.toList()) as ProjectionMatrix
    }

    fun orthographic(
        left: Float, right: Float,
        top: Float, bottom: Float,
        near: Float, far: Float
    ): ProjectionMatrix {
        var m = FloatArray(16)
        Matrix.orthoM(m, 0, left, right, bottom, top, near, far)
        return ProjectionMatrix().fromArray(m.toList()) as ProjectionMatrix
    }

    fun perspective(
        fovy: Float, aspect: Float,
        near: Float, far: Float
    ): ProjectionMatrix {
        var m = FloatArray(16)
        Matrix.perspectiveM(m, 0, fovy, aspect, near, far)
        return ProjectionMatrix().fromArray(m.toList()) as ProjectionMatrix
    }

    fun lookAt(
        eye: Vector3,
        center: Vector3 = Vector3(0f, 0f, 0f),
        up: Vector3 = Vector3(0f, 1f, 0f)
    ): ProjectionMatrix {
        var m = FloatArray(16)
        Matrix.setLookAtM(m, 0, eye.x, eye.y, eye.z, center.x, center.y, center.z, up.x, up.y, up.z)
        return ProjectionMatrix().fromArray(m.toList()) as ProjectionMatrix
    }
}