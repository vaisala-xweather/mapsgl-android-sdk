package com.xweather.mapsgl.gl.math

class Vector4(var x: Float, var y: Float, var z: Float, var w: Float) : IVector {

    override fun fromArray(array: FloatArray, offset: Int): Vector4 {
        this.x = array[offset];
        this.y = array[offset + 1];
        this.z = array[offset + 2];
        this.w = array[offset + 3];
        return this;
    }

    override fun toArray(array: FloatArray, offset: Int): FloatArray {
        array[offset] = this.x
        array[offset + 1] = this.y
        array[offset + 2] = this.z
        array[offset + 3] = this.w
        return array
    }

    override fun length(): Float =
        Math.sqrt((x * x).toDouble() + (y * y).toDouble() + (z * z).toDouble() + (w * w).toDouble())
            .toFloat()


    override fun copy(v4: IVector): Vector4 {
        (v4 as Vector4).let {
            this.x = v4.x
            this.y = v4.y
            this.z = v4.z
            return this
        }
    }

    override fun clone() = Vector4(x, y, z, w)

    override fun add(v4: IVector): Vector4 {
        (v4 as Vector4).let {
            this.x += v4.x
            this.y += v4.y
            this.z += v4.z
            this.w += v4.w
            return this
        }
    }

    override fun addScalar(s: Float): Vector4 {
        this.x += s
        this.y += s
        this.z += s
        this.w += s
        return this
    }

    override fun subtract(v4: IVector): Vector4 {
        (v4 as Vector4).let {
            this.x -= v4.x
            this.y -= v4.y
            this.z -= v4.z
            this.w -= v4.w
            return this
        }
    }

    override fun subtractScalar(s: Float): Vector4 {
        this.x -= s
        this.y -= s
        this.z -= s
        this.w -= s
        return this
    }

    override fun multiply(v4: IVector): Vector4 {
        (v4 as Vector4).let {
            this.x *= v4.x
            this.y *= v4.y
            this.z *= v4.z
            this.w *= v4.w
            return this
        }
    }

    override fun multiplyScalar(s: Float): Vector4 {
        this.x *= s
        this.y *= s
        this.z *= s
        this.w *= s
        return this
    }

    override fun divide(v4: IVector): Vector4 {
        (v4 as Vector4).let {
            this.x /= v4.x
            this.y /= v4.y
            this.z /= v4.z
            this.w /= v4.w
            return this
        }
    }

    override fun divideScalar(s: Float): Vector4 {
        this.x /= s
        this.y /= s
        this.z /= s
        this.w /= s
        return this
    }

    override fun distanceTo(v4: IVector) = Math.sqrt(
        (v4 as Vector4).let {
            Math.pow(this.x.toDouble() - v4.x, 2.0) +
                    Math.pow(this.y.toDouble() - v4.y, 2.0) +
                    Math.pow(this.z.toDouble() - v4.z, 2.0) +
                    Math.pow(this.w.toDouble() - v4.w, 2.0)
        }
    ).toFloat()

    override fun dot(v4: IVector) =
        (v4 as Vector4).let { x * v4.x + y * v4.y + z * v4.z + w * v4.w }

    override fun isEqual(v4: IVector) = (v4 as Vector4).let {
        this.x == v4.x && this.y == v4.y && this.z == v4.z && this.w == v4.w
    }

    override fun lerp(v4: IVector, factor: Float): Vector4 {
        val v = v4 as Vector4
        return Vector4(
            x + factor * (v.x - x),
            y + factor * (v.y - y),
            z + factor * (v.z - z),
            w + factor * (v.w - w)
        )
    }

    override fun normalize(): Vector4 {
        var len: Double = (x * x + y * y + z * z + w * w).toDouble()
        if (len > 0) {
            //TODO: evaluate use of glm_invsqrt here?
            len = (1.0 / Math.sqrt(len.toDouble()))
        }
        return Vector4(x * len.toFloat(), y * len.toFloat(), z * len.toFloat(), w * len.toFloat())
    }

    override fun scale(v: Float) = Vector4(x * v, y * v, z * v, w * v)

    override fun applyMatrix4(m: Matrix4): Vector4 {
        return Vector4(
            x * m.elements[0] + y * m.elements[4] + z * m.elements[8] + w * m.elements[12],
            x * m.elements[1] + y * m.elements[5] + z * m.elements[9] + w * m.elements[13],
            x * m.elements[2] + y * m.elements[6] + z * m.elements[10] + w * m.elements[14],
            x * m.elements[3] + y * m.elements[7] + z * m.elements[11] + w * m.elements[15],
        )
    }
}