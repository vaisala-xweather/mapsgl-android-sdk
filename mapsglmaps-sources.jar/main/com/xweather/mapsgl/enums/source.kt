package com.xweather.mapsgl.enums

internal enum class VectorSourceType(val value: String) {
    point("point"),
    line("line"),
    polygon("polygon"),
    symbol("symbol");

    companion object {
        fun fromValue(value: String): VectorSourceType = when (value) {
            "point" -> point
            "line" -> line
            "polygon" -> polygon
            "symbol" -> symbol
            else -> throw IllegalArgumentException()
        }
    }
}

internal enum class DataSourceType(val value: String) {
    raster("raster"),
    vector("vector"),
    geojson("geo-json"),
    encoded("encoded"),
    encodedAeris("encoded-aeris"),
    vectorAeris("vector-aeris");

    companion object {
        fun fromValue(value: String): DataSourceType = when (value) {
            "raster" -> raster
            "vector" -> vector
            "geo-json" -> geojson
            "encoded" -> encoded
            "encoded-aeris" -> encodedAeris
            "vector-aeris" -> vectorAeris
            else -> throw IllegalArgumentException()
        }
    }
}
