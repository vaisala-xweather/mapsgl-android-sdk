package com.xweather.mapsgl.anim

import com.xweather.mapsgl.AbortSignal
import com.xweather.mapsgl.AnyAuthenticator
import com.xweather.mapsgl.gl.extensions.pr
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Date

/**
 * Options for a tile request.
 */
/** @suppress **/
data class TileRequestOptions(
    /** The HTTP method to use for the request.   */
    val method: String = "",

    /** The authenticator to use for the request, if any.   */
    val authenticator: AnyAuthenticator? = null,

    /** The request body to send, if any.    */
    val body: Any? = null,

    /** The request headers to send, if any.    */
    val headers: Any? = null,

    /** The request parameters to send, if any.    */
    val params: Map<String, Any>? = null,

    /** The AbortSignal to use for the request.    */
    val signal: AbortSignal? = null,

    /** Whether to reload the tile if it has already been loaded.    */
    var reload: Boolean = true,

    /** Whether to check if the tile is already pending before loading.    */
    var checkPending: Boolean = true,

    /** The time intervals to load for the tile.    */
    val intervals: List<Date>? = null,

    /** Used for p-type radar    */
    var isRadar: Boolean = false


) {

    init {
        if (pr.ON) pr.p("TileRequestOptions", pr.radarFix2, "init{} isRadar:$isRadar")
    }

    fun formatDate(date: Date): String {
        val instant = date.toInstant()
        val zonedDateTime = ZonedDateTime.ofInstant(instant, ZoneId.systemDefault()) // detect timezone
        val formatter: DateTimeFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME
        return "${zonedDateTime.format(formatter).substring(0, 19)}Z"
    }

}
