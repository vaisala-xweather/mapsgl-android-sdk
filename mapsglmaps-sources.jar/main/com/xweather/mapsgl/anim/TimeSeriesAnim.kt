package com.xweather.mapsgl.anim

import java.util.Date

//TODO: There is a lot more to this class to add!

/*
enum class TimeClampMode(value: String) {
    none("none"),
    past("past"),
    future("future"),
    }
 */
/** @suppress **/
data class TimeSeriesState(
    val position: Int = 0,
    val interval: Date? = null,
    val nextInterval: Date? = null,
    val intervalPosition: Int= 0,
    val index: Int = 0,
    val nextIndex: Int = 0
)

