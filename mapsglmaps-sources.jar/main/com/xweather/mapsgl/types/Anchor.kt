package com.xweather.mapsgl.types

enum class Anchor(val value: String) {
    CENTER("center"),
    LEFT("left"),
    RIGHT("right"),
    TOP("top"),
    BOTTOM("bottom"),
    TOP_LEFT("top-left"),
    TOP_RIGHT("top-right"),
    BOTTOM_LEFT("bottom-left"),
    BOTTOM_RIGHT("bottom-right")
}

data class AnchorOffset(
    var x: Double = 0.0,
    var y: Double = 0.0
)