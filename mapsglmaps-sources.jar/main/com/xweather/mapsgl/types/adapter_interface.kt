package com.xweather.mapsgl.types

import com.xweather.mapsgl.tiles.LatLonBounds

/**
 * Provides a common interface when communicating between data layers and the associated map.
 *
 * @interface MapProvider
 */

interface MapProvider : Observable {
    fun getSize(): Size
    fun getCenter(): Coordinate
    fun getBounds(): LatLonBounds
    fun getZoom(): Double
    fun getBearing(): Double
    fun getPitch(): Double
    fun getFov(): Double
}

interface Observable {
    fun on(name: String, callback: (event: Any) -> Unit)
    fun off(name: String, callback: (event: Any) -> Unit)
}


