package com.xweather.mapsgl.types

/**
*  Headers.kt
*
*  Created by Jason Suto on 01/09/24.
*  Based on the IOS version
**/

typealias Headers = HashMap<Any, Any>