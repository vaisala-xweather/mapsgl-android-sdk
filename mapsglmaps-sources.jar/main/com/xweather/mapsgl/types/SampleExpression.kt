package com.xweather.mapsgl.types

enum class SampleExpression {
    /** Value is a float sampled from a single band. **/
    NUMBER,
    /** Value is a vector sampled and calculated from two bands. **/
    VECTOR,
    /** Value is a float sampled and calculated as the sum of two bands. **/
    SUM,
    /** Value is a float sampled and calculated as the difference of two bands.**/
    DIFFERENCE,
    /** Value is a float sampled and calculated from the vector of two bands. **/
    ANGLE,
    /** Value is calculated using a custom shader chunk based on the encoded data. **/
    CUSTOM,
    NO_DATA
}
