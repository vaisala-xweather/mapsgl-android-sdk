package com.xweather.mapsgl.types

/**
*  TileSize.kt
*
*  Created by Jason Suto on 01/08/24.
*  Adapted from IOS version.
**/

data class TileSize(var width: Int, var height: Int) {
    init {
        require(width >= 0)
        require(height >= 0)
    }
}

fun TileSize(size: Int): TileSize {
    return TileSize(size,size)
}