package com.xweather.mapsgl.types.math_type

data class ValueRange(var min: Double, val max: Double, val unit: String)

data class ValueRangeInt(val min: Int, val max: Int, val unit: String)

