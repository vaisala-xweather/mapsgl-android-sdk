package com.xweather.mapsgl.weather

data class BoundingBox(
    val north: Int,
    val west: Int,
    val south: Int,
    val east: Int
)

val regionBoundingBox: Map<String, BoundingBox> = mapOf(
    "us" to BoundingBox(
        north = 57,
        west = -127,
        south = 24,
        east = -59
    ),
    "europe" to BoundingBox(
        north = 72,
        west = -11,
        south = 23,
        east = 46
    ),
    "japan" to BoundingBox(
        north = 46,
        west = 122,
        south = 24,
        east = 149
    ),
    "australia" to BoundingBox(
        north = -9,
        west = 114,
        south = -44,
        east = 154
    ),
    "new_zealand" to BoundingBox(
        north = -34,
        west = 166,
        south = -47,
        east = 179
    )
)




