package com.xweather.mapsgl.weather.common


internal interface Mask {
    val layerId: String
    val invert: Boolean
    val overrides: Map<String, Any>?
}

internal data class waterMask(
    override val layerId: String = "water",
    override val invert: Boolean = false,
    override val overrides: Map<String, Any>?  = mapOf(
        "paint" to mapOf(
            "fill" to mapOf(
                "color" to "#fff"
            )
        )
    )
): Mask

internal data class landMask(
    override val layerId: String = "land",
    override val invert: Boolean = true,
    override val overrides: Map<String, Any>?  = mapOf(
        "paint" to mapOf(
            "fill" to mapOf(
                "color" to "#fff"
            )
        )
    )
): Mask



