//
//  Conditions.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2025-10-22T18:06:35.565Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.LegendCode
import com.xweather.mapsgl.layers.spec.ContourLayerDescriptor
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.ContourPaint
import com.xweather.mapsgl.style.ParticleDensity
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.ParticlePaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations
import com.xweather.mapsgl.weather.toColor


object Conditions {
    class CloudCover(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.CLOUD_COVER
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TCDC_PRECIP_UVI(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.cloud_cover.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.sky.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.PERCENTAGE]?.setTitle("Cloud Cover")

        init {
            legend = LegendCode.CLOUD_COVER.getLegend()
        }
    }

    class DewPoints(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.DEW_POINTS
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.dew_point.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.dewPoint.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Dew Point")

        init {
            legend = LegendCode.DEW_POINT.getLegend()
        }

    }

    class FeelsLike(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.FEELS_LIKE
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.feels_like.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.temperature.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Feels Like")

        init {
            legend = LegendCode.FEELS_LIKE.getLegend()
        }
    }

    class HeatIndex(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HEAT_INDEX
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.heat_index.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 26.66667..54.44,
                    colorScale = ColorScaleOptions(
                        ColorScales.temperature.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Heat Index")

        init {
            legend = LegendCode.HEAT_INDEX.getLegend()
        }

    }

    class Humidity(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HUMIDITY
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.humidity.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.humidity.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.PERCENTAGE]?.setTitle("Humidity")

        init {
            legend = LegendCode.HUMIDITY.getLegend()
        }
    }


    class Precipitation(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PRECIPITATION
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRECIP(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.precip.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red, ColorBand.green, ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.00007..0.21167,
                    colorScale = ColorScaleOptions(
                        ColorScales.precip_accum.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation: Presentation? = null

        init {
            presentation = presentations[PresentationType.PRECIPITATION]
            legend = LegendCode.ACCUM_PRECIP.getLegend()
        }
    }

    class PressureMeanSeaLevel(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PRESSURE_MEAN_SEA_LEVEL
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRMSL_VIS_GUST10(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.pressure_msl.fill",
            source.id,
            quality = DataQuality.low,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        listOf(
                            ColorStop(950.0, toColor("#D08AFF")),
                            ColorStop(960.0, toColor("#9A00FF")),
                            ColorStop(970.0, toColor("#6401FF")),
                            ColorStop(980.0, toColor("#0300B8")),
                            ColorStop(990.0, toColor("#084ADA")),
                            ColorStop(1000.0, toColor("#01CDFF")),
                            ColorStop(1010.0, toColor("#23DC02")),
                            ColorStop(1020.0, toColor("#FEF90B")),
                            ColorStop(1030.0, toColor("#FE7B00")),
                            ColorStop(1040.0, toColor("#FA0107")),
                            ColorStop(1050.0, toColor("#970100")),
                            ColorStop(1060.0, toColor("#DB5C5F")),
                        ),
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.PRESSURE]?.setTitle("Surface Pressure")
    }

    class PressureMeanSeaLevelContour(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> {
        override val code: LayerCode = LayerCode.PRESSURE_MEAN_SEA_LEVEL_CONTOUR
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRMSL_VIS_GUST10(service)
        override val layer: ContourLayerDescriptor = ContourLayerDescriptor(
            "conditions.pressure_msl.contour",
            source.id,
            quality = DataQuality.high,
            paint = ContourLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        listOf(
                            ColorStop(950.0, toColor("#D08AFF")),
                            ColorStop(960.0, toColor("#9A00FF")),
                            ColorStop(970.0, toColor("#6401FF")),
                            ColorStop(980.0, toColor("#0300B8")),
                            ColorStop(990.0, toColor("#084ADA")),
                            ColorStop(1000.0, toColor("#01CDFF")),
                            ColorStop(1010.0, toColor("#23DC02")),
                            ColorStop(1020.0, toColor("#FEF90B")),
                            ColorStop(1030.0, toColor("#FE7B00")),
                            ColorStop(1040.0, toColor("#FA0107")),
                            ColorStop(1050.0, toColor("#970100")),
                            ColorStop(1060.0, toColor("#DB5C5F")),
                        ),
                        interval = 0.0,
                    ),
                    smoothing = .5f
                ),
                contour = ContourPaint(
                    interval = StyleValue.Constant(2.0),
                    majorInterval = StyleValue.Constant(10.0),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.PRESSURE]?.setTitle("Surface Pressure")
        override var legend: Legend? = null

        init {
            legend = LegendCode.PRESSURE.getLegend()
        }
    }

    class TemperaturesContour(
        val service: WeatherService
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> {
        override val code: LayerCode = LayerCode.TEMPERATURES_CONTOUR
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: ContourLayerDescriptor = ContourLayerDescriptor(
            "conditions.temperature.contour",
            source.id,
            quality = DataQuality.exact,
            paint = ContourLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.temperature.stops,
                        interval = 0.0,
                    ),
                    smoothing = 1.0f
                ),
                contour = ContourPaint(
                    interval = StyleValue.Constant(1.11),
                    majorInterval = StyleValue.Constant(5.55001),
                ),
            ),

            )
        override var presentation = presentations[PresentationType.TEMPERATURE]
        override var legend: Legend? = null

        init {
            legend = LegendCode.TEMPERATURE.getLegend()
        }
    }

    class Radar(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.RADAR
        override val source: EncodedSourceDescriptor = WeatherSource.radar_REFC_PRATE_PTYPESMPL(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.radar.fill",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    //drawRange = 10.0..87.0, //Fixme: Why does adding drawRange break animations... maybe radar shader does not handle it the same
                    colorScale = ColorScaleOptions(
                        stops = listOf(
                            listOf(
                                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                ColorStop(5.99, toColor("rgba(0,0,0,0)")),
                                ColorStop(6.0, toColor("#8CF482")),
                                ColorStop(10.0, toColor("#49eb3a")),
                                ColorStop(33.0, toColor("#114c00")),
                                ColorStop(40.0, toColor("#e4c700")),
                                ColorStop(50.0, toColor("#da0000")),
                                ColorStop(60.0, toColor("#7a0009")),
                                ColorStop(65.0, toColor("#9e0570")),
                                ColorStop(70.0, toColor("#dc42b1")),
                                ColorStop(80.0, toColor("#dea8ff")),
                                ColorStop(87.0, toColor("#faf3ff")),
                            ),
                            listOf(
                                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                ColorStop(5.9, toColor("rgba(255,163,249,0)")),
                                ColorStop(6.0, toColor("#ffa3f9")),
                                ColorStop(25.0, toColor("#d518be")),
                                ColorStop(58.0, toColor("#58003c")),
                                ColorStop(87.0, toColor("#58003c")),
                            ),
                            listOf(
                                ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                                ColorStop(5.9, toColor("rgba(124,255,255,0)")),
                                ColorStop(6.0, toColor("#7cffff")),
                                ColorStop(7.0, toColor("#00e8ff")),
                                ColorStop(25.0, toColor("#0061ea")),
                                ColorStop(45.0, toColor("#0000af")),
                                ColorStop(58.0, toColor("#5c00f5")),
                                ColorStop(87.0, toColor("#5c00f5")),
                            ),
                        ),
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.RADAR]
        override var legend: Legend? = LegendCode.RADAR.getLegend()
    }

    class Snow(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.SNOW
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_SNOW_PRECIP_TMP2(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.snow.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red, ColorBand.green, ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.00254..0.21167,
                    colorScale = ColorScaleOptions(
                        ColorScales.snowdepth.stops
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.SNOWFALL]

        init {
            legend = LegendCode.ACCUM_SNOW.getLegend()
        }
    }

    class SnowDepth(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.SNOW_DEPTH
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_SNOD(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.snow_depth.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.0254..7.9248,
                    colorScale = ColorScaleOptions(
                        ColorScales.snowdepth.stops,
                    ),
                ),
            ),
        )
        override var presentation: Presentation? = null

        init {
            legend = LegendCode.SNOW_DEPTH.getLegend()
        }

    }

    class Temperatures(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.TEMPERATURES
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.temperature.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.temperature.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.TEMPERATURE]

        init {
            legend = LegendCode.TEMPERATURE.getLegend()
        }
    }

    class Temperatures1HourChange(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.TEMPERATURES_1_HOUR_CHANGE
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_DELTA(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.temperature_1hr_change.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    expression = SampleExpression.DIFFERENCE,
                    channel = listOf(ColorBand.red, ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        listOf(
                            ColorStop(-22.2, toColor("#EF90FF")),
                            ColorStop(-13.875, toColor("#D741DA")),
                            ColorStop(-8.325, toColor("#8B21DA")),
                            ColorStop(-5.55, toColor("#0070F1")),
                            ColorStop(-2.775, toColor("#8ED4F9")),
                            ColorStop(-0.555, toColor("rgba(142,212,249,0)")),
                            ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                            ColorStop(0.555, toColor("rgba(255,217,42,0)")),
                            ColorStop(2.775, toColor("#FFD92A")),
                            ColorStop(5.55, toColor("#FF932A")),
                            ColorStop(8.325, toColor("#E2330B")),
                            ColorStop(19.425, toColor("#9D0000")),
                            ColorStop(22.2, toColor("#D00071")),
                        ),
                        range = -22.2..22.2,
                        interval = 0.0,
                    ),
                    offset = 0.5f,
                ),
            ),
        )
        override var presentation = presentations[PresentationType.TEMPERATURE_CHANGE]

        init {
            legend = LegendCode.TEMPERATURE_CHANGE_1HR.getLegend()
        }
    }

    class Temperatures24HourChange(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.TEMPERATURES_24_HOUR_CHANGE
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_DELTA(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.temperature_24hr_change.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    expression = SampleExpression.DIFFERENCE,
                    channel = listOf(ColorBand.red, ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        listOf(
                            ColorStop(-33.3, toColor("#EF90FF")),
                            ColorStop(-27.75, toColor("#D741DA")),
                            ColorStop(-22.2, toColor("#8B21DA")),
                            ColorStop(-16.65, toColor("#0013CA")),
                            ColorStop(-11.1, toColor("#0070F1")),
                            ColorStop(-5.55, toColor("#8ED4F9")),
                            ColorStop(-0.555, toColor("rgba(142,212,249,0)")),
                            ColorStop(0.0, toColor("rgba(0,0,0,0)")),
                            ColorStop(0.555, toColor("rgba(255,217,42,0)")),
                            ColorStop(5.55, toColor("#FFD92A")),
                            ColorStop(11.1, toColor("#FF932A")),
                            ColorStop(16.65, toColor("#E2330B")),
                            ColorStop(22.2, toColor("#9D0000")),
                            ColorStop(27.75, toColor("#D00071")),
                            ColorStop(33.3, toColor("#FF698C")),
                        ),
                        range = -27.75..27.75,
                        interval = 0.0,
                    ),
                    offset = 0.5f,
                ),
            ),
        )
        override var presentation: Presentation? = null

        init {
            presentation = presentations[PresentationType.TEMPERATURE_CHANGE]
            legend = LegendCode.TEMPERATURE_CHANGE_24HR.getLegend()

        }
    }

    class UltravioletIndex(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ULTRAVIOLET_INDEX
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TCDC_PRECIP_UVI(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.uvi.fill",
            source.id,
            quality = DataQuality.low,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.uvi.stops,
                        interval = 1.0,
                    ),
                    smoothing = 1.0f,
                ),
            ),
        )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("UV Index")

        init {
            legend = LegendCode.UVI.getLegend()
        }
    }

    class Visibility(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.VISIBILITY
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRMSL_VIS_GUST10(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.visibility.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.visibility.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.DISTANCE]?.setTitle("Visibility")

        init {
            legend = LegendCode.VISIBILITY.getLegend()
        }
    }

    class WindChill(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.WIND_CHILL
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_APTMP2_DPT2_RH2(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.wind_chill.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = -62.22..4.44444,
                    colorScale = ColorScaleOptions(
                        ColorScales.temperature.stops,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Wind Chill")
        override var legend = LegendCode.WIND_CHILL.getLegend()
    }

    class WindGusts(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_GUSTS
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PRMSL_VIS_GUST10(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.wind_gust.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.windSpeed.stops,
                        range = 0.0..53.64,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.WIND_GUST]

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WindParticles(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<ParticleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_PARTICLES
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: ParticleLayerDescriptor = ParticleLayerDescriptor(
            "conditions.wind_speed.particle",
            source.id,
            quality = DataQuality.exact,
            paint = ParticleLayerPaint(
                sample = SamplePaint(
                    expression = SampleExpression.VECTOR,
                    channel = listOf(ColorBand.green, ColorBand.blue),
                    interpolation = InterpolationMode.BILINEAR,
                    colorScale = ColorScaleOptions(
                        ColorScales.windSpeed.stops,
                        range = 0.0..53.64,
                        interval = 0.0,
                    ),
                    smoothing = 1.0f,
                ),
                particle = ParticlePaint(
                    density = ParticleDensity.NORMAL,
                    size = Size(2, 2),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.WIND_SPEED]

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WindSpeeds(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_SPEEDS
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.wind_speed.fill",
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    expression = SampleExpression.VECTOR,
                    channel = listOf(ColorBand.green, ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.windSpeed.stops,
                        range = 0.0..53.64,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.WIND_SPEED]

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WindSpeedsContour(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<ContourLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WIND_SPEEDS_CONTOUR
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TMP2_UGRD10_VGRD10(service)
        override val layer: ContourLayerDescriptor = ContourLayerDescriptor(
            "conditions.wind_speed.contour",
            source.id,
            quality = DataQuality.high,
            paint = ContourLayerPaint(
                sample = SamplePaint(
                    expression = SampleExpression.VECTOR,
                    channel = listOf(ColorBand.green, ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    colorScale = ColorScaleOptions(
                        ColorScales.windSpeed.stops,
                        range = 0.0..53.64,
                    ),
                    smoothing = 1.0f
                ),
                contour = ContourPaint(
                    interval = StyleValue.Constant(2.25),
                    majorInterval = StyleValue.Constant(11.25),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.WIND_SPEED]

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }
}
