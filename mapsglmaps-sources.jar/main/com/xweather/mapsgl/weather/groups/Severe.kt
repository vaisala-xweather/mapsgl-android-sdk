//
//  Severe.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2025-10-22T18:06:35.562Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.LegendCode
import com.xweather.mapsgl.controls.legend.Point.AlertsLegendItemResolver
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.coordinates.LatLon
import com.xweather.mapsgl.coordinates.LatitudeLongitude
import com.xweather.mapsgl.coordinates.MapBounds
import com.xweather.mapsgl.coordinates.MapCoordinate
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.HeatmapLayerDescriptor
import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.HeatmapLayerPaint
import com.xweather.mapsgl.style.HeatmapPaint
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.BaseVectorConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.CompositeWeatherLayerConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations
import com.xweather.mapsgl.weather.toColor

object Severe {
    class Alerts(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.ALERTS
        override val source: VectorSourceDescriptor = WeatherSource.severe_alerts(service)
        override val layer: FillLayerDescriptor = FillLayerDescriptor(
            "severe.alerts.fill",
            source.id,
            paint = FillLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Expression(Expression.concat(listOf("#", Expression.get("COLOR")))),
                ),
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#000")),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.ALERTS]
        override var legend: Legend? = PointLegend(
            title = "Alerts", layerId = "alerts", id = "alerts", itemResolver = AlertsLegendItemResolver()
        )
    }

    class AlertsOutline(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.ALERTS_OUTLINE
        override val source: VectorSourceDescriptor = WeatherSource.severe_alerts(service)
        override val layer: LineLayerDescriptor = LineLayerDescriptor(
            "severe.alerts.line",
            source.id,
            paint = LineLayerPaint(
                stroke = StrokePaint(
                    color = StyleValue.Expression(Expression.concat(listOf("#", Expression.get("COLOR")))),
                    thickness = StyleValue.Constant(3.0),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.ALERTS]
        override var legend: Legend? = null
    }

    class Convective(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.CONVECTIVE
        override val source: GeoJSONSourceDescriptor = WeatherSource.severe_convective(service)
        override val layer: FillLayerDescriptor = FillLayerDescriptor(
            "severe.convective.fill",
            source.id,
            paint = FillLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Expression(
                        Expression.match(
                            Expression.downcase(Expression.get("details.risk.type")),
                            ColorScales.convective.toExpressionSteps(),
                            "#999999",
                        ),
                    ),
                    opacity = StyleValue.Constant(0.9),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.CONVECTIVE]
        override var legend: Legend? = null
    }

    class ConvectiveOutline(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.CONVECTIVE_OUTLINE
        override val source: GeoJSONSourceDescriptor = WeatherSource.severe_convective(service)
        override val layer: LineLayerDescriptor = LineLayerDescriptor(
            "severe.convective.line",
            source.id,
            paint = LineLayerPaint(
                stroke = StrokePaint(
                    color = StyleValue.Expression(
                        Expression.match(
                            Expression.downcase(Expression.get("details.risk.type")),
                            ColorScales.convective.toExpressionSteps(),
                            "#999999",
                        ),
                    ),
                    thickness = StyleValue.Constant(3.0),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.CONVECTIVE]
        override var legend: Legend? = null
    }

    class HailSevereProbability(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.HAIL_SEVERE_PROBABILITY
        override val layers = listOf(
            HailSevereProbabilityUnitedStates(service),
            HailSevereProbabilityEurope(service),
            HailSevereProbabilityJapan(service),
            HailSevereProbabilityAustralia(service),
        )
    }

    class HailSevereProbabilityAustralia(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.HAIL_SEVERE_PROBABILITY_AUSTRALIA
        override val source: EncodedSourceDescriptor = WeatherSource.severe_hail_MESH_POSH_australia(service).apply {
            val sw = LatLon(-44.0, 114.0)
            val ne = LatLon(-9.0, 154.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.hail.posh.australia",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 10.0..101.6,
                    colorScale = ColorScaleOptions(
                        ColorScales.hailProbability.stops,
                        range = 0.0..100.0,
                        interval = 0.0,
                        normalized = true,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.PERCENTAGE]?.setTitle("Severe Hail Prob")
        override var legend: Legend? = LegendCode.HAIL_PROB.getLegend()
    }

    class HailSevereProbabilityEurope(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.HAIL_SEVERE_PROBABILITY_EUROPE
        override val source: EncodedSourceDescriptor = WeatherSource.severe_hail_MESH_POSH_europe(service).apply {
            val sw = LatLon(23.0, -11.0)
            val ne = LatLon(72.0, 45.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.hail.posh.europe",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 10.0..101.6,
                    colorScale = ColorScaleOptions(
                        ColorScales.hailProbability.stops,
                        range = 0.0..100.0,
                        interval = 0.0,
                        normalized = true,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.PERCENTAGE]?.setTitle("Severe Hail Prob")
        override var legend: Legend? = LegendCode.HAIL_PROB.getLegend()
    }

    class HailSevereProbabilityJapan(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.HAIL_SEVERE_PROBABILITY_JAPAN
        override val source: EncodedSourceDescriptor = WeatherSource.severe_hail_MESH_POSH_japan(service).apply {
            val sw = LatLon(24.0, 122.0)
            val ne = LatLon(46.0, 149.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.hail.posh.japan",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 10.0..101.6,
                    colorScale = ColorScaleOptions(
                        ColorScales.hailProbability.stops,
                        range = 0.0..100.0,
                        interval = 0.0,
                        normalized = true,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.PERCENTAGE]?.setTitle("Severe Hail Prob")
        override var legend: Legend? = LegendCode.HAIL_PROB.getLegend()
    }

    class HailSevereProbabilityUnitedStates(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.HAIL_SEVERE_PROBABILITY_UNITED_STATES
        override val source: EncodedSourceDescriptor = WeatherSource.severe_hail_MESH_POSH_us(service).apply {
            val sw = LatLon(24.0, -127.0)
            val ne = LatLon(57.0, -59.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.hail.posh.us",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 10.0..101.6,
                    colorScale = ColorScaleOptions(
                        ColorScales.hailProbability.stops,
                        range = 0.0..100.0,
                        interval = 0.0,
                        normalized = true,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.PERCENTAGE]?.setTitle("Severe Hail Prob")
        override var legend: Legend? = LegendCode.HAIL_PROB.getLegend()
    }

    class HailSize(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.HAIL_SIZE
        override val layers = listOf(
            HailSizeUnitedStates(service),
            HailSizeEurope(service),
            HailSizeJapan(service),
            HailSizeAustralia(service),
        )
    }

    class HailSizeAustralia(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HAIL_SIZE_AUSTRALIA
        override val source: EncodedSourceDescriptor = WeatherSource.severe_hail_MESH_POSH_australia(service).apply {
            val sw = LatLon(-44.0, 114.0)
            val ne = LatLon(-9.0, 154.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.hail.size.australia",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 1.0..101.6,
                    colorScale = ColorScaleOptions(
                        ColorScales.hailSize.stops,
                        range = 0.0..76.2,
                        interval = 1.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.SIZE]?.setTitle("Hail Size")

        init {
            legend = LegendCode.HAIL_SIZE.getLegend()
        }
    }

    class HailSizeEurope(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HAIL_SIZE_EUROPE
        override val source: EncodedSourceDescriptor = WeatherSource.severe_hail_MESH_POSH_europe(service).apply {
            val sw = LatLon(23.0, -11.0)
            val ne = LatLon(72.0, 45.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.hail.size.europe",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 1.0..101.6,
                    colorScale = ColorScaleOptions(
                        ColorScales.hailSize.stops,
                        range = 0.0..76.2,
                        interval = 1.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.SIZE]?.setTitle("Hail Size")

        init {
            legend = LegendCode.HAIL_SIZE.getLegend()
        }
    }

    class HailSizeJapan(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HAIL_SIZE_JAPAN
        override val source: EncodedSourceDescriptor = WeatherSource.severe_hail_MESH_POSH_japan(service).apply {
            val sw = LatLon(24.0, 122.0)
            val ne = LatLon(46.0, 149.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.hail.size.japan",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 1.0..101.6,
                    colorScale = ColorScaleOptions(
                        ColorScales.hailSize.stops,
                        range = 0.0..76.2,
                        interval = 1.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.SIZE]?.setTitle("Hail Size")

        init {
            legend = LegendCode.HAIL_SIZE.getLegend()
        }
    }

    class HailSizeUnitedStates(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HAIL_SIZE_UNITED_STATES
        override val source: EncodedSourceDescriptor = WeatherSource.severe_hail_MESH_POSH_us(service).apply {
            val sw = LatLon(24.0, -127.0)
            val ne = LatLon(57.0, -59.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.hail.size.us",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 1.0..101.6,
                    colorScale = ColorScaleOptions(
                        listOf(
                            ColorStop(0.0, toColor("rgba(132,0,170,0)")),
                            ColorStop(1.0, toColor("#372497")),
                            ColorStop(12.7, toColor("#1D6AA2")),
                            ColorStop(25.3746, toColor("#089E9A")),
                            ColorStop(25.4, toColor("#09BB93")),
                            ColorStop(50.8, toColor("#FEF112")),
                            ColorStop(76.2, toColor("#FE5412")),
                        ),
                        range = 0.0..76.2,
                        interval = 1.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.SIZE]?.setTitle("Hail Size")

        init {
            legend = LegendCode.HAIL_SIZE.getLegend()
        }
    }

    class HailThreats(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.HAIL_THREATS
        override val layers = listOf(
            HailThreatsPolygons(service),
            HailThreatsTracks(service),
            HailThreatsPoints(service),
        )
    }

    class HailThreatsPoints(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.HAIL_THREATS_POINTS
        override val source: VectorSourceDescriptor = WeatherSource.severe_hail_threats(service)
        override val layer: CircleLayerDescriptor = CircleLayerDescriptor(
            "severe.hail.threats.circle",
            source.id,
            filter = Expression.contains(Expression.geometryType, listOf("Point")),
            paint = CircleLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Constant(toColor("#520BAE")),
                    opacity = StyleValue.Constant(0.5),
                ),
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#fff")),
                    thickness = StyleValue.Constant(1.0),
                ),
                circle = CirclePaint(
                    radius = StyleValue.Constant(2.0),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.THREAT]?.setTitle("Hail Threat")
        override var legend: Legend? = null
    }

    class HailThreatsPolygons(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.HAIL_THREATS_POLYGONS
        override val source: VectorSourceDescriptor = WeatherSource.severe_hail_threats(service)
        override val layer: FillLayerDescriptor = FillLayerDescriptor(
            "severe.hail.threats.fill",
            source.id,
            filter = Expression.contains(
                Expression.geometryType,
                listOf(
                    "Polygon",
                    "MultiPolygon",
                ),
            ),
            paint = FillLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Expression(
                        Expression.step(
                            Expression.floor(
                                Expression.divide(
                                    Expression.subtract(
                                        Expression.get("period.range.minTimestamp"),
                                        Expression.get("details.issuedTimestamp"),
                                    ),
                                    60,
                                ),
                            ),
                            ColorScales.hailThreat.toExpressionSteps(),
                        ),
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.THREAT]?.setTitle("Hail Threat")
        override var legend: Legend? = LegendCode.HAIL_THREAT.getLegend()
    }

    class HailThreatsTracks(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.HAIL_THREATS_TRACKS
        override val source: VectorSourceDescriptor = WeatherSource.severe_hail_threats(service)
        override val layer: LineLayerDescriptor = LineLayerDescriptor(
            "severe.hail.threats.line",
            source.id,
            filter = Expression.contains(
                Expression.geometryType,
                listOf(
                    "LineString",
                    "MultiLineString",
                ),
            ),
            paint = LineLayerPaint(
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#520BAE")),
                ),
            ),
        )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class LightningAll(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.LIGHTNING_ALL
        override val layers = listOf(
            LightningFlash(service),
            LightningStrikes(service),
        )
    }

    class LightningAllIcons(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.LIGHTNING_ALL_ICONS
        override val layers = listOf(
            LightningFlash(service),
            LightningStrikesIcons(service),
        )
    }

    class LightningDensity(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY
        override val layers = listOf(
            LightningDensityUnitedStates(service),
            LightningDensityEurope(service),
            LightningDensityJapan(service),
            LightningDensityAustralia(service),
        )
    }

    class LightningDensityAustralia(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_AUSTRALIA
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_australia(service).apply {
                val sw = LatLon(-44.0, 114.0)
                val ne = LatLon(-9.0, 154.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.australia.all",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityCloudToGround(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND
        override val layers = listOf(
            LightningDensityCloudToGroundUnitedStates(service),
            LightningDensityCloudToGroundEurope(service),
            LightningDensityCloudToGroundJapan(service),
            LightningDensityCloudToGroundAustralia(service),
        )
    }

    class LightningDensityCloudToGroundAustralia(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND_AUSTRALIA
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_australia(service).apply {
                val sw = LatLon(-44.0, 114.0)
                val ne = LatLon(-9.0, 154.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.australia.cg",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityCloudToGroundEurope(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND_EUROPE
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_europe(service).apply {
                val sw = LatLon(23.0, -11.0)
                val ne = LatLon(72.0, 45.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.europe.cg",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityCloudToGroundJapan(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND_JAPAN
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_japan(service).apply {
                val sw = LatLon(24.0, 122.0)
                val ne = LatLon(45.0, 149.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.japan.cg",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityCloudToGroundUnitedStates(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND_UNITED_STATES
        override val source: EncodedSourceDescriptor = WeatherSource.severe_lightning_LGT_IC_LGT_CG_us(service).apply {
            val sw = LatLon(24.0, -127.0)
            val ne = LatLon(57.0, -59.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.us.cg",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityEurope(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_EUROPE
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_europe(service).apply {
                val sw = LatLon(23.0, -11.0)
                val ne = LatLon(72.0, 45.0)

                //val sw = LatLon(23.0, -11.0) //original
                //val ne = LatLon(72.0, 46.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.europe.all",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityIntracloud(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_INTRACLOUD
        override val layers = listOf(
            LightningDensityIntracloudUnitedStates(service),
            LightningDensityIntracloudEurope(service),
            LightningDensityIntracloudJapan(service),
            LightningDensityIntracloudAustralia(service),
        )
    }

    class LightningDensityIntracloudAustralia(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_INTRACLOUD_AUSTRALIA
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_australia(service).apply {
                val sw = LatLon(-44.0, 114.0)
                val ne = LatLon(-9.0, 154.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.australia.ic",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityIntracloudEurope(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_INTRACLOUD_EUROPE
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_europe(service).apply {
                val sw = LatLon(23.0, -11.0)
                val ne = LatLon(72.0, 45.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.europe.ic",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityIntracloudJapan(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_INTRACLOUD_JAPAN
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_japan(service).apply {
                val sw = LatLon(24.0, 122.0)
                val ne = LatLon(46.0, 149.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.japan.ic",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityIntracloudUnitedStates(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_INTRACLOUD_UNITED_STATES
        override val source: EncodedSourceDescriptor = WeatherSource.severe_lightning_LGT_IC_LGT_CG_us(service).apply {
            val sw = LatLon(24.0, -127.0)
            val ne = LatLon(57.0, -59.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.us.ic",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.green),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityJapan(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_JAPAN
        override val source: EncodedSourceDescriptor =
            WeatherSource.severe_lightning_LGT_IC_LGT_CG_japan(service).apply {
                val sw = LatLon(24.0, 122.0)
                val ne = LatLon(46.0, 149.0)
                bounds = MapBounds(
                    MapCoordinate(sw, LatitudeLongitude()),
                    MapCoordinate(ne, LatitudeLongitude()),
                )
            }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.japan.all",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningDensityUnitedStates(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_DENSITY_UNITED_STATES
        override val source: EncodedSourceDescriptor = WeatherSource.severe_lightning_LGT_IC_LGT_CG_us(service).apply {
            val sw = LatLon(24.0, -127.0)
            val ne = LatLon(57.0, -59.0)
            bounds = MapBounds(
                MapCoordinate(sw, LatitudeLongitude()),
                MapCoordinate(ne, LatitudeLongitude()),
            )
        }
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "severe.lightning.density.us.all",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    drawRange = 0.1..10.0,
                    colorScale = ColorScaleOptions(
                        ColorScales.lightningDensity.stops,
                        range = 0.0..10.0,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.LIGHTNING_DENSITY]

        init {
            legend = LegendCode.LIGHTNING_DENSITY.getLegend()
        }
    }

    class LightningFlash(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_FLASH
        override val source: VectorSourceDescriptor = WeatherSource.severe_lightning_flash(service)
        override val layer: CircleLayerDescriptor = CircleLayerDescriptor(
            "severe.lightning_flash.circle",
            source.id,
            paint = CircleLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Constant(toColor("#999")),
                ),
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#333")),
                    thickness = StyleValue.Constant(1.0),
                ),
                circle = CirclePaint(
                    radius = StyleValue.Constant(2.0),
                ),
            ),
        )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class LightningStrikes(val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_STRIKES
        override val source: VectorSourceDescriptor = WeatherSource.severe_lightning(service)
        override val layer: CircleLayerDescriptor = CircleLayerDescriptor(
            "severe.lightning.circle",
            source.id,
            paint = CircleLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Expression(
                        Expression.step(
                            Expression.get("age"),
                            ColorScales.lightningStrike.toExpressionSteps(),
                        ),
                    ),
                ),
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#333")),
                    thickness = StyleValue.Constant(2.0),
                ),
                circle = CirclePaint(
                    radius = StyleValue.Constant(3.0),
                ),
            ),
        )
        override var presentation: Presentation? = null

        init {
            legend = LegendCode.LIGHTNING.getLegend()
        }
    }

    class LightningStrikesHeat(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> {
        override val code: LayerCode = LayerCode.LIGHTNING_STRIKES_HEAT
        override val source: VectorSourceDescriptor = WeatherSource.severe_lightning(service)
        override val layer: HeatmapLayerDescriptor = HeatmapLayerDescriptor(
            "severe.lightning.heat",
            source.id,
            paint = HeatmapLayerPaint(
                heatmap = HeatmapPaint(
                    color = StyleValue.Expression(
                        Expression.interpolate(
                            listOf("heatmap-density"), stops = ColorScales.heatmap.stops
                        ),
                    ),
                    radius = StyleValue.Constant(20.0),
                ),
            ),
        )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class LightningStrikesIcons(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.LIGHTNING_STRIKES_ICONS
        override val source: VectorSourceDescriptor = WeatherSource.severe_lightning(service)
        override val layer: SymbolLayerDescriptor = SymbolLayerDescriptor(
            "severe.lightning.symbol",
            source.id,
            paint = SymbolLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Expression(
                        Expression.step(
                            Expression.get("age"),
                            ColorScales.lightningStrike.toExpressionSteps(),
                        ),
                    ),
                ),
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#333")),
                    thickness = StyleValue.Constant(0.5),
                ),
                icon = IconPaint(
                    allowOverlap = StyleValue.Constant(true),
                    image = StyleValue.Constant("mapsgl:lightning-bolt"),
                    size = StyleValue.Constant(0.28),
                ),
            ),
        )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class LightningThreats(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.LIGHTNING_THREATS
        override val layers = listOf(
            LightningThreatsPolygons(service),
            LightningThreatsTracks(service),
            LightningThreatsPoints(service),
        )
    }

    class LightningThreatsPoints(val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LIGHTNING_THREATS_POINTS
        override val source: VectorSourceDescriptor = WeatherSource.severe_lightning_threats(service)
        override val layer: CircleLayerDescriptor = CircleLayerDescriptor(
            "severe.lightning.threats.circle",
            source.id,
            filter = Expression.contains(Expression.geometryType, listOf("Point")),
            paint = CircleLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Constant(toColor("#DE2900")),
                ),
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#fff")),
                    thickness = StyleValue.Constant(1.0),
                ),
                circle = CirclePaint(
                    radius = StyleValue.Constant(2.0),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.THREAT]?.setTitle("Lightning Threat")
        override var legend: Legend? = null
    }

    class LightningThreatsPolygons(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.LIGHTNING_THREATS_POLYGONS
        override val source: VectorSourceDescriptor = WeatherSource.severe_lightning_threats(service)
        override val layer: FillLayerDescriptor = FillLayerDescriptor(
            "severe.lightning.threats.fill",
            source.id,
            filter = Expression.contains(
                Expression.geometryType,
                listOf(
                    "Polygon",
                    "MultiPolygon",
                ),
            ),
            paint = FillLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Expression(
                        Expression.step(
                            Expression.floor(
                                Expression.divide(
                                    Expression.subtract(
                                        Expression.get("period.range.minTimestamp"),
                                        Expression.get("details.issuedTimestamp"),
                                    ),
                                    60,
                                ),
                            ),
                            ColorScales.lightningThreat.toExpressionSteps(),
                        ),
                    ),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.THREAT]?.setTitle("Lightning Threat")
        override var legend: Legend? = LegendCode.LIGHTNING_THREAT.getLegend()
    }

    class LightningThreatsTracks(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.LIGHTNING_THREATS_TRACKS
        override val source: VectorSourceDescriptor = WeatherSource.severe_lightning_threats(service)
        override val layer: LineLayerDescriptor = LineLayerDescriptor(
            "severe.lightning.threats.line",
            source.id,
            filter = Expression.and(
                listOf(
                    Expression.contains(
                        Expression.geometryType,
                        listOf(
                            "LineString",
                            "MultiLineString",
                        ),
                    ),
                    Expression.equals(Expression.get("details.movement.reliability"), "HIGH"),
                    Expression.greaterThan(Expression.get("details.totalPeriods"), 1),
                ),
            ),
            paint = LineLayerPaint(
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#DE2900")),
                ),
            ),
        )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class Stormcells(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.STORMCELLS
        override val layers = listOf(
            StormcellsCones(service),
            StormcellsTracks(service),
            StormcellsPositions(service),
        )
    }

    class StormcellsCones(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.STORMCELLS_CONES
        override val source: VectorSourceDescriptor = WeatherSource.severe_stormcells(service)
        override val layer: FillLayerDescriptor = FillLayerDescriptor(
            "severe.stormcells.cone.line",
            source.id,
            filter = Expression.equals(Expression.geometryType, "Polygon"),
            paint = FillLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Expression(
                        Expression.match(
                            Expression.downcase(Expression.get("traits.type")),
                            ColorScales.stormcell.toExpressionSteps(),
                            "#999999",
                        ),
                    ),
                    opacity = StyleValue.Constant(0.5),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.STORM_CELL]
        override var legend: Legend? = LegendCode.STORM_CELL.getLegend()
    }

    class StormcellsHeat(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> {
        override val code: LayerCode = LayerCode.STORMCELLS_HEAT
        override val source: VectorSourceDescriptor = WeatherSource.severe_stormcells(service)
        override val layer: HeatmapLayerDescriptor = HeatmapLayerDescriptor(
            "severe.stormcells.heat",
            source.id,
            filter = Expression.equals(Expression.geometryType, "Point"),
            paint = HeatmapLayerPaint(
                heatmap = HeatmapPaint(
                    color = StyleValue.Expression(
                        Expression.interpolate(
                            listOf("heatmap-density"), stops = ColorScales.heatmap.stops
                        ),
                    ),
                    radius = StyleValue.Constant(20.0),
                ),
            ),
        )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class StormcellsPositions(val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.STORMCELLS_POSITIONS
        override val source: VectorSourceDescriptor = WeatherSource.severe_stormcells(service)
        override val layer: CircleLayerDescriptor = CircleLayerDescriptor(
            "severe.stormcells.position.circle",
            source.id,
            filter = Expression.equals(Expression.geometryType, "Point"),
            paint = CircleLayerPaint(
                fill = FillPaint(
                    color = StyleValue.Expression(
                        Expression.match(
                            Expression.downcase(Expression.get("traits.type")),
                            ColorScales.stormcell.toExpressionSteps(),
                            "#999999",
                        ),
                    ),
                ),
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#fff")),
                    thickness = StyleValue.Constant(3.0),
                ),
                circle = CirclePaint(
                    radius = StyleValue.Constant(3.0),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.STORM_CELL]

        init {
            legend = LegendCode.STORM_CELL.getLegend()
        }
    }

    class StormcellsTracks(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.STORMCELLS_TRACKS
        override val source: VectorSourceDescriptor = WeatherSource.severe_stormcells(service)
        override val layer: LineLayerDescriptor = LineLayerDescriptor(
            "severe.stormcells.track.line",
            source.id,
            filter = Expression.equals(Expression.geometryType, "LineString"),
            paint = LineLayerPaint(
                stroke = StrokePaint(
                    color = StyleValue.Constant(toColor("#fff")),
                    thickness = StyleValue.Constant(3.0),
                ),
            ),
        )
        override var presentation = presentations[PresentationType.STORM_CELL]
        override var legend: Legend? = null
    }

    class Stormreports(val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.STORMREPORTS
        override val source: VectorSourceDescriptor = WeatherSource.severe_stormreports(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "severe.stormreports.circle",
                source.id,
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.downcase(Expression.get("report.cat")),
                                            ColorScales.stormreport.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(3.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.STORM_REPORT]

        init {
            legend = LegendCode.STORM_REPORT.getLegend()
        }
    }

    class StormreportsHeat(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> {
        override val code: LayerCode = LayerCode.STORMREPORTS_HEAT
        override val source: VectorSourceDescriptor = WeatherSource.severe_stormreports(service)
        override val layer: HeatmapLayerDescriptor = HeatmapLayerDescriptor(
            "severe.stormreports.heat",
            source.id,
            paint = HeatmapLayerPaint(
                heatmap = HeatmapPaint(
                    color = StyleValue.Expression(
                        Expression.interpolate(
                            listOf("heatmap-density"), stops = ColorScales.heatmap.stops
                        ),
                    ),
                    radius = StyleValue.Constant(20.0),
                ),
            ),
        )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }
}
