//
//  AirQuality.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2025-10-22T18:06:35.558Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.LegendCode
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations
import com.xweather.mapsgl.weather.toColor

object AirQuality {
    class AirQuality(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY
        override val source: VectorSourceDescriptor = WeatherSource.airquality_points(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "air_quality.point",
                source.id,
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.downcase(Expression.get("periods.0.category")),
                                            ColorScales.airQuality.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class CarbonMonoxide(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.CARBON_MONOXIDE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_CO_NO_NO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.co.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale = ColorScaleOptions(
                                    ColorScales.co.stops,
                                )
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("CO")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_CO.getLegend()
        }

    }

    class AirQualityHealthIndexCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_HEALTH_INDEX_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AQHI_AQI_China_AQI_India(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.aqhi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityHealthIndexCategories.stops,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQHI")

        init {
            legend = LegendCode.AIR_QUALITY_HEALTH_INDEX.getLegend()
        }
    }

    class AirQualityIndex(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AirNow_PM2P5_PM10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.index.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#29e11f")),
                                            ColorStop(25.0, toColor("#29e11f")),
                                            ColorStop(75.0, toColor("#f8f92a")),
                                            ColorStop(125.0, toColor("#f9681b")),
                                            ColorStop(175.0, toColor("#f60115")),
                                            ColorStop(251.0, toColor("#7a2c83")),
                                            ColorStop(301.0, toColor("#65001b")),
                                            ColorStop(500.0, toColor("#65001b")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI")
        override var legend: Legend? = LegendCode.AIR_QUALITY_INDEX.getLegend()
    }

    class AirQualityIndexCaiCategories(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_CAI_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_CAI_AQI_CAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.cai.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#0000ff")),
                                            ColorStop(51.0, toColor("#00ff00")),
                                            ColorStop(101.0, toColor("#ffff00")),
                                            ColorStop(251.0, toColor("#ff0000")),
                                        ),
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("CAI")
        override var legend: Legend? = LegendCode.AIR_QUALITY_INDEX_CAI.getLegend()
    }

    class AirQualityIndexCaqiCategories(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_CAQI_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_CAI_AQI_CAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.caqi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#79bc6a")),
                                            ColorStop(26.0, toColor("#bbcf4c ")),
                                            ColorStop(51.0, toColor("#eec20b")),
                                            ColorStop(76.0, toColor("#f29305")),
                                            ColorStop(101.0, toColor("#e8416f")),
                                        ),
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("CAQI")
        override var legend: Legend? = LegendCode.AIR_QUALITY_INDEX_CAQI.getLegend()
    }

    class AirQualityIndexCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AirNow_PM2P5_PM10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.index_categories.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#29e11f")),
                                            ColorStop(51.0, toColor("#f8f92a")),
                                            ColorStop(101.0, toColor("#f9681b")),
                                            ColorStop(151.0, toColor("#f60115")),
                                            ColorStop(200.0, toColor("#7a2c83")),
                                            ColorStop(301.0, toColor("#65001b")),
                                        ),
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI")

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_CATEGORIES.getLegend()
        }
    }

    class AirQualityIndexChinaCategories(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_CHINA_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AQHI_AQI_China_AQI_India(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.china.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#00ff00")),
                                            ColorStop(51.0, toColor("#ffff00")),
                                            ColorStop(101.0, toColor("#ff9900")),
                                            ColorStop(151.0, toColor("#ff0000")),
                                            ColorStop(201.0, toColor("#540099")),
                                            ColorStop(301.0, toColor("#800000")),
                                        ),
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI (China)")
        override var legend: Legend? = LegendCode.AIR_QUALITY_INDEX_CHINA.getLegend()
    }

    class AirQualityIndexEaqiCategories(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_EAQI_CATEGORIES
        override val source: EncodedSourceDescriptor =
            WeatherSource.airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.eaqi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#50f0e6")),
                                            ColorStop(26.0, toColor("#50ccaa")),
                                            ColorStop(51.0, toColor("#f0e641")),
                                            ColorStop(76.0, toColor("#ff5050")),
                                            ColorStop(101.0, toColor("#960032")),
                                            ColorStop(126.0, toColor("#7d2181")),
                                        ),
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI (EAQI)")
        override var legend: Legend? = LegendCode.AIR_QUALITY_INDEX_EAQI.getLegend()
    }

    class AirQualityIndexIndiaCategories(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_INDIA_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AQHI_AQI_China_AQI_India(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.india.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#00cc00")),
                                            ColorStop(51.0, toColor("#66cc00")),
                                            ColorStop(101.0, toColor("#ffff00")),
                                            ColorStop(201.0, toColor("#ff9900")),
                                            ColorStop(301.0, toColor("#ff0000")),
                                            ColorStop(401.0, toColor("#a52a2a")),
                                        ),
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI (India)")
        override var legend: Legend? = LegendCode.AIR_QUALITY_INDEX_INDIA.getLegend()
    }

    class AirQualityIndexUbaDaqiCategories(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_CATEGORIES
        override val source: EncodedSourceDescriptor =
            WeatherSource.airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.uba_daqi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#50f0e6")),
                                            ColorStop(26.0, toColor("#50cdaa")),
                                            ColorStop(51.0, toColor("#f0e641")),
                                            ColorStop(76.0, toColor("#ff5050")),
                                            ColorStop(101.0, toColor("#960032")),
                                        ),
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("UBA DAQI")
        override var legend: Legend? = null
    }

    class AirQualityIndexUkDaqiCategories(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_UK_DAQI_CATEGORIES
        override val source: EncodedSourceDescriptor =
            WeatherSource.airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.uk_daqi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#009900")),
                                            ColorStop(1.5, toColor("#ff9900")),
                                            ColorStop(4.5, toColor("#ff0000")),
                                            ColorStop(7.5, toColor("#990099")),
                                        ),
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("UK DAQI")
        override var legend: Legend? = null
    }

    class NitricOxide(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.NITRIC_OXIDE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_CO_NO_NO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.no.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale = ColorScaleOptions(
                                    ColorScales.no.stops,
                                )
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("NO")
        override var legend: Legend? = LegendCode.AIR_QUALITY_NO.getLegend()
    }

    class NitrogenDioxide(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.NITROGEN_DIOXIDE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_CO_NO_NO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.no2.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.no2.stops,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("NO2")
        override var legend: Legend? = LegendCode.AIR_QUALITY_NO2.getLegend()
    }

    class Ozone(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.OZONE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_O3_SO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.o3.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.o3.stops,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("O3")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_O3.getLegend()

        }
    }

    class ParticulateMatter10Micron(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.PARTICULATE_MATTER_10_MICRON
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AirNow_PM2P5_PM10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.pm10.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.pm10.stops
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("PM10")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_PM10.getLegend()
        }
    }

    class ParticulateMatter2p5Micron(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.PARTICULATE_MATTER_2P5_MICRON
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AirNow_PM2P5_PM10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.pm2p5.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.pm25.stops
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("PM2.5")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_PM2P5.getLegend()
        }
    }

    class SulfurDioxide(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SULFUR_DIOXIDE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_O3_SO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.so2.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.so2.stops,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("SO2")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_SO2.getLegend()
        }
    }
}
