//
//  Maritime.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2025-10-22T18:06:35.570Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.LegendCode
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.ParticleDensity
import com.xweather.mapsgl.style.ParticleKind
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.ParticlePaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations
import com.xweather.mapsgl.weather.toColor

object Maritime {
    class OceanCurrents(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.OCEAN_CURRENTS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_WTMP_UOGRD_VOGRD(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.ocean_current.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.VECTOR,
                                channel = listOf(ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.oceanCurrent.stops,
                                        range = 0.0..3.0864,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WIND_SPEED]?.setTitle("Ocean Current")

        init {
            legend = LegendCode.OCEAN_CURRENT.getLegend()
        }
    }

    class OceanCurrentsParticles(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<ParticleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.OCEAN_CURRENTS_PARTICLES
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_WTMP_UOGRD_VOGRD(service)
        override val layer: ParticleLayerDescriptor =
            ParticleLayerDescriptor(
                "maritime.ocean_current.particle",
                source.id,
                quality = DataQuality.exact,
                mask = MaskLayerKind.LAND,
                paint =
                    ParticleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.VECTOR,
                                channel = listOf(ColorBand.green, ColorBand.blue),
                                interpolation = InterpolationMode.BILINEAR,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.oceanCurrent.stops,
                                        range = 0.0..3.0864,
                                        interval = 0.0,
                                    ),
                            ),
                        particle =
                            ParticlePaint(
                                density = ParticleDensity.NORMAL,
                                size = Size(2, 2),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WIND_SPEED]?.setTitle("Ocean Current")

        init {
            legend = LegendCode.OCEAN_CURRENT.getLegend()
        }
    }

    class SeaSurfaceTemperatures(val service: WeatherService) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.SEA_SURFACE_TEMPERATURES
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_WTMP_UOGRD_VOGRD(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.sst.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.temperature.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.TEMPERATURE]?.setTitle("Sea Surface Temp")

        init {
            legend = LegendCode.TEMPERATURE.getLegend()
        }
    }

    class StormSurge(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.STORM_SURGE
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SURGE_TIDE(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.storm_surge.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.stormSurge.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.HEIGHT]?.setTitle("Storm Surge")

        init {
            legend = LegendCode.STORM_SURGE.getLegend()
        }
    }

    class SwellHeights(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL_HEIGHTS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL1_SWPER1_SWDIR1(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.swell_height.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.waveHeight.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.HEIGHT]?.setTitle("Swell Height")
        override var legend: Legend? = null
    }

    class SwellParticles(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL_PARTICLES
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL1_SWPER1_SWDIR1(service)
        override val layer: ParticleLayerDescriptor =
            ParticleLayerDescriptor(
                "maritime.swell_dir.particle",
                source.id,
                quality = DataQuality.exact,
                mask = MaskLayerKind.LAND,
                paint =
                    ParticleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.ANGLE,
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BILINEAR,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#ffffff")),
                                            ColorStop(1.0, toColor("#ffffff")),
                                        ),
                                        range = 0.0..359.0,
                                        interval = 0.0,
                                        normalized = true,
                                    ),
                            ),
                        particle =
                            ParticlePaint(
                                kind = ParticleKind.BAR,
                                size = Size(8, 1),
                                trailsFade = 0.94,
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.DIRECTION]?.setTitle("Swell Direction")
        override var legend: Legend? = null
    }

    class SwellPeriods(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL_PERIODS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL1_SWPER1_SWDIR1(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.swell_period.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.wavePeriod.stops,
                                        interval = 1.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PERIOD]?.setTitle("Swell Period")
        override var legend: Legend? = null
    }

    class Swell2Heights(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL2_HEIGHTS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL2_SWPER2_SWDIR2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.swell2_height.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.waveHeight.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.HEIGHT]?.setTitle("Swell 2 Height")
        override var legend: Legend? = null
    }

    class Swell2Particles(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL2_PARTICLES
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL2_SWPER2_SWDIR2(service)
        override val layer: ParticleLayerDescriptor =
            ParticleLayerDescriptor(
                "maritime.swell2_dir.particle",
                source.id,
                quality = DataQuality.exact,
                mask = MaskLayerKind.LAND,
                paint =
                    ParticleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.ANGLE,
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BILINEAR,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#ffffff")),
                                            ColorStop(1.0, toColor("#ffffff")),
                                        ),
                                        range = 0.0..359.0,
                                        interval = 0.0,
                                        normalized = true,
                                    ),
                            ),
                        particle =
                            ParticlePaint(
                                kind = ParticleKind.BAR,
                                size = Size(8, 1),
                                trailsFade = 0.94,
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.DIRECTION]?.setTitle("Swell 2 Direction")
        override var legend: Legend? = null
    }

    class Swell2Periods(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL2_PERIODS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL2_SWPER2_SWDIR2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.swell2_period.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.wavePeriod.stops,
                                        interval = 1.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PERIOD]?.setTitle("Swell 2 Period")
        override var legend: Legend? = null
    }

    class Swell3Heights(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL3_HEIGHTS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL3_SWPER3_SWDIR3(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.swell3_height.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.waveHeight.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.HEIGHT]?.setTitle("Swell 3 Height")
        override var legend: Legend? = null
    }

    class Swell3Particles(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL3_PARTICLES
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL3_SWPER3_SWDIR3(service)
        override val layer: ParticleLayerDescriptor =
            ParticleLayerDescriptor(
                "maritime.swell3_dir.particle",
                source.id,
                quality = DataQuality.exact,
                mask = MaskLayerKind.LAND,
                paint =
                    ParticleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.ANGLE,
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BILINEAR,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#ffffff")),
                                            ColorStop(1.0, toColor("#ffffff")),
                                        ),
                                        range = 0.0..359.0,
                                        interval = 0.0,
                                        normalized = true,
                                    ),
                            ),
                        particle =
                            ParticlePaint(
                                kind = ParticleKind.BAR,
                                size = Size(8, 1),
                                trailsFade = 0.94,
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.DIRECTION]?.setTitle("Swell 3 Direction")
        override var legend: Legend? = null
    }

    class Swell3Periods(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.SWELL3_PERIODS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SWELL3_SWPER3_SWDIR3(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.swell3_period.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.wavePeriod.stops,
                                        interval = 1.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PERIOD]?.setTitle("Swell 3 Period")
        override var legend: Legend? = null
    }

    class TideHeights(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.TIDE_HEIGHTS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_SURGE_TIDE(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.tide_height.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.tideHeight.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.HEIGHT_CHANGE]?.setTitle("Tide Height")

        init {
            legend = LegendCode.TIDE_HEIGHT.getLegend()
        }
    }

    class WaveHeights(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WAVE_HEIGHTS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_HTSGW_DIRPW_PERPW(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.wave_height.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.waveHeight.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.HEIGHT]?.setTitle("Wave Height")

        init {
            legend = LegendCode.WAVE_HEIGHT.getLegend()
        }
    }

    class WaveParticles(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<ParticleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WAVE_PARTICLES
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_HTSGW_DIRPW_PERPW(service)
        override val layer: ParticleLayerDescriptor =
            ParticleLayerDescriptor(
                "maritime.wave_dir.particle",
                source.id,
                quality = DataQuality.exact,
                mask = MaskLayerKind.LAND,
                paint =
                    ParticleLayerPaint(
                        sample =
                            SamplePaint(
                                expression = SampleExpression.ANGLE,
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BILINEAR,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("#ffffff")),
                                            ColorStop(1.0, toColor("#ffffff")),
                                        ),
                                        range = 0.0..359.0,
                                        interval = 0.0,
                                        normalized = true,
                                    ),
                            ),
                        particle =
                            ParticlePaint(
                                kind = ParticleKind.BAR,
                                size = Size(8, 1),
                                trailsFade = 0.94,
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.DIRECTION]?.setTitle("Wave Direction")

        init {
            legend = LegendCode.WIND_SPEED.getLegend()
        }
    }

    class WavePeriods(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        override val code: LayerCode = LayerCode.WAVE_PERIODS
        override val source: EncodedSourceDescriptor = WeatherSource.maritime_HTSGW_DIRPW_PERPW(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "maritime.wave_period.fill",
                source.id,
                quality = DataQuality.high,
                mask = MaskLayerKind.LAND,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.wavePeriod.stops,
                                        interval = 1.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.PERIOD]?.setTitle("Wave Period")
        override var legend: Legend? = null
    }
}
