package com.xweather.mapsgl.utils

import com.xweather.mapsgl.gl.extensions.pr
import java.util.*
import kotlin.collections.HashMap

/**
 * Adapted from js version which was adapted from Lumo: https://github.com/unchartedsoftware/lumo
 * Copyright (c) 2016-2019 Uncharted Software Inc.
 * Copyrights licensed under the MIT License.
 **/

// LRUCache via LinkedList
// https://medium.com/dsinjs/implementing-lru-cache-in-javascript-94ba6755cda9
// https://github.com/Brokerloop/ttlcache/blob/master/src/index.ts
// https://dev.to/glebirovich/typescript-data-structures-linked-list-3o8i


interface Entry<String, V> {
    val key: String
    var value: V
    var expiration: Long
    var node: LinkedListNode<Entry<String, V>>?
}

interface LRUCacheConfig<String, V> {
    val capacity: Int
    val ttl: Long
    val onRemove: ((key: String, value: V) -> Unit)?
}

class LinkedListNode<T>(var value: T) {
    var prev: LinkedListNode<T>? = null
    var next: LinkedListNode<T>? = null
}

class LinkedList<T> {
    var head: LinkedListNode<T>? = null
    var tail: LinkedListNode<T>? = null

    fun unshift(value: T): LinkedListNode<T> {
        val newNode = LinkedListNode(value)
        if (head == null) {
            head = newNode
            tail = newNode
        } else {
            newNode.next = head
            head?.prev = newNode
            head = newNode
        }
        return newNode
    }

    fun unshiftNode(node: LinkedListNode<T>) {
        removeNode(node)
        node.next = head
        head?.prev = node
        head = node
        if (tail == null) {
            tail = node;
        }
    }

    fun pop(): T {
        if (tail == null) {
            throw EmptyStackException()
        }

        val value = tail!!.value;
        removeNode(tail!!)
        return value
    }

    fun removeNode(node: LinkedListNode<T>) {
        if (node == head) {
            head = node.next
        }
        if (node == tail) {
            tail = node.prev
        }

        node.prev?.next = node.next
        node.next?.prev = node.prev

        node.next = null
        node.prev = null
    }


    fun clear() {
        head = null
        tail = null
    }


    fun items(): Sequence<LinkedListNode<T>> {
        return sequence {
            var current = head
            while (current != null) {
                yield(current)
                current = current.next
            }
        }
    }
}

/*
*     val capacity: Int
    val ttl: Long
    val onRemove: ((key: K, value: V) -> Unit)?
* */

class LRUCache<String, V>(
    var capacity: Int,
    val ttl: Long,
    val onRemove: ((key: String, value: V) -> Unit)?,
    /*config: LRUCacheConfig<String, V>? = null*/
) : MutableMap<String, V> {
    //var capacity: Int = config?.capacity ?: 20
    //private set
    //private val _ttl: Long = config?.ttl ?: 0
    private val _cache: MutableMap<String, LinkedListNode<Entry<String, V>>> = HashMap()
    private val _list: LinkedList<Entry<String, V>> = LinkedList()
    //override val entries: MutableSet<MutableMap.MutableEntry<String, V>>
    //   get() = TODO("Not yet implemented")

    override val entries: MutableSet<MutableMap.MutableEntry<String, V>>
        get() = object : AbstractMutableSet<MutableMap.MutableEntry<String, V>>() {
            override fun iterator(): MutableIterator<MutableMap.MutableEntry<String, V>> {
                val iterator = _list.items().iterator()
                return object : MutableIterator<MutableMap.MutableEntry<String, V>> {
                    override fun hasNext(): Boolean = iterator.hasNext()
                    override fun next(): MutableMap.MutableEntry<String, V> {
                        val node = iterator.next()
                        val entry = node.value
                        return object : MutableMap.MutableEntry<String, V> {
                            override val key: String = entry.key as String
                            override var value: V = entry.value
                            override fun setValue(newValue: V): V {
                                val oldValue = value
                                entry.value = newValue
                                return oldValue
                            }
                        }
                    }

                    override fun remove() {
                        TODO("Not yet implemented")
                    }
                }
            }

            override fun add(element: MutableMap.MutableEntry<String, V>): Boolean {
                TODO("Not yet implemented")
            }

            override val size: Int
                get() = _cache.size

            override fun clear() {
                this@LRUCache.clear()
            }
        }


    override val keys: MutableSet<String>
        get() = keys().toMutableSet()
    //private val _onRemove: ((key: K, value: V) -> Unit)? = config?.onRemove

    override val size: Int
        get() = _cache.size
    override val values: MutableCollection<V>
        get() = values().toMutableSet()

    val cache: Map<String, LinkedListNode<Entry<String, V>>>
        get() = _cache

    val first: V?
        get() = _list.head?.value?.value

    val last: V?
        get() = _list.tail?.value?.value

    fun keys(): Sequence<String> = _list.items().map { it.value.key }

    fun values(): Sequence<V> = _list.items().map { it.value.value }

    fun entries(): Sequence<Pair<String, V>> = _list.items().map { Pair(it.value.key, it.value.value) }

    init {
        this.capacity = Math.max(1, capacity)
    }

    fun has(key: String): Boolean {
        return _cache.containsKey(key)
    }

    override fun get(key: String): V? {
        val node = _cache[key]

        if (node == null) {
            return null
        }

        if (_isExpired(node.value)) {
            if(pr.ON) pr.p("LRU", pr.lruDelete, "get() deleting ${node.value.key}")
            //delete(node.value.key)

            return null
        }

        _bumpAge(node.value)
        return node.value.value

    }

    fun peek(key: String): V? {
        return _cache[key]?.value?.value
    }

    operator fun set(key: String, value: V) {
        val existingNode = _cache[key]

        if (existingNode != null) {
            val entry = existingNode.value
            if (entry.value != value) {
                onRemove?.invoke(entry.key, entry.value)
                entry.value = value
            }
            _bumpAge(entry)
            return
        }

        val entry = object : Entry<String, V> {
            override val key: String = key
            override var value: V = value
            override var expiration: Long = Date().time + ttl
            override var node: LinkedListNode<Entry<String, V>>? = null
        }

        val node = _list.unshift(entry)
        _cache[key] = node
        entry.node = node

        if (_cache.size > capacity) {
            val nodeToEvict = _list.pop()
            if(pr.ON) pr.p("LRU", pr.lruDelete, "evict() ${nodeToEvict.key}")
            //delete(nodeToEvict.key)
        }
    }

    fun delete(key: String): V? {
        val node = _cache[key] ?: return null
        val entry = node.value
        if(pr.ON) pr.p("LRU", pr.lruDelete, "delete() ${entry.key}")
        onRemove?.invoke(entry.key, entry.value)
        _cache.remove(key)
        _list.removeNode(node)
        return entry.value
    }

    override fun clear() {
        forEach { entry ->
            onRemove?.invoke(entry.key, entry.value)
        }
        _cache.clear()
        _list.clear()
    }

    override fun isEmpty(): Boolean {
        TODO("Not yet implemented")
    }

    override fun remove(key: String): V? {
        return delete(key)
    }

    override fun putAll(from: Map<out String, V>) {
        for ((key, value) in from) {
            set(key, value) // Use our set logic which handles capacity and LRU
        }
    }

    override fun put(key: String, value: V): V? {
        val existingNode = _cache[key]
        val oldValue = if (existingNode != null && !_isExpired(existingNode.value)) {
            existingNode.value.value
        } else {
            null
        }
        set(key, value) // Use our set logic
        return oldValue // Return the previous value, or null if new/expired
    }

    override fun containsValue(value: V): Boolean {
        TODO("Not yet implemented")
    }

    override fun containsKey(key: String): Boolean {
        return _cache.containsKey(key)
    }

    fun forEach(fn: (entry: Entry<String, V>) -> Unit) {
        _cache.values.forEach { node ->
            fn(node.value)
        }
    }

    private fun _bumpAge(entry: Entry<String, V>) {
        entry.expiration = Date().time + ttl
        entry.node?.let { _list.unshiftNode(it) }
    }

    private fun _isExpired(entry: Entry<String, V>): Boolean {
        return if (ttl > 0) {
            entry.expiration < Date().time
        } else false
    }
}