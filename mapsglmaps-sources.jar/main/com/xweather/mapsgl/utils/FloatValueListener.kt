package com.xweather.mapsgl.utils


import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope

class FloatValueListener : ViewModel() {

    private val _floatValue = MutableStateFlow(0.0f)  // Initial value
    val floatValue: StateFlow<Float> = _floatValue.asStateFlow() // Expose read-only StateFlow

    fun setFloatValue(newValue: Float) {
        _floatValue.value = newValue
    }

    // Example of observing changes using Flow (in a ViewModel or other lifecycle-aware component)
    init {
        viewModelScope.launch {
            floatValue.collect { newValue ->
                // This code will be executed every time floatValue changes
                println("Float value changed to: $newValue")
                // Perform other actions here, like updating UI, saving to database, etc.
            }
        }
    }
}