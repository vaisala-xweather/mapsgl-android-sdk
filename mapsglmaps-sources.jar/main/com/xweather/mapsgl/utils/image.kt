import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.sources.DataPool
import com.xweather.mapsgl.types.Size

data class ImageRepresentable(
    val width: Int,
    val height: Int,
    val data: ByteArray?
)

fun copyImage(
    src: ImageRepresentable,
    dest: ImageRepresentable,
    sx: Int,
    sy: Int,
    tx: Int,
    ty: Int,
    size: Size,
    channels: Int = 4
): ImageRepresentable {
    if (size.width == 0 || size.height == 0) {
        //println("image copyImage() p4  size.width == 0 || size.height == 0")
        return dest
    }

    if (size.width > src.width
        || size.height > src.height
        || sx > src.width - size.width
        || sy > src.height - size.height
    ) {
        throw Error("out of range source coordinates for image copy")
    }

    if (size.width > dest.width
        || size.height > dest.height
        || tx > dest.width - size.width
        || ty > dest.height - size.height
    ) {
        throw Error("out of range destination coordinates for image copy")
    }

    val srcData = src.data
    val dstData = dest.data

    if (srcData == dstData) throw Error("srcData equals dstData, so image is already copied")

    if (srcData != null) {
    }

    for (y in 0 until size.height) {
        val srcOffset = ((sy + y) * src.width + sx) * channels
        val dstOffset = ((ty + y) * dest.width + tx) * channels
        for (i in 0 until size.width * channels) {
            dstData!![dstOffset + i] = srcData!![srcOffset + i]
        }
    }
    if (dstData != null) {
    }
    return dest

}

fun padBitmap(bitmap: ByteArray, originalSize: Int, padding: Int): ByteArray {
    val paddedSize = originalSize + (padding + padding)
    val paddedBitmap: ByteArray

    if (false && DataPool.paddedEnabled) {
        while (DataPool.freepBBList.isEmpty()) {
            DataPool.freepBBList.add(ByteArray(paddedSize * paddedSize * 4))
        }

        val bBuffer = DataPool.freepBBList.removeAt(0)
        DataPool.usedBBList.add(bBuffer)
        paddedBitmap = bBuffer
    } else {
        paddedBitmap = ByteArray(paddedSize * paddedSize * 4)
        if (pr.ON) pr.p("Image", pr.dataPool, "padBitmap() bitmap.size: ${paddedBitmap.size}") //1065024
    }
    //if(pr.ON) pr.p("Image", pr.dataPool, "padBitmap() bitmap.size: ${paddedBitmap.size}") //1065024
    var srcIndex = 0
    var dstIndex = padding * (paddedSize * 4)

    val originalSizeX4 = originalSize * 4

    for (y in 0 until originalSize) {
        dstIndex += (padding * 4)
        System.arraycopy(bitmap, srcIndex, paddedBitmap, dstIndex, originalSizeX4)
        srcIndex += originalSizeX4
        dstIndex += originalSizeX4 + (padding * 4)
    }

    return paddedBitmap
}

fun padBitmapRadar(bitmap: ByteArray, originalSize: Int, padding: Int): ByteArray {
    val paddedSize = originalSize + (padding * 2)


    val paddedBitmap: ByteArray
    if (false && DataPool.paddedEnabled) {
        while (DataPool.freepBBList.isEmpty()) {
            if (pr.ON) pr.p("Image", pr.dataPool, "was empty, added buffer", 2) //1065024
            DataPool.freepBBList.add(ByteArray(paddedSize * paddedSize * 4))
        }

        val bBuffer = DataPool.freepBBList.removeAt(0)
        DataPool.usedBBList.add(bBuffer)
        paddedBitmap = bBuffer
    } else {
        paddedBitmap = ByteArray(paddedSize * paddedSize * 4)
    }


    //if(pr.ON) pr.p("Image", pr.dataPool, "padBitmapRadar() bitmap.size: ${paddedBitmap.size}") //1065024
    var srcIndex = 0
    var dstIndex = padding * (paddedSize * 4)
    val originalSizeX4 = originalSize * 4

    val byte1 = 1.toByte()
    val byte2 = 2.toByte()
    val byte3 = 3.toByte()

    for (y in 0 until originalSize) {
        dstIndex += (padding * 4)
        for (x in 0 until originalSizeX4 step 4) {

            paddedBitmap[dstIndex + x + 3] = bitmap[srcIndex + x]
            if (bitmap[x + srcIndex + 1] == byte1) paddedBitmap[dstIndex + x + 1] = 1 //green
            else if (bitmap[x + srcIndex + 1] == byte3) paddedBitmap[dstIndex + x] = 1 //red
            else if (bitmap[x + srcIndex + 1] == byte2) paddedBitmap[dstIndex + x + 2] = 1 //blue
        }
        //System.arraycopy(bitmap, srcIndex, paddedBitmap, dstIndex, originalSizeX4)
        srcIndex += originalSizeX4
        dstIndex += originalSizeX4 + (padding * 4)
    }

    return paddedBitmap
}