package com.xweather.mapsgl.utils

/**
 * Constrain a value to lie between two values.
 *
 * @param value
 * @param min
 * @param max
 * @return
 */
fun clamp(value: Double, min: Double, max: Double): Double {
    return value.coerceIn(min, max)
}

