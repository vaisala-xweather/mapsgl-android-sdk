package com.xweather.mapsgl.utils

import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.launch

class Signal<T> private constructor(
    private val flowInternal: Flow<T>,
    private val emitter: suspend (T) -> Unit,
    private val defaultScope: CoroutineScope? = null
) {
    val flow: Flow<T> get() = flowInternal

    fun send(value: T, scope: CoroutineScope? = null) {
        (scope ?: defaultScope)?.launch {
            emitter(value)
        } ?: error("No CoroutineScope provided to send()")
    }

    fun observe(
        scope: CoroutineScope? = null,
        onEach: suspend (T) -> Unit,
        onCompletion: ((Throwable?) -> Unit)? = null
    ): Job {
        return flow
            .onEach { onEach(it) }
            .onCompletion { cause -> onCompletion?.invoke(cause) }
            .launchIn(scope ?: defaultScope ?: error("No CoroutineScope provided to observe()"))
    }

    fun observeNext(
        scope: CoroutineScope? = null,
        onValue: suspend (T) -> Unit,
        onCompletion: ((Throwable?) -> Unit)? = null
    ): Job {
        return flow
            .take(1)
            .onEach { onValue(it) }
            .onCompletion { cause -> onCompletion?.invoke(cause) }
            .launchIn(scope ?: defaultScope ?: error("No CoroutineScope provided to observeNext()"))
    }

    companion object {
        fun <T> withInitialValue(initial: T, scope: CoroutineScope? = null): Signal<T> {
            val stateFlow = MutableStateFlow(initial)
            return Signal(stateFlow, { stateFlow.value = it }, scope)
        }

        fun <T> eventOnly(scope: CoroutineScope? = null): Signal<T> {
            val flow = MutableSharedFlow<T>(
                replay = 0,
                extraBufferCapacity = 1,
                onBufferOverflow = BufferOverflow.DROP_OLDEST
            )
            return Signal(flow, { flow.tryEmit(it) }, scope)
        }
    }
}