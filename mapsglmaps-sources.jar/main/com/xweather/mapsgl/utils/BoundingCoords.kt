package com.xweather.mapsgl.utils

/**
 *   BoundingCoords.kt
 *
 *  Replaces Pair<Pair<Double, Double>, Pair<Double, Double>> for clarity's sake.
 *
 *   @author Jason Suto on 02/12/24.
 *
 */
class BoundingCoords(var x1:Double, var y1:Double, var x2: Double, var y2:Double) {
}