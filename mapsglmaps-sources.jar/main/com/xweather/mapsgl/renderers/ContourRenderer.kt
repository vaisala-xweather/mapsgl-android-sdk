package com.xweather.mapsgl.renderers


import com.xweather.mapsgl.gl.ContourRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.programs.TriangleProgram
import com.xweather.mapsgl.style.ColorLookupTable
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.math_type.ValueRange


class ContourRenderer(override var id: String) : EncodedDataRenderer<TileData, LayerRenderContext<Any>>(id) {
    private lateinit var paintStyle: ContourLayerPaint

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {
        TODO("Not yet implemented")
    }

    override fun onAdd() {
        TODO("Not yet implemented")
    }

    override fun setUpRenderPass(): RenderPass {
        if (pr.ON) pr.p("ParticleRenderer", pr.waaveRenderpath, ">> setupRenderpass")
        if (this.tileLayer?.source?.id != null) {
            return ContourRenderPass(tileLayer!!.source.id, tileLayer!!.paint)
        } else {
            return ContourRenderPass("particle", tileLayer!!.paint)
        }
    }

    override suspend fun update() {
        TODO("Not yet implemented")
    }

    override fun setup(paint: LayerPaint) {
        paintStyle = paint as ContourLayerPaint
        val colorscale = paintStyle.sample.colorScale

        var drawRange = paintStyle.sample.drawRange
        _outputRange = ValueRange(0.0, 255.0, "")
        // sourceMetadata = dataSource.metadata  //.getMetadataForBand(band);

        val tProgram = (program as TriangleProgram)
        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        if (drawRange == null) {
            drawRange = colorscale.range
        } else {//received draw range from WeatherService drawRange (outside of color stops)

        }
        val colorDrawRange = drawRange ?: (dataRange.min..dataRange.max ?: 0.0..1.0)
        createColorLookupTables(options = colorscale, drawRange = colorDrawRange)

        if (paintStyle.sample.drawRange != null) {
            tProgram.updateDataRange(colorDrawRange.start.toFloat(), colorDrawRange.endInclusive.toFloat())
        } else {
            tProgram.updateDataRange(colorDrawRange.start.toFloat(), colorDrawRange.endInclusive.toFloat())
        }

        if (colorscale.stops[0] is ColorStop) { //single list
            colorBandBitmap =
                arrayOf(colorLookupTable.createColorLookupBitmap(256, 1, colorscale.stops as List<ColorStop>))
            colorBandTexHandles[0] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

        } else { //multiple list, radar
            colorBandBitmap = arrayOf(
                colorLookupTable.createColorLookupBitmap(256, 1, colorscale.stops[0] as List<ColorStop>),
                colorLookupTable.createColorLookupBitmap(256, 1, colorscale.stops[1] as List<ColorStop>),
                colorLookupTable.createColorLookupBitmap(256, 1, colorscale.stops[2] as List<ColorStop>)
            )

            colorBandTexHandles[0] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

            colorBandTexHandles[1] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[1], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle1"] = colorBandTexHandles[1]

            colorBandTexHandles[2] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[2], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle2"] = colorBandTexHandles[2]
        }

        val fullRange = (colorLookupTable.initialStops.last().value - colorLookupTable.initialStops.first().value)
        drawLow =
            ((colorLookupTable.filteredStops.first().value - colorLookupTable.initialStops.first().value) / fullRange).toFloat()
        drawHigh =
            (1 - (((colorLookupTable.initialStops.last().value - colorLookupTable.filteredStops.last().value))) / fullRange).toFloat()


        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1

        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }

        val colorRangeFactor: Float = if (paintStyle.sample.drawRange != null) {
            val csRange = (colorDrawRange.endInclusive - colorDrawRange.start).toFloat()
            val cltRange = (colorLookupTable.initialStops.last().value - colorLookupTable.initialStops.first().value)
            (csRange / cltRange.toFloat()).toFloat()
        } else {
            1f
        }

        tProgram.updateChannels(channel1, channel2) //normal
        tProgram.updateOutputRange((_outputRange.min / 255.0).toFloat(), (_outputRange.max / 255.0).toFloat())
        tProgram.updateColorRangeFactor(colorRangeFactor)
        tProgram.updateColorSampleOffset(paintStyle.sample.offset)
        tProgram.updateDrawRange(drawLow, drawHigh) //normal
        tProgram.setUniform("mode", mode)
        tProgram.updateMode(mode)
        tProgram.updateSmoothing(paintStyle.sample.smoothing)
        tProgram.setContourUniforms(
            paintStyle.contour.interval.constantValue!!.toFloat(),
            paintStyle.contour.majorInterval.constantValue!!.toFloat(),
            paintStyle.contour.width.constantValue!!.toFloat(),
            paintStyle.contour.majorWidth.constantValue!!.toFloat()
        )


        if (md != null) {
            if (md.noData != null) {
                _outputRange.min = md.noData!!.toDouble()
                //tProgram.updateNoData(md.noData!!.toFloat())
                println("EncodedDataRenderer.setup()  noData: set to md.noData!!.toFloat()")
            }
        }

        mode = 0
    } //end of setup()

    fun setupOld(paint: LayerPaint) {
        paintStyle = (paint as ContourLayerPaint)
        val colorScale = paintStyle.sample.colorScale
        var drawRange = paintStyle.sample.drawRange
        _outputRange = ValueRange(0.0, 255.0, "")

        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        val tProgram = (program as TriangleProgram)

        if (drawRange == null) {
            drawRange = colorScale.range
        }

        val colorDrawRange = drawRange ?: 0.0..1.0
        createColorLookupTables(options = colorScale, drawRange = colorDrawRange)

        tProgram.setContourUniforms(
            paintStyle.contour.interval.constantValue!!.toFloat(),
            paintStyle.contour.majorInterval.constantValue!!.toFloat(),
            paintStyle.contour.width.constantValue!!.toFloat(),
            paintStyle.contour.majorWidth.constantValue!!.toFloat()
        )

        if (paintStyle.sample.drawRange != null) {
            tProgram.updateDataRange(
                colorDrawRange.start.toFloat(),
                colorDrawRange.endInclusive.toFloat()
            ) //TODO: Data range only matters for vector?
        } else {
            tProgram.updateDataRange(colorDrawRange.start.toFloat(), colorDrawRange.endInclusive.toFloat())
        }

        //Fixme: colorRange is applied in createColorLookupBitmap(), it should be applied earlier in createColorLookupTables()
        colorBandBitmap = arrayOf(colorLookupTable.createColorLookupBitmap(256, 1))

        tProgram.uniforms["colorBitmap"] = colorBandBitmap
        colorBandTexHandles[0] =
            ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
        tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1
        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }
        tProgram.updateChannels(channel1, channel2) //normal

    }

    override fun setNeedsUpdate() {}

    fun setupFrameBufferProgram(paint: LayerPaint, rasterTileProgram: RasterTileProgram) {
        paintStyle = (paint as ContourLayerPaint)
        val colorScale = paintStyle.sample.colorScale
        var drawRange = paintStyle.sample.drawRange
        _outputRange = ValueRange(0.0, 255.0, "")

        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        val tProgram = (rasterTileProgram as TriangleProgram)

        if (drawRange == null) {
            drawRange = colorScale.range
        } else { //received draw range from WeatherService drawRange (outside of color stops)
        }
        val colorDrawRange = drawRange ?: 0.0..1.0
        createColorLookupTables(options = colorScale, drawRange = colorDrawRange)

        if (paintStyle.sample.drawRange != null) {
            tProgram.updateDataRange(
                colorDrawRange.start.toFloat(),
                colorDrawRange.endInclusive.toFloat()
            ) //TODO: Data range only matters for vector?
        } else {
            tProgram.updateDataRange(colorDrawRange.start.toFloat(), colorDrawRange.endInclusive.toFloat())
        }

        //Fixme: colorRange is applied in createColorLookupBitmap(), it should be applied earlier in createColorLookupTables()
        colorBandBitmap = arrayOf(colorLookupTable.createColorLookupBitmap(256, 1))

        tProgram.uniforms["colorBitmap"] = colorBandBitmap[0]
        colorBandTexHandles[0] =
            ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
        tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]
        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1
        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }
        tProgram.updateChannels(channel1, channel2) //normal
    }
}