package com.xweather.mapsgl.renderers

import android.graphics.Bitmap
import android.graphics.Paint
import com.xweather.mapsgl.Partial
import com.xweather.mapsgl.anim.TimeSeriesState
import com.xweather.mapsgl.data.DataRange
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.programs.TriangleProgram
import com.xweather.mapsgl.layers.style.SampleStyle
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.style.ColorLookupTable
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.RendererSpecification
import com.xweather.mapsgl.types.SampleChannel
import com.xweather.mapsgl.types.math_type.ValueRange


typealias TileRendererOptions = RendererSpecification

interface EncodedDataRendererOptions : TileRendererOptions {
    var palette: Partial<ColorScaleOptions>
    var channel: SampleChannel //| Array<SampleChannel>
    var interpolation: InterpolationMode
    var smoothing: Double
    var drawRange: Partial<ValueRange>
}

open class EncodedDataRenderer<DataType : TileData, Context : LayerRenderContext<Any>>(
    override var id: String
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {

    var TAG = "EncodedDataRenderer"

    private var _timeState: TimeSeriesState = TimeSeriesState(
        position = 0,
        index = 0,
        nextIndex = 0
    )

    private val _colorLookupTables: MutableList<ColorLookupTable> = mutableListOf() //= []
    lateinit var _outputRange: ValueRange
    private lateinit var _dataRange: DataRange
    private lateinit var sampleDataRange: DataRange
    private lateinit var _channel: Array<String>
    private var _debugEnabled = false
    private lateinit var paintStyle: SampleLayerPaint // ColorSampling
    private val paint: Paint = Paint() //TODO: constructor?
    lateinit var colorBandBitmap: Array<Bitmap>//Array<Bitmap>
    var drawHigh = 0f
    var drawLow = 0f

    lateinit var colorLookupTable: ColorLookupTable
    var colorBandTexHandles = IntArray(3)
    var mode = 0

    val channel: Array<String>
        get() = _channel

    val interpolation: InterpolationMode
        get() {
            val mode = (context.paintStyle as SampleStyle).interpolation

            return if ((mode) != null) {
                mode
            } else {
                InterpolationMode.BILINEAR
            }
        }

    val smoothing: Double
        get() = /*context.paintStyle.sampleSmoothing() ?:*/ 0.0

    val progress: Double
        get() = /*layer.animator?.relativePosition ?:*/ 0.0

    val timeState: TimeSeriesState
        get() = _timeState

    val dataRange: ValueRange
        get() = _dataRange.range.copy()


    private val colorLookupTables: MutableList<ColorLookupTable>
        get() = _colorLookupTables

    override fun initialize(context: RenderContext<Any>) {
    }

    init {
        cachesTextures = false
    }

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {
        TODO("Not yet implemented")
    }

    //override fun draw(texUnit: HashMap<String, HashMap<String, Int>>) {
    //   TODO("Not yet implemented")
    //}

    // override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer) {
    //     TODO("Not yet implemented")
    // }

    override fun onAdd() {
        TODO("Not yet implemented")
    }

    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {
        TODO("Not yet implemented")
    }

    override fun setNeedsUpdate() {}

    override fun setUpRenderPass(): RenderPass {
        // if(pr.ON)pr.p(TAG,pr.particles, "setupRenderPass() returning encoded or regular render pass")
        return RenderPass(tileLayer?.source!!.id, tileLayer!!.paint)
    }

    override suspend fun update() {
        TODO("Not yet implemented")
    }

    open fun setup(paint: LayerPaint) {
        paintStyle = paint as SampleLayerPaint
        val colorscale = paintStyle.sample.colorScale
        var drawRange = paintStyle.sample.drawRange
        _outputRange = ValueRange(0.0, 255.0, "")
        // sourceMetadata = dataSource.metadata  //.getMetadataForBand(band);

        val tProgram = (program as TriangleProgram)
        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        if (drawRange == null) {
            drawRange = colorscale.range
        } else {//received draw range from WeatherService drawRange (outside of color stops)
        }
        val colorDrawRange = drawRange ?: (dataRange.min..dataRange.max ?: 0.0..1.0)
        createColorLookupTables(options = colorscale, drawRange = colorDrawRange)

        if (paintStyle.sample.drawRange != null) {
            tProgram.updateDataRange(colorDrawRange.start.toFloat(), colorDrawRange.endInclusive.toFloat())
        } else {
            tProgram.updateDataRange(colorDrawRange.start.toFloat(), colorDrawRange.endInclusive.toFloat())
        }

        if (colorscale.stops[0] is ColorStop) { //single list
            colorBandBitmap =
                arrayOf(colorLookupTable.createColorLookupBitmap(256, 1, colorscale.stops as List<ColorStop>))
            colorBandTexHandles[0] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

        } else { //multiple list, radar
            colorBandBitmap = arrayOf(
                colorLookupTable.createColorLookupBitmap(256, 1, colorscale.stops[0] as List<ColorStop>),
                colorLookupTable.createColorLookupBitmap(256, 1, colorscale.stops[1] as List<ColorStop>),
                colorLookupTable.createColorLookupBitmap(256, 1, colorscale.stops[2] as List<ColorStop>)
            )

            colorBandTexHandles[0] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

            colorBandTexHandles[1] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[1], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle1"] = colorBandTexHandles[1]

            colorBandTexHandles[2] =
                ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[2], paintStyle.sample.colorScale.interpolate)
            tProgram.uniforms["colorBandTexHandle2"] = colorBandTexHandles[2]
        }

        val fullRange = (colorLookupTable.initialStops.last().value - colorLookupTable.initialStops.first().value)
        drawLow =
            ((colorLookupTable.filteredStops.first().value - colorLookupTable.initialStops.first().value) / fullRange).toFloat()
        drawHigh =
            (1 - (((colorLookupTable.initialStops.last().value - colorLookupTable.filteredStops.last().value))) / fullRange).toFloat()


        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1

        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }
        val colorRangeFactor: Float = if (paintStyle.sample.drawRange != null) {
            val csRange = (colorDrawRange.endInclusive - colorDrawRange.start).toFloat()
            val cltRange = (colorLookupTable.initialStops.last().value - colorLookupTable.initialStops.first().value)
            (csRange / cltRange.toFloat()).toFloat()
        } else {
            1f
        }

        tProgram.updateChannels(channel1, channel2) //normal
        tProgram.updateOutputRange((_outputRange.min / 255.0).toFloat(), (_outputRange.max / 255.0).toFloat())
        tProgram.updateColorRangeFactor(colorRangeFactor)
        tProgram.updateColorSampleOffset(paintStyle.sample.offset)
        tProgram.updateDrawRange(drawLow, drawHigh) //normal
        tProgram.setUniform("mode", mode)
        tProgram.updateMode(mode)
        if (md != null) {
            if (md.noData != null) {
                _outputRange.min = md.noData!!.toDouble()
                //tProgram.updateNoData(md.noData!!.toFloat())
                println("EncodedDataRenderer.setup()  noData: set to md.noData!!.toFloat()")
            }
        }


        mode = 0
    } //end of setup()

    fun createColorLookupTables(options: ColorScaleOptions, drawRange: ClosedRange<Double>) {
        colorLookupTable = ColorLookupTable(
            options.stops,
            drawRange,
            interpolate = options.interpolate,
            interval = options.interval,
            roundDown = options.roundDown
        )
        colorLookupTables.add(colorLookupTable)
        if (options.masks != null) {
            // TODO - set up color LUT for masks
        } else {
        }
    }
}
