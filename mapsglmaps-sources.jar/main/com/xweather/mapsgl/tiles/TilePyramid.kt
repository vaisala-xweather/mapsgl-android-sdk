package com.xweather.mapsgl.tiles

import android.util.Log
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.coordinates.LatitudeLongitude
import com.xweather.mapsgl.coordinates.MapBounds
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.sources.TileSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date
import kotlin.coroutines.cancellation.CancellationException

private const val TAG = "TilePyramid"

data class LatLonBounds(
    val westExtent: Double,
    val southExtent: Double,
    val eastExtent: Double,
    val northExtent: Double,
    val wrapped: Boolean = false
)

data class GLCoordinate2D(var x: Double, var y: Double)

/**
 *  TilePyramid.kt
 *
 *  Adapted from IOS version.
 *  @author Jason Suto on 12/18/23.
 */
class TilePyramid<DataType : TileData>(private val layer: TileLayer) {
    val key: String = "${layer.mapController?.account?.id}_${layer.mapController?.account?.secret}"
    private val worldCoord = TileCoord(0, 0, 0)
    private var timesArray: Array<String>? = arrayOf("", "")
    private lateinit var timeline: Timeline
    var formattedDate: String? = null
    lateinit var fallbackOptions: TileRequestOptions
    val maxIntervals = 8
    var memUsageLast = 0f

    var tileSource: TileSource<TileData> //<DataType>
        get() = layer.source
        set(value) {
            layer.source = value
        }

    val tileCache: TileCache<com.xweather.mapsgl.sources.DataType>
        get() = tileSource.tileCache


    /** Make sure you don't request times not included in valid times. **/
    private fun filterABTimesByValidTimes(sourceId: String): Array<String> {

        val layerLists = Timeline.sourceTimeHash[sourceId] ?: return emptyArray()
        val result = mutableListOf<String>()

        // Helper function to add items to reqLongs/reqStrings while maintaining sort order.
        fun addRequestInOrder(timeLong: Long, timeString: String) {

            val insertionIndex = layerLists.reqLongs.binarySearch(timeLong)

            // Only add the item if it's not already in the request list.
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                layerLists.reqLongs.add(correctIndex, timeLong)
                //println(">> TilePyramid filterABTimesByValidTimes() adding to reqStrings: ${timeString}")
                layerLists.reqStrings.add(correctIndex, timeString)
            }
        }

        val timeLongA = Timeline.timeLongs[Timeline.currentPhaseA]
        val timeStringA = Timeline.timeStrings[Timeline.currentPhaseA]

        if (layerLists.timeLongs.binarySearch(timeLongA) >= 0) {
            // The exact time is valid for this layer.
            result.add(timeStringA)
            addRequestInOrder(timeLongA, timeStringA)
        }

        // --- Process Phase B ---
        val timeLongB = Timeline.timeLongs[Timeline.currentPhaseB]
        val timeStringB = Timeline.timeStrings[Timeline.currentPhaseB]

        if (timeLongA != timeLongB && layerLists.timeLongs.binarySearch(timeLongB) >= 0) {
            // The exact time is valid for this layer and is different from Phase A.
            result.add(timeStringB)
            addRequestInOrder(timeLongB, timeStringB)
        }

        return result.toTypedArray()
    }

    /** Make sure you don't request times not included in valid times  **/
    private fun filterTimelineByValidTimes(): Array<String> {
        val layerLists = Timeline.sourceTimeHash[layer.source.id] ?: return emptyArray()

        // Ensure the list is sorted before we begin, as binarySearch requires it.
        // This is a safeguard in case the list was modified incorrectly elsewhere.
        if (layerLists.timeLongs.isSorted().not()) {
            layerLists.timeLongs.sort()
        }

        val returnList: MutableList<String> = mutableListOf()

        // A helper extension function to add items while maintaining sort order.
        fun MutableList<Long>.addInOrder(element: Long, associatedString: String) {
            val insertionIndex = this.binarySearch(element)
            // If the item is not already present, add it.
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                this.add(correctIndex, element)
                layerLists.reqStrings.add(correctIndex, associatedString)
            }
        }

        for ((index, timeString) in Timeline.timeStrings.withIndex()) {
            val timelineLong = Timeline.timeLongs[index]

            // Search for the timeline time in the layer's valid times.
            val searchResult = layerLists.timeLongs.binarySearch(timelineLong)

            if (searchResult >= 0) {
                // --- Exact match found ---
                returnList.add(timeString)
                layerLists.reqLongs.addInOrder(timelineLong, timeString)
            } else {
                // --- No exact match, find the next largest (closest) time ---
                val insertionPoint = -(searchResult + 1)

                if (insertionPoint < layerLists.timeLongs.size) {
                    // This is the next available time in the layer's list.
                    val nextClosestLong = layerLists.timeLongs[insertionPoint]
                    val nextClosestString = layerLists.timeStrings[insertionPoint]

                    returnList.add(nextClosestString)
                    layerLists.reqLongs.addInOrder(nextClosestLong, nextClosestString)
                } else {
                    // This time is after the last available time for the layer, so there's no "next" item to use.
                    // We can optionally use the last available item as a fallback.
                    if (layerLists.timeLongs.isNotEmpty()) {
                        val lastValidLong = layerLists.timeLongs.last()
                        val lastValidString = layerLists.timeStrings.last()
                        returnList.add(lastValidString)
                        layerLists.reqLongs.addInOrder(lastValidLong, lastValidString)
                    }
                }
            }
        }

        return returnList.toTypedArray()
    }

    // You might need to add this helper extension function to your project if it doesn't exist.
// It can be placed at the top level of any utility file.
    fun <T : Comparable<T>> List<T>.isSorted(): Boolean {
        for (i in 0 until this.size - 1) {
            if (this[i] > this[i + 1]) {
                return false
            }
        }
        return true
    }

    /** Determine which tiles are already downloaded, and request the ones that aren't */
    suspend fun requestTilesForDownload(
        coords: List<TileCoord>,
        options: TileRequestOptions,
        externalScope: CoroutineScope,
    ): Result<Unit> { // Keep Result<Unit> signature

        timeline = layer.mapController!!.timeline
        if (tileSource.metaDataNeeded > 0 && tileSource.isEncoded) {
            val startDate = if (this::timeline.isInitialized) timeline.start else null
            val endDate = if (this::timeline.isInitialized) timeline.end else null

            if (pr.ON) pr.p(
                TAG,
                pr.tileReq,
                "requestTilesForDownload() calling and awaiting fetchMetadata() with $startDate / $endDate"
            )

            // Make fetchMetadata a suspend function and await its completion
            val metadataResult = tileSource.fetchMetadata(startDate, endDate)

            // If fetching fails, stop and propagate the failure.
            if (metadataResult.isFailure) {
                return Result.failure(
                    metadataResult.exceptionOrNull()
                        ?: IllegalStateException("Metadata fetch failed without an exception.")
                )
            }
            // If successful, the function will now continue instead of returning early.
            if (pr.ON) pr.p(
                TAG,
                pr.fetchMeta,
                "requestTilesForDownload() proceeding, hopefully AFTER metadata fetch  with $startDate / $endDate\""
            )

        } else {
            //if (pr.ON) pr.p(TAG, pr.tileReq, "requestTilesForDownload() SKIPPING METADATA FETCH", 2 )
        }

        if (formattedDate == null) {
            val calendar = Calendar.getInstance()
            calendar.time = Date()
            calendar.add(Calendar.HOUR_OF_DAY, -12)
            formattedDate = options.formatDate(calendar.time)
            fallbackOptions = options
        }


        timesArray =
            if (timeline.state == AnimationState.playing || timeline.opts.shouldPreloadData || timeline.opts.forcePreloadOneTime) {
                val returnA = filterTimelineByValidTimes()
                returnA
            } else {
                if (pr.ON) pr.p(TAG, pr.tilePyramidReq, ">> TilePyramid requestTilesForDownload() entered, NOT playing")
                filterABTimesByValidTimes(layer.source.id)
            }
        pr.p(TAG, pr.hailFix, "requestTilesForDownload() at the end, array is: ${timesArray.toString()}")
        val coordIntervalMap: HashMap<String, MutableList<String>> =
            HashMap() // Map: CoordHash -> List<TimeIntervalString>

        timesArray?.forEach { time ->
            coords.forEach { coord ->
                val tempCoord = TileCoord(coord.x, coord.y, coord.z, 0, time)
                val hash = tempCoord.hash()

                if (!tileCache.tiles.containsKey(hash) && !tileCache._pending.containsKey(hash) && !tileCache._requestedTiles.containsKey(
                        hash
                    )
                ) {

                    Timeline.addPendingEncodedDownload(layer.source.id, hash)
                    coordIntervalMap.getOrPut(coord.hashShort()) { mutableListOf() }.add(time)
                    tileCache._requestedTiles[hash] = System.currentTimeMillis() // Mark as requested
                    if (pr.ON) pr.p(
                        TAG,
                        pr.infiniteLoad,
                        " requestTilesForDownload() pending size: ${layer.source.id} ${hash}"
                    )
                }
            }
        }

        // Request WorldCoord when not playing
        if (timeline.state != AnimationState.playing && tileSource.minZoom.toInt() == 0) {
            timesArray?.forEach { time ->
                worldCoord.time = time
                val hash = worldCoord.hash()
                if (!tileCache.tiles.containsKey(hash) && !tileCache._pending.containsKey(hash) && !tileCache._requestedTiles.containsKey(
                        hash
                    )
                ) {
                    coordIntervalMap.getOrPut(worldCoord.hashShort()) { mutableListOf() }.add(time)
                    tileCache._requestedTiles[hash] = System.currentTimeMillis() // Mark as requested
                }
            }
        }

        return try { // Wrap in try-catch for potential issues during launch/join
            coroutineScope { // Create a scope for launching concurrent jobs
                val downloadJobs = mutableListOf<Job>() // Keep track of launched jobs

                if (tileSource.isEncoded) {//Encoded
                    coordIntervalMap.forEach { (coordShortHash, intervals) ->
                        val tileCoord = TileCoord.fromHashShort(coordShortHash)
                        if (tileCoord != null) {
                            intervals.chunked(24 / tileSource.datasets.size).forEach { intervalChunk ->
                                downloadJobs.add(launch {
                                    try {
                                        tileSource.requestTiles(
                                            tileCoord,
                                            options,
                                            formattedDate!!,
                                            true,
                                            intervalChunk
                                        )
                                    } catch (e: Exception) {
                                        Log.e(TAG, "Error in tile request job for ${tileCoord.hashShort()}", e)
                                    }

                                    if (layer.mapController != null) {
                                        val mapController = layer.mapController
                                        if (mapController is MapboxMapController) {
                                            mapController.mapboxMap?.executeOnRenderThread {
                                                mapController.layerHosts[layer.id]?.bindTextures(layer.source.id)
                                            }
                                        } else {
                                            //todo: Logic for other map types as needed
                                        }
                                    }
                                })
                            }
                        }
                    }
                } else { // Raster
                    coordIntervalMap.forEach { (coordShortHash, intervals) ->
                        val tileCoord = TileCoord.fromHashShort(coordShortHash)
                        if (tileCoord != null) {
                            if (pr.ON) pr.p(
                                TAG,
                                pr.rasterFix,
                                "requestTilesForDownload() coordShortHash: $coordShortHash ----------------"
                            )
                            for (interval in intervals) {
                                if (pr.ON) pr.p(TAG, pr.rasterFix, "requestTilesForDownload() interval: ${interval}")

                                downloadJobs.add(launch {
                                    try {
                                        tileSource.requestTiles(tileCoord, options, interval, true)
                                    } catch (e: Exception) {
                                        if (pr.ON) pr.p(TAG, pr.rasterFix, "requestTilesForDownload() ERROR: ${e}", 2)
                                    }
                                })
                            }
                        }
                    }
                } // end Raster

                if (!Timeline.threadDownload) { //original method that slows down while downloading
                    downloadJobs.joinAll()
                } else {
                    if (downloadJobs.isNotEmpty()) {
                        val batchSize = downloadJobs.size // Capture size for the log message
                        if (pr.ON) pr.p(
                            TAG,
                            pr.tileRequest,
                            "Launching completion logger coroutine for $batchSize jobs."
                        )
                        externalScope.launch(Dispatchers.Default) { // Use Default or IO for waiting
                            try {
                                if (pr.ON) pr.p(
                                    TAG,
                                    pr.tileRequest,
                                    "[CompletionLogger] Waiting for $batchSize jobs..."
                                )
                                downloadJobs.joinAll() // This coroutine suspends here
                            } catch (e: CancellationException) {
                                Log.w(TAG, "[CompletionLogger] Waiting coroutine cancelled.")
                            } catch (e: Exception) {
                                Log.e(TAG, "[CompletionLogger] Error waiting for job batch completion", e)
                            }
                        }
                        layer.mapController!!.checkDownloadStatus(
                            layer.id,
                            tileCache.pendingCount
                        ) // Check remaining pending

                    }
                }
            } // End coroutineScope

            Result.success(Unit) // Indicate the overall process initiated successfully
        } catch (e: Exception) {
            println("$TAG Error during concurrent download process, $e")
            Result.failure(e) // Return failure if the scope or launching had issues
        }
    }

    fun checkAndClearMemory(coords: List<TileCoord>) {
        if (true || tileCache.memUsage != memUsageLast) {
            if (pr.ON) pr.p(TAG, pr.clearMem, "from requestTileForDownload(), mem is ${tileSource.tileCache.memUsage}")
            memUsageLast = tileCache.memUsage

            if (coords.isNotEmpty()) {
                if (pr.ON) pr.p(TAG, pr.clearMem, "requestTileForDownload(), zoom from Coords: ${coords.first().z}")
                if (tileSource.tileCache.memUsage > .05f) {
                    //if(pr.ON) pr.p (TAG, pr.clearMem, "requestTileForDownload(),memUsage over 80%",2)
                    //tileCache.clearOtherZooms(coords.first().z)
                    //tileCache.clearOutsideBounds(this.layer.persistentTileBounds)
                    //tileCache.removeAll()

                    //tileSource.tileManager.pending.remove()
                    //_pending.remove(coord.hash())
                }
            }
        }
    }

    private fun removeOutOfBounds(
        bounds: MapBounds<LatitudeLongitude> /*LatLonBounds*/,
        coords: /*Mutable*/List<TileCoord>
    ) {
        coords.filter { coord ->
            coord.mapBounds?.let { coordBounds ->
                if (coordBounds.eastExtent < bounds.westExtent || coordBounds.westExtent > bounds.eastExtent) {
                    return@filter false
                } else return@filter !(coordBounds.southExtent > bounds.northExtent || coordBounds.northExtent < bounds.southExtent)
            } ?: true
        }
    }

    private fun sortAroundCenter(center: GLCoordinate2D, coords: MutableList<TileCoord>): MutableList<TileCoord> {
        if (coords.isNotEmpty()) {
            //Todo: further optimizations possible
            val numTiles = (powerTableD[coords.first().z])
            var dax: Double
            var day: Double
            var da: Double
            coords.sortBy { coord ->
                val aCenter = coord.getCenter()
                dax = (center.x * (numTiles)) - (aCenter.x + .5f)
                day = (center.y * (numTiles)) - (aCenter.y + .5f)
                da = (dax * dax) + (day * day)
                da
            }
        }
        return coords
    }

    interface DictionaryProtocol {
        fun contains(coord: TileCoord): Boolean
    }

    interface Sequence {
        fun contains(coord: TileCoord): Boolean
    }

    interface Collection {
        fun contains(coord: TileCoord): Boolean
    }

    operator fun TilePyramid<DataType>.contains(coord: TileCoord): Boolean {
        return tileSource.contains(coord)
    }

    operator fun TilePyramid<DataType>.get(coord: TileCoord): Tile<com.xweather.mapsgl.sources.DataType>? {
        return tileCache[coord]
    }
}