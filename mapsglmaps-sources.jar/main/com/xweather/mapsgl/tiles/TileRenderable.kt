package com.xweather.mapsgl.tiles

import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.math.Vector3
//import com.xweather.mapsgl.types.TextureCoordinateOffset

typealias AnyTileRenderable = TileRenderable<*>

interface TileRenderableProtocol {
}

/** Holds a Tile (TileCoord, data, hash, state, and bounds) along with scale, offset, */
data class TileRenderable<DataType : TileData>(
    val tile: Tile<DataType>,

    ) : TileRenderableProtocol {

    var scale = Vector3(1.0f, 1.0f, 1.0f)
    var offset = Vector3(0.0f, 0.0f, 0.0f)
    //var uvOffset: TextureCoordinateOffset = TextureCoordinateOffset()
    var coord: TileCoord = tile.coord
    var partialScale = 1f

    init {
        coord.x += this.coord.offset
    }

    /**
     * Returns the view matrix for the tile including its scale and translation transformations.
     */
    fun getViewMatrix(): ProjectionMatrix {
        val matrix = ProjectionMatrix()
        matrix.scale(scale)
        matrix.translate(offset)
        return matrix
    }
}


