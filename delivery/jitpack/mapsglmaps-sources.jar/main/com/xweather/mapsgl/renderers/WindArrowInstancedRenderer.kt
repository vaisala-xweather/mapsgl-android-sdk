package com.xweather.mapsgl.renderers

import android.opengl.GLES31
import android.os.SystemClock
import android.util.Log
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.IconSize
import java.util.Locale
import kotlin.concurrent.withLock

/**
 * Instanced GL renderer for gridded wind direction arrows (`conditions.wind_speed.arrow`).
 *
 * Uses the same dual-phase buffer and GPU meld uniform as [WindBarbInstancedRenderer] so timeline playback can
 * hit the display refresh rate without rebuilding CPU instances each frame.
 */
class WindArrowInstancedRenderer(
    override var id: String,
) : GridLayerRenderer(id) {

    override val logTag: String = "WindArrowInstancedRenderer"

    private var windArrowShaderProgram = 0

    /** [GLES31.glGetUniformLocation] for `noData`; -1 if missing. */
    private var noDataUniformLocation = -1
    private var haloColorUniformLocation = -1
    private var haloWidthUniformLocation = -1

    private var lastZeroInstanceLogMs = 0L

    /** Mapbox render-thread draw() calls per second (see [recordDrawFpsTick]). */
    private var drawFpsCount = 0
    private var drawFpsWindowStartMs = 0L

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>, camera: Camera) {
        val tl = tileLayer ?: return
        scheduleInstancedCpuGatherBeforeDraw(tl)
        consumePendingInstanceUploadAndDraw(camera)
        val mc = tl.mapController as? MapboxMapController
        val gs = gridSource
        if (mc != null && gs != null && gpuInstanceCount > 0) {
            maybeSchedulePrefetchNextPhase(tl, mc, gs, VIEWPORT_EXTRA_EAST_FRACTION)
        }
        recordDrawFpsTick()
    }

    private fun recordDrawFpsTick() {
        val now = SystemClock.uptimeMillis()
        if (drawFpsWindowStartMs == 0L) drawFpsWindowStartMs = now
        drawFpsCount++
        val elapsed = now - drawFpsWindowStartMs
        if (elapsed < 1000L) return
        val hz = drawFpsCount * 1000.0 / elapsed
        Log.d(
            logTag,
            String.format(
                Locale.US,
                "[%s] arrow layer draw %.1f Hz (%d calls in %d ms)",
                id,
                hz,
                drawFpsCount,
                elapsed,
            ),
        )
        drawFpsCount = 0
        drawFpsWindowStartMs = now
    }

    override suspend fun runGridGatherOnce(
        tl: TileLayer,
        gs: EncodedGridVectorTileSource,
        mc: MapboxMapController,
    ): Boolean {
        if (adoptPrefetched()) return true
        val zoom = CameraSync.zoomForCustomLayerInstancing()
        val gatherKeyAtStart = computeGatherKey(tl)
        val bounds = resolveVisibleGeoBoundsForGather(tl, mc, zoom)
        val coords = tl.visibleTileCoordsForSidecarSampling()
        if (coords.isEmpty()) return false

        val (floats, n) = gs.buildInstancedWindBufferDualPhase(
            coords,
            zoom,
            bounds,
            12_000,
            viewportExtraEastFraction = VIEWPORT_EXTRA_EAST_FRACTION,
        )
        if (n == 0) {
            val now = SystemClock.uptimeMillis()
            if (now - lastZeroInstanceLogMs > 3000L) {
                lastZeroInstanceLogMs = now
            }
        }
        bufferLock.withLock {
            pendingInstanceData = floats
            pendingInstanceCount = n
            pendingGatherZoom = zoom
            pendingAppliedGatherKey = gatherKeyAtStart
            pendingBufferPhaseA = Timeline.currentPhaseA
            pendingBufferPhaseB = Timeline.currentPhaseB
        }
        return true
    }

    /**
     * Mercator half-extents: along-arrow (x) and perpendicular (y) from [IconPaint.iconSize] (JS pixel w×h) or uniform [IconPaint.size].
     */
    private fun resolveIconHalfExtentsXY(baseHalfWorld: Float): Pair<Float, Float> {
        val p = tileLayer?.paint as? GridLayerPaint ?: return baseHalfWorld to baseHalfWorld
        val icon = p.icon
        icon.iconSize?.let { sz ->
            return mercatorHalfExtentsFromJsIconPixels(sz.width, sz.height, baseHalfWorld)
        }
        val s = icon.size?.constantValue ?: return baseHalfWorld to baseHalfWorld
        val u = s.toFloat().coerceIn(0.05f, 8f)
        val d = griddedIconDisplayDensity()
        val e = (baseHalfWorld * u * d).coerceIn(2f, 192f)
        return e to e
    }

    /**
     * Normalized 0–1 sentinel from [com.xweather.mapsgl.sources.SourceMetadata.noData] (encoded byte 0–255),
     * matching [sample.frag.combined.glsl] / [com.xweather.mapsgl.renderers.EncodedDataRenderer] usage.
     * Returns `-1` when metadata has no noData → fragment shader skips the test.
     */
    private fun encodedNoDataUniformNormalized(): Float {
        val tl = tileLayer ?: return -1f
        val src = tl.source as? TileSource<*> ?: return -1f
        val raw = src.metadata.noData ?: return -1f
        return raw.coerceIn(0, 255).toFloat() / 255f
    }

    override fun ensureGlResources() {
        if (glReady) return
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, VERT_SHADER)
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, FRAG_SHADER)
        windArrowShaderProgram = GLES31.glCreateProgram().also { prog ->
            GLES31.glAttachShader(prog, vs)
            GLES31.glAttachShader(prog, fs)
            GLES31.glLinkProgram(prog)

            val linkStatus = IntArray(1)
            GLES31.glGetProgramiv(prog, GLES31.GL_LINK_STATUS, linkStatus, 0)
            if (linkStatus[0] == 0) {
                val log = GLES31.glGetProgramInfoLog(prog) ?: "<null>"
                Log.e(logTag, "Shader program link failed. program=$prog log=$log")
                GLES31.glDeleteProgram(prog)
                windArrowShaderProgram = 0
                GLES31.glDeleteShader(vs)
                GLES31.glDeleteShader(fs)
                return
            }
        }
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)

        noDataUniformLocation = GLES31.glGetUniformLocation(windArrowShaderProgram, "noData")
        haloColorUniformLocation = GLES31.glGetUniformLocation(windArrowShaderProgram, "u_haloColor")
        haloWidthUniformLocation = GLES31.glGetUniformLocation(windArrowShaderProgram, "u_haloWidth")

        val vaos = IntArray(1)
        GLES31.glGenVertexArrays(1, vaos, 0)
        vao = vaos[0]
        GLES31.glBindVertexArray(vao)

        val quad = floatArrayOf(
            -1f, -1f, 1f, -1f, -1f, 1f,
            1f, -1f, -1f, 1f, 1f, 1f,
        )
        val vbos = IntArray(2)
        GLES31.glGenBuffers(2, vbos, 0)
        quadVbo = vbos[0]
        instanceVbo = vbos[1]

        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, quadVbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, quad.size * 4, quad.toFloatBuffer(), GLES31.GL_STATIC_DRAW)
        GLES31.glEnableVertexAttribArray(0)
        GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, 2 * 4, 0)
        GLES31.glVertexAttribDivisor(0, 0)

        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, instanceVbo)
        val stride = FLOATS_PER_INSTANCE * 4
        GLES31.glEnableVertexAttribArray(1)
        GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, stride, 0)
        GLES31.glVertexAttribDivisor(1, 1)
        GLES31.glEnableVertexAttribArray(2)
        GLES31.glVertexAttribPointer(2, 4, GLES31.GL_FLOAT, false, stride, 8)
        GLES31.glVertexAttribDivisor(2, 1)
        GLES31.glEnableVertexAttribArray(3)
        GLES31.glVertexAttribPointer(3, 4, GLES31.GL_FLOAT, false, stride, 24)
        GLES31.glVertexAttribDivisor(3, 1)
        GLES31.glEnableVertexAttribArray(4)
        GLES31.glVertexAttribPointer(4, 4, GLES31.GL_FLOAT, false, stride, 40)
        GLES31.glVertexAttribDivisor(4, 1)

        GLES31.glBindVertexArray(0)
        glReady = true
    }

    override fun drawInstanced(camera: Camera, instanceCount: Int, meld: Float) {
        if (windArrowShaderProgram == 0) return
        val proj = CameraSync.mapboxProjectionMatrix ?: projectionMatrixToFloatArray(camera.projectionMatrix)
        val mv = CameraSync.mapboxModelViewMatrix ?: matrix4ToFloatArray(camera.viewMatrix)

        GLES31.glUseProgram(windArrowShaderProgram)
        GLES31.glUniformMatrix4fv(
            GLES31.glGetUniformLocation(windArrowShaderProgram, "u_projection"),
            1,
            false,
            proj,
            0,
        )
        GLES31.glUniformMatrix4fv(GLES31.glGetUniformLocation(windArrowShaderProgram, "u_modelView"), 1, false, mv, 0)
        GLES31.glUniform1f(
            GLES31.glGetUniformLocation(windArrowShaderProgram, "u_mercatorZoomFix"),
            CameraSync.mercatorWorldPixelZoomFix(gpuGatherZoom),
        )

        val baseHalfWorld = baseHalfWorldMercatorForInstancedIcon()
        val (halfX, halfY) = resolveIconHalfExtentsXY(baseHalfWorld)
        GLES31.glUniform2f(
            GLES31.glGetUniformLocation(windArrowShaderProgram, "u_iconHalfExtent"),
            halfX,
            halfY,
        )
        GLES31.glUniform1f(GLES31.glGetUniformLocation(windArrowShaderProgram, "u_dataMeld"), meld)
        val stretchMax = (gridSource?.iconScalarNormMax ?: 53.64).toFloat().coerceAtLeast(1e-3f)
        GLES31.glUniform1f(GLES31.glGetUniformLocation(windArrowShaderProgram, "u_scalarStretchMax"), stretchMax)
        val compactWaveSwell = id.startsWith("maritime.") && id.endsWith("_dir.fill")
        GLES31.glUniform1f(
            GLES31.glGetUniformLocation(windArrowShaderProgram, "u_compactWaveSwellArrow"),
            if (compactWaveSwell) 1f else 0f,
        )

        // Maritime dirs use fixed nominal speed in the instance buffer; do not run the wind speed vs noData discard.
        // Wind arrows: skip fragment noData test — it compared normalized speed to an encoded-byte sentinel and
        // hid most arrows (including calm winds). Omit no-data instances in [EncodedGridVectorTileSource] instead.
        val noDataFrag = -1f
        if (noDataUniformLocation >= 0) {
            GLES31.glUniform1f(noDataUniformLocation, noDataFrag)
        }
        applyStrokeHaloUniforms(haloWidthUniformLocation, haloColorUniformLocation)

        GLES31.glBindVertexArray(vao)
        val depthWasEnabled = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glEnable(GLES31.GL_BLEND)
        GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
        GLES31.glDrawArraysInstanced(GLES31.GL_TRIANGLES, 0, 6, instanceCount)
        GLES31.glDisable(GLES31.GL_BLEND)
        if (depthWasEnabled) GLES31.glEnable(GLES31.GL_DEPTH_TEST)
        GLES31.glBindVertexArray(0)
        GLES31.glUseProgram(0)
    }

    private fun compileShader(type: Int, src: String): Int {
        val s = GLES31.glCreateShader(type)
        GLES31.glShaderSource(s, src)
        GLES31.glCompileShader(s)
        val status = IntArray(1)
        GLES31.glGetShaderiv(s, GLES31.GL_COMPILE_STATUS, status, 0)
        if (status[0] == 0) {
            val log = GLES31.glGetShaderInfoLog(s) ?: "<null>"
            Log.e(logTag, "Shader compile failed. type=$type shader=$s log=$log")
        }
        return s
    }

    companion object {
        /** Wider grid to the east so left-anchored arrow quads don’t pop in/out at the right edge when panning. */
        private const val VIEWPORT_EXTRA_EAST_FRACTION = 0.10

        private const val VERT_SHADER = """#version 310 es
precision highp float;
uniform mat4 u_projection;
uniform mat4 u_modelView;
uniform float u_mercatorZoomFix;
uniform vec2 u_iconHalfExtent;
uniform float u_dataMeld;
uniform float u_scalarStretchMax;
uniform float u_compactWaveSwellArrow;
layout(location = 0) in vec2 a_quad;
layout(location = 1) in vec2 a_tileXY;
layout(location = 2) in vec4 a_phase;
layout(location = 3) in vec4 a_colorA;
layout(location = 4) in vec4 a_colorB;
out vec4 v_color;
out vec2 v_local;
out float v_speedMs;
out float v_dirDeg;
void main() {
    float t = clamp(u_dataMeld, 0.0, 1.0);
    float k = clamp(u_compactWaveSwellArrow, 0.0, 1.0);
    float dirA = a_phase.x;
    float speedA = a_phase.y;
    float dirB = a_phase.z;
    float speedB = a_phase.w;
    // Shortest-path blend in degrees, then one unit vector. Linear mix(va,vb,t) collapses near t≈0.5 when A/B
    // oppose (~180°), so length→0 and atan(y,x) jitters — worse at 1× playback (larger Δt per frame).
    float dDeg = mod(dirB - dirA + 540.0, 360.0) - 180.0;
    float dirM = mod(dirA + t * dDeg + 360.0, 360.0);
    float radM = radians(dirM - 90.0);
    vec2 vm = vec2(cos(radM), sin(radM));
    // Wind: legacy atan(y,x). Maritime wave/swell (k=1): JS-aligned atan(x,y)-90°.
    float rotDegWind = degrees(atan(vm.y, vm.x));
    float rotDegMaritime = degrees(atan(vm.x, vm.y) - 1.57079632679);
    float rotDeg = mix(rotDegWind, rotDegMaritime, k);
    float rad = radians(rotDeg);
    float c = cos(rad);
    float sn = sin(rad);
    mat2 R = mat2(c, -sn, sn, c);

    // Pivot at tail (same xStart as fragment). Quad left is -1 in a_quad.x; tail is inset for compact maritime.
    float speedMs = mix(speedA, speedB, t);
    float sNorm = clamp(speedMs / max(u_scalarStretchMax, 1e-6), 0.0, 1.0);
    float sLen = mix(sNorm, 0.0, k);
    float xStartRaw = mix(-0.96, -0.90, k);
    float xEndLo = mix(-0.72, -0.50, k);
    float xEndHi = mix(0.68, 0.34, k);
    float xEnd = mix(xEndLo, xEndHi, sLen);
    float xStart = mix(xStartRaw, xEnd - 0.5 * (xEnd - xStartRaw), k);

    vec2 rel = a_quad * u_iconHalfExtent;
    vec2 pivot = vec2(xStart * u_iconHalfExtent.x, 0.0);
    vec2 offset = R * (rel - pivot) + pivot;

    vec4 world = vec4((a_tileXY + offset) * u_mercatorZoomFix, 0.0, 1.0);
    gl_Position = u_projection * u_modelView * world;
    v_color = vec4(mix(a_colorA.rgb, a_colorB.rgb, t), 1.0);
    v_local = a_quad;
    v_speedMs = mix(speedA, speedB, t);
    v_dirDeg = dirM;
}
"""

        private const val FRAG_SHADER = """#version 310 es
#define NO_DATA
precision highp float;
in vec4 v_color;
in vec2 v_local;
in float v_speedMs;
in float v_dirDeg;
uniform float u_scalarStretchMax;
/** 1.0 = shorter shaft, larger head (wave-dir / swell-dir only). */
uniform float u_compactWaveSwellArrow;
/** Encoded no-data sentinel as normalized 0–1 (metadata byte / 255); negative disables discard test. */
uniform float noData;
/** [GridLayerPaint.stroke] halo (icon-halo parity); width 0 disables. */
uniform vec4 u_haloColor;
uniform float u_haloWidth;
out vec4 fragColor;

/** Signed distance from point to infinite line through p1–p2 (matches reference project). */
float line_distance(vec2 p, vec2 p1, vec2 p2) {
    vec2 center = (p1 + p2) * 0.5;
    float len = length(p2 - p1);
    vec2 dir = (p2 - p1) / max(len, 1e-6);
    vec2 rel_p = p - center;
    return dot(rel_p, vec2(dir.y, -dir.x));
}

/** Distance to line segment p1–p2 (matches reference project). */
float segment_distance(vec2 p, vec2 p1, vec2 p2) {
    vec2 center = (p1 + p2) * 0.5;
    float len = length(p2 - p1);
    vec2 dir = (p2 - p1) / max(len, 1e-6);
    vec2 rel_p = p - center;
    float dist1 = abs(dot(rel_p, vec2(dir.y, -dir.x)));
    float dist2 = abs(dot(rel_p, dir)) - 0.5 * len;
    return max(dist1, dist2);
}

/**
 * Same CSG as arrow_stealth: min(d5, max(max(-d1,d3), -max(-d2,d4))).
 * Reference assumes y+ up; icon quad is y+ down, so evaluate in q = (x,-y).
 */
float arrow_stealth_sdf(vec2 pIcon, vec2 start, vec2 endTip, float head, float height, float linewidth, float shaftHalfH) {
    vec2 p = vec2(pIcon.x, -pIcon.y);
    vec2 end = endTip;
    float h = max(head, 1e-4);
    float lw = max(linewidth, 1e-4);
    vec2 ou = end - h * vec2(1.0, -height);
    vec2 ol = end - h * vec2(1.0, height);
    vec2 inner = end - vec2(0.75 * h, 0.0);
    float d1 = line_distance(p, ou, end);
    float d2 = line_distance(p, ou, inner);
    float d3 = line_distance(p, ol, end);
    float d4 = line_distance(p, ol, inner);
    float d5 = segment_distance(p, start, end - vec2(lw, 0.0));
    float headComb = max(max(-d1, d3), -max(-d2, d4));
    return min(d5 - shaftHalfH, headComb);
}

void main() {
    vec2 p = v_local;
   
#ifdef NO_DATA
    // Match encoded raster: compare normalized speed to metadata noData (see noData uniform).
    // Maritime swell arrows pass noData=-1 from Kotlin so this branch is off (nominal speed is not real swell height).
    if (noData >= 0.0) {
        float sNorm = clamp(v_speedMs / max(u_scalarStretchMax, 1e-6), 0.0, 1.0);
        float eps = max(1.0 / 256.0, 1e-4);
        if (abs(sNorm - noData) < eps) {
            discard;
        }
    }
#endif

    // Right-pointing arrow in local icon space.
    float s = clamp(v_speedMs / max(u_scalarStretchMax, 1e-6), 0.0, 1.0);
    float k = clamp(u_compactWaveSwellArrow, 0.0, 1.0);
    // Wind: length scales with s (shortest ≈ s=0). Maritime: fixed at that short end so size matches calm wind-dir.
    float sLen = mix(s, 0.0, k);

    // Hide "down" arrow orientation for wave-dir/swell-dir only.
    // Our icon rotation convention is: arrow rotation angle = dirDeg - 90.
    if (k > 0.5) {
        const float EPS_ARROW_DEG = .02;
        const float TARGET_ARROW_ANGLE_DEG = 91.43; // down
        float arrowAngle = mod(v_dirDeg - 90.0, 360.0);
        float delta = abs(arrowAngle - TARGET_ARROW_ANGLE_DEG);
        //delta = min(delta, 360.0 - delta);
        if (delta < EPS_ARROW_DEG) discard;
   }

    float xStartRaw = mix(-0.96, -0.90, k);
    float xEndLo = mix(-0.72, -0.50, k);
    float xEndHi = mix(0.68, 0.34, k);
    float xEnd = mix(xEndLo, xEndHi, sLen);
    float xStart = mix(xStartRaw, xEnd - 0.5 * (xEnd - xStartRaw), k);

    // Web grid-field.frag is the same for wind and maritime angle grids (arrow_stealth + filled(d, 0.15, 0.01)).
    // Do not thin the k=1 maritime branch — that made wave/swell arrows look narrower than JS.
    float shaftHy = 0.10;
    float headY = 0.38;
    float tipA = 0.32;
    float tipB = 0.42;
    float tipX = min(xEnd + mix(tipA, tipB, sLen), 0.99);
    float dBarb = 0.045;
    float xBarb = max(xStart + 0.05, xEnd - dBarb);
    float headLen = max(tipX - xBarb, 0.02);
    float heightRat = headY / headLen;
    float linewidth = max(tipX - xEnd, 1e-4);
    vec2 tip = vec2(tipX, 0.0);
    float sdf = arrow_stealth_sdf(p, vec2(xStart, 0.0), tip, headLen, heightRat, linewidth, shaftHy);
    float aa = 0.048;
    float fillBias = 0.062;
    float fillEdge = sdf - fillBias;
    float fillMask = 1.0 - smoothstep(-aa, aa, fillEdge);
    vec4 fillColor = vec4(v_color.rgb, fillMask * v_color.a);

    // Mapbox-style icon halo: widen the SDF cutoff outward, then keep only the ring outside the fill.
    if (u_haloWidth > 0.0) {
        float haloMask = (1.0 - smoothstep(-aa, aa, fillEdge - u_haloWidth)) * (1.0 - fillMask);
        vec3 rgb = mix(u_haloColor.rgb, fillColor.rgb, fillMask);
        float alpha = max(haloMask * u_haloColor.a, fillColor.a);
        fragColor = vec4(rgb, alpha);
    } else {
        fragColor = fillColor;
    }
}
"""
    }
}
