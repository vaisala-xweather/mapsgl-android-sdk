/**
 *  RasterLayerRenderer.kt
 *
 *
 *  Created by Jason Suto 12/21/23.
 *  Adapted from IOS version.
 */
package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController

/**
 *  RasterLayerRenderer.kt
 *
 *  A lot of this is handled in TileLayerRenderer
 *
 *  @author Jason Suto on 12/22/23.
 */
/// TODO: If `RasterLayerRenderer` doesn't need to add/override any methods
// (everything can be done in `TileRenderer` or `extension TileLayer where Context == RasterTileLayer.RenderContext`), change this to a typealias.
open class RasterLayerRenderer : TileLayerRenderer<com.xweather.mapsgl.tiles.TileData, LayerRenderContext<Any>>() {

    /** [TileLayer.render] uses the 3-arg overload with a [Camera]; this is unused for raster tiles. */
    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {}

    override fun onAdd() {}

    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {}

    override fun onRemove() {}

    override suspend fun onMove() {}

    override suspend fun update() {}

    override fun onMoveStart() {}

    override suspend fun onMoveEnd() {}

    override fun onResize() {}

    override fun onClick() {}

    override fun onVisible() {}

    override fun onHidden() {}

    /** Called from TileLayerRenderer.prerender*/
    @Throws(Exception::class)
    override fun setUpRenderPass(): RenderPass {
        renderPass = RenderPass(tileLayer?.source!!.id, tileLayer!!.paint)
        renderPass.id = id
        return renderPass
    }

    override var id: String
        get() = tileLayer!!.id
        set(value) {}
}

@Deprecated("Use `RasterLayerRenderer` instead.", ReplaceWith("RasterLayerRenderer"))
internal typealias RasterRenderer = RasterLayerRenderer
