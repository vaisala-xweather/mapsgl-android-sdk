package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.Partial
import com.xweather.mapsgl.anim.TimeSeriesState
import com.xweather.mapsgl.gl.EmptyRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.SampleChannel
import com.xweather.mapsgl.types.math_type.ValueRange

interface EmptyRendererOptions : TileRendererOptions {
    var palette: Partial<ColorScaleOptions>
    var channel: SampleChannel
    var interpolation: InterpolationMode
    var smoothing: Double
    var drawRange: Partial<ValueRange>
}

open class EmptyRenderer(
    override var id: String
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {

    var TAG = "EncodedDataRenderer"

    private var _timeState: TimeSeriesState = TimeSeriesState(
        position = 0,
        index = 0,
        nextIndex = 0
    )

    override fun initialize(context: RenderContext<Any>) {
    }

    init {
        cachesTextures = false
    }

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {
        TODO("Not yet implemented")
    }

    override fun onAdd() {
        TODO("Not yet implemented")
    }

    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {
        TODO("Not yet implemented")
    }

    override fun setNeedsUpdate() {}

    override fun setUpRenderPass(): RenderPass {
        return EmptyRenderPass(tileLayer?.source!!.id, tileLayer!!.paint)
    }

    override suspend fun update() {
        TODO("Not yet implemented")
    }

    open fun setup(paint: LayerPaint) {
    }

    fun createColorLookupTables(options: ColorScaleOptions, drawRange: ClosedRange<Double>) {
    }
}

