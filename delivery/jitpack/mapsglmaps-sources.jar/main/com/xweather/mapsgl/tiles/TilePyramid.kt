package com.xweather.mapsgl.tiles

import android.util.Log
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.StaggeredIntervalPhase
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.coordinates.LatitudeLongitude
import com.xweather.mapsgl.coordinates.MapBounds
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.sources.TileSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.Calendar
import java.util.Date
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.floor

private const val TAG = "TilePyramid"

data class LatLonBounds(
    val westExtent: Double,
    val southExtent: Double,
    val eastExtent: Double,
    val northExtent: Double,
    val wrapped: Boolean = false
)

data class GLCoordinate2D(var x: Double, var y: Double)

/**
 *  TilePyramid.kt
 *
 *  Adapted from IOS version.
 *  @author Jason Suto on 12/18/23.
 */
class TilePyramid<DataType : TileData>(private val layer: TileLayer) {
    val key: String = "${layer.mapController?.account?.id}_${layer.mapController?.account?.secret}"
    private val worldCoord = TileCoord(0, 0, 0)
    @Volatile
    private var quietWorldTileJob: Job? = null
    private var timesArray: Array<String>? = arrayOf("", "")
    private lateinit var timeline: Timeline
    var formattedDate: String? = null
    lateinit var fallbackOptions: TileRequestOptions
    val maxIntervals = 8
    var memUsageLast = 0f

    var tileSource: TileSource<TileData> //<DataType>
        get() = layer.source
        set(value) {
            layer.source = value
        }

    val tileCache: TileCache<com.xweather.mapsgl.sources.DataType>
        get() = tileSource.tileCache

    /**
     * Alternate time-string keys for the same instant (layer canonical vs global timeline format).
     * Tiles may have been stored under either string before [filterTimelineByValidTimes] was fixed.
     */
    private fun cacheLookupTimeKeys(layerLists: LayerTimeline?, canonicalTime: String, timeLong: Long?): List<String> {
        val keys = LinkedHashSet<String>()
        if (canonicalTime.length >= 2) {
            keys.add(canonicalTime)
        }
        if (timeLong != null) {
            val globalIdx = Timeline.timeLongs.indexOf(timeLong)
            if (globalIdx >= 0) {
                Timeline.timeStrings.getOrNull(globalIdx)?.let { global ->
                    if (global.length >= 2) keys.add(global)
                }
            }
            layerLists?.timeLongs?.indexOf(timeLong)?.takeIf { it >= 0 }?.let { layerIdx ->
                layerLists.timeStrings.getOrNull(layerIdx)?.let { layer ->
                    if (layer.length >= 2) keys.add(layer)
                }
            }
        }
        return keys.toList()
    }

    /**
     * True when this coord×time is already downloaded, in flight, or retained in native/ready bookkeeping.
     * Scrub must consult [TileList.readyList] and [TileCache.nativeCache], not only [TileCache.tiles],
     * because LRU eviction removes LRU entries while the bytes remain available for re-bind.
     */
    private fun encodedPairSatisfied(
        sourceId: String,
        coord: TileCoord,
        canonicalTime: String,
        timeLong: Long? = null,
        layerLists: LayerTimeline? = Timeline.sourceTimeHash[sourceId],
    ): Boolean {
        for (timeKey in cacheLookupTimeKeys(layerLists, canonicalTime, timeLong)) {
            val hash = TileCoord(coord.x, coord.y, coord.z, 0, timeKey).hash()
            if (tileCache._pending.containsKey(hash) || tileCache._requestedTiles.containsKey(hash)) {
                return true
            }
            if (tileCache.tiles.containsKey(hash)) {
                return true
            }
            if (tileCache.nativeCache.containsKey("$sourceId$hash")) {
                return true
            }
            if (TileList.readyList.containsTimeInTile(sourceId, coord.hashShort(), timeKey)) {
                return true
            }
        }
        return false
    }

    /**
     * After scrub while paused, re-queue visible tiles that are already loaded so [TileCache.bindTextures]
     * can restore them from native cache without another HTTP pass.
     */
    internal fun requeueLoadedVisibleTilesForBind(coords: List<TileCoord>, times: Array<String>?) {
        if (!tileSource.isEncoded || times.isNullOrEmpty()) return
        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val sourceId = layer.source.id
        for (time in times) {
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            for (coord in coords) {
                if (!encodedPairSatisfied(sourceId, coord, time, timeLong, layerLists)) continue
                val lookupCoord = TileCoord(coord.x, coord.y, coord.z, time = time)
                val hash = lookupCoord.hash()
                if (!tileCache.reinsertShellForNativeBindIfNeeded(lookupCoord, hash)) continue
                tileCache.withBindListLock {
                    if (!tileCache.bindList.contains(hash)) {
                        tileCache.bindList.add(hash)
                    }
                }
            }
        }
    }

    /**
     * Maps a timeline instant to this layer's [LayerTimeline] valid-time list: exact match, else next valid time
     * at or after the scrub, else last valid time (same idea as [filterTimelineByValidTimes]).
     * Paused mode used to require an **exact** tick match, so new layers often requested **no** times until play().
     */
    private fun closestLayerValidTime(layerLists: LayerTimeline, timelineLong: Long): Pair<Long, String>? {
        if (layerLists.timeLongs.isEmpty()) return null
        val searchResult = layerLists.timeLongs.binarySearch(timelineLong)
        if (searchResult >= 0) {
            return layerLists.timeLongs[searchResult] to layerLists.timeStrings[searchResult]
        }
        val insertionPoint = -(searchResult + 1)
        if (insertionPoint < layerLists.timeLongs.size) {
            val j = insertionPoint
            return layerLists.timeLongs[j] to layerLists.timeStrings[j]
        }
        val last = layerLists.timeLongs.lastIndex
        return layerLists.timeLongs[last] to layerLists.timeStrings[last]
    }

    /**
     * Time strings to request while paused/scrubbing. Uses the same phase mapping as
     * [LayerTimeline.computeGlobalAnimationTarget] / [RenderPass] (sparse playback lists until
     * staggered fill is [com.xweather.mapsgl.anim.StaggeredIntervalPhase.Full]), not raw global
     * [Timeline.currentPhaseA]/[Timeline.currentPhaseB] indices via [filterABTimesByValidTimes].
     */
    internal fun timesForPausedOrScrubDownload(sourceId: String): Array<String> {
        val layerLists = Timeline.sourceTimeHash[sourceId] ?: return emptyArray()
        val collected = LinkedHashSet<String>()

        fun addRequestInOrder(timeLong: Long, timeString: String) {
            val insertionIndex = layerLists.reqLongs.binarySearch(timeLong)
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                layerLists.reqLongs.add(correctIndex, timeLong)
                layerLists.reqStrings.add(correctIndex, timeString)
            }
        }

        // Match the next draw frame (idle: one nearest interval; playing/scrub: phase A/B + meld).
        val target = layerLists.computeGlobalAnimationTarget()
        if (target.phaseA.length > 4) collected.add(target.phaseA)
        if (target.phaseB.length > 4 && target.phaseB != target.phaseA) collected.add(target.phaseB)

        if (collected.isEmpty()) {
            if (layerLists.phaseAString.length > 4) collected.add(layerLists.phaseAString)
            if (layerLists.phaseBString.length > 4) collected.add(layerLists.phaseBString)
        }

        if (collected.isEmpty()) {
            return filterABTimesByValidTimes(sourceId)
        }

        for (time in collected) {
            val idx = layerLists.timeStrings.indexOf(time)
            if (idx >= 0) {
                addRequestInOrder(layerLists.timeLongs[idx], time)
            }
        }
        return collected.toTypedArray()
    }

    /** Phase-A/B time strings used while the timeline is paused (scrub). */
    internal fun scrubPhaseTimesArray(): Array<String> =
        timesForPausedOrScrubDownload(layer.source.id)

    /** Legacy global-phase mapping; only used as last resort in [timesForPausedOrScrubDownload]. */
    private fun filterABTimesByValidTimes(sourceId: String): Array<String> {

        val layerLists = Timeline.sourceTimeHash[sourceId] ?: return emptyArray()
        val result = mutableListOf<String>()

        fun addRequestInOrder(timeLong: Long, timeString: String) {
            val insertionIndex = layerLists.reqLongs.binarySearch(timeLong)
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                layerLists.reqLongs.add(correctIndex, timeLong)
                layerLists.reqStrings.add(correctIndex, timeString)
            }
        }

        if (Timeline.prefersSingleIntervalIdleTarget()) {
            val target = layerLists.computeGlobalAnimationTarget()
            if (target.phaseA.length > 4) {
                val idx = layerLists.timeStrings.indexOf(target.phaseA)
                if (idx >= 0) {
                    addRequestInOrder(layerLists.timeLongs[idx], target.phaseA)
                }
                return arrayOf(target.phaseA)
            }
        }

        val timeLongA = Timeline.timeLongs[Timeline.currentPhaseA]

        closestLayerValidTime(layerLists, timeLongA)?.let { (validLongA, validStringA) ->
            result.add(validStringA)
            addRequestInOrder(validLongA, validStringA)
        }

        val timeLongB = Timeline.timeLongs[Timeline.currentPhaseB]

        if (timeLongA != timeLongB) {
            closestLayerValidTime(layerLists, timeLongB)?.let { (validLongB, validStringB) ->
                result.add(validStringB)
                addRequestInOrder(validLongB, validStringB)
            }
        }

        return result.toTypedArray()
    }

    /** Make sure you don't request times not included in valid times  **/
    private fun filterTimelineByValidTimes(): Array<String> {
        val layerLists = Timeline.sourceTimeHash[layer.source.id] ?: return emptyArray()

        // Ensure the list is sorted before we begin, as binarySearch requires it.
        // This is a safeguard in case the list was modified incorrectly elsewhere.
        if (layerLists.timeLongs.isSorted().not()) {
            layerLists.timeLongs.sort()
        }

        val returnList: MutableList<String> = mutableListOf()

        // A helper extension function to add items while maintaining sort order.
        fun MutableList<Long>.addInOrder(element: Long, associatedString: String) {
            val insertionIndex = this.binarySearch(element)
            // If the item is not already present, add it.
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                this.add(correctIndex, element)
                layerLists.reqStrings.add(correctIndex, associatedString)
            }
        }

        for ((index, timeString) in Timeline.timeStrings.withIndex()) {
            val timelineLong = Timeline.timeLongs[index]

            // Search for the timeline time in the layer's valid times.
            val searchResult = layerLists.timeLongs.binarySearch(timelineLong)

            if (searchResult >= 0) {
                // --- Exact match found ---
                // Always use the layer's canonical time string for cache keys and HTTP requests.
                // Using global Timeline.timeStrings here caused scrub (filterABTimesByValidTimes,
                // which uses layer strings) to miss tiles that were downloaded during playback.
                if (layerLists.downloadAllowsLayerIndex(searchResult)) {
                    val layerTimeString = layerLists.timeStrings[searchResult]
                    returnList.add(layerTimeString)
                    layerLists.reqLongs.addInOrder(timelineLong, layerTimeString)
                }
            } else {
                // --- No exact match, find the next largest (closest) time ---
                val insertionPoint = -(searchResult + 1)

                if (insertionPoint < layerLists.timeLongs.size) {
                    if (layerLists.downloadAllowsLayerIndex(insertionPoint)) {
                        val nextClosestLong = layerLists.timeLongs[insertionPoint]
                        val nextClosestString = layerLists.timeStrings[insertionPoint]

                        returnList.add(nextClosestString)
                        layerLists.reqLongs.addInOrder(nextClosestLong, nextClosestString)
                    }
                } else {
                    if (layerLists.timeLongs.isNotEmpty()) {
                        val lastIdx = layerLists.timeLongs.lastIndex
                        if (layerLists.downloadAllowsLayerIndex(lastIdx)) {
                            val lastValidLong = layerLists.timeLongs[lastIdx]
                            val lastValidString = layerLists.timeStrings[lastIdx]
                            returnList.add(lastValidString)
                            layerLists.reqLongs.addInOrder(lastValidLong, lastValidString)
                        }
                    }
                }
            }
        }

        return returnList.toTypedArray()
    }

    // You might need to add this helper extension function to your project if it doesn't exist.
// It can be placed at the top level of any utility file.
    fun <T : Comparable<T>> List<T>.isSorted(): Boolean {
        for (i in 0 until this.size - 1) {
            if (this[i] > this[i + 1]) {
                return false
            }
        }
        return true
    }

    /**
     * Read-only estimate of how many new encoded (coord×time) pairs would be queued for [coords],
     * using the same metadata, time filtering, and cache checks as [requestTilesForDownload]
     * but without mutating caches, Timeline pending lists, or requesting bytes.
     * Used to fix download % across multiple layers before any layer runs.
     */
    suspend fun preflightEncodedNewPairCount(
        coords: List<TileCoord>,
        options: TileRequestOptions,
    ): Int {
        if (!tileSource.isEncoded) return 0

        timeline = layer.mapController!!.timeline
        if (tileSource.metaDataNeeded > 0) {
            val startDate = if (this::timeline.isInitialized) timeline.start else null
            val endDate = if (this::timeline.isInitialized) timeline.end else null
            val metadataResult = tileSource.fetchMetadata(startDate, endDate)
            if (metadataResult.isFailure) return 0
        }

        ensureFormattedDate(options)

        val timesArrayLocal = resolveDownloadTimes()

        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val sourceId = layer.source.id
        var count = 0
        timesArrayLocal?.forEach { time ->
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            coords.forEach { coord ->
                if (!encodedPairSatisfied(sourceId, coord, time, timeLong, layerLists)) {
                    count++
                }
            }
        }
        return count
    }

    /**
     * Clears pending-download bookkeeping for [intervalChunk] when encoded work is cancelled
     * or fails before [TileCache.bindTextures] runs (which normally removes these entries).
     * Safe to call after successful bind: second remove is a no-op for completed counts.
     */
    private fun releasePendingEncodedTimelineKeysForChunk(
        sourceId: String,
        tileCoord: TileCoord,
        intervalChunk: List<String>,
    ) {
        val short = tileCoord.hashShort()
        for (interval in intervalChunk) {
            TileList.pendingList.remove(sourceId, short, interval)
            Timeline.removePendingEncodedDownload(
                sourceId,
                TileCoord(tileCoord.x, tileCoord.y, tileCoord.z, 0, interval).hash(),
            )
        }
    }

    /**
     * Fetches z=0 for the idle timeline interval(s) when missing, without progress UI.
     * Used during pan/zoom while the timeline is paused.
     */
    internal suspend fun scheduleQuietIdleWorldTileDownload(
        options: TileRequestOptions,
        externalScope: CoroutineScope,
    ) {
        if (!layer.visible || !tileSource.isEncoded) return
        timeline = layer.mapController!!.timeline
        if (timeline.state == AnimationState.playing) return
        if (floor(tileSource.minZoom).toInt() > 0) return

        ensureFormattedDate(options)
        val date = formattedDate ?: return
        val times = timesForPausedOrScrubDownload(layer.source.id)
        if (times.isEmpty()) return

        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val sourceId = layer.source.id
        val missingIntervals = times.filter { time ->
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            !encodedPairSatisfied(sourceId, worldCoord, time, timeLong, layerLists)
        }.distinct()
        if (missingIntervals.isEmpty()) return

        val alreadyRunning = synchronized(this) {
            quietWorldTileJob?.isActive == true
        }
        if (alreadyRunning) return

        for (interval in missingIntervals) {
            worldCoord.time = interval
            val hash = worldCoord.hash()
            tileCache._requestedTiles[hash] = System.currentTimeMillis()
        }

        quietWorldTileJob = externalScope.launch(Dispatchers.Default) {
            try {
                missingIntervals.chunked(24 / tileSource.datasets.size.coerceAtLeast(1)).forEach { intervalChunk ->
                    try {
                        tileSource.requestTiles(
                            worldCoord,
                            options,
                            date,
                            fromAnimation = false,
                            intervals = intervalChunk,
                            trackDownloadProgress = false,
                        )
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Log.e(TAG, "Quiet world tile download failed for ${layer.id}", e)
                        for (interval in intervalChunk) {
                            worldCoord.time = interval
                            tileCache._requestedTiles.remove(worldCoord.hash())
                        }
                    }
                    val mapController = layer.mapController
                    if (mapController is MapboxMapController) {
                        mapController.mapboxMap?.executeOnRenderThread {
                            mapController.layerHosts[layer.id]?.bindTextures(layer.source.id)
                        }
                    }
                }
            } finally {
                synchronized(this@TilePyramid) {
                    quietWorldTileJob = null
                }
            }
        }
    }

    /** Determine which tiles are already downloaded, and request the ones that aren't */
    suspend fun requestTilesForDownload(
        coords: List<TileCoord>,
        options: TileRequestOptions,
        externalScope: CoroutineScope,
    ): Result<Unit> { // Keep Result<Unit> signature

        timeline = layer.mapController!!.timeline
        if (tileSource.metaDataNeeded > 0 && tileSource.isEncoded) {
            val startDate = if (this::timeline.isInitialized) timeline.start else null
            val endDate = if (this::timeline.isInitialized) timeline.end else null

            if (pr.ON) pr.p(
                TAG,
                pr.tileReq,
                "requestTilesForDownload() calling and awaiting fetchMetadata() with $startDate / $endDate"
            )

            // Make fetchMetadata a suspend function and await its completion
            val metadataResult = tileSource.fetchMetadata(startDate, endDate)

            // If fetching fails, stop and propagate the failure.
            if (metadataResult.isFailure) {
                return Result.failure(
                    metadataResult.exceptionOrNull()
                        ?: IllegalStateException("Metadata fetch failed without an exception.")
                )
            }
            // If successful, the function will now continue instead of returning early.
            if (pr.ON) pr.p(
                TAG,
                pr.fetchMeta,
                "requestTilesForDownload() proceeding, hopefully AFTER metadata fetch  with $startDate / $endDate\""
            )

        } else {
            //if (pr.ON) pr.p(TAG, pr.tileReq, "requestTilesForDownload() SKIPPING METADATA FETCH", 2 )
        }

        ensureFormattedDate(options)

        timesArray = resolveDownloadTimes()

        if (pr.ON && pr.tileDownloadAudit.active) {
            timesArray?.let { arr ->
                val seen = HashMap<String, Int>()
                for (t in arr) {
                    seen[t] = (seen[t] ?: 0) + 1
                }
                val dups = seen.filter { it.value > 1 }
                if (dups.isNotEmpty()) {
                    pr.p(
                        TAG,
                        pr.tileDownloadAudit,
                        "timesArray contains duplicate time strings (same pass): $dups source=${layer.source.id} layer=${layer.id}"
                    )
                }
            }
            val zMin = floor(tileSource.minZoom).toInt()
            val zMax = floor(tileSource.maxZoom).toInt()
            for (coord in coords) {
                val n = powerTableI[coord.z]
                val badZoom = coord.z < zMin || coord.z > zMax
                val badXY = n <= 0 || coord.x < 0 || coord.y < 0 || coord.x >= n || coord.y >= n
                if (badZoom || badXY) {
                    pr.p(
                        TAG,
                        pr.tileDownloadAudit,
                        "download queue invalid tile (z not in [$zMin,$zMax] or x/y out of range): z=${coord.z} x=${coord.x} y=${coord.y} n=$n source=${layer.source.id} layer=${layer.id}"
                    )
                }
            }
        }

        val coordIntervalMap: HashMap<String, MutableList<String>> =
            HashMap() // Map: CoordHash -> List<TimeIntervalString>

        var newDownloadPairs = 0
        var skippedAlreadyTracked = 0
        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val sourceId = layer.source.id

        timesArray?.forEach { time ->
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            coords.forEach { coord ->
                if (encodedPairSatisfied(sourceId, coord, time, timeLong, layerLists)) {
                    skippedAlreadyTracked++
                    return@forEach
                }
                val tempCoord = TileCoord(coord.x, coord.y, coord.z, 0, time)
                val hash = tempCoord.hash()
                Timeline.addPendingEncodedDownload(layer.source.id, hash)
                coordIntervalMap.getOrPut(coord.hashShort()) { mutableListOf() }.add(time)
                newDownloadPairs++
                tileCache._requestedTiles[hash] = System.currentTimeMillis() // Mark as requested
                if (pr.ON) pr.p(
                    TAG,
                    pr.infiniteLoad,
                    " requestTilesForDownload() pending size: ${layer.source.id} ${hash}"
                )
            }
        }

        if (pr.ON && pr.tileDownloadAudit.active) {
            coordIntervalMap.forEach { (shortHash, list) ->
                val dupTimes = list.groupingBy { it }.eachCount().filter { it.value > 1 }
                if (dupTimes.isNotEmpty()) {
                    pr.p(
                        TAG,
                        pr.tileDownloadAudit,
                        "DUPLICATE time in interval list for one tile (should not happen): hashShort=$shortHash counts=$dupTimes layer=${layer.id}"
                    )
                }
            }
            pr.p(
                TAG,
                pr.tileDownloadAudit,
                "requestTilesForDownload summary: layer=${layer.id} source=${layer.source.id} coords=${coords.size} timeSlots=${timesArray?.size ?: 0} newPairs=$newDownloadPairs skippedAlreadyPresent=$skippedAlreadyTracked coordGroups=${coordIntervalMap.size}"
            )
        }

        // Request WorldCoord when not playing.
        // This was causing zoom level 0 tiles to be requested every time the timeline is paused.
        // Commented out to avoid redundant zoom-0 requests during pause/play transitions.
        //
        // if (timeline.state != AnimationState.playing && tileSource.minZoom.toInt() == 0) {
        //     timesArray?.forEach { time ->
        //         worldCoord.time = time
        //         val hash = worldCoord.hash()
        //         if (!tileCache.tiles.containsKey(hash) && !tileCache._pending.containsKey(hash) && !tileCache._requestedTiles.containsKey(
        //                 hash
        //             )
        //         ) {
        //             coordIntervalMap.getOrPut(worldCoord.hashShort()) { mutableListOf() }.add(time)
        //             tileCache._requestedTiles[hash] = System.currentTimeMillis() // Mark as requested
        //         }
        //     }
        // }

        return try { // Wrap in try-catch for potential issues during launch/join
            coroutineScope { // Create a scope for launching concurrent jobs
                val downloadJobs = mutableListOf<Job>() // Keep track of launched jobs
                // Prevent too many concurrent download/processing jobs from contending for CPU,
                // cache state, and render-thread binds (can otherwise cause frame hitches).
                val maxConcurrentRequests = 30
                val semaphore = Semaphore(maxConcurrentRequests)

                if (tileSource.isEncoded) {//Encoded
                    coordIntervalMap.forEach { (coordShortHash, intervals) ->
                        val tileCoord = TileCoord.fromHashShort(coordShortHash)
                        if (tileCoord != null) {
                            intervals.chunked(24 / tileSource.datasets.size).forEach { intervalChunk ->
                                downloadJobs.add(launch {
                                    try {
                                        semaphore.withPermit {
                                            tileSource.requestTiles(
                                                tileCoord,
                                                options,
                                                formattedDate!!,
                                                true,
                                                intervalChunk
                                            )
                                        }
                                    } catch (e: CancellationException) {
                                        throw e
                                    } catch (e: Exception) {
                                        Log.e(TAG, "Error in tile request job for ${tileCoord.hashShort()}", e)
                                    } finally {
                                        releasePendingEncodedTimelineKeysForChunk(
                                            tileSource.id,
                                            tileCoord,
                                            intervalChunk,
                                        )
                                    }

                                    if (layer.mapController != null) {
                                        val mapController = layer.mapController
                                        if (mapController is MapboxMapController) {
                                            mapController.mapboxMap?.executeOnRenderThread {
                                                mapController.layerHosts[layer.id]?.bindTextures(layer.source.id)
                                            }
                                        } else {
                                            //todo: Logic for other map types as needed
                                        }
                                    }
                                })
                            }
                        }
                    }
                } else { // Raster
                    coordIntervalMap.forEach { (coordShortHash, intervals) ->
                        val tileCoord = TileCoord.fromHashShort(coordShortHash)
                        if (tileCoord != null) {
                            if (pr.ON) pr.p(
                                TAG,
                                pr.rasterFix,
                                "requestTilesForDownload() coordShortHash: $coordShortHash ----------------"
                            )
                            for (interval in intervals) {
                                if (pr.ON) pr.p(TAG, pr.rasterFix, "requestTilesForDownload() interval: ${interval}")

                                downloadJobs.add(launch {
                                    try {
                                        semaphore.withPermit {
                                            tileSource.requestTiles(tileCoord, options, interval, true)
                                        }
                                    } catch (e: Exception) {
                                        if (pr.ON) pr.p(TAG, pr.rasterFix, "requestTilesForDownload() ERROR: ${e}", 2)
                                    }
                                })
                            }
                        }
                    }
                } // end Raster

                if (!Timeline.threadDownload) { //original method that slows down while downloading
                    downloadJobs.joinAll()
                } else {
                    if (downloadJobs.isNotEmpty()) {
                        val batchSize = downloadJobs.size // Capture size for the log message
                        if (pr.ON) pr.p(
                            TAG,
                            pr.tileRequest,
                            "Launching completion logger coroutine for $batchSize jobs."
                        )
                        externalScope.launch(Dispatchers.Default) { // Use Default or IO for waiting
                            try {
                                if (pr.ON) pr.p(
                                    TAG,
                                    pr.tileRequest,
                                    "[CompletionLogger] Waiting for $batchSize jobs..."
                                )
                                downloadJobs.joinAll() // This coroutine suspends here
                            } catch (e: CancellationException) {
                                Log.w(TAG, "[CompletionLogger] Waiting coroutine cancelled.")
                            } catch (e: Exception) {
                                Log.e(TAG, "[CompletionLogger] Error waiting for job batch completion", e)
                            }
                        }
                        layer.mapController!!.checkDownloadStatus(
                            layer.id,
                            tileCache.pendingCount
                        ) // Check remaining pending

                    }
                }
            } // End coroutineScope

            Result.success(Unit) // Indicate the overall process initiated successfully
        } catch (e: Exception) {
            println("$TAG Error during concurrent download process, $e")
            Result.failure(e) // Return failure if the scope or launching had issues
        }
    }

    fun checkAndClearMemory(coords: List<TileCoord>) {
        if (true || tileCache.memUsage != memUsageLast) {
            if (pr.ON) pr.p(TAG, pr.clearMem, "from requestTileForDownload(), mem is ${tileSource.tileCache.memUsage}")
            memUsageLast = tileCache.memUsage

            if (coords.isNotEmpty()) {
                if (pr.ON) pr.p(TAG, pr.clearMem, "requestTileForDownload(), zoom from Coords: ${coords.first().z}")
                if (tileSource.tileCache.memUsage > .05f) {
                    //if(pr.ON) pr.p (TAG, pr.clearMem, "requestTileForDownload(),memUsage over 80%",2)
                    //tileCache.clearOtherZooms(coords.first().z)
                    //tileCache.clearOutsideBounds(this.layer.persistentTileBounds)
                    //tileCache.removeAll()

                    //tileSource.tileManager.pending.remove()
                    //_pending.remove(coord.hash())
                }
            }
        }
    }

    private fun removeOutOfBounds(
        bounds: MapBounds<LatitudeLongitude> /*LatLonBounds*/,
        coords: /*Mutable*/List<TileCoord>
    ) {
        coords.filter { coord ->
            coord.mapBounds?.let { coordBounds ->
                if (coordBounds.eastExtent < bounds.westExtent || coordBounds.westExtent > bounds.eastExtent) {
                    return@filter false
                } else return@filter !(coordBounds.southExtent > bounds.northExtent || coordBounds.northExtent < bounds.southExtent)
            } ?: true
        }
    }

    private fun sortAroundCenter(center: GLCoordinate2D, coords: MutableList<TileCoord>): MutableList<TileCoord> {
        if (coords.isNotEmpty()) {
            //Todo: further optimizations possible
            val numTiles = (powerTableD[coords.first().z])
            var dax: Double
            var day: Double
            var da: Double
            coords.sortBy { coord ->
                val aCenter = coord.getCenter()
                dax = (center.x * (numTiles)) - (aCenter.x + .5f)
                day = (center.y * (numTiles)) - (aCenter.y + .5f)
                da = (dax * dax) + (day * day)
                da
            }
        }
        return coords
    }

    private fun ensureFormattedDate(options: TileRequestOptions) {
        if (formattedDate != null) return
        val calendar = Calendar.getInstance()
        calendar.time = Date()
        calendar.add(Calendar.HOUR_OF_DAY, -12)
        formattedDate = bracketedRasterInterval(options.formatDate(calendar.time))
        fallbackOptions = options
    }

    /**
     * Image/raster tiles use bracketed validTimes strings (e.g. `["2025-05-19T12:00:00Z"]`) for URL
     * encoding and texture hash keys. [TileRequestOptions.formatDate] returns plain ISO without brackets.
     */
    private fun bracketedRasterInterval(isoUtc: String): String {
        val trimmed = isoUtc.trim()
        if (trimmed.startsWith("[\"")) return trimmed
        val inner = trimmed.removePrefix("[").removeSuffix("]").trim('"')
        return "[\"$inner\"]"
    }

    /**
     * When no timeline/valid-times exist for a raster source (e.g. satellite geocolor on a map without
     * a scrubber), still request and draw a single recent frame.
     */
    private fun ensureStaticRasterLayerTimeline(sourceId: String, interval: String) {
        val lt = Timeline.sourceTimeHash.getOrPut(sourceId) { LayerTimeline(sourceId) }
        if (lt.timeStrings.isNotEmpty()) return
        lt.timeStrings = mutableListOf(interval)
        lt.timeLongs = mutableListOf(System.currentTimeMillis() / 1000L)
        lt.phaseAString = interval
        lt.phaseBString = interval
        lt.onValidTimesUpdated()
    }

    private fun resolveDownloadTimes(): Array<String> {
        val wantsFullRange =
            timeline.opts.shouldPreloadData ||
                timeline.opts.forcePreloadOneTime ||
                Timeline.fullTimelinePreloadActive

        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val staggeredNeedsFullPass =
            layerLists != null &&
                layerLists.useStaggeredDownload() &&
                layerLists.staggeredPhase != StaggeredIntervalPhase.Full &&
                layerLists.staggeredPhase != StaggeredIntervalPhase.Inactive

        val useFullTimelinePass =
            wantsFullRange ||
                (timeline.state == AnimationState.playing && staggeredNeedsFullPass)

        val base =
            if (useFullTimelinePass) {
                filterTimelineByValidTimes()
            } else {
                timesForPausedOrScrubDownload(layer.source.id)
            }
        if (base.isNotEmpty()) {
            return base
        }
        return fallbackDownloadTimesWhenNoneResolved()
    }

    /**
     * Paused demos often add the encoded layer before [LayerTimeline.phaseAString]/[phaseBString]
     * are set. Returning an empty list here left [preflightEncodedDownloadPairCount] at zero, so
     * [MapController.refreshVisibleLayers] skipped downloads until play/scrub.
     */
    private fun fallbackDownloadTimesWhenNoneResolved(): Array<String> {
        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        if (layerLists != null && layerLists.timeStrings.isNotEmpty()) {
            val scrubLong = (
                timeline.start.time +
                    ((timeline.end.time - timeline.start.time) * timeline.position).toLong()
                ) / 1000L
            closestLayerValidTime(layerLists, scrubLong)?.let { (validLong, validString) ->
                layerLists.phaseAString = validString
                layerLists.phaseBString = validString
                val insertionIndex = layerLists.reqLongs.binarySearch(validLong)
                if (insertionIndex < 0) {
                    val correctIndex = -(insertionIndex + 1)
                    layerLists.reqLongs.add(correctIndex, validLong)
                    layerLists.reqStrings.add(correctIndex, validString)
                }
                return arrayOf(validString)
            }
        }
        val bracketed = bracketedRasterInterval(formattedDate!!)
        ensureStaticRasterLayerTimeline(layer.source.id, bracketed)
        return arrayOf(bracketed)
    }

    interface DictionaryProtocol {
        fun contains(coord: TileCoord): Boolean
    }

    interface Sequence {
        fun contains(coord: TileCoord): Boolean
    }

    interface Collection {
        fun contains(coord: TileCoord): Boolean
    }

    operator fun TilePyramid<DataType>.contains(coord: TileCoord): Boolean {
        return tileSource.contains(coord)
    }

    operator fun TilePyramid<DataType>.get(coord: TileCoord): Tile<com.xweather.mapsgl.sources.DataType>? {
        return tileCache[coord]
    }
}