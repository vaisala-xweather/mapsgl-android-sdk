package com.xweather.mapsgl.tiles

import android.graphics.Bitmap
import android.opengl.EGL14
import android.opengl.EGLContext
import android.opengl.GLES31
import android.opengl.GLUtils
import com.xweather.mapsgl.NativeLibCache
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.sources.DataPool
import com.xweather.mapsgl.sources.data.EncodedData
import com.xweather.mapsgl.utils.LRUCache
import java.nio.ByteBuffer
import java.util.ArrayDeque
import java.util.concurrent.locks.ReentrantLock
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

private fun computeDefaultCacheCapacity(): Int {
    // Playback loops the full timeline (often 30+ intervals) in ~2s and must keep every
    // viewport tile×time resident for the whole session — not a playhead sliding window.
    val maxMemoryMb = Runtime.getRuntime().maxMemory() / (1024 * 1024)
    val target = when {
        maxMemoryMb < 512 -> 1_200
        maxMemoryMb < 1_024 -> 2_400
        else -> 4_000
    }
    return target.coerceIn(800, 4_000)
}

private val defaultCacheCapacity: Int = computeDefaultCacheCapacity()
private const val TAG = "TileCache"

/**
 * A `TileCache` is a cache of tiles that are currently in use by the map. It is used to keep track
 * of which tiles are currently in use, which tiles are pending, and which tiles are stale.
 * @template Data The type of data that the tiles contain.
 * @internal
 */
class TileCache<DataType : TileData>(val sourceID: String = "") {
    /**
     * Set around [evictTilesOutsideViewport]'s removals. Rule 7 ("never evict the current
     * timeline") only ever meant the tiles for the *currently visible* viewport — [onRemove]'s
     * play/hold-residency guard below exists to stop an incidental LRU-capacity eviction from
     * recycling memory the layer still needs to animate. A deliberate viewport-change eviction is
     * the opposite case: these tiles are confirmed no-longer-visible, so the memory must be freed
     * regardless of play state, or every viewport ever panned to during a session stays resident
     * forever and GPU/native memory grows without bound (observed: 2GB+ GL texture memory after
     * an extended session, downloads stalling, animation starved of frame time).
     */
    @Volatile
    private var forceNativeFreeOnRemove = false

    /**
     * The LRU-backed store of non-persistent tiles, keyed by tile-coordinate hash. Capacity comes
     * from [defaultCacheCapacity]. Eviction is disabled while [Timeline.isGloballyPlaying] or
     * [Timeline.holdFullTimelineResidency] holds so a full playback range stays resident, and a
     * removed entry's native/GPU pixels are freed here unless that same play/hold state (or a
     * deliberate viewport-change eviction via [forceNativeFreeOnRemove]) says otherwise.
     */
    val tiles: LRUCache<String, Tile<DataType>> = LRUCache(
        capacity = defaultCacheCapacity,
        ttl = 0,
        onRemove = { key, value: Tile<DataType> ->
            // Free native pixels for this tile×time — except while the timeline is playing or we are
            // holding full-range residency after a completed play load. Pause+scrub must re-bind
            // without another HTTP/decode (Java heap OOM / multi-minute reload).
            // GPU slot recycle still runs via [drainPendingBindRecycle].
            if ((forceNativeFreeOnRemove ||
                    (!Timeline.isGloballyPlaying && !Timeline.holdFullTimelineResidency)) &&
                nativeCache.containsKey("${sourceID}${key}")
            ) {
                nativeCache.removeData("${sourceID}${key}")
                if (nativeCount > 0) nativeCount--
            }
            _requestedTiles.remove(key)
            _pending.remove(key)
            _pendingTime.remove(key)
            textures?.remove(key)
            val bindSlot = value.bindNum
            value.bindNum = -1
            enqueueBindRecycle(key, bindSlot)
            withBindListLock { bindList.remove(key) }
            // A pending-encoded key normally clears when the tile binds. If the entry disappears
            // first, nothing else will ever clear it: the load indicator stays below 100% forever
            // and [Timeline.isEncodedBindPending] reports that phase permanently unready, which
            // freezes playback on one interval.
            Timeline.removePendingEncodedDownload(sourceID, key)
            val time = value.coord.time
            if (time.length > 1) {
                // Only the "ready" claim is dropped: without this the source would still think the
                // interval is downloaded and never re-request the pixels we just freed. Pending /
                // requested bookkeeping stays owned by the in-flight download path.
                TileList.readyList.remove(sourceID, value.coord.hashShort(), time)
            }
        },
        canEvict = { key, _: Tile<DataType> ->
            // Full-range playback must keep every viewport×interval resident (often 30+). Evicting
            // mid-play recycled GPU textures and left buildReadyPlaybackList with only ~1–2 frames.
            // Also hold residency after a completed play load ([MapController.suppressStreamingLoadUi]
            // path / global flag): pause+scrub must not capacity-evict and force a multi-minute reload.
            if (Timeline.isGloballyPlaying || Timeline.holdFullTimelineResidency) false
            else !isInFlight(key)
        },
    )


    /**
     * Process-wide GPU/native bookkeeping shared by every [TileCache] instance: the shared
     * [textureUnits] pool, bind-slot recycling, and the global per-frame GPU bind budget. Kept
     * here rather than per-instance because texture units are a single scarce GPU resource shared
     * across all layers/sources, and must survive across `MapView` instances in the same process.
     */
    companion object {
        /** Number of tile×time entries currently resident in [nativeCache] across all [TileCache] instances; used only for diagnostic logging (see [memoryLog]). */
        var nativeCount = 0
        /** Total number of GPU texture-unit slots handed out via [takeBindSlot] since the last [oneTimeCacheSetup] reset; also the next slot index to allocate once [freeBindSlots] is empty. */
        var bindCount = 0
        /** Snapshot of [bindCount] from the previous [memoryLog] call, used to only log memory usage when a new bind has actually occurred. */
        var lastBindCount = 0
        /** Count of exceptions caught while binding textures in [bindTextures] (e.g. concurrent-modification races), used for diagnostic logging. */
        var concurrentCount = 0
        private var textureUnits: IntArray =
            IntArray(4096) //was 4096 //TEMP-DIAG: shrunk to 40 to force overflow quickly
        /** Recycled [Tile.bindNum] indices so long playback does not burn through [textureUnits]. */
        private val freeBindSlots: ArrayDeque<Int> = ArrayDeque()
        private val freeBindSlotsLock = ReentrantLock()
        /** True once [oneTimeCacheSetup] has generated [textureUnits] at least once for the current EGL context; a repeat call is a no-op unless the context has since changed. */
        var hasInitialized = false

        private fun takeBindSlot(): Int {
            freeBindSlotsLock.lock()
            try {
                if (freeBindSlots.isNotEmpty()) {
                    return freeBindSlots.removeFirst()
                }
            } finally {
                freeBindSlotsLock.unlock()
            }
            val slot = bindCount
            bindCount++
            return slot
        }

        private fun releaseBindSlot(bindNum: Int) {
            if (bindNum < 0) return
            freeBindSlotsLock.lock()
            try {
                freeBindSlots.addLast(bindNum)
            } finally {
                freeBindSlotsLock.unlock()
            }
        }

        /**
         * The EGL context the cached [textureUnits] handles belong to. GL texture names are scoped
         * to the context that generated them, so a second `MapView` (e.g. in another activity) sees
         * stale integers that may collide with its own textures. Comparing the current context to
         * this snapshot reliably detects the switch — `glIsTexture` does not, because the integer
         * ID can happen to be a valid (but unrelated) texture in the new context.
         */
        private var textureContext: EGLContext? = null

        // Global GPU bind budget shared across all layers.
        // This prevents a frame hitch when multiple layers bind in the same render pass.
        private var lastBindResetNs: Long = 0L
        private var globalBindCount: Int = 0
        private const val GLOBAL_MAX_BINDS_PER_FRAME = 8
        /** Higher budget while playing so full-timeline residency can reach the GPU quickly. */
        private const val GLOBAL_MAX_BINDS_PER_FRAME_PLAYING = 96
        private const val FRAME_RESET_NS: Long = 16_000_000L // ~60fps

        private fun resetGlobalBindBudgetIfNeeded(nowNs: Long) {
            if (lastBindResetNs == 0L || nowNs - lastBindResetNs >= FRAME_RESET_NS) {
                lastBindResetNs = nowNs
                globalBindCount = 0
            }
        }

        private fun globalBindBudget(): Int =
            if (Timeline.isGloballyPlaying) GLOBAL_MAX_BINDS_PER_FRAME_PLAYING
            else GLOBAL_MAX_BINDS_PER_FRAME

        private fun canBindMore(): Boolean = globalBindCount < globalBindBudget()

        private fun recordBind() {
            globalBindCount++
        }
    }


    /**
     * Coordinate-hash -> request-timestamp map marking a tile as having an in-flight download
     * requested (set by [TilePyramid] when a request is issued). Cleared as soon as the tile is
     * bound or otherwise resolved, so a stale entry does not permanently block re-requesting it.
     */
    val _requestedTiles: MutableMap<String, Long> = mutableMapOf()
    /** Tiles bucketed by zoom level; populated by [updateTile] and pruned by [removeTile]. */
    val levels: MutableMap<Int, MutableList<Tile<DataType>>> = mutableMapOf()
    /**
     * Tiles for zoom levels below [_persistentLevelCount] that are never subject to LRU eviction,
     * kept separate from [tiles] so low-zoom/overview tiles always stay resident.
     */
    val _persistents: MutableMap<String, Tile<DataType>> = mutableMapOf()
    /**
     * Tile×time entries currently awaiting a download response, keyed by coordinate hash. See
     * [setPending]/[setPendingKey]/[isPending]; entries here (and in [bindList]) mark a key as
     * in-flight so [isInFlight] can veto eviction until the response arrives and it is bound.
     */
    val _pending: MutableMap</*TileCoord*/String, Tile<DataType>> = mutableMapOf()
    /** Timestamp each [_pending] entry was marked pending, set/cleared alongside it in [setPending]/[setPendingKey]. */
    val _pendingTime: MutableMap<String, Long> = mutableMapOf()
    /** Coordinate hashes flagged as stale (e.g. needing a refresh) via [setStale]; queried by [isStale]. */
    val _stale: MutableMap<String, Boolean> = mutableMapOf()
    // A ConcurrentHashMap-backed set, not a locked MutableList: onRemove/canEvict (called by
    // [tiles]'s LRU while its own internal lock is held) need to touch bindList membership, while
    // other call sites (e.g. XweatherEncodedTileSource's edge-blend loop) call tileCache.updateTile()
    // — which acquires that same LRU lock — from inside withBindListLock. A separate lock taken in
    // both directions (LRU-lock-then-bindListLock here, bindListLock-then-LRU-lock there) is a
    // classic lock-order-inversion deadlock; both threads observed blocked on ANR traces. A
    // concurrent collection needs no external lock for these membership ops, so the ordering
    // conflict can't occur. [withBindListLock] is kept only so existing call sites don't all need
    // touching; it no longer synchronizes anything.
    /**
     * Coordinate hashes of tiles queued for GPU upload, drained by [bindTextures]. Sources add to
     * this set once a tile's data is ready to bind; [isInFlight] treats membership as in-flight so
     * eviction leaves the entry alone until it is actually bound (or dropped if the underlying
     * cache entry vanishes first).
     */
    val bindList: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()

    internal inline fun <T> withBindListLock(block: () -> T): T {
        return block()
    }

    /**
     * GL texture-unit indices queued for deletion; drained a few at a time inside [bindTextures]
     * (see `maxDeletesPerCall`) so a large batch of deletes does not stall a single frame.
     */
    val removeFromGPUList: MutableList<Int> = mutableListOf()


    /** Coordinate hash to list-of-hashes lookup; currently unused elsewhere in the codebase. */
    val hashList: HashMap<String, MutableList<String>> = hashMapOf()

    //val bindQueue: ConcurrentLinkedQueue<String> = ConcurrentLinkedQueue()

    //fixme: Below was set to 2. Keep at 0 until Partials and Persistents are better implemented.
    private val _persistentLevelCount: Int = 0 //2

    //private val _removeCallbacks: MutableList<(Tile<DataType>) -> Unit> = mutableListOf()
    private var textures: MutableMap<String, Bitmap>? = mutableMapOf()

    /** Coordinate hash -> bound GL texture-unit id, maintained by [bindTextures] and consumed by rendering to look up which texture holds a given tile. */
    val hashMap = hashMapOf<String, Int>()

    /** Reserved for a future tile snapshot; currently never initialized or assigned. */
    lateinit var copyMap: MutableMap<String, Tile<DataType>>

    //var lastTileCount = 0
    /** Fraction (0–1) of [Runtime.maxMemory] currently used by the JVM heap, refreshed by [memoryLog] each time [bindCount] changes. */
    var memUsage = 0f

    /** Current total tile count: [tiles] plus the (currently zero, since [_persistentLevelCount] is 0) persistent-level capacity. */
    val capacity: Int
        get() = tiles.size + _persistentLevelCount.sumPowerOfFour()
    /** Coordinate hashes of every tile currently in [tiles]. */
    val keys: Set<String>
        get() = tiles.keys
    /** Number of tiles currently in [tiles]. */
    val count: Int
        get() = tiles.size
    /** Number of tile×time entries currently awaiting a download response (size of [_pending]). */
    val pendingCount: Int
        get() = _pending.size
    /** Number of coordinate hashes currently flagged stale (size of [_stale]). */
    val staleCount: Int
        get() = _stale.size

    /** This cache's handle to the native pixel store, namespaced by [sourceID] so different sources' tiles never collide. */
    val nativeCache = NativeLibCache(sourceID)

    /**
     * Generates the shared [textureUnits] GL texture names once per EGL context. Safe to call
     * repeatedly: a no-op if [hasInitialized] is already true for the current context, but detects
     * an EGL context switch (e.g. a second `MapView`/activity) via object identity against
     * [textureContext] and regenerates + resets the shared bind bookkeeping in that case, since
     * texture names from the old context are meaningless (or worse, colliding) in the new one.
     */
    fun oneTimeCacheSetup() {
        // `textureUnits` is a process-wide static so it survives across `MapView` instances and
        // EGL contexts (e.g. when a second activity creates its own `MapView`). The GL handles
        // inside it, however, are scoped to the context that generated them. If the surrounding
        // EGL context has changed since we last populated the array, every cached integer is now
        // either invalid or — worse — a collision with an unrelated Mapbox-owned texture in the
        // new context, which silently corrupts subsequent uploads and renders the layer invisible.
        // The reliable detector is an `EGLContext` object identity check (not `glIsTexture`, since
        // a stale ID can coincidentally match a valid texture in the new context).
        val currentContext = EGL14.eglGetCurrentContext()
        val sameContext = hasInitialized
                && textureContext != null
                && textureContext == currentContext
                && currentContext != EGL14.EGL_NO_CONTEXT
        if (sameContext) return
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glGenTextures(textureUnits.size, textureUnits, 0)
        hasInitialized = true
        textureContext = currentContext
        // Slot indices held by tiles from the previous context are no longer meaningful, so reset
        // the shared bind cursor. Any still-live `TileCache` instances re-bind from scratch with
        // the new handles on their next render pass.
        bindCount = 0
        lastBindCount = 0
        globalBindCount = 0
        lastBindResetNs = 0L
        freeBindSlotsLock.lock()
        try {
            freeBindSlots.clear()
        } finally {
            freeBindSlotsLock.unlock()
        }
    }

    private val pendingBindRecycle: MutableList<Pair<String, Int>> = mutableListOf()
    private val pendingBindRecycleLock = ReentrantLock()

    private fun enqueueBindRecycle(coordHash: String, bindNum: Int) {
        pendingBindRecycleLock.lock()
        try {
            pendingBindRecycle.add(coordHash to bindNum)
        } finally {
            pendingBindRecycleLock.unlock()
        }
    }

    /**
     * True while a tile is queued for GPU upload or still downloading, so eviction must leave it
     * alone; dropping it strands the bind and its pending-download bookkeeping.
     */
    private fun isInFlight(key: String): Boolean {
        // Only true in-flight work. [_requestedTiles] can linger after bind and would otherwise
        // permanently veto eviction of every interval visited during a long playthrough.
        if (_pending.containsKey(key)) return true
        return withBindListLock { bindList.contains(key) }
    }

    /** Apply [onRemove] GPU bookkeeping on the GL thread (hashMap + bind-slot recycle). */
    fun flushPendingGpuEvictions() {
        drainPendingBindRecycle()
    }

    private fun drainPendingBindRecycle() {
        val batch: List<Pair<String, Int>>
        pendingBindRecycleLock.lock()
        try {
            if (pendingBindRecycle.isEmpty()) return
            batch = pendingBindRecycle.toList()
            pendingBindRecycle.clear()
        } finally {
            pendingBindRecycleLock.unlock()
        }
        for ((coordHash, bindNum) in batch) {
            hashMap.remove(coordHash)
            releaseBindSlot(bindNum)
        }
    }

    /**
     * Drops cached tile×time entries whose interval is outside the active playback keep-set.
     * Call when the global timeline phase advances so long playback does not retain every
     * interval visited so far (native ~1MB + GL texture per tile×time).
     */
    fun evictTimesNotIn(keepTimes: Set<String>) {
        // Sliding-window eviction is disabled for full-range play residency (and the post-load hold).
        // Callers also early-return, but this is the hard stop if anything else invokes us.
        if (Timeline.isGloballyPlaying || Timeline.holdFullTimelineResidency) return
        if (keepTimes.isEmpty()) return
        val keysToRemove = ArrayList<String>()
        for ((key, tile) in tiles.entries()) {
            val time = tile.coord.time
            if (time.length > 1 && time !in keepTimes && !isInFlight(key)) {
                keysToRemove.add(key)
            }
        }
        for (key in keysToRemove) {
            tiles.remove(key)
        }
    }

    /**
     * Evicts every cached tile×time whose tile coordinate (x/y/z, ignoring interval) is not in
     * [visibleHashShorts] and is not a protected zoom-ancestor of one ([protectedAncestorHashShorts])
     * — i.e., belongs to a viewport panned away from. Deliberately runs regardless of play state
     * (unlike [evictTimesNotIn]): rule 7's "never evict" is about the *currently visible* tiles'
     * full timeline, not every viewport ever visited during a session. Without this, GPU/native
     * memory for stale viewports never comes back, growing unbounded until downloads stall and
     * rendering has no headroom left to animate.
     *
     * [protectedAncestorHashShorts] exists because a zoom change was evicting the *exact same*
     * coarser tiles [RenderPass.determinePartial] falls back to for the newly-visible (not-yet-
     * downloaded) tiles at the new zoom — this ran every frame via [flushPendingGpuEvictions]
     * racing the very next draw call, so the ancestor was gone before the fallback could ever use
     * it, and zooming in showed a hard blank instead of a cropped/scaled parent texture. The
     * ancestor set is geometrically small (at most one tile per zoom level per visible tile,
     * shrinking toward zoom 0), so protecting it does not reintroduce the unbounded growth this
     * eviction exists to prevent.
     */
    @JvmOverloads
    fun evictTilesOutsideViewport(visibleHashShorts: Set<String>, protectedAncestorHashShorts: Set<String> = emptySet()) {
        if (visibleHashShorts.isEmpty()) return
        val keysToRemove = ArrayList<String>()
        for ((key, tile) in tiles.entries()) {
            if (isInFlight(key)) continue
            val hashShort = tile.coord.hashShort()
            if (hashShort !in visibleHashShorts && hashShort !in protectedAncestorHashShorts) {
                keysToRemove.add(key)
            }
        }
        if (keysToRemove.isEmpty()) return
        forceNativeFreeOnRemove = true
        try {
            for (key in keysToRemove) {
                tiles.remove(key)
            }
        } finally {
            forceNativeFreeOnRemove = false
        }
    }

    /**  Called from LayerHost. **/
    fun bindTextures(sourceId: String? = null): HashMap<String, Int> {
        drainPendingBindRecycle()
        val isEmpty = withBindListLock { bindList.isEmpty() }
        if (isEmpty) return hashMap
        if (pr.ON) {
            val size = withBindListLock { bindList.size }
            pr.p(TAG, pr.dataPool, "bindTextures() entered, bindList.size: $size")
        }

        var bindIncremented: Boolean
        val tempList = withBindListLock { bindList.toList() } // snapshot to avoid concurrent modification

        var count = 0
        // While playing, drain the bind queue fast so all ~30 intervals become GPU-ready instead of
        // stalling at a couple of hold frames (3/frame was far behind full-range download).
        val maxBindsPerFrame = if (Timeline.isGloballyPlaying) 48 else 3
        val maxDeletesPerCall = 2

        //if (pr.ON) pr.p(TAG, pr.backfillEdge, "bindTextures() entered, bindList:${bindList}")

        resetGlobalBindBudgetIfNeeded(System.nanoTime())

        for (item in tempList) {
            if (count >= maxBindsPerFrame) break // per-layer cap
            if (!canBindMore()) break // global cap across all layers

            bindIncremented = false
            _requestedTiles.remove(item) // added 250305, to help notify when downloads are done

            if (removeFromGPUList.isNotEmpty()) {
                val deletes = minOf(removeFromGPUList.size, maxDeletesPerCall)
                val removeArray = removeFromGPUList.subList(0, deletes).toIntArray()
                GLES31.glDeleteTextures(deletes, removeArray, 0)
                println("$TAG bindTextures() removed ${deletes} textures from GPU (capped)")
                // Purge stale coordHash -> textureUnit mappings for any textures we just deleted.
                // Otherwise RenderPass can draw using a texture unit that no longer contains the expected tile.
                if (hashMap.isNotEmpty()) {
                    val deletedUnits = removeArray.toHashSet()
                    val toRemove = hashMap.entries.filter { it.value in deletedUnits }.map { it.key }
                    toRemove.forEach { hashMap.remove(it) }
                }
                removeFromGPUList.subList(0, deletes).clear()
            }
            val queuedTile = tiles[item] ?: _persistents[item]
            if (queuedTile == null) {
                // The cache entry vanished before we could upload it (eviction, source purge).
                // Drop the queue entry and release its pending-download key: the old `tiles[item]!!`
                // threw here and the catch swallowed it, leaving the item in [bindList] forever,
                // which pinned the load indicator and stopped the timeline from advancing.
                withBindListLock { bindList.remove(item) }
                Timeline.removePendingEncodedDownload(sourceID, item)
                _pending.remove(item)
                _pendingTime.remove(item)
                continue
            }

            try {
                val tile = queuedTile
                if (tile.isEncoded) { //Encoded Tiles
                    if (pr.ON) pr.p(TAG, pr.backfillEdge, " bindTextures() binding ${item}")
                    //if (pr.ON) pr.p(TAG, pr.bindTextures, "before null check:")
                    //TODO: see if the null check triggers the catch
                    // If we've previously bound and freed `paddedData`, we can lazily restore it
                    // from native cache so the tile can be re-bound without re-downloading.
                    if (tile.encodedData?.paddedData == null) {
                        val nativeKey = "${sourceID}${tile.coordHash}"
                        val restored = nativeCache.getData(nativeKey)
                        if (restored != null) {
                            val existingEd = tile.encodedData
                            if (existingEd != null) {
                                existingEd.paddedData = restored
                            } else {
                                // Shell tiles inserted by reinsertShellForNativeBindIfNeeded have
                                // encodedData == null. Restore from native cache by creating a minimal
                                // EncodedData with the correct dimension inferred from the stored bytes
                                // (dimension × dimension × 4 RGBA bytes).
                                val dim = sqrt(restored.size / 4.0).roundToInt()
                                tile.encodedData = EncodedData(
                                    byteArrayOf(), blend = false, padding = 0,
                                    id = sourceID, deferPadToNativePipeline = true,
                                ).also { ed ->
                                    ed.dimension = dim
                                    ed.paddedData = restored
                                }
                            }
                        }
                    }

                    if (tile.encodedData?.paddedData != null) {
                        val dim = tile.encodedData!!.dimension
                        val padded = tile.encodedData!!.paddedData!!
                        val expectedBytes = dim * dim * 4
                        if (padded.size != expectedBytes) {
                            android.util.Log.e(
                                TAG,
                                "Encoded tile buffer size mismatch: dim=$dim expectedBytes=$expectedBytes actual=${padded.size} " +
                                        "coord=${tile.coordHash} — upload may show banding/stripes",
                            )
                        }

                        if (pr.ON) pr.p(TAG, pr.edgeBlend, " bindTextures() binding $tile.coordHash}")

                        if (tile.bindNum < 0) {
                            tile.bindNum = takeBindSlot()
                            bindIncremented = true
                        } else {
                            bindIncremented = false
                        }

                        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureUnits[tile.bindNum])
                        hashMap[tile.coordHash] = textureUnits[tile.bindNum]
                        //GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_NEAREST)
                        //GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_NEAREST)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
                        GLES31.glTexImage2D(
                            GLES31.GL_TEXTURE_2D, 0, GLES31.GL_RGBA,
                            tile.encodedData!!.dimension, tile.encodedData!!.dimension,
                            0,
                            GLES31.GL_RGBA,
                            GLES31.GL_UNSIGNED_BYTE,
                            ByteBuffer.wrap(tile.encodedData!!.paddedData!!)
                        )
                        recordBind()

                        if (!nativeCache.containsKey("${sourceID}${tile.coordHash}")) {
                            nativeCount++
                        }

                        nativeCache.putData("${sourceID}${tile.coordHash}", tile.encodedData!!.paddedData!!)
                        tile.encodedData!!.paddedData = null

                        if (false && DataPool.paddedEnabled) {//fixme Testing false&&
                            DataPool.usedBBList.remove(tile.encodedData!!.paddedData)
                            DataPool.freepBBList.add(tile.encodedData!!.paddedData!!)
                            DataPool.paddedStatus()
                        } else if (false) {
                            tile.encodedData!!.paddedData = null  //fixme Testing this is default. test commenting out
                        }

                        if (pr.ON) pr.p(TAG, pr.infiniteLoad, " bindTextures() removing ${sourceId} ${tile.coordHash}")

                        Timeline.removePendingEncodedDownload(sourceID, tile.coordHash)
                        _pending.remove(tile.coordHash)
                        _pendingTime.remove(tile.coordHash)
                        withBindListLock { bindList.remove(item) }

                        // bindCount advances inside takeBindSlot() when allocating a new slot
                        if (pr.ON) pr.p(TAG, pr.bindCount, "bindCount: $bindCount newSlot=$bindIncremented")
                    } else {
                        // Native/pixels missing — do not leave this key stuck in bindList/pending
                        // or the load indicator never completes. Also drop hollow ready/tiles claims
                        // so the next playback refresh re-downloads instead of skipping forever.
                        withBindListLock { bindList.remove(item) }
                        Timeline.removePendingEncodedDownload(sourceID, item)
                        _pending.remove(item)
                        _pendingTime.remove(item)
                        _requestedTiles.remove(item)
                        TileCoord.fromHash(item)?.let { coord ->
                            if (coord.time.length > 1) {
                                TileList.readyList.remove(sourceID, coord.hashShort(), coord.time)
                            }
                        }
                        tiles.delete(item)
                    }

                } // end encoded
                else { // Raster Image
                    if (pr.ON) pr.p(
                        TAG,
                        pr.tileBind,
                        " bindTextures() doing ${tile.coordHash}, tile.data is null? ${tile.data == null} "
                    )
                    // Reuse this tile's existing slot, exactly as the encoded branch does. Taking a
                    // fresh slot on every bind (and never storing it on the tile) leaked one texture
                    // unit per re-bind out of the fixed [textureUnits] pool: [onRemove] recycles via
                    // `value.bindNum`, which stayed -1 for raster tiles, so nothing was ever returned
                    // to [freeBindSlots] and a long session with a raster layer up would exhaust it.
                    if (tile.bindNum < 0) {
                        tile.bindNum = takeBindSlot()
                        bindIncremented = true
                    } else {
                        bindIncremented = false
                    }
                    GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureUnits[tile.bindNum])
                    hashMap[tile.coordHash] = textureUnits[tile.bindNum]
                    GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
                    GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
                    GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
                    GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
                    GLUtils.texImage2D(GLES31.GL_TEXTURE_2D, 0, tile.data as Bitmap, 0)
                    recordBind()
                    tile.data = null
                    withBindListLock { bindList.remove(item) }
                }

            } catch (e: Exception) {
                concurrentCount++
                android.util.Log.e(
                    "StuckLoadDiag",
                    "BIND-EXCEPTION bindCount=$bindCount textureUnitsSize=${textureUnits.size} " +
                            "concurrentCount=$concurrentCount tile=$item ex=$e"
                )
                if (pr.ON) {
                    pr.p(TAG, pr.tileBind, "bindTextures() concurrent exception!\n$e", 2)
                    pr.p(
                        TAG,
                        pr.tileBind,
                        " bindTextures() error on $bindCount, number of errors:$concurrentCount  tile:${item}",
                        2
                    )
                }
            }
            count++
        }
        DataPool.bindCount = bindCount

        // Prevent drawing textures for tiles that are *not yet bound*.
        // Previously we removed hashMap entries for ALL tiles in `bindList`, which can cause
        // visible "on/off" flicker when scroll reveals add more tiles than we can bind this frame.
        // For tiles that were already bound earlier (bindNum >= 0), keep the existing texture mapping
        // until the re-bind actually happens.
        val pendingToBind = withBindListLock { bindList.toHashSet() }
        if (pendingToBind.isNotEmpty()) {
            pendingToBind.forEach { coordHash ->
                val tile = tiles[coordHash] ?: _persistents[coordHash]
                // Only purge mapping if the tile hasn't been bound yet.
                if (tile == null || tile.bindNum < 0) {
                    hashMap.remove(coordHash)
                }
            }
        }

        memoryLog()
        return hashMap
    }

    //** called from bindTextures(), used in testing to keep track of memory usage **/
    private fun memoryLog() {
        if (bindCount != lastBindCount) {
            val maxMemory = Runtime.getRuntime().maxMemory()
            val totalMemory = Runtime.getRuntime().totalMemory()
            memUsage = (totalMemory.toFloat() / maxMemory.toFloat())
            pr.p(
                TAG,
                pr.memoryMonitor,
                "bound: $bindCount, (${totalMemory / 1048576} / ${maxMemory / 1048576} MB)  (${(memUsage * 100).toInt()}%)  nc:${nativeCount}",
                2
            )

            lastBindCount = bindCount
        }
    }

    /**
     * Removes every cached tile whose coordinate falls outside [bounds] (wrong zoom, or x/y outside
     * the given range) and is not currently in-flight, letting [onRemove] own the actual native/GPU
     * cleanup. No-op if [bounds] is null.
     */
    @Suppress("UNUSED_PARAMETER")
    fun clearOutsideBounds(bounds: TileBounds?, clearNative: Boolean = true) {
        if (bounds == null) return
        if (pr.ON) {
            pr.p(TAG, pr.clearMem, "clearOutsideBounds() ------------------------")
            pr.p(
                TAG,
                pr.clearMem,
                "clearOutsideBounds() want to clear outside top: ${bounds.top} bot: ${bounds.bottom} "
            )
        }

        // Snapshot keys, then remove so [onRemove] owns native/GPU cleanup. This used to be gated
        // entirely behind pr.ON, so production never freed out-of-view tiles.
        val keysToRemove = ArrayList<String>()
        for ((key, tile) in tiles.entries()) {
            val coord = tile.coord
            val outsideZoom = coord.z != bounds.zoom
            val outsideX = coord.x < bounds.left || coord.x > bounds.right
            val outsideY = coord.y > bounds.bottom || coord.y < bounds.top
            if ((outsideZoom || outsideX || outsideY) && !isInFlight(key)) {
                if (pr.ON) {
                    pr.p(TAG, pr.clearMem, "clearOutsideBounds() deleting ${key}", 2)
                }
                keysToRemove.add(key)
            }
        }
        for (key in keysToRemove) {
            tiles[key]?.data = null
            tiles.remove(key)
        }
    }

    /** True if [coord] is already cached, checking [_persistents] for persistent zoom levels and [tiles] otherwise. */
    fun contains(coord: TileCoord): Boolean {
        if (coord.z < _persistentLevelCount) {
            return _persistents.containsKey(coord.hash())
        } else {
            return tiles.containsKey(coord.hash())
        }
    }

    /**
     * Re-inserts a shell [Tile] when [nativeCache] still has pixels but [tiles] LRU evicted the entry,
     * so [bindTextures] can restore [EncodedData.paddedData] without another HTTP request.
     */
    /**
     * True when this tile×time can be uploaded (or is already on the GPU). A bare [tiles] entry or
     * [TileList.readyList] claim is not enough — those can outlive lost pixels and then permanently
     * skip HTTP while [buildReadyPlaybackList] never sees a texture.
     */
    fun hasBindableEncodedPixels(hash: String): Boolean {
        if (hashMap.containsKey(hash)) return true
        if (nativeCache.containsKey("$sourceID$hash")) return true
        val tile = tiles[hash] ?: _persistents[hash] ?: return false
        return tile.encodedData?.paddedData != null
    }

    /**
     * Re-inserts a shell [Tile] when [nativeCache]/GPU still has pixels for [hash] (per
     * [hasBindableEncodedPixels]) but the entry is missing from [tiles]/[_persistents] — e.g. the
     * LRU evicted it — so [bindTextures] can restore [EncodedData.paddedData] without another HTTP
     * request. Returns true if the tile is bindable (whether or not a shell needed inserting).
     */
    fun reinsertShellForNativeBindIfNeeded(coord: TileCoord, hash: String): Boolean {
        if (hasBindableEncodedPixels(hash)) {
            if (!tiles.containsKey(hash) && !_persistents.containsKey(hash)) {
                // Native/GPU only — insert a shell so [bindTextures] can restore paddedData.
                val shell = Tile<DataType>(coord).apply {
                    isEncoded = true
                    coordHash = hash
                    state = TileState.Ready
                }
                tiles[hash] = shell
            }
            return true
        }
        return false
    }

    /** Looks up the cached [Tile] for [coord] (persistent levels or [tiles]), or null if not cached. */
    operator fun get(coord: TileCoord): Tile<DataType>? {
        return lookup(coord)
    }

    /** Stores [tile] under [coord] via [updateTile], or removes any cached entry for [coord] if [tile] is null. */
    operator fun set(coord: TileCoord, tile: Tile<DataType>?) {
        if (tile != null) {
            updateTile(tile, coord)
        } else {
            removeTile(coord)
        }
    }

    private fun lookup(coord: TileCoord): Tile<DataType>? {
        return if (coord.z < _persistentLevelCount) {
            _persistents[coord.hash()]
        } else {
            tiles[coord.hash()]
        }
    }

    /** Convenience overload of [updateTile] that stores [tile] under its own [Tile.coord]. */
    fun updateTile(tile: Tile<DataType>) {
        if (pr.ON) pr.p(
            "TileCache",
            pr.hashmapLong,
            "updateTile() tile.time: ${tile.time}  tile.coord.time: ${tile.coord.time} tile.coordHash: ${tile.coordHash}"
        )
        updateTile(tile, tile.coord)
    }

    /**
     * Stores [tile] in [_persistents] (for zoom levels below [_persistentLevelCount]) or [tiles]
     * otherwise, keyed by [coord]/[tile.coordHash], and ensures a bucket for [coord]'s zoom exists
     * in [levels].
     */
    fun updateTile(tile: Tile<DataType>, coord: TileCoord) {
        if (coord.z < _persistentLevelCount) {
            _persistents[tile.coordHash] = tile
        } else {
            if (pr.ON) pr.p(
                TAG,
                pr.tileReceived,
                "updateTile() putting tile in tiles[], data is null? ${tile.data == null}"
            )
            tiles[tile.coordHash] = tile
        }
        if (!levels.containsKey(tile.coord.z)) {
            levels[tile.coord.z] = mutableListOf()
        }
    }

    private fun removeTile(coord: TileCoord) {
        if (coord.z < _persistentLevelCount) {
            _persistents.remove(coord.hash())
        }
        if (levels.containsKey(coord.z)) {
            val removeIndex = levels[coord.z]?.indexOfFirst { tile -> tile.coord == coord }
            if (removeIndex != null && removeIndex != -1) {
                levels[coord.z]?.removeAt(removeIndex)
            }
            if (levels[coord.z]?.isEmpty() == true) {
                levels.remove(coord.z)
            }
        }
        textures?.remove(coord.hash())
    }

    /** True if [coord] currently has an in-flight download tracked in [_pending]. */
    fun isPending(coord: TileCoord): Boolean {
        return _pending.containsKey(coord.hash())
    }

    /** True if [tile] is currently flagged stale in [_stale]. */
    fun isStale(tile: Tile<DataType>): Boolean {
        return _stale.containsKey(tile.coordHash)
    }

    /**
     * Marks or clears [tile] as pending in [_pending]/[_pendingTime], keyed by its own
     * [Tile.coordHash]. See [setPendingKey] for marking an arbitrary hash without a [Tile] instance.
     */
    fun setPending(isPending: Boolean, tile: Tile<DataType>) {
        if (isPending) {
            if (!_pending.containsKey(tile.coordHash)) {
                _pending[tile.coordHash] = tile
                _pendingTime[tile.coordHash] = System.currentTimeMillis()
            }

        } else {
            _pending.remove(tile.coordHash)
            _pendingTime.remove(tile.coordHash)
        }
    }

    /**
     * Marks or clears the pending flag for an arbitrary hash key, independent of a specific [Tile]
     * instance. A multi-interval batch request marks only one "representative" tile pending, and
     * that flag clears the moment the HTTP response arrives — well before the other intervals in
     * the batch have been decoded, edge-blended, and queued to bind. Until this per-interval flag
     * is set too, [isInFlight] sees those other intervals as safe to drop, so a concurrent
     * [clearOutsideBounds] or [evictTimesNotIn] sweep can strand one before it is ever bound.
     * [placeholder] is never read back — only key presence matters to pending/in-flight checks.
     */
    fun setPendingKey(isPending: Boolean, key: String, placeholder: Tile<DataType>) {
        if (isPending) {
            if (!_pending.containsKey(key)) {
                _pending[key] = placeholder
                _pendingTime[key] = System.currentTimeMillis()
            }
        } else {
            _pending.remove(key)
            _pendingTime.remove(key)
        }
    }

    /** Marks or clears [tile] as stale in [_stale], keyed by its [Tile.coordHash]. */
    fun setStale(isStale: Boolean, tile: Tile<DataType>) {
        if (isStale) {
            _stale[tile.coordHash] = true
        } else {
            _stale.remove(tile.coordHash)
        }
    }

    /** Clears every entry from [tiles] (does not touch [_persistents]). */
    fun removeAll() {
        tiles.clear()

    }

    /** Deletes the shared [textureUnits] GL texture names, releasing this cache's GPU texture pool. */
    fun cleanup() {
        GLES31.glDeleteTextures(textureUnits.size, textureUnits, 0)
        val error = GLES31.glGetError()
        if (error != GLES31.GL_NO_ERROR) {
            if (pr.ON) pr.p(TAG, pr.i13, "Error deleting texture names: $error")
        }
    }
}

private fun Int.sumPowerOfFour(): Int {
    return ((4.0.pow(this.toDouble()) - 1) / 3).toInt()
}