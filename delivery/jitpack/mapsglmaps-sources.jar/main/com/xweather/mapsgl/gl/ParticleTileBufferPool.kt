package com.xweather.mapsgl.gl

import android.opengl.GLES31
import android.opengl.GLES31.*
import android.util.Log
import com.xweather.mapsgl.gl.ParticleSsboManager.Companion.FLOAT_SIZE_BYTES
import com.xweather.mapsgl.gl.ParticleSsboManager.Companion.VEC2_COMPONENTS
import com.xweather.mapsgl.gl.ParticleSsboManager.Companion.VEC4_COMPONENTS
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

/**
 * One static / dynamic / render SSBO triple plus render VBO, packed by tile slot.
 * Batched compute uses one bind set and a 2D dispatch (particle groups × visible tiles).
 */
class ParticleTileBufferPool(
    val maxSlots: Int,
    val bufferItemsPerTile: Int,
) {
    companion object {
        private const val TAG = "ParticleTileBufferPool"
        const val STATIC_BP = 0
        const val DYNAMIC_BP = 1
        const val RENDER_BP = 2
        /** Per-frame: vec2 tx/ty offsets per visible tile (same order as dispatch workgroup Y). */
        const val TILE_UV_FRAME_BP = 3
        /** Per-frame: storage slot index per visible tile (maps frame index → pooled SSBO slice). */
        const val TILE_SLOT_FRAME_BP = 4
    }

    var staticSsboId: Int = 0
        private set
    var dynamicSsboId: Int = 0
        private set
    var renderSsboId: Int = 0
        private set
    var tileUvFrameSsboId: Int = 0
        private set
    var tileSlotFrameSsboId: Int = 0
        private set
    var renderVboId: Int = 0
        private set

    private val staticBufferIds = IntArray(3)
    private var frameSsboIds = IntArray(2)

    var particleVaoId: Int = 0
        private set

    private var gpuReady = false

    fun ensureGpuObjectsCreated() {
        if (gpuReady) return

        glGenBuffers(staticBufferIds.size, staticBufferIds, 0)
        staticSsboId = staticBufferIds[0]
        dynamicSsboId = staticBufferIds[1]
        renderSsboId = staticBufferIds[2]

        glGenBuffers(frameSsboIds.size, frameSsboIds, 0)
        tileUvFrameSsboId = frameSsboIds[0]
        tileSlotFrameSsboId = frameSsboIds[1]

        val staticBytes = maxSlots * bufferItemsPerTile * VEC2_COMPONENTS * FLOAT_SIZE_BYTES
        val vecBytes = maxSlots * bufferItemsPerTile * VEC4_COMPONENTS * FLOAT_SIZE_BYTES

        glBindBuffer(GL_SHADER_STORAGE_BUFFER, staticSsboId)
        glBufferData(GL_SHADER_STORAGE_BUFFER, staticBytes, null, GL_STATIC_DRAW)
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, dynamicSsboId)
        glBufferData(GL_SHADER_STORAGE_BUFFER, vecBytes, null, GL_DYNAMIC_COPY)
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, renderSsboId)
        glBufferData(GL_SHADER_STORAGE_BUFFER, vecBytes, null, GL_DYNAMIC_COPY)

        glBindBuffer(GL_SHADER_STORAGE_BUFFER, tileUvFrameSsboId)
        glBufferData(GL_SHADER_STORAGE_BUFFER, maxSlots * VEC2_COMPONENTS * FLOAT_SIZE_BYTES, null, GL_DYNAMIC_DRAW)
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, tileSlotFrameSsboId)
        glBufferData(GL_SHADER_STORAGE_BUFFER, maxSlots * 1 * 4, null, GL_DYNAMIC_DRAW)

        glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0)

        val vboArr = IntArray(1)
        glGenBuffers(1, vboArr, 0)
        renderVboId = vboArr[0]
        glBindBuffer(GL_ARRAY_BUFFER, renderVboId)
        glBufferData(GL_ARRAY_BUFFER, vecBytes, null, GL_DYNAMIC_DRAW)
        glBindBuffer(GL_ARRAY_BUFFER, 0)

        gpuReady = true
        Log.d(TAG, "Pool created maxSlots=$maxSlots bufferItemsPerTile=$bufferItemsPerTile")
    }

    fun bindSsboBasesForCompute() {
        ensureGpuObjectsCreated()
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, STATIC_BP, staticSsboId)
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, DYNAMIC_BP, dynamicSsboId)
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, RENDER_BP, renderSsboId)
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, TILE_UV_FRAME_BP, tileUvFrameSsboId)
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, TILE_SLOT_FRAME_BP, tileSlotFrameSsboId)
    }

    fun uploadFrameTileUv(slotCount: Int, txOffsets: FloatArray, tyOffsets: FloatArray) {
        ensureGpuObjectsCreated()
        val interleaved = FloatArray(slotCount * 2)
        var p = 0
        for (i in 0 until slotCount) {
            interleaved[p++] = txOffsets[i]
            interleaved[p++] = tyOffsets[i]
        }
        val bb = ByteBuffer.allocateDirect(interleaved.size * FLOAT_SIZE_BYTES)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        bb.put(interleaved).position(0)

        glBindBuffer(GL_SHADER_STORAGE_BUFFER, tileUvFrameSsboId)
        glBufferData(
            GL_SHADER_STORAGE_BUFFER,
            slotCount * VEC2_COMPONENTS * FLOAT_SIZE_BYTES,
            bb,
            GL_DYNAMIC_DRAW
        )
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0)
    }

    fun uploadFrameTileSlots(slotCount: Int, slots: IntArray) {
        ensureGpuObjectsCreated()
        val bb = ByteBuffer.allocateDirect(slotCount * 4).order(ByteOrder.nativeOrder()).asIntBuffer()
        bb.put(slots, 0, slotCount).position(0)

        glBindBuffer(GL_SHADER_STORAGE_BUFFER, tileSlotFrameSsboId)
        glBufferData(GL_SHADER_STORAGE_BUFFER, slotCount * 4, bb, GL_DYNAMIC_DRAW)
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0)
    }

    fun uploadStaticSlot(slot: Int, src: FloatBuffer, floatCount: Int) {
        ensureGpuObjectsCreated()
        val byteOffset = slot * bufferItemsPerTile * VEC2_COMPONENTS * FLOAT_SIZE_BYTES
        val sizeBytes = floatCount * FLOAT_SIZE_BYTES
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, staticSsboId)
        glBufferSubData(GL_SHADER_STORAGE_BUFFER, byteOffset, sizeBytes, src)
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0)
    }

    /** Copies each used storage slot's render data to the same offset in the VBO. */
    fun copyRenderToVboPooledSlots(slotIndices: IntArray, slotCount: Int, drawNum: Int, memoryBarrierAfter: Boolean) {
        ensureGpuObjectsCreated()
        for (i in 0 until slotCount) {
            val slot = slotIndices[i]
            val byteBase = slot * bufferItemsPerTile * VEC4_COMPONENTS * FLOAT_SIZE_BYTES
            val span = drawNum * VEC4_COMPONENTS * FLOAT_SIZE_BYTES
            glBindBuffer(GL_COPY_READ_BUFFER, renderSsboId)
            glBindBuffer(GL_COPY_WRITE_BUFFER, renderVboId)
            glCopyBufferSubData(GL_COPY_READ_BUFFER, GL_COPY_WRITE_BUFFER, byteBase, byteBase, span)
        }
        glBindBuffer(GL_COPY_READ_BUFFER, 0)
        glBindBuffer(GL_COPY_WRITE_BUFFER, 0)
        if (memoryBarrierAfter) {
            glMemoryBarrier(GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT)
        }
    }

    fun ensureParticleVao(attribLocation: Int, components: Int, strideBytes: Int) {
        ensureGpuObjectsCreated()
        if (particleVaoId != 0) return

        val arr = IntArray(1)
        GLES31.glGenVertexArrays(1, arr, 0)
        particleVaoId = arr[0]
        GLES31.glBindVertexArray(particleVaoId)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, renderVboId)
        GLES31.glEnableVertexAttribArray(attribLocation)
        GLES31.glVertexAttribPointer(
            attribLocation,
            components,
            GLES31.GL_FLOAT,
            false,
            strideBytes,
            0
        )
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        GLES31.glBindVertexArray(0)
    }

    fun deleteGpu() {
        if (particleVaoId != 0) {
            GLES31.glDeleteVertexArrays(1, intArrayOf(particleVaoId), 0)
            particleVaoId = 0
        }
        if (staticSsboId != 0) {
            GLES31.glDeleteBuffers(staticBufferIds.size, staticBufferIds, 0)
            staticSsboId = 0
            dynamicSsboId = 0
            renderSsboId = 0
        }
        if (tileUvFrameSsboId != 0) {
            GLES31.glDeleteBuffers(frameSsboIds.size, frameSsboIds, 0)
            tileUvFrameSsboId = 0
            tileSlotFrameSsboId = 0
        }
        if (renderVboId != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(renderVboId), 0)
            renderVboId = 0
        }
        gpuReady = false
    }
}
