package com.xweather.mapsgl.gl.math

import android.opengl.Matrix

/*
 * 4x4 Matrix
 */
open class Matrix4 : AbstractMatrix(), IMatrix {

    companion object {
        private val IDENTITY_ELEMENTS = listOf(
            1.0f, 0.0f, 0.0f, 0.0f,
            0.0f, 1.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 1.0f, 0.0f,
            0.0f, 0.0f, 0.0f, 1.0f
        )
        private val ZERO_ELEMENTS = listOf(
            0.0f, 0.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 0.0f, 0.0f,
            0.0f, 0.0f, 0.0f, 0.0f
        )

        fun identity() = Matrix4().insertElements(IDENTITY_ELEMENTS)
        fun zero() = Matrix4().insertElements(ZERO_ELEMENTS)
        fun copy(m: Matrix4) = m.clone() as Matrix4
    }

    init {
        elements.addAll(IDENTITY_ELEMENTS)
    }

    fun copy(m: Matrix4) {
        this.elements.clear()
        this.elements.addAll(m.elements)
    }

    fun fromPerspective(fovy: Float, aspect: Float, near: Float, far: Float): Matrix4 {
        perspective(fovy, aspect, near, far)
        return this
    }

    fun fromIdentity(): Matrix4 {
        identity()
        return this
    }

    fun fromOrthogonal(
        left: Float,
        right: Float,
        top: Float,
        bottom: Float,
        near: Float,
        far: Float
    ): Matrix4 {
        ortho(left, right, bottom, top, near, far)
        return this
    }

    fun fromQuaternion(q: QuaternionTC): Matrix4 {
        fromQuat(q)
        return this
    }

    /*
     * TODO Verify math correctness
     */
    private fun perspective(fovy: Float, aspect: Float, near: Float, far: Float? = null) {
        val f = 1.0 / Math.tan(fovy.toDouble() / 2)
        elements[0] = (f / aspect).toFloat()
        elements[1] = 0f
        elements[2] = 0f
        elements[3] = 0f
        elements[4] = 0f
        elements[5] = f.toFloat()
        elements[6] = 0f
        elements[7] = 0f
        elements[8] = 0f
        elements[9] = 0f
        elements[11] = -1f
        elements[12] = 0f
        elements[13] = 0f
        elements[15] = 0f
        if (far != null) {
            val nf = 1 / (near - far)
            elements[10] = (far + near) * nf
            elements[14] = 2 * far * near * nf
        } else {
            elements[10] = -1f
            elements[14] = -2 * near
        }
    }

    private fun indentity() {
        elements[0] = 1f
        elements[1] = 0f
        elements[2] = 0f
        elements[3] = 0f

        elements[4] = 0f
        elements[5] = 1f
        elements[6] = 0f
        elements[7] = 0f

        elements[8] = 0f
        elements[9] = 0f
        elements[10] = 1f
        elements[11] = 0f

        elements[12] = 0f
        elements[13] = 0f
        elements[14] = 0f
        elements[15] = 1f

    }


    /*
     * TODO Verify math correctness
     */
    private fun ortho(
        left: Float,
        right: Float,
        top: Float,
        bottom: Float,
        near: Float,
        far: Float
    ) {
        val lr = 1 / (left - right)
        val bt = 1 / (bottom - top)
        val nf = 1 / (near - far)
        elements[0] = -2 * lr
        elements[1] = 0f
        elements[2] = 0f
        elements[3] = 0f
        elements[4] = 0f
        elements[5] = -2 * bt
        elements[6] = 0f
        elements[7] = 0f
        elements[8] = 0f
        elements[9] = 0f
        elements[10] = 2 * nf
        elements[11] = 0f
        elements[12] = (left + right) * lr
        elements[13] = (top + bottom) * bt
        elements[14] = (far + near) * nf
        elements[15] = 1f
    }

    /*
     * TODO Verify math correctness
     */
    private fun fromQuat(q: QuaternionTC) {
        val x = q.x
        val y = q.y
        val z = q.z
        val w = q.w
        val x2 = x + x
        val y2 = y + y
        val z2 = z + z
        val xx = x * x2
        val yx = y * x2
        val yy = y * y2
        val zx = z * x2
        val zy = z * y2
        val zz = z * z2
        val wx = w * x2
        val wy = w * y2
        val wz = w * z2
        elements[0] = 1 - yy - zz
        elements[1] = yx + wz
        elements[2] = zx - wy
        elements[3] = 0f
        elements[4] = yx - wz
        elements[5] = 1 - xx - zz
        elements[6] = zy + wx
        elements[7] = 0f
        elements[8] = zx + wy
        elements[9] = zy - wx
        elements[10] = 1 - xx - yy
        elements[11] = 0f
        elements[12] = 0f
        elements[13] = 0f
        elements[14] = 0f
        elements[15] = 1f
    }

    private fun getScaling(): Vector3 {
        val m11 = elements[0]
        val m12 = elements[1]
        val m13 = elements[2]
        val m21 = elements[4]
        val m22 = elements[5]
        val m23 = elements[6]
        val m31 = elements[8]
        val m32 = elements[9]
        val m33 = elements[10]
        return Vector3(
            hypot(m11, m12, m13),
            hypot(m21, m22, m23),
            hypot(m31, m32, m33)
        )
    }

    private fun hypot(x: Float, y: Float, z: Float) =
        Math.sqrt((x * x + y * y + z * z).toDouble()).toFloat()

    /*
     * TODO Verify math correctness
     */
    fun getRotation(): QuaternionTC {
        var q = QuaternionTC()
        val scaling = getScaling()
        val is1 = 1 / scaling.x
        val is2 = 1 / scaling.y
        val is3 = 1 / scaling.z
        val sm11 = elements[0] * is1
        val sm12 = elements[1] * is2
        val sm13 = elements[2] * is3
        val sm21 = elements[4] * is1
        val sm22 = elements[5] * is2
        val sm23 = elements[6] * is3
        val sm31 = elements[8] * is1
        val sm32 = elements[9] * is2
        val sm33 = elements[10] * is3
        val trace = sm11 + sm22 + sm33
        var S: Double
        if (trace > 0) {
            S = Math.sqrt(trace + 1.0) * 2
            q.w = (0.25 * S).toFloat()
            q.x = ((sm23 - sm32) / S).toFloat()
            q.y = ((sm31 - sm13) / S).toFloat()
            q.z = ((sm12 - sm21) / S).toFloat()
        } else if (sm11 > sm22 && sm11 > sm33) {
            S = Math.sqrt(1.0 + sm11 - sm22 - sm33) * 2
            q.w = ((sm23 - sm32) / S).toFloat()
            q.x = (0.25 * S).toFloat()
            q.y = ((sm12 + sm21) / S).toFloat()
            q.z = ((sm31 + sm13) / S).toFloat()
        } else if (sm22 > sm33) {
            S = Math.sqrt(1.0 + sm22 - sm11 - sm33) * 2
            q.w = ((sm31 - sm13) / S).toFloat()
            q.x = ((sm12 + sm21) / S).toFloat()
            q.y = (0.25 * S).toFloat()
            q.z = ((sm23 + sm32) / S).toFloat()
        } else {
            S = Math.sqrt(1.0 + sm33 - sm11 - sm22) * 2
            q.w = ((sm12 - sm21) / S).toFloat()
            q.x = ((sm31 + sm13) / S).toFloat()
            q.y = ((sm23 + sm32) / S).toFloat()
            q.z = (0.25 * S).toFloat()
        }
        return q
    }

    fun determinant() =
        elements[0] * (elements[5] * elements[10] * elements[15] + elements[6] * elements[11] * elements[13] + elements[7] * elements[9] * elements[14] -
                elements[7] * elements[10] * elements[13] - elements[6] * elements[9] * elements[15] - elements[5] * elements[11] * elements[14]) -
                elements[4] * (elements[1] * elements[10] * elements[15] + elements[2] * elements[11] * elements[13] + elements[3] * elements[9] * elements[14] -
                elements[3] * elements[10] * elements[13] - elements[2] * elements[9] * elements[15] - elements[1] * elements[11] * elements[14]) +

                elements[8] * (elements[1] * elements[6] * elements[15] + elements[2] * elements[7] * elements[13] + elements[3] * elements[5] * elements[14] -
                elements[3] * elements[6] * elements[13] - elements[2] * elements[5] * elements[15] - elements[1] * elements[7] * elements[14]) -

                elements[12] * (elements[1] * elements[6] * elements[11] + elements[2] * elements[7] * elements[9] + elements[3] * elements[5] * elements[10] -
                elements[3] * elements[6] * elements[9] - elements[2] * elements[5] * elements[11] - elements[1] * elements[7] * elements[10])

    fun insertElements(list: List<Float>): Matrix4 {
        var matrix = Matrix4()
        matrix.elements.clear()
        matrix.elements.addAll(list)
        return matrix
    }

    /*
     * TODO replace code with my own someday ?
     *  dionsaputra Github code
     */
    fun invert(): Matrix4? {
        val src = FloatArray(16)
        copyTop16To(this, src)
        val mInv = FloatArray(16)
        return if (Matrix.invertM(mInv, 0, src, 0)) {
            insertElements(mInv.toList())
        } else {
            null
        }
    }

    fun inverse(m: Matrix4): Matrix4? {
        val src = FloatArray(16)
        copyTop16To(m, src)
        val mInv = FloatArray(16)
        return if (Matrix.invertM(mInv, 0, src, 0)) {
            insertElements(mInv.toList())
        } else {
            null
        }
    }

    /*
     * TODO Requires verification from WebGL
     */
    fun rotateInRadian(axis: RotateAxis, radians: Float): Matrix4 {
        val degrees = radians * 180.0 / Math.PI
        return rotateInDegrees(axis, degrees.toFloat())
    }

    fun rotateInDegrees(axis: RotateAxis, degrees: Float): Matrix4 {
        val rm = FloatArray(16)
        val m = FloatArray(16)

        val matrix = identity()
        var i = 0
        for (element in matrix.elements) {
            m[i++] = element.toFloat()
        }

        var x = 0f
        var y = 0f
        var z = 0f
        when (axis) {
            RotateAxis.RotateX -> x = 1f
            RotateAxis.RotateY -> y = 1f
            RotateAxis.RotateZ -> z = 1f
        }
        Matrix.rotateM(rm, 0, m, 0, degrees.toFloat(), x, y, z)
        return insertElements(
            rm.toList()
        )
    }

    fun scale(v3: Vector3, scaleMatrix: FloatArray? = null): Matrix4 {
        var sm = FloatArray(16)
        val m = scaleMatrix?.let { scaleMatrix } ?: identity().elements.toFloatArray()
        Matrix.scaleM(sm, 0, m, 0, v3.x, v3.y, v3.z)
        return fromArray(sm.toList()) as Matrix4
    }

    fun scaleScalar(s: Float): Matrix4 {
        var sm = FloatArray(16)
        val m = identity().elements.toFloatArray()
        Matrix.scaleM(sm, 0, m, 0, s, s, s)
        return fromArray(sm.toList()) as Matrix4
    }

    fun translate(v3: Vector3): Matrix4 {
        var tm = FloatArray(16)
        val m = identity().elements.toFloatArray()
        Matrix.translateM(tm, 0, m, 0, v3.x, v3.y, v3.z)
        return fromArray(tm.toList()) as Matrix4
    }

    fun transpose() = insertElements(
        listOf(
            this.elements[0],
            this.elements[4],
            this.elements[8],
            this.elements[12],

            this.elements[1],
            this.elements[5],
            this.elements[9],
            this.elements[13],

            this.elements[2],
            this.elements[6],
            this.elements[10],
            this.elements[14],

            this.elements[3],
            this.elements[7],
            this.elements[11],
            this.elements[15],
        )
    )

    /** Copy the first 16 entries (column-major 4×4); pads with 0 if the list was corrupted/longer. */
    private fun copyTop16To(m: Matrix4, out: FloatArray) {
        val e = m.elements
        for (i in 0 until 16) {
            out[i] = if (i < e.size) e[i] else 0f
        }
    }

    /**
     * Column-major 4×4 multiply, matching OpenGL / [Matrix.multiplyMM] (lhs × rhs).
     * The previous hand-rolled multiply did not match column-major layout and broke
     * [invert] vs tile transforms built with Android [Matrix] APIs.
     */
    fun multiply(m1: Matrix4, m2: Matrix4? = null): Matrix4 {
        val lhs = FloatArray(16)
        val rhs = FloatArray(16)
        val out = FloatArray(16)
        if (m2 != null) {
            copyTop16To(m1, lhs)
            copyTop16To(m2, rhs)
        } else {
            copyTop16To(this, lhs)
            copyTop16To(m1, rhs)
        }
        Matrix.multiplyMM(out, 0, lhs, 0, rhs, 0)
        elements.clear()
        for (i in 0 until 16) elements.add(out[i])
        return this
    }

    fun compose(translation: Vector3, quaternion: QuaternionTC, scale: Vector3) =
        fromRotationTranslationScale(quaternion, translation, scale)

    fun getTranslation(position: Vector3) {
        elements[12] = position.x
        elements[13] = position.y
        elements[14] = position.z
    }

    /*
     * TODO Verify math correctness
     */
    private fun fromRotationTranslationScale(q: QuaternionTC, v: Vector3, s: Vector3): Matrix4 {
        var m = Matrix4()
        // Quaternion math
        val x = q.x
        val y = q.y
        val z = q.z
        val w = q.w
        val x2 = x + x
        val y2 = y + y
        val z2 = z + z
        val xx = x * x2
        val xy = x * y2
        val xz = x * z2
        val yy = y * y2
        val yz = y * z2
        val zz = z * z2
        val wx = w * x2
        val wy = w * y2
        val wz = w * z2
        val sx = s.x
        val sy = s.y
        val sz = s.z
        m.elements.add((1 - (yy + zz)) * sx)
        m.elements.add((xy + wz) * sx)
        m.elements.add((xz - wy) * sx)
        m.elements.add(0f)
        m.elements.add((xy - wz) * sy)
        m.elements.add((1 - (xx + zz)) * sy)
        m.elements.add((yz + wx) * sy)
        m.elements.add(0f)
        m.elements.add((xz + wy) * sz)
        m.elements.add((yz - wx) * sz)
        m.elements.add((1 - (xx + yy)) * sz)
        m.elements.add(0f)
        m.elements.add(v.x)
        m.elements.add(v.y)
        m.elements.add(v.z)
        m.elements.add(1f)
        return m
    }

    fun multiplyScalar(s: Float) = insertElements(
        listOf(
            elements[0] * s,
            elements[1] * s,
            elements[2] * s,
            elements[3] * s,

            elements[4] * s,
            elements[5] * s,
            elements[6] * s,
            elements[7] * s,

            elements[8] * s,
            elements[9] * s,
            elements[10] * s,
            elements[11] * s,

            elements[12] * s,
            elements[13] * s,
            elements[14] * s,
            elements[15] * s,
        )
    )

    override fun toString() =
        "${elements[0]}, ${elements[1]}, ${elements[2]}, ${elements[3]}, " +
                "${elements[4]}, ${elements[5]}, ${elements[6]}, ${elements[7]}, " +
                "${elements[8]}, ${elements[9]}, ${elements[10]}, ${elements[11]}, " +
                "${elements[12]}, ${elements[13]}, ${elements[14]}, ${elements[15]}"


}

enum class RotateAxis {
    RotateX,
    RotateY,
    RotateZ
}