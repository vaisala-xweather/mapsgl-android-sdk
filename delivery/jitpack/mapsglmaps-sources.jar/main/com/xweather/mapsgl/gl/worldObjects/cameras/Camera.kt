package com.xweather.mapsgl.gl.worldObjects.cameras
import android.graphics.RectF
import android.opengl.Matrix
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.math.Vector3
import com.xweather.mapsgl.gl.worldObjects.AbstractObject3D

/*
 * TODO Finish implementing Nick's webGL Camera
 *  https://bitbucket.org/hamweather/webgl-core/src/master/src/core/Camera.ts
 *
 * Camera Math WebGL
 * http://learnwebgl.brown37.net/07_cameras/camera_math.html
 *
 * Matrix MVP explained
 * http://www.opengl-tutorial.org/beginners-tutorials/tutorial-3-matrices/#the-model-matrix
 */
open class Camera(
    override var type: CameraType = CameraType.Perspective,
    override var near: Float = 1f,      // near most point on axis
    override var far: Float = 1000f,    // far most point on axis
    override var fov: Float = 45f,      // field of view
    override var aspect: Float = 1f,    // aspect ratio
    override var bounds: RectF,
    override var zoom: Double = 1.0
) : ICamera, AbstractObject3D() {

    // Fixme: test variables
    var blurSize = 0f
    var blurRadius = 0f
    var colorize = true
    var returnMatrix = FloatArray(16) //used in getViewMatrix
    var resX=0
    var resY=0
    /* 0 = initial,    */
    var moveState=0
    var orientationChanged = false
    var needsRotationHandled = false





    /** dpi of 2 results in dpiMult of 1. dpi of 4 results in dpiMult of 2 **/
    var dpiMult = 1f
    /** Screen refresh rate of 60 results in value of 1f. Refresh rate of 120 results in value of .5f **/
    var refreshRateFactor=1f

    //var projectionFromParameters=FloatArray(16)

    companion object{
        const val MOVING = 2
        const val STOPPED = 3
        var darkBackground = false

    }

    // camera view of the world (ortho/perceptive)
    override lateinit var projectionMatrix: ProjectionMatrix

    // camera's position
    override lateinit var viewMatrix: Matrix4

    // camera's position ?
    override lateinit var worldPosition: Vector3

    init {
        setup( type, near, far, fov, aspect, bounds, zoom)
    }

    fun setup(
        type: CameraType = CameraType.Perspective,
        near: Float = 1f,      // near most point on axis
        far: Float = 1000f,    // far most point on axis
        fov: Float = 45f,      // field of view
        aspect: Float = 1f,    // aspect ratio
        bounds: RectF,
        zoom: Double = 1.0
    ) {
        projectionMatrix = ProjectionMatrix()
        viewMatrix = Matrix4()
        worldPosition = Vector3()

        // Use the requested type. Do not infer from bounds: symmetric perspective frusta use
        // non-zero left/right (e.g. -width/2 … +width/2) and were incorrectly forced to orthographic.
        this.type = type
        if (this.type == CameraType.Orthographic) {
            this.orthographic(
                bounds.left,
                bounds.right,
                bounds.top,
                bounds.bottom,
                near,
                far,
                zoom.toFloat()
            );
        } else {
            this.perspective(fov, aspect, near, far);
        }

        updateMatrixWorld()
    }

    override fun perspective(fov: Float, aspect: Float, near: Float, far: Float) {
        this.fov = fov;
        this.aspect = aspect;
        this.near = near;
        this.far = far;
        this.projectionMatrix.fromPerspective(fov, aspect, near, far);
        this.type = CameraType.Perspective;
    }

    override fun orthographic(
        left: Float,
        right: Float,
        top: Float,
        bottom: Float,
        near: Float,
        far: Float,
        zoom: Float
    ) {
        this.bounds = RectF(left, right, top, bottom)
        this.near = near;
        this.far = far;

        this.projectionMatrix.orthographic(
            left / zoom,
            right / zoom,
            top / zoom,
            bottom / zoom,
            near,
            far
        )
        this.type = CameraType.Orthographic;
    }

    override fun lookAt(target: Vector3): Camera {
        super.lookAt(target, true);

        var matrix = FloatArray(16)
        position.let {
            Matrix.setLookAtM(
                matrix, 0,
                it.x, it.y, it.z,
                0f, 0f, 0f,
                0f, 1.0f, 0.0f       // up axis in this 3D world - Y
            );
        }
        return this;
    }

    /*
     * TODO Refactor these classes to streamline
     *  camera position should be updated from outside (renderer or above)
     */
    override fun getViewMatrix(): FloatArray {
        Matrix.setIdentityM(returnMatrix, 0); // initialize to identity matrix
        return returnMatrix
    }

    override fun updateMatrixWorld(): Camera {
       // super.updateMatrixWorld(false); //commented this out because it cleared worldMatrix
       // println("Camera worldMatrix: $worldMatrix")

        viewMatrix= worldMatrix.invert()!!
       // println(" Camera viewMatrix: $viewMatrix")
        //println("world before: $worldMatrix")
       // worldMatrix.getTranslation(worldPosition); //fixme: Strips out world position? See if needed
        //println("world after: $worldMatrix")

        return this
    }
}

