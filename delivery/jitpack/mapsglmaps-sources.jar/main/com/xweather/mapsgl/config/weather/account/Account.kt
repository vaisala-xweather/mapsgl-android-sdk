package com.xweather.mapsgl.config.weather.account

/**
 * Xweather API credentials used across MapsGL tile requests and authentication.
 *
 * The pair is combined into an access key form (`id_secret`) in URL templates and
 * [com.xweather.mapsgl.weather.XweatherAuthenticator]; treat [secret] as sensitive and avoid logging it.
 *
 * @property id Client / application id.
 * @property secret Client secret paired with [id].
 *
 * @see com.xweather.mapsgl.weather.WeatherService
 * @see com.xweather.mapsgl.map.MapController
 */
data class XweatherAccount(
    val id: String,
    val secret: String,
)
