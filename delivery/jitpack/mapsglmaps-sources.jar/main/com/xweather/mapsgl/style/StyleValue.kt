package com.xweather.mapsgl.style

import androidx.compose.ui.graphics.Color

data class Anchor(val rawValue: String)
data class AnchorOffset(val x: Double, val y: Double)
data class TextJustification(val rawValue: String)
data class TextTransform(val rawValue: String)

sealed class StyleColor {
    data class Color(val color: androidx.compose.ui.graphics.Color) : StyleColor()
    data class Hex(val hexString: String) : StyleColor()
    data class RGBA(val rgbaString: String) : StyleColor()

    fun toRGBAString(): String = when (this) {
        is Color -> color.toRGBAString()
        is Hex -> hexString
        is RGBA -> rgbaString
    }
}

fun Color.toRGBAString(): String {
    val a = this.alpha
    val r = (this.red * 255.0).toInt()
    val g = (this.green * 255.0).toInt()
    val b = (this.blue * 255.0).toInt()
    return "rgba($r,$g,$b,$a)"
}

//fun Int.toRGBAString(): String {
//    val a = Color.alpha(this) / 255f
//    val r = Color.red(this)
//    val g = Color.green(this)
//    val b = Color.blue(this)
//    return "rgba($r,$g,$b,$a)"
//}

/**
 * Paint or layout property value: either a **constant** literal or a Mapbox-style **expression**.
 *
 * MapsGL uses `StyleValue` anywhere a style property can be static or data-driven (for example
 * [StrokePaint.thickness], colors in [FillPaint], or zoom interpolation). Constants serialize to
 * JSON literals; [StyleValue.Expression] variants serialize to Mapbox expression arrays/objects via
 * [com.xweather.mapsgl.style.Expression.toJSONObject].
 *
 * Use [Constant] for fixed values known at compile time. Use [StyleValue.Expression] (or
 * [fromExpressionArray]) when the value should follow feature data, zoom, or other runtime inputs,
 * matching the JavaScript SDK’s expression arrays.
 *
 * @param T Type of the value held by [Constant] (covariant; [StyleValue.Expression] uses [Nothing] because it
 *   does not carry a single Kotlin-typed literal).
 *
 * @see com.xweather.mapsgl.style.Expression
 * @see makeJSONObject
 */
sealed class StyleValue<out T> {
    /**
     * A single literal value written directly into style JSON (not wrapped in an expression operator).
     *
     * @property value The Kotlin value; converted for JSON via [resolvedValue] / [makeJSONObject]
     *   (colors to `rgba(...)`, [LineJoin]/[LineCap] to strings, etc.).
     */
    data class Constant<T>(val value: T) : StyleValue<T>()

    /**
     * A Mapbox-compatible expression tree (e.g. `["get", "mag"]`, `["interpolate", ...]`).
     *
     * @property expression Root expression node; serializes with [com.xweather.mapsgl.style.Expression.toJSONObject].
     */
    data class Expression(val expression: com.xweather.mapsgl.style.Expression) : StyleValue<Nothing>()

    /**
     * The [Constant.value] when this is a [Constant]; otherwise `null`.
     */
    val constantValue: T?
        get() = (this as? Constant<T>)?.value

    /**
     * The wrapped [com.xweather.mapsgl.style.Expression] when this is a [StyleValue.Expression]; otherwise `null`.
     */
    val expressionValue: com.xweather.mapsgl.style.Expression?
        get() = (this as? Expression)?.expression

    /**
     * JSON-ready representation: constants pass through [makeJSONObject], expressions through
     * [com.xweather.mapsgl.style.Expression.toJSONObject]. Useful for debugging or custom style serialization.
     */
    val resolvedValue: Any?
        get() = when (this) {
            is Constant -> makeJSONObject(value)
            is Expression -> expression.toJSONObject()
        }

    companion object {
        /**
         * Builds a [StyleValue.Expression] from a raw expression array (first element is typically the operator string).
         *
         * @param array Top-level expression list as understood by [com.xweather.mapsgl.style.Expression].
         */
        fun <T> fromExpressionArray(array: List<Any>): StyleValue<T> = Expression(Expression(array))
    }
}

fun makeJSONObject(value: Any?): Any? = when (value) {
    is Expression -> value.toJSONObject()
    is Anchor -> value.rawValue
    is AnchorOffset -> listOf(value.x, value.y)
    // Support the public types used by IconPaint/TextPaint.
    // Without this, `com.xweather.mapsgl.types.Anchor.BOTTOM` etc. won't serialize to the
    // expected Mapbox `icon-anchor` / `text-anchor` string/offset and Mapbox falls back to center.
    is com.xweather.mapsgl.types.Anchor -> value.value
    is com.xweather.mapsgl.types.AnchorOffset -> listOf(value.x, value.y)
    is TextJustification -> value.rawValue
    is TextTransform -> value.rawValue
    is LineJoin -> value.value
    is LineCap -> value.value
    is List<*> -> value.map { makeJSONObject(it) }
    is Map<*, *> -> value.entries.associate { (k, v) -> k.toString() to makeJSONObject(v) }
    is Color -> value.toRGBAString()
    is StyleColor -> when (value) {
        is StyleColor.Color -> value.color.toRGBAString()
        is StyleColor.Hex -> value.hexString
        is StyleColor.RGBA -> value.rgbaString
    }
//    is Int -> value.toRGBAString()
    else -> value
}