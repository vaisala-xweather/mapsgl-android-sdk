package com.xweather.mapsgl.style

import androidx.compose.ui.graphics.Color

/**
 * Per-span formatting options for Mapbox `format` expressions built with [Expression.Companion.format].
 *
 * Serialized to a small JSON object (`font-scale`, `text-font`, `text-color`) alongside each text fragment.
 */
data class TextFormatOptions(
    var fontScale: Double? = null,
    var textFont: List<String>? = null,
    var textColor: Color? = null
) {
    fun toJSONObject(): Map<String, Any> {
        val obj = mutableMapOf<String, Any>()
        fontScale?.let { obj["font-scale"] = it }
        textFont?.let { obj["text-font"] = it }
        textColor?.let { obj["text-color"] = it.toRGBAString() }
        return obj
    }
}

/**
 * Mapbox **style expression** wrapper: holds a JSON-serializable tree (usually a [List] with an operator in
 * the first element, or a nested structure) compatible with Mapbox’s expression spec.
 *
 * Use the factory methods on the companion object for common operators (`get`, `interpolate`, `match`, …).
 * Embed inside [StyleValue.Expression] for data-driven paint properties.
 *
 * @property raw Underlying value passed to [makeJSONObject] for style JSON or debugging.
 *
 * @see StyleValue.Expression
 * @see makeJSONObject
 */
data class Expression(val raw: Any) {
    fun toJSONObject(): Any? = makeJSONObject(raw)

    /**
     * Factory helpers mirroring Mapbox expression operators. Methods return new [Expression] nodes;
     * combine them or wrap in [StyleValue.Expression] as needed.
     */
    companion object {
        val geometryType = listOf("geometry-type")
        var zoom = listOf("zoom")

        fun get(property: String): Expression =
            if (property.contains('.')) getPath(property)
            else Expression(listOf("get", property))

        fun getPath(path: String): Expression {
            val keys = path.split(".")
            return keys.fold(null as Expression?) { acc, key ->
                if (acc == null) Expression(listOf("get", key))
                else {
                    key.toIntOrNull()?.let { Expression(listOf("at", it, acc.raw)) }
                        ?: Expression(listOf("get", key, acc.raw))
                }
            } ?: get("")
        }

        fun literal(value: Any): Expression = Expression(listOf("literal", value))

        fun rgb(red: Any, green: Any, blue: Any): Expression =
            Expression(listOf("rgb", red, green, blue))

        fun rgba(red: Any, green: Any, blue: Any, alpha: Any): Expression =
            Expression(listOf("rgba", red, green, blue, alpha))

        fun subtract(lhs: Any, rhs: Any): Expression =
            Expression(listOf("-", lhs, rhs))

        fun subtract(value: Any): Expression = subtract(0, value)

        fun add(lhs: Any, rhs: Any): Expression =
            Expression(listOf("+", lhs, rhs))

        fun multiply(lhs: Any, rhs: Any): Expression =
            Expression(listOf("*", lhs, rhs))

        fun divide(lhs: Any, rhs: Any): Expression =
            Expression(listOf("/", lhs, rhs))

        fun mod(lhs: Any, rhs: Any): Expression =
            Expression(listOf("%", lhs, rhs))

        fun floor(value: Any): Expression =
            Expression(listOf("floor", value))

        fun ceil(value: Any): Expression =
            Expression(listOf("ceil", value))

        fun round(value: Any): Expression =
            Expression(listOf("round", value))

        fun abs(value: Any): Expression =
            Expression(listOf("abs", value))

        fun min(vararg values: Any): Expression =
            Expression(listOf("min") + values)

        fun max(vararg values: Any): Expression =
            Expression(listOf("max") + values)

        fun toNumber(value: Any): Expression =
            Expression(listOf("to-number", value))

        fun toString(value: Any): Expression =
            Expression(listOf("to-string", value))

        fun toBoolean(value: Any): Expression =
            Expression(listOf("to-boolean", value))

        fun equals(lhs: Any, rhs: Any): Expression =
            Expression(listOf("==", lhs, rhs))

        fun notEquals(lhs: Any, rhs: Any): Expression =
            Expression(listOf("!=", lhs, rhs))

        fun greaterThan(lhs: Any, rhs: Any): Expression =
            Expression(listOf(">", lhs, rhs))

        fun lessThan(lhs: Any, rhs: Any): Expression =
            Expression(listOf("<", lhs, rhs))

        fun greaterThanOrEqual(lhs: Any, rhs: Any): Expression =
            Expression(listOf(">=", lhs, rhs))

        fun lessThanOrEqual(lhs: Any, rhs: Any): Expression =
            Expression(listOf("<=", lhs, rhs))

        fun and(expressions: List<Any>): Expression =
            Expression(listOf("all") + expressions)

        fun or(expressions: List<Any>): Expression =
            Expression(listOf("any") + expressions)

        fun not(expression: Any): Expression =
            Expression(listOf("!", expression))

        fun <T : Any> step(input: Any, stops: List<Step<T>>): Expression {
            val flattened = mutableListOf<Any?>()
            stops.forEachIndexed { index, stop ->
                if (index == 0) {
                    stop.resolvedResult()?.let { flattened.add(it) }
                } else {
                    flattened.add(stop.value)
                    stop.resolvedResult()?.let { flattened.add(it) }
                }
            }
            return Expression(listOf("step", input) + flattened)
        }

        fun interpolate(interpolation: Any, input: Any, stops: List<Any>): Expression =
            Expression(listOf("interpolate", interpolation, input) + stops)

        fun match(input: Any, matches: List<Step<Any>>, fallback: Any?): Expression {
            val flattened = matches.flatMap { listOf(it.value, it.resolvedResult()) }
            return Expression(listOf("match", input) + flattened + listOf(fallback))
        }

        fun switchCase(conditionsAndResults: List<Case>, fallback: Any): Expression {
            val flattened = mutableListOf<Any?>()
            for (case in conditionsAndResults) {
                flattened.add(case.condition)
                flattened.add(case.result)
            }
            flattened.add(fallback)
            return Expression(listOf("case") + flattened)
        }

        fun coalesce(expressions: List<Any>): Expression =
            Expression(listOf("coalesce") + expressions)

        fun length(input: Any): Expression =
            Expression(listOf("length", input))

        fun concat(parts: List<Any>): Expression =
            Expression(listOf("concat") + parts)

        fun upcase(input: Any): Expression =
            Expression(listOf("upcase", input))

        fun downcase(input: Any): Expression =
            Expression(listOf("downcase", input))

        fun join(separator: String, parts: List<Any>): Expression =
            Expression(listOf("join", separator) + parts)

        fun slice(input: Any, start: Int, end: Int? = null): Expression {
            val expr = mutableListOf<Any>("slice", input, start)
            if (end != null) expr.add(end)
            return Expression(expr)
        }

        fun at(index: Int, array: Any): Expression =
            Expression(listOf("at", index, array))

        fun contains(value: Any, array: List<String>): Expression =
            Expression(listOf("in", value, array))

        fun has(property: String, obj: Any? = null): Expression {
            return if (property.contains('.')) {
                hasPath(property)
            } else {
                if (obj != null) Expression(listOf("has", property, obj))
                else Expression(listOf("has", property))
            }
        }

        fun hasPath(property: String): Expression {
            val keys = property.split('.')
            val last = keys.lastOrNull() ?: return Expression(listOf("has", property))
            if (keys.size == 1) return Expression(listOf("has", last))
            val parentPath = keys.dropLast(1).joinToString(".")
            val parentObject = getPath(parentPath)
            return has(last, parentObject)
        }

        fun indexOf(search: Any, array: Any): Expression =
            Expression(listOf("index-of", search, array))

        fun interpolate(input: Any, stops: List<Any>): Expression {
            val flattened = stops.flatMap {
                if (it is ColorStop) listOf(it.value, it.color.toRGBAString())
                else listOf(it)
            }
            return Expression(listOf("interpolate", listOf("linear"), input) + flattened)
        }

        fun interpolateExponential(input: Any, base: Double, stops: List<Any>): Expression =
            Expression(listOf("interpolate", listOf("exponential", base), input) + stops)

        fun interpolateCubicBezier(input: Any, controlPoints: List<Double>, stops: List<Any>): Expression =
            Expression(listOf("interpolate", listOf("cubic-bezier") + controlPoints, input) + stops)

        fun format(parts: List<Pair<StyleValue<String>, TextFormatOptions>>): Expression {
            val formatted = mutableListOf<Any>("format")
            parts.forEach { (value, options) ->
                value.resolvedValue?.let { formatted.add(it) }
                formatted.add(options.toJSONObject())
            }
            return Expression(formatted)
        }

        fun bind(bindings: List<Variable>, output: Any): Expression {
            val expression = mutableListOf<Any>("let")
            bindings.forEach { variable ->
                expression.add(variable.key)
                makeJSONObject(variable.value)?.let { expression.add(it) }
            }
            makeJSONObject(output)?.let { expression.add(it) }
            return Expression(expression)
        }

        fun variable(name: String): Expression =
            Expression(listOf("var", name))
    }

    /**
     * One stop in `step` (or similar) expressions: input threshold [value] and [result] output.
     *
     * @param value Stop key; first stop may use a default output via [resolvedResult] rules in [step].
     * @param result Literal or nested expression; JSON via [makeJSONObject].
     */
    data class Step<T>(val value: T?, val result: Any) {
        fun resolvedResult(): Any? = makeJSONObject(result)
    }

    /**
     * One branch in a `case` expression: boolean [condition] and [result] when true.
     */
    data class Case(
        val condition: Expression,
        val result: Any?
    )

    /**
     * Binding for `let`: [key] name and [value] bound expression or literal.
     */
    data class Variable(
        val key: String,
        val value: Any
    )
}