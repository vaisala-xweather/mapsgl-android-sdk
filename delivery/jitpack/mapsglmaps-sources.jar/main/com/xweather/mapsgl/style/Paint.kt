package com.xweather.mapsgl.style

import LayerEvents
import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.layers.spec.LayerEventEmitter
import com.xweather.mapsgl.layers.spec.StyleJSON
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.ColorSampling
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.TextJustification
import com.xweather.mapsgl.types.TextTransform

// A base interface for paint styles used in individual render passes.
interface Paint

enum class LineJoin(val value: String) {
    MITER("miter"), ROUND("round"), BEVEL("bevel")
}

enum class LineCap(val value: String) {
    BUTT("butt"), ROUND("round"), SQUARE("square")
}

// Style options for raster tiles rendered as static images.
//
// This type defines how raster imagery (e.g., PNG or JPG tiles) is displayed.
class RasterPaint : Paint


/**
 * Grid spacing in logical px from style/JS.
 *
 * Instanced GL gridded layers ([EncodedGridVectorTileSource]) combine device density with an internal spacing scale
 * when building placement so on-screen density matches [IconSize]-scaled icons; Mapbox symbol layout from
 * [GridLayerPaint.asStyleJSON] is unchanged.
 */
class GridPaint(var spacing: Double = 20.0) : Paint {}


// Style options for visualizing sampled values from encoded data sources.
//
// Defines interpolation, color mapping, value ranges, and animation blending for encoded datasets.
class SamplePaint(
    override var expression: SampleExpression = SampleExpression.NUMBER,
    override var channel: List<ColorBand> = listOf(ColorBand.red),
    override var quality: DataQuality = DataQuality.exact,
    override var interpolation: InterpolationMode = InterpolationMode.BICUBIC,
    override var smoothing: Float = 0.0f,
    override var offset: Float = 0.0f,
    override var drawRange: ClosedRange<Double>? = null,
    colorScale: ColorScaleOptions = ColorScaleOptions(),
    var multiband: Boolean = false,
    var meld: Boolean = true,
    /**
     * Shader normalization max for encoded-grid sidecar symbols; when null, [colorScale].range end is used.
     */
    var encodedScalarNormMax: Double? = null,
    var eventEmitter: LayerEventEmitter? = null,
) : Paint, ColorSampling {

    override var colorScale: ColorScaleOptions = colorScale
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE", LayerEvents.SamplePaintChangeEvent(
                    property = "sample.colorscale", value = value
                )
            )
        }
}

class ContourPaint(
    //override var expression: SampleExpression = SampleExpression.NUMBER,
    //override var channel: List<ColorBand> = listOf(ColorBand.red),
    //override var quality: DataQuality = DataQuality.exact,
    //override var interpolation: InterpolationMode = InterpolationMode.BICUBIC,
    //override var smoothing: Float = 0.0f,
    //override var offset: Float = 0.0f,
    //override var drawRange: ClosedRange<Double>? = null,
    colorScale: ColorScaleOptions = ColorScaleOptions(),
    var multiband: Boolean = false,
    var meld: Boolean = true,
    var eventEmitter: LayerEventEmitter? = null,
    var interval: StyleValue<Double> = StyleValue.Constant(2.0),
    var majorInterval: StyleValue<Double> = StyleValue.Constant(10.0),

    var width: StyleValue<Double> = StyleValue.Constant(1.0),
    var majorWidth: StyleValue<Double> = StyleValue.Constant(3.0),
    var scale: StyleValue<Double> = StyleValue.Constant(1.0),
) : Paint {


    /** Determines the value interval for which to draw major, or thicker, contour lines for. If this value is `0`, then
     * major contour lines will not be rendered. This value must be in the same units as the data source. **/


}

// Style options for visualizing vector field data as animated particles.
//
// Supports dense or fixed-count particle rendering with tunable trail, speed, and emission effects.

class ParticlePaint(
    // The visual type of the particle, such as `.circle` or `.arrow`.
    var kind: ParticleKind = ParticleKind.CIRCLE,
    var density: ParticleDensity = ParticleDensity.NORMAL,
    var count: Int = 0,
    /** The size of each individual particle. For wind particles, you only need to set one integer. For
     * wave and swell particles, you can set the width and height individually to create rectangular particles. **/
    var size: Size = Size(2),
    var speed: Double = 1.0,
    var trails: Boolean = true,
    var trailsFade: Double = 0.97,
    var dropRate: Double = 0.01,
    var dropRateBump: Double = 0.01
) : Paint


class FillPaint(
    // 1. Remove 'override val' from here to avoid property collision.
    // This is now just an argument used for initialization.
    color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    var pattern: StyleValue<String>? = null,
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    var eventEmitter: LayerEventEmitter? = null
) : Paint {

    // 2. Define the property manually so we can use a custom setter
    var color: StyleValue<Color> = color
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE", LayerEvents.SamplePaintChangeEvent(
                    property = "fill.color", value = value
                )
            )
        }

    /**
     * Custom copy function to replicate data class behavior.
     * Use this to create a new instance with specific property changes.
     */
    fun copy(
        color: StyleValue<Color> = this.color,
        pattern: StyleValue<String>? = this.pattern,
        opacity: StyleValue<Double> = this.opacity,
        eventEmitter: LayerEventEmitter? = this.eventEmitter
    ): FillPaint {
        return FillPaint(
            color = color, pattern = pattern, opacity = opacity, eventEmitter = eventEmitter
        )
    }
}

data class StrokePaint(
    var color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    var thickness: StyleValue<Double> = StyleValue.Constant(2.0),
    var lineJoin: StyleValue<LineJoin> = StyleValue.Constant(LineJoin.ROUND),
    var lineCap: StyleValue<LineCap> = StyleValue.Constant(LineCap.ROUND)
) : Paint

class CirclePaint(
    // Remove var/val from constructor argument to allow manual property definition
    color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    var radius: StyleValue<Double> = StyleValue.Constant(6.0),
    var sortKey: StyleValue<Double>? = null,
    var eventEmitter: LayerEventEmitter? = null
) : Paint {

    // Manual property with setter to trigger the sync event
    var color: StyleValue<Color> = color
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE", LayerEvents.SamplePaintChangeEvent(
                    property = "circle.color", value = value
                )
            )
        }

    /**
     * Custom copy function to replicate data class behavior.
     */
    fun copy(
        color: StyleValue<Color> = this.color,
        radius: StyleValue<Double> = this.radius,
        sortKey: StyleValue<Double>? = this.sortKey,
        eventEmitter: LayerEventEmitter? = this.eventEmitter
    ): CirclePaint {
        return CirclePaint(
            color = color, radius = radius, sortKey = sortKey, eventEmitter = eventEmitter
        )

    }
}

/**
 * Width and height in the same units as MapsGL JS `icon.size` — **pixel dimensions** for the laid-out symbol quad
 * (see web `SymbolStore.layoutIcon`: `w`/`h` from [PaintStyle.iconSize]).
 *
 * Instanced gridded renderers convert these to Mercator half-extents using
 * [GridLayerRenderer.mercatorHalfExtentsFromJsIconPixels] with [JS_REFERENCE_WIDTH_PX] (40px reference); width/height
 * are multiplied by device [android.util.DisplayMetrics.density] there so physical on-screen size scales with DPI.
 *
 * [innerWidth] / [innerHeight] are **relative to [JS_REFERENCE_WIDTH_PX]** for Mapbox `icon-size` in [GridLayerPaint.asStyleJSON].
 */
class IconSize(
    width: Float,
    height: Float,
) {
    var width: Float = width
    var height: Float = height

    val innerWidth: Float get() = width / JS_REFERENCE_WIDTH_PX
    val innerHeight: Float get() = height / JS_REFERENCE_WIDTH_PX

    companion object {
        /** Matches web default icon width (e.g. `conditions` wind arrow `size: { width: 40, height: 20 }`). */
        const val JS_REFERENCE_WIDTH_PX: Float = 40f
    }
}

/**
 * Wind barb sprite atlas (parity with JS `icon.atlas`: ordered ids and speed step in **m/s** per index).
 *
 * The default ids are `mapsgl:wind-barb-0` … `mapsgl:wind-barb-100` in 5 kt steps. [intervalMs] is the bucket width
 * in m/s (JS: `5 * 0.5144444`). Instanced GL barbs still draw procedurally in [com.xweather.mapsgl.renderers.WindBarbInstancedRenderer];
 * keep [IconPaint.image] consistent with these ids for any Mapbox symbol / tooling path.
 */
data class IconAtlas(
    val ids: List<String>,
    /** Speed step in m/s between consecutive sprite indices (5 kt). */
    val intervalMs: Double,
) {

    val image: StyleValue<String> = windBarbSpriteImageExpression(ids, intervalMs)

    companion object {
        /** 1 kt → m/s (matches wind barb shader / JS `0.5144444`). */
        const val KNOTS_TO_MS_PER_KNOT: Double = 0.5144444

        /** JS `icon.atlas.interval`: 5 kt expressed in m/s (`5 * 0.5144444`). */
        const val WIND_BARB_INTERVAL_MS: Double = 5.0 * KNOTS_TO_MS_PER_KNOT

        /**
         * Mapbox `icon-image` expression: concat [prefix from ids][0] with the knot suffix derived from feature
         * `speed` (m/s). [intervalMs] is the bucket width in m/s (e.g. [WIND_BARB_INTERVAL_MS]); knot step and clamp
         * come from the numeric suffixes in [ids].
         */
        fun windBarbSpriteImageExpression(ids: List<String>, intervalMs: Double): StyleValue<String> {
            require(ids.isNotEmpty()) { "IconAtlas.ids must not be empty" }
            require(intervalMs > 0.0) { "IconAtlas.intervalMs must be positive" }
            val kts =
                ids.map { id ->
                    id.substringAfterLast('-').toDoubleOrNull()
                        ?: error("IconAtlas.ids entries must end with a numeric knot suffix: $id")
                }
            val ktStep =
                if (kts.size >= 2) {
                    kts[1] - kts[0]
                } else {
                    5.0
                }
            val maxKt = kts.maxOrNull() ?: 0.0
            val maxInner = (maxKt / ktStep).toInt().coerceAtLeast(0).toDouble()
            val prefix = ids[0].substringBeforeLast('-') + "-"
            return StyleValue.Expression(
                Expression.concat(
                    listOf(
                        Expression.literal(prefix),
                        Expression.toString(
                            Expression.multiply(
                                Expression.min(
                                    Expression.max(
                                        Expression.round(
                                            Expression.divide(
                                                Expression.toNumber(Expression.get("speed")),
                                                intervalMs,
                                            ),
                                        ),
                                        0.0,
                                    ),
                                    maxInner,
                                ),
                                ktStep,
                            ),
                        ),
                    ),
                ),
            )
        }
    }
}

data class IconPaint(
    var allowOverlap: StyleValue<Boolean> = StyleValue.Constant(false),
    var image: StyleValue<String>? = null,
    var size: StyleValue<Double>? = null,
    /**
     * Optional width/height scales for sidecar/GL symbols. Takes precedence over [size] for instanced wind renderers
     * when non-null.
     */
    var iconSize: IconSize? = null,
    /** Declarative atlas (JS `icon.atlas`); optional; see [IconAtlas]. */
    var atlas: IconAtlas? = null,
    var anchor: StyleValue<Anchor> = StyleValue.Constant(Anchor.CENTER),
    var offset: StyleValue<AnchorOffset> = StyleValue.Constant(AnchorOffset()),
    var padding: StyleValue<Double> = StyleValue.Constant(0.0),
    /**
     * Constant rotation offset in degrees (e.g. `-90` for wind barb/arrow base tilt). When [rotationUsesDataDirection]
     * is true, Mapbox icon rotation is `dir + rotation` from encoded features.
     */
    var rotation: Double = 0.0,
    /**
     * When true, [rotationExpression] uses `dir + rotation` via `Expression.get("dir")`; when false, rotation is constant.
     */
    var rotationUsesDataDirection: Boolean = false,
) : Paint {

    /**
     * Mapbox `icon-rotate` value, derived from [rotation] whenever read. Wind layers use
     * [StyleValue.Expression] with `dir + rotation`; other icons use [StyleValue.Constant].
     */
    internal val rotationExpression: StyleValue<Double>
        get() =
            if (rotationUsesDataDirection) {
                StyleValue.Expression(
                    Expression.add(
                        Expression.toNumber(Expression.get("dir")),
                        rotation,
                    ),
                )
            } else {
                StyleValue.Constant(rotation)
            }
}

data class TextPaint(
    var allowOverlap: StyleValue<Boolean> = StyleValue.Constant(false),
    var value: StyleValue<String>,
    var size: StyleValue<Double>? = null,
    var font: StyleValue<List<String>>? = null,
    var weight: StyleValue<String>? = null,
    var color: StyleValue<Color> = StyleValue.Constant(Color.Black),
    var outlineColor: StyleValue<Color>? = null,
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    var align: StyleValue<TextJustification> = StyleValue.Constant(TextJustification.CENTER),
    var transform: StyleValue<TextTransform> = StyleValue.Constant(TextTransform.NONE),
    var anchor: StyleValue<Anchor> = StyleValue.Constant(Anchor.CENTER),
    var offset: StyleValue<AnchorOffset> = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
    var padding: StyleValue<Double> = StyleValue.Constant(0.0),
    var rotation: StyleValue<Double> = StyleValue.Constant(0.0),
    var letterSpacing: StyleValue<Double>? = null,
    var lineHeight: StyleValue<Double>? = null,
    var maxWidth: StyleValue<Double>? = null
) : Paint

data class HeatmapPaint(
    var color: StyleValue<Color> = StyleValue.Expression(
        Expression.interpolate(
            listOf("heatmap-density"), listOf(
                0.0 to "rgba(0, 0, 0, 0)",
                0.2 to "rgba(0, 0, 255, 0.2)",
                0.45 to "rgba(0, 255, 0, 0.5)",
                0.85 to "rgba(255, 255, 0, 1)",
                1.0 to "rgba(255, 0, 0, 1)"
            )
        )
    ),
    var intensity: StyleValue<Double> = StyleValue.Constant(2.0),
    var radius: StyleValue<Double> = StyleValue.Constant(20.0),
    var weight: StyleValue<Double> = StyleValue.Constant(2.0)
) : Paint

interface LayerPaint {
    var opacity: Float
}

interface VectorLayerPaint : LayerPaint {
    fun asStyleJSON(id: String, source: String, sourceLayer: String? = null): StyleJSON
}

data class RasterLayerPaint(
    override var opacity: Float = 1.0f, var raster: RasterPaint
) : LayerPaint

data class SampleLayerPaint(
    override var opacity: Float = 1.0f, var sample: SamplePaint
) : LayerPaint

data class ContourLayerPaint(
    override var opacity: Float = 1.0f, var sample: SamplePaint, var contour: ContourPaint
) : LayerPaint {

    var interval: StyleValue<Double> = StyleValue.Constant(1.0)


}

data class ParticleLayerPaint(
    override var opacity: Float = 1.0f, var sample: SamplePaint, var particle: ParticlePaint
) : LayerPaint

data class FillLayerPaint(
    override var opacity: Float = 1.0f, var fill: FillPaint, var stroke: StrokePaint = StrokePaint()
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.FILL, source, sourceLayer).apply {
            fillColor = fill.color
            fillOpacity = fill.opacity
            fillOutlineColor = stroke.color
        }
    }
}

data class LineLayerPaint(
    override var opacity: Float = 1.0f, var stroke: StrokePaint
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.LINE, source, sourceLayer).apply {
            lineColor = stroke.color
            lineOpacity = stroke.opacity
            lineWidth = stroke.thickness
        }
    }
}

data class CircleLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint = FillPaint(),
    var stroke: StrokePaint = StrokePaint(),
    var circle: CirclePaint
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.CIRCLE, source, sourceLayer).apply {
            circleColor = fill.color
            circleOpacity = fill.opacity
            circleRadius = circle.radius
            circleStrokeColor = stroke.color
            circleStrokeOpacity = stroke.opacity
            circleStrokeWidth = stroke.thickness
            circleSortKey = circle.sortKey
        }
    }
}

data class GridLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint? = FillPaint(
        color = StyleValue.Expression(
            Expression.rgb(
                Expression.toNumber(Expression.get("shaderR")),
                Expression.toNumber(Expression.get("shaderG")),
                Expression.toNumber(Expression.get("shaderB")),
            ),
        ),
    ),
    var stroke: StrokePaint? = null,
    var icon: IconPaint = IconPaint(),
    var text: List<TextPaint> = emptyList(),
    /**
     * Gridded / sidecar icon grid: step in **world pixels at zoom 0** (world width = 512px).
     * Consumed by [com.xweather.mapsgl.sources.EncodedGridVectorTileSource]; not emitted in Mapbox Style JSON.
     */
    var grid: GridPaint = GridPaint(spacing = 20.0),
    /**
     * Encoded-field color mapping for gridded/sidecar symbols ([SamplePaint.colorScale], optional [SamplePaint.encodedScalarNormMax]).
     * Not emitted in Mapbox Style JSON.
     */
    var sample: SamplePaint? = null,
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        // If halo thickness is a constant 0.0, omit halo-related style properties.
        // This lets Mapbox avoid extra halo/shader work instead of "drawing" a zero-width halo.
        val strokeThickness = stroke?.thickness
        val strokeThicknessConstant = strokeThickness?.constantValue
        val hasNonZeroHalo =
            stroke != null && (strokeThicknessConstant == null || kotlin.math.abs(strokeThicknessConstant) > 1e-9)

        return StyleJSON(id, StyleJSON.LayerType.SYMBOL, source, sourceLayer).apply {
            iconAllowOverlap = icon.allowOverlap
            iconAnchor = icon.anchor
            iconColor = fill?.color
            if (hasNonZeroHalo) {
                iconHaloColor = stroke?.color
                iconHaloWidth = stroke?.thickness
            }
            iconImage = icon.image
            iconOffset = icon.offset
            iconOpacity = fill?.opacity
            iconPadding = icon.padding
            iconRotate = icon.rotationExpression
            iconSize = icon.iconSize?.let { sz ->
                // Mapbox icon-size ≈ 1.0 for a 40px-tall/wide JS icon; scale linearly with max dimension.
                StyleValue.Constant(
                    (kotlin.math.max(sz.width.toDouble(), sz.height.toDouble()) / IconSize.JS_REFERENCE_WIDTH_PX)
                        .coerceIn(0.05, 8.0),
                )
            } ?: icon.size

            text.firstOrNull()?.let { baseText ->
                textField = if (text.size > 1) {
                    val baseSize = baseText.size?.resolvedValue as? Double ?: 12.0
                    val inputs = text.flatMap {
                        val size = (it.size?.resolvedValue as? Double) ?: 12.0
                        val scale = size / baseSize
                        listOf(
                            it.value to TextFormatOptions(fontScale = scale),
                            StyleValue.Constant("\n") to TextFormatOptions(fontScale = scale)
                        )
                    }
                    StyleValue.Expression(Expression.format(inputs))
                } else {
                    baseText.value
                }
                textAllowOverlap = baseText.allowOverlap
                textAnchor = baseText.anchor
                textColor = baseText.color
                textHaloColor = baseText.outlineColor
                textHaloBlur = StyleValue.Constant(0.5)
                textHaloWidth =
                    if (hasNonZeroHalo) stroke?.thickness ?: StyleValue.Constant(1.0) else StyleValue.Constant(0.0)
                textJustify = baseText.align
                textLetterSpacing = baseText.letterSpacing
                textLineHeight = baseText.lineHeight
                textMaxWidth = baseText.maxWidth
                textOffset = baseText.offset
                textOpacity = baseText.opacity
                textPadding = baseText.padding
                textRotate = baseText.rotation
                textSize = baseText.size
                textTransform = baseText.transform
            }
        }
    }
}

data class HeatmapLayerPaint(
    override var opacity: Float = 1.0f, var heatmap: HeatmapPaint
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.HEATMAP, source, sourceLayer).apply {
            heatmapColor = heatmap.color
            heatmapIntensity = heatmap.intensity
            heatmapRadius = heatmap.radius
            heatmapOpacity = heatmap.weight
        }
    }
}

