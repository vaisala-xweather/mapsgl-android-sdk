package com.xweather.mapsgl.style

import android.graphics.Color as AndroidColor
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.math.floor
import kotlin.math.round

/**
 * CPU-side palette sampling aligned with [EncodedDataRenderer] + VECTOR + COLOR_LOOKUP in
 * [sample.frag.combined.glsl] (normalized speed → draw window → GPU ramp width with shader edge clamp).
 */
internal object EncodedShaderPalette {

    // ReentrantLock, not synchronized: cacheForOptions() is called from per-tile/per-sample
    // rendering hot paths — the small-lock-inside-a-large-method shape that has already caused an
    // R8/ART VerifyError on some devices for a different lock elsewhere in this codebase.
    private val lock = ReentrantLock()

    data class Cache(
        val pixels: IntArray,
        val drawLow: Double,
        val drawHigh: Double,
    )

    fun cacheForOptions(options: ColorScaleOptions): Cache {
        val key = "argb_${options.stops.hashCode()}_${options.range}_${options.interpolate}_${options.interval}_${options.roundDown}"
        return lock.withLock {
            CacheHolder.memo.getOrPut(key) { buildCache(options) }
        }
    }

    fun colorArgb(speed: Double, cache: Cache, vectorNormMax: Double): Int {
        val norm = (speed / vectorNormMax).coerceIn(0.0, 1.0)
        var lutT = (norm - cache.drawLow) / (cache.drawHigh - cache.drawLow)
        if (lutT.isNaN()) lutT = 0.0
        lutT = lutT.coerceIn(0.001, 0.995)
        return sampleLinear(cache.pixels, lutT)
    }

    private fun buildCache(options: ColorScaleOptions): Cache {
        val drawRange = options.range
            ?: (((options.stops.firstOrNull() as? ColorStop)?.value ?: 0.0)..((options.stops.lastOrNull() as? ColorStop)?.value ?: 1.0))
        val table = ColorLookupTable(
            options.stops,
            drawRange,
            options.interpolate,
            options.interval,
            options.roundDown,
        )
        val w = ColorLookupTable.GPU_COLOR_LUT_WIDTH
        val bitmap = table.createColorLookupBitmap(w, 1)
        val pixels = IntArray(w)
        bitmap.getPixels(pixels, 0, w, 0, 0, w, 1)
        bitmap.recycle()

        val fullRange = table.initialStops.last().value - table.initialStops.first().value
        val (drawLow, drawHigh) = if (fullRange <= 0.0 || table.filteredStops.isEmpty()) {
            0.0 to 1.0
        } else {
            val low = ((table.filteredStops.first().value - table.initialStops.first().value) / fullRange)
            val high = (1.0 - ((table.initialStops.last().value - table.filteredStops.last().value) / fullRange))
            low to high
        }
        return Cache(pixels, drawLow, drawHigh)
    }

    private fun sampleLinear(pixels: IntArray, u: Double): Int {
        val maxIdx = pixels.size - 1
        if (maxIdx <= 0) return pixels[0]
        val x = u * maxIdx.toDouble()
        val i0 = floor(x).toInt().coerceIn(0, maxIdx - 1)
        val i1 = (i0 + 1).coerceIn(0, maxIdx)
        val t = (x - i0).coerceIn(0.0, 1.0)
        val c0 = pixels[i0]
        val c1 = pixels[i1]
        val a = AndroidColor.alpha(c0) + t * (AndroidColor.alpha(c1) - AndroidColor.alpha(c0))
        val r = AndroidColor.red(c0) + t * (AndroidColor.red(c1) - AndroidColor.red(c0))
        val g = AndroidColor.green(c0) + t * (AndroidColor.green(c1) - AndroidColor.green(c0))
        val b = AndroidColor.blue(c0) + t * (AndroidColor.blue(c1) - AndroidColor.blue(c0))
        return AndroidColor.argb(
            round(a).toInt(),
            round(r).toInt(),
            round(g).toInt(),
            round(b).toInt(),
        )
    }

    private object CacheHolder {
        val memo = java.util.concurrent.ConcurrentHashMap<String, Cache>()
    }
}
