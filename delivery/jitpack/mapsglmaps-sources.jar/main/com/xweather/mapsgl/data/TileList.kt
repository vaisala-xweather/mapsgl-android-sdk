package com.xweather.mapsgl.data

import com.xweather.mapsgl.anim.Timeline
import java.util.Timer
import java.util.TimerTask


class TileList {
    companion object {
        val requestedList: LayerTileList = LayerTileList("requested")
        val pendingList: LayerTileList = LayerTileList("pending", true)
        val failedList: LayerTileList = LayerTileList("failed")
        val readyList: LayerTileList = LayerTileList("ready")

        /**
         * Wipe per-source tile bookkeeping so a freshly created [com.xweather.mapsgl.map.MapController]
         * doesn't see entries from a previous controller's sources. Without this, when a new
         * controller is created with the same source IDs as a previous one, the "ready" list still
         * has entries pointing at the dead controller's tile objects and the "pending" list still
         * has in-flight downloads that will never complete (the prior controller's coroutines may
         * have been cancelled).
         */
        fun resetForNewController() {
            requestedList.layers.clear()
            pendingList.layers.clear()
            failedList.layers.clear()
            readyList.layers.clear()
        }

        /** Drops all tile bookkeeping for [sourceId] when a [com.xweather.mapsgl.map.MapController] is destroyed. */
        fun purgeSourceFromAllLists(sourceId: String) {
            requestedList.purgeLayer(sourceId)
            pendingList.purgeLayer(sourceId)
            failedList.purgeLayer(sourceId)
            readyList.purgeLayer(sourceId)
        }

        /** Drops encoded-tile bookkeeping for a weather layer id (e.g. demo teardown). */
        fun purgeLayerFromAllLists(layerId: String) {
            purgeSourceFromAllLists(layerId)
        }
    }
}


class LayerTileList(val listId: String = "unNamedList", val setListener: Boolean = false) {


    interface TileListListener {
        fun onListStarted()   // Triggered when count goes from 0 to 1
        fun onListEmpty()     // Triggered when count goes from 1 to 0
        fun onSubListEmpty(layerId: String)  // Triggered when a layerList is empty
        fun onTick()
    }

    private var timer: Timer? = null


    /**
     * Starts a repeating task that runs every 500ms
     */
    private fun startRepeatingTrigger() {
        if (timer != null) return // Already running

        timer = Timer()
        timer?.schedule(object : TimerTask() {
            override fun run() {
                // This runs on a background thread
                listener?.onTick()
            }
        }, 0, 500) // 0 delay, 500ms period
    }

    /**
     * Stops the repeating task
     */
    private fun stopRepeatingTrigger() {
        timer?.cancel()
        timer = null
    }

    /** Pauses the 500ms pending-download poll while the map is in the background. */
    fun pauseBackgroundPolling() {
        stopRepeatingTrigger()
    }

    /** Restarts the poll if pending encoded tiles remain after returning to the foreground. */
    fun resumeBackgroundPollingIfNeeded() {
        if (!setListener) return
        synchronized(this) {
            if (countAllEntriesUnsynced() > 0) {
                startRepeatingTrigger()
            }
        }
    }


    var listener: TileListListener? = null
    var initialCount = 0

    // A small container to hold the ISO time string and the system timestamp
    data class DownloadEntry(
        val timeString: String,
        val sessionId: Long = Timeline.mapSessionId,
        val timestamp: Long = System.currentTimeMillis(),
    )

    // The top-level map: Key = LayerID, Value = LayerData
    val layers: HashMap<String, LayerData> = hashMapOf()

    class LayerData(val layerId: String) {
        // Updated: Value is now a list of DownloadEntry instead of just String
        val tiles: HashMap<String, MutableList<DownloadEntry>> = hashMapOf()
    }

    /**
     * Helper function to safely add a time to a specific tile in a specific layer.
     * The timestamp is automatically generated via the DownloadEntry default value.
     */
    fun add(layerId: String, tileHash: String, timeString: String, sessionId: Long = Timeline.mapSessionId) {
        synchronized(this) {
            if (setListener) {
                initialCount = countAllEntriesUnsynced() // Check count before adding
            }

            val layer = layers.getOrPut(layerId) { LayerData(layerId) }
            val entryList = layer.tiles.getOrPut(tileHash) { mutableListOf() }

            // Check if the timeString already exists in our entries
            if (entryList.none { it.timeString == timeString && it.sessionId == sessionId }) {
                entryList.add(DownloadEntry(timeString, sessionId))
            }

            if (setListener && initialCount == 0 && countAllEntriesUnsynced() > 0) {
                startRepeatingTrigger() // <--- START TIMER HERE
                listener?.onListStarted()
            }
        }
    }

    fun remove(layerId: String, tileHash: String, timeString: String) {
        synchronized(this) {
            val layer = layers[layerId]
            val entryList = layer?.tiles?.get(tileHash)
            if (layer != null && entryList != null) {
                // Remove the entry matching the string
                entryList.removeAll { it.timeString == timeString }

                // Cleanup: If no more entries for this tile, remove the tile entry
                if (entryList.isEmpty()) {
                    layer.tiles.remove(tileHash)
                }

                // Cleanup: If no more tiles for this layer, remove the layer entry
                if (layer.tiles.isEmpty()) {
                    layers.remove(layerId)
                    listener?.onSubListEmpty(layerId)
                }

                // If the list just became completely empty, trigger listener
                if (setListener && countAllEntriesUnsynced() == 0 && layers.isEmpty()) {
                    stopRepeatingTrigger() // <--- STOP TIMER HERE
                    listener?.onListEmpty()
                }
            }
        }
    }

    /**
     * Returns the total count of all entries (time strings) across all layers and all tiles.
     * This represents the global size of the list.
     */
    /**
     * Must be called only while holding [this] monitor (same as all other [layers] access).
     */
    private fun countAllEntriesUnsynced(): Int {
        var total = 0
        layers.values.forEach { layer ->
            layer.tiles.values.forEach { entryList ->
                total += entryList.size
            }
        }
        return total
    }

    fun countAllEntries(): Int {
        return synchronized(this) {
            countAllEntriesUnsynced()
        }
    }

    /**
     * Returns the total count of unique tiles currently tracked for a specific layer.
     */
    fun countTilesInLayer(layerId: String): Int {
        return layers[layerId]?.tiles?.size ?: 0
    }

    /**
     * Returns the total count of all time strings across all tiles in a specific layer.
     */
    fun countAllTimesInLayer(layerId: String): Int {
        return synchronized(this) {
            val layer = layers[layerId]
            var total = 0
            layer?.tiles?.values?.forEach { entryList ->
                total += entryList.size
            }
            total
        }
    }

    /**
     * Returns true if [timeString] is still present in the pending list for [layerId].
     * This is used to avoid animating into incomplete intervals.
     */
    fun containsTimeInLayer(layerId: String, timeString: String): Boolean {
        return synchronized(this) {
            val layer = layers[layerId]
            val session = Timeline.mapSessionId
            layer != null && layer.tiles.values.any { entryList ->
                entryList.any { it.timeString == timeString && it.sessionId == session }
            }
        }
    }

    /**
     * Returns true if [timeString] is still present in the pending list for the specific
     * [tileHash] within [layerId].
     *
     * This is intentionally tile-specific (not just "any tile in the layer") so callers can
     * decide whether to freeze animation based on what is currently visible.
     */
    fun containsTimeInTile(layerId: String, tileHash: String, timeString: String): Boolean {
        return synchronized(this) {
            val entryList = layers[layerId]?.tiles?.get(tileHash)
            val session = Timeline.mapSessionId
            entryList != null && entryList.any { it.timeString == timeString && it.sessionId == session }
        }
    }

    fun purgeLayer(layerId: String) {
        synchronized(this) {
            layers.remove(layerId)
        }
    }

    fun printAll() {
        synchronized(this) {
            if (layers.isEmpty()) {
                println(">> $listId list is empty.")
            } else {
                layers.forEach { (layerId, layerData) ->
                    println(">> Layer: $layerId")
                    layerData.tiles.forEach { (tileHash, entries) ->
                        println(">>   └── Tile: $tileHash")
                        entries.forEach { entry ->
                            println(">>       └── Time: ${entry.timeString} (Added at: ${entry.timestamp})")
                        }
                    }
                }
                println(">> $listId count: ${countAllEntriesUnsynced()}")
            }
        }
    }
}