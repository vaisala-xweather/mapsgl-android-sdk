package com.xweather.mapsgl.sources

import android.provider.ContactsContract
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.coordinates.LatLonBounds
import com.xweather.mapsgl.error.AuthenticationError
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.EventSource
import com.xweather.mapsgl.geo.Projection
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.utils.convertToDates
import com.xweather.mapsgl.utils.reduceDatesToRange
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.logging.Logger

open class SourceMetadataSchema {
    var tileSize: TileSize = TileSize(256)
    var minZoom: Float = 0.0f
    var maxZoom: Float = 21.0f
    var bounds: LatLonBounds? = null
    var projection: Projection
        get() = TODO("Not yet implemented")
        set(value) {}
    var validTimes: MutableList<Date> = mutableListOf()
    var validTimesString: String = ""
    var datasets: List<DatasetType> = emptyList()

    var minZooms = floatArrayOf(0.0f, 0.0f, 0.0f)
    var maxZooms = floatArrayOf(0.0f, 0.0f, 0.0f)
    var validTimesStrings: MutableList<String> = mutableListOf()

    /** Valid start time for a time-series data source, if any.   */
    lateinit var startDate: Date

    /** Valid end time for a time-series data source, if any.   */
    lateinit var endDate: Date
}

/**
 *  SourceMetadata.kt
 *
 *  Based on the IOS version
 * @author Jason Suto 01/08/24
 */
class SourceMetadata<DataType>(data: DataType/*TileSource<TileData>*/, url: URL?) :
    EventSource where DataType : SourceMetadataSchema {
    /** For time-specific data sources, the maximum number of time intervals allowed for the data's time
     * series. A value of `0` means no limit and will allow the full set of valid times.    */
    private var maxValidTimeIntervals = 0
    private val TAG = "SourceMetadata"
    override val eventDispatcher = EventDispatcher()
    var url: URL? = null
    var data: /*TileSource<TileData>*/DataType
    var parameters: MutableMap<String, String> = mutableMapOf()
    var isLoading: Boolean = false
    var hasLoaded: Boolean = false
    var decode: ((metadata: DataType, jsonData: ContactsContract.Contacts.Data) -> DataType)? = null

    //private var loadingTask: Task/*<ContactsContract.Contacts.Data,  Error<Any>>?*/? = null
    lateinit var _data: DataType
    var noData: Int? = null

    var success = false
    private var hasLoadedMetadata: Boolean = false
    private var metadataLoadingTask: Deferred<Any>? = null

    init {
        this.url = url
        this.data = data
    }

    /** Returns an array of valid times for the source. If the source has multiple datasets, the valid times
     * for the first dataset will be returned.
     * @param max - The maximum number of valid times to return. A value of `0` means no limit and will return
     * all valid times.
     * @returns An array of valid times for the source.     */
    fun getValidTimes(index: Int = 0, max: Int = maxValidTimeIntervals): List<Date> {
        return getDatasetValidTimesAtIndex(index, max)
    }

    /**
     * Returns the valid times for the dataset at the provided index.
     * @param index - The dataset index
     * @param max - The maximum number of valid times to return. A value of `0` means no limit and will return
     * all valid times.
     * @returns An array of valid times for the dataset.
     */
    fun getDatasetValidTimesAtIndex(index: Int, max: Int = maxValidTimeIntervals): List<Date> {
        val validTimes = data.validTimes

        if ((validTimes.isEmpty())) return emptyList()

        val times: List<Any> = if (validTimes?.firstOrNull() is List<*>) {
            (validTimes[index] as? List<Any>) ?: emptyList()
        } else {
            validTimes
        }
        var dates: List<Date> = convertToDates(times)

        if (max > 0 && times.size > max) {
            dates = reduceDatesToRange(dates, data.startDate, data.endDate, max)
        }

        return dates
    }

    suspend fun load(request: URLRequest, layerId: String, sourceId: String): Boolean {
        //if (hasLoadedMetadata) return true
        // Added to keep looking for metadata if user is offline during this function. Issue 9
        var loadingErrors = false

        // Timeline range changes update start/end and must re-fetch; joining an in-flight load
        // with the previous URL left layer valid times covering only the old range.
        metadataLoadingTask?.let { inFlight ->
            inFlight.cancel()
            runCatching { inFlight.join() }
            metadataLoadingTask = null
        }

        metadataLoadingTask = CoroutineScope(Dispatchers.IO).async {
            try {
                val response = request.execute()
                //print("METADATA loaded")
                when (response.data) {
                    is JSONObject -> {
                        val json = response.data
                        val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)

                        val allMinZooms = mutableListOf<Float>()
                        val allMaxZooms = mutableListOf<Float>()
                        val validTimeStrings = mutableListOf<String>()
                        val layerTimes = Timeline.sourceTimeHash[sourceId]
                        val isRadar = sourceId == ("radar_REFC_PRATE_PTYPESMPL")

                        if (isRadar) {
                            val keysIterator = json.keys()
                            if (keysIterator.hasNext()) {
                                val key = keysIterator.next()
                                val entry = json.getJSONObject(key)
                                val originalTimes = entry.getJSONArray("validTimes")

                                /*
                                for (i in 0 until originalTimes.length()) {
                                    println(">> SourceMetaData load() | key: $key Time at index $i: ${originalTimes.getString(i)}")
                                }
                                */

                                val times = mutableListOf<String>()

                                for (i in 0 until originalTimes.length()) {
                                    times.add(originalTimes.getString(i))
                                }

                                val filteredTimes = if (isRadar) {
                                    times.filter { it.endsWith(":00:00+00:00") }
                                } else {
                                    times
                                }

                                //println(">> SourceMetaData load() filteredTimes: ${filteredTimes}")

                                val validTimes: MutableList<Date> = mutableListOf()

                                for (i in 0 until filteredTimes.size) {
                                    val dateStr = filteredTimes[i]
                                    val truncatedDateStr = dateStr.replace("+00:00", "Z")
                                    dateFormat.parse(dateStr)?.let {
                                        validTimes.add(it)
                                        //layerTimes?.timeDates?.add(it)
                                    }

                                    validTimeStrings.add(truncatedDateStr)
                                }

                                if (layerTimes != null) {

                                    if (pr.ON) pr.p(
                                        TAG, pr.layerMetadata, "load() updating layerTimes for $layerId to $validTimes"
                                    )

                                    // LayerTimeline mutations (timeDates, timeStrings, timeLongs,
                                    // sparseTimeLongs/Strings via onValidTimesUpdated) must happen on
                                    // the main thread. Mutating sparseTimeLongs from this IO coroutine
                                    // while the main thread reads it in computeGlobalAnimationTarget()
                                    // caused a NoSuchElementException crash on .first().
                                    val resolvedTimes = validTimes
                                    withContext(Dispatchers.Main) {
                                        layerTimes.timeDates = resolvedTimes
                                        Timeline.datesToStringsAndLongs(sourceId)
                                    }
                                }

                                if (entry.has("minZoom")) {
                                    val minZoom = entry.optDouble("minZoom", -1.0).toFloat()
                                    if (minZoom >= 0) {
                                        allMinZooms.add(minZoom)
                                    }
                                }
                                if (entry.has("maxZoom")) {
                                    val maxZoom = entry.optDouble("maxZoom", -1.0).toFloat()
                                    if (maxZoom >= 0) {
                                        allMaxZooms.add(maxZoom)
                                    }
                                }

                                data.validTimes = validTimes
                            }
                        } else {
                            //println(">> SourceMetaData load() | the key========================================")
                            for (key in json.keys()) {
                                val entry = json.getJSONObject(key)

                                val originalTimes = entry.getJSONArray("validTimes")
                                val times = mutableListOf<String>()

                                for (i in 0 until originalTimes.length()) {
                                    times.add(originalTimes.getString(i))
                                }

                                val filteredTimes = if (isRadar) {
                                    times.filter { it.endsWith(":00:00+00:00") || it.endsWith(":00:00Z") }
                                } else {
                                    times
                                }

                                val validTimes: MutableList<Date> = mutableListOf()

                                for (i in 0 until filteredTimes.size) {
                                    val dateStr = filteredTimes[i]
                                    val truncatedDateStr = dateStr.replace("+00:00", "Z")
                                    dateFormat.parse(dateStr)?.let {
                                        validTimes.add(it)
                                        //layerTimes?.timeDates?.add(it)
                                    }

                                    validTimeStrings.add(truncatedDateStr)
                                }

                                if (layerTimes != null) {

                                    if (pr.ON) pr.p(
                                        TAG, pr.layerMetadata, "load() updating layerTimes for $layerId to $validTimes"
                                    )

                                    val resolvedTimes = validTimes
                                    withContext(Dispatchers.Main) {
                                        layerTimes.timeDates = resolvedTimes
                                        Timeline.datesToStringsAndLongs(sourceId)
                                    }
                                }

                                if (entry.has("minZoom")) {
                                    val minZoom = entry.optDouble("minZoom", -1.0).toFloat()
                                    if (minZoom >= 0) {
                                        allMinZooms.add(minZoom)
                                    }
                                }
                                if (entry.has("maxZoom")) {
                                    val maxZoom = entry.optDouble("maxZoom", -1.0).toFloat()
                                    if (maxZoom >= 0) {
                                        allMaxZooms.add(maxZoom)
                                    }
                                }

                                data.validTimes = validTimes

                                //println(">> SourceMetaData load() | the key: $key #: ${validTimes.size} 1st: ${validTimes[0]}   last: ${validTimes[validTimes.size - 1]}")
                            }
                        }

                        if (allMinZooms.isNotEmpty()) {
                            data.minZoom = allMinZooms.minOrNull() ?: 0f
                        }
                        if (allMaxZooms.isNotEmpty()) {
                            data.maxZoom = allMaxZooms.maxOrNull() ?: 21f
                        }
                        data.minZooms = allMinZooms.toFloatArray()
                        data.maxZooms = allMaxZooms.toFloatArray()

                        Timeline.validTimesList[layerId] = validTimeStrings  //TODO: see if validTimesList is redundant
                    }
                }
            } catch (e: AuthenticationError) {
                if (e.statusCode == 401) {
                    Logger.getGlobal().severe("Authentication error")
                    throw AuthenticationError(401, "")
                } else {
                    Logger.getGlobal().severe("Unexpected auth error: $e")
                    throw e
                }
            } catch (e: Exception) {
                Logger.getGlobal().severe("Metadata load failed: $e")
                //throw e
                loadingErrors = true
            } finally {
                //println("METADATA loaded")
                hasLoadedMetadata = !loadingErrors
                metadataLoadingTask = null
            }

            if (pr.ON) pr.p(
                TAG, pr.fetchMeta, "load() metaDataLoaded finished for ${layerId} ${data.startDate} to ${data.endDate}"
            )
        }
        metadataLoadingTask!!.await()

        return !loadingErrors
    }
}