package com.xweather.mapsgl.sources

import VariableObserver
import com.mapbox.geojson.Feature
import com.mapbox.geojson.MultiPolygon
import com.mapbox.geojson.Point
import com.mapbox.geojson.Polygon
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.error.AuthenticationError
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.mapbox.GlStencilOsm
import com.xweather.mapsgl.map.mapbox.MapboxVectorFeature
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import com.xweather.mapsgl.map.mapbox.hasWaterStencilMvtTagInFeatures
import com.xweather.mapsgl.sources.utils.FeatureCluster
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.Headers
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.utils.formatDateArrayToString
import com.xweather.mapsgl.utils.replaceVars
import com.xweather.mapsgl.utils.toDate
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import no.ecc.vectortile.VectorTileDecoder
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.logging.Logger
import kotlin.math.max
import kotlin.math.min


class VectorData(
    val validTime: Date,
    val features: MutableList<Feature>
) : TileData {
    override fun init(byteArrayOf: ByteArray) {
        TODO("Not yet implemented")
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is VectorData) return false
        return this.hashCode() == other.hashCode()
    }

    override fun hashCode(): Int {
        // You can customize this to suit your hash requirements.
        // For now, just combine validTime and features size as an example:
        return 31 * validTime.hashCode() + features.hashCode()
    }
}

// TODO: move this into a source transformer
data class XweatherVectorLayerMetadata(
    var layers: List<Layer>,
    var validTimes: List<Date>
) {
    data class Layer(
        val name: String,
        val minZoom: Int,
        val maxZoom: Int,
        val fields: List<String>?
    )
}

/**
 * Runtime vector tile source created by [com.xweather.mapsgl.map.MapController.addSource] when using
 * [com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor]. Obtain via [com.xweather.mapsgl.map.MapController.getSource]
 * and cast to this type to change [TileSource.tileURL], [TileSource.minZoom] / [TileSource.maxZoom], or refresh tiles.
 */
open class VectorTileSource(override val id: String, open var authenticator: XweatherAuthenticator? = null) :
    TileSource<VectorData>() {
    private companion object {
        // Comma-separated "z/x/y" tiles to trace stencil pipeline end-to-end.
        private const val MASK_DEBUG_TARGETS = "6/19/21,6/19/22,6/20/21,6/20/22,6/19/23,6/20/23"
    }

    private val TAG = "VectorTileSource"

    //override var tileManager: /*TileRequestManager<VectorData> = TileRequestManager(this as TileSource<TileData>)
    override var timeRange: ClosedRange<Date>? = null
    var dlCount = 0
    var validTimes: List<Date>? = null
    var validTime: Date = Date()
    val consumers: MutableList<DataSourceConsumer> = mutableListOf()
    private val consumedLayers: MutableMap<String, Int> = mutableMapOf()

    override var tileCache: TileCache<DataType> = TileCache()

    // TODO("Temporary vectorTileCache until base TileSource can be cleaned up")
    protected val vectorTileCache: TileCache<VectorData> = TileCache()
    private val dateFormatter: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault())
    val metadataObserver = VariableObserver()
    private var hadLoadedMetadata = false
    private var metadataLoadingTask: Deferred<Any>? = null

    private var invalidateFunction: ((Int, Int, Int) -> Unit)? = null
    private var batchInvalidateFunction: ((List<Triple<Int, Int, Int>>) -> Unit)? = null
    private var decoder: VectorTileDecoder = VectorTileDecoder()

    /**
     * When set (GL stencil mask mode), invoked on the tile decode thread after each successful MVT parse
     * with the same [TileCoord] / coord-hash key used by encoded raster meshes.
     */
    var glStencilMaskTileListener: ((coord: TileCoord, coordHash: String, features: List<Feature>) -> Unit)? = null

    /**
     * Ensures [parseVectorTile] includes [sourceLayerTag] in decoded MVT layers (refcounted).
     * @return Undo closure; call when the dependency is removed.
     */
    fun addStencilParseLayerDependency(sourceLayerTag: String): () -> Unit {
        stencilParseExtraLayers.merge(sourceLayerTag, 1, Int::plus)
        invalidate()
        return {
            stencilParseExtraLayers.computeIfPresent(sourceLayerTag) { _, c ->
                (c - 1).takeIf { it > 0 }
            }
            invalidate()
        }
    }

    /**
     * Invoked on the tile decode thread after each successful parse, after [glStencilMaskTileListener].
     */
    fun addCustomStencilTileListener(
        listenerId: String,
        listener: (coord: TileCoord, coordHash: String, features: List<Feature>) -> Unit,
    ): () -> Unit {
        customStencilTileListeners[listenerId] = listener
        invalidate()
        return {
            customStencilTileListeners.remove(listenerId)
            invalidate()
        }
    }

    /**
     * Swap the current listener for [listenerId] without calling [invalidate]. Use when the spec a
     * weather layer cares about is unchanged but a captured value inside the listener (e.g. a line
     * mask's `lineHalfWidth` / `lineStyle`) has been updated — we want the next replay through the
     * listener to pick up the new closure without forcing Mapbox to re-fetch and re-decode every
     * cached MVT tile, which is the expensive path that [invalidate] triggers.
     *
     * The caller is responsible for replaying cached features (see
     * [replayCustomStencilFeedsFromCachedVectorTiles]) so existing cache entries get rebuilt.
     */
    internal fun replaceCustomStencilTileListenerWithoutInvalidate(
        listenerId: String,
        listener: (coord: TileCoord, coordHash: String, features: List<Feature>) -> Unit,
    ) {
        customStencilTileListeners[listenerId] = listener
    }

    /**
     * Number of vector tiles currently held in [vectorTileCache]; debug-only.
     *
     * Reads `LRUCache.size` directly (a `HashMap.size` field read, O(1)) instead of
     * `.entries().count()`. The latter walks the LRU's internal doubly-linked list lazily, which
     * deadlocks indefinitely if any other thread does a [LRUCache.get] mid-iteration: that `get`
     * calls `_bumpAge` → `_list.unshiftNode`, which moves the just-visited node to the head, so
     * the iterator's `current.next` points back into already-visited territory and the loop never
     * terminates. We saw this hang inside [GlStencilCustomMaskCoordinator.refreshPaint] between
     * its `listeners swapped` and `replay source=` log lines — the count call was wedged while
     * cached tile feeds bumped LRU nodes from the listener side. The same class of bug was
     * already patched in [replayCustomStencilFeedsFromCachedVectorTiles] /
     * [replayGlStencilFeedsFromCachedVectorTiles] by snapshotting, but the count call here was
     * missed because `.count()` on a Sequence looks like a one-shot value, not an iteration.
     */
    internal fun cachedVectorTileCount(): Int = vectorTileCache.tiles.size
    /**
     * Reparse attempts for cached tiles that still lack `water` features while stencil masking is active.
     * A single attempt is not always enough when a stale/corrupt response was cached.
     */
    private val stencilInclusionReparseAttempts = ConcurrentHashMap<String, Int>()
    private val maxStencilInclusionReparseAttempts = 3

    /**
     * Extra MVT source-layer names to parse so GLES custom stencil masks receive features even when no
     * style consumer references that layer.
     */
    private val stencilParseExtraLayers = ConcurrentHashMap<String, Int>()
    private val customStencilTileListeners =
        ConcurrentHashMap<String, (TileCoord, String, List<Feature>) -> Unit>()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var isAdminSource = false
    private val useTimelessStencilMaskKeys: Boolean
        get() = id == GlStencilOsm.SOURCE_ID

    private fun maskDebugMatches(z: Int, x: Int, y: Int): Boolean {
        if (MASK_DEBUG_TARGETS.isEmpty()) return false
        val key = "$z/$x/$y"
        return MASK_DEBUG_TARGETS.split(',').any { it.trim() == key }
    }

    init {
        metadata = SourceMetadata(
            ImageTileSource.MetadataSchema(), URL(
                mapsGLServer
            )
        )

        tileManager = TileRequestManager(this as TileSource<TileData>)
    }

    override fun getMetadataURL(): URL? {
        val url = metadataURL ?: return null
        val variables = emptyMap<String, Any>().toMutableMap()
        timeRange?.let {
            variables.set("startDate", it.start)
            variables.set("endDate", it.endInclusive)
        }
        authenticator?.appendTileCredentialVariables(variables)
        val urlString = url.replaceVars(variables, true)

        return URL(urlString)
    }

    override fun appendTileUrlVariables(coord: TileCoord, vars: MutableMap<String, Any>) {
        authenticator?.appendTileCredentialVariables(vars)
    }

    override suspend fun fetchMetadata(startDate: Date?, endDate: Date?): Result<Unit> {
        val reload = false
        if (hadLoadedMetadata && !reload) return Result.success(Unit)

        authenticator?.authenticate()

        val url =
            getMetadataURL() ?: return Result.failure(IllegalStateException("Metadata URL could not be generated."))

        if (metadataLoadingTask != null) {
            try {
                metadataLoadingTask!!.join()
            } catch (e: Exception) {
                MapsGLDebug.trace("Metadata loading task failed: ${e.localizedMessage}")
                return Result.failure(IllegalStateException(e.localizedMessage))
            }
            // return
        }

        metadataLoadingTask = CoroutineScope(Dispatchers.IO).async {
            val request = URLRequest(url.toString())

            authenticator?.credentials?.let { credentials ->
                request.setAuthorization("Bearer ${credentials.accessToken}")
            }

            try {
                val response = request.execute()
                when (response.data) {
                    is JSONObject -> {
                        val json = response.data
                        if (json.keys().hasNext()) {
                            val dataKey = json.keys().next()
                            json.optJSONObject(dataKey)?.let {
                                val layers = emptyList<XweatherVectorLayerMetadata.Layer>().toMutableList()
                                val validTimes = emptyList<Date>().toMutableList()

                                it.optJSONArray("layers")?.let {
                                    for (i in 0 until it.length()) {
                                        val item = it.getJSONObject(i)
                                        val name = item.getString("name")

                                        val minZoom = if (item.has("minZoom")) {
                                            item.getInt("minZoom")
                                        } else {
                                            0
                                        }

                                        val maxZoom = if (item.has("maxZoom")) {
                                            item.getInt("maxZoom")
                                        } else {
                                            21
                                        }

                                        val fields = if (item.has("fields")) {
                                            val fieldsList = mutableListOf<String>()
                                            val fieldsArray = item.optJSONArray("fields")
                                            if (fieldsArray != null) {
                                                for (j in 0 until fieldsArray.length()) {
                                                    fieldsList.add(fieldsArray.optString(j))
                                                }
                                            }
                                            fieldsList
                                        } else {
                                            emptyList()
                                        }

                                        val layer = XweatherVectorLayerMetadata.Layer(
                                            name,
                                            minZoom,
                                            maxZoom,
                                            fields
                                        )
                                        layers.add(layer)
                                    }
                                }
                                // Parse validTimes array into List<Date>
                                it.optJSONArray("validTimes")?.let { validTimesArray ->
                                    val dateFormat =
                                        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
                                    for (i in 0 until validTimesArray.length()) {
                                        val dateStr = validTimesArray.optString(i)
                                        try {
                                            val date = dateFormat.parse(dateStr)
                                            if (date != null) validTimes.add(date)
                                        } catch (e: Exception) {
                                            // Optionally log or handle parse error
                                        }
                                    }
                                }
                                isAdminSource = true
                                val metadata = XweatherVectorLayerMetadata(layers, validTimes)
                                minZoom = metadata.layers.first().minZoom.toFloat()
                                maxZoom = metadata.layers.first().maxZoom.toFloat()
                            }
                        }
                        hadLoadedMetadata = true
                    }
                }
            } catch (e: AuthenticationError) {
                if (e.statusCode == 401) {
                    Logger.getGlobal().severe("Authentication error")
                    throw AuthenticationError(401, "")
                } else {
                    Logger.getGlobal().severe("Unexpected auth error: $e")
                    throw e
                }
            } catch (e: Exception) {
                Logger.getGlobal().severe("Metadata load failed: $e")
                throw e
            } finally {
                metadataLoadingTask = null
            }
        }

        metadataLoadingTask!!.await()
        return Result.success(Unit)
    }

    override fun getTileData(coord: TileCoord): Any? {
        val tile = this.vectorTileCache.tiles[coord.hash()]
        return tile?.data;
    }

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?,
        trackDownloadProgress: Boolean,
    ): Any {
        return 0
    }

    open suspend fun requestTile(
        x: Int,
        y: Int,
        z: Int,
        mapZoomForDensity: Double? = null,
        visibleGeoBounds: VisibleGeoBounds? = null,
    ): VectorData? {
        val debugMaskTile = useTimelessStencilMaskKeys && maskDebugMatches(z, x, y)
        val validTimeStr2 = if (useTimelessStencilMaskKeys) "" else formatDateArrayToString(listOf(validTime))
        val coord = TileCoord(x, y, z, 0, validTimeStr2)

        var reload = false
        val existing = getTileData(coord)
        val existingTile = tileCache.get(coord)

        if (existing != null && existing is VectorData && existingTile?.state !== TileState.Expired) {
            if (false && existing.validTime != validTime) {
//                options.reload = true
                reload = true
            } else {
                // Stale/corrupt: parse may have missed `water` layer features, so GLES stencil has no CPU mesh.
                // Retry a few times by expiring cached tile and forcing parse with current consumers.
                if (glStencilMaskTileListener != null &&
                    !hasWaterStencilMvtTagInFeatures(existing.features)
                ) {
                    val key = coord.hash()
                    val attempts = stencilInclusionReparseAttempts.getOrDefault(key, 0)
                    if (attempts < maxStencilInclusionReparseAttempts) {
                        stencilInclusionReparseAttempts[key] = attempts + 1
                        MapsGLDebug.trace(
                            "[GlStencilMask] base.osm cache missing water features; expiring tile for reparse " +
                                "attempt ${attempts + 1}/$maxStencilInclusionReparseAttempts: $key",
                        )
                        existingTile?.state = TileState.Expired
                        vectorTileCache[coord]?.let { t ->
                            t.state = TileState.Expired
                            vectorTileCache.setStale(true, t)
                        }
                        // Fall through: download + parse
                    } else {
                        // Tile data already exists in cache, just return it
                        feedGlStencilMaskFromVectorCache(coord, existing)
                        return existing
                    }
                } else {
                    if (glStencilMaskTileListener != null && hasWaterStencilMvtTagInFeatures(existing.features)) {
                        stencilInclusionReparseAttempts.remove(coord.hash())
                    }
                    // Tile data already exists in cache, just return it
                    feedGlStencilMaskFromVectorCache(coord, existing)
                    return existing
                }
            }
        }

        // Keep URL placeholders satisfied for sources that require `{time::iso}` in the path,
        // but keep stencil cache keys timeless via empty coord.time.
        val url = makeTileURL(coord, mutableMapOf("time" to validTime))
        if (debugMaskTile) {
            MapsGLDebug.trace("[MaskDebug][Fetch] requestTile start key=${z}/${x}/${y} url=$url")
        }
        val urlRequest = URLRequest(url.toString())
        authenticator?.credentials?.let { credentials ->
            urlRequest.setAuthorization("Bearer ${credentials.accessToken}")
        }

        if (vectorTileCache.pendingCount == 0) {
            trigger(DataSourceEvents.LoadStart(sourceID = id))
            _shouldTriggerLoadCompleteEvent = true
        }

        val validTimeStr = if (useTimelessStencilMaskKeys) "" else formatDateArrayToString(listOf(validTime))
        coord.time = validTimeStr
        val tile = vectorTileCache[coord] ?: Tile<VectorData>(coord).also { newTile ->
            newTile.time = validTimeStr
            newTile.coordHash = coord.hash()
            vectorTileCache.updateTile(newTile, coord)
        }

        vectorTileCache.setPending(true, tile)
        tile.state = TileState.Loading
        //trigger(DataSourceEvents.TileLoadStart(id, null))

        val tileResponse = try {
            tileManager.loadTile(coord, urlRequest /*, options*/)
        } catch (e: Exception) {
            if (debugMaskTile) {
                MapsGLDebug.trace("[MaskDebug][Fetch] requestTile error key=${z}/${x}/${y} err=${e.message}")
            }
            Logger.getGlobal().warning("Failed to load tile $coord: ${e.message}")
            return null
        }

        tile.state = TileState.Ready
        val tileData = tileResponse?.data as ByteArray?

        tileData?.let {
            if (debugMaskTile) {
                MapsGLDebug.trace("[MaskDebug][Fetch] response bytes key=${z}/${x}/${y} size=${tileData.size}")
            }
            // Needs to be concurrent
            val deferred = scope.async(Dispatchers.Default) {
                parseVectorTile(tile, tileData, validTime, headers = tileResponse?.headers)
            }
            val result = deferred.await()
            tile.data = result
            tileCache.tiles[coord.hash()] = tile as Tile<DataType>
            //trigger(DataSourceEvents.LoadComplete(id))
            return result

        }
        if (debugMaskTile) {
            MapsGLDebug.trace("[MaskDebug][Fetch] no tileData key=${z}/${x}/${y}")
        }
        return null
    }

    fun abortTile(x: Int, y: Int, z: Int) {
        val coord = TileCoord(x, y, z)
//        abortTile(coord)
    }

    open fun invalidate() {
        stencilInclusionReparseAttempts.clear()
        // Expire synchronously so a concurrent Mapbox fetch cannot return cached Ready tiles before
        // per-tile Mapbox invalidation is scheduled (remove/re-add same source id).
        val keys = (tileCache.keys + vectorTileCache.keys).distinct()
        for (key in keys) {
            val coord = TileCoord.fromHash(key) ?: continue
            vectorTileCache[coord]?.let { t ->
                t.state = TileState.Expired
                vectorTileCache.setStale(true, t)
            }
            tileCache[coord]?.let { t ->
                t.state = TileState.Expired
                tileCache.setStale(true, t)
            }
        }
        scope.launch {
            try {
                for (key in keys) {
                    val coord = TileCoord.fromHash(key) ?: continue
                    invalidateFunction?.invoke(coord.x, coord.y, coord.z)
                }
            } catch (t: Throwable) {
                MapsGLDebug.logE("VectorTileSource", "invalidate() failed", t)
            }
        }
    }

    fun setInvalidateFunction(invalidateFunction: ((Int, Int, Int) -> Unit)?) {
        this.invalidateFunction = invalidateFunction
    }

    /** True after [com.xweather.mapsgl.map.mapbox.MapboxVectorSourceAdapter] registered this source on the style. */
    internal fun isWiredToMapboxCustomGeometrySource(): Boolean = invalidateFunction != null

    fun setBatchInvalidateFunction(batchInvalidateFunction: ((List<Triple<Int, Int, Int>>) -> Unit)?) {
        this.batchInvalidateFunction = batchInvalidateFunction
    }

    /** Subclasses that do not use [tileCache] (e.g. [EncodedGridVectorTileSource]) call this for each loaded Mapbox tile. */
    protected fun notifyMapboxCustomGeometryTileInvalidation(x: Int, y: Int, z: Int) {
        invalidateFunction?.invoke(x, y, z)
    }

    /**
     * Prefer this for many tiles: one Main-thread coroutine instead of one launch per tile (avoids Mapbox stalls).
     */
    protected fun notifyMapboxCustomGeometryTilesInvalidation(coords: List<Triple<Int, Int, Int>>) {
        if (coords.isEmpty()) return
        val batch = batchInvalidateFunction
        if (batch != null) batch(coords)
        else coords.forEach { (x, y, z) -> invalidateFunction?.invoke(x, y, z) }
    }

    protected fun launchInSourceScope(block: suspend () -> Unit) {
        scope.launch { block() }
    }

    override val kind: DataSourceKind
        get() = DataSourceKind.VECTOR

    override fun addConsumer(consumer: DataSourceConsumer) {
        if (consumers.any { it.layerId == consumer.layerId }) {
            return
        }
        consumers.add(consumer)

        consumer.sourceLayerId?.let { layerName ->
            val exists = consumedLayers.containsKey(layerName)
            consumedLayers[layerName] = consumedLayers.getOrDefault(layerName, 0) + 1

            // If layerName hasn't been added yet, invalidate so new layer data is parsed next time tiles are requested
            if (!exists) {
                invalidate()
            }
        }
    }

    override fun removeConsumer(layerId: String) {
        val consumer = consumers.firstOrNull { it.layerId == layerId }
        val layerName = consumer?.sourceLayerId
        if (layerName != null) {
            val count = consumedLayers[layerName]
            if (count != null) {
                val newCount = count - 1
                if (newCount <= 0) {
                    consumedLayers.remove(layerName)
                    // We've completely eliminated the need for this layer, so invalidate the source to clear cached data
                    invalidate()
                } else {
                    consumedLayers[layerName] = newCount
                }
            }
        }
        consumers.remove(consumer)
    }

    /**
     * [parseVectorTile] only runs when bytes are loaded from the network. Mapbox can call
     * [requestTile] many times for tiles already in [vectorTileCache]; the early return path must
     * still invoke [glStencilMaskTileListener] or the GL stencil land cache never fills (marine
     * products added after the first base.osm fetch, or consumer registered after parse).
     *
     * Custom GLES stencil masks ([addCustomStencilTileListener]) must run here too: most vector
     * sources keep [glStencilMaskTileListener] null, so bailing when it is null would skip the
     * cache entirely on every tile hit.
     */
    private fun feedGlStencilMaskFromVectorCache(coord: TileCoord, data: VectorData) {
        val hash = vectorTileCache[coord]?.coordHash ?: coord.hash()
        val snapshot = data.features.toList()
        val tLand0 = System.nanoTime()
        glStencilMaskTileListener?.invoke(coord, hash, snapshot)
        val landMs = (System.nanoTime() - tLand0) / 1_000_000
        if (landMs > 30) {
            MapsGLDebug.logD(
                "VectorTileSource",
                "feed slow: glStencilMaskTileListener key=${coord.hash()} feats=${snapshot.size} ms=$landMs",
            )
        }
        if (customStencilTileListeners.isNotEmpty()) {
            for (cb in customStencilTileListeners.values) {
                cb(coord, hash, snapshot)
            }
        }
    }

    /**
     * After registering custom stencil listeners, replay already-cached MVT parses so the stencil
     * CPU mesh cache fills without waiting for a network round-trip (tiles often parsed before
     * the weather layer + coordinator run).
     */
    internal fun replayCustomStencilFeedsFromCachedVectorTiles() {
        if (customStencilTileListeners.isEmpty()) return
        // `entries()` builds its snapshot internally under [LRUCache]'s lock, so the sequence we
        // get back doesn't touch the live linked list. That matters because
        // [feedGlStencilMaskFromVectorCache] calls `vectorTileCache[coord]`, which mutates the LRU
        // via `_bumpAge` → `_list.unshiftNode`. Previously this method snapshotted with a manual
        // `.toList()` over the lazy sequence, but the snapshot itself could be invalidated by a
        // background tile-parse `get` from another thread — the lazy walk would loop on a stale
        // `.next` pointer and `.toList()` would `add()` until the heap was exhausted (we saw a
        // 118 MB OOM from this path). The fix lives in [LRUCache.entries] now; the loop body here
        // is just a normal iteration over a list-backed sequence.
        for ((_, tile) in vectorTileCache.tiles.entries()) {
            val vd = tile.data as? VectorData ?: continue
            if (vd.features.isEmpty()) continue
            feedGlStencilMaskFromVectorCache(tile.coord, vd)
        }
    }

    /**
     * Replays cached vector tiles into [glStencilMaskTileListener] (and custom listeners) so stencil
     * meshes can be rebuilt immediately without waiting for network/parse on zoom-dependent mask updates.
     */
    internal fun replayGlStencilFeedsFromCachedVectorTiles() {
        if (glStencilMaskTileListener == null && customStencilTileListeners.isEmpty()) return
        // See [replayCustomStencilFeedsFromCachedVectorTiles] for the snapshot-safety story.
        for ((_, tile) in vectorTileCache.tiles.entries()) {
            val vd = tile.data as? VectorData ?: continue
            if (vd.features.isEmpty()) continue
            feedGlStencilMaskFromVectorCache(tile.coord, vd)
        }
    }

    private suspend fun parseVectorTile(
        tile: Tile<VectorData>,
        data: ByteArray,
        validTime: Date,
        headers: Headers?
    ): VectorData = withContext(Dispatchers.Default) {
        val coord = tile.coord
        if (pr.ON) pr.p(TAG, pr.invVec, "parseVectorTile():  ${coord.hash()}")
        decoder.isAutoScale = false

        val allFeatures = decoder.decode(data)
        val tileLayerNames = allFeatures.layerNames
        val debugMaskTile = useTimelessStencilMaskKeys && maskDebugMatches(coord.z, coord.x, coord.y)

        if (pr.ON) pr.p(TAG, pr.invVec, "parseVectorTile() consumers count: ${consumers.count()}")

        for (consumer in consumers) {
            if (pr.ON) pr.p(
                TAG,
                pr.invVec,
                "parseVectorTile() consumer: lID ${consumer.layerId}   sLID: ${consumer.sourceLayerId}"
            )
        }

        // Build the list of needed source-layer names based on active consumers
        val neededLayerNames = mutableListOf<String>()
        consumers.forEach { consumer ->
            val sourceLayerId = consumer.sourceLayerId ?: return@forEach
            val tileLayerId = sourceLayerId.removeSuffix("::inverted")
            if (tileLayerNames.contains(tileLayerId)) {
                neededLayerNames += sourceLayerId
            }
        }

        // GLES stencil: parse raw `water` (marine LAND / WATER masks) and `transportation` (road ribbon mask).
        if (glStencilMaskTileListener != null && tileLayerNames.contains("water")) {
            if (!neededLayerNames.contains("water")) {
                neededLayerNames.add("water")
            }
        }
        if (glStencilMaskTileListener != null && tileLayerNames.contains("transportation")) {
            if (!neededLayerNames.contains("transportation")) {
                neededLayerNames.add("transportation")
            }
        }
        if (glStencilMaskTileListener != null && tileLayerNames.contains("admin")) {
            if (!neededLayerNames.contains("admin")) {
                neededLayerNames.add("admin")
            }
        }
        if (glStencilMaskTileListener != null && tileLayerNames.contains("boundary")) {
            if (!neededLayerNames.contains("boundary")) {
                neededLayerNames.add("boundary")
            }
        }

        for (tag in stencilParseExtraLayers.keys) {
            val base = tag.removeSuffix("::inverted")
            if (tileLayerNames.contains(base) && !neededLayerNames.contains(tag)) {
                neededLayerNames.add(tag)
            }
        }
        if (debugMaskTile) {
            MapsGLDebug.trace(
                "[MaskDebug][Parse] key=${coord.z}/${coord.x}/${coord.y} layers=${tileLayerNames.joinToString()} " +
                    "needed=${neededLayerNames.joinToString()}",
            )
        }

        // If no layers provided by any consumers, then default to the first to handle cases where
        // MVT only has a single layer and no `sourceLayer` is necessary
        if (neededLayerNames.isEmpty() && tileLayerNames.isNotEmpty()) {
            if (glStencilMaskTileListener != null) {
                if (tileLayerNames.contains("water")) {
                    neededLayerNames.add("water")
                }
                if (tileLayerNames.contains("transportation")) {
                    neededLayerNames.add("transportation")
                }
                if (tileLayerNames.contains("admin")) {
                    neededLayerNames.add("admin")
                }
                if (tileLayerNames.contains("boundary")) {
                    neededLayerNames.add("boundary")
                }
            } else {
                neededLayerNames += tileLayerNames.first()
            }
        }

        val features = mutableListOf<Feature>()

        for (layerName in neededLayerNames.distinct()) {
            val invertFeatures = layerName.endsWith("::inverted")
            val tileLayerName = layerName.removeSuffix("::inverted")

            // Fetch features from the tile layer, convert to Mapbox Features, and tag the layer name
            var layerFeatures: List<Feature> =
                decoder.decode(data, tileLayerName)?.mapNotNull { feature ->
                    // Sometimes properties are stored as dot-notated strings in a flattened dictionary, but styling requires nested structure
                    // So convert the properties to the original nested dictionary structure
                    val properties = nestedDictionary(feature.attributes).toMutableMap()
                    // Wall-clock ms at tile decode; matches JS `Date.now()` at paint time for freshly loaded tiles.
                    properties["now"] = System.currentTimeMillis().toDouble()
                    injectFireReportStartTimestampMillisForStyle(properties)
                    properties["layer"] = layerName
                    MapboxVectorFeature.from(coord, feature, properties)
                } ?: listOf()

            // Optional inversion of polygonal features into a single “inverse” polygon covering the tile
            if (invertFeatures) {
                val inverted = inverseTileFeatures(layerFeatures, coord)
                if (inverted != null) {
                    inverted.addStringProperty("layer", layerName)
                    layerFeatures = mutableListOf(inverted)
                } else {
                    // No valid land mask for this tile; do not keep raw water polys tagged water::inverted
                    // (putFromFeatures would triangulate water as "land" and invert the mask).
                    layerFeatures = emptyList()
                }
            }

            features += layerFeatures
        }

        // Optional clustering / de-duplication for dense point-only tiles
        val isAllPoints = features.all { it.geometry() is Point }

        if (isAllPoints && features.size > 3000) {
            val minDistanceKm = 1.0
            val maxDistanceKm = 10.0
            val t = ((10 - coord.z).coerceIn(0, 10)) / 10.0
            val maxDistanceKilometers = minDistanceKm + t * (maxDistanceKm - minDistanceKm)

            val pointClusterer = FeatureCluster()
            val clustered = pointClusterer.deduplicateClosePoints(features, maxDistanceKilometers)
            features.clear()
            features += clustered
        }

        val featSnapshot = features.toList()
        glStencilMaskTileListener?.invoke(coord, tile.coordHash, featSnapshot)
        if (customStencilTileListeners.isNotEmpty()) {
            for (cb in customStencilTileListeners.values) {
                cb(coord, tile.coordHash, featSnapshot)
            }
        }
        if (debugMaskTile) {
            val water = features.count { it.getStringProperty("layer") == "water" }
            val inv = features.count { it.getStringProperty("layer") == "water::inverted" }
            MapsGLDebug.trace("[MaskDebug][Parse] key=${coord.z}/${coord.x}/${coord.y} features=${features.size} water=$water inv=$inv")
        }

        VectorData(validTime, features)
    }

    private fun inverseTileFeatures(features: List<Feature>, tileCoord: TileCoord): Feature? {
        if (features.isEmpty()) {
            // Inverting "no water" is ambiguous (all-ocean vs all-land with empty layer). The legacy
            // path used a full-tile outer ring as "land" with no holes, which stencils the entire
            // weather quad (stencil=1) so GL_EQUAL 0 rejects every fragment — the marine layer vanishes.
            // Safer: no land mask for this tile; marine still shows; rare land tiles with no water
            // layer may show marine on land.
            return null
        }
        var currentBounds = getLatLonBoundsOfTile(tileCoord)

        // Expand bounds to fully contain buffered features
        val allCoords: List<Point> = features
            .mapNotNull { feature ->
                when (val geom = feature.geometry()) {
                    is Polygon -> geom.coordinates().flatten()                  // List<List<Point>> -> List<Point>
                    is MultiPolygon -> geom.coordinates().flatten()
                        .flatten()   // List<List<List<Point>>> -> List<Point>
                    else -> null
                }
            }
            .flatten()

        if (allCoords.isNotEmpty()) {
            val minLat = allCoords.minOfOrNull { it.latitude() }?.let {
                min(currentBounds.southExtent, it)
            } ?: currentBounds.southExtent
            val maxLat = allCoords.maxOfOrNull { it.latitude() }?.let {
                max(currentBounds.northExtent, it)
            } ?: currentBounds.northExtent
            val minLon = allCoords.minOfOrNull { it.longitude() }?.let {
                min(currentBounds.westExtent, it)
            } ?: currentBounds.westExtent
            val maxLon = allCoords.maxOfOrNull { it.longitude() }?.let {
                max(currentBounds.eastExtent, it)
            } ?: currentBounds.eastExtent

            currentBounds = LatLonBounds(
                minLon,
                minLat,
                maxLon,
                maxLat
            )

            if (pr.ON) pr.p(
                TAG,
                pr.invVec2,
                "inverseTileFeatures() db bounds:lon: ${(maxLon - minLon).toInt()} ($minLon / $maxLon)  lat: ${(maxLat - minLat).toInt()}  ($minLat / $maxLat)  ",
            )

            if (pr.ON) for (coord in allCoords) {
                if (pr.ON) pr.p(TAG, pr.invVec2, "   coord:$coord  ")
            }

        }

        //outer ring is CCW
        val outerRing: List<Point> = listOf(
            Point.fromLngLat(currentBounds.westExtent, currentBounds.southExtent),
            Point.fromLngLat(currentBounds.eastExtent, currentBounds.southExtent),
            Point.fromLngLat(currentBounds.eastExtent, currentBounds.northExtent),
            Point.fromLngLat(currentBounds.westExtent, currentBounds.northExtent),
            Point.fromLngLat(currentBounds.westExtent, currentBounds.southExtent)
        ).reversedIfClockwise()

        val holeRings: MutableList<List<Point>> = mutableListOf()

        for (feature in features) {
            when (val geom = feature.geometry()) {
                is Polygon -> {
                    val rings: List<List<Point>> = geom.coordinates()
                    rings.forEachIndexed { index, ring ->
                        val corrected = if (index == 0) {
                            ring.reversedIfClockwise()           // outer -> hole, ensure CCW->CW
                        } else {
                            ring.reversedIfCounterClockwise()     // inner -> outer-of-hole, ensure CW->CCW
                        }
                        holeRings.add(corrected)
                    }
                }

                is MultiPolygon -> {
                    val polys: List<List<List<Point>>> = geom.coordinates()
                    polys.forEach { poly ->
                        poly.forEachIndexed { index, ring ->
                            val corrected = if (index == 0) {
                                ring.reversedIfClockwise()
                            } else {
                                ring.reversedIfCounterClockwise()
                            }
                            holeRings.add(corrected)
                        }
                    }
                }

                else -> {
                    // ignore non-polygonal geometry
                }
            }
        }

        if (holeRings.isEmpty()) {
            // No polygonal water to punch out: do not use outerRing alone (full-tile = all land in stencil).
            // That happens for water layer that only has points/lines, or non-polygon geometry.
            return null
        }
        val allRings = ArrayList<List<Point>>(1 + holeRings.size)
        allRings.add(outerRing)
        allRings.addAll(holeRings)
        val feature: Feature = Feature.fromGeometry(Polygon.fromLngLats(allRings))

        feature.addNumberProperty("now", System.currentTimeMillis().toDouble())
        feature.addStringProperty("featureType", "Polygon")
        feature.addStringProperty("geometry-type", "Polygon")

        return feature
    }
}

/**
 * Epoch millis from [report] `startDateISO`, aligned with JavaScript `new Date(report.startDateISO).getTime()`.
 * Null when the field is absent or not parseable (Invalid Date on the web).
 */
private fun fireReportStartEpochMillisFromIso(report: Map<String, Any>): Double? {
    val iso = report["startDateISO"] as? String ?: return null
    toDate(iso)?.time?.let { return it.toDouble() }
    return try {
        java.time.OffsetDateTime.parse(iso).toInstant().toEpochMilli().toDouble()
    } catch (_: Exception) {
        try {
            java.time.Instant.parse(iso).toEpochMilli().toDouble()
        } catch (_: Exception) {
            null
        }
    }
}

/**
 * Fires-obs styling uses `report.startDateISO` only for the 24h "new" rule (see web `getFireObsPointStyle`).
 * We store that instant as `report.startTimestampMillis` for Mapbox expressions.
 */
private fun injectFireReportStartTimestampMillisForStyle(properties: MutableMap<String, Any>) {
    val reportObj = properties["report"] as? Map<String, Any> ?: return
    if (reportObj.containsKey("startTimestampMillis")) return
    val report = reportObj.toMutableMap()
    val millis = fireReportStartEpochMillisFromIso(report) ?: return
    report["startTimestampMillis"] = millis
    properties["report"] = report
}

fun nestedDictionary(flat: Map<String, Any>): Map<String, Any> {
    fun insert(target: Any?, keys: List<String>, value: Any): Any {
        if (keys.isEmpty()) return target ?: value

        val key = keys.first()
        val remainingKeys = keys.drop(1)

        return if (key.toIntOrNull() != null) {
            val index = key.toInt()
            val array = (target as? List<Any?>)?.toMutableList() ?: mutableListOf()

            while (array.size <= index) {
                array.add(null)
            }

            array[index] = insert(array[index], remainingKeys, value)
            array
        } else {
            val dict = (target as? Map<*, *>)?.toMutableMap() ?: mutableMapOf()
            dict[key] = insert(dict[key], remainingKeys, value)
            dict
        }
    }

    var result: Any = mutableMapOf<String, Any>()

    for ((flatKey, value) in flat) {
        val keys = flatKey.split(".")
        result = insert(result, keys, value)
    }

    @Suppress("UNCHECKED_CAST")
    return result as? Map<String, Any> ?: emptyMap()
}
