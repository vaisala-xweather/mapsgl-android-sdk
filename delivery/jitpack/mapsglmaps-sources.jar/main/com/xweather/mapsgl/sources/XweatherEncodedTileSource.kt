package com.xweather.mapsgl.sources

import VariableObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.lifecycle.Observer
import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.TileResponse
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import com.xweather.mapsgl.sources.data.EncodedData
import com.xweather.mapsgl.sources.data.EncodedTimeSeriesData
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileQuadrant
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URL
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.roundToInt

@Suppress("Dokka")
data class RequestOptions(
    val dataSetId: String,
    val dataMin: Double,
    val dataMax: Double,
    val outputMin: Double,
    val outputMax: Double,
    val outputNoDataValue: Double? = null,
    val validTimes: MutableList<Date>? = null
)

const val TAG = "XWeatherEncodedTileSource"
private const val BYTESIZE = 4
/** Radar source id — passed as [isRadar] to native padding helpers. */
private const val RADAR_ENCODED_ID = "radar_REFC_PRATE_PTYPESMPL"
var outstandingReq = 0

/**
 *  XweatherEncodedTileSource.kt
 *
 *  A subclass of `EncodedTileSource` that is used to request and process encoded tile data from the MapsGL server.
 *
 *  Based  on the IOS version.
 *  @author Jason Suto 01/08/24
 *
 */

@Suppress("Dokka")
class XweatherEncodedTileSource(
    override var id: String,
    override var authenticator: XweatherAuthenticator?
) : EncodedTileSource("XweatherEncodedTileSource") {

    private val mapPrefixURL = "${mapsGLServer}/tile"
    private val tileByteArraySize = 1048576

    var isStale = false

    enum class Error {
        InvalidData
    }

    companion object {
        var s = 0
        var d = 0
        var stride = 0
        var paddingXByteSize = 0

        // Fixed pool avoids Dispatchers.Default.limitedParallelism, which requires a newer
        // kotlinx-coroutines than some host apps resolve (NoSuchMethodError on older coroutines).
        private val tileProcessingDispatcher =
            Executors.newFixedThreadPool(2) { r ->
                Thread(r, "mapsgl-encoded-tile").apply { isDaemon = true }
            }.asCoroutineDispatcher()
        // Comma-separated "z/x/y" weather tiles to trace end-to-end.
        private const val WEATHER_DEBUG_TARGETS = "6/19/21,6/19/22,6/20/21,6/20/22,6/19/23,6/20/23"
    }


    override var kind: DataSourceKind = DataSourceKind.AERIS_ENCODED
//    override lateinit var bounds: MapBounds<LatitudeLongitude>
//    override val TileSource<DataType>.bounds: LatLonBounds
//        get() {
//            return this.bounds
//        }

    override var tileCache: TileCache<DataType> = TileCache(sourceID = id)
    override var datasets: List<DatasetType> = listOf()
    override val isEncoded: Boolean = true

    private var requestCount = 0
    var pendingRequestedTiles: MutableList<String> = mutableListOf()
    private val size = DataPool.originalSize
    private val padding = DataPool.padding
    val metadataObserver = VariableObserver()

    lateinit var passedObserver: Observer<String>
    private val dateFormatter: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault())
    private val paddingManager = PaddingManager(size, padding, tileCache, id)

    val threadSafeTileMap = ConcurrentHashMap<String, Tile<DataType>>()
    val threadSafeIntervalMap = ConcurrentHashMap<String, List<String>?>()
    private val onEncodedTileReadyListeners = mutableListOf<(TileCoord) -> Unit>()

    private fun weatherDebugMatches(coord: TileCoord): Boolean {
        if (WEATHER_DEBUG_TARGETS.isEmpty()) return false
        val key = "${coord.z}/${coord.x}/${coord.y}"
        return WEATHER_DEBUG_TARGETS.split(',').any { it.trim() == key }
    }

    init {
        metadata = SourceMetadata(ImageTileSource.MetadataSchema(), URL(mapsGLServer))
        isReady = false
    }

    private val layerId: String
        get() {
            return this.metadataObserver.layerId
        }

    override fun getMetadataURL(): URL? {
        var urlString = metadataURL ?: return null
        val datasetString = "&data-set-ids=${datasets.joinToString("&data-set-ids=") { it.code }}"

        if (pr.ON) pr.p(
            TAG,
            pr.metadata,
            "getMetadataURL() metadata.data.startDate: ${metadata.data.startDate}, metadata.data.endDate: ${metadata.data.endDate}"
        )

        val beginString = dateFormatter.format(metadata.data.startDate.time)
        val endString = dateFormatter.format(metadata.data.endDate.time)
        urlString = urlString.replace("&{datasets}", datasetString)
        urlString = urlString.replace("{startDate}", beginString).replace("{endDate}", endString)
        if (pr.ON) pr.p(TAG, pr.metadata, "getMetadataURL() returning $urlString ")
        return URL(urlString)
    }

    fun setObserver(observer: Observer<String>, layerID: String) {
        metadataObserver.observeVariableAndQuit(observer, layerID)
        passedObserver = observer
    }

    override suspend fun fetchMetadata(startDate: Date?, endDate: Date?): Result<Unit> {
        authenticator?.authenticate()

        if (startDate != null) {
            metadata.data.startDate = Date(startDate.time - 6 * 3600 * 1000)
        }
        if (endDate != null) {
            metadata.data.endDate = Date(endDate.time + 6 * 3600 * 1000)
        } else {
        }

        val url =
            getMetadataURL() ?: return Result.failure(IllegalStateException("Metadata URL could not be generated."))
        val request = URLRequest(url.toString())

        request.setHeader("Referer", MapController.packageName!!)
        authenticator?.credentials?.let { credentials ->
            request.setAuthorization("Bearer ${credentials.accessToken}")
        }

        val success = withContext(Dispatchers.IO) {
            if (Timeline.sourceTimeHash[id] == null) {
                Timeline.sourceTimeHash[id] = LayerTimeline(id)
            }

            val loaded = metadata.load(request, metadataObserver.layerId, id)
            minZoom = metadata.data.minZoom
            maxZoom = metadata.data.maxZoom
            if (loaded) {
                metaDataNeeded--
            }
            loaded
        }

        if (!success) {
            return Result.failure(IllegalStateException("Metadata load did not complete for $id"))
        }

        if (metaDataNeeded == 0) {
            metadataObserver.updateVariable(metadataObserver.layerId)
        }

        return Result.success(Unit)
    }

    @Synchronized
    fun addOnEncodedTileReadyListener(listener: (TileCoord) -> Unit) {
        onEncodedTileReadyListeners.add(listener)
    }

    @Synchronized
    private fun notifyEncodedTileReady(coord: TileCoord) {
        if (onEncodedTileReadyListeners.isEmpty()) return
        val listenersSnapshot = onEncodedTileReadyListeners.toList()
        for (listener in listenersSnapshot) {
            runCatching { listener(coord) }
        }
    }

    /** Test function to detect color format of image **/
    fun getImageColorFormat(imageBytes: ByteArray): Bitmap.Config? {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, options)
        return options.outConfig
    }

    private fun removeTrackedPendingInterval(
        coord: TileCoord,
        interval: String,
        trackDownloadProgress: Boolean,
    ) {
        if (trackDownloadProgress) {
            TileList.pendingList.remove(this.id, coord.hashShort(), interval)
        }
    }

    private fun removeTrackedPendingEncoded(intervalHash: String, trackDownloadProgress: Boolean) {
        if (trackDownloadProgress) {
            Timeline.removePendingEncodedDownload(id, intervalHash)
        }
    }

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?,
        trackDownloadProgress: Boolean,
    ): Any { // Return type might need adjustment if you expect specific results
        //if (pr.ON) pr.p(TAG, pr.tileReq, "requestTiles() entered  ${layerId}")

        // ownerMapSessionId is stamped in [MapController.addSource]; fall back to the active
        // session so tiles are not discarded when the field was not set (regression guard).
        val requestSession =
            ownerMapSessionId.takeIf { it != 0L } ?: Timeline.mapSessionId

        val urlTime = intervalToIsoPathTime(currentDate)
        val tileUrl = makeTileURL(coord, mutableMapOf("time" to urlTime))
        if (weatherDebugMatches(coord)) {
            MapsGLDebug.trace("[WeatherDebug][Fetch] request start key=${coord.z}/${coord.x}/${coord.y} time=$currentDate intervals=${intervals?.size ?: 0}")
        }
        val urlRequest = URLRequest(tileUrl.toString()).apply {
            // Prevent "loading forever" by bounding per-tile HTTP time.
            // When this trips, requestTiles() will fall into the failure path and
            // remove the tile interval from TileList.pendingList so animation can continue.
            connectTimeoutMs = 20_000
            readTimeoutMs = 20_000
        }
        prepareTileRequest(urlRequest, coord.time, intervals) // Sets body based on intervals

        val intervalList = intervals.orEmpty()
        if (intervalList.isNotEmpty()) {
            val allSatisfied = intervalList.all { interval ->
                val lookupCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                tileCache.tiles.containsKey(lookupCoord.hash()) ||
                    tileCache._pending.containsKey(lookupCoord.hash()) ||
                    tileCache.nativeCache.containsKey("${id}${lookupCoord.hash()}") ||
                    (requestSession == Timeline.mapSessionId &&
                        TileList.readyList.containsTimeInTile(id, coord.hashShort(), interval))
            }
            if (allSatisfied) {
                return RequestTileSuccess.alreadyExists
            }
        }

        fun markReady(interval: String) {
            if (requestSession != Timeline.mapSessionId) return
            TileList.readyList.add(this.id, coord.hashShort(), interval, requestSession)
        }

        // --- Tile Cache and State Logic (seems mostly okay) ---
        // Set correct time on coord for cache lookup if multiple intervals are passed
        val primaryLookupTime = intervals?.firstOrNull() ?: coord.time ?: "" // Use first interval or original time
        val coordForLookup = (TileCoord(coord.x, coord.y, coord.z))  // Use a copy for lookup key
        coordForLookup.time = primaryLookupTime
        // Get or create the tile representing this batch (maybe use first interval time?)


        val representativeTile = tileCache[coordForLookup] ?: TileType(coordForLookup).also { newTile ->
            newTile.isEncoded = true
            newTile.coordHash = coordForLookup.hash()
            tileCache.updateTile(newTile, coordForLookup) // Update cache with the representative tile
        }

        // Set pending *before* starting the load operation for this representative coord/interval list
        tileCache.setPending(true, representativeTile)
        representativeTile.state = TileState.Loading
        if (trackDownloadProgress) {
            trigger(DataSourceEvents.TileLoadStart(id, representativeTile))
        }

        if (pr.ON) pr.p(TAG, pr.tileRequest, "requestTiles() req ${coord.hashShort()} intv: $intervals")

        var keepTrack = 0

        val tileResponse: TileResponse? = try {
            if (intervals != null) {
                for (interval in intervals) {
                    if (trackDownloadProgress) {
                        TileList.requestedList.add(this.id, coord.hashShort(), interval)
                        TileList.pendingList.add(this.id, coord.hashShort(), interval)
                        Timeline.currentDLCount++
                    }
                    if (pr.ON) pr.p(TAG, pr.tileReq, "cordHash:${coord.hashShort()}    ${interval}")
                }
            }



            requestCount++
            pendingRequestedTiles.add(coord.hash())
            keepTrack = requestCount
            tileManager.loadTile(coord, urlRequest) // Call the modified suspending function
        } catch (e: Exception) {
            if (weatherDebugMatches(coord)) {
                MapsGLDebug.trace("[WeatherDebug][Fetch] request exception key=${coord.z}/${coord.x}/${coord.y} err=${e.message}")
            }
            MapsGLDebug.logE(TAG, "loadTile failed for ${coord.hashShort()}", e)
            //println("XweatherEncodedTileSource requestTiles() failed for ${coord.hashShort()}")
            requestCount--
            pendingRequestedTiles.remove(coord.hash())

            // Remove pending entries for the whole multi-interval batch.
            // Then retry each interval individually so other intervals can still load.
            val intervalList = intervals.orEmpty()
            for (interval in intervalList) {
                removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
            }

            tileCache.setPending(false, representativeTile) // Ensure representative pending is cleared
            representativeTile.state = TileState.Failed // Mark as failed (sub-interval successes may override)

            // CancellationException signals coroutine cancellation (e.g. controller shutdown).
            // Pending state is already cleaned up above; re-throw so the coroutine machinery
            // can propagate the cancellation instead of falling into the retry loop and
            // stamping phantom TileList entries against the new session's mapSessionId.
            if (e is CancellationException) throw e

            // Non-time-series / unexpected call path: keep timeline bookkeeping consistent.
            if (intervalList.isEmpty()) {
                removeTrackedPendingEncoded(coord.hash(), trackDownloadProgress)
                return RequestTileSuccess.alreadyExists
            }

            for (interval in intervalList) {
                try {
                    val singleUrlRequest = URLRequest(tileUrl.toString()).apply {
                        connectTimeoutMs = 20_000
                        readTimeoutMs = 20_000
                    }
                    prepareTileRequest(singleUrlRequest, coord.time, listOf(interval))

                    val singleResponse = tileManager.loadTile(coord, singleUrlRequest)
                    if (singleResponse != null) {
                        markReady(interval)

                        representativeTile.data = singleResponse.data
                        singleResponse.data = 0
                        onTileLoaded(representativeTile, listOf(interval), 1)
                    } else {
                        if (trackDownloadProgress) {
                            TileList.failedList.add(this.id, coord.hashShort(), interval)
                        }
                        val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                        removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                    }
                } catch (e2: Exception) {
                    if (e2 is CancellationException) throw e2
                    if (trackDownloadProgress) {
                        TileList.failedList.add(this.id, coord.hashShort(), interval)
                    }
                    val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                    removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                    MapsGLDebug.logW(TAG, "Single-interval retry failed for ${intervalCoord.hash()}", e2)
                }
            }

            // We already retried per-interval in the catch block; skip the shared tileResponse-null failure path.
            return RequestTileSuccess.alreadyExists
        }

        // --- Process the result ---
        if (tileResponse != null) {
            if (requestSession != Timeline.mapSessionId) {
                requestCount--
                pendingRequestedTiles.remove(coord.hash())
                tileCache.setPending(false, representativeTile)
                for (interval in intervalList) {
                    removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
                }
                return RequestTileSuccess.alreadyExists
            }
            if (weatherDebugMatches(coord)) {
                MapsGLDebug.trace("[WeatherDebug][Fetch] response ok key=${coord.z}/${coord.x}/${coord.y}")
            }
            if (pr.ON) {
                pr.p(TAG, pr.receivedEnc, "recieved enc data: ${tileResponse.headers}")
            }
            requestCount--
            pendingRequestedTiles.remove(coord.hash())

            //if(pr.ON) pr.p(TAG, pr.tileRequestActual, "requestTiles() actually received ${tileResponse.headers.values}")
            if (pr.ON) pr.p(TAG, pr.tileRequestActual, "requestTiles() requestCount:     $requestCount     $keepTrack")

            representativeTile.data = tileResponse.data
            tileResponse.data = 0
            // coordHash looks like 0:0/0/0/["2025-04-30T14:00:00Z"]

            if (Timeline.movedOnTileLoaded) {
                for (interval in intervals!!) {
                    removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
                    markReady(interval)
                }
                threadSafeTileMap[representativeTile.coordHash] = representativeTile
                threadSafeIntervalMap[representativeTile.coordHash] = intervals
            } else {
                try {
                    onTileLoaded(representativeTile, intervals, 1)
                } finally {
                    for (interval in intervals!!) {
                        removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
                        markReady(interval)
                    }
                }
            }

            // onTileLoaded should handle setting state to Ready and clearing pending
        } else {
            if (weatherDebugMatches(coord)) {
                MapsGLDebug.trace("[WeatherDebug][Fetch] response null key=${coord.z}/${coord.x}/${coord.y}")
            }
            // Failure already logged (e.g., timeout inside URLRequest/URLConnection).
            // IMPORTANT: clear representative tile "pending" state too, otherwise
            // checkDownloadStatus() can keep waiting even though TileList.pendingList
            // has already been updated.
            requestCount--
            tileCache.setPending(false, representativeTile)
            representativeTile.state = TileState.Failed

            val intervalList = intervals.orEmpty()

            // Remove pending for the whole multi-interval batch.
            // Then retry each interval individually so other intervals can still load.
            for (interval in intervalList) {
                removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
            }

            if (intervalList.isEmpty()) {
                removeTrackedPendingEncoded(coord.hash(), trackDownloadProgress)
                pendingRequestedTiles.remove(coord.hash())
                return RequestTileSuccess.alreadyExists
            }

            for (interval in intervalList) {
                // If the batch failed, we only bother retrying when there are multiple intervals.
                if (intervalList.size == 1) {
                    if (trackDownloadProgress) {
                        TileList.failedList.add(this.id, coord.hashShort(), interval)
                    }
                    val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                    removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                    continue
                }

                try {
                    val singleUrlRequest = URLRequest(tileUrl.toString()).apply {
                        connectTimeoutMs = 20_000
                        readTimeoutMs = 20_000
                    }
                    prepareTileRequest(singleUrlRequest, coord.time, listOf(interval))

                    val singleResponse = tileManager.loadTile(coord, singleUrlRequest)
                    if (singleResponse != null) {
                        markReady(interval)

                        representativeTile.data = singleResponse.data
                        singleResponse.data = 0
                        onTileLoaded(representativeTile, listOf(interval), 1)
                    } else {
                        if (trackDownloadProgress) {
                            TileList.failedList.add(this.id, coord.hashShort(), interval)
                        }
                        val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                        removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                    }
                } catch (e2: Exception) {
                    if (trackDownloadProgress) {
                        TileList.failedList.add(this.id, coord.hashShort(), interval)
                    }
                    val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                    removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                    MapsGLDebug.logW(TAG, "Single-interval retry failed for ${intervalCoord.hash()}", e2)
                }
            }

            pendingRequestedTiles.remove(coord.hash())
            MapsGLDebug.logW(TAG, "TileResponse was null for ${coord.hash()}, load failed.")
        }
        if (pr.ON) pr.p(TAG, pr.dataPool, "XWeatherEncodedTileSource requestTiles() exited")
        return RequestTileSuccess.alreadyExists // Placeholder, adjust as needed
    }

    private fun convertBitmapToByteArray(bitmap: Bitmap): ByteArray? {
        val byteBuffer = ByteBuffer.allocate(bitmap.byteCount)
        bitmap.copyPixelsToBuffer(byteBuffer)
        byteBuffer.rewind()
        //bitmap.recycle()
        return byteBuffer.array()
    }

    private fun moveBitmapToByteArray(bitmap: Bitmap): ByteArray {
        bitmap.copyPixelsToBuffer(DataPool.byteBuffer)
        DataPool.byteBuffer.rewind()
        //bitmap.recycle()
        return DataPool.byteBuffer.array()
    }


    /**
     * Backfills the edges of the tile with its neighbors' data and vice versa.
     * This mirrors the logic found in the JavaScript SDK for seamless tile stitching.
     */
    suspend fun onTileLoaded(tile: TileType, intervals: List<String>?, mode: Int) {
        if (pr.ON) pr.p(
            TAG,
            pr.backfillEdge,
            "onTileLoaded() entered for  ${tile.coordHash}  }"
        )
        // 1. First, perform the standard loading logic (decoding, data chunking, etc.)
        // Note: If you renamed your original function to onTileLoadedOrig, call that first.
        // onTileLoadedOrig(tile, intervals, mode)

        Timeline.totalDownloads++

        isStale = tileCache.isStale(tile)
        if (isStale) {
            tileCache.setStale(false, tile)
            //trigger(DataSourceEvents.TileDiscard(sourceID = id, tile = tile))
            if (pr.ON) pr.p(TAG, pr.flicker, "onTileLoaded() begining, STALE: ${tile.coordHash}")
            return
        } else {
            //todo: IF you remove this, paused dl does not work?
            //if(pr.ON) pr.p(TAG, pr.flicker, "onTileLoaded() begining set pending false: ${tile.coordHash}")
            tileCache.setPending(false, tile)
        }

        withContext(tileProcessingDispatcher) {
            val doEdgeBlending = true
            val rawBytes = (tile.data) as ByteArray
            if (weatherDebugMatches(tile.coord)) {
                MapsGLDebug.trace("[WeatherDebug][Decode] begin key=${tile.coord.z}/${tile.coord.x}/${tile.coord.y} rawBytes=${rawBytes.size} intervals=${intervals?.size ?: 0}")
            }
            val tempMultiIntervalByteArray: ByteArray = if (DataPool.bigImageEnabled) {
                val bitmap = parseTile(tile, rawBytes, null)
                try {
                    moveBitmapToByteArray(bitmap)
                } finally {
                    bitmap.recycle()
                }
            } else {
                tileCache.nativeCache.decodeImageBytesToRgba(rawBytes)
                    ?: run {
                        val bitmap = parseTile(tile, rawBytes, null)
                        try {
                            convertBitmapToByteArray(bitmap)
                                ?: throw IllegalArgumentException("Invalid image data (bitmap decode)")
                        } finally {
                            bitmap.recycle()
                        }
                    }
            }
            if (weatherDebugMatches(tile.coord)) {
                MapsGLDebug.trace("[WeatherDebug][Decode] rgba ready key=${tile.coord.z}/${tile.coord.x}/${tile.coord.y} bytes=${tempMultiIntervalByteArray.size}")
            }

            if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() intervals are null?: ${intervals == null}")

            if (intervals != null) {
                tile.data = null

                // Make a list of missing intervals
                val missingIntervalHash: HashMap<Int, String> = hashMapOf()
                if ((tempMultiIntervalByteArray.size / intervals.size) != tileByteArraySize) {
                    for ((missingIndex, interval) in intervals.withIndex()) {
                        // if (!Timeline.sourceTimeHash[id]?.timeStrings?.contains(interval.substring(2,interval.length - 2))!!) // need to test this
                        if (!Timeline.validTimesList[layerId]!!.contains(interval.substring(2, interval.length - 2))) {
                            missingIntervalHash[missingIndex] = interval
                        }
                    }
                }

                val useNativeSplitPad =
                    missingIntervalHash.isEmpty() &&
                        intervals.isNotEmpty()

                val paddedStripsOrNull: Array<ByteArray>? = if (useNativeSplitPad) {
                    tileCache.nativeCache.splitAndPadEncodedTilesToByteArrays(
                        tempMultiIntervalByteArray,
                        intervals.size,
                        DataPool.originalSize,
                        padding,
                        id == RADAR_ENCODED_ID,
                    ) ?: error("native split+pad failed for $id tile=${tile.coordHash}")
                } else {
                    null
                }

                val dataHash: HashMap<Int, ByteArray?> = hashMapOf()
                var offset = 0
                for ((i, interval) in intervals.withIndex()) {
                    val newTile = Tile<DataType>(TileCoord(tile.coord.x, tile.coord.y, tile.coord.z, time = interval))
                    //if (pr.ON) pr.p(TAG, pr.validTimes, "   onTileLoaded() checking i:$i vs missingHash keys: ${missingIntervalHash.keys} " )
                    if (missingIntervalHash.containsKey(i)) {
                        if (pr.ON) pr.p(TAG, pr.tileReceived, "onTileLoaded() identified missing index $i, skipping", 2)
                        offset++
                    } else {
                        newTile.isEncoded = true
                        newTile.time = interval
                        newTile.state = TileState.Processing
                        if (useNativeSplitPad) {
                            newTile.encodedData = EncodedData(
                                byteArrayOf(),
                                doEdgeBlending,
                                padding,
                                id,
                                deferPadToNativePipeline = true,
                            )
                            newTile.encodedData!!.paddedData = paddedStripsOrNull!![i]
                        } else {
                            newTile.data = getByteArrayChunkWidth(
                                tempMultiIntervalByteArray,
                                intervals.size - missingIntervalHash.size,
                                i - offset
                            )
                            dataHash[i - offset] = newTile.data as ByteArray
                        }
                        val nativeChunkReady =
                            useNativeSplitPad && newTile.encodedData?.paddedData != null
                        val kotlinChunkReady = !useNativeSplitPad && newTile.data != null
                        if (nativeChunkReady || kotlinChunkReady) {
                            if (!useNativeSplitPad) {
                                newTile.encodedData = encodePaddedViaNativeCache(
                                    newTile.data as ByteArray,
                                    newTile.coordHash,
                                    doEdgeBlending,
                                )
                                newTile.data = null
                            }
                            if (doEdgeBlending) {
                                val neighbors = newTile.coord.getNeighbors()
                                neighbors.forEach { (quadrant, neighborCoord) ->

                                    // Normalize coordinates to handle world wraparound (x < 0 or x > max)
                                    val normalizedCoord = neighborCoord.normalize()

                                    // Check if the neighbor tile exists in our cache
                                    val neighborTile = tileCache[normalizedCoord]

                                    if (neighborTile?.encodedData?.paddedData == null) {
                                        if (pr.ON) pr.p(TAG, pr.edgeBlend, "onTileLoaded() neighbor paddedData is null")


                                        if (pr.ON) pr.p(
                                            TAG,
                                            pr.edgeBlend,
                                            " onTileLoaded() trying to GET: ${id}${tile.coordHash}"
                                        )
                                        neighborTile?.encodedData?.paddedData =
                                            tileCache.nativeCache.getData("${id}${neighborTile?.coordHash}")

                                        if (pr.ON) pr.p(
                                            TAG,
                                            pr.edgeBlend,
                                            "onTileLoaded()  found n padTile in cache? ${neighborTile?.encodedData?.paddedData != null}"
                                        )
                                    }

                                    if (neighborTile?.encodedData?.paddedData != null) {

                                        if (pr.ON) pr.p(
                                            TAG,
                                            pr.edgeBlend,
                                            "     onTileLoaded() quad:$quadrant  neighborCoord: $neighborCoord",
                                        )

                                        // Perform the bidirectional backfill
                                        fillEdge(newTile, neighborTile) //this one works?
                                        fillEdge(neighborTile, newTile) //does not work

                                        // Flag that textures need re-binding since pixels changed
                                        newTile.needsBind = true
                                        neighborTile.needsBind = true
                                        if (pr.ON) pr.p(
                                            TAG,
                                            pr.backfillEdge,
                                            "      onTileLoaded() t.needs: ${newTile.needsBind} n.needs: ${neighborTile.needsBind}"
                                        )

                                        tileCache.withBindListLock {
                                            if (!tileCache.bindList.contains(neighborTile.coordHash)) {
                                                tileCache.bindList.add(neighborTile.coordHash)
                                                tileCache.updateTile(neighborTile)
                                                neighborTile.state = TileState.Ready
                                            }
                                        }
                                    } else {
                                        if (pr.ON) pr.p(
                                            TAG,
                                            pr.backfillEdge,
                                            "onTileLoaded() $quadrant null... ordinal ${quadrant.ordinal}"
                                        )
                                        if (quadrant == TileQuadrant.TopCenter) {
                                            //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padUP")
                                            paddingManager.padUp(newTile)
                                        } else if (quadrant == TileQuadrant.BottomCenter) {
                                            //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padDOWN")
                                            paddingManager.padDown(newTile)
                                        } else if (quadrant == TileQuadrant.MiddleLeft) {
                                            //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padLEFT")
                                            paddingManager.padLeft(newTile)
                                        } else if (quadrant == TileQuadrant.MiddleRight) {
                                            // if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padRIGHT")
                                            paddingManager.padRight(newTile)
                                        }
                                        newTile.needsBind = true

                                    }
                                }
                            }
                            newTile.needsBind = true
                            tileCache.withBindListLock {
                                if (!tileCache.bindList.contains(newTile.coordHash)) {
                                    tileCache.bindList.add(newTile.coordHash)
                                }
                            }
                            tileCache.updateTile(newTile)
                            newTile.state = TileState.Ready
                            notifyEncodedTileReady(newTile.coord)

                        } else {
                        } // end if (nativeChunkReady || kotlinChunkReady)
                    }
                }

                // Account for missing intervals
                for (key in missingIntervalHash.keys) {
                    if (pr.ON) pr.p(
                        TAG,
                        pr.validTimes2,
                        "onTileLoaded() at the end, need to construct data for  missing index $key  -   ${missingIntervalHash[key]}",
                        2
                    )
                    val newTile =
                        Tile<DataType>(TileCoord(tile.coord.x, tile.coord.y, tile.coord.z, time = intervals[key]))
                    newTile.isEncoded = true
                    newTile.time = intervals[key]
                    newTile.state = TileState.Processing

                    if (key != 0 && key != intervals.size - 1) { // blend if possible
                        if (pr.ON) pr.p(TAG, pr.validTimes2, "onTileLoaded() at the end, interval is not endpoint..", 2)
                        if (dataHash[key - 1] != null && dataHash[key + 1] != null) {
                            if (pr.ON) pr.p(
                                TAG,
                                pr.validTimes2,
                                "onTileLoaded() found needed data for blending, sizes ${dataHash[key - 1]!!.size} and ${dataHash[key + 1]!!.size}: ",
                                2
                            )
                            newTile.data = blendByteArrays(dataHash[key - 1]!!, dataHash[key + 1]!!)
                        }
                    } else if (key == 0) {
                        newTile.data = dataHash[1]
                    } else { //key at last interval
                        newTile.data = dataHash[key - 1]
                    }

                    try {
                        newTile.encodedData = encodePaddedViaNativeCache(
                            newTile.data as ByteArray,
                            newTile.coordHash,
                            doEdgeBlending,
                        )
                        if (doEdgeBlending) {
                            paddingManager.blendEdges(newTile, tileCache, 2)
                        }
                        newTile.needsBind = true
                        tileCache.updateTile(newTile)
                        newTile.state = TileState.Ready
                        notifyEncodedTileReady(newTile.coord)
                        newTile.data = null
                    } catch (e: NullPointerException) {
                        MapsGLDebug.logE(
                            "XWeatherEncodedTileSource",
                            "onTileLoaded() newTile.data was null for ${newTile.coordHash}"
                        )
                    }

                }

                dataHash.clear()
            } // end intervls != null
            else { // intervals == null
                if (pr.ON) pr.p(
                    TAG,
                    pr.backfillEdge,
                    "onTileLoaded() about to loop through intervals data, but intervals are null!!}"
                )
                tile.encodedData = encodePaddedViaNativeCache(
                    tempMultiIntervalByteArray,
                    tile.coordHash,
                    doEdgeBlending,
                )
                tile.state = TileState.Processing

                if (doEdgeBlending) {
                    paddingManager.blendEdges(tile, tileCache, 3)
                }
                tile.data = null
                tile.state = TileState.Ready
                tile.needsBind = true
                tileCache.updateTile(tile)
                notifyEncodedTileReady(tile.coord)

                if (tileCache.pendingCount == 0 && _shouldTriggerLoadCompleteEvent) {
                    if (pr.ON) pr.p(TAG, pr.groupTrigger, "groupTrigger LoadComplete for id: $id")
                    ImageTileSource._apiEvent.value = RasterTileApiEvent.Reload(true) //this is needed
                    //trigger(DataSourceEvents.LoadComplete(sourceID = id))
                    //_shouldTriggerLoadCompleteEvent = false
                }

                if (tileCache.pendingCount == 0) {
                    if (pr.ON) {
                        pr.p(TAG, pr.downloadsDone, "tileCache.pendingCount: 0")
                    }
                } else if (pr.ON) {
                    pr.p(TAG, pr.downloadsDone, "tileCache.pendingCount: ${tileCache.pendingCount}")
                }
            }

            //TODO: Commenting this out doesn't have as much of an effect as anticipated...
            if (pr.ON) pr.p(TAG, pr.flicker, "onTileLoaded() end, removing from _pending: ${tile.coordHash} ")
            tileCache.setPending(false, tile) // 'tile' here is the representative tile passed in

            if (pr.ON) pr.p(TAG, pr.flicker, " onTileLoaded() B tileCache.bindlist.size: ${tileCache.bindList.size}")
        }
    }

    /**
     * Handles the coordinate math and wrapping for a single edge backfill.
     */
    /**
     * Handles the coordinate math and wrapping for a single edge backfill.
     * This version correctly handles Zoom 1 and world wraparound.
     */
    private fun fillEdge(destTile: TileType, sourceTile: TileType) {
        val destCoord = destTile.coord
        val sourceCoord = sourceTile.coord

        val initialDx = sourceCoord.x - destCoord.x
        val dy = sourceCoord.y - destCoord.y
        val dim = 1 shl destCoord.z

        // Case: Same tile (usually Zoom 0 world tile)
        if (initialDx == 0 && dy == 0) {
            if (destCoord.z == 0) {
                val destData = destTile.encodedData
                val sourceData = sourceTile.encodedData
                if (destData != null && sourceData != null) {
                    destData.backfillEdge(sourceData, -1, 0)
                    destData.backfillEdge(sourceData, 1, 0)
                }
            }
            return
        }

        val destData = destTile.encodedData ?: return
        val sourceData = sourceTile.encodedData ?: return

        // 1. Check Direct Neighbor (Distance must be 1)
        if (Math.abs(initialDx) <= 1 && Math.abs(dy) <= 1) {
            destData.backfillEdge(sourceData, initialDx, dy)
        }

        // 2. Check Wraparound Neighbor (Distance must be dim - 1)
        // At Z=1, dim=2, so dim-1 is 1. This means the same tile is both
        // a direct neighbor and a wraparound neighbor.
        if (dim > 1 && Math.abs(dy) <= 1) {
            var wrapDx = initialDx

            if (initialDx == 1 - dim) {
                // Source is 0, Dest is 1 (Z=1) or Source is 0, Dest is Max
                wrapDx = 1
                destData.backfillEdge(sourceData, wrapDx, dy)
                if (pr.ON) pr.p(TAG, pr.wrapFix, "Wraparound Right Edge applied")
            } else if (initialDx == dim - 1) {
                // Source is 1, Dest is 0 (Z=1) or Source is Max, Dest is 0
                wrapDx = -1
                destData.backfillEdge(sourceData, wrapDx, dy)
                if (pr.ON) pr.p(TAG, pr.wrapFix, "Wraparound Left Edge applied")
            }
        }
    }

    /**
     * Pads one `originalSize`×`originalSize` RGBA strip in native and returns deferred [EncodedData] (no cache hop).
     */
    private fun encodePaddedViaNativeCache(
        rgba: ByteArray,
        coordKeySuffix: String,
        doEdgeBlendingArg: Boolean,
    ): EncodedData {
        val expected = DataPool.originalSize * DataPool.originalSize * 4
        require(rgba.size == expected) {
            "encodePaddedViaNativeCache: expected $expected bytes, got ${rgba.size} (id=$id suffix=$coordKeySuffix)"
        }
        val padded = tileCache.nativeCache.padEncodedRgbaToPaddedByteArray(
            rgba,
            DataPool.originalSize,
            padding,
            id == RADAR_ENCODED_ID,
        ) ?: error("native pad failed id=$id suffix=$coordKeySuffix")
        return EncodedData(
            byteArrayOf(),
            doEdgeBlendingArg,
            padding,
            id,
            deferPadToNativePipeline = true,
        ).also { it.paddedData = padded }
    }

    private fun getByteArrayChunkWidth(
        bitmapData: ByteArray,
        imageWidth: Int,
        chunkIndex: Int,
        bytesPerPixel: Int = 4
    ): ByteArray {

        val bytesPerRow = (imageWidth * 512) * bytesPerPixel

        val imageHeight = 512 // bitmapData.size / bytesPerRow
        val chunkWidth = 512

        val outputChunkBytesPerRow = chunkWidth * bytesPerPixel
        val outputChunkSize = outputChunkBytesPerRow * imageHeight
        val outputChunkData = ByteArray(outputChunkSize)

        // Calculate the starting X offset (in bytes) within each row for the desired chunk
        val chunkStartXOffsetBytes = chunkIndex * chunkWidth * bytesPerPixel

        // Copy the relevant segment from each row of the input data to the output data
        for (y in 0 until imageHeight) {
            // Start index of the current row in the input buffer
            val inputRowStartIndex = y * bytesPerRow
            // Start index of the segment to copy within the current input row
            val inputSegmentStartIndex = inputRowStartIndex + chunkStartXOffsetBytes
            // Start index of the current row in the output buffer
            val outputRowStartIndex = y * outputChunkBytesPerRow

            System.arraycopy(
                bitmapData,         // Source array
                inputSegmentStartIndex, // Start position in source
                outputChunkData,    // Destination array
                outputRowStartIndex,  // Start position in destination
                outputChunkBytesPerRow // Number of bytes to copy
            )
        }
        return outputChunkData
    }

    override fun addConsumer(consumer: DataSourceConsumer) {

    }

    /**
     * Removes a consumer
     * @param consumer: The consumer to be removed
     */
    override fun removeConsumer(layerId: String) {}

    fun extractValidTimes(jsonString: String): List<String> {
        val validTimesList = mutableListOf<String>()

        try {
            // 1. Parse the top-level JSON array (e.g., [[...]])
            val topLevelArray = JSONArray(jsonString)

            // 2. Get the inner JSON array (e.g., [{...}, {...}, ...])
            //    We assume the structure always has the inner array at index 0.
            if (topLevelArray.length() > 0) {
                val innerArray = topLevelArray.getJSONArray(0)

                // 3. Get the first JSON object from the inner array
                //    We assume the validTimes are in the first object.
                if (innerArray.length() > 0) {
                    val firstObject: JSONObject = innerArray.getJSONObject(0)

                    // 4. Get the "validTimes" JSON array from the object
                    if (firstObject.has("validTimes")) { // Check if the key exists
                        val timesArray: JSONArray = firstObject.getJSONArray("validTimes")

                        // 5. Iterate through the times array and add strings to our list
                        for (i in 0 until timesArray.length()) {
                            val timeString: String = timesArray.getString(i)
                            validTimesList.add(timeString)
                        }
                    } else {
                        MapsGLDebug.trace("Warning: 'validTimes' key not found in the first object.")
                    }
                } else {
                    MapsGLDebug.trace("Warning: Inner array is empty.")
                }
            } else {
                MapsGLDebug.trace("Warning: Top-level array is empty.")
            }

        } catch (e: JSONException) {
            // Handle potential errors during JSON parsing (e.g., invalid format)
            MapsGLDebug.trace("Error parsing JSON string: ${e.message}")
            e.printStackTrace()
            // Return empty list on error
            return emptyList()
        }

        return validTimesList
    }

    private fun blendByteArrays(
        byteArray1: ByteArray,
        byteArray2: ByteArray,
        blendFactor: Float = 0.5f // Default to a 50% blend
    ): ByteArray {

        // 1. Input Validation
        if (byteArray1.size != byteArray2.size) {
            throw IllegalArgumentException(
                "Input byte arrays must have the same size. " +
                    "byteArray1 size: ${byteArray1.size}, byteArray2 size: ${byteArray2.size}"
            )
        }

        // Ensure blendFactor is within the valid range [0.0, 1.0]
        val clampedBlendFactor = blendFactor.coerceIn(0.0f, 1.0f)
        val baseFactor = 1.0f - clampedBlendFactor

        val size = byteArray1.size
        val result = ByteArray(size) // Create the output array

        // 2. Iterate and Blend Each Byte
        for (i in 0 until size) {
            // Get bytes and treat them as unsigned integers (0-255) for calculation
            val byte1Unsigned = byteArray1[i].toInt() and 0xFF
            val byte2Unsigned = byteArray2[i].toInt() and 0xFF

            // Perform linear interpolation using floating-point math
            val blendedValueFloat = (byte1Unsigned * baseFactor) + (byte2Unsigned * clampedBlendFactor)

            // Round, clamp to valid byte range (0-255), and convert back to Byte
            val blendedByteValue = blendedValueFloat
                .roundToInt()       // Round to nearest integer
                .coerceIn(0, 255) // Clamp to unsigned byte range
                .toByte()           // Convert back to signed Byte type

            result[i] = blendedByteValue
        }
        // 3. Return the Result
        return result
    }
}

typealias DataType = EncodedTimeSeriesData
