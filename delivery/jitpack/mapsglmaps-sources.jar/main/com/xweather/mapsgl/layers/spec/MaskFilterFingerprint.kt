package com.xweather.mapsgl.layers.spec

import com.xweather.mapsgl.style.Expression
import org.json.JSONObject
import java.security.MessageDigest
import java.util.TreeMap

/**
 * Stable short suffix for auto-generated mask layer ids when a [LayerMaskLayerConfig.maskFilter]
 * is present (parity with the JS SDK appending a base64 fragment of `JSON.stringify(filter)`).
 */
internal object MaskFilterFingerprint {

    fun compactSuffix(filter: Expression): String {
        val json = jsonStableString(filter.raw)
        val digest = MessageDigest.getInstance("SHA-256").digest(json.toByteArray(Charsets.UTF_8))
        return buildString(10) {
            for (i in 0 until 5) {
                val b = digest[i].toInt() and 0xFF
                append(((b + 0x100).toString(16)).substring(1))
            }
        }
    }

    /**
     * Deterministic JSON-ish text for [raw] (Map keys sorted) so identical logical filters hash the same.
     */
    private fun jsonStableString(raw: Any?): String = when (raw) {
        null -> "null"
        is String -> JSONObject.quote(raw)
        is Boolean, is Byte, is Short, is Int, is Long, is Float, is Double -> raw.toString()
        is Enum<*> -> JSONObject.quote(raw.name)
        is List<*> -> "[" + raw.joinToString(",") { jsonStableString(it) } + "]"
        is Array<*> -> "[" + raw.joinToString(",") { jsonStableString(it) } + "]"
        is Map<*, *> -> {
            val sorted = TreeMap<String, Any?>()
            for ((k, v) in raw) sorted[k.toString()] = v
            "{" + sorted.entries.joinToString(",") { (k, v) ->
                JSONObject.quote(k) + ":" + jsonStableString(v)
            } + "}"
        }
        else -> JSONObject.quote(raw.toString())
    }
}
