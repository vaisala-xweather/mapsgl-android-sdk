package com.xweather.mapsgl.layers.spec

import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.ContourPaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.HeatmapLayerPaint
import com.xweather.mapsgl.style.HeatmapPaint
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.ParticlePaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.RasterPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType
import com.xweather.mapsgl.weather.WeatherConfiguration

enum class MaskLayerKind {
    NONE,
    LAND,
    WATER,
    /**
     * GLES stencil: all features in the MVT `transportation` source-layer from [GlStencilOsm] (same
     * tiles as marine land/water). Weather draws only along road geometry (line ribbon), similar to [WATER].
     */
    TRANSPORTATION,
    /**
     * GLES stencil: country border geometry from [com.xweather.mapsgl.map.mapbox.GlStencilOsm] tiles —
     * Mapbox Streets `admin` (admin_level 0) or MapsGL `boundary` (admin_level 2). Requires
     * [BitmapLayerDescriptor.maskCountryIso3166Alpha2] (e.g. `"US"`, `"ES"`). Draw only along matched
     * borders (line ribbon), same stencil test as [WATER].
     */
    COUNTRY,
}

/**
 * How multiple [StencilMaskLayerRef] entries combine in the stencil buffer (mirrors JS `mask.mode`).
 */
enum class StencilMaskCombineMode {
    /** Every mask slot must be set (intersection). */
    ALL,
    /** At least one mask slot must be set (union). */
    ANY,
}

/**
 * References a Mapbox style layer (typically [com.xweather.mapsgl.layers.tile.VectorTileLayer]) by id.
 * That layer’s [com.xweather.mapsgl.layers.tile.VectorTileLayer.sourceLayer] and [filter] define which
 * MVT features fill this stencil slot.
 */
data class StencilMaskLayerRef(val layerId: String)

/**
 * JS-style layer mask convenience for weather layers:
 * - `layers`: explicit layer refs (optionally auto-create built-in weather masks with [overrides])
 * - `type`: quick `water`/`land` mask
 * - `mode`/`invert`: same semantics as JS SDK
 *
 * Resolved by [com.xweather.mapsgl.map.MapController.addWeatherLayer] into [StencilLayerMaskSpec].
 */
enum class LayerMaskType {
    /**
     * Mask to **water** geometry (built-in water mask layer); weather draws only where water stencil is set.
     */
    WATER,

    /**
     * Mask to **land**: uses the same water stencil source with inverted semantics so weather draws on land.
     */
    LAND,
}

/**
 * One entry in [LayerMaskSpec.layers]: either an existing map layer id or a **weather layer code**
 * used to auto-create a mask layer.
 *
 * When [id] matches an existing layer, that layer’s geometry is used as a stencil mask as-is.
 * When it does not exist but matches a [com.xweather.mapsgl.weather.LayerCode] (by [com.xweather.mapsgl.weather.LayerCode.value]
 * or enum name), [com.xweather.mapsgl.map.MapController.addWeatherLayer] creates a helper mask layer
 * (default id `"${id}::mask"`, or [maskId] if set) with optional [overrides].
 *
 * @property id Existing layer id **or** weather product id / enum name for auto-creation.
 * @property maskId Stable id for the auto-created mask layer; defaults to `"${id}::mask"` plus a
 *   short hash suffix when [maskFilter] is set (JS parity: unique ids per filter without an explicit [maskId]).
 * @property overrides Applied to the [com.xweather.mapsgl.weather.WeatherConfiguration] when a mask layer is auto-created
 *   (for example stroke width on road masks).
 * @property maskFilter Optional Mapbox-style filter applied to the auto-created weather mask layer’s
 *   vector descriptor, and used (with [maskId] null) to derive a unique default [maskId] suffix.
 *
 * @see LayerMaskSpec
 * @see com.xweather.mapsgl.map.MapController.addWeatherLayer
 */
data class LayerMaskLayerConfig(
    val id: String,
    val maskId: String? = null,
    val overrides: ((WeatherConfiguration) -> Unit)? = null,
    val maskFilter: Expression? = null,
)

/**
 * JavaScript SDK–style **`mask`** configuration for weather layers on Android.
 *
 * Set this on supported bitmap-style descriptors ([RasterLayerDescriptor], [SampleLayerDescriptor],
 * [ContourLayerDescriptor], [ParticleLayerDescriptor], [GridLayerDescriptor]) as `layerMask`. When
 * [com.xweather.mapsgl.map.MapController.addWeatherLayer] resolves it to a [StencilLayerMaskSpec]
 * (explicit stencil layer refs, combine mode, invert).
 *
 * **Semantics (aligned with JS)**
 * - [layers]: mask from one or more vector / mask layers. Each [LayerMaskLayerConfig] references an existing
 *   layer id or a known weather [com.xweather.mapsgl.weather.LayerCode] for auto-created masks.
 * - [type]: shorthand for built-in water/land masking; [LayerMaskType.LAND] uses the water mask layer with
 *   inverted semantics (land visible where water stencil is clear).
 * - [mode]: [StencilMaskCombineMode.ALL] (intersection) vs [StencilMaskCombineMode.ANY] (union), mirroring JS `mask.mode`.
 * - [invert]: optional; when `null`, resolution uses `true` for land-type shorthand and `false` otherwise
 *   (see implementation in `MapController`).
 *
 * **Limits**: resolution keeps at most [StencilLayerMaskSpec.MAX_STENCIL_MASK_LAYERS] distinct mask layers; extras are dropped
 * with a log line.
 *
 * At least one of [layers] or [type] must be non-null / non-empty (enforced in `init`).
 *
 * @property layers Ordered list of mask sources (existing layers or auto-created weather masks).
 * @property type Optional built-in water or land mask in addition to (or instead of) [layers].
 * @property mode How multiple mask slots combine in the stencil buffer.
 * @property invert When non-null, passed through to [StencilLayerMaskSpec]; when null, defaults depend on [type].
 *
 * @see StencilLayerMaskSpec
 * @see StencilMaskCombineMode
 * @see com.xweather.mapsgl.map.MapController.addWeatherLayer
 */
data class LayerMaskSpec(
    val layers: List<LayerMaskLayerConfig> = emptyList(),
    val type: LayerMaskType? = null,
    val mode: StencilMaskCombineMode = StencilMaskCombineMode.ALL,
    val invert: Boolean? = null,
) {
    init {
        require(layers.isNotEmpty() || type != null) {
            "layerMask requires non-empty [layers] and/or [type]"
        }
    }
}

/**
 * GLES stencil mask built from one triangle mesh per referenced vector layer, combined per [mode].
 * Up to [MAX_STENCIL_MASK_LAYERS] entries are supported (one stencil bit per slot in the non-sequential
 * combine path; typical GLES stencil buffers expose 8 bits — see [MAX_STENCIL_MASK_LAYERS]).
 *
 * Alternatively (or additionally), [clipBounds] fills a stencil slot from an axis-aligned lat/lon rectangle
 * intersected with each tile — no vector tiles required (e.g. mask to the continental US).
 */
data class StencilLayerMaskSpec(
    val layers: List<StencilMaskLayerRef> = emptyList(),
    val mode: StencilMaskCombineMode = StencilMaskCombineMode.ALL,
    val invert: Boolean = false,
    val clipBounds: LatLonBounds? = null,
) {
    init {
        require(layers.isNotEmpty() || clipBounds != null) {
            "stencilLayerMask requires non-empty [layers] and/or [clipBounds]"
        }
        require(layers.size <= MAX_STENCIL_MASK_LAYERS) {
            "stencilLayerMask supports at most $MAX_STENCIL_MASK_LAYERS layers (got ${layers.size})"
        }
    }

    companion object {
        /**
         * Maximum vector mask layers in one spec. Matches a typical 8-bit stencil buffer’s one-hot
         * bit budget for [com.xweather.mapsgl.map.mapbox.GlStencilMaskRenderer.drawCustomMaskSlotIntoStencil]
         * (`1 shl index`). The sequential-ALL path can combine more geometric passes without bit packing,
         * but this cap keeps the bitmask combine path well-defined. If [clipBounds] is used together with
         * vector masks in the non-sequential path, leave headroom (clip consumes one additional bit).
         */
        const val MAX_STENCIL_MASK_LAYERS = 8

        /** Approximate contiguous United States (WGS84), for demos without boundary vector tiles. */
        val US_CONTIGUOUS_BOUNDS = LatLonBounds(
            westExtent = -124.833,
            southExtent = 24.396,
            eastExtent = -66.949,
            northExtent = 49.384,
        )
    }
}

interface LayerEventEmitter {
    fun on(eventName: String, callback: (Any?) -> Unit)
    fun off(eventName: String)
    fun trigger(eventName: String, data: Any? = null)
}

class LayerEventManager : LayerEventEmitter {
    private val listeners = mutableMapOf<String, MutableList<(Any?) -> Unit>>()

    override fun on(eventName: String, callback: (Any?) -> Unit) {
        listeners.getOrPut(eventName) { mutableListOf() }.add(callback)
    }

    override fun off(eventName: String) {
        listeners.remove(eventName)
    }

    override fun trigger(eventName: String, data: Any?) {
        listeners[eventName]?.forEach { it(data) }
    }
}

interface LayerDescriptor<P : LayerPaint> : LayerEventEmitter {
    var id: String
    val type: LayerType
    var source: String
    var paint: P//LayerPaint
}

interface BitmapLayerDescriptor<P : LayerPaint> : LayerDescriptor<P> {
    var quality: DataQuality
    var mask: MaskLayerKind
    /**
     * When [mask] is [MaskLayerKind.COUNTRY], ISO 3166-1 alpha-2 (e.g. `"US"`, `"ES"`). Ignored for other mask kinds.
     */
    var maskCountryIso3166Alpha2: String?
}

/**
 * Marker for layer descriptors that map to Mapbox **vector** style layers (fill, line, circle, symbol, heatmap).
 * Implementations add [sourceLayer] (MVT layer name, or `null` for GeoJSON) and an optional feature [filter].
 *
 * The type parameter `P` is the paint type serialized via [VectorLayerPaint.asStyleJSON] when the layer is added.
 *
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see com.xweather.mapsgl.layers.tile.VectorTileLayer
 */
interface VectorLayerDescriptor<P : LayerPaint> : LayerDescriptor<P> {
    var sourceLayer: String?
    var filter: Expression?
    /**
     * When true, MapsGL does not register a Mapbox `fill` / `line` / `circle` / `symbol` / `heatmap` style layer.
     * The [com.xweather.mapsgl.layers.tile.VectorTileLayer] still exists for tile/GeoJSON consumers, MVT fetch
     * (e.g. [com.xweather.mapsgl.map.mapbox.GlStencilCustomMaskCoordinator]), and GLES stencil mesh build in
     * [com.xweather.mapsgl.renderers.TileLayerRenderer] — only screen drawing via Mapbox paint is skipped.
     */
    var stencilOnly: Boolean
}

data class RasterLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: RasterLayerPaint = RasterLayerPaint(
        raster = RasterPaint()
    ),
    /**
     * JS-style convenience for custom stencil masks:
     * `mask: { layerIds: ["admin-mask"] }`
     *
     * When non-empty, [com.xweather.mapsgl.map.MapController.addLayer] maps these ids to a
     * [StencilLayerMaskSpec] under GLES stencil mode.
     */
    var maskLayerIds: List<String> = emptyList(),
    /**
     * Single mask layer id shorthand (JS `mask: "layerId"` on a layer). Lowest precedence among
     * stencil mask fields: after [stencilLayerMask], [layerMask], and [maskLayerIds].
     */
    var maskLayerId: String? = null,
    /** JS-style mask convenience; takes precedence over [maskLayerIds] and [maskLayerId] when provided. */
    var layerMask: LayerMaskSpec? = null,
    /**
     * Advanced custom stencil mask configuration. Takes precedence over [maskLayerIds] when set.
     */
    var stencilLayerMask: StencilLayerMaskSpec? = null,
) : BitmapLayerDescriptor<RasterLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override var mask: MaskLayerKind = MaskLayerKind.NONE
    override var maskCountryIso3166Alpha2: String? = null
    override val type: LayerType = LayerType.raster
}

data class SampleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: SampleLayerPaint = SampleLayerPaint(
        sample = SamplePaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE,
    /**
     * Optional stencil mask from
     * arbitrary vector layers (see [StencilLayerMaskSpec]). [maskLayerIds] / [maskLayerId] / [layerMask]
     * are resolved before [addLayer]; this takes precedence over [mask] for GLES stencil clipping.
     */
    var maskLayerIds: List<String> = emptyList(),
    /** Single mask layer id shorthand; see [RasterLayerDescriptor.maskLayerId]. */
    var maskLayerId: String? = null,
    var layerMask: LayerMaskSpec? = null,
    var stencilLayerMask: StencilLayerMaskSpec? = null,
    override var maskCountryIso3166Alpha2: String? = null,
) : BitmapLayerDescriptor<SampleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.sample

    init {
        // This connects the paint's setter to this descriptor's event bus
        paint.sample.eventEmitter = this

        //println(">>> LayerDescriptor: SampleLayerDescriptor init linked to Emitter!")
    }
}

data class ContourLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: ContourLayerPaint = ContourLayerPaint(
        sample = SamplePaint(),
        contour = ContourPaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE,
    var maskLayerIds: List<String> = emptyList(),
    var maskLayerId: String? = null,
    var layerMask: LayerMaskSpec? = null,
    var stencilLayerMask: StencilLayerMaskSpec? = null,
    override var maskCountryIso3166Alpha2: String? = null,
) : BitmapLayerDescriptor<ContourLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.sample

    init {
        paint.sample.eventEmitter = this
    }
}

data class ParticleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: ParticleLayerPaint = ParticleLayerPaint(
        sample = SamplePaint(),
        particle = ParticlePaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE,
    var maskLayerIds: List<String> = emptyList(),
    var maskLayerId: String? = null,
    var layerMask: LayerMaskSpec? = null,
    var stencilLayerMask: StencilLayerMaskSpec? = null,
    override var maskCountryIso3166Alpha2: String? = null,
) : BitmapLayerDescriptor<ParticleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.particles
}

/**
 * Descriptor for a Mapbox **fill** layer: polygon features filled with optional outline, backed by a vector or
 * GeoJSON source.
 *
 * Add the source with [com.xweather.mapsgl.map.MapController.addSource], then register this descriptor via
 * [com.xweather.mapsgl.map.MapController.addLayer]. Renders as a [VectorTileLayer] using Mapbox’s native fill layer.
 *
 * For **vector tiles**, set [sourceLayer] to the MVT layer containing polygons. For **GeoJSON**, use `null` on
 * [sourceLayer] so the whole collection is used. [filter] restricts which features participate.
 *
 * @property id Unique layer id within the controller.
 * @property source Id of an existing vector or GeoJSON source.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON-only sources.
 * @property paint Fill color and opacity. Outline is drawn on a companion Mapbox `line` layer
 * (`{layerId}::stroke`); width comes from [com.xweather.mapsgl.style.FillLayerPaint.scaleOutlineThickness].
 * @property filter Optional Mapbox filter expression.
 *
 * @see com.xweather.mapsgl.style.FillLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class FillLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: FillLayerPaint = FillLayerPaint(
        fill = FillPaint(),
        stroke = StrokePaint()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
) : VectorLayerDescriptor<FillLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.fill
}

/**
 * Descriptor for a Mapbox **line** layer: line strings (and polygon rings when applicable) stroked from a vector
 * or GeoJSON source.
 *
 * **Setup** matches other [VectorLayerDescriptor] types: add the source with
 * [com.xweather.mapsgl.map.MapController.addSource], then register this descriptor with
 * [com.xweather.mapsgl.map.MapController.addLayer]. The runtime implementation is a
 * [com.xweather.mapsgl.layers.tile.VectorTileLayer] backed by Mapbox’s native `line` style layer.
 *
 * **Sources**
 * - **Vector tiles**: set [sourceLayer] to the MVT layer name that contains line geometry.
 * - **GeoJSON**: set [sourceLayer] to `null` when the whole feature collection should be used.
 *
 * **Paint** ([paint]) is a [com.xweather.mapsgl.style.LineLayerPaint] wrapping [com.xweather.mapsgl.style.StrokePaint];
 * it maps to Mapbox `line-color`, `line-opacity`, `line-width`, `line-join`, `line-cap`, and `line-miter-limit`.
 * Join, cap, and miter limit are also honored when this layer is used as a **GLES stencil mask** source (road ribbons,
 * custom mask pipelines).
 *
 * **Stencil-only lines**: when [stencilOnly] is `true`, MapsGL still fetches tiles and builds stencil geometry from
 * this layer’s features, but does **not** add a visible Mapbox `line` layer. Use that for mask-only line sources
 * (for example motorways referenced from [LayerMaskSpec] on a weather layer), analogous to JS layers that exist
 * primarily for `mask.layers`.
 *
 * Example (visible road line, then reference its id from a weather layer’s [LayerMaskSpec]):
 * ```
 * controller.addSource("roads", vectorSourceDescriptor)
 * controller.addLayer(
 *     LineLayerDescriptor(
 *         id = "road-motorway",
 *         source = "roads",
 *         sourceLayer = "transportation",
 *         paint = LineLayerPaint(stroke = StrokePaint().apply {
 *             thickness = StyleValue.Constant(5.0)
 *             lineJoin = StyleValue.Constant(LineJoin.MITER)
 *             lineCap = StyleValue.Constant(LineCap.ROUND)
 *         }),
 *         filter = Expression.eq(Expression.get("class"), Expression.literal("motorway"))
 *     )
 * )
 * // controller.addWeatherLayer(..., layerMask = LayerMaskSpec(layers = listOf(LayerMaskLayerConfig(id = "road-motorway"))))
 * ```
 *
 * @property id Unique layer id within the map controller (referenced by [LayerMaskSpec] / [StencilLayerMaskSpec]
 *   when used as a mask).
 * @property source Id of an already-added vector or GeoJSON source.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON-only usage.
 * @property paint Line stroke styling serialized to Mapbox `line-*` paint properties.
 * @property filter Optional Mapbox filter expression; narrows which features draw and which contribute to masks.
 * @property stencilOnly When `true`, skip registering a visible Mapbox line layer; still drive stencil mesh build.
 *   See [VectorLayerDescriptor.stencilOnly].
 *
 * @see com.xweather.mapsgl.style.LineLayerPaint
 * @see com.xweather.mapsgl.style.StrokePaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see LayerMaskSpec
 */
data class LineLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: LineLayerPaint = LineLayerPaint(
        stroke = StrokePaint()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
) : VectorLayerDescriptor<LineLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.line
}

/**
 * Descriptor for a Mapbox **circle** layer: points rendered as filled disks with optional stroke, driven by a
 * vector or GeoJSON source.
 *
 * Register the backing source first ([com.xweather.mapsgl.map.MapController.addSource]), then add this layer with
 * [com.xweather.mapsgl.map.MapController.addLayer]. The layer is implemented as a [VectorTileLayer] over Mapbox’s
 * native circle layer.
 *
 * **Sources**
 * - **Vector tile** source ([com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor]): set [sourceLayer]
 *   to the MVT layer name. [filter] may narrow features.
 * - **GeoJSON** source ([com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor]): set [sourceLayer] to
 *   `null`; the whole [com.mapbox.geojson.FeatureCollection] is used (see product examples such as earthquakes).
 *
 * **Paint** is held in [paint] ([CircleLayerPaint]): fill color, stroke, and circle radius map to Mapbox
 * `circle-color`, `circle-radius`, `circle-stroke-*`, etc. Use [com.xweather.mapsgl.style.StyleValue] and
 * [Expression] for data-driven styling (e.g. magnitude-based radius).
 *
 * **Stacking**: the `beforeID` argument to [com.xweather.mapsgl.map.MapController.addLayer] controls insertion order
 * relative to existing style layers (see that method’s KDoc).
 *
 * @property id Stable layer identifier; must be unique within the map controller.
 * @property source Identifier of an already-added source whose features this layer draws.
 * @property sourceLayer For vector tiles, the source layer name inside the MVT; for GeoJSON-only sources, use `null`.
 * @property paint Circle fill, stroke, and geometry styling converted to Mapbox style JSON.
 * @property filter Optional Mapbox filter expression; combined with source-layer filtering when [sourceLayer] is set.
 *
 * @see com.xweather.mapsgl.style.CircleLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see com.xweather.mapsgl.layers.tile.VectorTileLayer
 */
data class CircleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: CircleLayerPaint = CircleLayerPaint(
        fill = FillPaint(),
        stroke = StrokePaint(),
        circle = CirclePaint()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
) : VectorLayerDescriptor<CircleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.circle
}

/**
 * Descriptor for a Mapbox **symbol** layer using [SymbolLayerPaint]: icons, text labels, and optional fill/stroke.
 *
 * Use after the backing source is registered ([com.xweather.mapsgl.map.MapController.addSource]). Typical sources are
 * **vector tiles** with a named [sourceLayer]; **GeoJSON** point/line data can use `null` on [sourceLayer] when the
 * style does not target a specific MVT layer.
 *
 * For **gridded** encoded products (spacing, [SamplePaint], etc.), use [GridLayerDescriptor] with [GridLayerPaint]
 * instead—this type stays Mapbox-style-only so `paint` is not confused with grid sidecar fields.
 *
 * @property id Unique layer id.
 * @property source Vector or GeoJSON source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON when applicable.
 * @property paint Icon, text, and optional fill/stroke configuration.
 * @property filter Optional Mapbox filter.
 *
 * @see com.xweather.mapsgl.style.SymbolLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class SymbolLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: SymbolLayerPaint = SymbolLayerPaint(
        icon = IconPaint(),
        text = emptyList()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
) : VectorLayerDescriptor<SymbolLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.symbol
}

/**
 * Descriptor for **symbol-style** layers that share [GridLayerPaint] with [SymbolLayerDescriptor] but add **masking**
 * and **data quality** knobs used by gridded and dense icon workflows (e.g. encoded-grid sidecars).
 *
 * Register the source, then [com.xweather.mapsgl.map.MapController.addLayer]. [mask] participates in land/water
 * masking where the map pipeline supports it; [quality] hints requested tile or sampling fidelity for applicable
 * sources. The initializer wires [paint.sample]’s event emitter to this descriptor for paint-driven events.
 *
 * @property id Unique layer id.
 * @property source Backing source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON when applicable.
 * @property mask Land/water/none mask for symbol placement.
 * @property paint Icon, text, optional sample grid, and fill/stroke.
 * @property filter Optional feature filter.
 * @property quality Requested [DataQuality] for tile or asset resolution where used.
 *
 * @see com.xweather.mapsgl.style.GridLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class GridLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    var mask: MaskLayerKind = MaskLayerKind.NONE,
    override var paint: GridLayerPaint = GridLayerPaint(
        icon = IconPaint(),
        text = emptyList()
    ),
    override var filter: Expression? = null,
    var quality: DataQuality = DataQuality.medium,
    var maskLayerIds: List<String> = emptyList(),
    var maskLayerId: String? = null,
    var layerMask: LayerMaskSpec? = null,
    var stencilLayerMask: StencilLayerMaskSpec? = null,
    /** See [BitmapLayerDescriptor.maskCountryIso3166Alpha2] when [mask] is [MaskLayerKind.COUNTRY]. */
    var maskCountryIso3166Alpha2: String? = null,
    override var stencilOnly: Boolean = false,
) : VectorLayerDescriptor<GridLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.symbol

    init {
        paint.sample?.eventEmitter = this
    }
}

/**
 * Descriptor for a Mapbox **heatmap** layer: point density visualized as a color ramp, backed by vector or GeoJSON
 * point data.
 *
 * Add the source first, then [com.xweather.mapsgl.map.MapController.addLayer]. [paint] ([HeatmapLayerPaint]) maps
 * to Mapbox `heatmap-color`, `heatmap-weight`, `heatmap-intensity`, `heatmap-radius`, and `heatmap-opacity`.
 *
 * Use [sourceLayer] for MVT point layers; `null` for GeoJSON when the source is a single feature collection of points.
 *
 * @property id Unique layer id.
 * @property source Point-capable vector or GeoJSON source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON.
 * @property paint Heatmap ramp, radius, intensity, and weight.
 * @property filter Optional feature filter.
 *
 * @see com.xweather.mapsgl.style.HeatmapLayerPaint
 * @see com.xweather.mapsgl.style.HeatmapPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class HeatmapLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: HeatmapLayerPaint = HeatmapLayerPaint(
        heatmap = HeatmapPaint()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
) : VectorLayerDescriptor<HeatmapLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.heatmap
}