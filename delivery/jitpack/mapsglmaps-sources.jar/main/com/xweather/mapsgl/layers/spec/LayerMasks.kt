package com.xweather.mapsgl.layers.spec

import com.xweather.mapsgl.weather.WeatherConfiguration
import com.xweather.mapsgl.weather.setLineStrokeThickness

/**
 * Factory helpers mirroring the [MapsGL JS `LayerMaskSpecification`](https://www.xweather.com/docs/mapsgl/advanced/masks).
 *
 * Use on weather layer descriptors ([com.xweather.mapsgl.layers.spec.SampleLayerDescriptor.layerMask],
 * etc.) or raster descriptors ([RasterLayerDescriptor.layerMask]).
 */
object LayerMasks {

    /**
     * JS: `mask: { type: 'land' }` — temperatures (and other weather tiles) only over land.
     *
     * Prefer [com.xweather.mapsgl.layers.spec.MaskLayerKind.LAND] on [com.xweather.mapsgl.layers.spec.BitmapLayerDescriptor.mask]
     * when you only need the built-in marine/land stencil without extra mask layers.
     */
    fun land(invert: Boolean? = null): LayerMaskSpec = LayerMaskSpec(
        type = LayerMaskType.LAND,
        invert = invert,
    )

    /** JS: `mask: { type: 'water' }` */
    fun water(invert: Boolean? = null): LayerMaskSpec = LayerMaskSpec(
        type = LayerMaskType.WATER,
        invert = invert,
    )

    /**
     * JS: `mask: { layerIds: ['admin-mask'] }` (shorthand for a single custom mask layer).
     */
    fun layerIds(
        vararg ids: String,
        mode: StencilMaskCombineMode = StencilMaskCombineMode.ALL,
        invert: Boolean = false,
    ): LayerMaskSpec = LayerMaskSpec(
        layers = ids.map { LayerMaskLayerConfig(id = it) },
        mode = mode,
        invert = invert,
    )

    /**
     * JS: `mask: { layers: [{ id: 'countries' }, { id: 'road-motorway' }], mode: 'all' }`.
     */
    fun layers(
        vararg configs: LayerMaskLayerConfig,
        mode: StencilMaskCombineMode = StencilMaskCombineMode.ALL,
        invert: Boolean? = null,
    ): LayerMaskSpec = LayerMaskSpec(
        layers = configs.toList(),
        mode = mode,
        invert = invert,
    )

    /**
     * JS docs “countries + motorways” example: built-in land ∩ visible motorway lines.
     *
     * - `"countries"` resolves to built-in OSM land (not a fill `countries::mask` layer).
     * - [roadLayerId] is an existing line layer or a [com.xweather.mapsgl.weather.LayerCode] (e.g. `road-motorway`).
     */
    fun landAndRoads(
        roadLayerId: String = "road-motorway",
        roadMaskId: String? = "road-motorway::mask",
        roadStrokeThickness: Double? = null,
        mode: StencilMaskCombineMode = StencilMaskCombineMode.ALL,
    ): LayerMaskSpec {
        val roadOverrides: ((WeatherConfiguration) -> Unit)? = roadStrokeThickness?.let { thickness ->
            { cfg -> cfg.setLineStrokeThickness(thickness) }
        }
        return layers(
            LayerMaskLayerConfig(id = "countries"),
            LayerMaskLayerConfig(
                id = roadLayerId,
                maskId = roadMaskId,
                overrides = roadOverrides,
            ),
            mode = mode,
        )
    }
}
