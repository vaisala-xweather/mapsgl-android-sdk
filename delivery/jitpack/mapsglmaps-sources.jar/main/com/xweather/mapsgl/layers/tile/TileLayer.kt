/**
 * TileLayer.kt
 *
 *  Adapted from IOS version
 *
 * @author Jason Suto 12/22/23
 *
 **/

package com.xweather.mapsgl.layers.tile

import android.content.Context
import android.os.Looper
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.series.AnyTimeSeries
import com.xweather.mapsgl.data.series.Data
import com.xweather.mapsgl.data.series.TimeSeries
import com.xweather.mapsgl.data.series.TimeSeriesAnimator
import com.xweather.mapsgl.data.series.TimeSeriesAnimatorOptions
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.geo.Viewport
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.LayerRenderer
import com.xweather.mapsgl.renderers.TileLayerRenderer
import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TilePyramid
import com.xweather.mapsgl.tiles.TileRenderable
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType
import com.xweather.mapsgl.types.math_type.ValueRange
import com.xweather.mapsgl.util.MapsGLDebug
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.sinh
import kotlin.time.Duration

private const val TAG = "TileLayer"

data class RenderContext<RenderableType>(
    override var paintStyle: LayerPaint, //PaintStyle,
    override var elapsedTime: Duration = Duration.ZERO,
    override var renderables: List<RenderableType> = listOf(), //List<TileRenderable<DataType>> = emptyList()
    //var projectionMatrix: ProjectiveTransform3D = ProjectiveTransform3D.identity,
    override var zoomLevel: Double = 0.0
) : LayerRenderContext<RenderableType>

interface TileLayerConfig /*: WebGLLayerConfig*/ {
    /** * Quality to use when rendering data.   */
    var quality: DataQuality

    /**  * Range of values to use when rendering data.  */
    var dataRange: ValueRange
    /**
     * Offset to apply to the map's zoom level when requesting data from the data source. This is useful to render data
     * at a different zoom level than the map's zoom level.
     */
    //var zoomOffset: Int
}

/** Represents a layer that renders data from a tile-based data source.
 *   This is the base class for all tile-based layers and is not intended to be used directly.
 */
open class TileLayer(
    final override var id: String,
    override var source: TileSource<TileData>,
    override var paint: LayerPaint,//SampleLayerPaint, //PaintStyle
    var tileLayerRenderer: TileLayerRenderer<TileData, LayerRenderContext<Any>>, //private?
    var zoomOffset: Int,
    val externalScope: CoroutineScope,
    var quality: DataQuality = DataQuality.exact,

    ) : MapLayer<TileData, LayerRenderContext<Any>> {

    var isRadar = false
    /** GLES stencil base mask kind for this layer (LAND/WATER/TRANSPORTATION/COUNTRY). */
    var glStencilMaskKind: MaskLayerKind = MaskLayerKind.NONE
    /** Optional ISO alpha-2 for COUNTRY base masks. */
    var glStencilMaskCountryIso: String? = null
    /** Optional custom multi-layer stencil mask (JS-style `mask.layerIds`). */
    var stencilLayerMask: StencilLayerMaskSpec? = null
    /**
     * When true, [glStencilMaskKind] [MaskLayerKind.LAND] runs first (marine clip), then line-only
     * [stencilLayerMask] layers are intersected on land (highways on land, not oceans).
     */
    var hybridLandWithCustomLineMask: Boolean = false

    companion object {
        private val dataQualityHash = mapOf(
            DataQuality.exact to 1f,
            DataQuality.high to 0.75f,
            DataQuality.medium to 0.5f,
            DataQuality.normal to 0.5f,
            DataQuality.low to 0.25f,
            DataQuality.minimal to 0.25f
        )
    }

    enum class TileLayerEventType {
        TILES_LOADING_STATUS_CHANGED, // Example: pass a boolean or count
        DATA_UPDATED,              // Example: pass metadata about the update
        SPECIFIC_ACTION_TRIGGERED,
        FINISHED_DRAWING,
        // Your custom event
        // Add more event types as needed
    }

    interface TileLayerEventListener {
        fun onTileLayerEvent(layerId: String, eventType: TileLayerEventType, data: Any? = null)
    }

    private val eventListeners = mutableListOf<TileLayerEventListener>() // Or TileLayerEventListenerV2


    fun addTileLayerEventListener(listener: TileLayerEventListener) { // Or TileLayerEventListenerV2
        if (!eventListeners.contains(listener)) {
            eventListeners.add(listener)
        }
    }

    fun removeTileLayerEventListener(listener: TileLayerEventListener) { // Or TileLayerEventListenerV2
        eventListeners.remove(listener)
    }

    /**
     * Triggers a specific event to all registered listeners.
     * @param eventType A string identifying the type of event.
     * @param data Optional data associated with the event.
     */
    protected fun triggerEvent(eventType: TileLayerEventType, data: Any? = null) { // Or eventType: TileLayerEventType
        // Consider running on a specific thread if needed (e.g., main thread for UI updates)
        // For simplicity, this triggers on the calling thread.
        externalScope.launch { // Or another appropriate scope
            eventListeners.forEach { listener ->
                listener.onTileLayerEvent(id, eventType, data)
            }
        }
    }

    private var zoomVar = 0.0
    var bounds: LatLonBounds? = null
    private var oldBounds: LatLonBounds? = null
    private var tileBounds: TileBounds? = null
    private var oldTileBounds: TileBounds? = null
    final override var eventDispatcher = EventDispatcher()
    private var visibleTileCoords: List<TileCoord> = mutableListOf()
    val pyramid: TilePyramid<DataType> = TilePyramid(this)
    override var alpha = 1.0f
    override var numW: Int = 0
    override var numH: Int = 0
    override var waitingOnDL: Boolean = false
    override var wasWaitingOnDL: Boolean = false
    private var offset = 0
    private var zoom = 0.0
    private var initialLoad = true
    private var oldRequestBounds: LatLonBounds? = null
    var persistentTileBounds: TileBounds? = null
    private var renderables: MutableList<TileRenderable<DataType>> = mutableListOf()

    // Rendering coordinates do not need to be recomputed every frame.
    // We only mark them dirty when bounds/viewport are updated via requestVisibleTiles().
    private var renderBoundsDirty: Boolean = true
    private var renderablesDirty: Boolean = true
    /**
     * [onMove] skips [requestVisibleTiles] while the timeline plays to limit download churn, but the
     * render path still recomputes meshes at the new map zoom each frame. Without a request at the new
     * Z, encoded tiles stay one or more levels behind until map idle or an extra zoom gesture.
     */
    private var lastOnMoveDisplayTileZ: Int? = null
    var alreadyRequested: MutableList<TileCoord> = mutableListOf()
    override var animator: TimeSeriesAnimator<Data>? = null
    override var renderer: LayerRenderer<Any>
        get() = TODO("Not yet implemented")
        set(value) {}

    var z = 0.0
    private var maxVal = 0
    private var latRad = 0.0
    override var layerRenderContext: LayerRenderContext<Any> = RenderContext(paint)
    lateinit var drawContext: Context
    override var timeSeries: AnyTimeSeries? = null
    var code = ""
    var message = ""

    override var mapController: MapController? = null
        get() = field
        set(value) {
            field = value
        }

    override var isDirty: Boolean = false
    override var visible: Boolean = true
    override var enabled: Boolean = false

    override val viewport: Viewport?
        get() = mapController?.viewport

    val tileRequestOptions: TileRequestOptions = TileRequestOptions(isRadar = (id == "radar_REFC_PRATE_PTYPESMPL"))

    var lastTileBounds: TileBounds? = null
    var currentTileBounds: TileBounds? = null
    var tileBoundsChanged = true
    var coords: List<TileCoord>? = null
    val oldCoords: List<TileCoord>? = null
    val dataQualityMult: Float

    /** The time series associated with the layer, if any.
     * @internal
     */

    init {

        dataQualityMult = dataQualityHash.getOrDefault(quality, 1f)

        //should this just be MapboxMapController.
        zoomOffset += 1 //leave this be, passed from MapboxMapController
        tileLayerRenderer.id = id

        // TODO: only set up time series and animator if timing series mode is not NONE
        timeSeries = TimeSeries()
        setupTimeSeriesAnimator()
        if (pr.ON) pr.p(TAG, pr.radarFix2, "init{} isRadar:$isRadar")

    }

    override fun setNeedsUpdate(force: Boolean) {
        if (!visible && !force) {
            return
        }
        isDirty = true
        tileLayerRenderer.setNeedsUpdate()
        mapController?.redraw()
    }

    fun getTileBounds(): TileBounds {
        if (bounds == null) {
            // Avoid blocking the caller thread (often UI/render) while waiting for Main.
            // On initial render, bounds should already be available from `onMove()`,
            // but this fallback prevents hard freezes if it's not.
            bounds = mapController?.getBounds()
                ?: LatLonBounds(westExtent = -180.0, southExtent = -85.0, eastExtent = 180.0, northExtent = 85.0)
        }

        //println(">>> TileLayer getTileBounds() bounds: W to E: ${bounds?.westExtent} to ${bounds?.eastExtent}")

        val zoomVarNext = zoomForVisibleTiles()
        val zoomIntNext = floor(zoomVarNext).toInt().coerceAtLeast(0)

        if (!renderBoundsDirty && tileBounds != null && tileBounds!!.zoom == zoomIntNext) {
            return tileBounds!!
        }

        zoom = mapZoomForVisibleTiles()
        zoomVar = zoomVarNext

        // Renderables follow map zoom (uncapped by encoded [source.maxZoom]) so land/water mask and
        // stencil can use native vector z; encoded rasters still use partial/parent textures as needed.
        tileBounds = getVisibleTileBounds(bounds!!, zoomVar, true)
        renderBoundsDirty = false
        return tileBounds!!
    }

    /**  gets a list of normalized renderables using getVisibleTileCoords()  */
    private fun getRenderables(): List<TileRenderable<DataType>> {
        if (!renderablesDirty) {
            return renderables
        }

        val tileBounds = getTileBounds()
        renderables.clear()

        //println(">>> TileLayer getRenderables() tileBounds: z ${tileBounds.zoom}   (${tileBounds.left} to ${tileBounds.right})")

        val visibleCoords = mapController?.let {
            getVisibleTileCoords(
                bounds!!,
                tileBounds,
                zoomVar,
                true,
            )
        }
        if (visibleCoords != null) {
            for (coord in visibleCoords) {
                renderables.add(TileRenderable(Tile(coord, null)))
            }
            oldTileBounds = tileBounds
        }
        renderablesDirty = false
        return renderables
    }

    /** * Recieves CoordinateBounds (Lat/Lon),
     * Calls  pyramid.requestTiles(coords, TileRequestOptions(reload = reload))
     * */
    suspend fun requestVisibleTiles(
        bounds: LatLonBounds,
        reload: Boolean = false,
        fromAnimation: Boolean = false
    ) {
        mapController?.let { map ->
            if (visible) {
                // Bounds/viewport changed; re-compute renderables for the next render.
                renderBoundsDirty = true
                renderablesDirty = true

                // Match [getTileBounds] / custom-layer zoom so requested z/x/y matches GLES renderables.
                // Scaling by [dataQualityMult] previously lowered download z vs draw z and could leave
                // visible rows (e.g. mid zoom) with no exact or partial texture.
                zoomVar = zoomForVisibleTiles()

                //println(">>> TileLayer requestVisibleTiles zoomOffset: ${zoomOffset}, zoomVar: $zoomVar, getDataZoom(): ${getDataZoom()} ${this.quality}")
                val tileBounds = getVisibleTileBounds(bounds, zoomVar)
                oldRequestBounds = bounds
                persistentTileBounds = tileBounds
                visibleTileCoords = getVisibleTileCoords(bounds, tileBounds, 0.0, false)

                val filteredVisibleTileCoords =
                    visibleTileCoords.filter { vtc -> //Ensure you don't request OOB tiles from server.
                        vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
                    }

                if (pr.ON && pr.tileDownloadAudit.active) {
                    val nTiles = { z: Int -> powerTableI[z] }
                    for (c in visibleTileCoords) {
                        if (c.x < 0 || c.y < 0 || c.x >= nTiles(c.z) || c.y >= nTiles(c.z)) {
                            pr.p(
                                TAG,
                                pr.tileDownloadAudit,
                                "requestVisibleTiles OOB tile not sent to download: z=${c.z} x=${c.x} y=${c.y} (n=${nTiles(c.z)}) layer=$id"
                            )
                        }
                    }
                }

                val finalTileCoords: List<TileCoord> = if (source.bounds != null) {
                    val region = source.bounds!!
                    val kept = filteredVisibleTileCoords.filter { coord -> isWithinRegionBounds(coord, region) }
                    if (pr.ON && pr.tileDownloadAudit.active) {
                        for (c in filteredVisibleTileCoords.filterNot { isWithinRegionBounds(it, region) }) {
                            pr.p(
                                TAG,
                                pr.tileDownloadAudit,
                                "requestVisibleTiles outside source.region bounds (skipped): z=${c.z} x=${c.x} y=${c.y} layer=$id source=${source.id}"
                            )
                        }
                    }
                    kept
                } else {
                    filteredVisibleTileCoords
                }

                alreadyRequested.addAll(finalTileCoords)
                tileRequestOptions.reload = reload

                val result = pyramid.requestTilesForDownload(
                    finalTileCoords,
                    tileRequestOptions,
                    externalScope,
                )

                if (result.isFailure) {
                    throw result.exceptionOrNull()!!
                }

                val encLayer = this as? EncodedTileLayer
                if (encLayer != null && source.isEncoded) {
                    val stencilTb = getVisibleTileBounds(bounds, zoomVar, fromGetRenderables = true)
                    val stencilCoords = getVisibleTileCoords(bounds, stencilTb, 0.0, fromGetRenderables = true)
                    if (encLayer.glStencilMaskKind != MaskLayerKind.NONE) {
                        map.schedulePrefetchGlStencilMaskTilesForWeatherRender(
                            stencilCoords,
                            encLayer.glStencilMaskKind,
                            encLayer.glStencilMaskCountryIso,
                        )
                    }
                    val customStencil = encLayer.stencilLayerMask
                    if (customStencil != null &&
                        (customStencil.layers.isNotEmpty() || customStencil.clipBounds != null)
                    ) {
                        map.schedulePrefetchGlStencilOsmTilesForCustomMask(stencilCoords)
                    }
                }

                if (mapController == null) return

                mapController!!.checkDownloadStatus(id, pyramid.tileCache.pendingCount)

                if (Timeline.movedOnTileLoaded) {
                    withContext(Dispatchers.IO) {
                        for (item in (pyramid.tileSource as XweatherEncodedTileSource).threadSafeTileMap) {
                            (pyramid.tileSource as XweatherEncodedTileSource).onTileLoaded(
                                item.value,
                                (pyramid.tileSource as XweatherEncodedTileSource).threadSafeIntervalMap[item.key],
                                1
                            )
                        }
                        (pyramid.tileSource as XweatherEncodedTileSource).threadSafeTileMap.clear()
                        (pyramid.tileSource as XweatherEncodedTileSource).threadSafeIntervalMap.clear()
                        mapController!!.checkDownloadStatus(id, pyramid.tileCache.pendingCount)
                    }
                }
            }
        }
    }

    /**
     * Same viewport and coord selection as [requestVisibleTiles], but only counts how many new
     * encoded (coord×time) pairs would be queued — no HTTP, no cache or pending-list mutation.
     * Summed across layers in [MapController.refreshVisibleLayers] to set a fixed download % denominator.
     */
    suspend fun preflightEncodedDownloadPairCount(): Int {
        if (!visible || !source.isEncoded) return 0
        val mc = mapController ?: return 0
        if (bounds == null) {
            bounds = mc.getBounds()
        }
        val b = bounds ?: return 0

        zoomVar = zoomForVisibleTiles()
        val tileBounds = getVisibleTileBounds(b, zoomVar)
        visibleTileCoords = getVisibleTileCoords(b, tileBounds, 0.0, false)

        val filteredVisibleTileCoords =
            visibleTileCoords.filter { vtc ->
                vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
            }

        val finalTileCoords: List<TileCoord> = if (source.bounds != null) {
            val region = source.bounds!!
            filteredVisibleTileCoords.filter { coord -> isWithinRegionBounds(coord, region) }
        } else {
            filteredVisibleTileCoords
        }

        return pyramid.preflightEncodedNewPairCount(finalTileCoords, tileRequestOptions)
    }

    private fun isWithinRegionBounds(coord: TileCoord, bounds: com.xweather.mapsgl.coordinates.LatLonBounds): Boolean {
        val n = powerTableD[coord.z]
        val lonDegPerTile = 360.0 / n
        val latRad = atan(sinh(Math.PI * (1 - 2 * coord.y / n)))
        val minLon = coord.x * lonDegPerTile - 180.0
        val maxLon = (coord.x + 1) * lonDegPerTile - 180.0
        val minLat = Math.toDegrees(atan(sinh(Math.PI * (1 - 2 * (coord.y + 1) / n))))
        val maxLat = Math.toDegrees(latRad)

        if (minLon < bounds.eastExtent && maxLon > bounds.westExtent) {
            if (minLat < bounds.northExtent && maxLat > bounds.southExtent) {
                return true
            }
        }
        return false
    }

    override fun getInfoForLocation(lat: Double, lng: Double, zoom: Int): String {
        return ""
    }

    override fun queryFeatures(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double?,
        queryLat: Double?,
    ): Any? {
        TODO("Not yet implemented")
    }

    /** * Recieves LatLonBounds
     * @return Tile number bounds. ex:(zoom=4, left=2, right=5, top=2, bottom=8))    */
    /** * Recieves LatLonBounds
     * @return Tile number bounds. ex:(zoom=4, left=2, right=5, top=2, bottom=8))    */
    internal fun getVisibleTileBounds(
        bounds: LatLonBounds,
        zoom: Double, //this zoom has offset baked in
        fromGetRenderables: Boolean = false
    ): TileBounds {
        var z = floor(zoom) //this zoom has offset baked in

        if (!fromGetRenderables) {
            if (z > source.maxZoom) z = source.maxZoom.toDouble()
        }

        var zoomInt = floor(z).toInt()
        if (zoomInt < 0) zoomInt = 0

        maxVal = (powerTableI[zoomInt] - 1)
        if (pr.ON) pr.p(TAG, pr.dateLine, "getVisibleTileBounds() using: ${bounds.westExtent} to ${bounds.eastExtent} ")

        lastTileBounds = currentTileBounds

        val yNorth = TileConversions.latToTile(bounds.northExtent, zoomInt)
        val ySouth = TileConversions.latToTile(bounds.southExtent, zoomInt)
        // Tile y grows south; northern latitudes map to smaller y. If north/south were ever inverted,
        // min/max still yields the correct inclusive span.
        var top = minOf(yNorth, ySouth).coerceAtLeast(0)
        var bottom = maxOf(yNorth, ySouth).coerceAtMost(maxVal)
        // Camera lat bounds can fall just inside a row while the viewport still shows the neighbor row.
        top = (top - 1).coerceAtLeast(0)
        bottom = (bottom + 1).coerceAtMost(maxVal)

        currentTileBounds = TileBounds(
            zoom = zoomInt,
            //swapped for the line below 250306 to fix dateline (to the left) issues on zoomOffset == -1
            // left = lonToTileNormalized(bounds.westExtent, zoomInt, fromGetRenderables),
            left = TileConversions.lonToTileNonNormalized(bounds.westExtent, zoomInt),
            right = TileConversions.lonToTileNormalized(bounds.eastExtent, zoomInt, fromGetRenderables),
            top = top,
            bottom = bottom
        )

        return currentTileBounds!!
    }

    private fun tileBoundsChanged(current: TileBounds, last: TileBounds): Boolean {
        if (current.top != last.top) return true
        if (current.bottom != last.bottom) return true
        if (current.left != last.left) return true
        if (current.right != last.right) return true
        if (current.zoom != last.zoom) return true

        return false
    }

    /**
     * Recieves LatLonBounds and zoom level
     * @return List of tile coords. Ex: (TileCoord: 4/2/2, TileCoord: 4/3/2)
     */
    override fun getVisibleTileCoords(
        latLonBounds: LatLonBounds,
        tileBounds: TileBounds,
        zoom: Double,
        fromGetRenderables: Boolean,
    ): List<TileCoord> {
        val coords: MutableList<TileCoord> = mutableListOf()

        if (fromGetRenderables) {
            // Enumerate every horizontal tile index the geographic bounds cover, across any number of
            // world copies (Mapbox can show many repeats when zoomed out). Older logic only stitched
            // one adjacent copy (-1/0/1), which capped encoded layers to ~2 worlds.
            //
            // Use [MapProvider.getUnwrappedCameraLonBoundsForTiles] (raw Mapbox unwrapped longitudes), not
            // [latLonBounds] from [getBounds] alone: [VisibleGeoBounds.fromMapboxUnwrappedCamera] can
            // collapse to a single world strip, which would limit xMin..xMax to one copy.
            val finalZoom = tileBounds.zoom.coerceAtLeast(0)
            val numTiles = powerTableI[finalZoom]
            if (numTiles <= 0) return coords

            val (westRaw, eastRaw) = mapController?.getUnwrappedCameraLonBoundsForTiles()
                ?: (latLonBounds.westExtent.toDouble() to latLonBounds.eastExtent.toDouble())
            var eastUnwrapped = eastRaw
            if (eastUnwrapped < westRaw) {
                eastUnwrapped += 360.0
            }

            val xMin = floor((westRaw + 180.0) / 360.0 * numTiles).toInt()
            val xMax = ceil((eastUnwrapped + 180.0) / 360.0 * numTiles).toInt() - 1

            for (y in tileBounds.top..tileBounds.bottom) {
                if (xMax < xMin) continue
                for (xi in xMin..xMax) {
                    val nx = ((xi % numTiles) + numTiles) % numTiles
                    val offset = xi - nx
                    coords.add(TileCoord(nx, y, finalZoom, offset))
                }
            }
        } else {
            // This branch handles simple tile requests (like for downloading)
            // where we only need tile coordinates normalized to a single world map.
            //
            // Use the same unwrapped camera longitudes as the renderables branch for horizontal
            // extent. [latLonBounds] / [getVisibleTileBounds] use [MapController.getBounds], which
            // passes through [VisibleGeoBounds.fromMapboxUnwrappedCamera] and can collapse the
            // viewport to a narrow longitude strip. At high pitch with many world copies, that strip
            // depends on bearing: facing E vs W yields different collapsed west/east, so tile
            // columns from [tileBounds.left]..[tileBounds.right] would miss tiles that are already
            // drawn (unwrapped) and force extra downloads after rotating.
            //
            // Several raw tile indices still map to the same normalized z/x/y; dedupe below.
            val finalZoom = tileBounds.zoom.coerceIn(
                floor(source.minZoom).toInt(),
                floor(source.maxZoom).toInt()
            )
            val numTiles = powerTableI[finalZoom]
            if (numTiles > 0) {
                val seenNorm = LinkedHashSet<String>()
                val (xMin, xMax) = mapController?.getUnwrappedCameraLonBoundsForTiles()?.let { (westRaw, eastRaw) ->
                    var eastUnwrapped = eastRaw
                    if (eastUnwrapped < westRaw) {
                        eastUnwrapped += 360.0
                    }
                    val minX = floor((westRaw + 180.0) / 360.0 * numTiles).toInt()
                    val maxX = ceil((eastUnwrapped + 180.0) / 360.0 * numTiles).toInt() - 1
                    minX to maxX
                } ?: (tileBounds.left to tileBounds.right)

                for (y in tileBounds.top..tileBounds.bottom) {
                    if (xMax < xMin) continue
                    for (xi in xMin..xMax) {
                        val nx = ((xi % numTiles) + numTiles) % numTiles
                        val key = "$finalZoom/$nx/$y"
                        if (seenNorm.add(key)) {
                            coords.add(TileCoord(nx, y, finalZoom))
                        }
                    }
                }
            }
        }

        if (initialLoad) { // Always download zoomLevel 0 first
            initialLoad = false
            if (tileBounds.zoom != 0) {
                val hasZ0Root = coords.any { it.z == 0 && it.x == 0 && it.y == 0 }
                if (!hasZ0Root) {
                    coords.add(TileCoord(0, 0, 0))
                }
            }
        }

        return coords
    }

    /**
     * [MapboxMap.getCameraState] must run on the map-owning thread; [getTileBounds] / render can run on
     * the GL thread. On main, read live zoom; otherwise use [CameraSync] (filled by custom-layer render / main).
     */
    private fun getDataZoom(): Double {
        val mc = mapController ?: return CameraSync.mapZoom
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return mc.getZoom()
        }
        return CameraSync.zoomForCustomLayerInstancing()
    }

    /** Map zoom (no [zoomOffset]), matching the source used in [getTileBounds]. */
    private fun mapZoomForVisibleTiles(): Double =
        CameraSync.customLayerRenderZoom ?: (CameraSync.camera.zoom ?: getDataZoom())

    /**
     * Effective data tile zoom: [mapZoomForVisibleTiles] plus [zoomOffset]. Used for render and download
     * tile indices so both paths agree.
     */
    private fun zoomForVisibleTiles(): Double =
        (mapZoomForVisibleTiles() + zoomOffset).coerceAtLeast(0.0)

    /** Used in TileTimeSeriesDataProvider. Needs testing */
    /** Used in TileTimeSeriesDataProvider. Needs testing */
    fun getVisibleTileCoords(): List<TileCoord> {
        return visibleTileCoords
    }

    /**
     * Tile coords for gridded sidecar sampling (e.g. GL wind barbs). Uses [visibleTileCoords] when
     * [requestVisibleTiles] has run; otherwise derives from current [bounds] / [getTileBounds] so
     * sampling still works when [onMove] skips downloads (timeline playing, etc.).
     */
    internal fun visibleTileCoordsForSidecarSampling(): List<TileCoord> {
        // Do not reuse [visibleTileCoords] from [requestVisibleTiles]: that path uses
        // [getVisibleTileCoords] with fromGetRenderables=false (download-style enumeration).
        // Gridded sidecar sampling must use fromGetRenderables=true (unwrapped camera, world copies)
        // and must track programmatic zoom changes even when [renderBoundsDirty] was not set yet.
        val b = bounds ?: mapController?.getBounds() ?: return emptyList()
        val tb = getTileBounds()
        val coords = getVisibleTileCoords(b, tb, zoomVar, true)
        var filtered = coords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        filtered = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        // At world / near-world zoom, tile enumeration can be empty before the first camera sync or while
        // unwrapped longitudes are still settling — instanced wind then gathers zero instances until a pan.
        if (filtered.isEmpty() && tb.zoom <= 0) {
            val root = TileCoord(0, 0, 0)
            val inRegion = source.bounds == null || isWithinRegionBounds(root, source.bounds!!)
            if (inRegion) return listOf(root)
        }
        return filtered
    }

    //** generates context.renderables can calls tileLayerRenderer.prerender(context)  */
    override fun prerender(elapsedTime: Double) {
        if (mapController == null || !visible) {
            return
        }
        layerRenderContext.renderables = getRenderables()
        layerRenderContext.paintStyle = paint
        tileLayerRenderer.prerender(layerRenderContext)
        return
    }

    override fun onRemove() {}

    /** Called from LayerHost.render(), calls TileLayerRenderer.draw()*/
    /** Called from LayerHost.render(), calls TileLayerRenderer.draw()*/
    override fun render(texUnit: HashMap<String, Int>, camera: Camera) {
        if (visible)
            tileLayerRenderer.draw(layerRenderContext, texUnit, camera)
        triggerEvent(TileLayerEventType.FINISHED_DRAWING)
    }

    override lateinit var type: LayerType

    override lateinit var timing: LayerTiming

    override var invertMaskLayer: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}

    override var sourceEventHandlers: MutableList<MapLayer.SourceEventHandler> = mutableListOf()

    override fun onAdd(context: Context, controller: MapController) {
        this.mapController = controller
        super.onAdd(context, controller)
        this.drawContext = context
        // need to trigger onMove to render initial tiles
        tileLayerRenderer.onAdd(this)

        (mapController)?.timeline?.playIsPressed?.observeForever { newValue ->
            // Avoid blocking the observer callback thread.
            externalScope.launch { handlePlayIsPressedChange(newValue) }
        }
    }

    override fun onAdd() {
        TODO("Not yet implemented")
    }

    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {
        TODO("Not yet implemented")
    }

    //triggers on play and pause
    private fun handlePlayIsPressedChange(newValue: Boolean) {
        if (newValue && bounds != null) {
            if (pr.ON) pr.p(TAG, pr.playPause, "handlePlayIsPressedChange(): Starting animation...")
            //println("TileLayer calling requestVisibleTiles with play button, looking")
            if (pr.ON) pr.p(TAG, pr.playLock, "handlePlayIsPressedChange($newValue) about to call requestVisibleTiles ")
            //requestVisibleTiles(bounds!!, fromAnimation = true) //commented this out 250320... was causing freeze when play pressed...

        } else {
            // if(pr.ON) pr.p(TAG, pr.obs_play,"TileLayer handlePlayIsPressedChange: Stopping animation...")
        }
    }

    /** z=0 prefetch for ancestor partials while paused; does not drive the load indicator. */
    private suspend fun scheduleQuietWorldTileIfNeededOnIdleCameraMove() {
        if (!visible || !source.isEncoded) return
        val tl = mapController?.timeline ?: animator?.animation?.timeline ?: return
        if (tl.state == AnimationState.playing) return
        pyramid.scheduleQuietIdleWorldTileDownload(tileRequestOptions, externalScope)
    }

    /** Gets bounds and requests visible tiles **/
    override suspend fun onMove() {
        oldBounds = bounds
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        // Keep renderables updated during movement.
        // Without this, the cached `tileBounds`/`renderables` can lag behind the camera,
        // producing temporary blank tiles until `onMoveEnd()` runs.
        renderBoundsDirty = true
        renderablesDirty = true

        if (this is VectorTileLayer) {

        } else { // Non-vector

            val timeline = animator?.animation?.timeline
            val playingBlocksMoveRequests = timeline != null &&
                timeline.state == AnimationState.playing &&
                !Timeline.pausedForDownload

            val displayTileZ = floor(zoomForVisibleTiles()).toInt().coerceAtLeast(0)
            val zoomTierChanged =
                lastOnMoveDisplayTileZ == null || displayTileZ != lastOnMoveDisplayTileZ
            if (zoomTierChanged) {
                lastOnMoveDisplayTileZ = displayTileZ
            }

            if (!playingBlocksMoveRequests || zoomTierChanged) {
                if (pr.ON) pr.p(
                    TAG,
                    pr.infiniteLoad,
                    "onMove() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
                )
                bounds?.let { requestVisibleTiles(it) }
            }
        }
    }

    suspend fun onMoveUnrestricted() {
        oldBounds = bounds
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        if (this is VectorTileLayer) {

        } else { // Non-vector

            //if(pr.ON) pr.p(TAG, pr.infiniteLoad, " onMove() calling requestVisibleTiles()")
            if (pr.ON) pr.p(
                TAG,
                pr.infiniteLoad,
                "onMoveUnrestricted() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
            )
            bounds?.let { requestVisibleTiles(it) }
        }
    }

    /** Calls requestVisibleTiles(), gets bounds if needed. */
    override suspend fun update() {
        //if (pr.ON) pr.p(TAG, pr.lagR, "update()")
        if (bounds == null) {
            bounds = mapController?.getBounds()
        }
        bounds?.let { requestVisibleTiles(it) }
    }

    /**
     * Re-queues already-downloaded visible tiles for GPU bind after a scrub while paused,
     * without issuing another HTTP wave.
     */
    internal suspend fun requeueVisibleBindsForScrub() {
        if (!visible || !source.isEncoded) return
        if (bounds == null) {
            bounds = mapController?.getBounds()
        }
        val b = bounds ?: return
        zoomVar = zoomForVisibleTiles()
        val tileBounds = getVisibleTileBounds(b, zoomVar)
        val visibleCoords = getVisibleTileCoords(b, tileBounds, 0.0, false)
        val filtered = visibleCoords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        val finalCoords = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        pyramid.requeueLoadedVisibleTilesForBind(finalCoords, pyramid.scrubPhaseTimesArray())
    }

    override fun onMoveStart() {
        //println("$TAG onMoveStart()")
    }

    override suspend fun onMoveEnd() {
        //println("TileLayer OnMoveEnd")
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        // Keep renderables in sync even if we skip triggering downloads.
        renderBoundsDirty = true
        renderablesDirty = true

        val shouldSkipDL = Timeline.isDownloading && !Timeline.pausedForDownload

        // While we are already waiting on a download batch, avoid triggering another wave of
        // visible-tile requests from frequent "idle" callbacks. This is what was causing
        // the download queue to grow continuously.
        if (shouldSkipDL) return

        val tl = mapController?.timeline ?: animator?.animation?.timeline
        if (tl == null || tl.state != AnimationState.playing) {
            scheduleQuietWorldTileIfNeededOnIdleCameraMove()
        }

        //if(pr.ON) pr.p(TAG, pr.infiniteLoad, " onMoveEnd() calling requestVisibleTiles() with bounds: ${bounds}")
        if (pr.ON) pr.p(
            TAG,
            pr.infiniteLoad,
            "onMoveEnd() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
        )
        bounds?.let { requestVisibleTiles(it) }
    }

    override fun onResize() {
        TODO("Not yet implemented")
    }

    override fun onClick() {
        TODO("Not yet implemented")
    }

    override fun onVisible() {
        tileLayerRenderer.onVisible()
        setNeedsUpdate()
    }

    override fun onHidden() {
        tileLayerRenderer.onHidden()
        setNeedsUpdate()
    }

    private fun setupTimeSeriesAnimator() {
        if (pr.ON) pr.p("MapLayer", pr.layerToAnimation, "setupTimeSeriesAnimator(), entered")
        //val (clamp, range, interleaved) = this.timing

        timing = LayerTiming()
        with(timing) {
            mode = TimeSeriesMode.NONE
            clamp = TimeClampMode.NONE
            range = null
            intervals = null
            interleaved = true
            operation = null
        }

        val clamp = timing.clamp
        val range = timing.range
        val interleaved = timing.interleaved


        val provider = createTimeSeriesDataProvider()

        if (pr.ON) pr.p(
            "TileLayer",
            pr.layerToAnimation,
            "setupTimeSeriesAnimator(), provider is null? ${provider == null}"
        )

        if (provider != null) {
            //if (interleaved != null) {
            provider.interleaveRequests = interleaved
            //} else provider.interleaveRequests = true
        }

        val animator = TimeSeriesAnimator(
            timeSeries as TimeSeries<Data>,
            provider,
            TimeSeriesAnimatorOptions(clamp!!),
            // mapOf("id" to this.id, "mode" to clamp!!)
        )

        this.animator = animator

        animator.animation.timeline = mapController?.timeline

        if (pr.ON) pr.p(
            "TileLayer",
            pr.layerToAnimation,
            "setupTimeSeriesAnimator() (this.animator == null) ? ${this.animator == null}"
        )

        if (range != null) {
            animator._timeRange = range
        }

        //if (true){ //TODO: Make sure this section works
        addSourceEventHandler(
            DataSourceEvents.TileLoad().toString(),
            { animator.updateEntryState() }
        )
        //}

        // TODO: note from javascript version: move this into TimeSeriesAnimator
        listOf(
            TimeSeriesEvent.DATA_ADVANCE,
            TimeSeriesEvent.LOAD_COMPLETE
        ).forEach { event ->

            animator.on(
                event,
                callback = object : EventDispatcher.MyEventListener<Any> {
                    override fun onEvent(v1: Any) {
                        if (true) {
                            //DriverManager.println("")
                        }
                        MapsGLDebug.trace("TileLayer _setupTimeSeriesAnimator() Event received with data: $v1")

                    }

                    override val eventDispatcher: EventDispatcher
                        get() = TODO("Not yet implemented")

                },
                null,
                this
            ).apply {
                //animator.on(event,   object : EventListener<TimeSeriesEvent> {},  context = this).apply {
                /*
                if (this.visible) {
                    this.setNeedsUpdate()
                }*/
            }

        }
        /*
        animator.on(TimeSeriesEvent.ADVANCE,object : EventListener {}, null,  this).apply{
            if (this.visible) {
                this.setNeedsUpdate()
                this.enabled = this.animator.canShowForDate(e as Date) ?: false
            }


        } //{ e ->
        */
        //}

        if (this.timing.mode == TimeSeriesMode.INTERVAL) {
            /*
            animator.on(TimeSeriesEvent.ADVANCE) {
                if (animator.provider == null) {
                    this.refresh(true)
                } else if (animator.isActive) {
                    animator.loadDataIfNeeded()
                }
            }
            animator.on(TimeSeriesEvent.INTERVAL_ADVANCE) { e ->
                if(animator.isActive == false) {
                    animator.loadDataForIntervals(listOf((e as? Any) ?: error("Type mismatch, event is not of type Any")))
                }
            }
        }  else if (this.timing.mode == TimeSeriesMode.ANY) {
            animator.on(TimeSeriesEvent.ADVANCE) {
                this.refresh(true)
            } */
        }

    }


}
/*
val DATA_ZOOM_RATIO = mapOf(
    DataQuality.exact to 1f,
    DataQuality.high to 0.95f,
    DataQuality.medium to 0.8f,
    DataQuality.normal to 0.65f,
    DataQuality.low to 0.4f,
    DataQuality.minimal to 0.25f
)
val DATA_TO_ZOOM = mapOf(
    DataQuality.exact to listOf(0),
    DataQuality.high to listOf(0, 1, 2, 3, 4, 4, 5, 5, 6, 7, 7, 8, 8, 9, 9, 10, 10, 10, 10, 10, 10),
    DataQuality.medium to listOf(0, 1, 1, 2, 3, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5),
    DataQuality.normal to listOf(0, 1, 1, 2, 3, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9),
    DataQuality.low to listOf(0, 0, 1, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6),
    DataQuality.minimal to listOf(0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3)
)
val QUALITY_PIXEL_RATIO = mapOf(
    DataQuality.exact to 1,
    DataQuality.high to 2,
    DataQuality.medium to 4,
    DataQuality.normal to 6,
    DataQuality.low to 8,
    DataQuality.minimal to 15
)
*/