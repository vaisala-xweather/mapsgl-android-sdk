package com.xweather.mapsgl.layers.tile

import LayerEvents
import android.content.Context
import com.xweather.mapsgl.data.series.AnyTimeSeries
import com.xweather.mapsgl.data.series.Data
import com.xweather.mapsgl.data.series.TimeRange
import com.xweather.mapsgl.data.series.TimeSeriesAnimator
import com.xweather.mapsgl.data.series.TimeSeriesDataProvider
import com.xweather.mapsgl.events.EventSource
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.geo.Viewport
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.MapEventObserver
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.LayerRenderer
import com.xweather.mapsgl.sources.DataSource
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType

/**
 * Minimal visibility contract for layers or hosts that only need show/hide hooks.
 */
interface MapLayerInternal {
    var visible: Boolean

    @Throws(Exception::class)
    fun onVisible()

    @Throws(Exception::class)
    fun onHidden()
}

/**
 * Common identity and data binding for anything that draws from a [DataSource].
 *
 * MapsGL tile layers implement this (via [MapLayer]) together with render state and timeline hooks.
 */
interface LayerProtocol {
    val id: String
    val source: DataSource

    //    var controller: MapControllerProtocol?
    var viewport: Viewport?
    var quality: DataQuality
    var timing: LayerTiming
}

typealias MapsGLLayer = LayerProtocol

/**
 * A **tile-backed map layer**: grid dimensions, source, paint, renderer, timeline, and visibility.
 *
 * Concrete implementations include [TileLayer] subclasses (encoded sample, raster, vector, particles).
 * Register layers with [com.xweather.mapsgl.map.MapController.addLayer] / weather helpers; the controller
 * wires [mapController], [renderer], and Mapbox custom layer hosting.
 *
 * @param DataType Tile payload type from [source].
 * @param RenderContext Renderer context type passed into the GL pipeline.
 */
interface MapLayer<DataType : TileData, RenderContext : LayerRenderContext<Any>> : /*Identifiable,*/ MapEventObserver,
    EventSource {
    var numW: Int
    var numH: Int
    val id: String
    var source: TileSource<DataType>
    var waitingOnDL: Boolean
    var wasWaitingOnDL: Boolean

    /** The map controller that this layer is associated with.   */
    var mapController: MapController?
    var paint: LayerPaint//PaintStyle
    var alpha: Float
    var layerRenderContext: RenderContext
    var isDirty: Boolean
    var enabled: Boolean
    var visible: Boolean
    val viewport: Viewport?
    var animator: TimeSeriesAnimator<Data>?

    /** @internal  */
    var renderer: LayerRenderer<Any>
    fun prerender(elapsedTime: Double)
    fun render(texUnit: HashMap<String, Int>, camera: Camera)


    /** The type of layer.  */
    var type: LayerType

    /** The map scene that this layer is rendered into.
     * @internal
     */
    //var scene: MapScene

    /** The layer's timing configuration.  */
    var timing: LayerTiming

    /** The time series associated with the layer, if any.
     * @internal
     */
    var timeSeries: AnyTimeSeries?

    /** Whether to invert the mask layer's output.  */
    var invertMaskLayer: Boolean

    /** @internal */
    var sourceEventHandlers: MutableList<SourceEventHandler>// = mutableListOf()

    /**
     * Registered source event name and callback (future hook parity with JS event bus).
     *
     * @property event Event key.
     * @property handler Invoked when the source emits the event.
     */
    data class SourceEventHandler(
        val event: String,
        val handler: (Any?) -> Unit
    )

    fun onAdd(context: Context, controller: MapController) {
        mapController = controller
        if (pr.ON) pr.p("MapLayer", pr.layerToAnimation, "onAdd(), entered")
    }

    fun getVisibleTileCoords(
        latLonBounds: LatLonBounds,
        tileBounds: TileBounds,
        zoom: Double,
        wrap: Boolean,
    ): List<TileCoord>

    /** Returns the time series data provider to use for animating the layer, if any.
     * @internal
     */
    fun createTimeSeriesDataProvider(): TimeSeriesDataProvider<TileLayer>? {
        return null
    }


    // Event Handlers
    fun addSourceEventHandler(event: String, handler: (e: Any?) -> Unit, once: Boolean = false) {
        if (sourceEventHandlers == null) {
            sourceEventHandlers = mutableListOf()
        }

        if (once) {
            // this.source.once(event, handler, this, this)
        } else {
            //  this.source.on(event, handler, this, this)
        }

        sourceEventHandlers.add(SourceEventHandler(event, handler))
    }

    @Throws(Exception::class)
    fun show() {
        if (!visible) {
            visible = true
            onVisible()
            trigger(LayerEvents.Show())
        }
    }

    @Throws(Exception::class)
    fun hide() {
        if (visible) {
            visible = false
            onHidden()
            trigger(LayerEvents.Hide())
        }
    }

    /** Flags the layer as dirty so that it is updated during the next render frame.
     * @param force - Whether to force the layer to be updated even if it is not visible.     */
    fun setNeedsUpdate(force: Boolean = false) {
        //println("MapLayer setNeedsUpdate()")
        if (!visible && !force) return

        isDirty = true
        renderer.setNeedsUpdate()
        mapController?.redraw()
    }


    /** Refreshes the layer by re-rendering it.
     * If a complete refresh is needed including triggering the associated data source to reload, then pass an argument
     * of `true` when calling the method. Otherwise, existing cached data will be used when the layer is re-rendered.
     * @param clear - Whether to clear the layer's data source and re-fetch data.    */
    fun refresh(clear: Boolean = false) {
        // Implementation of refresh logic here
        if (clear) {
            //println("Clear is true, performing full refresh")
        } else {
            //println("Clear is false, performing partial refresh")
        }
    }


    /** Called when the data source's metadata has been loaded.
     * @internal     */
    open fun onSourceMetadata() {
        if (this.timeSeries == null) return

        this.setTimeSeriesFromMetadata()
    }

    fun onReady() {
        if (this.animator != null && this.animator!!.currentInterval.equals(-1) == true) {
            /*
            this.animator.once(TimeSeriesEvent.DATA_ADVANCE) {
                this.trigger(LayerEvents.Ready())
            }
            */
        } else {
            this.trigger(LayerEvents.Ready())
        }
    }

    data class TimeSeriesData(val loading: Boolean = false, val valid: Boolean = false)

    /** Updates the layer's time series intervals based on the valid times from the data source's metadata.
     * @internal
     */
    private fun setTimeSeriesFromMetadata() {
        val validTimes = source.metadata.getValidTimes()

        if ((validTimes.isEmpty()) && timeSeries != null) {
            val seriesData = validTimes.fold(HashMap<String, Any>()) { result, date ->
                val interval = (date.time).toString()
                val existingData = timeSeries?.dataForTimeInterval(date.time)
                //result[interval as TimeIntervalKey] = existingData ?: TimeSeriesData(loading = false, valid = false) //below code with elvis operator
                if (existingData != null) {
                    result[interval] = existingData
                } else {
                    result[interval] = TimeSeriesData(loading = false, valid = false)
                }
                result
            }
            timeSeries?.setDataAny(seriesData) //TODO: Check cast from any to data in setData()
        }
    }

    override fun onVisible() {
        renderer.onVisible()
        setNeedsUpdate()
    }

    override fun onHidden() {
        renderer.onHidden()
        setNeedsUpdate()
    }


    fun getInfoForLocation(lat: Double, lng: Double, zoom: Int): String
    fun queryFeatures(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double? = null,
        queryLat: Double? = null,
    ): Any?
}

val MapLayer<*, *>.viewport: Viewport?
    get() = this.mapController?.viewport

//region Interfaces

/** Configuration options for a WebGL layer. */
interface MapLayerConfig {
    /** The data source that this layer will render.   */
    val source: DataSource

    /** The layer's data to use from the data source, if applicable. This is only used for vector tile data sources
     * whose tiles are in the Mapbox Vector Tile (MVT) format.    */
    val sourceLayer: String?

    /** The feature type to render from the data source, if applicable. This is only used for vector tile data sources
     * whose tiles are in the Mapbox Vector Tile (MVT) format.     */
    val sourceType: VectorSourceType?

    /** Renderer responsible for rendering this layer and its data.     */
    val renderer: LayerRenderer<Any>

    /** Map controller's viewport.
     * @internal
     */
    val viewport: Viewport

    /** Animation instance that controls the animation of this layer if time-based.     */
    val animation: Animation?
}


// Placeholder for DataSource interface.
//interface DataSource

// Placeholder for VectorSourceType enum.
enum class VectorSourceType {
    POINT,
    LINE,
    POLYGON
}

/*
// Placeholder for LayerRenderer interface.
interface LayerRenderer {
    fun setNeedsUpdate()
}
*/
// Placeholder for Viewport interface.
interface Viewport

// Placeholder for Animation interface.
interface Animation

/** Configuration for a layer's time-based animation. */
class LayerTiming {
    /** The mode of the time series animation.   */
    lateinit var mode: TimeSeriesMode

    /** Defines how to restrict the visibility of a time-specific layer, either `past`, `future` or `range` time
     * intervals.
     */
    var clamp: TimeClampMode? = null

    /** Defines the valid start and end date range for the layer. When provided, the layer will automatically be
     * hidden outside of this date range.     */
    var range: TimeRange? = null

    /** Maximum number of time intervals to use for the data set.
     * @remarks
     * The actual intervals returned by the server may be less than this value depending on the available valid
     * times within the requested range of the map's timeline and the data source. NOTE: Increasing this value may
     * affect the performance of your map, so avoid setting this to large numbers.     */
    var intervals: Int? = null

    /** Whether data requests for animation frames should be interleaved. Default value is `true`.
     * @remarks
     * Data requests for time series animations are broken up in to multiple interval chunks of based on
     * the maximum number of intervals per request. When `true`, data requests for each frame of the animation will
     * be staggered and loaded at evenly-spaced intervals across the entire time range of the animation so that
     * the full time range can be animated as remaining intervals continue loading and filling in between
     * already-loaded intervals. When `false`, data requests will be loaded in sequential order, starting from the
     * beginning of the time range.     */
    var interleaved: Boolean = true

    /** The operation to perform on the data within the time series. Defaults to `none`.    */
    var operation: TimeSeriesOperation? = null

    /** Flags the renderer as dirty so that it is updated during the next render frame.   */
    fun setNeedsUpdate() {


    }

}

// Placeholder for TimeSeriesMode enum. Replace with your actual implementation.
enum class TimeSeriesMode {
    NONE,
    INTERVAL,
    ANY
}

// Placeholder for TimeClampMode enum. Replace with your actual implementation.
enum class TimeClampMode {
    NONE,
    RANGE,
    PAST,
    FUTURE
}

// Placeholder for TimeRange interface. Replace with your actual implementation.
//interface TimeRange

// Placeholder for TimeSeriesOperation enum. Replace with your actual implementation.
enum class TimeSeriesOperation {
    NONE,
    /** Sum decoded scalar samples over consecutive timeline intervals (precip accumulation, etc.). */
    SUM,
}


//endregion Interfaces

