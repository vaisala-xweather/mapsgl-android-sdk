//
//  LegendCode.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:17.409Z
//

@file:Suppress("FunctionName")

package com.xweather.mapsgl.weather

import androidx.core.graphics.toColorInt
import com.xweather.mapsgl.anim.Easing
import com.xweather.mapsgl.anim.EasingCurveFactory
import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.Point.AlertsLegendItemResolver
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.Point.PointLegendItem
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegendItem
import com.xweather.mapsgl.controls.legend.bar.BarLegendLabels
import com.xweather.mapsgl.extensions.UnitLength
import com.xweather.mapsgl.extensions.UnitPressure
import com.xweather.mapsgl.extensions.UnitSpeed
import com.xweather.mapsgl.extensions.UnitTemperature
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.utils.inToMMRate
import kotlin.math.PI
import kotlin.math.acos
import kotlin.math.round

enum class LegendCode(val id: String) {
    ACCUM_PRECIP("accum-precip"),
    ACCUM_SNOW("accum-snow"),
    AIR_QUALITY_HEALTH_INDEX("air-quality-health-index"),
    AIR_QUALITY_INDEX("air-quality-index"),
    AIR_QUALITY_INDEX_CAI("air-quality-index-cai"),
    AIR_QUALITY_INDEX_CAQI("air-quality-index-caqi"),
    AIR_QUALITY_INDEX_CATEGORIES("air-quality-index-categories"),
    AIR_QUALITY_INDEX_CHINA("air-quality-index-china"),
    AIR_QUALITY_INDEX_EAQI("air-quality-index-eaqi"),
    AIR_QUALITY_INDEX_UK_DAQI("air-quality-index-uk-daqi"),
    AIR_QUALITY_INDEX_UBA_DAQI("air-quality-index-uba-daqi"),
    AIR_QUALITY_INDEX_INDIA("air-quality-index-india"),
    CARBON_MONOXIDE("air-quality-co"),
    NITRIC_OXIDE("air-quality-no"),
    NITROGEN_DIOXIDE("air-quality-no2"),
    OZONE("air-quality-o3"),
    PARTICULATE_MATTER_10_MICRON("air-quality-pm10"),
    PARTICULATE_MATTER_2P5_MICRON("air-quality-pm2p5"),
    SULFUR_DIOXIDE("air-quality-so2"),
    ALERTS("alerts"),
    CLOUD_COVER("cloud-cover"),
    CONVECTIVE("convective"),
    DEW_POINT("dew-point"),
    DROUGHT("drought"),
    EARTHQUAKE("earthquake"),
    FIRE_OBSERVATION("fire-observation"),
    FIRE_OUTLOOK("fire-outlook"),
    HAIL_POSH("hail-posh"),
    HAIL_SIZE("hail-size"),
    HAIL_THREAT("hail-threat"),
    HEAT_INDEX("heat-index"),
    HUMIDITY("humidity"),
    LIGHTNING("lightning"),
    LIGHTNING_DENSITY("lightning-density"),
    LIGHTNING_THREAT("lightning-threat"),
    PRESSURE("pressure"),
    OCEAN_CURRENT("ocean-current"),
    PRECIP_RATE("precip-rate"),
    RADAR("radar"),
    RIVER_OBSERVATION("river-observation"),
    ROAD_WEATHER_RISK("road-weather-risk"),
    ROAD_WEATHER_SUMMARY("road-weather-summary"),
    ROAD_WEATHER_SURFACE("road-weather-surface"),
    ROAD_WEATHER_TEMPERATURE("road-weather-temperature"),
    ROAD_WEATHER_TEMPERATURE_FREEZE("road-weather-temperature-freeze"),
    SNOW_DEPTH("snow-depth"),
    STORM_SURGE("storm-surge"),
    STORM_CELL("storm-cell"),
    STORM_REPORT("storm-report"),
    TEMPERATURE("temperature"),
    TEMPERATURE_CHANGE_1_HOUR("temperature-change-1hr"),
    TEMPERATURE_CHANGE_24_HOUR("temperature-change-24hr"),
    TIDE_HEIGHT("tide-height"),
    TROPICAL_BREAKPOINT("tropical-breakpoint"),
    TROPICAL_CYCLONE("tropical-cyclone"),
    ULTRAVIOLET_INDEX("uvi"),
    VISIBILITY("visibility"),
    WAVE_HEIGHT("wave-height"),
    WAVE_PERIOD("wave-period"),
    SWELL_HEIGHT("swell-height"),
    SWELL_PERIOD("swell-period"),
    WIND_CHILL("wind-chill"),
    WIND_SPEED("wind-speed");

    /**
     * Retrieves the appropriate Legend configuration based on the given LegendCode.
     *
     * @param code The LegendCode enum representing the desired legend.
     * @return The corresponding Legend, or null if the code is not recognized.
     */
    fun getLegend(): Legend =
        when (this) {


            PRECIP_RATE -> {
                // Hour precip: colorscale range 0..5 in/hr (JS conditions.precip); drawRange min 0.01 in/hr.
                val precipHourColorMin = 0.0
                val precipHourColorMax = inToMMRate(5.0)
                val precipHourLegendMaxIn = 5.0
                fun hourPrecipLinearNorm(inches: Double): Double {
                    val x = inches.coerceIn(0.0, precipHourLegendMaxIn)
                    return x / precipHourLegendMaxIn
                }

                /**
                 * Normalized bar position [0,1] for an in/hr tick, matching ease-in sine ramp sampling.
                 * Forward ease: f(p)=1-cos(πp/2); this returns p = f⁻¹(u) with u = linear norm in rate.
                 */
                fun hourPrecipBarPositionInches(inches: Double): Double {
                    val u = hourPrecipLinearNorm(inches).coerceIn(0.0, 1.0)
                    return (2.0 / PI) * acos((1.0 - u).coerceIn(-1.0, 1.0))
                }

                BarLegend(
                    id = id,
                    title = "1-Hour Precipitation",
                    measurement = MeasurementUnits.MeasurementType.PRECIPITATION,
                    resample = EasingCurveFactory.curve(Easing.IN_SINE),
                    units = MeasurementUnits.IMPERIAL,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.precip_accum.stops,
                                        range = precipHourColorMin..precipHourColorMax,
                                        normalized = false,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.precipitationRate,
                                        values =
                                            BarLegendLabels.Values.FromLabels { unit ->
                                                when (unit) {
                                                    is UnitLength.Inches -> {
                                                        val values =
                                                            listOf(
                                                                0.01,
                                                                0.1,
                                                                0.5,
                                                                1.0,
                                                                2.0,
                                                                3.0,
                                                                4.0,
                                                                5.0,
                                                            )
                                                        values.mapIndexed { index, inches ->
                                                            val positionedAt = hourPrecipBarPositionInches(inches)

                                                            val formattedValue =
                                                                if (inches % 1.0 == 0.0) {
                                                                    inches.toInt().toString()
                                                                } else {
                                                                    inches.toString()
                                                                }
                                                            val label =
                                                                if (index == 0) {
                                                                    "$formattedValue in"
                                                                } else {
                                                                    formattedValue
                                                                }
                                                            Pair(positionedAt, label)
                                                        }
                                                    }

                                                    is UnitLength.Millimeters -> {
                                                        val mmTicks =
                                                            listOf(
                                                                1.0,
                                                                2.0,
                                                                5.0,
                                                                10.0,
                                                                25.0,
                                                                50.0,
                                                                75.0,
                                                                100.0,
                                                                125.0,
                                                            )
                                                        mmTicks.mapIndexed { index, mm ->
                                                            val positionedAt = hourPrecipBarPositionInches(mm / 25.4)
                                                            val label =
                                                                if (index == 0) {
                                                                    val v = round(mm * 10.0) / 10.0
                                                                    "$v mm"
                                                                } else {
                                                                    "${round(mm).toInt()}"
                                                                }
                                                            Pair(positionedAt, label)
                                                        }
                                                    }

                                                    else -> emptyList()
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }


            ACCUM_PRECIP -> {
                // MapsGL JS accum-precip legend: ticks 0.01 in, then 5,7,…,25; bar spans 0..25 in on the ramp.
                val precipAccumDrawMin = 0.00007
                val precipAccumDrawMax = 0.21167
                val precipAccumLegendMaxIn = 25.0
                val accumPrecipInSine = EasingCurveFactory.curve(Easing.IN_SINE)
                fun accumPrecipBarPositionInches(inches: Double): Double {
                    val tLinear = (inches / precipAccumLegendMaxIn).coerceIn(0.0, 1.0)
                    // Same as linear map through precipAccumDrawMin..precipAccumDrawMax then renormalize (was identity).
                    return accumPrecipInSine(tLinear)
                }
                BarLegend(
                    id = id,
                    title = "Accumulated Precipitation",
                    measurement = MeasurementUnits.MeasurementType.PRECIPITATION,
                    resample = accumPrecipInSine,
                    units = MeasurementUnits.IMPERIAL,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.precip_accum.stops,
                                        range = precipAccumDrawMin..precipAccumDrawMax,
                                        normalized = false,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.precipitationRate,
                                        values =
                                            BarLegendLabels.Values.FromLabels { unit ->
                                                when (unit) {
                                                    is UnitLength.Inches -> {
                                                        val values =
                                                            listOf(
                                                                0.01,
                                                                5.0,
                                                                7.0,
                                                                10.0,
                                                                12.0,
                                                                14.0,
                                                                16.0,
                                                                18.0,
                                                                20.0,
                                                                25.0,
                                                            )
                                                        values.mapIndexed { index, inches ->
                                                            val positionedAt = accumPrecipBarPositionInches(inches)
                                                            val formattedValue =
                                                                if (inches % 1.0 == 0.0) {
                                                                    inches.toInt().toString()
                                                                } else {
                                                                    inches.toString()
                                                                }
                                                            val label =
                                                                if (index == 0) {
                                                                    "$formattedValue in"
                                                                } else {
                                                                    formattedValue
                                                                }
                                                            Pair(positionedAt, label)
                                                        }
                                                    }

                                                    is UnitLength.Millimeters -> {
                                                        // Same fractional positions as JS imperial (0..25 in → 0..635 mm).
                                                        val inchTicks =
                                                            listOf(
                                                                0.01,
                                                                5.0,
                                                                7.0,
                                                                10.0,
                                                                12.0,
                                                                14.0,
                                                                16.0,
                                                                18.0,
                                                                20.0,
                                                                25.0,
                                                            )
                                                        inchTicks.mapIndexed { index, inches ->
                                                            val mm = inches * 25.4
                                                            val positionedAt = accumPrecipBarPositionInches(inches)
                                                            val label =
                                                                if (index == 0) {
                                                                    val v = round(mm * 10.0) / 10.0
                                                                    "$v mm"
                                                                } else {
                                                                    "${round(mm).toInt()}"
                                                                }
                                                            Pair(positionedAt, label)
                                                        }
                                                    }

                                                    else -> emptyList()
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            ACCUM_SNOW -> {
                BarLegend(
                    id = id,
                    title = "Accumulated Snowfall",
                    measurement = MeasurementUnits.MeasurementType.SNOWFALL,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.cubicBezier(0.55, 0.09, 1.0, 0.75),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.snowdepth.stops,
                                        range = 0.00254..1.524,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.snowfall,
                                        values =
                                            BarLegendLabels.Values.FromValues { unit ->
                                                when (unit) {
                                                    is UnitLength.Inches ->
                                                        listOf(
                                                            0.1,
                                                            1.0,
                                                            3.0,
                                                            6.0,
                                                            9.0,
                                                            12.0,
                                                            18.0,
                                                            24.0,
                                                            36.0,
                                                            48.0,
                                                            60.0
                                                        )

                                                    is UnitLength.Centimeters ->
                                                        listOf(
                                                            0.5,
                                                            3.0,
                                                            5.0,
                                                            10.0,
                                                            15.0,
                                                            25.0,
                                                            50.0,
                                                            75.0,
                                                            100.0,
                                                            150.0
                                                        )

                                                    else -> emptyList()
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            AIR_QUALITY_HEALTH_INDEX -> {
                PointLegend(
                    id = id,
                    title = "Air Quality Health Index (AQHI)",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#0000ff".toColorInt(), "Low"),
                            PointLegendItem("#00ff00".toColorInt(), "Moderate"),
                            PointLegendItem("#ffff00".toColorInt(), "High"),
                            PointLegendItem("#ff0000".toColorInt(), "Very High"),
                        ),
                )
            }

            AIR_QUALITY_INDEX -> {
                BarLegend(
                    id = id,
                    title = "Air Quality Index (AQI)",
                    measurement = MeasurementUnits.MeasurementType.NONE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.airQualityIndex.stops,
                                        range = 0.0..500.0,
                                        interpolate = true,
                                        positions = listOf(0.0, 0.1, 0.2, 0.4, 0.6, 0.8, 0.95, 1.0),
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values =
                                            BarLegendLabels.Values.FromValues { _ ->
                                                listOf(0.0, 50.0, 100.0, 150.0, 200.0, 300.0, 400.0, 500.0)
                                            },
                                    ),
                            )
                        ),
                )
            }

            AIR_QUALITY_INDEX_CAI -> {
                PointLegend(
                    id = id,
                    title = "Air Quality Index (Korean)",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#0000ff".toColorInt(), "Good"),
                            PointLegendItem("#00ff00".toColorInt(), "Moderate"),
                            PointLegendItem("#ffff00".toColorInt(), "Unhealthy"),
                            PointLegendItem("#ff0000".toColorInt(), "Very Unhealthy"),
                        ),
                )
            }

            AIR_QUALITY_INDEX_CAQI -> {
                PointLegend(
                    id = id,
                    title = "Air Quality Index (Common)",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#79bc6a".toColorInt(), "Very Low"),
                            PointLegendItem("#bbcf4c".toColorInt(), "Low"),
                            PointLegendItem("#eec20b".toColorInt(), "Medium"),
                            PointLegendItem("#f29305".toColorInt(), "High"),
                            PointLegendItem("#e8416f".toColorInt(), "Very High"),
                        ),
                )
            }

            AIR_QUALITY_INDEX_CATEGORIES -> {
                PointLegend(
                    id = id,
                    title = "Air Quality",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#29e11f".toColorInt(), "Good"),
                            PointLegendItem("#f8f92a".toColorInt(), "Moderate"),
                            PointLegendItem("#f9681b".toColorInt(), "Sensitive Groups"),
                            PointLegendItem("#f60115".toColorInt(), "Unhealthy"),
                            PointLegendItem("#7a2c83".toColorInt(), "Very Unhealthy"),
                            PointLegendItem("#65001b".toColorInt(), "Hazardous"),
                        ),
                )
            }

            AIR_QUALITY_INDEX_CHINA -> {
                PointLegend(
                    id = id,
                    title = "Air Quality Index (China)",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#00ff00".toColorInt(), "Excellent"),
                            PointLegendItem("#ffff00".toColorInt(), "Good"),
                            PointLegendItem("#ff9900".toColorInt(), "Lightly Polluted"),
                            PointLegendItem("#ff0000".toColorInt(), "Moderately Polluted"),
                            PointLegendItem("#540099".toColorInt(), "Heavily Polluted"),
                            PointLegendItem("#800000".toColorInt(), "Severely Polluted"),
                        ),
                )
            }

            AIR_QUALITY_INDEX_EAQI -> {
                PointLegend(
                    id = id,
                    title = "Air Quality Index (European)",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#50f0e6".toColorInt(), "Good"),
                            PointLegendItem("#50ccaa".toColorInt(), "Fair"),
                            PointLegendItem("#f0e641".toColorInt(), "Moderate"),
                            PointLegendItem("#ff5050".toColorInt(), "Poor"),
                            PointLegendItem("#960032".toColorInt(), "Very Poor"),
                            PointLegendItem("#7d2181".toColorInt(), "Extremely Poor"),
                        ),
                )
            }

            AIR_QUALITY_INDEX_UK_DAQI -> {
                PointLegend(
                    id = id,
                    title = "Air Quality Index (UK)",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#009900".toColorInt(), "Low"),
                            PointLegendItem("#ff9900".toColorInt(), "Moderate"),
                            PointLegendItem("#ff0000".toColorInt(), "High"),
                            PointLegendItem("#990099".toColorInt(), "Very High"),
                        ),
                )
            }

            AIR_QUALITY_INDEX_UBA_DAQI -> {
                PointLegend(
                    id = id,
                    title = "Air Quality Index (German)",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#50f0e6".toColorInt(), "Very Good"),
                            PointLegendItem("#50cdaa".toColorInt(), "Good"),
                            PointLegendItem("#f0e641".toColorInt(), "Moderate"),
                            PointLegendItem("#ff5050".toColorInt(), "Poor"),
                            PointLegendItem("#960032".toColorInt(), "Very Poor"),
                        ),
                )
            }

            AIR_QUALITY_INDEX_INDIA -> {
                PointLegend(
                    id = id,
                    title = "Air Quality Index (India)",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#00cc00".toColorInt(), "Good"),
                            PointLegendItem("#66cc00".toColorInt(), "Satisfactory"),
                            PointLegendItem("#ffff00".toColorInt(), "Moderate"),
                            PointLegendItem("#ff9900".toColorInt(), "Poor"),
                            PointLegendItem("#ff0000".toColorInt(), "Severe"),
                            PointLegendItem("#a52a2a".toColorInt(), "Hazardous"),
                        ),
                )
            }

            CARBON_MONOXIDE -> {
                BarLegend(
                    id = id,
                    title = "Carbon Monoxide (CO)",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.curve(Easing.IN_OUT_SQRT),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.airQualityCo.stops,
                                        range = 0.0..1000.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.concentration,
                                        values =
                                            BarLegendLabels.Values.FromValues { _ ->
                                                listOf(0.0, 125.0, 250.0, 500.0, 750.0, 1000.0)
                                            },
                                    ),
                            )
                        ),
                )
            }

            NITRIC_OXIDE -> {
                BarLegend(
                    id = id,
                    title = "Nitrogen Monoxide (NO)",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.curve(Easing.IN_SINE),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.airQualityNo.stops,
                                        range = 0.0..100.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.concentration,
                                        values =
                                            BarLegendLabels.Values.FromValues { _ ->
                                                listOf(0.0, 5.0, 10.0, 25.0, 50.0, 100.0)
                                            },
                                    ),
                            )
                        ),
                )
            }

            NITROGEN_DIOXIDE -> {
                BarLegend(
                    id = id,
                    title = "Nitrogen Dioxide (NO2)",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.curve(Easing.IN_SQRT),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.airQualityNo2.stops,
                                        range = 0.0..100.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.concentration,
                                        values =
                                            BarLegendLabels.Values.FromValues { _ ->
                                                listOf(0.0, 10.0, 20.0, 30.0, 50.0, 100.0)
                                            },
                                    ),
                            )
                        ),
                )
            }

            OZONE -> {
                BarLegend(
                    id = id,
                    title = "Ozone (03)",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.curve(Easing.IN_SQRT),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.airQualityO3.stops,
                                        range = 0.0..300.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.concentration,
                                        values =
                                            BarLegendLabels.Values.FromValues { _ ->
                                                listOf(0.0, 50.0, 100.0, 150.0, 225.0, 300.0)
                                            },
                                    ),
                            )
                        ),
                )
            }

            PARTICULATE_MATTER_10_MICRON -> {
                BarLegend(
                    id = id,
                    title = "Particle Pollution (PM10)",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.curve(Easing.IN_CUBIC),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.airQualityPm10.stops,
                                        range = 0.0..1000.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.concentration,
                                        values =
                                            BarLegendLabels.Values.FromValues { _ ->
                                                listOf(0.0, 10.0, 25.0, 50.0, 100.0, 250.0, 500.0, 1000.0)
                                            },
                                    ),
                            )
                        ),
                )
            }

            PARTICULATE_MATTER_2P5_MICRON -> {
                BarLegend(
                    id = id,
                    title = "Particle Pollution (PM2.5)",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.cubicBezier(0.65, 0.0, 0.85, 1.0),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.airQualityPm2p5.stops,
                                        range = 0.0..300.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.concentration,
                                        values =
                                            BarLegendLabels.Values.FromValues { _ ->
                                                listOf(0.0, 10.0, 25.0, 50.0, 100.0, 200.0, 300.0)
                                            },
                                    ),
                            )
                        ),
                )
            }

            SULFUR_DIOXIDE -> {
                BarLegend(
                    id = id,
                    title = "Sulfur Dioxide (SO2)",
                    measurement = MeasurementUnits.MeasurementType.CONCENTRATION,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.curve(Easing.IN_SQRT),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.airQualitySo2.stops,
                                        range = 0.0..100.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.concentration,
                                        values =
                                            BarLegendLabels.Values.FromValues { _ ->
                                                listOf(0.0, 5.0, 10.0, 25.0, 50.0, 100.0)
                                            },
                                    ),
                            )
                        ),
                )
            }

            ALERTS -> {
                PointLegend(
                    id = id,
                    title = "Alerts",
                    layerId = "^alerts(-outline|-short-fuse)?",
                    itemResolver = AlertsLegendItemResolver(),
                    items = listOf(),
                )
            }

            CLOUD_COVER -> {
                BarLegend(
                    id = id,
                    title = "Cloud Cover",
                    measurement = MeasurementUnits.MeasurementType.NONE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.sky.stops,
                                        range = 0.0..100.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values = BarLegendLabels.Values.Every { 10.0 },
                                    ),
                            )
                        ),
                )
            }

            CONVECTIVE -> {
                PointLegend(
                    id = id,
                    title = "Convective Outlook",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#b3e6b1".toColorInt(), "General"),
                            PointLegendItem("#6cbd69".toColorInt(), "Marginal"),
                            PointLegendItem("#f4f964".toColorInt(), "Slight"),
                            PointLegendItem("#e0b767".toColorInt(), "Enhanced"),
                            PointLegendItem("#e0686a".toColorInt(), "Moderate"),
                            PointLegendItem("#fe59ff".toColorInt(), "High"),
                        ),
                )
            }

            DEW_POINT -> {
                BarLegend(
                    id = id,
                    title = "Dew Point",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.dewPoint.stops,
                                        range = -84.44..32.22,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                        values = BarLegendLabels.Values.Every { 20.0 },
                                    ),
                            )
                        ),
                )
            }

            DROUGHT -> {
                PointLegend(
                    id = id,
                    title = "Drought Monitor",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#ffff00".toColorInt(), "Abnormally Dry"),
                            PointLegendItem("#fccc66".toColorInt(), "Moderate"),
                            PointLegendItem("#ff9b00".toColorInt(), "Severe"),
                            PointLegendItem("#e10000".toColorInt(), "Extreme"),
                            PointLegendItem("#600000".toColorInt(), "Exceptional"),
                        ),
                )
            }

            EARTHQUAKE -> {
                PointLegend(
                    id = id,
                    title = "Earthquakes",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#6fb314".toColorInt(), "Mini"),
                            PointLegendItem("#dfcb01".toColorInt(), "Minor"),
                            PointLegendItem("#ce8f00".toColorInt(), "Light"),
                            PointLegendItem("#ff5d01".toColorInt(), "Moderate"),
                            PointLegendItem("#e90004".toColorInt(), "Strong"),
                            PointLegendItem("#ce0052".toColorInt(), "Major"),
                            PointLegendItem("#b90285".toColorInt(), "Great"),
                            PointLegendItem("#f500ff".toColorInt(), "Catastrophic"),
                        ),
                )
            }

            FIRE_OBSERVATION -> {
                PointLegend(
                    id = id,
                    title = "Fires",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#E83A00".toColorInt(), "New"),
                            PointLegendItem("#E88900".toColorInt(), "Active"),
                            PointLegendItem("#6C6461".toColorInt(), "Contained"),
                        ),
                )
            }

            FIRE_OUTLOOK -> {
                PointLegend(
                    id = id,
                    title = "Fire Outlook",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#FFB268".toColorInt(), "Elevated"),
                            PointLegendItem("#FE666A".toColorInt(), "Critical"),
                            PointLegendItem("#FE58FF".toColorInt(), "Extreme"),
                        ),
                )
            }

            HAIL_POSH -> {
                BarLegend(
                    id = id,
                    title = "Severe Hail Probability",
                    measurement = MeasurementUnits.MeasurementType.RATIO,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops =
                                            listOf(
                                                ColorStop(0.0, toColor("#440154")),
                                                ColorStop(0.125, toColor("#482777")),
                                                ColorStop(0.25, toColor("#3f4a8a")),
                                                ColorStop(0.375, toColor("#31678e")),
                                                ColorStop(0.5, toColor("#26838f")),
                                                ColorStop(0.625, toColor("#1f9d8a")),
                                                ColorStop(0.75, toColor("#6cce5a")),
                                                ColorStop(0.875, toColor("#b6de2b")),
                                                ColorStop(1.0, toColor("#fee825")),
                                            ),
                                        range = 0.0..100.0,
                                        normalized = true,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.ratio,
                                        values = BarLegendLabels.Values.Every { 10.0 },
                                    ),
                            )
                        ),
                )
            }

            HAIL_SIZE -> {
                BarLegend(
                    id = id,
                    title = "Hail Size",
                    measurement = MeasurementUnits.MeasurementType.PRECIPITATION,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops =
                                            listOf(
                                                ColorStop(0.0, toColor("#440154")),
                                                ColorStop(0.125, toColor("#482777")),
                                                ColorStop(0.25, toColor("#3f4a8a")),
                                                ColorStop(0.375, toColor("#31678e")),
                                                ColorStop(0.5, toColor("#26838f")),
                                                ColorStop(0.625, toColor("#1f9d8a")),
                                                ColorStop(0.75, toColor("#6cce5a")),
                                                ColorStop(0.875, toColor("#b6de2b")),
                                                ColorStop(1.0, toColor("#fee825")),
                                            ),
                                        range = 0.0..76.2,
                                        normalized = true,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.precipitationRate,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitLength.Millimeters -> 5.0
                                                    is UnitLength.Inches -> 1.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            HAIL_THREAT -> {
                BarLegend(
                    id = id,
                    title = "Hail Threats (lead time)",
                    measurement = MeasurementUnits.MeasurementType.TIME,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.hailThreat.stops,
                                        range = 0.0..70.0,
                                        interpolate = false,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values = BarLegendLabels.Values.Every { 10.0 },
                                    ),
                            )
                        ),
                )
            }

            HEAT_INDEX -> {
                BarLegend(
                    id = id,
                    title = "Heat Index",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.temperature.stops,
                                        range = 26.66667..54.44,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitTemperature.Celsius -> 5.0
                                                    is UnitTemperature.Fahrenheit -> 10.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            HUMIDITY -> {
                BarLegend(
                    id = id,
                    title = "Humidity",
                    measurement = MeasurementUnits.MeasurementType.RATIO,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.humidity.stops,
                                        range = 0.0..100.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.ratio,
                                        values = BarLegendLabels.Values.Every { 20.0 },
                                    ),
                            )
                        ),
                )
            }

            LIGHTNING -> {
                PointLegend(
                    id = id,
                    title = "Lightning Strikes",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#eeeeee".toColorInt(), "< 1 minute"),
                            PointLegendItem("#F8E203".toColorInt(), "1-5 minutes"),
                            PointLegendItem("#F97000".toColorInt(), "5-10 minutes"),
                            PointLegendItem("#C4150D".toColorInt(), "> 10 minutes"),
                            PointLegendItem("#999999".toColorInt(), "Intra-cloud"),
                        ),
                )
            }

            LIGHTNING_DENSITY -> {
                BarLegend(
                    id = id,
                    title = "Lightning Density",
                    measurement = MeasurementUnits.MeasurementType.NONE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.lightningDensity.stops,
                                        range = 0.0..10.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values = BarLegendLabels.Values.Every { 1.0 },
                                    ),
                            )
                        ),
                )
            }

            LIGHTNING_THREAT -> {
                BarLegend(
                    id = id,
                    title = "Lightning Threats (lead time)",
                    measurement = MeasurementUnits.MeasurementType.TIME,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.lightningThreat.stops,
                                        range = 0.0..70.0,
                                        interpolate = false,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values = BarLegendLabels.Values.Every { 10.0 },
                                    ),
                            )
                        ),
                )
            }

            PRESSURE -> {
                BarLegend(
                    id = id,
                    title = "Surface Pressure",
                    measurement = MeasurementUnits.MeasurementType.PRESSURE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.mslp.stops,
                                        range = 950.0..1060.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitPressure.Millibars -> 20.0
                                                    is UnitPressure.InchesOfMercury -> 1.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            OCEAN_CURRENT -> {
                BarLegend(
                    id = id,
                    title = "Ocean Currents",
                    measurement = MeasurementUnits.MeasurementType.SPEED,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.oceanCurrent.stops,
                                        range = 0.0..3.0864,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.speed,
                                        values = BarLegendLabels.Values.Every { 1.0 },
                                    ),
                            )
                        ),
                )
            }

            RADAR -> {
                BarLegend(
                    id = id,
                    title = "Radar",
                    measurement = MeasurementUnits.MeasurementType.INTENSITY,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.radarRain.stops,
                                        range = 6.0..87.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values =
                                            BarLegendLabels.Values.FromLabels { _ ->
                                                listOf(0.0 to "Light", 0.5 to "RAIN", 1.0 to "Heavy")
                                            },
                                    ),
                            ),
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.radarMix.stops,
                                        range = 6.0..87.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values =
                                            BarLegendLabels.Values.FromLabels { _ ->
                                                listOf(0.0 to "Light", 0.5 to "MIX", 1.0 to "Heavy")
                                            },
                                    ),
                            ),
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.radarSnow.stops,
                                        range = 6.0..87.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values =
                                            BarLegendLabels.Values.FromLabels { _ ->
                                                listOf(0.0 to "Light", 0.5 to "SNOW", 1.0 to "Heavy")
                                            },
                                    ),
                            ),
                        ),
                )
            }

            RIVER_OBSERVATION -> {
                PointLegend(
                    id = id,
                    title = "River Observations",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#535353".toColorInt(), "Out of Service"),
                            PointLegendItem("#AFB6AD".toColorInt(), "Old Data"),
                            PointLegendItem("#5F9CE6".toColorInt(), "Unavailable"),
                            PointLegendItem("#7F5013".toColorInt(), "Low Threshold"),
                            PointLegendItem("#0EFF00".toColorInt(), "No Flooding"),
                            PointLegendItem("#FFFF00".toColorInt(), "Action"),
                            PointLegendItem("#FE8700".toColorInt(), "Minor"),
                            PointLegendItem("#FF0100".toColorInt(), "Moderate"),
                            PointLegendItem("#C000FF".toColorInt(), "Major"),
                        ),
                )
            }

            ROAD_WEATHER_RISK -> {
                PointLegend(
                    id = id,
                    title = "Road Rollover Risk",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#ccc".toColorInt(), "Minimal"),
                            PointLegendItem("#FFEB00".toColorInt(), "Low"),
                            PointLegendItem("#FF9C00".toColorInt(), "Moderate"),
                            PointLegendItem("#E00200".toColorInt(), "High"),
                            PointLegendItem("#9A00B8".toColorInt(), "Major"),
                        ),
                )
            }

            ROAD_WEATHER_SUMMARY -> {
                PointLegend(
                    id = id,
                    title = "Road Summary",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#00C500".toColorInt(), "Low Risk"),
                            PointLegendItem("#FFCE00".toColorInt(), "Moderate Risk"),
                            PointLegendItem("#FF0000".toColorInt(), "High Risk"),
                            PointLegendItem("#666".toColorInt(), "Unknown"),
                        ),
                )
            }

            ROAD_WEATHER_SURFACE -> {
                PointLegend(
                    id = id,
                    title = "Road Surface",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#bbb".toColorInt(), "Dry"),
                            PointLegendItem("#3B960F".toColorInt(), "Moist"),
                            PointLegendItem("#00E300".toColorInt(), "Wet"),
                            PointLegendItem("#B643FF".toColorInt(), "Slush"),
                            PointLegendItem("#0043FF".toColorInt(), "Snow"),
                            PointLegendItem("#FF00A6".toColorInt(), "Ice"),
                            PointLegendItem("#666".toColorInt(), "Unknown"),
                        ),
                )
            }

            ROAD_WEATHER_TEMPERATURE -> {
                BarLegend(
                    id = id,
                    title = "Road Temperature",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.temperature.stops,
                                        range = -40.0..71.11,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                        values = BarLegendLabels.Values.Every { 20.0 },
                                    ),
                            )
                        ),
                )
            }

            ROAD_WEATHER_TEMPERATURE_FREEZE -> {
                PointLegend(
                    id = id,
                    title = "Road Temperature - Freeze",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#992BFF".toColorInt(), "Hard Freeze"),
                            PointLegendItem("#0046FF".toColorInt(), "Freeze"),
                            PointLegendItem("#73DAFC".toColorInt(), "Near Freeze"),
                        ),
                )
            }

            SNOW_DEPTH -> {
                BarLegend(
                    id = id,
                    title = "Snow Depth",
                    measurement = MeasurementUnits.MeasurementType.SNOWFALL,
                    units = MeasurementUnits.IMPERIAL,
                    resample = EasingCurveFactory.cubicBezier(0.7, 0.0, 1.0, 0.6),
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.snowdepth.stops,
                                        range = 0.00254..1.524,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.snowfall,
                                        values =
                                            BarLegendLabels.Values.FromValues { unit ->
                                                when (unit) {
                                                    is UnitLength.Inches ->
                                                        listOf(0.1, 1.0, 3.0, 6.0, 12.0, 18.0, 24.0, 36.0, 48.0, 60.0)

                                                    is UnitLength.Centimeters ->
                                                        listOf(0.5, 3.0, 5.0, 10.0, 25.0, 50.0, 100.0, 150.0)

                                                    else -> emptyList()
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            STORM_SURGE -> {
                BarLegend(
                    id = id,
                    title = "Storm Surge",
                    measurement = MeasurementUnits.MeasurementType.HEIGHT,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.stormSurge.stops,
                                        range = 0.0..5.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.height,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitLength.Meters -> 1.0
                                                    is UnitLength.Feet -> 2.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            STORM_CELL -> {
                PointLegend(
                    id = id,
                    title = "Storm Cells",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#2ED300".toColorInt(), "General"),
                            PointLegendItem("#EBE100".toColorInt(), "Hail"),
                            PointLegendItem("#F17200".toColorInt(), "Rotating"),
                            PointLegendItem("#FF2600".toColorInt(), "Tornadic"),
                        ),
                )
            }

            STORM_REPORT -> {
                PointLegend(
                    id = id,
                    title = "Storm Reports",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#629FEC".toColorInt(), "Avalanche"),
                            PointLegendItem("#4100E2".toColorInt(), "Blizzard"),
                            PointLegendItem("#E66300".toColorInt(), "Fire"),
                            PointLegendItem("#117D01".toColorInt(), "Flood"),
                            PointLegendItem("#767676".toColorInt(), "Fog"),
                            PointLegendItem("#B300E2".toColorInt(), "Ice"),
                            PointLegendItem("#61DEF7".toColorInt(), "Hail"),
                            PointLegendItem("#8C8C8C".toColorInt(), "Lightning"),
                            PointLegendItem("#39E600".toColorInt(), "Rain"),
                            PointLegendItem("#165CEF".toColorInt(), "Snow"),
                            PointLegendItem("#40DB83".toColorInt(), "Tides"),
                            PointLegendItem("#C50000".toColorInt(), "Tornado"),
                            PointLegendItem("#D8CC03".toColorInt(), "Wind"),
                            PointLegendItem("#FF59B3".toColorInt(), "Tropical"),
                            PointLegendItem("#999999".toColorInt(), "Other"),
                        ),
                )
            }

            TEMPERATURE -> {
                BarLegend(
                    id = id,
                    title = "Temperatures",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.temperature.stops,
                                        range = -62.22..54.44,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                        values = BarLegendLabels.Values.Every { 20.0 },
                                    ),
                            )
                        ),
                )
            }

            TEMPERATURE_CHANGE_1_HOUR -> {
                BarLegend(
                    id = id,
                    title = "1-Hour Temp Change",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE_DELTA,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.tempChange1Hour.stops,
                                        range = -22.2..22.2,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.temperatureDelta,
                                        values = BarLegendLabels.Values.Every { 10.0 },
                                    ),
                            )
                        ),
                )
            }

            TEMPERATURE_CHANGE_24_HOUR -> {
                BarLegend(
                    id = id,
                    title = "24-Hour Temp Change",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE_DELTA,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.tempChange24Hour.stops,
                                        range = -27.75..27.75,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.temperatureDelta,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitTemperature.Celsius -> 10.0
                                                    is UnitTemperature.Fahrenheit -> 20.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            TIDE_HEIGHT -> {
                BarLegend(
                    id = id,
                    title = "Tide Height",
                    measurement = MeasurementUnits.MeasurementType.HEIGHT,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.tideHeight.stops,
                                        range = -12.192..12.192,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.height,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitLength.Meters -> 0.5
                                                    is UnitLength.Feet -> 2.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            TROPICAL_BREAKPOINT -> {
                PointLegend(
                    id = id,
                    title = "Tropical Cyclone Breakpoints",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#FFE403".toColorInt(), "Tropical Storm Watch"),
                            PointLegendItem("#FF9100".toColorInt(), "Tropical Storm Warning"),
                            PointLegendItem("#FF00D2".toColorInt(), "Hurricane Watch"),
                            PointLegendItem("#FF0018".toColorInt(), "Hurricane Warning"),
                        ),
                )
            }

            TROPICAL_CYCLONE -> {
                PointLegend(
                    id = id,
                    title = "Tropical Cyclones",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#4875FB".toColorInt(), "Low"),
                            PointLegendItem("#FFE700".toColorInt(), "Depression"),
                            PointLegendItem("#FEA800".toColorInt(), "Storm"),
                            PointLegendItem("#DD0002".toColorInt(), "Cat 1"),
                            PointLegendItem("#FF0491".toColorInt(), "Cat 2"),
                            PointLegendItem("#DD00FD".toColorInt(), "Cat 3"),
                            PointLegendItem("#FEAFFF".toColorInt(), "Cat 4"),
                            PointLegendItem("#EFEFEF".toColorInt(), "Cat 5"),
                            PointLegendItem("#DD0002".toColorInt(), "Typhoon"),
                            PointLegendItem("#EFEFEF".toColorInt(), "Super Typhoon"),
                        ),
                )
            }

            ULTRAVIOLET_INDEX -> {
                BarLegend(
                    id = id,
                    title = "Ultraviolet Index (UVI)",
                    measurement = MeasurementUnits.MeasurementType.NONE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.uvi.stops,
                                        range = 1.0..12.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values = BarLegendLabels.Values.Every { 1.0 },
                                    ),
                            )
                        ),
                )
            }

            VISIBILITY -> {
                BarLegend(
                    id = id,
                    title = "Visibility",
                    measurement = MeasurementUnits.MeasurementType.DISTANCE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.visibility.stops,
                                        range = 0.0..16093.4,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.distance,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitLength.Kilometers -> 2.0
                                                    is UnitLength.Miles -> 1.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            WAVE_HEIGHT, SWELL_HEIGHT -> {
                BarLegend(
                    id = id,
                    title = "Wave/Swell Height",
                    measurement = MeasurementUnits.MeasurementType.HEIGHT,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.waveHeight.stops,
                                        range = 0.0..15.0,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.height,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitLength.Meters -> 1.0
                                                    is UnitLength.Feet -> 5.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            WAVE_PERIOD, SWELL_PERIOD -> {
                BarLegend(
                    id = id,
                    title = "Wave/Swell Period",
                    measurement = MeasurementUnits.MeasurementType.TIME,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.wavePeriod.stops,
                                        range = 0.0..24.0,
                                        interpolate = false,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.none,
                                        values = BarLegendLabels.Values.Every { 2.0 },
                                    ),
                            )
                        ),
                )
            }

            WIND_CHILL -> {
                BarLegend(
                    id = id,
                    title = "Wind Chill",
                    measurement = MeasurementUnits.MeasurementType.TEMPERATURE,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.temperature.stops,
                                        range = -62.22..4.44444,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.temperature,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitTemperature.Celsius -> 10.0
                                                    is UnitTemperature.Fahrenheit -> 20.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }

            WIND_SPEED -> {
                BarLegend(
                    id = id,
                    title = "Wind Speeds",
                    measurement = MeasurementUnits.MeasurementType.SPEED,
                    units = MeasurementUnits.IMPERIAL,
                    resample = null,
                    items =
                        listOf(
                            BarLegendItem(
                                colorScaleOptions =
                                    ColorScaleOptions(
                                        stops = ColorScales.windSpeed.stops,
                                        range = 0.0..53.64,
                                        interpolate = true,
                                    ),
                                labels =
                                    BarLegendLabels(
                                        currentUnits = MeasurementUnits.IMPERIAL.speed,
                                        values =
                                            BarLegendLabels.Values.Every { unit ->
                                                when (unit) {
                                                    is UnitSpeed.KilometersPerHour -> 20.0
                                                    is UnitSpeed.MilesPerHour -> 10.0
                                                    else -> 1.0
                                                }
                                            },
                                    ),
                            )
                        ),
                )
            }
        }
}
