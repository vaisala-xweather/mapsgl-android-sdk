//
//  Climate.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:16.310Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.HeatmapLayerDescriptor
import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.style.HeatmapLayerPaint
import com.xweather.mapsgl.style.HeatmapPaint
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.TextPaint
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.weather.BaseVectorConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.CompositeWeatherLayerConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.LegendCode
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations
import com.xweather.mapsgl.weather.toColor

object Climate {
    class DroughtMonitor(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.DROUGHT_MONITOR
        override val source: GeoJSONSourceDescriptor = WeatherSource.drought(service)
        override val layer: FillLayerDescriptor =
            FillLayerDescriptor(
                "climate.drought_monitor.fill",
                source.id,
                paint =
                    FillLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.category")),
                                            ColorScales.droughtMonitor.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.DROUGHT]
        override var legend: Legend? = null

        init {
            legend = LegendCode.DROUGHT.getLegend()
        }
    }

    class DroughtMonitorOutline(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.DROUGHT_MONITOR_OUTLINE
        override val source: GeoJSONSourceDescriptor = WeatherSource.drought(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "climate.drought_monitor.outline",
                source.id,
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.category")),
                                            ColorScales.droughtMonitor.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                                thickness = StyleValue.Constant(3.0),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.DROUGHT]
        override var legend: Legend? = null

        init {
            legend = LegendCode.DROUGHT.getLegend()
        }
    }

    class Earthquakes(
        val service: WeatherService,
    ) : BaseVectorConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.EARTHQUAKES
        override val source: GeoJSONSourceDescriptor = WeatherSource.earthquakes(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "climate.earthquakes.point",
                source.id,
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.downcase(Expression.get("report.type")),
                                            ColorScales.earthquake.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.downcase(Expression.get("report.type")),
                                            listOf(
                                                Expression.Step("minor", result = 8),
                                                Expression.Step("light", result = 9),
                                                Expression.Step("moderate", result = 10),
                                                Expression.Step("strong", result = 12),
                                                Expression.Step("major", result = 14),
                                                Expression.Step("great", result = 17),
                                                Expression.Step("catastrophic", result = 20),
                                            ),
                                            5,
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.EARTHQUAKE]
        override var legend: Legend? = null

        init {
            legend = LegendCode.EARTHQUAKE.getLegend()
        }
    }

    class EarthquakesHeat(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, HeatmapLayerDescriptor> {
        override val code: LayerCode = LayerCode.EARTHQUAKES_HEAT
        override val source: GeoJSONSourceDescriptor = WeatherSource.earthquakes(service)
        override val layer: HeatmapLayerDescriptor =
            HeatmapLayerDescriptor(
                "climate.earthquakes.heat",
                source.id,
                paint =
                    HeatmapLayerPaint(
                        heatmap =
                            HeatmapPaint(
                                color = StyleValue.Expression(
                                    Expression.interpolate(
                                        listOf("heatmap-density"),
                                        stops = ColorScales.heatmap.stops
                                    )
                                ),
                                radius = StyleValue.Constant(20.0),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.EARTHQUAKE]
        override var legend: Legend? = null
    }

    class Fires(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.FIRES
        override val layers =
            listOf(
                FiresPerimeter(service),
                FiresObs(service),
                FiresObsNames(service),
            )
    }

    class FiresIcons(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.FIRES_ICONS
        override val layers =
            listOf(
                FiresPerimeter(service),
                FiresObsIcons(service),
                FiresObsNames(service),
            )
    }

    class FiresObs(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.FIRES_OBS
        override val source: VectorSourceDescriptor = WeatherSource.fires_obs(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "climate.fire_obs.point",
                source.id,
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.switchCase(
                                            listOf(
                                                Expression.Case(
                                                    condition = Expression.equals(
                                                        Expression.get("report.perContained"),
                                                        100
                                                    ), result = "#6C6461"
                                                ),
                                                Expression.Case(
                                                    condition =
                                                        Expression.and(
                                                            listOf(
                                                                Expression.has("report.startTimestampMillis"),
                                                                Expression.lessThan(
                                                                    Expression.subtract(
                                                                        Expression.toNumber(Expression.get("now")),
                                                                        Expression.toNumber(
                                                                            Expression.get("report.startTimestampMillis"),
                                                                        ),
                                                                    ),
                                                                    86400000,
                                                                ),
                                                            ),
                                                        ),
                                                    result = "#E83A00",
                                                ),
                                            ),
                                            fallback = "#E88900",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius =
                                    StyleValue.Expression(
                                        Expression.min(
                                            20,
                                            Expression.round(
                                                Expression.add(
                                                    5,
                                                    Expression.multiply(
                                                        15,
                                                        Expression.divide(
                                                            Expression.multiply(
                                                                Expression.get("report.areaAC"),
                                                                Expression.switchCase(
                                                                    listOf(
                                                                        Expression.Case(
                                                                            condition =
                                                                                Expression.equals(
                                                                                    Expression.get("report.perContained"),
                                                                                    100,
                                                                                ),
                                                                            result = 0.75,
                                                                        ),
                                                                    ),
                                                                    fallback = 1,
                                                                ),
                                                            ),
                                                            10000,
                                                        ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WILDFIRE]
        override var legend: Legend? = null

        init {
            legend = LegendCode.FIRE_OBSERVATION.getLegend()
        }
    }

    class FiresObsHeat(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor>() {
        override val code: LayerCode = LayerCode.FIRES_OBS_HEAT
        override val source: VectorSourceDescriptor = WeatherSource.fires_obs(service)
        override val layer: HeatmapLayerDescriptor =
            HeatmapLayerDescriptor(
                "climate.fire_obs.heat",
                source.id,
                paint =
                    HeatmapLayerPaint(
                        heatmap =
                            HeatmapPaint(
                                color = StyleValue.Expression(
                                    Expression.interpolate(
                                        listOf("heatmap-density"),
                                        stops = ColorScales.heatmap.stops
                                    )
                                ),
                                radius = StyleValue.Constant(20.0),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WILDFIRE]
        override var legend: Legend? = null
    }

    class FiresObsIcons(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor>() {
        override val code: LayerCode = LayerCode.FIRES_OBS_ICONS
        override val source: VectorSourceDescriptor = WeatherSource.fires_obs(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "climate.fire_obs.icons",
                source.id,
                paint =
                    SymbolLayerPaint(
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image =
                                    StyleValue.Expression(
                                        Expression.concat(
                                            listOf(
                                                "mapsgl:fire-",
                                                Expression.toString(
                                                    Expression.max(
                                                        1,
                                                        Expression.min(
                                                            5,
                                                            Expression.floor(
                                                                Expression.add(
                                                                    1,
                                                                    Expression.multiply(
                                                                        4,
                                                                        Expression.divide(
                                                                            Expression.subtract(
                                                                                Expression.coalesce(
                                                                                    listOf(
                                                                                        Expression.get("report.perContained"),
                                                                                        0,
                                                                                    ),
                                                                                ),
                                                                                50,
                                                                            ),
                                                                            50,
                                                                        ),
                                                                    ),
                                                                ),
                                                            ),
                                                        ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    ),
                                size =
                                    StyleValue.Expression(
                                        Expression.min(
                                            0.4,
                                            Expression.add(
                                                0.15,
                                                Expression.multiply(
                                                    0.25,
                                                    Expression.divide(
                                                        Expression.max(
                                                            1,
                                                            Expression.get("report.areaAC"),
                                                        ),
                                                        10000,
                                                    ),
                                                ),
                                            ),
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WILDFIRE]
        override var legend: Legend? = null
    }

    class FiresObsNames(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor>() {
        override val code: LayerCode = LayerCode.FIRES_OBS_NAMES
        override val source: VectorSourceDescriptor = WeatherSource.fires_obs(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "climate.fire_obs.names",
                source.id,
                paint =
                    SymbolLayerPaint(
                        text =
                            listOf(
                                TextPaint(
                                    value = StyleValue.Expression(Expression.get("report.name")),
                                    size = StyleValue.Constant(14.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.TOP),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.5)),
                                ),
                                TextPaint(
                                    value =
                                        StyleValue.Expression(
                                            Expression.concat(
                                                listOf(
                                                    Expression.toString(
                                                        Expression.round(
                                                            Expression.max(
                                                                1,
                                                                Expression.switchCase(
                                                                    listOf(
                                                                        Expression.Case(
                                                                            condition =
                                                                                Expression.and(
                                                                                    listOf(
                                                                                        Expression.has("perimeter"),
                                                                                        Expression.toBoolean(
                                                                                            Expression.get(
                                                                                                "perimeter"
                                                                                            )
                                                                                        ),
                                                                                        Expression.has("perimeter.areaAC"),
                                                                                    ),
                                                                                ),
                                                                            result = Expression.get("perimeter.areaAC"),
                                                                        ),
                                                                    ),
                                                                    fallback = Expression.get("report.areaAC"),
                                                                ),
                                                            ),
                                                        ),
                                                    ),
                                                    " acres",
                                                ),
                                            ),
                                        ),
                                    size = StyleValue.Constant(11.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.TOP),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class FiresOutlook(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.FIRES_OUTLOOK
        override val source: GeoJSONSourceDescriptor = WeatherSource.fires_outlook(service)
        override val layer: FillLayerDescriptor =
            FillLayerDescriptor(
                "climate.fire_outlook.fill",
                source.id,
                paint =
                    FillLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.downcase(Expression.get("details.risk.type")),
                                            listOf(
                                                Expression.Step("elevated", result = "#FFB268"),
                                                Expression.Step("critical", result = "#FE666A"),
                                                Expression.Step("extreme", result = "#FE58FF"),
                                            ),
                                            "#999999",
                                        ),
                                    ),
                                opacity = StyleValue.Constant(0.9),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.FIRE_OUTLOOK.getLegend()
        }
    }

    class FiresPerimeter(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.FIRES_PERIMETER
        override val source: GeoJSONSourceDescriptor = WeatherSource.fires_perimeter(service)
        override val layer: FillLayerDescriptor =
            FillLayerDescriptor(
                "climate.fire_obs.perimeter",
                source.id,
                filter =
                    Expression.contains(
                        Expression.geometryType,
                        listOf(
                            "Polygon",
                            "MultiPolygon",
                        ),
                    ),
                paint =
                    FillLayerPaint(
                        fill =
                            FillPaint(
                                color = StyleValue.Constant(toColor("#ff0000")),
                                opacity = StyleValue.Constant(0.6),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#ff0000")),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.WILDFIRE]
        override var legend: Legend? = null
    }

    class RiverObservations(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.RIVER_OBSERVATIONS
        override val source: VectorSourceDescriptor = WeatherSource.rivers(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "climate.river_obs.point",
                source.id,
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.downcase(Expression.get("ob.status")),
                                            listOf(
                                                Expression.Step("out_of_service", result = "#535353"),
                                                Expression.Step("obs_not_current", result = "#AFB6AD"),
                                                Expression.Step("not_defined", result = "#5F9CE6"),
                                                Expression.Step("low_threshold", result = "#7F5013"),
                                                Expression.Step("no_flooding", result = "#0EFF00"),
                                                Expression.Step("action", result = "#FFFF00"),
                                                Expression.Step("minor", result = "#FE8700"),
                                                Expression.Step("moderate", result = "#FF0100"),
                                                Expression.Step("major", result = "#C000FF"),
                                            ),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(3.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.RIVER_OBSERVATION]
        override var legend: Legend? = null

        init {
            legend = LegendCode.RIVER_OBSERVATION.getLegend()
        }
    }
}
