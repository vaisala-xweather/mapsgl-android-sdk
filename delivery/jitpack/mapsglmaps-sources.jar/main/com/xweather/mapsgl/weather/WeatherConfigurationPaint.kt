package com.xweather.mapsgl.weather

import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.style.StyleValue

/**
 * Applies **stroke thickness** to a single vector **line** weather configuration (parity with JS
 * `addWeatherLayer(..., { paint: { stroke: { thickness } } })`).
 *
 * No-op if this is not a [WeatherLayerConfiguration] whose layer is a [LineLayerDescriptor].
 * For [CompositeWeatherLayerConfiguration], use [setLineStrokeThicknessOnAllLineLayers] or edit
 * [CompositeWeatherLayerConfiguration.layers] in a [MapController.addWeatherLayer] configure callback.
 */
fun WeatherConfiguration.setLineStrokeThickness(thickness: Double) {
    val w = this as? WeatherLayerConfiguration<*, *> ?: return
    val line = w.layer as? LineLayerDescriptor ?: return
    line.paint.stroke.thickness = StyleValue.Constant(thickness)
}

/**
 * Recurses into composite configs and sets line stroke thickness on every child that is a line layer.
 */
fun WeatherConfiguration.setLineStrokeThicknessOnAllLineLayers(thickness: Double) {
    when (this) {
        is CompositeWeatherLayerConfiguration ->
            layers.forEach { it.setLineStrokeThicknessOnAllLineLayers(thickness) }
        else -> setLineStrokeThickness(thickness)
    }
}
