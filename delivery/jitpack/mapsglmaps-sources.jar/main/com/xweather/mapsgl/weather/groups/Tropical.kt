//
//  Tropical.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:16.319Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.TextPaint
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.CompositeWeatherLayerConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.LegendCode
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.toColor

object Tropical {
    class TropicalCyclones(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES
        override val layers =
            listOf(
                TropicalCyclonesForecastErrorCones(service),
                TropicalCyclonesTrackLines(service),
                TropicalCyclonesForecastLines(service),
                TropicalCyclonesTrackPoints(service),
                TropicalCyclonesForecastPoints(service),
                TropicalCyclonesPositions(service),
                TropicalCyclonesNames(service),
            )
    }

    class TropicalCyclonesArchive(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_ARCHIVE
        override val layers =
            listOf(
                TropicalCyclonesForecastErrorCones(service),
                TropicalCyclonesTrackLinesArchive(service),
                TropicalCyclonesForecastLines(service),
                TropicalCyclonesTrackPointsArchive(service),
                TropicalCyclonesForecastPoints(service),
                TropicalCyclonesNamesArchive(service),
            )
    }

    class TropicalCyclonesArchiveIcons(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_ARCHIVE_ICONS
        override val layers =
            listOf(
                TropicalCyclonesForecastErrorCones(service),
                TropicalCyclonesTrackLinesArchive(service),
                TropicalCyclonesForecastLines(service),
                TropicalCyclonesTrackPointIconsArchive(service),
                TropicalCyclonesForecastPointIcons(service),
                TropicalCyclonesPositionIcons(service),
                TropicalCyclonesNamesArchive(service),
            )
    }

    class TropicalCyclonesBreakPoints(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_BREAK_POINTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "tropical.active.breakpoints",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "breakPointAlert"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("alertType")),
                                            listOf(
                                                Expression.Step("TR.A", result = "#FFE403"),
                                                Expression.Step("TR.W", result = "#FF9100"),
                                                Expression.Step("HU.A", result = "#FF00D2"),
                                                Expression.Step("HU.W", result = "#FF0018"),
                                            ),
                                            "#999",
                                        ),
                                    ),
                                thickness =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("alertType")),
                                            listOf(
                                                Expression.Step("TR.W", result = 8),
                                                Expression.Step("HU.W", result = 8),
                                            ),
                                            4,
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_BREAKPOINT.getLegend()
        }
    }

    class TropicalCyclonesForecastErrorCones(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_FORECAST_ERROR_CONES
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: FillLayerDescriptor =
            FillLayerDescriptor(
                "tropical.cone.fill",
                source.id,
                filter =
                    Expression.contains(
                        Expression.geometryType,
                        listOf(
                            "Polygon",
                            "MultiPolygon",
                        ),
                    ),
                paint =
                    FillLayerPaint(
                        fill =
                            FillPaint(
                                color = StyleValue.Constant(toColor("rgba(255, 0, 0, 0.1)")),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#ff0000")),
                                thickness = StyleValue.Constant(1.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesForecastLines(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_FORECAST_LINES
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "tropical.forecast_active.line",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "forecastLine"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                                thickness = StyleValue.Constant(3.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesForecastLinesInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_FORECAST_LINES_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "tropical.forecast_invests.line",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "forecastLine"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                                thickness = StyleValue.Constant(3.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesForecastPointIcons(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_FORECAST_POINT_ICONS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.forecast.symbol",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "forecastPoint"),
                paint =
                    GridLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(0.5),
                            ),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.get("details.stormType"),
                                            listOf(
                                                Expression.Step("H", result = "mapsgl:hurricane"),
                                                Expression.Step("TY", result = "mapsgl:hurricane"),
                                                Expression.Step("TC", result = "mapsgl:hurricane"),
                                                Expression.Step("STY", result = "mapsgl:hurricane"),
                                                Expression.Step("TS", result = "mapsgl:tropical-storm"),
                                                Expression.Step("TD", result = "mapsgl:tropical-depression"),
                                            ),
                                            "mapsgl:tropical-low",
                                        ),
                                    ),
                                size =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 0.3),
                                                Expression.Step(4, result = 0.5),
                                            ),
                                        ),
                                    ),
                            ),
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(null, result = ""),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            Expression.match(
                                                                Expression.get("details.stormCat"),
                                                                listOf(
                                                                    Expression.Step(
                                                                        listOf(
                                                                            "H1",
                                                                            "H2",
                                                                            "H3",
                                                                            "H4",
                                                                            "H5",
                                                                        ),
                                                                        result = Expression.slice(
                                                                            Expression.get("details.stormCat"),
                                                                            1,
                                                                            2
                                                                        ),
                                                                    ),
                                                                    Expression.Step("STY", result = "S"),
                                                                ),
                                                                "",
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesForecastPointIconsInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_FORECAST_POINT_ICONS_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.forecast.symbol",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "forecastPoint"),
                paint =
                    GridLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(0.5),
                            ),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.get("details.stormType"),
                                            listOf(
                                                Expression.Step("H", result = "mapsgl:hurricane"),
                                                Expression.Step("TY", result = "mapsgl:hurricane"),
                                                Expression.Step("TC", result = "mapsgl:hurricane"),
                                                Expression.Step("STY", result = "mapsgl:hurricane"),
                                                Expression.Step("TS", result = "mapsgl:tropical-storm"),
                                                Expression.Step("TD", result = "mapsgl:tropical-depression"),
                                            ),
                                            "mapsgl:tropical-low",
                                        ),
                                    ),
                                size =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 0.3),
                                                Expression.Step(4, result = 0.5),
                                            ),
                                        ),
                                    ),
                            ),
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(null, result = ""),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            Expression.match(
                                                                Expression.get("details.stormCat"),
                                                                listOf(
                                                                    Expression.Step(
                                                                        listOf(
                                                                            "H1",
                                                                            "H2",
                                                                            "H3",
                                                                            "H4",
                                                                            "H5",
                                                                        ),
                                                                        result = Expression.slice(
                                                                            Expression.get("details.stormCat"),
                                                                            1,
                                                                            2
                                                                        ),
                                                                    ),
                                                                    Expression.Step("STY", result = "S"),
                                                                ),
                                                                "",
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesForecastPoints(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_FORECAST_POINTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "tropical.forecast_active.circle",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "forecastPoint"),
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesForecastPointsInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_FORECAST_POINTS_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "tropical.forecast_invests.circle",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "forecastPoint"),
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesIcons(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_ICONS
        override val layers =
            listOf(
                TropicalCyclonesForecastErrorCones(service),
                TropicalCyclonesTrackLines(service),
                TropicalCyclonesForecastLines(service),
                TropicalCyclonesTrackPointIcons(service),
                TropicalCyclonesForecastPointIcons(service),
                TropicalCyclonesPositionIcons(service),
                TropicalCyclonesNames(service),
            )
    }

    class TropicalCyclonesInvests(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_INVESTS
        override val layers =
            listOf(
                TropicalCyclonesTrackLinesInvests(service),
                TropicalCyclonesTrackPointsInvests(service),
                TropicalCyclonesPositionsInvests(service),
                TropicalCyclonesNamesInvests(service),
            )
    }

    class TropicalCyclonesInvestsIcons(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_INVESTS_ICONS
        override val layers =
            listOf(
                TropicalCyclonesTrackLinesInvests(service),
                TropicalCyclonesTrackPointIconsInvests(service),
                TropicalCyclonesPositionIconsInvests(service),
                TropicalCyclonesNamesInvests(service),
            )
    }

    class TropicalCyclonesNames(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_NAMES
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.names_active.text",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "position"),
                paint =
                    GridLayerPaint(
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value = StyleValue.Expression(Expression.get("details.stormShortName")),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.TOP),
                                    offset =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(
                                                        null,
                                                        result =
                                                            listOf(
                                                                0,
                                                                0.667,
                                                            ),
                                                    ),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            listOf(
                                                                0,
                                                                1,
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesNamesArchive(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_NAMES_ARCHIVE
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_archive(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.names_archive.text",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "position"),
                paint =
                    GridLayerPaint(
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value = StyleValue.Expression(Expression.get("details.stormShortName")),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.TOP),
                                    offset =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(
                                                        null,
                                                        result =
                                                            listOf(
                                                                0,
                                                                0.667,
                                                            ),
                                                    ),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            listOf(
                                                                0,
                                                                1,
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesNamesInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_NAMES_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.names_invests.text",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "position"),
                paint =
                    GridLayerPaint(
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value = StyleValue.Expression(Expression.get("details.stormShortName")),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.TOP),
                                    offset =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(
                                                        null,
                                                        result =
                                                            listOf(
                                                                0,
                                                                0.667,
                                                            ),
                                                    ),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            listOf(
                                                                0,
                                                                1,
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesPositionIcons(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_POSITION_ICONS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.positions_active.symbol",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "position"),
                paint =
                    GridLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(0.5),
                            ),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.get("details.stormType"),
                                            listOf(
                                                Expression.Step("H", result = "mapsgl:hurricane"),
                                                Expression.Step("TY", result = "mapsgl:hurricane"),
                                                Expression.Step("TC", result = "mapsgl:hurricane"),
                                                Expression.Step("STY", result = "mapsgl:hurricane"),
                                                Expression.Step("TS", result = "mapsgl:tropical-storm"),
                                                Expression.Step("TD", result = "mapsgl:tropical-depression"),
                                            ),
                                            "mapsgl:tropical-low",
                                        ),
                                    ),
                                size =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 0.3),
                                                Expression.Step(4, result = 0.5),
                                            ),
                                        ),
                                    ),
                            ),
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(null, result = ""),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            Expression.match(
                                                                Expression.get("details.stormCat"),
                                                                listOf(
                                                                    Expression.Step(
                                                                        listOf(
                                                                            "H1",
                                                                            "H2",
                                                                            "H3",
                                                                            "H4",
                                                                            "H5",
                                                                        ),
                                                                        result = Expression.slice(
                                                                            Expression.get("details.stormCat"),
                                                                            1,
                                                                            2
                                                                        ),
                                                                    ),
                                                                    Expression.Step("STY", result = "S"),
                                                                ),
                                                                "",
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesPositionIconsInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_POSITION_ICONS_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.positions_invests.symbol",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "position"),
                paint =
                    GridLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(0.5),
                            ),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.get("details.stormType"),
                                            listOf(
                                                Expression.Step("H", result = "mapsgl:hurricane"),
                                                Expression.Step("TY", result = "mapsgl:hurricane"),
                                                Expression.Step("TC", result = "mapsgl:hurricane"),
                                                Expression.Step("STY", result = "mapsgl:hurricane"),
                                                Expression.Step("TS", result = "mapsgl:tropical-storm"),
                                                Expression.Step("TD", result = "mapsgl:tropical-depression"),
                                            ),
                                            "mapsgl:tropical-low",
                                        ),
                                    ),
                                size =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 0.3),
                                                Expression.Step(4, result = 0.5),
                                            ),
                                        ),
                                    ),
                            ),
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(null, result = ""),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            Expression.match(
                                                                Expression.get("details.stormCat"),
                                                                listOf(
                                                                    Expression.Step(
                                                                        listOf(
                                                                            "H1",
                                                                            "H2",
                                                                            "H3",
                                                                            "H4",
                                                                            "H5",
                                                                        ),
                                                                        result = Expression.slice(
                                                                            Expression.get("details.stormCat"),
                                                                            1,
                                                                            2
                                                                        ),
                                                                    ),
                                                                    Expression.Step("STY", result = "S"),
                                                                ),
                                                                "",
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesPositions(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_POSITIONS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "tropical.positions_active.circle",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "position"),
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesPositionsInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_POSITIONS_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "tropical.positions_invests.circle",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "position"),
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackLines(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_LINES
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "tropical.track_active.line",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackLine"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                                thickness = StyleValue.Constant(3.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackLinesArchive(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_LINES_ARCHIVE
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_archive(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "tropical.track_archive.line",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackLine"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                                thickness = StyleValue.Constant(3.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackLinesInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_LINES_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "tropical.track_invests.line",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackLine"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                                thickness = StyleValue.Constant(3.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackPointIcons(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_POINT_ICONS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.track_active.symbol",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackPoint"),
                paint =
                    GridLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(0.5),
                            ),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.get("details.stormType"),
                                            listOf(
                                                Expression.Step("H", result = "mapsgl:hurricane"),
                                                Expression.Step("TY", result = "mapsgl:hurricane"),
                                                Expression.Step("TC", result = "mapsgl:hurricane"),
                                                Expression.Step("STY", result = "mapsgl:hurricane"),
                                                Expression.Step("TS", result = "mapsgl:tropical-storm"),
                                                Expression.Step("TD", result = "mapsgl:tropical-depression"),
                                            ),
                                            "mapsgl:tropical-low",
                                        ),
                                    ),
                                size =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 0.3),
                                                Expression.Step(4, result = 0.5),
                                            ),
                                        ),
                                    ),
                            ),
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(null, result = ""),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            Expression.match(
                                                                Expression.get("details.stormCat"),
                                                                listOf(
                                                                    Expression.Step(
                                                                        listOf(
                                                                            "H1",
                                                                            "H2",
                                                                            "H3",
                                                                            "H4",
                                                                            "H5",
                                                                        ),
                                                                        result = Expression.slice(
                                                                            Expression.get("details.stormCat"),
                                                                            1,
                                                                            2
                                                                        ),
                                                                    ),
                                                                    Expression.Step("STY", result = "S"),
                                                                ),
                                                                "",
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackPointIconsArchive(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_POINT_ICONS_ARCHIVE
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_archive(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.track_archive.symbol",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackPoint"),
                paint =
                    GridLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(0.5),
                            ),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.get("details.stormType"),
                                            listOf(
                                                Expression.Step("H", result = "mapsgl:hurricane"),
                                                Expression.Step("TY", result = "mapsgl:hurricane"),
                                                Expression.Step("TC", result = "mapsgl:hurricane"),
                                                Expression.Step("STY", result = "mapsgl:hurricane"),
                                                Expression.Step("TS", result = "mapsgl:tropical-storm"),
                                                Expression.Step("TD", result = "mapsgl:tropical-depression"),
                                            ),
                                            "mapsgl:tropical-low",
                                        ),
                                    ),
                                size =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 0.3),
                                                Expression.Step(4, result = 0.5),
                                            ),
                                        ),
                                    ),
                            ),
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(null, result = ""),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            Expression.match(
                                                                Expression.get("details.stormCat"),
                                                                listOf(
                                                                    Expression.Step(
                                                                        listOf(
                                                                            "H1",
                                                                            "H2",
                                                                            "H3",
                                                                            "H4",
                                                                            "H5",
                                                                        ),
                                                                        result = Expression.slice(
                                                                            Expression.get("details.stormCat"),
                                                                            1,
                                                                            2
                                                                        ),
                                                                    ),
                                                                    Expression.Step("STY", result = "S"),
                                                                ),
                                                                "",
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackPointIconsInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_POINT_ICONS_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "tropical.track_invests.symbol",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackPoint"),
                paint =
                    GridLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(0.5),
                            ),
                        icon =
                            IconPaint(
                                allowOverlap = StyleValue.Constant(true),
                                image =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.get("details.stormType"),
                                            listOf(
                                                Expression.Step("H", result = "mapsgl:hurricane"),
                                                Expression.Step("TY", result = "mapsgl:hurricane"),
                                                Expression.Step("TC", result = "mapsgl:hurricane"),
                                                Expression.Step("STY", result = "mapsgl:hurricane"),
                                                Expression.Step("TS", result = "mapsgl:tropical-storm"),
                                                Expression.Step("TD", result = "mapsgl:tropical-depression"),
                                            ),
                                            "mapsgl:tropical-low",
                                        ),
                                    ),
                                size =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 0.3),
                                                Expression.Step(4, result = 0.5),
                                            ),
                                        ),
                                    ),
                            ),
                        text =
                            listOf(
                                TextPaint(
                                    allowOverlap = StyleValue.Constant(true),
                                    value =
                                        StyleValue.Expression(
                                            Expression.step(
                                                Expression.zoom,
                                                listOf(
                                                    Expression.Step(null, result = ""),
                                                    Expression.Step(
                                                        4,
                                                        result =
                                                            Expression.match(
                                                                Expression.get("details.stormCat"),
                                                                listOf(
                                                                    Expression.Step(
                                                                        listOf(
                                                                            "H1",
                                                                            "H2",
                                                                            "H3",
                                                                            "H4",
                                                                            "H5",
                                                                        ),
                                                                        result = Expression.slice(
                                                                            Expression.get("details.stormCat"),
                                                                            1,
                                                                            2
                                                                        ),
                                                                    ),
                                                                    Expression.Step("STY", result = "S"),
                                                                ),
                                                                "",
                                                            ),
                                                    ),
                                                ),
                                            ),
                                        ),
                                    size = StyleValue.Constant(12.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#444")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackPoints(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_POINTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_active(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "tropical.track_active.circle",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackPoint"),
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackPointsArchive(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_POINTS_ARCHIVE
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_archive(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "tropical.track_archive.circle",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackPoint"),
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }

    class TropicalCyclonesTrackPointsInvests(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
        override val code: LayerCode = LayerCode.TROPICAL_CYCLONES_TRACK_POINTS_INVESTS
        override val source: GeoJSONSourceDescriptor = WeatherSource.tropical_invests(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "tropical.track_invests.circle",
                source.id,
                filter = Expression.equals(Expression.get("featureType"), "trackPoint"),
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.upcase(Expression.get("details.stormCat")),
                                            ColorScales.tropicalCyclone.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            legend = LegendCode.TROPICAL_CYCLONE.getLegend()
        }
    }
}
