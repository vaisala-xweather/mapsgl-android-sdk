package com.xweather.mapsgl.weather

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.Log
import androidx.annotation.Keep
import androidx.compose.ui.graphics.toArgb
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.ContourLayerDescriptor
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.GridLayerDescriptor
import com.xweather.mapsgl.layers.spec.HeatmapLayerDescriptor
import com.xweather.mapsgl.layers.spec.LayerDescriptor
import com.xweather.mapsgl.layers.spec.LayerEventEmitter
import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.RasterLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor
import com.xweather.mapsgl.map.ImageRegisteringMap
import com.xweather.mapsgl.map.MapStyle
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.SourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.utils.replaceVars
import com.xweather.mapsgl.weather.common.Presentation
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import java.net.URL

interface WeatherConfiguration {
    val code: LayerCode
}

interface WeatherLayerConfiguration<
        S : SourceDescriptor,       // The type of the source
        L : LayerDescriptor<*>,      // The type of the LayerDescriptor
        > : WeatherConfiguration {
    val source: S
    val layer: L // layer is of type L, and L guarantees its 'paint' property is of type P

    /**
     * An optional presentation object for this layer.
     * The default implementation is `null`.
     * Classes that have a presentation should override this property.
     */
    var presentation: Presentation?
    var legend: Legend?

}


typealias SampleConfiguration = WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor>
typealias VCircleConfiguration = WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>

interface CompositeWeatherLayerConfiguration : WeatherConfiguration {
    // Each layer in the composite will now also conform to the new WeatherLayerConfiguration structure
    val layers: List<WeatherLayerConfiguration<*, *>> // Or use AnyWeatherLayerConfiguration
}

/**
 * Modified BaseEncodedConfiguration to support both Sample and Particle layers.
 * It uses a generic L constrained to LayerDescriptor to handle both types.
 */
abstract class BaseEncodedConfiguration<L : LayerDescriptor<*>> :
    WeatherLayerConfiguration<EncodedSourceDescriptor, L> {
    private var isSyncing = false

    override var legend: Legend? = null
        set(value) {
            val oldValue = field
            field = value

            // Only start syncing if we aren't already in the middle of a sync
            if (!isSyncing && value != null && value != oldValue /*&& oldValue != null*/) {
                //println(">>> WeatherService LEGEND OVERRIDE STARTSYNCING")
                startSyncing()
            }
        }

    private fun startSyncing() {
        try {
            // 1. Link the emitter

            val sample = when (val l = layer) {
                is SampleLayerDescriptor -> l.paint.sample
                is ParticleLayerDescriptor -> l.paint.sample
                is GridLayerDescriptor -> l.paint.sample
                else -> null
            }

            sample?.eventEmitter = layer
            0
            // 2. Setup listener (ensure we only have one)
            layer.off("PAINT_CHANGE")
            layer.on("PAINT_CHANGE") {
                //println(">>> WeatherService: trigger detected, calling performSync()")
                performSync()
            }
            //println(">>> WeatherService: initial calling performSync()")
            // performSync()
        } catch (e: Exception) {
            Log.e("BaseEncodedConfig", "Sync failed: ${e.message}")
        }
    }

    private fun performSync() {
        println(">>> WeatherService: performSync() entered")
        val sample = when (val l = layer) {
            is SampleLayerDescriptor -> l.paint.sample
            is ParticleLayerDescriptor -> l.paint.sample
            is GridLayerDescriptor -> l.paint.sample
            else -> null
        }

        if (sample == null) return

        val currentScale = sample.colorScale
        if (legend is BarLegend<*>) {
            val currentLegend = legend as? BarLegend<Dimension> ?: return
            isSyncing = true
            try {
                val updatedLegend = currentLegend.copy(
                    items = currentLegend.items.map { item ->
                        item.copy(
                            colorScaleOptions = item.colorScaleOptions.copy(
                                stops = currentScale.stops,
                                positions = currentScale.positions,
                                interval = currentScale.interval,
                                range = currentScale.range ?: item.colorScaleOptions.range,
                                normalized = currentScale.normalized,
                                interpolate = currentScale.interpolate,
                                masks = currentScale.masks
                            )
                        )
                    }
                )
                this.legend = updatedLegend
            } finally {
                isSyncing = false
            }
        } else if (legend is PointLegend) {
            //println(">>> WeatherService performSync Entered, detected point legend!!!")
            val currentLegend = legend as? PointLegend ?: return
            isSyncing = true

            try {
                val currentStops = (currentScale.stops as List<ColorStop>)
                /* for (stop in currentScale.stops) {
                    println(">>> WeatherService currentScale stop: ${stop}")
                }
                for ((i, item) in currentLegend.items.withIndex()) {
                    println(">>> WeatherService legend item:: ${item.color}")
                } */
                for ((i, item) in currentLegend.items.withIndex()) {
                    if (currentStops.size > i) {
                        item.color = currentStops[i].color.toArgb()
                    }
                }
            } finally {
                isSyncing = false
            }
        }
    }
}

// --- Implementation Examples ---

/**
 * Example of a Sample implementation
 */
abstract class BaseSampleConfiguration : BaseEncodedConfiguration<SampleLayerDescriptor>()

/**
 * Example of a Particle implementation
 */
abstract class BaseParticleConfiguration : BaseEncodedConfiguration<ParticleLayerDescriptor>()


abstract class BaseVectorConfiguration<S : SourceDescriptor, L : LayerDescriptor<*>> : WeatherLayerConfiguration<S, L> {
    private var isSyncing = false
    var initial = true

    override var legend: Legend? = null
        set(value) {
            val oldValue = field
            field = value

            if (!isSyncing && value != null && value != oldValue) {
                startSyncing()
            }
        }

    private fun startSyncing() {
        try {
            // Use a helper to get the paint object regardless of descriptor type
            val paintInstance = getFillPaint()

            // Assign the emitter so changes to paint trigger performSync
            (paintInstance as? FillPaint)?.eventEmitter = layer

            val emitter = layer as? LayerEventEmitter ?: return
            emitter.off("PAINT_CHANGE")
            emitter.on("PAINT_CHANGE") {
                performSync()
            }

            performSync()
        } catch (e: Exception) {
            Log.e("BaseVectorConfig", "Sync failed: ${e.message}")
        }
    }

    /**
     * Helper to extract the color-bearing paint object from different descriptor types
     */
    private fun getFillPaint(): Any? {
        return when (val l = layer) {
            is CircleLayerDescriptor -> l.paint.fill
            is FillLayerDescriptor -> l.paint.fill
            else -> null
        }
    }

    private fun performSync() {
        if (initial) {
            initial = false
            return
        }

        val currentLegend = legend as? PointLegend ?: return

        // Extract the color StyleValue dynamically
        val paint = getFillPaint()
        val fillColorValue = (paint as? FillPaint)?.color ?: return

        isSyncing = true

        try {
            if (fillColorValue is StyleValue.Constant) {
                val colorInt = fillColorValue.value.toArgb()
                currentLegend.items.forEach { it.color = colorInt }
            } else if (fillColorValue is StyleValue.Expression) {
                val expressionList = fillColorValue.expression.toJSONObject() as? List<*> ?: emptyList<Any>()

                if (expressionList.isNotEmpty()) {
                    val operator = expressionList[0].toString()
                    val startIndex = when (operator) {
                        "match" -> 3
                        "case" -> 2
                        else -> -1
                    }

                    if (startIndex != -1) {
                        val colorMappings = mutableListOf<Pair<String, Int>>()

                        for (i in startIndex until expressionList.size step 2) {
                            val conditionRaw = expressionList[i - 1].toString()
                            val colorObj = expressionList[i]
                            val colorInt = parseColorFromExpression(colorObj) ?: continue

                            val cleanLabel = conditionRaw
                                .replace(Regex("""[\[\]"']"""), "")
                                .replace("==", "")
                                .replace("get, type", "")
                                .replace(",", "")
                                .trim()

                            colorMappings.add(cleanLabel to colorInt)
                        }

                        currentLegend.items.forEach { item ->
                            val match = colorMappings.find { (label, _) ->
                                label.contains(item.label, ignoreCase = true) ||
                                        item.label.contains(label, ignoreCase = true)
                            }
                            if (match != null) {
                                item.color = match.second
                            }
                        }

                        parseColorFromExpression(expressionList.last())?.let { fallbackColor ->
                            if (colorMappings.size < currentLegend.items.size) {
                                currentLegend.items.lastOrNull()?.color = fallbackColor
                            }
                        }
                    }
                }
            }
        } finally {
            isSyncing = false
        }
    }
}

abstract class BaseVectorConfigurationOld<S : SourceDescriptor> : WeatherLayerConfiguration<S, CircleLayerDescriptor> {
    private var isSyncing = false
    var initial = true

    override var legend: Legend? = null
        set(value) {
            val oldValue = field
            field = value

            if (!isSyncing && value != null && value != oldValue) {
                startSyncing()
            }
        }

    private fun startSyncing() {
        try {
            val paintInstance = layer.paint.fill

            // 2. Assign the emitter (Casting to access the property we added to FillPaint/CirclePaint)
            // If CirclePaint/FillPaint implements LayerEventEmitter, we cast it here
            (paintInstance as? FillPaint)?.eventEmitter = layer

            val emitter = layer as? LayerEventEmitter ?: return
            emitter.off("PAINT_CHANGE")
            emitter.on("PAINT_CHANGE") {
                //println(">>> WeatherService: trigger detected, calling performSync() for FILL VECTOR")
                performSync()
            }

            performSync()
        } catch (e: Exception) {
            Log.e("BaseVectorConfig", "Sync failed: ${e.message}")
        }
    }

    private fun performSync() {
        if (initial) {
            initial = false
            return
        }
        //println(">>> WeatherService performSync Entered for vector circle/fill")
        val currentLegend = legend as? PointLegend ?: return
        val fillColorValue = layer.paint.fill.color
        isSyncing = true

        try {
            if (fillColorValue is StyleValue.Constant) {
                val colorInt = fillColorValue.value.toArgb()
                currentLegend.items.forEach { it.color = colorInt }
            } else if (fillColorValue is StyleValue.Expression) {
                val expressionList = fillColorValue.expression.toJSONObject() as? List<*> ?: emptyList<Any>()

                if (expressionList.isNotEmpty()) {
                    val operator = expressionList[0].toString()
                    // Determine starting index based on expression type
                    // match: [match, input, label, color, ...] -> Index 3
                    // case:  [case, condition, color, condition, color, ...] -> Index 2
                    val startIndex = when (operator) {
                        "match" -> 3
                        "case" -> 2
                        else -> -1
                    }

                    if (startIndex != -1) {
                        // 1. Identify all color outputs and their corresponding labels/conditions
                        val colorMappings = mutableListOf<Pair<String, Int>>()

                        for (i in startIndex until expressionList.size step 2) {
                            val conditionRaw = expressionList[i - 1].toString()
                            val colorObj = expressionList[i]
                            val colorInt = parseColorFromExpression(colorObj) ?: continue

                            // Clean the condition string:
                            // Turns '["==", ["get", "type"], "mini"]' into 'mini'
                            val cleanLabel = conditionRaw
                                .replace(Regex("""[\[\]"']"""), "") // Remove brackets and quotes
                                .replace("==", "")                  // Remove operators
                                .replace("get, type", "")           // Remove the getter logic
                                .replace(",", "")                   // Remove stray commas
                                .trim()

                            colorMappings.add(cleanLabel to colorInt)
                        }

                        // 2. Map the cleaned labels to the legend items
                        currentLegend.items.forEach { item ->
                            // Find a mapping where the cleaned condition matches the legend label
                            val match = colorMappings.find { (label, _) ->
                                label.contains(item.label, ignoreCase = true) ||
                                        item.label.contains(label, ignoreCase = true)
                            }

                            if (match != null) {
                                println(">>> WeatherService: ${currentLegend.layerId}  ${currentLegend.id} match, color ${item.color} -> ${match.second}}")
                                item.color = match.second
                            }
                        }

                        // 3. Handle the fallback (last item in expressionList)
                        // Usually, the fallback in your 'case' is the "default" state
                        parseColorFromExpression(expressionList.last())?.let { fallbackColor ->
                            // Only apply fallback to items that weren't matched above
                            // OR apply to a specific "Other" item if it exists
                            if (colorMappings.size < currentLegend.items.size) {
                                println(">>> WeatherService: colorMappings.size ${colorMappings.size}, currentLegend.items.size ${currentLegend.items.size}}")
                                currentLegend.items.lastOrNull()?.color = fallbackColor
                            }
                        }
                    }
                }
            }
        } finally {
            isSyncing = false
        }
    }
}

private fun parseColorFromExpression(obj: Any?): Int? {
    val colorStr = obj?.toString() ?: return null

    return try {
        if (colorStr.startsWith("rgba")) {
            // Parses "rgba(111,179,20,1.0)"
            val parts = colorStr.removePrefix("rgba(").removeSuffix(")").split(",")
            val r = parts[0].trim().toInt()
            val g = parts[1].trim().toInt()
            val b = parts[2].trim().toInt()
            val a = (parts[3].trim().toFloat() * 255).toInt()
            android.graphics.Color.argb(a, r, g, b)
        } else if (colorStr.startsWith("#")) {
            android.graphics.Color.parseColor(colorStr)
        } else {
            null
        }
    } catch (e: Exception) {
        null
    }
}


@Keep
class WeatherService(
    val account: XweatherAccount
) {
    val authenticator: XweatherAuthenticator = XweatherAuthenticator(account, mapsGLServer)
    val style: MapStyle = MapStyle()
    var isStyleLoaded: Boolean = false
        private set

    companion object {
        const val XweatherMaxIntervals = 50
        val XweatherStyle = mapOf(
            "icon" to "https://cdn.aerisapi.com/sdk/js/mapsgl/assets/sprite{suffix}.json",
            "sdf" to "https://cdn.aerisapi.com/sdk/js/mapsgl/assets/sprite-sdf{suffix}.json"
        )

        val apiServer = URL("https://data.api.xweather.com")
        val mapsGLServer = URL("https://prod.v1.mapsgl.api.xweather.com")
        val ampServer = URL("https://maps.api.xweather.com")
        val layerMetadataURLPath = "https://www.xweather.com/docs/mapsgl/api/layers"

        const val rasterMetadataURLPath = "/{accessKey}/{code}.json"
        const val rasterTileURLPathTemplate = "/{accessKey}/{code}/{z}/{x}/{y}/{time}@2x.png"
        const val vectorTileURLPathTemplate = "/{accessKey}/{code}/{z}/{x}/{y}/{time::utc:format[yyyyMMddhhmm00]}.pbf"
        const val geoJSONURLPathTemplate = "/{route}"

        const val mapsGLTileMetadataURLPath = "/tile?details=true&{datasets}&begin={startDate}&end={endDate}"
        const val mapsGLTileURLPathTemplate = "/tile/{z}/{x}/{y}/{width}x{height}/{time}.png"
        const val mapsGLVectorMetadataURLPath =
            "/vector/?details=true&products={code}&begin={startDate::iso}&end={endDate::iso}"
        const val mapsGLVectorTileURLPathTemplate = "/vector/{code}/{time::iso}/{z}/{x}/{y}.pbf"

        val mapsGLTileMetadataURLQueryItems = mapOf(
            "details" to "true"
        )

        @Keep
        fun Admin2Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.Admin2Boundaries(service)

        @Keep
        fun Admin34Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.Admin34Boundaries(service)

        @Keep
        fun Admin56Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.Admin56Boundaries(service)

        @Keep
        fun AirQuality(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.AirQuality(service)

        @Keep
        fun CarbonMonoxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.CarbonMonoxide(service)

        @Keep
        fun AirQualityHealthIndexCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityHealthIndexCategories(service)

        @Keep
        fun AirQualityIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndex(service)

        @Keep
        fun AirQualityIndexCaiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexCaiCategories(service)

        @Keep
        fun AirQualityIndexCaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexCaqiCategories(service)

        @Keep
        fun AirQualityIndexCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexCategories(service)

        @Keep
        fun AirQualityIndexChinaCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexChinaCategories(service)

        @Keep
        fun AirQualityIndexEaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexEaqiCategories(service)

        @Keep
        fun AirQualityIndexIndiaCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexIndiaCategories(service)

        @Keep
        fun AirQualityIndexUbaDaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexUbaDaqiCategories(service)

        @Keep
        fun AirQualityIndexUkDaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexUkDaqiCategories(service)

        @Keep
        fun NitricOxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.NitricOxide(service)

        @Keep
        fun NitrogenDioxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.NitrogenDioxide(service)

        @Keep
        fun Ozone(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Ozone(service)

        @Keep
        fun ParticulateMatter10Micron(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.ParticulateMatter10Micron(service)

        @Keep
        fun ParticulateMatter2p5Micron(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.ParticulateMatter2p5Micron(service)

        @Keep
        fun SulfurDioxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SulfurDioxide(service)

        @Keep
        fun Alerts(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.Alerts(service)

        @Keep
        fun AlertsOutline(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.AlertsOutline(service)

        @Keep
        fun Boundaries(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.Boundaries(service)

        @Keep
        fun CloudCover(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.CloudCover(service)

        @Keep
        fun Convective(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.Convective(service)

        @Keep
        fun ConvectiveOutline(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.ConvectiveOutline(service)

        @Keep
        fun DewPoints(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.DewPoints(service)

        @Keep
        fun DroughtMonitor(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.DroughtMonitor(service)

        @Keep
        fun DroughtMonitorOutline(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.DroughtMonitorOutline(service)

        @Keep
        fun Earthquakes(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.Earthquakes(service)

        @Keep
        fun EarthquakesHeat(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.EarthquakesHeat(service)

        @Keep
        fun FeelsLike(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.FeelsLike(service)

        @Keep
        fun Fires(service: WeatherService): CompositeWeatherLayerConfiguration = WeatherConfigurations.Fires(service)

        @Keep
        fun FiresIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.FiresIcons(service)

        @Keep
        fun FiresObs(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.FiresObs(service)

        @Keep
        fun FiresObsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.FiresObsHeat(service)

        @Keep
        fun FiresObsIcons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.FiresObsIcons(service)

        @Keep
        fun FiresObsNames(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.FiresObsNames(service)

        @Keep
        fun FiresOutlook(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.FiresOutlook(service)

        @Keep
        fun FiresPerimeter(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.FiresPerimeter(service)

        @Keep
        fun HailSevereProbability(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.HailSevereProbability(service)

        @Keep
        fun HailSevereProbabilityAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSevereProbabilityAustralia(service)

        @Keep
        fun HailSevereProbabilityEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSevereProbabilityEurope(service)

        @Keep
        fun HailSevereProbabilityJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSevereProbabilityJapan(service)

        @Keep
        fun HailSevereProbabilityUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSevereProbabilityUnitedStates(service)

        @Keep
        fun HailSize(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.HailSize(service)

        @Keep
        fun HailSizeAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSizeAustralia(service)

        @Keep
        fun HailSizeEurope(service: WeatherService): SampleConfiguration = WeatherConfigurations.HailSizeEurope(service)

        @Keep
        fun HailSizeJapan(service: WeatherService): SampleConfiguration = WeatherConfigurations.HailSizeJapan(service)

        @Keep
        fun HailSizeUnitedStates(service: WeatherService): SampleConfiguration =
            WeatherConfigurations.HailSizeUnitedStates(service)

        @Keep
        fun HailThreats(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.HailThreats(service)

        @Keep
        fun HailThreatsPoints(service: WeatherService): VCircleConfiguration =
            WeatherConfigurations.HailThreatsPoints(service)

        @Keep
        fun HailThreatsPolygons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.HailThreatsPolygons(service)

        @Keep
        fun HailThreatsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.HailThreatsTracks(service)

        @Keep
        fun HeatIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HeatIndex(service)

        @Keep
        fun Humidity(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Humidity(service)

        @Keep
        fun LightningAll(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningAll(service)

        @Keep
        fun LightningAllIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningAllIcons(service)

        @Keep
        fun LightningDensity(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningDensity(service)

        @Keep
        fun LightningDensityAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityAustralia(service)

        @Keep
        fun LightningDensityCloudToGround(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningDensityCloudToGround(service)

        @Keep
        fun LightningDensityCloudToGroundAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityCloudToGroundAustralia(service)

        @Keep
        fun LightningDensityCloudToGroundEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityCloudToGroundEurope(service)

        @Keep
        fun LightningDensityCloudToGroundJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityCloudToGroundJapan(service)

        @Keep
        fun LightningDensityCloudToGroundUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityCloudToGroundUnitedStates(service)

        @Keep
        fun LightningDensityEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityEurope(service)

        @Keep
        fun LightningDensityIntracloud(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningDensityIntracloud(service)

        @Keep
        fun LightningDensityIntracloudAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityIntracloudAustralia(service)

        @Keep
        fun LightningDensityIntracloudEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityIntracloudEurope(service)

        @Keep
        fun LightningDensityIntracloudJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityIntracloudJapan(service)

        @Keep
        fun LightningDensityIntracloudUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityIntracloudUnitedStates(service)

        @Keep
        fun LightningDensityJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityJapan(service)

        @Keep
        fun LightningDensityUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityUnitedStates(service)

        @Keep
        fun LightningFlash(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.LightningFlash(service)

        @Keep
        fun LightningStrikes(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.LightningStrikes(service)

        @Keep
        fun LightningStrikesHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.LightningStrikesHeat(service)

        @Keep
        fun LightningStrikesIcons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.LightningStrikesIcons(service)

        @Keep
        fun LightningThreats(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningThreats(service)

        @Keep
        fun LightningThreatsPoints(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.LightningThreatsPoints(service)

        @Keep
        fun LightningThreatsPolygons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.LightningThreatsPolygons(service)

        @Keep
        fun LightningThreatsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.LightningThreatsTracks(service)

        @Keep
        fun OceanCurrents(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.OceanCurrents(service)

        @Keep
        fun OceanCurrentsParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.OceanCurrentsParticles(service)

        @Keep
        fun PlaceCity(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.PlaceCity(service)

        @Keep
        fun PlaceCountry(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.PlaceCountry(service)

        @Keep
        fun PlaceNeighborhood(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.PlaceNeighborhood(service)

        @Keep
        fun PlaceState(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.PlaceState(service)

        @Keep
        fun Places(service: WeatherService): CompositeWeatherLayerConfiguration = WeatherConfigurations.Places(service)

        @Keep
        fun Precipitation(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Precipitation(service)

        /*
        @Keep
        fun PrecipitationRate(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.PrecipitationRate(service)
        */
        @Keep
        fun PressureMeanSeaLevel(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.PressureMeanSeaLevel(service)

        @Keep
        fun PressureMeanSeaLevelContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> =
            WeatherConfigurations.PressureMeanSeaLevelContour(service)

        @Keep
        fun Radar(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Radar(service)

        @Keep
        fun RiverObservations(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.RiverObservations(service)

        @Keep
        fun RoadAll(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadAll(service)

        @Keep
        fun RoadMotorway(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadMotorway(service)

        @Keep
        fun RoadPrimary(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadPrimary(service)

        @Keep
        fun RoadSecondaryTertiary(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadSecondaryTertiary(service)

        @Keep
        fun RoadStreet(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadStreet(service)

        @Keep
        fun RoadTrunk(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadTrunk(service)

        @Keep
        fun Roads(service: WeatherService): CompositeWeatherLayerConfiguration = WeatherConfigurations.Roads(service)

        @Keep
        fun Satellite(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.Satellite(service)

        @Keep
        fun SatelliteGeocolor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.SatelliteGeocolor(service)

        @Keep
        fun SatelliteInfraredColor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.SatelliteInfraredColor(service)

        @Keep
        fun SatelliteVisible(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.SatelliteVisible(service)

        @Keep
        fun SatelliteWaterVapor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.SatelliteWaterVapor(service)

        @Keep
        fun Snow(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Snow(service)

        @Keep
        fun SnowDepth(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SnowDepth(service)

        @Keep
        fun SeaSurfaceTemperatures(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SeaSurfaceTemperatures(service)

        @Keep
        fun StormSurge(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.StormSurge(service)

        @Keep
        fun Stormcells(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.Stormcells(service)

        @Keep
        fun StormcellsCones(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.StormcellsCones(service)

        @Keep
        fun StormcellsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.StormcellsHeat(service)

        @Keep
        fun StormcellsPositions(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.StormcellsPositions(service)

        @Keep
        fun StormcellsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.StormcellsTracks(service)

        @Keep
        fun Stormreports(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.Stormreports(service)

        @Keep
        fun StormreportsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.StormreportsHeat(service)

        @Keep
        fun SwellHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SwellHeights(service)

        @Keep
        fun SwellParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.SwellParticles(service)

        @Keep
        fun SwellPeriods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SwellPeriods(service)

        @Keep
        fun Swell2Heights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Swell2Heights(service)

        @Keep
        fun Swell2Particles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.Swell2Particles(service)

        @Keep
        fun Swell2Periods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Swell2Periods(service)

        @Keep
        fun Swell3Heights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Swell3Heights(service)

        @Keep
        fun Swell3Particles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.Swell3Particles(service)

        @Keep
        fun Swell3Periods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Swell3Periods(service)

        @Keep
        fun Temperatures(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Temperatures(service)

        @Keep
        fun Temperatures1HourChange(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, /*SampleLayerPaint,*/ SampleLayerDescriptor> =
            WeatherConfigurations.Temperatures1HourChange(service)

        @Keep
        fun Temperatures24HourChange(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Temperatures24HourChange(service)

        @Keep
        fun TideHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.TideHeights(service)

        @Keep
        fun TropicalCyclones(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclones(service)

        @Keep
        fun TropicalCyclonesArchive(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesArchive(service)

        @Keep
        fun TropicalCyclonesArchiveIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesArchiveIcons(service)

        @Keep
        fun TropicalCyclonesBreakPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesBreakPoints(service)

        @Keep
        fun TropicalCyclonesForecastErrorCones(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastErrorCones(service)

        @Keep
        fun TropicalCyclonesForecastLines(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastLines(service)

        @Keep
        fun TropicalCyclonesForecastLinesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastLinesInvests(service)

        @Keep
        fun TropicalCyclonesForecastPointIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastPointIcons(service)

        @Keep
        fun TropicalCyclonesForecastPointIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastPointIconsInvests(service)

        @Keep
        fun TropicalCyclonesForecastPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastPoints(service)

        @Keep
        fun TropicalCyclonesForecastPointsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastPointsInvests(service)

        @Keep
        fun TropicalCyclonesIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesIcons(service)

        @Keep
        fun TropicalCyclonesInvests(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesInvests(service)

        @Keep
        fun TropicalCyclonesInvestsIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesInvestsIcons(service)

        @Keep
        fun TropicalCyclonesNames(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesNames(service)

        @Keep
        fun TropicalCyclonesNamesArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesNamesArchive(service)

        @Keep
        fun TropicalCyclonesNamesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesNamesInvests(service)

        @Keep
        fun TropicalCyclonesPositionIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesPositionIcons(service)

        @Keep
        fun TropicalCyclonesPositionIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesPositionIconsInvests(service)

        @Keep
        fun TropicalCyclonesPositions(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesPositions(service)

        @Keep
        fun TropicalCyclonesPositionsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesPositionsInvests(service)

        @Keep
        fun TropicalCyclonesTrackLines(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackLines(service)

        @Keep
        fun TropicalCyclonesTrackLinesArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackLinesArchive(service)

        @Keep
        fun TropicalCyclonesTrackLinesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackLinesInvests(service)

        @Keep
        fun TropicalCyclonesTrackPointIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointIcons(service)

        @Keep
        fun TropicalCyclonesTrackPointIconsArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointIconsArchive(service)

        @Keep
        fun TropicalCyclonesTrackPointIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointIconsInvests(service)

        @Keep
        fun TropicalCyclonesTrackPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPoints(service)

        @Keep
        fun TropicalCyclonesTrackPointsArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointsArchive(service)

        @Keep
        fun TropicalCyclonesTrackPointsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointsInvests(service)

        @Keep
        fun UltravioletIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.UltravioletIndex(service)

        @Keep
        fun Visibility(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Visibility(service)

        @Keep
        fun Water(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.Water(service)

        @Keep
        fun Land(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.Land(service)

        @Keep
        fun WaterwayLakeRiverBoundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.WaterwayLakeRiverBoundaries(service)

        @Keep
        fun WaterwayOceanBoundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.WaterwayOceanBoundaries(service)

        @Keep
        fun WaveHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WaveHeights(service)

        @Keep
        fun WaveParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.WaveParticles(service)

        @Keep
        fun WavePeriods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WavePeriods(service)

        @Keep
        fun WindChill(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WindChill(service)

        @Keep
        fun WindGusts(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WindGusts(service)

        @Keep
        fun WindParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.WindParticles(service)

        @Keep
        fun WindSpeeds(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WindSpeeds(service)

        @Keep
        fun WindBarbs(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.WindBarbs(service)

        @Keep
        fun WindDirectionArrows(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.WindDirectionArrows(service)

        @Keep
        fun WaveDirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.WaveDirectionGrid(service)

        @Keep
        fun SwellDirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.SwellDirectionGrid(service)

        @Keep
        fun Swell2DirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.Swell2DirectionGrid(service)

        @Keep
        fun Swell3DirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.Swell3DirectionGrid(service)


        //====================================================================================================================================


        //  @Keep
        //  fun PrecipitationRate(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
        //      WeatherConfigurations.PrecipitationRate(service)

        @Keep
        fun TemperaturesContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> =
            WeatherConfigurations.TemperaturesContour(service)

        @Keep
        fun WindSpeedsContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> =
            WeatherConfigurations.WindSpeedsContour(service)


    }

    suspend fun loadStyles(map: ImageRegisteringMap, dpr: Float = 1.0f) {
        var noLoadFailures = true
        coroutineScope {
            XweatherStyle.map { (key, urlPath) ->
                async {
                    // fix for issue 9, crash when app starts offline
                    try {
                        style.loadSprite("mapsgl", urlPath, map, dpr)
                    } catch (e: Exception) {
                        noLoadFailures = false
                        Log.e("WeatherService", "Failed to load sprite '$key' from $urlPath: ${e.message}", e)
                    }
                }
            }.forEach { it.await() }
        }

        // The CDN sprite sheets do not include a generic arrow icon, but gridded wind-direction
        // layers reference `mapsgl:arrow`. Register a small tintable SDF-style bitmap so Mapbox
        // can render + color it via `icon-color`.
        runCatching {
            val arrow = createSdfArrowBitmap(sizePx = 96)
            map.addImage("mapsgl:arrow", arrow, true)
        }.onFailure { e ->
            noLoadFailures = false
            Log.e("WeatherService", "Failed to register generated sprite 'mapsgl:arrow': ${e.message}", e)
        }

        isStyleLoaded = noLoadFailures
    }

    private fun createSdfArrowBitmap(sizePx: Int): Bitmap {
        val s = sizePx.coerceAtLeast(16)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(android.graphics.Color.TRANSPARENT)

        // Draw a right-pointing arrow in alpha; we then encode alpha into the red channel for SDF-style use.
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = android.graphics.Color.WHITE
        }
        val p = Path()
        val cx = s * 0.5f
        val cy = s * 0.5f
        val shaftHalfH = s * 0.10f
        val shaftL = s * 0.34f
        val headL = s * 0.22f
        val headHalfH = s * 0.22f

        val x0 = cx - shaftL
        val x1 = cx + shaftL
        val x2 = x1 + headL
        // Swallow/barbed head (deep center V), not a convex triangle on x1 — matches instanced GL wind arrow.
        val dNotch = s * 0.13f
        val dBarb = s * 0.038f
        var xNotch = x1 - dNotch
        val xBarb = x1 - dBarb
        val margin = s * 0.04f
        if (xNotch < x0 + margin) xNotch = x0 + margin
        p.moveTo(x2, cy)
        p.lineTo(xBarb, cy - headHalfH)
        p.lineTo(xNotch, cy)
        p.lineTo(xBarb, cy + headHalfH)
        p.lineTo(x1, cy + shaftHalfH)
        p.lineTo(x0, cy + shaftHalfH)
        p.lineTo(x0, cy - shaftHalfH)
        p.lineTo(x1, cy - shaftHalfH)
        p.close()

        c.drawPath(p, fill)

        // Encode ARGB alpha into the red channel and also keep it as alpha.
        val pixels = IntArray(s * s)
        bmp.getPixels(pixels, 0, s, 0, 0, s, s)
        for (i in pixels.indices) {
            val a = android.graphics.Color.alpha(pixels[i])
            pixels[i] = android.graphics.Color.argb(a, a, a, a)
        }
        bmp.setPixels(pixels, 0, s, 0, 0, s, s)
        return bmp
    }

    suspend fun loadLayerMetadata(): Result<List<WeatherLayerMetadata>> {
        try {
            val request = URLRequest(layerMetadataURLPath)
            val response = request.execute()
            when (response.data) {
                is JSONObject -> {
                    val json = response.data.getJSONArray("layers")
                    val layers = mutableListOf<WeatherLayerMetadata>()
                    for (i in 0 until json.length()) {
                        val obj = json.getJSONObject(i)
                        val metadata = WeatherLayerMetadata(
                            id = obj.getString("id"),
                            title = obj.getString("title"),
                            description = obj.getString("description"),
                            type = obj.getString("type"),
                            imageUrl = URL(obj.getString("imageUrl")),
                            animatable = obj.getBoolean("animatable"),
                            categories = obj.getJSONArray("categories").let { arr ->
                                List(arr.length()) { arr.getString(it) }
                            },
                            dataRange = obj.getString("dataRange"),
                            dataCoverage = obj.getJSONArray("dataCoverage").let { arr ->
                                List(arr.length()) { arr.getString(it) }
                            },
                            updateInterval = obj.getString("updateInterval")
                        )
                        layers.add(metadata)
                    }
                    return Result.success(layers)
                }

                else -> {
                    return Result.failure(Exception("Layer metadata is not a valid JSON array"))
                }
            }
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    fun makeRasterSourceDescriptor(code: String): ImageSourceDescriptor =
        makeRasterSourceDescriptor("wx::raster.$code", code)

    fun makeRasterSourceDescriptor(id: String, code: String): ImageSourceDescriptor {
        val pathVars = mapOf(
            "accessKey" to "${account.id}_${account.secret}", "code" to code
        )

        val descriptor = ImageSourceDescriptor(id)
        descriptor.url = "$ampServer" + rasterTileURLPathTemplate.replaceVars(pathVars, true)
        descriptor.metadataUrl = "$ampServer" + rasterMetadataURLPath.replaceVars(pathVars, true)
        descriptor.tileSize = TileSize(512)
        //        descriptor.transformer = XweatherRasterSourceTransformer()
        //        descriptor.useTimeSeries = true

        return descriptor
    }

    fun makeEncodedSourceDescriptor(group: EncodedDataGroup): EncodedSourceDescriptor =
        makeEncodedSourceDescriptor(group.id, group.datasets)

    // This function generates invalid metadata urls that look like this:
    // https://prod.v1.mapsgl.api.xweather.com//tile?api-key=id_secret&details=true
    fun makeEncodedSourceDescriptor(
        id: String, datasets: List<EncodedDataset>
    ): EncodedSourceDescriptor {
        var queryParams = mapOf("api-key" to "${account.id}_${account.secret}")
        queryParams = queryParams + mapsGLTileMetadataURLQueryItems

        val queryString = queryParams.entries.joinToString("&") { (k, v) ->
            "${k}=${v}"
        }

        val descriptor = EncodedSourceDescriptor(id)
        descriptor.url = "$mapsGLServer$mapsGLTileURLPathTemplate"
        descriptor.metadataUrl = "$mapsGLServer$mapsGLTileMetadataURLPath"
        descriptor.tileSize = TileSize(512)
        descriptor.authenticator = authenticator

        descriptor.datasets = datasets.mapIndexed { index, dataset ->
            dataset.apply { band = ColorBand.fromRawValue(index) }
        }

        return descriptor
    }

    fun makeVectorSourceDescriptor(code: String): VectorSourceDescriptor = makeVectorSourceDescriptor("wx::$code", code)

    fun makeVectorSourceDescriptor(id: String, code: String): VectorSourceDescriptor {
        val pathVars = mapOf(
            "accessKey" to "${account.id}_${account.secret}", "code" to code
        )

        val descriptor = VectorSourceDescriptor(id)
        descriptor.url = "$mapsGLServer" + mapsGLVectorTileURLPathTemplate.replaceVars(pathVars)
        descriptor.metadataUrl = "$mapsGLServer" + mapsGLVectorMetadataURLPath.replaceVars(pathVars)
        descriptor.tileSize = TileSize(512)
        descriptor.authenticator = authenticator
        //        descriptor.transformer = XweatherRasterSourceTransformer()
        //        descriptor.useTimeSeries = true

        return descriptor
    }

    fun makeAmpVectorSourceDescriptor(code: String): VectorSourceDescriptor =
        makeAmpVectorSourceDescriptor("wx::$code", code)

    fun makeAmpVectorSourceDescriptor(id: String, code: String): VectorSourceDescriptor {
        val pathVars = mapOf(
            "accessKey" to "${account.id}_${account.secret}", "code" to code
        )

        val descriptor = VectorSourceDescriptor(id)
        descriptor.url = "$ampServer" + vectorTileURLPathTemplate.replaceVars(pathVars)
        descriptor.metadataUrl = "$ampServer" + rasterMetadataURLPath.replaceVars(pathVars)
        descriptor.tileSize = TileSize(512)
        //        descriptor.transformer = XweatherRasterSourceTransformer()
        //        descriptor.useTimeSeries = true

        return descriptor
    }

    fun makeGeoJSONSourceDescriptor(
        id: String, route: String, params: Map<String, Any> = emptyMap()
    ): GeoJSONSourceDescriptor {
        val pathVars = mapOf("route" to route)
        val queryParams = params.toMutableMap().apply {
            this["format"] = "geojson"
            this["from"] = "{startDate::iso}"
            this["to"] = "{endDate::iso}"
            this["client_id"] = account.id
            this["client_secret"] = account.secret
        }

        val queryString = queryParams.entries.joinToString("&") { (k, v) ->
            "${k}=${v}"
        }

        val descriptor = GeoJSONSourceDescriptor(id)
        descriptor.url = "$apiServer" + geoJSONURLPathTemplate.replaceVars(pathVars).removePrefix("/") + "?$queryString"

        return descriptor
    }
}
