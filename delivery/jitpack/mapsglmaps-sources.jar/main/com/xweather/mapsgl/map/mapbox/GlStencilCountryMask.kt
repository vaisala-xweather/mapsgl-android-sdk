package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import java.util.Locale

/**
 * Country outline stencil: filters MVT features from Mapbox Streets `admin` (admin_level 0) or
 * MapsGL OSM `boundary` (admin_level 2, non-maritime), matched by ISO 3166-1 alpha-2.
 */
internal object GlStencilCountryMask {

    private val ISO_PROPERTY_KEYS =
        listOf(
            "iso_3166_1",
            "ISO_3166_1",
            "iso_a2",
            "ISO_A2",
            "ISO3166-1:alpha2",
            "iso_3166_1_alpha3",
            "iso_3166_1_alpha_3",
            "iso_a3",
            "ISO_A3",
            "adm0_a3",
            "country_code",
            "country_iso",
        )

    fun normalizeIso(raw: String?): String? {
        val t = raw?.trim()?.uppercase(Locale.US) ?: return null
        if (t.length != 2) return null
        if (!t[0].isLetter() || !t[1].isLetter()) return null
        return t
    }

    fun matchesIso(feature: Feature, wantIso: String): Boolean {
        val u = wantIso.uppercase(Locale.US)
        val u3 = runCatching { Locale("", u).isO3Country.uppercase(Locale.US) }.getOrNull()
        val raw = isoRaw(feature) ?: return false
        if (raw.equals(u, ignoreCase = true)) return true
        if (u3 != null && raw.equals(u3, ignoreCase = true)) return true
        if ('-' in raw) {
            for (part in raw.split('-')) {
                val p = part.trim()
                if (p.equals(u, ignoreCase = true)) return true
                if (u3 != null && p.equals(u3, ignoreCase = true)) return true
            }
        }
        return false
    }

    private fun isoRaw(f: Feature): String? {
        for (k in ISO_PROPERTY_KEYS) {
            f.getStringProperty(k)?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        }
        return null
    }

    private fun adminLevel(f: Feature): Int? {
        f.getNumberProperty("admin_level")?.let { return it.toInt() }
        f.getStringProperty("admin_level")?.toIntOrNull()?.let { return it }
        return null
    }

    private fun isNonMaritimeBoundary(f: Feature): Boolean {
        val m = f.getNumberProperty("maritime") ?: return true
        return m.toInt() != 1
    }

    /**
     * Country-level boundary features for stencil ribbons (lines; polygons triangulated elsewhere).
     */
    fun isCountryBoundaryFeature(f: Feature): Boolean =
        when (featureLayerTag(f)) {
            "admin" -> adminLevel(f) == 0
            "boundary" -> adminLevel(f) == 2 && isNonMaritimeBoundary(f)
            else -> false
        }
}
