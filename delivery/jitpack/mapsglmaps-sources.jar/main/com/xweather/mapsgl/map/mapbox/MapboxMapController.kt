package com.xweather.mapsgl.map.mapbox

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.graphics.Bitmap
import android.os.Looper
import android.os.SystemClock
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.google.gson.JsonElement
import com.mapbox.bindgen.Value
import com.mapbox.common.Cancelable
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.mapbox.maps.CameraChangedCallback
import com.mapbox.maps.CameraOptions
import com.mapbox.maps.CoordinateBounds
import com.mapbox.maps.LayerPosition
import com.mapbox.maps.MapIdleCallback
import com.mapbox.maps.MapView
import com.mapbox.maps.MapboxMap
import com.mapbox.maps.QueriedRenderedFeature
import com.mapbox.maps.RenderFrameFinishedCallback
import com.mapbox.maps.RenderedQueryGeometry
import com.mapbox.maps.RenderedQueryOptions
import com.mapbox.maps.ScreenBox
import com.mapbox.maps.ScreenCoordinate
import com.mapbox.maps.Size
import com.mapbox.maps.extension.style.layers.getLayer
import com.mapbox.maps.extension.style.layers.properties.generated.Visibility
import com.mapbox.maps.extension.style.sources.addSource
import com.mapbox.maps.extension.style.sources.generated.GeoJsonSource
import com.mapbox.maps.extension.style.sources.generated.geoJsonSource
import com.mapbox.maps.extension.style.sources.getSource
import com.mapbox.maps.plugin.gestures.gestures
import com.mapbox.maps.toCameraOptions
import com.xweather.mapsgl.anim.AnimationEvent
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.events.MapControllerEvents
import com.xweather.mapsgl.geo.Geo
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.FeatureQueryResult
import com.xweather.mapsgl.layers.QueriedFeature
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.tile.EncodedTileLayer
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.ImageRegisteringMap
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.MaskUtils
import com.xweather.mapsgl.map.MaskUtils.Companion._masks
import com.xweather.mapsgl.map.MaskUtils.Companion.getBackgroundColorRBGStringFromLayer
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.camera
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.mapZoom
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.rotScalePitchMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.scaleMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.translationMatrix
import com.xweather.mapsgl.map.mapbox.CameraSync.Companion.worldMatrix
import com.xweather.mapsgl.sources.DataSource
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.VisibleGeoBounds
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.VectorLayerPaint
import com.xweather.mapsgl.tiles.GLCoordinate2D
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.types.Coordinate
import com.xweather.mapsgl.utils.parseDateArrayFromString
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Date
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.pow

/**
 * [MapController] implementation backed by Mapbox Maps SDK: wires style sources/layers, custom GL
 * weather layers ([MapboxLayerHost]), camera sync ([CameraSync]), and Mapbox gestures (e.g. map clicks).
 *
 * Construct with the same [MapView] you show in your activity and an [XweatherAccount] for API access.
 *
 * @see MapController for weather layers, timeline, data inspector, and legends.
 */
class MapboxMapController : MapController, DefaultLifecycleObserver {
    /** Mapbox map handle; non-null after construction. Safe to use from the main thread once the view is attached. */
    var mapboxMap: MapboxMap? = null

    /**
     * Last [coordinateBoundsForCameraUnwrapped] snapshot from the owning (main) thread.
     * Mapbox forbids reading [MapboxMap.cameraState] / coordinate bounds from other threads
     * (e.g. render thread during custom layer draw, or IO during tile download).
     */
    @Volatile
    private var cachedMapboxBounds: CoordinateBounds? = null

    private val mapboxCancelables = mutableListOf<Cancelable>()
    internal var i = 0
    internal var i2 = 0

    /**
     * Last zoom density bin used for [EncodedGridVectorTileSource] ([EncodedGridVectorTileSource.densityKeyForMapZoom], 64 bins/level).
     * When the bin changes, sidecar symbol grids are invalidated so Mapbox refetches with the new spacing.
     */
    private var lastEncodedGridDensityKey: Int? = null

    /**
     * Last quantized visible bounds (see [EncodedGridVectorTileSource.viewportKeyForVisibleBounds]).
     * When pan / pitch / bearing changes the viewport, sidecars refetch so icons stay clipped and dense for the screen.
     */
    private var lastEncodedGridViewportKey: String? = null

    /** Floor zoom (integer zoom level). Used to ensure invalidation when Mapbox swaps tile z. */
    private var lastEncodedGridZoomFloor: Int? = null

    /** Log throttle so we only print once per integer zoom floor change. */
    private var lastLoggedEncodedGridZoomFloor: Int? = null

    /** Debug: last [mapZoom] printed to Logcat (encoded tile alignment vs zoom). */
    private var lastDebugLoggedMapZoom: Double? = null

    /** Poll camera during gestures (debounce alone never fires while the map is moving). */
    private var lastEncodedGridCameraFramePollMs: Long = 0L

    /** Throttle timeline meld-driven invalidation when camera is stationary. */
    private var lastEncodedGridTimelineInvalidateMs: Long = 0L

    /** Last quantized meld key invalidated for encoded-grid symbols. */
    private var lastEncodedGridTimelineMeldKey: Int? = null

    /**
     * @deprecated v1.1.0 — use [MapboxMapController] `(mapView, account)` only.
     *
     * @param mapView Host [MapView].
     * @param baseContext Unused; retained for binary compatibility.
     * @param account Xweather credentials.
     * @param lifecycleOwner Unused; retained for binary compatibility.
     */
    @Deprecated(
        message = "Please use MapboxMapController(mapView: MapView, account: XweatherAccount) instead.",
        level = DeprecationLevel.WARNING
    )
    constructor(
        mapView: MapView,
        baseContext: Context,
        account: XweatherAccount,
        lifecycleOwner: LifecycleOwner,
    ) : this(mapView, account)

    /**
     * @param mapView Host [MapView] (must be the Mapbox map you display).
     * @param account Xweather credentials for [MapController.service] and tile URLs.
     */
    constructor(
        mapView: MapView,
        account: XweatherAccount,
    ) : super(mapView, account) {

        mapView.context.registerComponentCallbacks(this)
        mapboxMap = mapView.mapboxMap
        centerLatLng = Coordinate(mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude())
        cachedMapboxBounds = mapboxMap!!.coordinateBoundsForCameraUnwrapped(
            mapboxMap!!.cameraState.toCameraOptions()
        )

        setupCamera(true)
        camera.refreshRateFactor = 60f / refreshRate
        /** dpi of 2 results in dpiMult of 1. dpi of 4 results in dpiMult of 2 **/
        camera.dpiMult = mapView.context.resources.displayMetrics.density / 2f
        handleCallbackSubscriptions()
        setupEvents()

        mapView.gestures.addOnMapClickListener(this)

        timeline.on(AnimationEvent.stop) {
            //println("DETECTED EVENT STOP FROM MapBoxMap")
            invalidateVector()
        }

        timeline.on(AnimationEvent.PAUSE) {
            //println("DETECTED EVENT STOP FROM MapboxMap")
            invalidateVector()
        }

        timeline.on(AnimationEvent.advance) {
            if (!anyEncodedGridVectorUsesMapboxTimelineMeld()) {
                return@on
            }
            val now = SystemClock.elapsedRealtime()
            val minIntervalMs = (1000.0 / refreshRate).toLong().coerceIn(4L, 50L)
            val m = Timeline.dataMeld
            val inMeldCrossfade = m > 1e-3f && m < 1f - 1e-3f
            if (inMeldCrossfade) {
                if (now - lastEncodedGridTimelineInvalidateMs >= minIntervalMs) {
                    lastEncodedGridTimelineInvalidateMs = now
                    CoroutineScope(Dispatchers.Main).launch {
                        invalidateEncodedGridVectorSourcesForTimelineMeld()
                    }
                }
            } else {
                val meldKey = (m * 2048f).toInt().coerceIn(0, 2048)
                val meldChanged = lastEncodedGridTimelineMeldKey == null || meldKey != lastEncodedGridTimelineMeldKey
                if (meldChanged && now - lastEncodedGridTimelineInvalidateMs >= minIntervalMs) {
                    lastEncodedGridTimelineInvalidateMs = now
                    lastEncodedGridTimelineMeldKey = meldKey
                    CoroutineScope(Dispatchers.Main).launch {
                        invalidateEncodedGridVectorSourcesForTimelineMeld()
                    }
                }
            }
        }


    }

    private fun invalidateVector() {
        for (layer in layers) {
            if (layer.value is VectorTileLayer) {
                if (layer.value.source !is GeoJSONSource) {
                    (layer.value.source as VectorTileSource).invalidate()
                } else {
                    // println("Detected event is  GeoJSONSource")
                }
            }
        }
    }

    /**
     * Invalidate encoded-grid symbol sources when zoom density or visible viewport changes so Mapbox refetches
     * tiles with updated spacing and [VisibleGeoBounds] clipping.
     */
    private fun invalidateEncodedGridVectorSourcesOnCameraChange() {
        val map = mapboxMap ?: return
        val zoom = map.cameraState.zoom
        val zoomFloor = kotlin.math.floor(zoom).toInt()
        if (lastLoggedEncodedGridZoomFloor == null || zoomFloor != lastLoggedEncodedGridZoomFloor) {
            lastLoggedEncodedGridZoomFloor = zoomFloor
            //println(">>> EncodedGridVector zoom update zoom=$zoom floor=$zoomFloor")
        }
        val densityKey = EncodedGridVectorTileSource.densityKeyForMapZoom(zoom)
        val visibleBounds =
            runCatching {
                val b = map.coordinateBoundsForCameraUnwrapped(map.cameraState.toCameraOptions())
                VisibleGeoBounds.fromMapboxUnwrappedCamera(
                    b,
                    map.cameraState.center.longitude(),
                    zoom,
                )
            }.getOrNull()
        val viewportKey =
            visibleBounds?.let { EncodedGridVectorTileSource.viewportKeyForVisibleBounds(it) } ?: "none"

        val densityChanged = lastEncodedGridDensityKey != null && densityKey != lastEncodedGridDensityKey
        val viewportChanged = lastEncodedGridViewportKey != null && viewportKey != lastEncodedGridViewportKey
        val zoomFloorChanged = lastEncodedGridZoomFloor != null && zoomFloor != lastEncodedGridZoomFloor

        if (densityChanged || viewportChanged || zoomFloorChanged) {
            forEachEncodedGridVectorTileSource { it.invalidate() }
        }
        lastEncodedGridDensityKey = densityKey
        lastEncodedGridViewportKey = viewportKey
        lastEncodedGridZoomFloor = zoomFloor
    }

    /**
     * Timeline meld updates can change vector icon direction/color with no camera movement.
     * Force encoded-grid source invalidation in that case so Mapbox refetches tile features.
     */
    private fun invalidateEncodedGridVectorSourcesForTimelineMeld() {
        forEachEncodedGridVectorTileSource { it.invalidateDynamicIconData() }
    }

    companion object {
        /** Logcat tag for this controller. */
        val TAG = "MapboxMapController"

        /** Camera projection mode matching MapsGL perspective setup. */
        const val PERSPECTIVECAMERA = 0

        /** Camera projection mode matching MapsGL orthographic setup. */
        const val ORTHOCAMERA = 1
    }

    /** Mapbox drawable size in pixels (width/height). */
    internal val size: Size
        get() = mapboxMap!!.getSize()

    private val cameraChangedCallBack = CameraChangedCallback { event ->

        cameraTriggered = true
        if (timeline.state == AnimationState.playing) {
            Timeline.pausedForMovement = true
        }
        // Do not call timeline.pause() here. Mapbox can emit CAMERA_CHANGED every frame at high pitch
        // (and other continuous camera updates), which cancels the debounced job below before its 150ms
        // delay completes — so timeline.resume() never runs, playback stays paused, and encoded-tile
        // timeline meld stops advancing. Tile refresh still runs from renderFrameFinished / debounced work.
        if (pr.ON) pr.p(TAG, pr.autoPlay, "cameraChangedCallback, $event")

        if (mapView.width != lastWidth) { //Detect orientation change, update camera.
            if (lastWidth != 0) {
                setupCamera(false)
                lastWidth = mapView.width
                camera.orientationChanged = true

                for (layer in layers) {
                    if (layer.value.paint is ParticleLayerPaint) {
                        camera.needsRotationHandled = true
                        //(layer.value.paint as ParticleStyle).needsRotationHandled = true
                    }
                }

                CoroutineScope(Dispatchers.Main).launch {
                    updateCamera() //Update matrices based on camera position
                    if (timeline.state != AnimationState.playing /*|| Timeline.pausedForMovement*/) {
                        onMove(cameraTriggered, "from cameraChangeCallback")
                    }
                }
            }
            lastWidth = mapView.width
        }

        debounceMoveEndJob?.cancel()
        debounceMoveEndJob = CoroutineScope(Dispatchers.Main).launch {
            delay(150)

            if (Timeline.pausedForMovement) {
                Timeline.pausedForMovement = false
            }

            updateLegendsForMap()
            invalidateEncodedGridVectorSourcesOnCameraChange()
        }

        // Reposition only: do not call updateWithSameData() here. That path runs finalizeLayoutAndMove(),
        // which posts moveView() to the next frame with stale screen coords while this callback also calls
        // move() immediately — the deferred move fights the fresh one and causes flicker/jumping during pan.
        if (dataInspector.isActive == true && mapboxMap != null && dataInspector.targetCoordinate != null) {
            dataInspector.move(mapboxMap!!.pixelForCoordinate(dataInspector.targetCoordinate!!))
        }
    }

    /** Called from constuctor **/
    private fun handleCallbackSubscriptions() {

        val mapIdleCallback = MapIdleCallback {
            CoroutineScope(Dispatchers.Main).launch {
                onMoveEnd()
                invalidateEncodedGridVectorSourcesOnCameraChange()
            }

            if (Timeline.pausedForMovement) {
                Timeline.pausedForMovement = false
            }

            if (cameraTriggered) {
                cameraTriggered = false
            } else {
                camera.moveState = Camera.STOPPED
            }
        }

        val renderFrameFinishedCallback = RenderFrameFinishedCallback {
            CoroutineScope(Dispatchers.Main).launch {
                updateCamera() //Update matrices based on camera position
                onMoveNoMove(cameraTriggered, "from cameraChangeCallback")
                // Debounced camera callbacks are cancelled while the map moves; poll here so encoded-grid
                // sources still invalidate during pinch-zoom and drag.
                val now = SystemClock.elapsedRealtime()
                if (now - lastEncodedGridCameraFramePollMs >= 75L) {
                    lastEncodedGridCameraFramePollMs = now
                    invalidateEncodedGridVectorSourcesOnCameraChange()
                }
            }
        }

        mapboxMap?.subscribeRenderFrameFinished(renderFrameFinishedCallback)
        mapboxMap?.subscribeCameraChanged(cameraChangedCallBack)
        mapboxMap?.subscribeMapIdle(mapIdleCallback)
        mapboxMap?.subscribeStyleLoaded {
            updateMaskLayersForMap()
        }
    }

    private fun updateMaskLayersForMap() {
        mapboxMap?.getStyle { style ->
            try {
                MaskUtils._masks.forEach { (kind, maskData) -> // Iterate through your tracked mask layers
                    var sourceLayerIdForColor: String? = null
                    when (kind) {
                        MaskLayerKind.LAND -> {
                            sourceLayerIdForColor = "land"
                        }

                        MaskLayerKind.NONE -> {}
                        MaskLayerKind.WATER -> {}
                    }
                    if (sourceLayerIdForColor != null) {
                        val rgbString = getBackgroundColorRBGStringFromLayer(style, sourceLayerIdForColor)

                        if (rgbString != null) {
                            MaskUtils.changeFillLayerColor(mapboxMap!!, "mask::land", rgbString)
                        }
                    }
                }
            } catch (e: Exception) {
                println("MapMaskUpdate Error updating mask layers: ${e.message}  error: $e")
            }
        }
    }

    /** This is in the CameraSync class in the typescript version */
    private fun updateCamera() {
        mapZoom = mapboxMap!!.cameraState.zoom
        /**Center of viewable map from 0 to 1, top to bottom*/
        val c = getCenter()
        val lonNorm = (c.lon % 360.0 + 360.0 + 180.0) % 360.0 - 180.0
        val point = viewport.projection.project(Coordinate(c.lat, lonNorm))
        viewport.centerCoordinate = GLCoordinate2D(point.x, point.y)
        worldSize = densityMult * Geo.TILE_SIZE * 2.0.pow(mapZoom).toFloat()
        zoomInt = mapZoom.toInt() + zoomOffset

        /*
        val prevLogged = lastDebugLoggedMapZoom
        if (prevLogged == null || kotlin.math.abs(mapZoom - prevLogged) > 1e-4) {
            lastDebugLoggedMapZoom = mapZoom
            Log.d(TAG, "mapZoom=$mapZoom zoomInt=$zoomInt (encoded tile / camera sync)")
        }
        */

        // Mercator scale must track fractional mapZoom: worldSize uses 2^mapZoom, so using
        // discrete zoomInt here caused ~2x jumps at integer zooms (e.g. 0.9999 vs 1.0).
        val zoomForMercatorScale = mapZoom + zoomOffset
        scaleCalc = (tileSize / worldSize) * 2f.pow(zoomForMercatorScale.toFloat())
        scaleMatrix.elements[0] = scaleCalc
        scaleMatrix.elements[5] = -scaleCalc

        translationCalc = tileSize * 2.0.pow(zoomForMercatorScale + 1.0) // +1: Mapbox tile space
        translationMatrix.elements[12] = (point.x * translationCalc).toFloat()
        translationMatrix.elements[13] = (point.y * translationCalc).toFloat()

        rotScalePitchMatrix = CameraSync.calculateCameraMatrixDeg(
            getPitch().toFloat(), getBearing().toFloat(), scaleMatrix
        )
        worldMatrix.multiply(rotScalePitchMatrix, translationMatrix)
        camera.zoom =
            mapZoom // This is used in render to compare to maxZoom and scale tiles, 4.9999 can turn into 5.0...
        camera.worldMatrix = worldMatrix
        camera.updateMatrixWorld() //  camera.viewMatrix= worldMatrix.invert(), strips translation out of world matrix

        // Keep [cachedMapboxBounds] current for any thread that must not call Mapbox Camera APIs (render, tile IO).
        runCatching {
            val m = mapboxMap!!
            cachedMapboxBounds = m.coordinateBoundsForCameraUnwrapped(m.cameraState.toCameraOptions())
        }
    }

    /**
     * @return Mapbox camera zoom (fractional allowed).
     */
    override fun getZoom(): Double {
        mapZoom = mapboxMap!!.cameraState.zoom
        return mapZoom
        // Mapbox zoom is 1 less than normal zoom levels
    }

    /**
     * Animates or jumps the camera to the given Mapbox zoom.
     *
     * @param zoom Mapbox zoom level.
     */
    override fun setZoom(zoom: Double) {
        mapZoom = zoom
        mapboxMap?.setCamera(CameraOptions.Builder().zoom(zoom).build())
    }

    /**
     * Sets map bearing (rotation in degrees; 0 = north up).
     *
     * @param bearing Degrees clockwise from north.
     */
    fun setBearing(bearing: Double) {
        mapboxMap?.setCamera(
            CameraOptions.Builder().bearing(bearing).build()
        )
    }

    /**
     * Sets map pitch / tilt in degrees.
     *
     * @param pitch Degrees from vertical (Mapbox convention).
     */
    fun setPitch(pitch: Double) {
        mapboxMap?.setCamera(
            CameraOptions.Builder().pitch(pitch).build()
        )
    }

    /**
     * @return Current bearing in degrees.
     */
    override fun getBearing(): Double {
        return mapboxMap!!.cameraState.bearing
    }

    /**
     * @return Current pitch in degrees.
     */
    override fun getPitch(): Double {
        return mapboxMap!!.cameraState.pitch
    }

    /**
     * @return Camera center as latitude/longitude degrees.
     */
    override fun getCenter(): Coordinate {
        return Coordinate(
            mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude()
        )
    }

    /**
     * Moves the camera center while preserving the current [getZoom].
     *
     * @param center Target latitude/longitude.
     */
    override fun setCenter(center: Coordinate) {
        centerLatLng = center
        mapboxMap?.setCamera(
            CameraOptions.Builder().center(
                Point.fromLngLat(center.lon, center.lat)
            ).zoom(getZoom()).build()
        )
    }

    /**
     * Visible geographic bounds derived from Mapbox unwrapped camera bounds and [VisibleGeoBounds].
     *
     * @return South, west, north, east in degrees for tile and UI logic.
     */
    override fun getBounds(): LatLonBounds {
        val boundingBox = getMapboxBounds()
        val v =
            VisibleGeoBounds.fromMapboxUnwrappedCamera(
                boundingBox,
                getCenter().lon,
                getZoom(),
            )

        // println(">>> MapboxMapController: getBounds() bnding bx: ${boundingBox.west()} to ${boundingBox.east()}")
        // println(">>> MapboxMapController: getBounds() bnding v: ${v.west} to ${v.east}")
        return LatLonBounds(v.west, v.south, v.east, v.north)
    }

    /**
     * Raw unwrapped longitudes from Mapbox — not passed through [VisibleGeoBounds], which can collapse
     * the viewport to a single [-180,180] strip and hide extra world copies for encoded tile draws.
     */
    override fun getUnwrappedCameraLonBoundsForTiles(): Pair<Double, Double> {
        val b = getMapboxBounds()
        return b.west() to b.east()
    }

    /**
     * Loads Xweather/MapsGL style assets once the Mapbox style is ready (images, DPR-aware resources).
     */
    override fun setupEvents() {
        val dpr = mapView.context.resources.displayMetrics.density
        doEnsuringStyleLoaded {
            mapboxMap?.let { map ->
                CoroutineScope(Dispatchers.Main).launch {
                    val registrar = MapboxImageRegistrar(map)
                    service.loadStyles(registrar, dpr)
                }
            }
        }
    }

    /**
     * [TileLayer.TileLayerEventListener] hook; reserved for future tile-layer events from Mapbox path.
     */
    override fun onTileLayerEvent(layerId: String, eventType: TileLayer.TileLayerEventType, data: Any?) {
    }


    internal fun testForceClear() {
        for (layer in layers.values) {
            if (layer is EncodedTileLayer) {
                val bounds = layer.getTileBounds()
                //println("MapboxMapController n cache size before: ${layer.source.tileCache.nativeCache.getCacheSize()}")

                layer.source.tileCache.clearOutsideBounds(bounds)
                //println("MapboxMapController n cache size after: ${layer.source.tileCache.nativeCache.getCacheSize()}")
            }
        }
    }

    /** [ComponentCallbacks2]: no-op; orientation is handled via camera callbacks. */
    override fun onConfigurationChanged(p0: Configuration) {}

    @Deprecated("Deprecated in Java")
    override fun onLowMemory() {
    }

    /**
     * Clears encoded tile caches outside the visible viewport when the OS reports memory pressure
     * ([ComponentCallbacks2]); aggressive only for background / UI-hidden levels.
     *
     * @param level Android memory trim level.
     */
    override fun onTrimMemory(level: Int) {
        // Determine how aggressively to clear caches based on the memory pressure level.
        val aggressive = when (level) {
            // Your app is running, but the device is getting low on memory.
            // A non-aggressive cleanup is appropriate.
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE, ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                if (pr.ON) pr.p(
                    TAG,
                    pr.onMemoryTrim,
                    "onTrimMemory: Foreground memory pressure detected. Performing normal cleanup."
                )
                false
            }

            // This constant is deprecated in API 35 and can be safely removed.
            // The system will no longer send this signal to a foreground app.

            // Your app's UI is no longer visible. A great time to be aggressive with cleanup.
            ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN -> {
                if (pr.ON) pr.p(TAG, pr.onMemoryTrim, "onTrimMemory: UI is hidden")
                true
            }

            // Your app is in the background and is on the LRU list to be killed.
            // This is your last chance to clean up. This is the same as onLowMemory().
            ComponentCallbacks2.TRIM_MEMORY_COMPLETE, ComponentCallbacks2.TRIM_MEMORY_MODERATE -> {
                if (pr.ON) pr.p(
                    TAG,
                    pr.onMemoryTrim,
                    "onTrimMemory: Background memory pressure is high. Releasing as much as possible."
                )
                true
            }

            else -> false
        }

        // Only purge aggressively when the OS is asking for it.
        // Doing it for TRIM_MEMORY_RUNNING_LOW/MODERATE causes visible "rebind/reload" hitches
        // even though the GPU isn't actually out of room.
        if (!aggressive) return

        for (layer in layers.values) {
            if (layer is EncodedTileLayer) {
                val bounds = layer.getTileBounds()
                layer.source.tileCache.clearOutsideBounds(bounds)
            }
        }
    }

    /**
     * Reorders a style layer in the Mapbox style stack.
     *
     * @param id Style layer id to move.
     * @param beforeId Insert **before** this layer id, or `null` for top of stack.
     */
    override fun moveLayer(id: String, beforeId: String?) {
        mapboxMap?.moveStyleLayer(id, LayerPosition(null, beforeId, null))
    }

    private fun doEnsuringStyleLoaded(block: () -> Unit) {
        mapboxMap?.let {
            if (it.style != null) {
                block()
            } else {
                val cancelable = it.subscribeStyleLoaded {
                    block()
                }
                mapboxCancelables += cancelable
            }
        }
    }

    private fun getMapboxBounds(): CoordinateBounds {
        val map = mapboxMap!!
        if (Looper.myLooper() == Looper.getMainLooper()) {
            val b = map.coordinateBoundsForCameraUnwrapped(map.cameraState.toCameraOptions())
            cachedMapboxBounds = b
            return b
        }
        val cached = cachedMapboxBounds
        if (cached != null) {
            return cached
        }
        // Should not happen after [cachedMapboxBounds] is set in the constructor; avoid touching Mapbox off main.
        throw IllegalStateException(
            "coordinateBoundsForCameraUnwrapped cache unavailable off main thread"
        )
    }

    /** Refreshes [MapController.centerLatLng] from the current Mapbox camera center. */
    override fun updateCenterLatLngFromMap() {
        centerLatLng = Coordinate(mapboxMap!!.cameraState.center.latitude(), mapboxMap!!.cameraState.center.longitude())
    }

    /**
     * Formats a [Date] as an ISO-8601-like UTC string (first 19 chars + `Z`) for display or logging.
     *
     * @param date Instant to format using the system default zone then normalized for output.
     */
    fun formatDate(date: Date): String {
        val instant = date.toInstant()
        val zonedDateTime = ZonedDateTime.ofInstant(instant, ZoneId.systemDefault()) // detect timezone
        val formatter: DateTimeFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME
        return "${zonedDateTime.format(formatter).substring(0, 19)}Z"
    }

    /**
     * Syncs MapsGL layer visibility, custom layer host visibility, and Mapbox style `visibility` for [id].
     */
    override fun setLayerVisible(id: String, visible: Boolean) {
        // Keep host + Mapbox style in sync before MapsGL redraw(). Previously super() ran first and could
        // triggerRepaint while layerHosts still had the old showLayer and/or before style visibility updated,
        // which matches “mask only updates after zoom” for custom layers.
        layerHosts[id]?.showLayer = visible
        //println(">>> MapboxMapController: setLayerVisible() visibility setting: #visible: $visible")
        doEnsuringStyleLoaded {
            mapboxMap?.style?.getLayer(id)?.visibility(if (visible) Visibility.VISIBLE else Visibility.NONE)
        }
        super.setLayerVisible(id, visible)
        triggerRepaintOnOwningThread()
    }

    override fun setLayerHostToUpdate(layerId: String) {
        layerHosts[layerId]?.setTexturesToBind()
    }

    override fun addToMap(source: DataSource, onSourceAdded: () -> Unit) {
        doEnsuringStyleLoaded {
            if (mapboxMap?.style?.styleSourceExists(source.id) == true) return@doEnsuringStyleLoaded
            if (pr.ON) pr.p("MapboxMapController", pr.adminLayers, "addToMap() 100")
            try {
                when (source) {
                    is VectorTileSource -> {
                        mapboxMap?.let {
                            val adapter = MapboxVectorSourceAdapter(source, it)
                            MainScope().launch {
                                val customSource = adapter.makeSource()
                                source.validTime =
                                    parseDateArrayFromString(Timeline.timeStrings[Timeline.currentPhaseA]).first()
                                source.setInvalidateFunction(adapter::invalidate)
                                if (source is EncodedGridVectorTileSource) {
                                    source.setBatchInvalidateFunction { coords ->
                                        adapter.invalidateTilesBatch(coords)
                                    }
                                }
                                mapboxMap?.addSource(customSource)
                                onSourceAdded.invoke()
                            }
                        }
                    }

                    is GeoJSONSource -> {
                        val emptyCollection = FeatureCollection.fromFeatures(emptyList())
                        source.pushGeoJsonToMapStyle = { fc ->
                            // Style mutations must run on the MapView / main thread.
                            mapView.post {
                                doEnsuringStyleLoaded {
                                    val style = mapboxMap?.style ?: return@doEnsuringStyleLoaded
                                    if (!style.styleSourceExists(source.id)) return@doEnsuringStyleLoaded
                                    val mb =
                                        style.getSource(source.id) as? GeoJsonSource ?: return@doEnsuringStyleLoaded
                                    mb.featureCollection(fc ?: emptyCollection)
                                }
                                mapboxMap?.triggerRepaint()
                            }
                        }
                        val geoJsonSource = geoJsonSource(source.id) {
                            when {
                                source.data != null -> featureCollection(source.data!!)
                                !source.url.isNullOrBlank() -> {
                                    val resolved = source.makeDataURL()
                                    if (resolved != null) {
                                        data(resolved.toString())
                                    } else {
                                        featureCollection(emptyCollection)
                                    }
                                }

                                else -> featureCollection(emptyCollection)
                            }
                        }
                        mapboxMap?.style?.addSource(geoJsonSource)
                        mapView.post { mapboxMap?.triggerRepaint() }
                        onSourceAdded.invoke()
                    }

                    else -> {}
                }
            } catch (e: Exception) {
                println(">>> MapController: Failed to add source to map: ${e.localizedMessage}")
            }
        }
    }

    /**
     * Adds [layer] to the Mapbox style: vector layers as Mapbox style layers, encoded/custom layers
     * via [MapboxLayerHost] persistent custom layers. Waits for style load and optionally for source readiness.
     */
    override fun addToMap(layer: MapLayer<*, *>, beforeId: String?) {
        // This ensures that the code inside only runs after the style is loaded.
        doEnsuringStyleLoaded {
            // Do not call super.addToMap for VectorTileLayer: TileLayer.onAdd runs RasterLayerRenderer.setUpRenderPass,
            // which casts paint to RasterLayerPaint; vector style layers use CircleLayerPaint / FillLayerPaint / etc.
            MainScope().launch {
                while (cameraTriggered) { // Don't add while mapbox is moving. Prevents crashes if added while moving.
                    delay(50)
                }

                val style = mapboxMap?.style ?: return@launch

                when (layer) {
                    is VectorTileLayer -> {
                        if (layer.paint is VectorLayerPaint) {
                            if (style.styleLayerExists(layer.id)) return@launch
                            val paintStyle = (layer.paint as VectorLayerPaint).asStyleJSON(
                                id = layer.id, source = layer.source.id, sourceLayer = layer.sourceLayer
                            )
                            paintStyle.filter = layer.filter
                            val styleJSON = paintStyle.asStyleJSONObject()

                            fun addStyleLayer() {
                                if (mapboxMap?.style?.styleLayerExists(layer.id) == true) return
                                mapboxMap?.styleManager?.addPersistentStyleLayer(
                                    Value.valueOf(styleJSON.toValueMap()), LayerPosition(null, beforeId, null)
                                )
                                mapView.post { mapboxMap?.triggerRepaint() }
                            }

                            if (mapboxMap?.style?.styleSourceExists(layer.source.id) == false) {
                                var job: Job? = null
                                job = onSourceAdded.observe(onEach = {
                                    if (it == layer.source.id) {
                                        addStyleLayer()
                                        job?.cancel()
                                    }
                                })

                                // Fallback in case onSourceAdded fires before observer registration.
                                MainScope().launch {
                                    repeat(30) {
                                        delay(100)
                                        if (mapboxMap?.style?.styleSourceExists(layer.source.id) == true) {
                                            addStyleLayer()
                                            job?.cancel()
                                            return@launch
                                        }
                                    }
                                }
                            } else {
                                addStyleLayer()
                            }

                            MainScope().launch {
                                delay(1000) // Wait for 1000 milliseconds (1 second)
                                trigger(MapControllerEvents.VECTOR_LAYER_ADDED, "")
                            }
                        }
                    }

                    is TileLayer -> {
                        super.addToMap(layer, beforeId)
                        layer.addTileLayerEventListener(this@MapboxMapController)
                        try {
                            if (!layerHosts.contains(layer.id)) {
                                val layerHost = MapboxLayerHost(mapView.context, layer)
                                startCustomLayerUpdates(layer.paint is ParticleLayerPaint)
                                layerHosts[layer.id] = layerHost
                                layerHost.setLayerHostCamera(camera)
                            }
                        } catch (e: Exception) {
                            println("$TAG Failed to add layer to map: $e")
                        }

                        mapboxMap?.style!!.addPersistentStyleCustomLayer(
                            layer.id, layerHosts[layer.id] as MapboxLayerHost, LayerPosition(null, beforeId, null)
                        )
                        // Gridded wind sidecars are registered before this style layer exists; without a post-add
                        // invalidate, Mapbox may not refetch custom geometry until the next camera change (e.g. zoom 0).
                        forEachEncodedGridVectorTileSource { it.invalidate() }
                        mapView.post { mapboxMap?.triggerRepaint() }
                    }
                }
            }
        }
    }

    /** Removes a style source from Mapbox when the [DataSource] is removed from the controller. */
    override fun removeFromMap(source: DataSource) {
        super.removeFromMap(source)

        doEnsuringStyleLoaded {
            if (source is VectorTileSource || source is GeoJSONSource) {
                if (source is GeoJSONSource) {
                    source.pushGeoJsonToMapStyle = null
                }
                mapboxMap?.style?.let {
                    if (it.styleSourceExists(source.id)) {
                        mapboxMap?.removeStyleSource(source.id)
                    }
                }
            }
        }
    }

    override fun removeFromMap(layer: MapLayer<*, *>) {
        super.removeFromMap(layer)
        if (layer is TileLayer) layer.removeTileLayerEventListener(this)
        doEnsuringStyleLoaded {
            mapboxMap?.style?.let {
                if (it.styleLayerExists(layer.id)) {
                    it.removeStyleLayer(layer.id)
                }
                layerHosts.remove(layer.id)
                //hostLayerIds.remove(layer.id)
            }
        }
    }

    /**
     * Mapbox [MapboxMap.triggerRepaint] must run on the thread that owns the native [Map] (the UI/main thread).
     * [redraw] is also invoked from the custom-layer render path (e.g. [MapboxLayerHost.bindTextures]), which runs
     * on the renderer thread — posting avoids bindgen "not owning the object" errors during timeline playback.
     */
    private fun triggerRepaintOnOwningThread() {
        val map = mapboxMap ?: return
        if (Looper.myLooper() == Looper.getMainLooper()) {
            map.triggerRepaint()
        } else {
            mapView.post { mapboxMap?.triggerRepaint() }
        }
    }

    /**
     * Schedules [MapboxMap.triggerRepaint] on the Mapbox map thread (posts if called from a worker or GL thread).
     */
    override fun redraw() {
        triggerRepaintOnOwningThread()
    }

    /**
     * Mapbox `queryRenderedFeatures` at a screen point for the given vector layers; fills data-inspector
     * vector fields when [onTouch] matches the active inspector buffer.
     *
     * @param point Geographic point (converted to screen via Mapbox).
     * @param vectorLayerList Vector style layers to include in the query.
     * @param onTouch When `true`, uses touch-buffer results; when `false`, uses programmatic query buffer.
     * @return Per-layer [FeatureQueryResult], or `null` if nothing queried or timeline blocks queries.
     */
    suspend fun queryFeatures(
        point: Point,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {


        ///println(">>> queryFeatures Entered")
        if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() entered, layerCount: ${vectorLayerList.size}")

        val result: DataInspectorResult? = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector.hasMoved)) {
            val queryGeometry = RenderedQueryGeometry(mapboxMap!!.pixelForCoordinate(point))
            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)
            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result?.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() layer.id: ${layer.id}")
                val featuresForThisLayer = featuresBySourceId[layer.source.id]
                //dataInspector?.dIResult?.queriedFeatures?.add(featuresForThisLayer)
                if (featuresForThisLayer.isNullOrEmpty()) {
                    if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeatures() exiting, features For ${layer.id} is null")
                    continue
                }

                if (pr.ON) pr.p(
                    TAG,
                    pr.fireVector,
                    "queryFeatures() featuresForThisLayer ${layer.id} size: ${featuresForThisLayer.size}"
                )

                val presentation = dataInspector.presentationsByLayerId[layer.id]

                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result?.vectorTitles?.add(presentation.title.toString())
                        result?.vectorLayerIds?.add(layer.id)
                        result?.vectorRawValues?.add(featuresForThisLayer)
                        result?.vectorValues?.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                if (pr.ON) pr.p(
                    TAG,
                    pr.fireVector,
                    "queryFeatures() featuresForThisLayer count: ${featuresForThisLayer.size} "
                )

                for (item in featuresForThisLayer) {
                    // CORRECT: Access the properties and feature through the 'queriedFeature' property of item.
                    val originalProperties = item.queriedFeature.feature.properties()
                    val featureId = item.queriedFeature.feature.id()


                    val myMap: Map<String, Any?>? = originalProperties?.entrySet()?.associate { (key, jsonElement) ->
                        // This is a recursive function defined right where it's used
                        fun toKotlinType(element: JsonElement): Any? {
                            return when {
                                element.isJsonNull -> null
                                element.isJsonPrimitive -> {
                                    val primitive = element.asJsonPrimitive
                                    when {
                                        primitive.isBoolean -> primitive.asBoolean
                                        primitive.isNumber -> primitive.asNumber // Can be Long, Double, etc.
                                        primitive.isString -> primitive.asString
                                        else -> primitive.toString()
                                    }
                                }

                                element.isJsonArray -> {
                                    // Recursively convert each element in the array
                                    element.asJsonArray.map { toKotlinType(it) }
                                }

                                element.isJsonObject -> {
                                    // Recursively convert the nested object to a map
                                    element.asJsonObject.entrySet().associate { (k, v) -> k to toKotlinType(v) }
                                }

                                else -> null
                            }
                        }
                        // Convert the value for the current key
                        key to toKotlinType(jsonElement)
                    }

                    if (myMap == null) {
                        return hashMapOf()
                    }

                    val queriedFeature = QueriedFeature(
                        featureId,
                        layer.source.id,
                        item.queriedFeature.sourceLayer, // Use the sourceLayer from the inner feature
                        myMap // Pass the original properties
                    )
                    queriedFeatureList.add(queriedFeature)
                    if (pr.ON) pr.p(
                        TAG,
                        pr.fireVector,
                        "queryFeatures() adding queried feature: ${queriedFeature.properties}"
                    )

                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult

            }
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            if (i2 > 0) {
                if (pr.ON) pr.p(
                    TAG, pr.flickerFix, "queryFeatures() vectorlist not empty, results found, update trigger vector!"
                )
                this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            }
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() found EMPTY, CLEARING DI Result!")
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
            //}
        }
        return null
    }

    /**
     * Queries features within a rectangular area.
     * @param boxTopLeft The top-left screen coordinate of the rectangle.
     * @param boxBottomRight The bottom-right screen coordinate of the rectangle.
     */
    suspend fun queryFeaturesInBox(
        boxTopLeft: ScreenCoordinate,
        boxBottomRight: ScreenCoordinate,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {

        if (pr.ON) pr.p(TAG, pr.fireVector, "queryFeaturesInBox() entered, layerCount: ${vectorLayerList.size}")

        val result: DataInspectorResult = if (onTouch) {
            dataInspector.dIResult
        } else {
            dataInspector.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector.hasMoved)) {
            // CHANGE: Use ScreenBox instead of pixelForCoordinate(point)
            val screenBox = ScreenBox(boxTopLeft, boxBottomRight)
            val queryGeometry = RenderedQueryGeometry(screenBox)

            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)

            // This call remains the same, but it now uses the geometry containing the ScreenBox
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)

            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                val featuresForThisLayer = featuresBySourceId[layer.source.id]

                if (featuresForThisLayer.isNullOrEmpty()) {
                    continue
                }

                val presentation = dataInspector.presentationsByLayerId[layer.id]
                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result.vectorTitles.add(presentation.title.toString())
                        result.vectorLayerIds.add(layer.id)
                        result.vectorRawValues.add(featuresForThisLayer)
                        result.vectorValues.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                for (item in featuresForThisLayer) {
                    val originalProperties = item.queriedFeature.feature.properties()
                    val featureId = item.queriedFeature.feature.id()

                    val myMap: Map<String, Any?>? = originalProperties?.entrySet()?.associate { (key, jsonElement) ->
                        fun toKotlinType(element: JsonElement): Any? {
                            return when {
                                element.isJsonNull -> null
                                element.isJsonPrimitive -> {
                                    val primitive = element.asJsonPrimitive
                                    when {
                                        primitive.isBoolean -> primitive.asBoolean
                                        primitive.isNumber -> primitive.asNumber
                                        primitive.isString -> primitive.asString
                                        else -> primitive.toString()
                                    }
                                }

                                element.isJsonArray -> element.asJsonArray.map { toKotlinType(it) }
                                element.isJsonObject -> element.asJsonObject.entrySet()
                                    .associate { (k, v) -> k to toKotlinType(v) }

                                else -> null
                            }
                        }
                        key to toKotlinType(jsonElement)
                    }

                    if (myMap != null) {
                        val queriedFeature = QueriedFeature(
                            featureId,
                            layer.source.id,
                            item.queriedFeature.sourceLayer,
                            myMap
                        )
                        queriedFeatureList.add(queriedFeature)
                    }
                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult
            }

            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            if (i2 > 0) {
                this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            }
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
        }
        return null
    }

    /**
     * Legacy vector query implementation kept for compatibility; prefer [queryFeatures].
     */
    suspend fun queryFeaturesOld(
        point: Point,
        vectorLayerList: List<VectorTileLayer>,
        onTouch: Boolean = true
    ): HashMap<String, FeatureQueryResult>? {
        if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() entered, layerCount: ${vectorLayerList.size}")
        if (dataInspector == null) return null

        val result: DataInspectorResult? = if (onTouch) {
            dataInspector?.dIResult
        } else {
            dataInspector?.queryResult
        }

        if (vectorLayerList.isNotEmpty() && (timeline.state != AnimationState.playing || dataInspector!!.hasMoved)) {
            val queryGeometry = RenderedQueryGeometry(mapboxMap!!.pixelForCoordinate(point))
            i2 = 0

            val layerIds = vectorLayerList.map { it.id }
            val queryOptions = RenderedQueryOptions(layerIds, null)
            val renderedFeatures = queryRenderedFeatures(queryGeometry, queryOptions)
            val featuresBySourceId = renderedFeatures.groupBy { it.queriedFeature.source }
            result?.clearVector()

            val returnMap: HashMap<String, FeatureQueryResult> = hashMapOf()

            for (layer in vectorLayerList) {
                if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() layer.id: ${layer.id}")
                val featuresForThisLayer = featuresBySourceId[layer.source.id]
                //dataInspector?.dIResult?.queriedFeatures?.add(featuresForThisLayer)
                if (featuresForThisLayer.isNullOrEmpty()) {
                    continue
                }

                val presentation = dataInspector?.presentationsByLayerId?.get(layer.id)
                if (presentation != null) {
                    val resultString = presentation.fn(featuresForThisLayer)
                    if (resultString.length > 5) {
                        result?.vectorTitles?.add(presentation.title.toString())
                        result?.vectorLayerIds?.add(layer.id)
                        result?.vectorRawValues?.add(featuresForThisLayer)
                        result?.vectorValues?.add(resultString)
                        i2++
                    }
                }

                val queriedFeatureList: MutableList<QueriedFeature> = mutableListOf()

                for (item in featuresForThisLayer) {
                    val stringValueMapItem = mapOf("layerName" to item)
                    val queriedFeature = QueriedFeature(
                        item.queriedFeature.feature.id(), layer.source.id, item.queriedFeature.sourceLayer,
                        stringValueMapItem
                    )
                    queriedFeatureList.add(queriedFeature)
                }

                val featureQueryResult = FeatureQueryResult(layer.id, queriedFeatureList)
                returnMap[layer.id] = featureQueryResult

            }
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            if (i2 > 0) {
                if (pr.ON) pr.p(
                    TAG, pr.flickerFix, "queryFeatures() vectorlist not empty, results found, update trigger vector!"
                )
                this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            }
            return returnMap

        } else if (vectorLayerList.isEmpty()) {
            if (pr.ON) pr.p(TAG, pr.flickerFix, "queryFeatures() found EMPTY, CLEARING DI Result!")
            result?.clearVector()
            this.trigger(DataInspectorEvent.VECTOR_UPDATE, "")
            return null
            //}
        }
        return null
    }

    /**
     * Wraps the callback-based `queryRenderedFeatures` function in a suspending coroutine.
     *
     * This function can be called from within a coroutine scope and will suspend until the
     * query is complete, then return the result or throw an exception.
     *
     * @param queryGeometry The geometry to query.
     * @param queryOptions The options for the query.
     * @return A `List<QueriedRenderedFeature>` containing the query results.
     * @throws Exception if the query fails.
     */
    private suspend fun queryRenderedFeatures(
        queryGeometry: RenderedQueryGeometry, queryOptions: RenderedQueryOptions
    ): List<QueriedRenderedFeature> {
        // This bridges the callback API with the coroutine world.
        // It suspends the coroutine until 'continuation.resume' or 'resumeWithException' is called.
        return suspendCancellableCoroutine { continuation ->
            mapboxMap!!.queryRenderedFeatures(queryGeometry, queryOptions) { result ->
                if (result.isValue) {
                    // On success, resume the coroutine with the list of features.
                    /*
                    continuation.resume(result.value ?: emptyList()) { cause, _, _ ->
                        null
                        (cause)
                    }*/
                    continuation.resume(result.value ?: emptyList()) // older version for compatibility.

                } else {
                    // On failure, resume the coroutine by throwing an exception.
                    continuation.resumeWithException(
                        Exception(result.error ?: "Mapbox queryRenderedFeatures failed with an unknown error.")
                    )
                }
            }
        }
    }

    /**
     * [addToMap] adds both the weather custom layer and (on first use) the mask vector layer asynchronously.
     * Wait until both ids exist, then place **every** encoded layer that uses this mask **below** the mask.
     * Moving only the newly-added layer leaves earlier layers (e.g. swell-heights) above the mask, so the
     * land fill vanishes visually when multiple masked layers are active.
     */
    internal fun syncLandMaskStackAfterWeatherLayerAdded(
        weatherLayerId: String,
        @Suppress("UNUSED_PARAMETER") insertBeforeId: String?,
        maskKind: MaskLayerKind,
    ) {
        if (maskKind == MaskLayerKind.NONE) return
        MainScope().launch {
            val maskData = _masks[maskKind] ?: return@launch
            val maskId = maskData.layer.id
            var attempts = 0
            while (attempts < 120) {
                val style = mapboxMap?.style
                if (style != null &&
                    style.styleLayerExists(weatherLayerId) &&
                    style.styleLayerExists(maskId)
                ) {
                    break
                }
                delay(50)
                attempts++
            }
            setLayerVisible(maskId, true)
            when (maskKind) {
                MaskLayerKind.LAND -> {
                    for (entry in layers) {
                        val v = entry.value
                        if (v is EncodedTileLayer && v.hasLandMask && v.visible &&
                            mapboxMap?.style?.styleLayerExists(v.id) == true
                        ) {
                            moveLayer(v.id, maskId)
                        }
                    }
                }

                else -> moveLayer(weatherLayerId, maskId)
            }
            (maskData.layer.source as? VectorTileSource)?.invalidate()
            triggerRepaintOnOwningThread()
        }
    }

    internal fun showOrHideLandMask(beforeId: String? = null): String? {
        //println(">>> MapboxMapController: showOrHideLandMask() entered,  ")
        var found = false

        for (layer in layers) {
            val layerValue = layer.value

            //println(">>> MapboxMapController: showOrHideLandMask() ${layerValue.id} ${layerValue.javaClass} ((layerValue is EncodedTileLayer )) == ${(layerValue is EncodedTileLayer)},  ")
            if (layerValue is EncodedTileLayer) {
                if (layerValue.visible && layerValue.hasLandMask) { //TODO: better logic to detect...
                    found = true
                }
            }
        }


        //println(">>> MapboxMapController: showOrHideLandMask() existingMaskData: ${_masks[MaskLayerKind.LAND]},  ")
        val existingMaskData = _masks[MaskLayerKind.LAND] ?: return null // Guard


        setLayerVisible(existingMaskData.layer.id, found)
        MaskUtils.lastVisibleState = found
        if (found) {
            (existingMaskData.layer.source as? VectorTileSource)?.invalidate()
            return existingMaskData.layer.id
        }

        return null
    }

    internal fun getLog() {
        /*
        println("GL1--------------------------------------------------------------")
        println("GL1 pausedForMovement:${Timeline.pausedForMovement}")
        println("GL1 pausedForDownload:${Timeline.pausedForDownload}")
        println("GL1 timeLine State:${timeline.state}")
        println("GL1 Camera MoveState:${camera.moveState}")
        println("GL1 tl.isDownloading: ${Timeline.isDownloading}")
        println("GL1 waitingOnDL: $waitingOnDL")
        println("GL1 wasWaitingOnDL: ${wasWaitingOnDL}")

        for (layer in layers) {
            if (layer.value.visible && layer.value.animator!!.animation.pendingCount != 0) {
                println("GL1 found PendingDL: ${layer.value.id} has ${layer.value.animator!!.animation.pendingCount}")
                println("GL1 tileCache pending: ${layer.value.source.tileCache._pending}")
            }
        }
        */
    }

    fun clearPending() {
        for (layer in layers) {
            if (layer.value is EncodedTileLayer) {
                layer.value.source.tileCache._pending.clear()
                layer.value.animator!!.animation.pendingCount = 0
                (layer.value.source as XweatherEncodedTileSource).pendingRequestedTiles.clear()
                checkDownloadStatus(layer.value.id, 0)
            }

        }

        Timeline.isDownloading = false
        waitingOnDL = false
        wasWaitingOnDL = true
        Timeline.pausedForDownload = false
        //timeline.state = AnimationState.playing
        //trigger(MapControllerEvents.LOAD_COMPLETE, true)

    }
}

/**
 * Bridges [ImageRegisteringMap] to Mapbox: registers bitmaps into the active style for symbol layers and sprites.
 * Used while loading style images during [MapboxMapController.setupEvents] (weather style load path).
 */
class MapboxImageRegistrar(private val mapboxMap: MapboxMap) : ImageRegisteringMap {
    /**
     * @param id Style image id referenced from layer paint.
     * @param image Raster to upload.
     * @param sdf When `true`, registers as an SDF image for tintable icons.
     */
    override fun addImage(id: String, image: Bitmap, sdf: Boolean) {
        mapboxMap.getStyle { style ->
            style.addImage(id, image, sdf)
        }
    }
}

// Utility extension functions to convert Map<String, Any> recursively into HashMap<String, Value>
private fun Any.toValue(): Value {
    return when (this) {
        is Map<*, *> -> {
            val map = HashMap<String, Value>()
            for ((k, v) in this) {
                if (k is String && v != null) {
                    map[k] = v.toValue()
                }
            }
            Value.valueOf(map)
        }

        is List<*> -> Value.valueOf(this.mapNotNull { it?.toValue() })
        is String -> Value.valueOf(this)
        is Int -> Value.valueOf(this.toLong())
        is Double -> Value.valueOf(this)
        is Float -> Value.valueOf(this.toDouble())
        is Long -> Value.valueOf(this)
        is Boolean -> Value.valueOf(this)
        else -> Value.nullValue()
    }
}

private fun Map<String, Any>.toValueMap(): HashMap<String, Value> {
    val result = HashMap<String, Value>()
    for ((key, value) in this) {
        result[key] = value.toValue()
    }
    return result
}