package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.Expression

/**
 * Minimal Mapbox-style filter evaluation for GLES stencil feature selection.
 * Supports `==`, `!=`, `all`, `any`, `!`, `get`, and `literal`.
 */
internal object StencilMaskFilter {

    fun matches(feature: Feature, filter: Expression?): Boolean {
        if (filter == null) return true
        return eval(filter.raw, feature) == true
    }

    @Suppress("UNCHECKED_CAST")
    private fun eval(node: Any?, f: Feature): Boolean? {
        when (node) {
            is Expression -> return eval(node.raw, f)
            is Boolean -> return node
            is List<*> -> {
                val list = node as List<Any?>
                if (list.isEmpty()) return null
                val op = list[0] as? String ?: return null
                when (op) {
                    "==" -> {
                        if (list.size < 3) return null
                        val a = evalValue(list[1], f) ?: return null
                        val b = evalValue(list[2], f) ?: return null
                        return valuesEqual(a, b)
                    }
                    "!=" -> {
                        if (list.size < 3) return null
                        val a = evalValue(list[1], f) ?: return null
                        val b = evalValue(list[2], f) ?: return null
                        return !valuesEqual(a, b)
                    }
                    "all" -> {
                        for (i in 1 until list.size) {
                            if (eval(list[i], f) != true) return false
                        }
                        return true
                    }
                    "any" -> {
                        for (i in 1 until list.size) {
                            if (eval(list[i], f) == true) return true
                        }
                        return false
                    }
                    "!" -> {
                        if (list.size < 2) return null
                        val inner = eval(list[1], f) ?: return null
                        return !inner
                    }
                }
            }
        }
        return null
    }

    @Suppress("UNCHECKED_CAST")
    private fun evalValue(node: Any?, f: Feature): Any? {
        when (node) {
            is Expression -> return evalValue(node.raw, f)
            is String, is Number, is Boolean -> return node
            is List<*> -> {
                val list = node as List<Any?>
                if (list.isEmpty()) return null
                when (list[0] as? String) {
                    "get" -> {
                        val key = list.getOrNull(1) as? String ?: return null
                        return featurePropertyAny(f, key)
                    }
                    "literal" -> return list.getOrNull(1)
                }
            }
        }
        return null
    }

    private fun featurePropertyAny(f: Feature, key: String): Any? {
        f.getStringProperty(key)?.let { return it }
        f.getNumberProperty(key)?.let { return it }
        return null
    }

    private fun valuesEqual(a: Any?, b: Any?): Boolean {
        if (a == null || b == null) return a == null && b == null
        if (a is Number && b is Number) {
            return a.toDouble() == b.toDouble()
        }
        return a == b || a.toString() == b.toString()
    }
}
