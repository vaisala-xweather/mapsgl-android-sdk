package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.weather.WeatherService

/**
 * Stencil land/water uses the same OSM MVT URL as [com.xweather.mapsgl.weather.WeatherSource.base_osm]
 * but a **dedicated** source id so [MapboxMapController.addToMap] always adds
 * [com.mapbox.maps.extension.style.sources.CustomGeometrySource] via [MapboxVectorSourceAdapter].
 *
 * Map styles commonly declare `base.osm` in JSON; in that case Mapbox never calls our
 * [com.xweather.mapsgl.sources.VectorTileSource.requestTile] / [glStencilMaskTileListener] path,
 * and the land stencil cache stays empty.
 */
object GlStencilOsm {
    const val SOURCE_ID: String = "mapsgl.stencil.base.osm"

    /**
     * Which vector tile source to use for the GLES stencil land/water mask.
     *
     * - [Source.MAPSGL] (default): Xweather's `open-street-map` endpoint at
     *   `prod.v1.mapsgl.api.xweather.com/vector/open-street-map/...`. Note that this dataset
     *   currently omits open-ocean polygons from its `water` MVT layer, which causes LAND-masked
     *   weather layers (Temperatures, etc.) to render across open water in tiles like the Gulf
     *   of St. Lawrence. A support ticket has been filed with Vaisala for the data fix.
     * - [Source.MAPBOX]: Mapbox Streets v8 (`api.mapbox.com/v4/mapbox.mapbox-streets-v8/...`).
     *   Requires [mapboxAccessToken] to be set to a valid Mapbox public access token. The
 *   `water` source-layer here is a single merged polygon covering all bodies of water
 *   including oceans, so the stencil masks correctly.
 *
 * [com.xweather.mapsgl.layers.spec.MaskLayerKind.TRANSPORTATION] uses the same tiles; the MVT
 * `transportation` layer is parsed for road/path line geometry (stencil ribbon), independent of `water`.
 *
 * [com.xweather.mapsgl.layers.spec.MaskLayerKind.COUNTRY] uses **boundary lines**: Mapbox Streets
 * [Source.MAPBOX] MVT layer `admin` (admin_level 0); [Source.MAPSGL] layer `boundary` (admin_level 2).
 * Match features with [com.xweather.mapsgl.layers.spec.BitmapLayerDescriptor.maskCountryIso3166Alpha2]
 * against properties such as `iso_3166_1` (and `iso_a2` on some tilesets).
 */
    enum class Source { MAPSGL, MAPBOX }

    /** Active stencil source. Set before constructing the `MapboxMapController`. */
    @JvmStatic
    var source: Source = Source.MAPSGL

    /**
     * Last [source] value used when wiring [SOURCE_ID] on a controller. When Demo 3 (MAPBOX) is
     * followed by Demo 2 (MAPSGL), the new controller must not reuse a mismatched tile URL.
     */
    @JvmStatic
    internal var lastWiredSource: Source? = null

    /**
     * Mapbox public access token, required only when [source] is [Source.MAPBOX]. Ignored for
     * [Source.MAPSGL].
     */
    @JvmStatic
    var mapboxAccessToken: String? = null

    internal fun sourceDescriptor(service: WeatherService): VectorSourceDescriptor =
        when (source) {
            Source.MAPBOX -> {
                val token = mapboxAccessToken
                    ?: error(
                        "GlStencilOsm.source = MAPBOX but mapboxAccessToken is null. " +
                            "Set GlStencilOsm.mapboxAccessToken before constructing the controller.",
                    )
                mapboxStreetsV8Descriptor(token)
            }
            Source.MAPSGL -> service.makeVectorSourceDescriptor(
                id = SOURCE_ID,
                code = "open-street-map",
            )
        }

    /**
     * Mapbox Streets v8 vector tiles. The `water` source-layer is a single merged polygon layer
     * covering all bodies of water (oceans, lakes, rivers); see
     * <https://docs.mapbox.com/data/tilesets/reference/mapbox-streets-v8/>. Tile size is 512.
     * Authentication is via query-string `access_token`, so [VectorSourceDescriptor.authenticator]
     * is left null.
     */
    private fun mapboxStreetsV8Descriptor(token: String): VectorSourceDescriptor =
        VectorSourceDescriptor(
            id = SOURCE_ID,
            url = "https://api.mapbox.com/v4/mapbox.mapbox-streets-v8/{z}/{x}/{y}.vector.pbf?access_token=$token",
            metadataUrl = "https://api.mapbox.com/v4/mapbox.mapbox-streets-v8.json?access_token=$token",
            tileSize = TileSize(512),
            authenticator = null,
        )
}
