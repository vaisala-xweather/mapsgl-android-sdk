package com.xweather.mapsgl.map.mapbox

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Bucketed pool of direct [FloatBuffer]s sharing memory with off-heap [java.nio.ByteBuffer]s.
 *
 * Long-lived stencil mesh vertex data used to live on the Java heap as `FloatArray`s. A
 * single Demo 3 motorway tile at high zoom emits hundreds of KB of vertex floats, and a
 * width-slider drag rebuilds dozens of those per second across the visible tile set. The
 * resulting Large Object Space (LOS) GC pressure was the dominant remaining source of
 * `Background concurrent copying GC` events in the steady-state render loop. Holding the
 * vertex data in pooled direct buffers achieves three things:
 *
 *  1. The bytes never enter the Java heap, so they don't participate in GC at all.
 *  2. The GPU upload (`glBufferData`) reads the same memory the builder wrote, removing the
 *     redundant `FloatArray -> direct ByteBuffer.put -> glBufferData` copy we used to do per
 *     VBO upload (see [GlStencilMaskRenderer.ensureCustomVbo]).
 *  3. Buffers are recycled across mesh rebuilds, so a steady width-slider drag amortises a
 *     handful of `allocateDirect` calls instead of one per tile per tick.
 *
 * ### Thread safety
 *
 * [acquire] runs on whichever worker coroutine is building meshes (`stencilMeshBuildScope`).
 * [releaseDeferred] is called from any thread when a [GlStencilMaskTileCache.CpuMesh] is
 * displaced. [drainDeferredReleases] **must** run on the GL render thread, and only after
 * the current frame has finished consuming any [GlStencilMaskTileCache.CpuMesh] references
 * it sourced from the cache.
 *
 * The two-phase release is essential: a cache mutation can race a render that just sampled
 * the soon-to-be-displaced mesh. Recycling the buffer immediately would let a parallel
 * worker `acquire` it and overwrite the bytes that the renderer is still reading. Holding
 * the released buffer in a queue until the GL thread is back at a frame boundary
 * (`ensureCurrentContext`) gives the renderer time to finish its read, and serialises the
 * actual recycling on a single thread.
 */
internal object DirectFloatBufferPool {
    /**
     * Bucket capacities (in floats). Sizes double from 256 floats (1 KB) up to 4 M floats
     * (16 MB). Smaller-than-256 meshes allocate fresh in the 256 bucket; larger-than-4M
     * meshes allocate ad-hoc and aren't pooled (they're rare and the bookkeeping wins fall
     * off quickly).
     */
    private val bucketSizes = intArrayOf(
        256,
        1_024,
        4_096,
        16_384,
        65_536,
        262_144,
        1_048_576,
        4_194_304,
    )

    /**
     * Default idle-buffer cap. The large buckets are tighter (see [bucketCap]) because a
     * single 16 MB buffer × 16 idle would be 256 MB of resident native memory, and on
     * 4 GB-class devices the kernel OOM-killer can claim the process before we ever see a
     * Java exception.
     */
    private const val DEFAULT_PER_BUCKET = 16

    /**
     * Per-bucket cap on idle buffers, indexed parallel to [bucketSizes]. Hand-tuned so the
     * total resident pool budget stays well under 100 MB even when every bucket is full:
     * the two biggest buckets (4 MB and 16 MB) are limited to a handful of entries each,
     * because a rebuild storm on Demo 3 doesn't actually need more than a couple of those
     * in flight at once.
     */
    private val bucketCap: IntArray = run {
        val caps = IntArray(bucketSizes.size) { DEFAULT_PER_BUCKET }
        // 1 MB bucket (262_144 floats): keep larger pool — Demo 3 ribbons land here on
        // typical motorway tiles, so reuse matters most.
        // 4 MB bucket (1_048_576 floats): cap at 8 (32 MB resident).
        // 16 MB bucket (4_194_304 floats): cap at 4 (64 MB resident).
        caps[6] = 8
        caps[7] = 4
        caps
    }

    private val pools: Array<ConcurrentLinkedDeque<FloatBuffer>> =
        Array(bucketSizes.size) { ConcurrentLinkedDeque() }

    private val deferredReleases = ConcurrentLinkedQueue<FloatBuffer>()

    private fun bucketIndex(floatCount: Int): Int {
        // Smallest bucket >= floatCount; -1 if larger than the largest bucket.
        for (i in bucketSizes.indices) {
            if (bucketSizes[i] >= floatCount) return i
        }
        return -1
    }

    /**
     * Returns a direct [FloatBuffer] with `position=0`, `limit=floatCount`, and `capacity` at
     * least [floatCount]. Native order; native memory. The buffer's contents are undefined
     * (recycled buffers carry whatever bytes the previous owner wrote).
     */
    fun acquire(floatCount: Int): FloatBuffer {
        require(floatCount >= 0) { "floatCount must be non-negative, was $floatCount" }
        val idx = bucketIndex(floatCount)
        if (idx < 0) {
            return ByteBuffer
                .allocateDirect(floatCount * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
                .apply {
                    limit(floatCount)
                    position(0)
                }
        }
        val capFloats = bucketSizes[idx]
        val pooled = pools[idx].pollFirst()
        val fb = pooled ?: ByteBuffer
            .allocateDirect(capFloats * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
        fb.limit(floatCount)
        fb.position(0)
        return fb
    }

    /**
     * Returns [buf] to the pool immediately. Caller must guarantee no other thread is still
     * reading from the buffer. Almost all stencil-mesh callers should use [releaseDeferred]
     * to avoid racing with a concurrent renderer; this overload is for build-time scratch
     * buffers whose lifetime never escapes a single worker.
     *
     * No-op when [buf] is null or its capacity doesn't match a known bucket. Also a no-op
     * — but logs a warning — when [buf] is already present in the pool, which would
     * otherwise produce a double-release: two `acquire`s could hand the same direct buffer
     * to parallel workers, and the resulting overwrite of vertex bytes would corrupt the
     * data right under a concurrent `glBufferData` upload (or worse, blow up with a
     * `position > limit` after one of the workers calls `clear()`).
     */
    fun release(buf: FloatBuffer?) {
        if (buf == null) return
        val capacity = buf.capacity()
        var idx = -1
        for (i in bucketSizes.indices) {
            if (bucketSizes[i] == capacity) {
                idx = i
                break
            }
        }
        if (idx < 0) return
        val pool = pools[idx]
        // Identity-based duplicate detection. `ConcurrentLinkedDeque.contains` walks the
        // list with `equals`, but for `FloatBuffer` that's content equality (expensive on
        // every release) — so we re-do the scan ourselves with `===`. The pool is capped
        // at ~16 entries per bucket, so this is at most ~16 reference comparisons per
        // release.
        for (existing in pool) {
            if (existing === buf) {
                android.util.Log.w(
                    "DirectFloatBufferPool",
                    "double release detected for buffer @${System.identityHashCode(buf)} " +
                        "(capacity=$capacity floats); ignoring",
                )
                return
            }
        }
        val cap = bucketCap[idx]
        // `ConcurrentLinkedDeque.size` is O(n); the cap is small (≤ DEFAULT_PER_BUCKET) so
        // this is cheap, but it's the steady-state hot path so a strict size check matters.
        // Letting the pool grow unbounded would not just defeat the recycling — for the
        // large buckets it would also OOM the device.
        if (pool.size >= cap) return
        buf.clear() // resets position=0, limit=capacity, mark=-1
        pool.offerFirst(buf)
    }

    /**
     * Queues [buf] for release at the next GL-thread drain. Safe to call from any thread.
     *
     * This is the right entry point for releasing a [GlStencilMaskTileCache.CpuMesh] that
     * was displaced from the tile cache: a renderer running concurrently may have just
     * sampled that mesh and be on its way to `glBufferData`; queueing the buffer here gives
     * it time to finish.
     */
    fun releaseDeferred(buf: FloatBuffer?) {
        if (buf == null) return
        deferredReleases.offer(buf)
    }

    /**
     * Recycles every buffer queued via [releaseDeferred] since the last drain. Must run on
     * the GL render thread, between frames, so no concurrent GL read can be staring at one
     * of the buffers being recycled.
     */
    fun drainDeferredReleases() {
        while (true) {
            val buf = deferredReleases.poll() ?: break
            release(buf)
        }
    }

    /**
     * Drops every pooled buffer. Use when the EGL context is torn down or the activity
     * exits — the buffer views may still be valid Java objects, but a fresh GL context will
     * never reuse them and clinging to 100+ MB of native memory across activity restarts
     * regresses Demo 5 navigation back to the OOMs we fixed earlier.
     */
    fun trim() {
        deferredReleases.clear()
        for (p in pools) p.clear()
    }
}
