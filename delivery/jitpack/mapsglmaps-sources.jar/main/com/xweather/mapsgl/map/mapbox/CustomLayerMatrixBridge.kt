package com.xweather.mapsgl.map.mapbox

import com.mapbox.maps.CustomLayerRenderParameters

/**
 * Pushes Mapbox native projection / model matrices into [CameraSync] for custom GL in
 * [com.mapbox.maps.CustomLayerHost] (same clip space as Mapbox layers).
 *
 * Mapbox Maps **11+** exposes [CustomLayerRenderParameters.projectionMatrix] as
 * `List<Double>` and the view/model as [com.mapbox.maps.CustomLayerMapProjection.getModelMatrix].
 * Older types (`DoubleArray`, etc.) are still supported via reflection fallback.
 */
internal object CustomLayerMatrixBridge {

    private val projectionCandidates = listOf(
        "projectionMatrix",
        "projection",
        "nativeProjectionMatrix",
    )
    private val modelViewCandidates = listOf(
        "modelViewMatrix",
        "modelviewMatrix",
        "nativeModelViewMatrix",
    )

    fun pushToCameraSync(parameters: CustomLayerRenderParameters) {
        CameraSync.customLayerRenderZoom = parameters.zoom
        CameraSync.lastCustomLayerRenderZoom = parameters.zoom
        val proj = matrixListToFloatArray(parameters.projectionMatrix)
            ?: extractMatrix16(parameters, projectionCandidates)
        val model = matrixListToFloatArray(parameters.projection.getModelMatrix())
            ?: extractMatrix16(parameters, modelViewCandidates)
        CameraSync.mapboxProjectionMatrix = proj
        CameraSync.mapboxModelViewMatrix = model
    }

    fun clearCameraSync() {
        CameraSync.customLayerRenderZoom = null
        CameraSync.mapboxProjectionMatrix = null
        CameraSync.mapboxModelViewMatrix = null
    }

    private fun matrixListToFloatArray(list: List<Double>?): FloatArray? {
        if (list == null || list.size < 16) return null
        return FloatArray(16) { i -> list[i].toFloat() }
    }

    private fun extractMatrix16(parameters: CustomLayerRenderParameters, names: List<String>): FloatArray? {
        val cls = parameters.javaClass
        for (name in names) {
            val getter = "get${name.replaceFirstChar { it.uppercaseChar() }}"
            val m = runCatching { cls.getMethod(getter).invoke(parameters) }.getOrNull()
                ?: runCatching {
                    cls.methods.firstOrNull { it.name == getter && it.parameterCount == 0 }?.invoke(parameters)
                }.getOrNull()
            when (m) {
                is DoubleArray -> if (m.size >= 16) return FloatArray(16) { i -> m[i].toFloat() } else continue
                is FloatArray -> if (m.size >= 16) return m.copyOf(16) else continue
                is List<*> -> {
                    @Suppress("UNCHECKED_CAST")
                    val doubles = m as? List<Double> ?: continue
                    matrixListToFloatArray(doubles)?.let { return it }
                }

                else -> continue
            }
        }
        return null
    }
}
