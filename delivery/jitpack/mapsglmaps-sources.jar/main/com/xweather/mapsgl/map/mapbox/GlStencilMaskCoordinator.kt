package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.util.MapsGLDebug

import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.weather.WeatherService
import java.util.EnumMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/**
 * Registers lightweight [DataSourceConsumer]s on [GlStencilOsm.SOURCE_ID] (same MVT as `base.osm`) so
 * mask layers are parsed, and feeds
 * [MapController.glStencilMaskTileCache] from parsed tiles (JS-style data path; drawing is GLES stencil).
 */
internal object GlStencilMaskCoordinator {

    private val refCounts: EnumMap<MaskLayerKind, AtomicInteger> =
        EnumMap(MaskLayerKind::class.java)

    private val controllerRegistrations =
        ConcurrentHashMap<MapController, MutableSet<MaskLayerKind>>()

    /** Marine [MaskLayerKind.LAND] GLES stencil uses raw `water` polygons only (no runtime inversion). */
    private val landConsumer = DataSourceConsumer("__maps_gl_stencil_mask_land", "water")
    private val waterConsumer = DataSourceConsumer("__maps_gl_stencil_mask_water", "water")

    /** All road / path line features in the MVT `transportation` layer (no class filter). */
    private val transportationConsumer =
        DataSourceConsumer("__maps_gl_stencil_mask_transportation", "transportation")

    /** Mapbox Streets `admin`; MapsGL OSM `boundary`. */
    private val countryConsumerMapbox =
        DataSourceConsumer("__maps_gl_stencil_mask_country_mapbox", "admin")
    private val countryConsumerMapsgl =
        DataSourceConsumer("__maps_gl_stencil_mask_country_mapsgl", "boundary")

    /** Registrations per normalized ISO alpha-2 (e.g. US, ES). */
    private val countryIsoRegistrationCount = ConcurrentHashMap<String, AtomicInteger>()

    init {
        for (k in MaskLayerKind.entries) {
            refCounts[k] = AtomicInteger(0)
        }
    }

    /**
     * Called from each new [MapController] after [com.xweather.mapsgl.anim.Timeline.resetForNewController].
     * Clears leaked process-wide ref counts and GL handles when the prior activity's controller did
     * not unregister cleanly (Demo 2 land mask → Demo 3 water mask is the common case).
     */
    fun prepareForNewMapController() {
        // Each activity gets a new MapController. Release any controller that did not tear
        // down cleanly before clearing registrations (Demo 2 land → Demo 3 water).
        val survivors = controllerRegistrations.keys.toList()
        for (controller in survivors) {
            releaseAllForController(controller, controller.service)
        }
        controllerRegistrations.clear()
        for (k in MaskLayerKind.entries) {
            refCounts[k]?.set(0)
        }
        countryIsoRegistrationCount.clear()
        // Keep [GlStencilOsm.lastWiredSource] so the next activity can detect MAPBOX ↔ MAPSGL switches.
        GlStencilMaskRendererHolder.renderer.onContextLost()
    }

    internal fun activeCountryIsoCodes(): Set<String> =
        countryIsoRegistrationCount.filterValues { it.get() > 0 }.keys

    private fun countryBoundaryConsumer(): DataSourceConsumer =
        if (GlStencilOsm.source == GlStencilOsm.Source.MAPBOX) countryConsumerMapbox else countryConsumerMapsgl

    fun ensureBaseOsmMaskConsumer(
        controller: MapController,
        service: WeatherService,
        kind: MaskLayerKind,
        countryIso3166Alpha2: String? = null,
    ) {
        if (kind == MaskLayerKind.NONE) return

        if (kind == MaskLayerKind.COUNTRY) {
            val iso = GlStencilCountryMask.normalizeIso(countryIso3166Alpha2)
            if (iso == null) {
                MapsGLDebug.trace(
                    "[GlStencilMask] COUNTRY mask requires maskCountryIso3166Alpha2 (e.g. \"US\", \"ES\")",
                )
                return
            }
            val layerCnt = refCounts[kind]!!.incrementAndGet()
            countryIsoRegistrationCount.computeIfAbsent(iso) { AtomicInteger(0) }.incrementAndGet()

            val sourceDesc = GlStencilOsm.sourceDescriptor(service)
            if (!controller.hasSource(sourceDesc.id)) {
                controller.addSource(sourceDesc)
            }
            val src = controller.getSource(sourceDesc.id) as? VectorTileSource
            if (src == null) {
                refCounts[kind]!!.decrementAndGet()
                val left = countryIsoRegistrationCount[iso]!!.decrementAndGet()
                if (left <= 0) countryIsoRegistrationCount.remove(iso)
                MapsGLDebug.trace(
                    "[GlStencilMask] ensureBaseOsmMaskConsumer: ${sourceDesc.id} is not a VectorTileSource; country stencil cache will stay empty",
                )
                return
            }
            if (layerCnt == 1) {
                src.addConsumer(countryBoundaryConsumer())
                src.glStencilMaskTileListener = { coord, coordHash, features ->
                    controller.glStencilMaskTileCache.putFromFeatures(coord, coordHash, features)
                }
                src.replayGlStencilFeedsFromCachedVectorTiles()
                src.invalidate()
                (controller as? MapboxMapController)?.ensureGlStencilBaseOsmFetchLayer()
            } else {
                src.invalidate()
            }
            return
        }

        val cnt = refCounts[kind]!!.incrementAndGet()
        controllerRegistrations.computeIfAbsent(controller) { ConcurrentHashMap.newKeySet() }.add(kind)

        val sourceDesc = GlStencilOsm.sourceDescriptor(service)
        if (!controller.hasSource(sourceDesc.id)) {
            controller.addSource(sourceDesc)
        }
        val src = controller.getSource(sourceDesc.id) as? VectorTileSource
        (controller as? MapboxMapController)?.let { mc ->
            if (GlStencilOsm.lastWiredSource != null && GlStencilOsm.lastWiredSource != GlStencilOsm.source) {
                mc.dropStaleGlStencilOsmStyleSource(src)
                controller.glStencilMaskTileCache.clearAll()
            }
        }
        if (src == null) {
            refCounts[kind]!!.decrementAndGet()
            controllerRegistrations[controller]?.remove(kind)
            MapsGLDebug.trace(
                "[GlStencilMask] ensureBaseOsmMaskConsumer: ${sourceDesc.id} is not a VectorTileSource; land/water stencil cache will stay empty",
            )
            return
        }
        val consumer = when (kind) {
            MaskLayerKind.NONE -> return
            MaskLayerKind.LAND -> landConsumer
            MaskLayerKind.WATER -> waterConsumer
            MaskLayerKind.TRANSPORTATION -> transportationConsumer
            MaskLayerKind.COUNTRY -> return
        }
        if (!src.consumers.any { it.layerId == consumer.layerId }) {
            src.addConsumer(consumer)
        }
        // Always bind the listener to this controller's cache (process-wide ref counts can skip
        // the cnt==1 path when switching demo activities).
        src.glStencilMaskTileListener = { coord, coordHash, features ->
            controller.glStencilMaskTileCache.putFromFeatures(coord, coordHash, features)
        }
        src.invalidate()
        (controller as? MapboxMapController)?.let { mc ->
            mc.ensureGlStencilOsmSourceWired {
                src.invalidate()
                mc.requestRepaintCoalesced()
            }
        }
    }

    fun releaseAllForController(controller: MapController, service: WeatherService) {
        val kinds = controllerRegistrations.remove(controller)?.toList() ?: return
        for (kind in kinds) {
            releaseLandWaterTransportConsumer(controller, service, kind)
        }
    }

    private fun releaseLandWaterTransportConsumer(
        controller: MapController,
        service: WeatherService,
        kind: MaskLayerKind,
    ) {
        val left = refCounts[kind]!!.decrementAndGet()
        if (left > 0) return
        val sourceDesc = GlStencilOsm.sourceDescriptor(service)
        val src = controller.getSource(sourceDesc.id) as? VectorTileSource ?: return
        val layerId = when (kind) {
            MaskLayerKind.LAND -> landConsumer.layerId
            MaskLayerKind.WATER -> waterConsumer.layerId
            MaskLayerKind.TRANSPORTATION -> transportationConsumer.layerId
            else -> return
        }
        src.removeConsumer(layerId)
        if (refCounts.values.all { it.get() == 0 }) {
            src.glStencilMaskTileListener = null
        }
        controller.glStencilMaskTileCache.clearKind(kind)
        releaseGpuResourcesSafelyIfIdle()
        if (refCounts.values.all { it.get() == 0 }) {
            (controller as? MapboxMapController)?.removeGlStencilBaseOsmFetchLayer()
        }
    }

    /**
     * Drop cached GL handles without calling `glDelete*` off the render thread.
     * Only when no mask kind is registered — releasing LAND while WATER is active on another
     * screen must not wipe the shared renderer (Demo 2 → Demo 3).
     */
    private fun releaseGpuResourcesSafelyIfIdle() {
        if (refCounts.values.all { it.get() == 0 }) {
            GlStencilMaskRendererHolder.renderer.onContextLost()
        }
    }

    fun releaseBaseOsmMaskConsumer(
        controller: MapController,
        service: WeatherService,
        kind: MaskLayerKind,
        countryIso3166Alpha2: String? = null,
    ) {
        if (kind == MaskLayerKind.NONE) return

        if (kind == MaskLayerKind.COUNTRY) {
            val iso = GlStencilCountryMask.normalizeIso(countryIso3166Alpha2) ?: return
            val leftTotal = refCounts[kind]!!.decrementAndGet()
            val ctr = countryIsoRegistrationCount[iso] ?: run {
                refCounts[kind]!!.incrementAndGet()
                return
            }
            val leftIso = ctr.decrementAndGet()
            if (leftIso <= 0) countryIsoRegistrationCount.remove(iso)
            if (leftTotal > 0) {
                controller.glStencilMaskTileCache.clearCountryIso(iso)
            }
            releaseGpuResourcesSafelyIfIdle()
            if (leftTotal > 0) return
            val sourceDesc = GlStencilOsm.sourceDescriptor(service)
            val src = controller.getSource(sourceDesc.id) as? VectorTileSource ?: return
            src.removeConsumer(countryBoundaryConsumer().layerId)
            if (refCounts.values.all { it.get() == 0 }) {
                src.glStencilMaskTileListener = null
            }
            controller.glStencilMaskTileCache.clearKind(MaskLayerKind.COUNTRY)
            if (refCounts.values.all { it.get() == 0 }) {
                (controller as? MapboxMapController)?.removeGlStencilBaseOsmFetchLayer()
            }
            return
        }

        val registeredKinds = controllerRegistrations[controller] ?: return
        if (!registeredKinds.remove(kind)) {
            return
        }
        releaseLandWaterTransportConsumer(controller, service, kind)
    }
}

internal object GlStencilMaskRendererHolder {
    val renderer = GlStencilMaskRenderer()
}
