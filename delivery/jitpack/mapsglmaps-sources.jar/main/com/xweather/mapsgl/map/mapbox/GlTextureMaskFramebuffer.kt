package com.xweather.mapsgl.map.mapbox

import android.opengl.GLES31

/**
 * Single-channel (R8) viewport-sized framebuffer used as the JS-style `tMask` render target.
 * Includes an 8-bit stencil attachment for sequential ALL (intersection) mask builds.
 */
internal class GlTextureMaskFramebuffer {

    private var textureId = 0
    private var fboId = 0
    private var stencilRbId = 0
    private var width = 0
    private var height = 0

    fun matchesSize(w: Int, h: Int): Boolean = w == width && h == height && fboId != 0

    fun colorTextureId(): Int = textureId

    fun ensureSize(viewportWidth: Int, viewportHeight: Int) {
        if (viewportWidth < 1 || viewportHeight < 1) return
        if (matchesSize(viewportWidth, viewportHeight)) return
        release()
        width = viewportWidth
        height = viewportHeight

        val tex = IntArray(1)
        GLES31.glGenTextures(1, tex, 0)
        textureId = tex[0]
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureId)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D,
            0,
            GLES31.GL_R8,
            width,
            height,
            0,
            GLES31.GL_RED,
            GLES31.GL_UNSIGNED_BYTE,
            null,
        )

        val rb = IntArray(1)
        GLES31.glGenRenderbuffers(1, rb, 0)
        stencilRbId = rb[0]
        GLES31.glBindRenderbuffer(GLES31.GL_RENDERBUFFER, stencilRbId)
        GLES31.glRenderbufferStorage(
            GLES31.GL_RENDERBUFFER,
            GLES31.GL_STENCIL_INDEX8,
            width,
            height,
        )

        val fbo = IntArray(1)
        GLES31.glGenFramebuffers(1, fbo, 0)
        fboId = fbo[0]
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, fboId)
        GLES31.glFramebufferTexture2D(
            GLES31.GL_FRAMEBUFFER,
            GLES31.GL_COLOR_ATTACHMENT0,
            GLES31.GL_TEXTURE_2D,
            textureId,
            0,
        )
        GLES31.glFramebufferRenderbuffer(
            GLES31.GL_FRAMEBUFFER,
            GLES31.GL_STENCIL_ATTACHMENT,
            GLES31.GL_RENDERBUFFER,
            stencilRbId,
        )
        val status = GLES31.glCheckFramebufferStatus(GLES31.GL_FRAMEBUFFER)
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0)
        GLES31.glBindRenderbuffer(GLES31.GL_RENDERBUFFER, 0)
        if (status != GLES31.GL_FRAMEBUFFER_COMPLETE) {
            release()
        }
    }

    /** Binds this FBO and sets viewport to [width]×[height]. Returns previously bound FBO id. */
    fun bind(): Int {
        val prev = IntArray(1)
        GLES31.glGetIntegerv(GLES31.GL_FRAMEBUFFER_BINDING, prev, 0)
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, fboId)
        GLES31.glViewport(0, 0, width, height)
        return prev[0]
    }

    fun unbind(previousFramebuffer: Int) {
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, previousFramebuffer)
    }

    fun release() {
        if (textureId != 0) {
            GLES31.glDeleteTextures(1, intArrayOf(textureId), 0)
            textureId = 0
        }
        if (stencilRbId != 0) {
            GLES31.glDeleteRenderbuffers(1, intArrayOf(stencilRbId), 0)
            stencilRbId = 0
        }
        if (fboId != 0) {
            GLES31.glDeleteFramebuffers(1, intArrayOf(fboId), 0)
            fboId = 0
        }
        width = 0
        height = 0
    }
}
