package com.xweather.mapsgl.utils

import com.xweather.mapsgl.gl.extensions.pr
import java.util.*
import kotlin.collections.HashMap

/**
 * Adapted from js version which was adapted from Lumo: https://github.com/unchartedsoftware/lumo
 * Copyright (c) 2016-2019 Uncharted Software Inc.
 * Copyrights licensed under the MIT License.
 **/

// LRUCache via LinkedList
// https://medium.com/dsinjs/implementing-lru-cache-in-javascript-94ba6755cda9
// https://github.com/Brokerloop/ttlcache/blob/master/src/index.ts
// https://dev.to/glebirovich/typescript-data-structures-linked-list-3o8i


interface Entry<String, V> {
    val key: String
    var value: V
    var expiration: Long
    var node: LinkedListNode<Entry<String, V>>?
}

interface LRUCacheConfig<String, V> {
    val capacity: Int
    val ttl: Long
    val onRemove: ((key: String, value: V) -> Unit)?
}

class LinkedListNode<T>(var value: T) {
    var prev: LinkedListNode<T>? = null
    var next: LinkedListNode<T>? = null
}

class LinkedList<T> {
    var head: LinkedListNode<T>? = null
    var tail: LinkedListNode<T>? = null

    fun unshift(value: T): LinkedListNode<T> {
        val newNode = LinkedListNode(value)
        if (head == null) {
            head = newNode
            tail = newNode
        } else {
            newNode.next = head
            head?.prev = newNode
            head = newNode
        }
        return newNode
    }

    fun unshiftNode(node: LinkedListNode<T>) {
        removeNode(node)
        node.next = head
        head?.prev = node
        head = node
        if (tail == null) {
            tail = node;
        }
    }

    fun pop(): T {
        if (tail == null) {
            throw EmptyStackException()
        }

        val value = tail!!.value;
        removeNode(tail!!)
        return value
    }

    fun removeNode(node: LinkedListNode<T>) {
        if (node == head) {
            head = node.next
        }
        if (node == tail) {
            tail = node.prev
        }

        node.prev?.next = node.next
        node.next?.prev = node.prev

        node.next = null
        node.prev = null
    }


    fun clear() {
        head = null
        tail = null
    }


    fun items(): Sequence<LinkedListNode<T>> {
        return sequence {
            var current = head
            while (current != null) {
                yield(current)
                current = current.next
            }
        }
    }
}

/*
*     val capacity: Int
    val ttl: Long
    val onRemove: ((key: K, value: V) -> Unit)?
* */

/**
 * Internally synchronized LRU map.
 *
 * Every public read or write takes [lock] for the duration of the operation, so callers can
 * touch the cache from any thread without external locking. This is important for
 * [com.xweather.mapsgl.sources.VectorTileSource]'s tile cache, which is read from the main
 * thread (e.g. `refreshCustomStencilMask` → `replayCustomStencilFeedsFromCachedVectorTiles`) at
 * the same time tile-parse worker coroutines call `get`/`set`/`delete` from background threads.
 *
 * History: the cache used to be lock-free, with iteration via `_list.items().map { ... }` — a lazy
 * Sequence that walks `current.next` pointers in the LRU's doubly-linked list. Any concurrent
 * `get` mutated those pointers (via `_bumpAge` → `_list.unshiftNode`), so the iterator's `.next`
 * pointed back into already-visited territory and `.toList()` / `.count()` looped forever. We
 * patched the obvious freezes by snapshotting up front with `.toList()`, but the snapshot itself
 * is the same lazy walk: a background tile-parse `get` mid-snapshot would re-trigger the same
 * infinite loop — `.toList()` keeps `add()`ing to its `ArrayList`, growing it until the heap is
 * exhausted (we observed an OOM trying to allocate 118 MB in
 * `replayCustomStencilFeedsFromCachedVectorTiles`'s `.toList()`).
 *
 * The fix is to actually make the cache thread-safe rather than try to defend against the data
 * race at every call site. All mutators and iteration helpers now build their results under
 * [lock]; the iteration helpers return *eagerly materialised* snapshots, so the returned
 * `Sequence` no longer touches `_list` after we release the lock. The `_cache.values`-based
 * iteration also doesn't depend on `.next` pointers, so it's robust against the LRU-order
 * shuffling that broke the linked-list walk.
 */
class LRUCache<String, V>(
    var capacity: Int,
    val ttl: Long,
    val onRemove: ((key: String, value: V) -> Unit)?,
) : MutableMap<String, V> {
    private val _cache: MutableMap<String, LinkedListNode<Entry<String, V>>> = HashMap()
    private val _list: LinkedList<Entry<String, V>> = LinkedList()

    /**
     * Single monitor protecting [_cache] and [_list]. Held briefly by every public read and write.
     * Re-entrant on the same thread, so callbacks like [onRemove] are free to call back into the
     * cache without deadlocking.
     */
    private val lock = Any()

    override val entries: MutableSet<MutableMap.MutableEntry<String, V>>
        get() = synchronized(lock) {
            val snap = LinkedHashSet<MutableMap.MutableEntry<String, V>>(_cache.size)
            for ((k, node) in _cache) {
                val entry = node.value
                snap.add(object : MutableMap.MutableEntry<String, V> {
                    override val key: String = k
                    override var value: V = entry.value
                    override fun setValue(newValue: V): V {
                        val oldValue = value
                        value = newValue
                        return oldValue
                    }
                })
            }
            snap
        }


    override val keys: MutableSet<String>
        get() = synchronized(lock) { HashSet(_cache.keys) }

    override val size: Int
        get() = synchronized(lock) { _cache.size }
    override val values: MutableCollection<V>
        get() = synchronized(lock) {
            val snap = ArrayList<V>(_cache.size)
            for (node in _cache.values) snap.add(node.value.value)
            snap
        }

    val cache: Map<String, LinkedListNode<Entry<String, V>>>
        get() = _cache

    val first: V?
        get() = synchronized(lock) { _list.head?.value?.value }

    val last: V?
        get() = synchronized(lock) { _list.tail?.value?.value }

    /**
     * Eagerly snapshots all keys under [lock] and returns a sequence over the snapshot. The
     * returned sequence does NOT touch the live LRU after this call returns, so callers can
     * iterate without holding the lock and without risking the linked-list `.next` infinite loop
     * that the old lazy `_list.items()` sequence had.
     */
    fun keys(): Sequence<String> {
        val snap: List<String> = synchronized(lock) { ArrayList(_cache.keys) }
        return snap.asSequence()
    }

    /** Like [keys] but for values. See [keys] for the snapshot rationale. */
    fun values(): Sequence<V> {
        val snap: List<V> = synchronized(lock) {
            val out = ArrayList<V>(_cache.size)
            for (node in _cache.values) out.add(node.value.value)
            out
        }
        return snap.asSequence()
    }

    /** Like [keys] but for `(key, value)` pairs. See [keys] for the snapshot rationale. */
    fun entries(): Sequence<Pair<String, V>> {
        val snap: List<Pair<String, V>> = synchronized(lock) {
            val out = ArrayList<Pair<String, V>>(_cache.size)
            for ((k, node) in _cache) out.add(Pair(k, node.value.value))
            out
        }
        return snap.asSequence()
    }

    init {
        this.capacity = Math.max(1, capacity)
    }

    fun has(key: String): Boolean = synchronized(lock) { _cache.containsKey(key) }

    override fun get(key: String): V? = synchronized(lock) {
        val node = _cache[key]
        if (node == null) {
            null
        } else if (_isExpired(node.value)) {
            if (pr.ON) pr.p("LRU", pr.lruDelete, "get() deleting ${node.value.key}")
            null
        } else {
            _bumpAge(node.value)
            node.value.value
        }
    }

    fun peek(key: String): V? = synchronized(lock) { _cache[key]?.value?.value }

    operator fun set(key: String, value: V) {
        synchronized(lock) {
            val existingNode = _cache[key]

            if (existingNode != null) {
                val entry = existingNode.value
                if (entry.value != value) {
                    onRemove?.invoke(entry.key, entry.value)
                    entry.value = value
                }
                _bumpAge(entry)
            } else {
                val entry = object : Entry<String, V> {
                    override val key: String = key
                    override var value: V = value
                    override var expiration: Long = Date().time + ttl
                    override var node: LinkedListNode<Entry<String, V>>? = null
                }

                val node = _list.unshift(entry)
                _cache[key] = node
                entry.node = node

                if (_cache.size > capacity) {
                    val nodeToEvict = _list.pop()
                    if (pr.ON) pr.p("LRU", pr.lruDelete, "evict() ${nodeToEvict.key}")
                }
            }
        }
    }

    fun delete(key: String): V? = synchronized(lock) {
        val node = _cache[key]
        if (node == null) {
            null
        } else {
            val entry = node.value
            if (pr.ON) pr.p("LRU", pr.lruDelete, "delete() ${entry.key}")
            onRemove?.invoke(entry.key, entry.value)
            _cache.remove(key)
            _list.removeNode(node)
            entry.value
        }
    }

    override fun clear() {
        synchronized(lock) {
            for (node in _cache.values) {
                val entry = node.value
                onRemove?.invoke(entry.key, entry.value)
            }
            _cache.clear()
            _list.clear()
        }
    }

    override fun isEmpty(): Boolean = synchronized(lock) { _cache.isEmpty() }

    override fun remove(key: String): V? = delete(key)

    override fun putAll(from: Map<out String, V>) {
        synchronized(lock) {
            for ((key, value) in from) {
                set(key, value)
            }
        }
    }

    override fun put(key: String, value: V): V? = synchronized(lock) {
        val existingNode = _cache[key]
        val oldValue = if (existingNode != null && !_isExpired(existingNode.value)) {
            existingNode.value.value
        } else {
            null
        }
        set(key, value)
        oldValue
    }

    override fun containsValue(value: V): Boolean {
        TODO("Not yet implemented")
    }

    override fun containsKey(key: String): Boolean = synchronized(lock) { _cache.containsKey(key) }

    fun forEach(fn: (entry: Entry<String, V>) -> Unit) {
        // Snapshot the entries before invoking [fn] so callbacks can safely re-enter the cache
        // (and so iteration can't be derailed by a concurrent mutation). `_cache.values` is a
        // `HashMap.values` view, which is not safe to iterate under concurrent mutation — copy
        // the node references out under the lock first.
        val nodes: List<LinkedListNode<Entry<String, V>>> = synchronized(lock) {
            ArrayList(_cache.values)
        }
        for (node in nodes) fn(node.value)
    }

    private fun _bumpAge(entry: Entry<String, V>) {
        entry.expiration = Date().time + ttl
        entry.node?.let { _list.unshiftNode(it) }
    }

    private fun _isExpired(entry: Entry<String, V>): Boolean {
        return if (ttl > 0) {
            entry.expiration < Date().time
        } else false
    }
}