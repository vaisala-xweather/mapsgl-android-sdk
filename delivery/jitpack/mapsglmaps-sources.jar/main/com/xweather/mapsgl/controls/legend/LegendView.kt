package com.xweather.mapsgl.controls.legend

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.compose.ui.graphics.toArgb
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.Point.PointLegendView
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegendView

/**
 * A custom Android View that displays a legend, built entirely programmatically without XML.
 *
 * This version creates and arranges all its child views (TextView, ScrollView) in code.
 * It handles displaying a title and a scrollable content area.
 */
class LegendView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    private lateinit var titleLabel: TextView
    private lateinit var scrollView: ScrollView
    private lateinit var contentContainer: FrameLayout

    var legend: Legend? = null
        private set

    val legendId: String?
        get() = legend?.id

    /**
     * Maximum height (dp) of the scrollable legend body. Set from [LegendControl.maxLegendContentHeightDp]
     * or per-view before [setLegend]. Use a large value (e.g. 10_000) to effectively disable scrolling.
     */
    var maxContentHeightDp: Int = DEFAULT_MAX_LEGEND_CONTENT_HEIGHT_DP
        set(value) {
            field = value.coerceAtLeast(0)
            applyScrollMaxHeightPx()
        }

    companion object {
        const val DEFAULT_MAX_LEGEND_CONTENT_HEIGHT_DP = 100
    }

    init {
        // This LinearLayout will be the root, arranged vertically.
        orientation = VERTICAL
        setupViews()
    }

    /**
     * Creates, configures, and adds all child views to this layout.
     */
    private fun setupViews() {
        // 1. Create the Title TextView
        titleLabel = TextView(context).apply {
            // Define layout parameters
            val params = MarginLayoutParams(
                MarginLayoutParams.MATCH_PARENT,
                MarginLayoutParams.WRAP_CONTENT
            )
            // Margins can be set here if needed (e.g., params.setMargins(...))
            layoutParams = params
        }
        addView(titleLabel) // Add title to the LinearLayout

        // 2. Create the ScrollView
        scrollView =
            ConstrainedScrollView(context).apply {
                isVerticalFadingEdgeEnabled = true
                setFadingEdgeLength((16 * resources.displayMetrics.density).toInt())
                isVerticalScrollBarEnabled = true

                val params = MarginLayoutParams(
                    MarginLayoutParams.MATCH_PARENT,
                    MarginLayoutParams.WRAP_CONTENT,
                ).apply {
                    topMargin = (4 * resources.displayMetrics.density).toInt()
                }
                layoutParams = params
            }
        applyScrollMaxHeightPx()

        // 3. Create the container that goes inside the ScrollView
        contentContainer = FrameLayout(context).apply {
            layoutParams = FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT
            )
            descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            isClickable = false
        }

        // Add the container to the ScrollView, then add the ScrollView to the root LinearLayout
        scrollView.addView(contentContainer)
        addView(scrollView)
    }

    /**
     * Sets or replaces the legend data and rebuilds the content view.
     */
    fun setLegend(newLegend: Legend) {
        this.legend = newLegend
        val title = newLegend.title
        titleLabel.text = title
        titleLabel.visibility = if (title.isNullOrBlank()) View.GONE else View.VISIBLE
        titleLabel.textSize = newLegend.titleFontSize.value
        titleLabel.setTextColor(newLegend.titleColorValue.toArgb())
        titleLabel.typeface = android.graphics.Typeface.create(
            titleLabel.typeface, // Start with the current typeface
            LegendDefaults.titleFontWeight.weight,          // Apply the numerical weight
            false                // 'false' for not italic
        )

        titleLabel.setTextSize(
            android.util.TypedValue.COMPLEX_UNIT_SP,
            newLegend.titleFontSize.value
        )


        // Remove any old content from the container
        val legendContentView = buildLegendContentView(newLegend)
        if (legendContentView != null) {
            contentContainer.removeAllViews()
            contentContainer.removeView(legendContentView)
            contentContainer.addView(legendContentView)
        }
    }

    /**
     * Factory function to create the specific legend content view.
     */
    private fun buildLegendContentView(legend: Legend): View? {
        return when (legend) {
            is BarLegend<*> -> {
                BarLegendView(context).apply {
                    setLegend(legend)
                }
            }

            is PointLegend -> {
                val pointLegendView = PointLegendView(context).apply {
                    this.legend = legend as PointLegend
                }

                titleLabel.text = legend.title
                titleLabel.setTextColor(legend.titleColorValue.toArgb())

                titleLabel.typeface = android.graphics.Typeface.create(
                    titleLabel.typeface, // Start with the current typeface
                    LegendDefaults.titleFontWeight.weight,          // Apply the numerical weight
                    false                // 'false' for not italic
                )

                contentContainer.removeAllViews()
                contentContainer.addView(pointLegendView)
                pointLegendView
            }
            // Add other 'when' branches for different legend types if needed
            else -> null
        }

    }

    private fun applyScrollMaxHeightPx() {
        val scroll = scrollView as? ConstrainedScrollView ?: return
        scroll.mxHeight = if (maxContentHeightDp > 0) {
            (maxContentHeightDp * resources.displayMetrics.density).toInt()
        } else {
            -1
        }
        scroll.requestLayout()
    }

    private class ConstrainedScrollView(context: Context) : ScrollView(context) {
        var mxHeight: Int = -1

        init {
            // tell the view not to act as a touch target if not scrollable
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }

        override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
            var newHeightMeasureSpec = heightMeasureSpec
            if (mxHeight > 0) {
                newHeightMeasureSpec = MeasureSpec.makeMeasureSpec(mxHeight, MeasureSpec.AT_MOST)
            }
            super.onMeasure(widthMeasureSpec, newHeightMeasureSpec)
        }

        override fun onInterceptTouchEvent(ev: android.view.MotionEvent): Boolean {
            // ONLY intercept if we can actually scroll.
            // If we can't scroll, we shouldn't touch the event at all.
            return if (canScrollVertically(1) || canScrollVertically(-1)) {
                super.onInterceptTouchEvent(ev)
            } else {
                false
            }
        }

        override fun onTouchEvent(ev: android.view.MotionEvent): Boolean {
            val canScroll = canScrollVertically(1) || canScrollVertically(-1)

            if (!canScroll) {
                // If the legend is small and doesn't scroll,
                // return false so the click passes to the containerView.
                return false
            }

            if (ev.action == android.view.MotionEvent.ACTION_DOWN) {
                parent.requestDisallowInterceptTouchEvent(true)
            }

            return super.onTouchEvent(ev)
        }
    }
}
