package com.xweather.mapsgl.anim

import android.view.Choreographer
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.xweather.mapsgl.gl.InterpolationResult
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * A TimeAnimation that manages and controls one or more individual animations. Using a timeline, you can
 * control the playback of multiple animations at once and keep them in sync.
 * @remarks
 * When an animation is added to a `Timeline`, it will not be added to the global {@link AnimationLoop}. Instead, the
 * `Timeline` will manage the animation's playback and progress. This means that individual animations will not be
 * updated unless the `Timeline` is playing.
 */
class Timeline(override var opts: AnimationOptions, internal val controller: MapController) : TimeAnimation(opts) {

    companion object {
        internal var clearParticles = false
        internal var totalDownloads = 0
        internal var isDownloading = false
        internal var pausedForMovement = false
        internal var pausedForDownload = false
        /** True while [MapController] is prefetching every interval after a timeline range change. */
        @Volatile
        internal var fullTimelinePreloadActive = false

        internal val threadDownload = false
        internal val movedOnTileLoaded = false
        internal var TAG = "TempStaticTimes"
        @Volatile
        internal var currentPhaseA = 0
        @Volatile
        internal var currentPhaseB = 1
        @Volatile
        internal var totalPhase = 1
        @Volatile
        internal var dataMeld: Float = 0f // Initial value
            set(value) {
                field = value.coerceIn(0.0f, 1.0f)
            }
        internal var frameRate = 60f
        private var isWaitingForEndDelay = false
        private var isWaitingForDelay = false
        private var timeWaitedForEndDelay = 0.0
        private var timeWaitedForDelay = 0.0

        internal var timeStrings: MutableList<String> = mutableListOf()
        internal var timeLongs: MutableList<Long> = mutableListOf()
        internal var timeDates: MutableList<Date> = mutableListOf()

        /**
         * Guards [timeStrings]/[timeLongs]/[timeDates] against a render-thread reader racing
         * [generateHourlyIntervals] / [resetForNewController] on another thread when the timeline
         * range changes. Readers must go through [globalTimeListsSnapshot] rather than reading
         * these fields directly — a live [MutableList] read on one thread while cleared or
         * reassigned on another produced a mid-read IndexOutOfBoundsException that escaped
         * uncaught into JNI and aborted the process.
         */
        private val timeListsLock = ReentrantLock()

        /** Atomic, immutable snapshot of the current global valid-time lists. */
        internal fun globalTimeListsSnapshot(): Pair<List<Long>, List<String>> = timeListsLock.withLock {
            timeLongs.toList() to timeStrings.toList()
        }


        internal val validTimesList: HashMap<String, MutableList<String>> = hashMapOf()
        internal var sourceTimeHash: HashMap<String, LayerTimeline> = hashMapOf()
        internal var currentDLCount = 0
        var pendingPercent = 0f

        /**
         * Items incrementally added via [addPendingEncodedDownload] (for [effectiveEncodedDownloadDenominator]).
         */
        private val encodedDownloadScheduledTotal = AtomicInteger(0)

        /**
         * Sum of [TileLayer.preflightEncodedDownloadPairCount] across visible encoded layers for this wave
         * (set before any layer runs so % uses a fixed total when playing with multiple layers).
         */
        private val encodedSessionDownloadTarget = AtomicInteger(0)

        /** Increments in [removePendingEncodedDownload] when an item is actually removed. */
        private val encodedDownloadCompletedTotal = AtomicInteger(0)

        private val staggeredFillDownloadSources: MutableSet<String> = ConcurrentHashMap.newKeySet()

        fun requestStaggeredFillDownload(sourceId: String) {
            if (sourceId.isNotEmpty()) {
                staggeredFillDownloadSources.add(sourceId)
            }
        }

        /** Removes and returns source ids that need a fill-interval download pass. */
        fun drainStaggeredFillDownloadRequests(): Set<String> {
            if (staggeredFillDownloadSources.isEmpty()) return emptySet()
            val pending = staggeredFillDownloadSources.toSet()
            staggeredFillDownloadSources.clear()
            return pending
        }

        /** Mirrors whether the map timeline is actively playing (not stopped/paused). */
        @Volatile
        internal var isGloballyPlaying: Boolean = false

        internal fun syncGlobalPlaybackState(state: AnimationState) {
            isGloballyPlaying = state == AnimationState.playing
        }

        @Volatile
        internal var idleTargetPosition: Double = 0.0

        @Volatile
        internal var idleTargetStartMs: Long = 0L

        @Volatile
        internal var idleTargetEndMs: Long = 0L

        @Volatile
        internal var idleTargetState: AnimationState = AnimationState.stopped

        @Volatile
        internal var idleTargetSeekBarMoved: Boolean = false

        internal fun syncIdleTargetSnapshot(
            position: Double,
            startMs: Long,
            endMs: Long,
            state: AnimationState,
            seekBarMoved: Boolean,
        ) {
            idleTargetPosition = position
            idleTargetStartMs = startMs
            idleTargetEndMs = endMs
            idleTargetState = state
            idleTargetSeekBarMoved = seekBarMoved
        }

        /**
         * When true, encoded layers use one valid time (nearest to [idleTargetPosition]) with meld 0
         * for download and draw. Playback, pause, and scrubbing keep dual-phase meld at the current frame.
         */
        internal fun prefersSingleIntervalIdleTarget(): Boolean =
            idleTargetState != AnimationState.playing &&
                idleTargetState != AnimationState.paused &&
                !idleTargetSeekBarMoved

        internal fun scrubEpochSec(): Long =
            (idleTargetStartMs + ((idleTargetEndMs - idleTargetStartMs) * idleTargetPosition).toLong()) / 1000L

        internal fun closestValidTimeInLists(
            timelineLong: Long,
            timeLongs: List<Long>,
            timeStrings: List<String>,
        ): Pair<Long, String>? {
            if (timeLongs.isEmpty() || timeStrings.isEmpty()) return null
            val searchResult = timeLongs.binarySearch(timelineLong)
            if (searchResult >= 0) {
                return timeLongs[searchResult] to timeStrings[searchResult]
            }
            val insertionPoint = -(searchResult + 1)
            if (insertionPoint < timeLongs.size) {
                val j = insertionPoint
                return timeLongs[j] to timeStrings[j]
            }
            val last = timeLongs.lastIndex
            return timeLongs[last] to timeStrings[last]
        }

        /** Global timeline phases when a layer has no [LayerTimeline] entry yet. */
        internal fun fallbackGlobalRenderPhases(): Triple<String, String, Float> {
            val (longs, strings) = globalTimeListsSnapshot()
            if (prefersSingleIntervalIdleTarget() && longs.isNotEmpty() && strings.isNotEmpty()) {
                val scrub = scrubEpochSec()
                closestValidTimeInLists(scrub, longs, strings)?.let { (_, phase) ->
                    return Triple(phase, phase, 0f)
                }
            }
            if (currentPhaseA < strings.size && currentPhaseB < strings.size) {
                return Triple(strings[currentPhaseA], strings[currentPhaseB], dataMeld)
            }
            return Triple("", "", 0f)
        }

        fun setEncodedSessionDownloadTarget(total: Int) {
            encodedSessionDownloadTarget.set(total.coerceAtLeast(0))
        }

        /** False while a session target from preflight is active; [resetEncodedDownloadProgressCounters] clears it. */
        internal fun isEncodedDownloadSessionTargetUnset(): Boolean =
            encodedSessionDownloadTarget.get() == 0

        private fun effectiveEncodedDownloadDenominator(): Int {
            val scheduled = encodedDownloadScheduledTotal.get()
            val session = encodedSessionDownloadTarget.get()
            // Preflight [session] can overshoot tiles actually enqueued via [addPendingEncodedDownload].
            return when {
                scheduled > 0 -> scheduled
                session > 0 -> session
                else -> 1
            }
        }

        var intervalLength = 3600L

        private val _pendingVectorDownloadsLiveData = MutableLiveData(0) // Initial value 0
        val pendingVectorDownloadsLiveData: LiveData<Int> = _pendingVectorDownloadsLiveData

        /** Used when layerInfo doesn't have valid time strings yet
         *  phase: 0 = A, 1 = B
         *  timeString: Usually from LayerInfo
         * **/
        /** True when the global timeline is parked on the final interval (playing or stopped). */
        fun isAtEndPosition(): Boolean {
            return currentPhaseB >= totalPhase && dataMeld >= 1f
        }

        internal fun getTimeString(phase: Int, timeString: String): String {
            if (phase == 0) {
                return if (timeString.length < 4) timeStrings[currentPhaseA] else timeString
            } else {
                return if (timeString.length < 4) timeStrings[currentPhaseB] else timeString
            }
        }


        /**
         * @param pendingTileListCount entries still in [com.xweather.mapsgl.tiles.TileList.pendingList]
         *        (used only when no encoded downloads have been scheduled this session).
         */
        internal fun calcDLPercent(pendingTileListCount: Int) {
            if (encodedSessionDownloadTarget.get() > 0 || encodedDownloadScheduledTotal.get() > 0) {
                val scheduled = encodedDownloadScheduledTotal.get()
                val pendingEncoded = countPendingEncodedAll()
                pendingPercent = when {
                    scheduled > 0 && pendingEncoded == 0 -> 100f
                    scheduled > 0 -> {
                        val httpDone = when {
                            currentDLCount <= 0 -> 0f
                            pendingTileListCount <= 0 -> 1f
                            else -> ((currentDLCount - pendingTileListCount).toFloat() / currentDLCount.toFloat())
                                .coerceIn(0f, 1f)
                        }
                        val bindDone =
                            ((scheduled - pendingEncoded).toFloat() / scheduled.toFloat()).coerceIn(0f, 1f)
                        // Smooth 0–100%: HTTP drives most of the bar; bind finishes the last ~20%.
                        // Avoids jumping to 90% when the bind queue exists but HTTP has not started.
                        val overall = httpDone * (0.80f + 0.20f * bindDone)
                        (overall * 100f).coerceIn(0f, 99f)
                    }
                    currentDLCount > 0 -> {
                        (((currentDLCount - pendingTileListCount).toFloat() / currentDLCount.toFloat()) * 100f)
                            .coerceIn(0f, 99f)
                    }
                    else -> 0f
                }
            } else if (currentDLCount > 0) {
                pendingPercent =
                    (((currentDLCount - pendingTileListCount).toFloat() / currentDLCount.toFloat()) * 100f).coerceIn(
                        0f,
                        100f,
                    )
            } else {
                pendingPercent = 0f
            }
        }

        internal fun resetEncodedDownloadProgressCounters() {
            encodedDownloadScheduledTotal.set(0)
            encodedSessionDownloadTarget.set(0)
            encodedDownloadCompletedTotal.set(0)
        }

        /**
         * Wipe every process-wide static this object holds, so a fresh `MapController` starts with
         * a clean slate. Required because much of MapsGL's per-source render/animation state lives
         * here in the companion (e.g. [sourceTimeHash], [validTimesList], [timeStrings]); when a
         * second `MapController` is created (typically in a new activity) with the same source IDs
         * as the previous one — temperature is the classic example — the stale entries make the
         * renderer think tiles for those time intervals are already downloaded and bound, while the
         * actual GPU data and per-source [LayerTimeline] reference the previous controller. The
         * new layer then renders nothing for the visible phase strings.
         *
         * Call from [MapController]'s constructor. Safe at process start because everything is
         * already in its initial state.
         */
        /**
         * Monotonic id for the active [com.xweather.mapsgl.map.MapController]. Incremented on each
         * [resetForNewController] so async tile completions from a finished activity cannot mark
         * [com.xweather.mapsgl.data.TileList.readyList] for a new map session.
         */
        @Volatile
        var mapSessionId: Long = 0L
            private set

        fun resetForNewController(): Long {
            mapSessionId++
            sourceTimeHash.clear()
            validTimesList.clear()
            timeListsLock.withLock {
                timeStrings.clear()
                timeLongs.clear()
                timeDates.clear()
            }
            currentPhaseA = 0
            currentPhaseB = 1
            totalPhase = 1
            dataMeld = 0f
            currentDLCount = 0
            pendingPercent = 0f
            clearParticles = false
            totalDownloads = 0
            isDownloading = false
            pausedForMovement = false
            pausedForDownload = false
            resetEncodedDownloadProgressCounters()
            clearPendingEncodedDownloads()
            _pendingVectorDownloadsLiveData.postValue(0)
            return mapSessionId
        }

        // Function to update the value
        fun updatePendingVectorDownloads(newValue: Int) {
            _pendingVectorDownloadsLiveData.postValue(newValue.coerceAtLeast(0)) // Use postValue if updating from a background thread
            // or _pendingVectorDownloadsLiveData.value = newValue if on the main thread
        }

        fun incrementPendingVectorDownloads() {
            val finalVal = _pendingVectorDownloadsLiveData.value?.plus(1)
            _pendingVectorDownloadsLiveData.postValue(finalVal)
            // or _pendingVectorDownloadsLiveData.value = newValue if on the main thread
        }

        fun decrementPendingVectorDownloads() {
            val firstVal = _pendingVectorDownloadsLiveData.value?.minus(1)
            val finalVal = firstVal?.coerceAtLeast(0)
            _pendingVectorDownloadsLiveData.postValue(finalVal)
            // or _pendingVectorDownloadsLiveData.value = newValue if on the main thread
        }

        fun updateAllMelds() {
            for (item in sourceTimeHash) {
                item.value.calcRenderVarFromDownloadedTimes()
            }
        }


        private val hourLong = 3600000

        /**
         * Serializes writes to [pendingEncodedDownloadsState] so concurrent add/remove from
         * download threads cannot drop updates. Used as the source of truth for both writers
         * (which mutate [pendingEncodedDownloadsState] under the lock) and the published snapshot
         * (which is posted to [_pendingEncodedDownloadsLiveData]).
         *
         * [LiveData.getValue] reflects only the last successful `postValue` after its main-thread
         * runnable has run — rapid postValues from background threads collapse to the last one and
         * lose intermediate state. We avoid that by never reading `_pendingEncodedDownloadsLiveData.value`
         * to compute the next state.
         */
        private val pendingEncodedDownloadLock = Any()

        /**
         * Authoritative pending-encoded state, mutated under [pendingEncodedDownloadLock].
         * Inner lists are mutated in place (and never escape the lock for reads) so writers can
         * efficiently add / remove without per-call allocations; a fresh immutable snapshot is
         * published via [postEncodedSnapshotLocked].
         */
        private val pendingEncodedDownloadsState: HashMap<String, MutableList<String>> = hashMapOf()

        private val _pendingEncodedDownloadsLiveData =
            MutableLiveData<HashMap<String, List<String>>>(hashMapOf())

        /**
         * Snapshot of [pendingEncodedDownloadsState]. Each posted [HashMap] and its [List] values
         * are not mutated after publish; readers (UI observers, GL thread) can iterate safely.
         */
        val pendingEncodedDownloadsLiveData: LiveData<HashMap<String, List<String>>> =
            _pendingEncodedDownloadsLiveData

        /** Caller must already hold [pendingEncodedDownloadLock]. */
        private fun postEncodedSnapshotLocked() {
            val snapshot = HashMap<String, List<String>>(pendingEncodedDownloadsState.size)
            for ((k, v) in pendingEncodedDownloadsState) {
                snapshot[k] = ArrayList(v)
            }
            _pendingEncodedDownloadsLiveData.postValue(snapshot)
        }

        fun addPendingEncodedDownload(id: String, item: String) {
            if (id.isEmpty() || item.isEmpty()) return
            synchronized(pendingEncodedDownloadLock) {
                val list = pendingEncodedDownloadsState.getOrPut(id) { mutableListOf() }
                if (item !in list) {
                    list.add(item)
                    encodedDownloadScheduledTotal.incrementAndGet()
                    // Keep session denominator >= scheduled when preflight missed work (e.g. late metadata).
                    encodedSessionDownloadTarget.updateAndGet { maxOf(it, encodedDownloadScheduledTotal.get()) }
                    postEncodedSnapshotLocked()
                }
            }
        }

        /**
         * Removes a download item from the pending list for a given ID.
         * If the list becomes empty, the ID is removed from the map.
         * @param id The identifier for the group of downloads.
         * @param item The specific item to remove.
         */
        fun removePendingEncodedDownload(id: String, item: String) {
            if (id.isEmpty() || item.isEmpty()) return
            synchronized(pendingEncodedDownloadLock) {
                val list = pendingEncodedDownloadsState[id]
                if (list != null && list.remove(item)) {
                    encodedDownloadCompletedTotal.incrementAndGet()
                    if (list.isEmpty()) {
                        pendingEncodedDownloadsState.remove(id)
                    }
                    postEncodedSnapshotLocked()
                }
            }
        }

        /** Clears all pending entries and publishes an empty snapshot. */
        internal fun clearPendingEncodedDownloads() {
            synchronized(pendingEncodedDownloadLock) {
                if (pendingEncodedDownloadsState.isEmpty()) {
                    _pendingEncodedDownloadsLiveData.postValue(hashMapOf())
                } else {
                    pendingEncodedDownloadsState.clear()
                    postEncodedSnapshotLocked()
                }
            }
        }

        /** Authoritative count from [pendingEncodedDownloadsState] (not the LiveData snapshot). */
        fun countPendingEncodedAll(): Int {
            return synchronized(pendingEncodedDownloadLock) {
                var n = 0
                for (list in pendingEncodedDownloadsState.values) n += list.size
                n
            }
        }

        /**
         * Authoritative read used by the GL render thread to gate tile binding. Reads the
         * in-memory state under [pendingEncodedDownloadLock] rather than the LiveData snapshot
         * (which can lag behind rapid writes).
         */
        fun isEncodedBindPending(sourceId: String, tileHashShort: String, phaseString: String): Boolean {
            if (sourceId.isEmpty() || tileHashShort.isEmpty() || phaseString.isEmpty()) return false
            val prefix = "$tileHashShort/"
            return synchronized(pendingEncodedDownloadLock) {
                val inner = pendingEncodedDownloadsState[sourceId]
                inner != null && inner.any { hash ->
                    hash.isNotEmpty() && hash.contains(phaseString) && hash.startsWith(prefix)
                }
            }
        }

        internal fun generateHourlyIntervals(startDate: Date, endDate: Date): MutableList<String> {
            //println("Timeline - generateHourlyIntervals() start: $startDate  end: $endDate")

            val intervalList = mutableListOf<String>()
            val longIntervalList = mutableListOf<Long>()
            val dateIntervalList = mutableListOf<Date>()
            // Truncate to local wall-clock hours (MapsGL JS timeline range is expressed in local time).
            // Tile/API keys remain UTC ISO strings below.
            val localZone = ZoneId.systemDefault()
            var currentZoned = startDate.toInstant().atZone(localZone).truncatedTo(ChronoUnit.HOURS)
            val endZoned = endDate.toInstant().atZone(localZone).truncatedTo(ChronoUnit.HOURS)
            val totalTimeHours = (endDate.time - startDate.time) / (3600 * 1000)

            if (totalTimeHours < 25) {
                intervalLength = 3600
            } else if (totalTimeHours < 49) {
                intervalLength = 3600 * 2
            } else if (totalTimeHours < 73) {
                intervalLength = 3600 * 3
            } else {
                val timeMult = totalTimeHours.toFloat() / 40f
                intervalLength = (3600.0 * timeMult).toLong()
            }

            val formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME.withZone(ZoneOffset.UTC)

            while (!currentZoned.isAfter(endZoned)) {
                val instant = currentZoned.toInstant()
                var formattedDate = formatter.format(instant)
                formattedDate = "[\"${formattedDate.substring(0, 14)}00:00Z\"]"
                intervalList.add(formattedDate)
                dateIntervalList.add(Date.from(instant))
                longIntervalList.add(instant.epochSecond)
                currentZoned = currentZoned.plusSeconds(intervalLength)
            }

            timeListsLock.withLock {
                timeStrings = intervalList
                timeLongs = longIntervalList
                timeDates = dateIntervalList
            }

            //TODO: for each source, get all valid times between start and end.


            if (pr.ON) pr.p(TAG, pr.interleave, "generateHourlyIntervals() times.size: ${timeStrings.size}")

            return timeStrings
        }


        /**
         * Converts a Date object to an ISO 8601 string in UTC.
         * @param date The Date object to format.
         * @return A string formatted as "yyyy-MM-dd'T'HH:mm:ss'Z'".
         */
        fun formatDateToUTCString(date: Date): String {
            // Define the specific date format pattern. The 'Z' at the end formats it as UTC.
            val utcFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            // Set the timezone to UTC to ensure the output is not affected by the device's local timezone.
            utcFormat.timeZone = TimeZone.getTimeZone("UTC")
            return utcFormat.format(date)
        }

        fun datesToStringsAndLongs(sourceId: String) {
            if (pr.ON) pr.p("Timeline", pr.layerTimes, "Timeline, datesToStringsAndLongs() entered")
            val layerTimeline = sourceTimeHash[sourceId]
            if (layerTimeline != null) {
                val stringList = mutableListOf<String>()
                val longList = mutableListOf<Long>()

                // Iterate through the source dates a single time.


                for (date in layerTimeline.timeDates) {
                    // Convert to a formatted string and add to the string list.
                    stringList.add("[\"${formatDateToUTCString(date)}\"]")
                    // Get the epoch time in seconds and add to the long list.
                    longList.add(date.time / 1000)
                }

                // Convert the lists to arrays and assign them to the LayerTimeline properties.
                layerTimeline.timeStrings = stringList
                layerTimeline.timeLongs = longList
                layerTimeline.onValidTimesUpdated()

                //println(">> Timeline, datesToStringsAndLongs()   .timeDates: ${layerTimeline.timeDates.size} ${layerTimeline.timeDates}")
                //println(">> Timeline, datesToStringsAndLongs() .timeStrings: ${layerTimeline.timeStrings.size} ${layerTimeline.timeStrings}")
                //println(">> Timeline, datesToStringsAndLongs()   .timeLongs: ${layerTimeline.timeLongs.size} ${layerTimeline.timeLongs}")


            }
        }


    } //end companion object

    internal var seekBarMoved = false
        set(value) {
            field = value
            publishIdleTargetSnapshot()
        }
    private var realWorldTime: String? = null
    private var _times: MutableList<String>? = null

    internal var times: MutableList<String>
        get() = Timeline.timeStrings
        set(value) {
            //numPhases = times!!.size
            _times = value
            Timeline.timeStrings = value
        }

    private val _animations: MutableList<Animation> = mutableListOf()
    private var playJob: Job? = null

    /**
     * Monotonic clock for [updateDataMeld] so meld advances by **elapsed** time between calls (VSync / load jitter)
     * instead of assuming every call represents exactly `1 / frameRate` seconds. Keeps gridded GPU blends aligned
     * with wall-clock playback like iOS interval-style progress.
     */
    private var lastDataMeldAdvanceMonotonicNanos: Long = 0L

    private var clampMin = 0.0
    private var clampMax = 1.0


    /** Whether the animation should begin playing immediately. */
    var autoPlay = opts.autoPlay

    /** Whether the animation should restart after completing playback. */
    var repeat = opts.repeat

    /** Factor used to scale the time of the animation where a value of 1 is normal speed, 0.5 is half speed, and 2
     * is double speed, etc. Only positive values are allowed.
     */
    var timeScale = 1.0

    init {
        start = opts.start
        end = opts.end
        duration = opts.duration
        delay = opts.delay
        endDelay = opts.endDelay
        autoPlay = opts.autoPlay
        repeat = opts.repeat
        enabled = opts.enabled


        if (pr.ON) pr.p(TAG, pr.pastInterval, "init{}  start:$start, end:$end")
        //println(">> Timeline calling generateHourlyIntervals() from init{}")

        generateHourlyIntervals(start, end)
        massUpdate(Timeline.timeStrings)

        currentPhaseA = 0
        currentPhaseB = 1
        publishIdleTargetSnapshot()
    }

    private fun publishIdleTargetSnapshot() {
        syncIdleTargetSnapshot(position, start.time, end.time, state, seekBarMoved)
    }

    /**
     * Restricts the animation to a specific date range relative to the overall start and end date. This is useful if you want to limit the animation to a subset of the overall time range without changing the overall start and end date values.
     * @param min: The minimum date for the range, which must be between the start and end date.
     * @param max: The maximum date for the range, which must be between the start and end date.
     */
    fun clampDateRange(min: Date, max: Date) {
        clampMin = (min.time - start.time).toDouble() / (end.time - start.time).toDouble()
        clampMax = (max.time - start.time).toDouble() / (end.time - start.time).toDouble()
        clampMin = clamp(clampMin, 0.0, 1.0)
        clampMax = clamp(clampMax, clampMin, 1.0)
    }

    /** @return true if the timeline wrapped and [setProgress] reset playback (no further meld carry). */
    private fun nextPhase(): Boolean {
        currentPhaseA++
        currentPhaseB++
        //println(">> Timeline nextPhase beforeEnd currentPhaseA to ${currentPhaseA}")
        if (currentPhaseB > totalPhase /*|| position > clampMax*/) {
            setProgress(clampMin)
            return true
        }
        //println(">> Timeline nextPhase set currentPhaseA to ${currentPhaseA}")
        return false
    }

    /** Seconds since the last playing [updateDataMeld] call; capped to avoid huge jumps after stalls. */
    private fun consumePlaybackDeltaSeconds(): Double {
        val now = System.nanoTime()
        val prev = lastDataMeldAdvanceMonotonicNanos
        lastDataMeldAdvanceMonotonicNanos = now
        if (prev == 0L) {
            return (1.0 / frameRate.toDouble().coerceAtLeast(1.0)).coerceAtMost(0.25)
        }
        val dt = (now - prev) / 1_000_000_000.0
        return dt.coerceIn(0.0, 0.25)
    }

    internal fun updateDataMeld(isNowPlaying: Boolean) {
        if (!isNowPlaying) {
            lastDataMeldAdvanceMonotonicNanos = 0L
            return
        }
        val deltaSec = consumePlaybackDeltaSeconds()
        if (isWaitingForEndDelay) {
            //pr.p("TEMPSTAT", pr.movePause, "frameTime: $frameTime")
            timeWaitedForEndDelay += deltaSec
            if (timeWaitedForEndDelay > endDelay) {
                timeWaitedForEndDelay = 0.0
                isWaitingForEndDelay = false
                clearParticles = true
                setProgress(clampMin)
            }
        } else if (isWaitingForDelay) {
            timeWaitedForDelay += deltaSec
            if (timeWaitedForDelay > delay) {
                timeWaitedForDelay = 0.0
                isWaitingForDelay = false
                //advance(clampMin)
                //setProgress(clampMin)
            }
        } else if (dataMeld < 1f) {
            val inc = (((totalPhase.toDouble() / duration) * deltaSec * timeScale)).toFloat()
            val next = dataMeld + inc
            if (next >= 1f) {
                if (currentPhaseB == totalPhase) {
                    // Final interval: hold at full meld; repeat/stop handled below (same as legacy increment).
                    dataMeld = 1f
                } else {
                    // Carry fractional progress across the phase step in one tick so we never expose a separate
                    // frame at meld==1.0 and then meld==0.0 (same boundary sampled twice).
                    var overshoot = next - 1f
                    var wrapped = nextPhase()
                    if (!wrapped) {
                        while (overshoot >= 1f) {
                            overshoot -= 1f
                            wrapped = nextPhase()
                            if (wrapped) break
                        }
                        if (!wrapped) {
                            dataMeld = overshoot.coerceIn(0f, 1f)
                        }
                    }
                }
            } else {
                dataMeld = next
            }

            if ((currentPhaseB == totalPhase && dataMeld >= 1f) || position > clampMax) {
                if (repeat) {
                    isWaitingForEndDelay = true
                } else {
                    //setProgress(clampMin)
                    stop()
                }
            }
            clearParticles = false
        } else {
            timeWaitedForEndDelay = 0.0
            if (pr.ON) pr.p("Timeline", pr.flicker2, " updateDataMeld: setting meld to 0")
            dataMeld = 0f
            nextPhase()
            //Timeline.updateAllMelds()
            clearParticles = false
        }
    }

    override var position: Double = 0.0
        get() = getSeekBarPosition() // Getter returns the value of the backing field

    /** The animations managed by the timeline.
     * @readonly
     */
    internal val animations: List<Animation>
        get() = _animations

    init {
        realWorldTime = formatDateToIsoString(Date())
        currentDate = Date()
    }

    /** Listen for the Play Button,  Listener set up in TileLayer.onAdd() */
    private val _playIsPressed = MutableLiveData<Boolean>() // Mutable version (internal)
    internal val playIsPressed: LiveData<Boolean> = _playIsPressed  // Read-only access

    private fun setPlayIsPressed(value: Boolean) {
        if (pr.ON) pr.p("Timeline", pr.playLock, "setPlayIsPressed() ${value}")
        _playIsPressed.postValue(value)
    }

    /** Returns the position the seekbar should be at, from 0.0 to 1.0 **/
    private fun getSeekBarPosition(): Double {

        var tempPosition = 0.0


        if (seekBarMoved || state == AnimationState.playing) {
            tempPosition = ((dataMeld + currentPhaseA) / totalPhase.toDouble())
            checkInterval()
        } else {
            tempPosition = calculateProgressBetweenDates(start, end, storedDate)
            checkInterval()
        }

        return tempPosition.coerceIn(0.0, 1.0)
    }

    internal fun getCurrentTimeStringA(): String {
        if (currentPhaseA > timeStrings.size - 1) {
            currentPhaseA = timeStrings.size - 1
        }
        return timeStrings[currentPhaseA]
    }

    internal fun getCurrentTimeStringB(): String {
        if (currentPhaseB > timeStrings.size - 1) {
            currentPhaseB = timeStrings.size - 1
        }

        if (pr.ON) pr.p(
            TAG,
            pr.pastInterval,
            "getCurrentTimeStringB() A: ${currentPhaseA}    B: ${currentPhaseB}   times.size: ${timeStrings.size}"
        )

        return timeStrings[currentPhaseB]
    }

    /** Updates the map to a point on the timeline from 0.0 to 1.0  **/
    private fun setProgress(progress: Double) {
        val numPerPhase = (100.0 / totalPhase.toFloat())   // = 50
        val moveIncrement = 1.0 / numPerPhase //= .02

        val progressMult = progress * 100.0

        currentPhaseA = 0
        currentPhaseB = 1
        if (progressMult <= numPerPhase) { //first interval

            dataMeld = (progressMult * moveIncrement).toFloat()
            if (pr.ON) pr.p("Timeline", pr.flicker2, " setProgress(): setting meld variable  $dataMeld")
        } else if (progress == 1.0) {
            currentPhaseA = totalPhase - 1
            currentPhaseB = totalPhase
            dataMeld = 1f
        } else {
            for (i in 0..totalPhase) {
                if (progressMult > (i + 1) * numPerPhase) {
                    if (currentPhaseB < totalPhase) {
                        currentPhaseA++
                        currentPhaseB++
                        //println(">> Timeline setProgress before end... currentPhaseA to ${currentPhaseA}")
                        dataMeld =
                            ((progressMult - ((100.0 / totalPhase.toFloat()) * (i + 1))) * moveIncrement).toFloat()
                        if (dataMeld > 1f) {
                            dataMeld = 1f
                        }
                    }
                }
            }
        }
        position = progress
        publishIdleTargetSnapshot()

        if (state != AnimationState.playing) {
            seekBarMoved = true
            controller.onTimelineScrubbedWhileIdle()
        } else {
            controller.schedulePlaybackLayerRefreshAfterScrub()
        }

        triggerAny(AnimationEvent.advance, progress)
    }

    /** Listen for the Downloading */
    //private val _isDownloading = MutableLiveData<Boolean>() // Mutable version (internal)

    internal fun setIsDownloading(value: Boolean) {
        //_isDownloading.postValue(value)// .value = value
        if (value) {
            controller.triggerLoadStart()
        } else {
            controller.triggerLoadComplete()
        }
    }

    // liveState is currently unused but may be used in the future if live tracking of "state" changes is desired.
    private val _liveState = MutableLiveData<AnimationState>() // Mutable version (internal)
    val liveState: LiveData<AnimationState> = _liveState  // Read-only access

    private fun setLiveState(value: AnimationState) {
        _liveState.postValue(value)// .value = value
    }

    override val info: TimelineInfo
        get() = TimelineInfo(
            isActive = this.isActive,
            currentDate = this.currentDate,
            startDate = this.start,
            endDate = this.end,
            deltaTime = this.deltaTime
        )

    /** Adds an animation to the timeline.
     * @param animation - The animation to add.
     */
    internal fun add(animation: Animation?) {
        if (pr.ON) pr.p("TimeLine", pr.timeLine, "add() entered, is animation null? ${animation == null}")
        if (animation == null) return
        animation.timeline = this
        if (animation !in animations) {
            animation.delay = this.delay
            animation.duration = this.duration
            animation.endDelay = this.endDelay

            if (animation is TimeAnimation) {
                animation.start = this.start
                animation.end = this.end
                animation.goTo(this.position)
            }

            opts.manualAdvance = this.config.value.manualAdvance // not sure if necessary
            animation.config.setState(opts)
            _animations.add(animation)

            animation.trigger(AnimationEvent.TIMELINE_CHANGE)

            // If the timeline is active (playing or paused) and manual advance is disabled, immediately start playing
            // the animation.
            if (this.isActive && !this.config.value.manualAdvance) {
                animation.play(startImmediately = false)
            }
        }
    }

    /** Removes an animation from the timeline.
     * @param animation - The animation to remove.
     */
    internal fun remove(animation: Animation?) {
        if (animation == null) return

        val index = _animations.indexOf(animation)
        if (index >= 0) {
            animation.timeline = null
            _animations.removeAt(index)
            animation.trigger(AnimationEvent.TIMELINE_CHANGE)
        }
    }

    /** Removes an animation from the timeline by its identifier if it exists.
     * @param id - The identifier of the animation to remove.
     */
    internal fun removeById(id: String) {
        val animation = animations.firstOrNull { it.id == id }
        animation?.let { remove(it) }
    }

    /** Stops and removes all animations from the timeline.
     */
    internal fun clear() {
        stop()
        _animations.clear()
    }

    private fun startPlayJob(fps: Float) {
        if (playJob != null) {
            playJob!!.cancel()
        }
        playJob = updateWhilePlaying(fps) {
            triggerAny(AnimationEvent.advance, position)
            storedDate = currentDate
        }
    }

    private fun cancelPlayJob() {
        if (playJob != null) {
            playJob!!.cancel()
        }
    }

    /**
     *  Begins playing the animation.
     *
     * If you want to start playing the animation from a specific position, pass a value from 0 to 1 to the play()
     * method where 0 is the beginning of the animation and 1 is the end. For example, use play(0.5) to start playback
     * halfway through the animation.
     *
     * @param positionInput An optional position to seek to before toggling play/stop.
     *                           If null, toggles playback from the current position.
     *
     **/
    fun play(positionInput: Double? = null) {
        play(positionInput, true)
    }


    override fun play(positionInput: Double?, startImmediately: Boolean) {
        if (!enabled) return

        if (startImmediately) {
            isWaitingForEndDelay = false
            timeWaitedForEndDelay = 99999999.0
        } else if (delay > 0.0) {
            isWaitingForDelay = true
            timeWaitedForDelay = 0.0

        }

        if (positionInput != null) {
            goTo(positionInput)
        } else {
            goTo(calculateProgressBetweenDates(start, end, storedDate))

        }

        val togglingToPlay = _state != AnimationState.playing
        if (togglingToPlay) {
            _state = AnimationState.playing
            setLiveState(AnimationState.playing)
            syncGlobalPlaybackState(_state)
        } else {
            _state = AnimationState.stopped
            setLiveState(AnimationState.stopped) // TODO: is this ever used?
            syncGlobalPlaybackState(_state)
        }

        setPlayIsPressed(togglingToPlay)
        controller.startAnimatingTimeline(togglingToPlay)

        //println(">> TimeLine.play() _state: ${_state}")

        this.trigger(AnimationEvent.play)

        if (_state == AnimationState.playing) {
            startPlayJob(frameRate)
        } else {
            cancelPlayJob()
        }
        publishIdleTargetSnapshot()
    }

    /** Begins playing the animation from the specified date where date is within the time range between the timeline's startDate and endDate values. **/
    fun playFromDate(fromDate: Date) {
        goToDate(fromDate)
        play(startImmediately = true)
    }

    /** Toggles the current state of the animation between paused and playing if currently active. **/
    override fun toggle() {
        if (_state == AnimationState.playing) {
            _state = AnimationState.paused
            setLiveState(AnimationState.paused)
            syncGlobalPlaybackState(_state)
        } else {
            _state = AnimationState.playing
            setLiveState(AnimationState.playing)
            syncGlobalPlaybackState(_state)
        }
        publishIdleTargetSnapshot()
    }

    /** Pauses the animation at its current position. **/
    override fun pause() {
        if (state == AnimationState.playing) {
            //if(pr.ON) pr.p("TimeLine", pr.playPause, "pause() B")
            _state = AnimationState.paused
            setLiveState(AnimationState.paused)
            syncGlobalPlaybackState(_state)
            this.trigger(AnimationEvent.PAUSE)
            setPlayIsPressed(false) // fire off listener in TileLayer
            _animations.forEach { it.pause() }
            super.pause()
            cancelPlayJob()
            lastDataMeldAdvanceMonotonicNanos = 0L
            publishIdleTargetSnapshot()
            controller.onTimelinePlaybackPaused()
        }
    }

    /**  Resumes playing the animation from its current position, such as after being paused. **/
    override fun resume() {
        //if(pr.ON) pr.p("TimeLine", pr.playPause, "resume()")
        _state = AnimationState.playing
        setLiveState(AnimationState.playing)
        syncGlobalPlaybackState(_state)
        //setPlayIsPressed(true) // fire off listener in TileLayer
        startPlayJob(frameRate)
        this.trigger(AnimationEvent.RESUME)
        _animations.forEach { it.resume() }
        super.resume()
        publishIdleTargetSnapshot()
    }

    /** Stops playing the animation. The timeline position will be updated to the time closest to the current time, which may be at the start or end of the time range or somewhere in between. **/
    override fun stop() {
        if (pr.ON) pr.p("TimeLine", pr.timeMove, "stop()")
        _state = AnimationState.stopped
        setLiveState(AnimationState.stopped)
        syncGlobalPlaybackState(_state)
        setPlayIsPressed(false) // fire off listener in TileLayer
        this.trigger(AnimationEvent.stop)
        _animations.forEach { it.stop() }
        super.stop()
        advanceToStopPosition()
        cancelPlayJob()
        lastDataMeldAdvanceMonotonicNanos = 0L
        publishIdleTargetSnapshot()
    }

    override fun restart() {
        if (pr.ON) pr.p("TimeLine", pr.playPause, "restart()")
        setPlayIsPressed(true) // fire off listener in TileLayer
        _state = AnimationState.playing
        setLiveState(AnimationState.playing)
        syncGlobalPlaybackState(_state)
        this.trigger(AnimationEvent.RESTART)
        _animations.forEach { it.restart() }
        super.restart()
    }

    /** Stops playing the animation if currently playing and updates the playhead back to its original starting position. **/
    override fun reset() {
        stop()
        goTo(0.0)
        this.trigger(AnimationEvent.RESET)

    }

    override fun advance(progress: Double, useTotalDuration: Boolean) { //boolean is set to true by default in JS
        if (pr.ON) pr.p("Timeline", pr.timeMove, "advance($progress, $useTotalDuration) calling super.advance()")
        _animations.forEach { it.advance(progress, useTotalDuration) }
        super.advance(progress, useTotalDuration)
        publishIdleTargetSnapshot()
        this.trigger(AnimationEvent.advance)

    }

    override fun goToDate(date: Date) {
        _animations.forEach { animation ->
            if (animation is TimeAnimation) {
                animation.goToDate(date)
            }
        }
        super.goToDate(date)
    }

    /** Update the map to reflect a position on the timeline from 0.0 to 1.0 **/
    override fun goTo(position: Double, useTotalDuration: Boolean) { //boolean is set to false by default in JS
        if (pr.ON) pr.p(TAG, pr.flicker2, "goto($position) calling setProgress()")

        controller.clearPostRangeChangeTilePrefetchSuppress()
        setProgress(position)
        //_animations.forEach { it.goTo(position, useTotalDuration) }
        //super.goTo(position, useTotalDuration)
        storedDate = currentDate

    }

    /** Calls a function for each animation in the timeline.
     * @param fn - The function to call for each animation.
     * @param enabledOnly - Whether to only call the function for enabled animations. Default is `true`.
     */
    private fun _each(fn: (animator: Animation) -> Unit, enabledOnly: Boolean = true) {
        _animations.filter { !enabledOnly || (enabledOnly && it.enabled) }.forEach(fn)
    }

    override fun advanceToStopPosition() {
        if (pr.ON) pr.p(
            "Timeline",
            pr.timeMove,
            "AdvanceToStopPosition alwaysStopAtStart:${alwaysStopAtStart}   st:${start.time}   rt: ${referenceDate.time}    et: ${end.time}                               "
        )
        if (alwaysStopAtStart) {
            advance(0.0)
        } else if (start.time < referenceDate.time && end.time > referenceDate.time) {
            //goToDate(referenceDate)
            if (pr.ON) pr.p(
                "Timeline",
                pr.timeMove,
                "AdvanceToStopPosition() calculateProgressBetweenDates(start, end, referenceDate) = ${
                    calculateProgressBetweenDates(
                        start, end, referenceDate
                    )
                } "
            )
            if (pr.ON) pr.p(
                "Timeline",
                pr.timeMove,
                "AdvanceToStopPosition() calling   advance(calculateProgressBetweenDates($start, $end, $referenceDate) )}  "
            )
            advance(calculateProgressBetweenDates(start, end, referenceDate /* * 100.0 */).toDouble())
        } else if (isPast) {
            advance(100.0)
        } else {
            advance(0.0)
        }
        publishIdleTargetSnapshot()
    }

    internal fun nextInterval() {
        if (pr.ON) pr.p(TAG, pr.timeMove, "nextInterval------------------")
        pause()
        val sizeMinusOne = timeStrings!!.size - 1

        if (dataMeld >= .97) {
            currentPhaseA++
            //println(">> Timeline nextInterval beforeEnd currentPhaseA to ${currentPhaseA}")
            currentPhaseB++
            dataMeld -= 1
            //updateAllMelds()
        }

        if (currentPhaseB < sizeMinusOne) {
            goTo(((currentPhaseA + 1).toDouble() / sizeMinusOne.toDouble()) * 1.0) //was 100.0
        } else {
            goTo(1.0) // was 100.0
        }

        //println(">> Timeline nextInterval set currentPhaseA to ${currentPhaseA}")
        triggerAny(AnimationEvent.advance, position)
    }

    internal fun prevInterval() {
        pause()

        if (dataMeld > .05f) {
            currentPhaseA++
            currentPhaseB++
            if (pr.ON) pr.p("TimeLine", pr.flicker2, " prevInterval: setting meld to 0")
            dataMeld = 0f
            //updateAllMelds()
        }

        if (currentPhaseA > 0) {
            val sizeMinusOne = timeStrings!!.size - 1
            goTo(((currentPhaseA - 1).toDouble() / sizeMinusOne) * 1.0) // was 100.0
        } else {
            goTo(0.0)
        }

        triggerAny(AnimationEvent.advance, position)
    }

    private fun formatDateToIsoString(date: Date): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        val tempDateString = "[\"${sdf.format(date)}"
        return "${tempDateString.substring(0, 16)}00:00+00:00\"]"
    }


    @OptIn(DelicateCoroutinesApi::class)
    internal fun updateWhilePlaying(fps: Float, block: suspend () -> Unit): Job {
        // Drive playback advances from VSync using Choreographer so timing stays aligned
        // with screen refresh even when work varies or the app is under load.
        val choreographer = Choreographer.getInstance()
        val playJob = Job()
        val scope = kotlinx.coroutines.CoroutineScope(playJob + Dispatchers.Default)

        val inFlight = java.util.concurrent.atomic.AtomicBoolean(false)

        val callback =
            object : Choreographer.FrameCallback {
                override fun doFrame(frameTimeNanos: Long) {
                    if (!playJob.isActive) return

                    // Ensure we don't pile up overlapping executions if `block` ever takes longer than a frame.
                    if (inFlight.compareAndSet(false, true)) {
                        scope.launch {
                            try {
                                block()
                            } finally {
                                inFlight.set(false)
                            }
                        }
                    }

                    choreographer.postFrameCallback(this)
                }
            }

        choreographer.postFrameCallback(callback)
        return playJob
    }
}

/** @suppress **/
class TimelineInfo(
    override val isActive: Boolean,
    override val currentDate: Date,
    override val startDate: Date,
    override val endDate: Date,
    override val deltaTime: Long // Or appropriate type for deltaTime
) : TimeAnimationInfo(isActive, currentDate, startDate, endDate, deltaTime) {}

/** Display target derived from the global [Timeline] clock for one encoded source. */
data class LayerAnimationTarget(
    val phaseA: String,
    val phaseB: String,
    val meld: Float,
    val targetLong: Long,
)

/** Sparse-then-fill download and playback when a layer has many valid intervals. */
enum class StaggeredIntervalPhase {
    Inactive,
    LoadingSparse,
    PlayingSparseLoadingFill,
    Full,
}

class LayerTimeline(val id: String) {
    companion object {
        /** Staggered mode applies when there are more than five valid intervals. */
        private const val STAGGERED_MIN_INTERVAL_COUNT = 6
    }
    var currentA = 0
    var currentB = 0
    var meld = 0f
    var lastMeld = 0f
    var paused = false
    /** True when every viewport tile is ready for [computeGlobalAnimationTarget]. */
    var viewportPlaybackReady: Boolean = true
    /** Frozen interval shown while [viewportPlaybackReady] is false. */
    var viewportHoldPhase: String = ""
    internal var timeDates: MutableList<Date> = mutableListOf()
    internal var timeStrings: MutableList<String> = mutableListOf()
    internal var timeLongs: MutableList<Long> = mutableListOf()

    //internal var reqDates: MutableList<Date> = mutableListOf()
    internal var reqStrings: MutableList<String> = mutableListOf()
    internal var reqLongs: MutableList<Long> = mutableListOf()

    var staggeredPhase: StaggeredIntervalPhase = StaggeredIntervalPhase.Inactive
    private val sparseTimeStrings = mutableListOf<String>()
    private val sparseTimeLongs = mutableListOf<Long>()

    /**
     * Guards [timeStrings]/[timeLongs]/[sparseTimeStrings]/[sparseTimeLongs] against a render-thread
     * reader racing a concurrent [refreshSparseLists] (triggered by [onValidTimesUpdated] when the
     * timeline range changes) — the render thread previously read a live, in-place-mutated list
     * (`binarySearch` computed against the pre-clear size, then indexed after the clear), throwing
     * an uncaught IndexOutOfBoundsException that aborted the process via JNI.
     */
    private val timeListsLock = ReentrantLock()
    var fillPassRequested: Boolean = false

    internal var phaseAString: String = ""
    internal var phaseBString: String = ""

    fun MutableList<Long>.addUnique(element: Long): Boolean {
        if (!this.contains(element)) {
            this.add(element)
            return true
        }
        return false
    }

    fun MutableList<String>.addUnique(element: String): Boolean {
        if (!this.contains(element)) {
            this.add(element)
            return true
        }
        return false
    }

    fun useStaggeredDownload(): Boolean = timeLongs.size >= STAGGERED_MIN_INTERVAL_COUNT

    /**
     * Sparse interval lists are for preload / paused scrub only. During active playback the global
     * clock must map onto the full [timeStrings] list (942cb1f behavior); using sparse lists while
     * playing made gridded icon meld jump ~1× per sparse step instead of smooth hourly crossfade.
     */
    private fun useSparsePlayback(): Boolean =
        useStaggeredDownload() &&
            staggeredPhase != StaggeredIntervalPhase.Full &&
            !Timeline.isGloballyPlaying &&
            Timeline.idleTargetState != AnimationState.paused

    fun refreshSparseLists() {
        timeListsLock.withLock {
            sparseTimeStrings.clear()
            sparseTimeLongs.clear()
            var i = 0
            while (i < timeStrings.size) {
                sparseTimeStrings.add(timeStrings[i])
                sparseTimeLongs.add(timeLongs[i])
                i += 2
            }
        }
    }

    fun onValidTimesUpdated() {
        refreshSparseLists()
        staggeredPhase = if (useStaggeredDownload()) {
            StaggeredIntervalPhase.LoadingSparse
        } else {
            StaggeredIntervalPhase.Inactive
        }
        fillPassRequested = false
    }

    /** Intervals used for animation target and viewport hold while sparse or loading fill. */
    fun playbackTimeStrings(): List<String> = timeListsLock.withLock {
        if (!useSparsePlayback()) {
            timeStrings.toList()
        } else {
            if (sparseTimeStrings.isEmpty()) refreshSparseLists()
            sparseTimeStrings.toList()
        }
    }

    fun playbackTimeLongs(): List<Long> = timeListsLock.withLock {
        if (!useSparsePlayback()) {
            timeLongs.toList()
        } else {
            if (sparseTimeLongs.isEmpty()) refreshSparseLists()
            sparseTimeLongs.toList()
        }
    }

    /**
     * Atomic snapshot of both playback lists together — [playbackTimeStrings] and
     * [playbackTimeLongs] called separately can each be individually consistent yet still return a
     * torn pair (one generation of longs paired with a different generation of strings) if
     * [refreshSparseLists] runs between the two calls.
     */
    fun playbackTimeListsSnapshot(): Pair<List<Long>, List<String>> = timeListsLock.withLock {
        playbackTimeLongs() to playbackTimeStrings()
    }

    /** Filters which layer valid-time indices are enqueued for download in the current pass. */
    fun downloadAllowsLayerIndex(layerIndex: Int): Boolean {
        // Never throttle odd intervals while the timeline is playing — instanced/grid layers need
        // every phase pair the global clock visits (de9f0b4 regressed to ~1 fps icon animation).
        if (!useStaggeredDownload() || Timeline.isGloballyPlaying) return true
        // Full-range prefetch (extend / preload) must queue every interval, not sparse evens only.
        if (Timeline.fullTimelinePreloadActive) return true
        return when (staggeredPhase) {
            StaggeredIntervalPhase.Inactive,
            StaggeredIntervalPhase.Full -> true
            StaggeredIntervalPhase.LoadingSparse -> layerIndex % 2 == 0
            StaggeredIntervalPhase.PlayingSparseLoadingFill -> true
        }
    }

    /**
     * Advances sparse → fill → full playback. Returns true when the fill-interval download wave
     * should be scheduled via [Timeline.requestStaggeredFillDownload].
     */
    fun updateStaggeredPlaybackState(allReadyForPhase: (String) -> Boolean): Boolean {
        if (!useStaggeredDownload()) {
            staggeredPhase = StaggeredIntervalPhase.Inactive
            return false
        }
        if (!Timeline.isGloballyPlaying) {
            // Still advance to Full when every interval is viewport-ready while paused, so scrub
            // does not treat a completed session as "sparse still loading".
            if (staggeredPhase == StaggeredIntervalPhase.PlayingSparseLoadingFill) {
                val fullReady = timeStrings.isNotEmpty() &&
                    timeStrings.all { allReadyForPhase(it) }
                if (fullReady) {
                    staggeredPhase = StaggeredIntervalPhase.Full
                }
            }
            return false
        }
        if (sparseTimeStrings.isEmpty()) refreshSparseLists()
        var requestFill = false
        when (staggeredPhase) {
            StaggeredIntervalPhase.Inactive -> {
                staggeredPhase = StaggeredIntervalPhase.LoadingSparse
            }
            StaggeredIntervalPhase.LoadingSparse -> {
                val sparseReady = sparseTimeStrings.isNotEmpty() &&
                    sparseTimeStrings.all { allReadyForPhase(it) }
                if (sparseReady) {
                    staggeredPhase = StaggeredIntervalPhase.PlayingSparseLoadingFill
                    if (!fillPassRequested) {
                        fillPassRequested = true
                        requestFill = true
                    }
                }
            }
            StaggeredIntervalPhase.PlayingSparseLoadingFill -> {
                val fullReady = timeStrings.isNotEmpty() &&
                    timeStrings.all { allReadyForPhase(it) }
                if (fullReady) {
                    staggeredPhase = StaggeredIntervalPhase.Full
                }
            }
            StaggeredIntervalPhase.Full -> {}
        }
        return requestFill
    }

    /**
     * Nearest product valid time to the current timeline scrub position (meld 0, single phase).
     */
    private fun nearestIdleTarget(): LayerAnimationTarget? {
        val (playbackLongs, playbackStrings) = playbackTimeListsSnapshot()
        val longs: List<Long>
        val strings: List<String>
        if (playbackLongs.isNotEmpty() && playbackStrings.isNotEmpty()) {
            longs = playbackLongs
            strings = playbackStrings
        } else {
            val (globalLongs, globalStrings) = Timeline.globalTimeListsSnapshot()
            if (globalLongs.isNotEmpty() && globalStrings.isNotEmpty()) {
                longs = globalLongs
                strings = globalStrings
            } else {
                return null
            }
        }
        val scrub = Timeline.scrubEpochSec()
        val nearest = Timeline.closestValidTimeInLists(scrub, longs, strings) ?: return null
        return LayerAnimationTarget(nearest.second, nearest.second, 0f, nearest.first)
    }

    /**
     * Global timeline position mapped onto this layer's valid [timeStrings] / [timeLongs].
     * Used as the animation target for viewport-complete playback gating in [RenderPass].
     */
    fun computeGlobalAnimationTarget(): LayerAnimationTarget {
        if (Timeline.prefersSingleIntervalIdleTarget()) {
            nearestIdleTarget()?.let { return it }
        }
        val (playbackLongs, playbackStrings) = playbackTimeListsSnapshot()
        if (playbackLongs.isEmpty() || playbackStrings.isEmpty()) {
            if (Timeline.prefersSingleIntervalIdleTarget()) {
                nearestIdleTarget()?.let { return it }
            }
            val phaseA = Timeline.timeStrings.getOrElse(Timeline.currentPhaseA) { "" }
            val phaseB = Timeline.timeStrings.getOrElse(Timeline.currentPhaseB) { "" }
            val timelineLongA = Timeline.timeLongs.getOrElse(Timeline.currentPhaseA) { 0L }
            val timelineLongB = Timeline.timeLongs.getOrElse(Timeline.currentPhaseB) { timelineLongA }
            val targetLong = (timelineLongA + (timelineLongB - timelineLongA) * Timeline.dataMeld).toLong()
            return LayerAnimationTarget(phaseA, phaseB, Timeline.dataMeld, targetLong)
        }
        val timelineLongA = Timeline.timeLongs.getOrElse(Timeline.currentPhaseA) { playbackLongs.first() }
        val timelineLongB = Timeline.timeLongs.getOrElse(Timeline.currentPhaseB) { playbackLongs.last() }
        var targetLong = (timelineLongA + (timelineLongB - timelineLongA) * Timeline.dataMeld).toLong()
        if (targetLong < playbackLongs.first()) {
            targetLong = playbackLongs.first()
        }
        val interpol = findInterpolationValuesFromAllValidTimes(targetLong, playbackLongs)
        return when {
            interpol != null -> LayerAnimationTarget(
                playbackStrings.getOrElse(interpol.aInt) { "" },
                playbackStrings.getOrElse(interpol.bInt) { "" },
                interpol.fraction,
                targetLong,
            )
            playbackLongs.size == 1 -> {
                val only = playbackStrings.first()
                LayerAnimationTarget(only, only, 0f, targetLong)
            }
            targetLong <= playbackLongs.first() -> {
                val first = playbackStrings.first()
                LayerAnimationTarget(first, first, 0f, targetLong)
            }
            targetLong >= playbackLongs.last() -> {
                val globalA = Timeline.timeStrings.getOrElse(Timeline.currentPhaseA) { "" }
                val globalB = Timeline.timeStrings.getOrElse(Timeline.currentPhaseB) { globalA }
                if (globalA.length > 4 && targetLong >= playbackLongs.last()) {
                    LayerAnimationTarget(globalA, globalB, Timeline.dataMeld, targetLong)
                } else {
                    val last = playbackStrings.last()
                    LayerAnimationTarget(last, last, 0f, targetLong)
                }
            }
            else -> {
                val first = playbackStrings.first()
                LayerAnimationTarget(first, first, 0f, targetLong)
            }
        }
    }

    /** Phase string currently shown (or last shown) for retain-on-playback. */
    fun visibleDisplayPhase(): String {
        if (phaseAString.isNotEmpty() && phaseAString == phaseBString) {
            return phaseAString
        }
        return if (meld <= 0f) phaseAString else phaseBString
    }

    /** Intervals to try to keep on screen when the next target is not ready yet. */
    fun retainPhaseCandidates(): List<String> = buildList {
        visibleDisplayPhase().takeIf { it.length > 4 }?.let { add(it) }
        phaseAString.takeIf { it.length > 4 && it !in this }?.let { add(it) }
        phaseBString.takeIf { it.length > 4 && it !in this }?.let { add(it) }
        viewportHoldPhase.takeIf { it.isNotEmpty() && it !in this }?.let { add(it) }
    }

    fun commitDisplayPhases(
        phaseA: String,
        phaseB: String,
        displayMeld: Float,
        playbackReady: Boolean,
        holdPhase: String?,
    ) {
        phaseAString = phaseA
        phaseBString = phaseB
        meld = displayMeld
        lastMeld = displayMeld
        viewportPlaybackReady = playbackReady
        val visible = if (phaseA == phaseB && phaseA.isNotEmpty()) {
            phaseA
        } else if (displayMeld <= 0f) {
            phaseA
        } else {
            phaseB
        }
        if (visible.length > 4) {
            viewportHoldPhase = visible
        }
        if (!playbackReady && !holdPhase.isNullOrEmpty()) {
            viewportHoldPhase = holdPhase
        }
    }

    fun calcRenderVarFromDownloadedTimes() {
        if (paused) {
            meld = lastMeld
            return
        }
        if (!viewportPlaybackReady) {
            // Display phases are owned by viewport gating in [RenderPass]; do not advance from downloads.
            meld = lastMeld
            return
        }

        val (globalLongs, _) = Timeline.globalTimeListsSnapshot()
        if (globalLongs.isEmpty()) {
            meld = lastMeld
            return
        }
        val idxA = Timeline.currentPhaseA.coerceIn(0, globalLongs.lastIndex)
        val idxB = Timeline.currentPhaseB.coerceIn(0, globalLongs.lastIndex)
        val tLlongA = globalLongs[idxA]
        val tLlongB = globalLongs[idxB]
        var targetLong = (tLlongA + (tLlongB - tLlongA) * Timeline.dataMeld).toLong()

        if (targetLong < globalLongs[0]) {
            targetLong = globalLongs[0]
        }

        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderPassLogging,
            " ==========================================================================================="
        )


        val interpolObject = findInterpolationValuesFromDownloaded(targetLong, reqLongs)
        if (interpolObject != null) {
            lastMeld = meld
            meld = interpolObject.fraction
            currentA = interpolObject.aInt
            currentB = interpolObject.bInt
            phaseAString = reqStrings[currentA]
            phaseBString = reqStrings[currentB]
        } else {
            if (pr.ON) pr.p(
                "LayerTimeline", pr.renderPassLogging, ">> Timeline calcRenderVar interpolObject = null!!! ", 2
            )
        }


        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderpass10,
            ">> Timeline calcRenderVar() meldInfo new Values: A: ${interpolObject?.lowerBound}     B: ${interpolObject?.upperBound}  fr:${interpolObject?.fraction}"
        )
    }

    private fun findInterpolationValuesFromDownloaded(
        targetValue: Long, requestedLongList: List<Long>
    ): InterpolationResult? {
        // We need at least two points to form a range.

        if (requestedLongList.size < 2) {
            if (pr.ON) pr.p(
                "LayerTimeline",
                pr.renderPassLogging,
                ">> Timeline findInterpolationVal() requestedLongList: ${requestedLongList}",
                2
            )
            if (pr.ON) pr.p(
                "LayerTimeline",
                pr.renderPassLogging,
                ">> Timeline findInterpolationVal() find.. (requestedLongList < 2), return null",
                2
            )

            if (requestedLongList.isNotEmpty()) {
                return InterpolationResult(requestedLongList.first(), requestedLongList.first(), 0.0f, 0, 0)
            }

            return null
        }

        // Use binarySearch to find the index or the insertion point.
        /*
        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderPassLogging,
            ">> Timeline calcRenderVar() target: $targetValue in list: ${requestedLongList}"
        )

        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderPassLogging,
            ">> Timeline calcRenderVar() target: $targetValue in list: ${reqDates}"
        )
        */

        val searchResult = requestedLongList.binarySearch(targetValue)
        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderpass10,
            ">> Timeline calcRenderVar() find.. searchResult: $searchResult   list.size:${requestedLongList.size}"
        )
        if (searchResult >= 0) {
            // Exact match found. The value is exactly on a point, so the fraction is 0.
            val value = requestedLongList[searchResult]
            return InterpolationResult(value, value, 0.0f, searchResult, searchResult)
        }

        // The value was not found. Convert the negative searchResult to an insertion point.
        val insertionPoint = -(searchResult + 1)

        // Handle edge cases: target is outside the entire range of the list.
        if (insertionPoint == 0 || insertionPoint == requestedLongList.size) {
            if (pr.ON) pr.p(
                "LayerTimeline",
                pr.renderPassLogging,
                ">> Timeline calcRenderVar() find.. (insertionPont == 0) return null",
                2
            )
            return null // Target is before the first element or after the last one.
        }

        // The target is between two elements.
        val lowerIndex = insertionPoint - 1
        val upperIndex = insertionPoint
        val lowerBound = requestedLongList[lowerIndex]
        val upperBound = requestedLongList[upperIndex]

        // Prevent division by zero if the bounds are identical.
        val range = (upperBound - lowerBound).toFloat()
        if (range == 0f) {
            return InterpolationResult(lowerBound, upperBound, 0.0f, lowerIndex, upperIndex)
        }

        // Calculate the fractional position of the target within the range.
        val position = (targetValue - lowerBound).toFloat()
        val fraction = position / range

        return InterpolationResult(
            lowerBound, upperBound, fraction.coerceIn(0.0f, 1.0f), lowerIndex, upperIndex
        )
    }


    /**
     * Finds the two values in a sorted list that a target value falls between,
     * and calculates the fractional distance between them.
     *
     * @param targetValue The long value to locate within the list.
     * @param sortedList The sorted list of longs to search within.
     * @return An [InterpolationResult] containing the lower and upper bound values and the fraction (0.0f to 1.0f).
     *         Returns null if the list has fewer than two elements or the target is outside the list's range.
     */
    fun findInterpolationValuesFromAllValidTimes(targetValue: Long, sortedList: List<Long>): InterpolationResult? {
        // We need at least two points to form a range.
        if (sortedList.size < 2) {
            return null
        }

        // Use binarySearch to find the index or the insertion point.
        val searchResult = sortedList.binarySearch(targetValue)

        if (searchResult >= 0) {
            // Exact match found. The value is exactly on a point, so the fraction is 0.
            val value = sortedList[searchResult]
            return InterpolationResult(value, value, 0.0f, searchResult, searchResult)
        }

        // The value was not found. Convert the negative searchResult to an insertion point.
        val insertionPoint = -(searchResult + 1)

        // Handle edge cases: target is outside the entire range of the list.
        if (insertionPoint == 0 || insertionPoint == sortedList.size) {
            return null // Target is before the first element or after the last one.
        }

        // The target is between two elements.
        val lowerIndex = insertionPoint - 1
        val upperIndex = insertionPoint
        val lowerBound = sortedList[lowerIndex]
        val upperBound = sortedList[upperIndex]

        // Prevent division by zero if the bounds are identical.
        val range = (upperBound - lowerBound).toFloat()
        if (range == 0f) {
            return InterpolationResult(lowerBound, upperBound, 0.0f, lowerIndex, upperIndex)
        }

        // Calculate the fractional position of the target within the range.
        val position = (targetValue - lowerBound).toFloat()
        val fraction = position / range

        return InterpolationResult(
            lowerBound, upperBound, fraction.coerceIn(0.0f, 1.0f), lowerIndex, upperIndex
        )
    }


}