/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.xweather.mapsglmaps;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.xweather.mapsglmaps";
  public static final String BUILD_TYPE = "release";
}
