package com.xweather.mapsgl.utils

import org.json.JSONArray
import java.text.SimpleDateFormat
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeFormatterBuilder
import java.time.temporal.ChronoField
import java.util.Date
import java.util.Locale
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.floor
import kotlin.math.min
import java.util.regex.Pattern

/**
 * Rule: timezone-lock-contention. [SimpleDateFormat]'s constructor always builds a default
 * [Calendar] internally, which calls the globally-synchronized [TimeZone.getDefault]
 * (`TimeZone.getDefaultRef()`) even when the caller immediately overrides the timezone (as
 * [formatDateArrayToString] used to). [formatDateArrayToString]/[parseDateArrayFromString] are
 * called once per tile-interval fetch/resolve — during an animation's interval-loading burst,
 * dozens of concurrent background coroutines hit this simultaneously, all contending on that one
 * JVM-wide lock; an atrace capture showed the UI thread itself blocked behind it (via
 * `monitor contention with owner ...TimeZone.getDefaultRef()`), causing dropped frames during
 * scroll/seekbar interaction. [DateTimeFormatter] is immutable and thread-safe with zero locking,
 * so a single cached instance eliminates the contention entirely.
 */
private val ISO_UTC_FORMATTER: DateTimeFormatter =
    DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssX", Locale.US).withZone(ZoneOffset.UTC)

fun relativeTimeToDate(relativeDate: Date, str: String): Date {
        return if (str == "now") {
            relativeDate
        } else {
            val seconds = relativeTimeToSeconds(str)
            Date(relativeDate.time + (seconds.toLong() * 1000))
        }
    }

    fun relativeTimeToSeconds(str: String): Double {
        //Implement your logic to convert relative time strings (e.g., "10s", "5m", "2h") to seconds.
        //This function requires more detailed implementation based on your specific relative time string format.
        TODO("Implement relative time string parsing to seconds")
    }


fun reduceDatesToRange(dates: List<Date>, start: Date?, end: Date?, totalIntervals: Int): List<Date> {
    if (start == null || end == null) {
        return emptyList()
    }

    val datesInRange = dates.filter { d -> d >= start && d <= end }
    if (datesInRange.size <= totalIntervals) {
        return datesInRange
    }

    val step = datesInRange.size.toDouble() / (totalIntervals - 1)
    val result = mutableListOf<Date>()

    for (i in 0 until totalIntervals) {
        val index = min(floor(i * step).toInt(), datesInRange.size - 1)
        result.add(datesInRange[index])
    }
    return result
}


private val isoDateStrRegex: Pattern = Pattern.compile(
    "^(\\d{4})-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])" +
            "(?:T([01]\\d|2[0-3]):([0-5]\\d):([0-5]\\d)(?:\\.(\\d{1,}))?(Z|[+-]([01]\\d|2[0-3]):([0-5]\\d))?)?$"
)

private fun isString(value: Any?): Boolean = value is String

private fun isNumber(value: Any?): Boolean = value is Number

private fun isDate(value: Any?): Boolean = value is Date

/**
 * Parses every ISO-8601 shape [isoDateStrRegex] accepts: date-only, date + `T` + time, an optional
 * fractional-seconds part, and an optional `Z` / `+hh:mm` offset. A missing offset is read as UTC,
 * matching [ISO_UTC_FORMATTER] and the `utc = true` intent of [toDate]; a missing time part is
 * read as midnight.
 *
 * History: this used a single `SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX")`. That pattern
 * hard-requires both the `.SSS` fraction and an offset, so the very common
 * `2024-01-15T12:30:00Z` form — the exact form [formatDateArrayToString] emits — matched the regex,
 * failed the parse, and made [toDate] return null. Building the formatter once also removes a
 * per-call `SimpleDateFormat` construction from the tile-fetch path (see the
 * timezone-lock-contention rule above).
 */
private val ISO_FLEXIBLE_PARSER: DateTimeFormatter = DateTimeFormatterBuilder()
    .append(DateTimeFormatter.ISO_LOCAL_DATE)
    .optionalStart()
    .appendLiteral('T')
    .append(DateTimeFormatter.ISO_LOCAL_TIME) // covers the optional fractional seconds
    .optionalEnd()
    .optionalStart()
    .appendOffsetId() // "Z" or "+hh:mm"
    .optionalEnd()
    .parseDefaulting(ChronoField.OFFSET_SECONDS, 0L)
    .parseDefaulting(ChronoField.HOUR_OF_DAY, 0L)
    .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 0L)
    .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 0L)
    .toFormatter(Locale.US)

private fun isoStringToDate(isoString: String): Date? {
    if (!isoDateStrRegex.matcher(isoString).matches()) {
        return null
    }
    return try {
        Date.from(Instant.from(ISO_FLEXIBLE_PARSER.parse(isoString)))
    } catch (e: Exception) {
        null
    }
}


private fun toUTCDate(date: Date): Date {
    val instant = date.toInstant()
    return Date.from(instant.atOffset(ZoneOffset.UTC).toInstant())
}

fun toDate(value: Any?, utc: Boolean = false): Date? {
    if (isString(value) && isoDateStrRegex.matcher(value as String).matches()) {
        return isoStringToDate(value)
    }

    if (isDate(value)) return value as Date?

    // Epoch millis, as a Number or as an all-digits String.
    //
    // Anything else is not a date and yields null. This used to end in `?: 0`, so any unparseable
    // string — including "" — became Date(0): junk in a `validTimes` payload turned into a
    // real-looking 1970 entry that [convertToDates]' mapNotNull could not drop, dragging the
    // timeline's start back to the epoch. The return type has always been nullable, so callers
    // already handle a null here.
    val millis: Long = when {
        isNumber(value) -> (value as Number).toLong()
        isString(value) -> (value as String).toLongOrNull() ?: return null
        else -> return null
    }
    val date = Date(millis)
    return if (utc) toUTCDate(date) else date
}


fun convertToDates(ar: List<Any?> = emptyList(), utc: Boolean = true): List<Date> {
    return ar.mapNotNull { toDate(it, utc) }
        .sortedBy { it.time }
}

fun parseDateArrayFromString(input: String): List<Date> {
    val result = mutableListOf<Date>()

    val jsonArray = JSONArray(input)
    for (i in 0 until jsonArray.length()) {
        val dateStr = jsonArray.optString(i)
        try {
            val date = Date.from(Instant.from(ISO_UTC_FORMATTER.parse(dateStr)))
            result.add(date)
        } catch (e: Exception) {
            // Log or ignore parse errors
        }
    }

    return result
}

fun formatDateArrayToString(dates: List<Date>): String {
    val quotedDates = dates.map { "\"${ISO_UTC_FORMATTER.format(it.toInstant())}\"" }
    return "[${quotedDates.joinToString(",")}]"
}

fun Date.convertedTo(format: String = "", timeZone: TimeZone = TimeZone.getDefault()): String {
    var workingFormat = format
    val calendar = Calendar.getInstance().apply {
        this.timeZone = timeZone
        this.time = this@convertedTo
    }

    if (workingFormat.endsWith("iso")) {
        val isoFormatter = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
        isoFormatter.timeZone = TimeZone.getTimeZone("UTC")
        return isoFormatter.format(this)
    }

    if (workingFormat.startsWith("utc:")) {
        calendar.timeZone = TimeZone.getTimeZone("UTC")
        workingFormat = workingFormat.removePrefix("utc:")
    }

    if (workingFormat == "epoch") {
        // Epoch *seconds*, which is what every xWeather endpoint (and the rest of this codebase —
        // see Timeline's `date.time / 1000`) means by "epoch". This used to multiply by 1000,
        // producing epoch microseconds, a unit no API accepts.
        return (this.time / 1000).toString()
    }

    // `[^\]]+`, not `\w+`: `\w` excludes `-` and `:`, so a punctuated pattern such as
    // `format[yyyy-MM-dd]` failed to match and the whole call silently fell through to
    // `Date.toString()`. Every pattern that matched before still matches identically.
    val formatMatch = Regex("""^format\[([^\]]+)]""").find(workingFormat)
    if (formatMatch != null) {
        var result = formatMatch.groupValues[1]

        val components = mapOf<String, (Date, Calendar) -> String>(
            "yyyy" to { date, cal -> cal.get(Calendar.YEAR).toString() },
            "MM" to { date, cal -> cal.get(Calendar.MONTH).plus(1).toString().padStart(2, '0') },
            "dd" to { date, cal -> cal.get(Calendar.DAY_OF_MONTH).toString().padStart(2, '0') },
            "hh" to { date, cal -> cal.get(Calendar.HOUR_OF_DAY).toString().padStart(2, '0') },
            "mm" to { date, cal -> cal.get(Calendar.MINUTE).toString().padStart(2, '0') }
        )

        for ((code, formatter) in components) {
            result = result.replace(code, formatter(this, calendar))
        }

        return result
    }

    return this.toString()
}