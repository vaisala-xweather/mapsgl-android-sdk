package com.xweather.mapsgl.utils

import kotlin.math.pow

fun FtoC(f: Double): Double = (f - 32) * .55555555
fun CtoF(c: Double): Double = (c * 1.8) + 32
fun mphToKph(mph: Double): Double = mph * 1.609344
fun mphToMs(mph: Double): Double = mph * 0.45
fun kphToMph(kph: Double): Double = kph * 0.6213712
fun kphToMs(kph: Double): Double = kph * 0.28
fun msToKph(ms: Double): Double = ms * 3.6
fun msToMph(ms: Double): Double = ms * 2.236936
fun mbToPa(mb: Double): Double = mb * 100
fun mbToHg(mb: Double): Double = mb * 0.029529983071445
fun paToMb(pa: Double): Double = pa * 0.01
fun hgToMb(hg: Double): Double = hg * 33.86389
fun mToKm(m: Double): Double = m * 0.001
fun mToFt(m: Double): Double = m * 3.280839895
fun mToMi(m: Double): Double = m * 0.00062
fun kmToM(km: Double): Double = km * 1000
fun ftToM(ft: Double): Double = ft * 0.3048
fun kmToMi(km: Double): Double = km * 0.62
fun miToM(mi: Double): Double = mi * 1609.34
fun mmToIn(mm: Double): Double = mm * 0.03937
fun inToMM(ins: Double): Double = ins * 25.4
fun inToMMRate(ins: Double): Double = inToMM(ins) / 3600
fun CtoFUnit(c: Double): Double = c * 1.8
fun FtoCUnit(f: Double): Double = f * 0.555
fun mphToMsUnit(mph: Double): Double = mph * 0.45
fun msToMphUnit(ms: Double): Double = ms * 2.24

fun dbzToMMRate(dbz: Double, perSecond: Boolean = false): Double {
    var rate = (10.0.pow(dbz * .1) * .005).pow(5.0 * .125)
    if (perSecond) {
        return rate / 3600.0
    }
    return rate
}

/**
 * Compass glyph + abbreviation for a bearing in degrees clockwise from north. Accepts any finite
 * bearing, normalizing it into `[0, 360)` first.
 *
 * Two fixes from the original, both matching the already-correct
 * [com.xweather.mapsgl.weather.common.Units.degToDir] used by the data inspector:
 *  - full modulo normalization instead of a single `+-360` nudge, which threw an
 *    [IndexOutOfBoundsException] for any bearing below -360 (negative index) and picked the wrong
 *    bucket above 720; and
 *  - a 22.5 degree bucket width. `360 / dirs.size` was Int/Int division and evaluated to 22, so
 *    every boundary drifted progressively (a bearing of 89 read "E" instead of "ENE"). All eight
 *    cardinal and inter-cardinal bearings are unchanged by this; only intermediate bearings shift,
 *    by at most one bucket.
 *
 * Buckets run `[0, 22.5)` = N, `[22.5, 45)` = NNE, and so on, so the first bucket starts at north
 * rather than being centred on it. That is left as-is: it is what `Units.degToDir` has always done,
 * and changing it would move every reported direction.
 */
fun degToDir(d: Double): String {
    val dirs = listOf(
        "↓ N", "↓ NNE", "↙ NE", "← ENE", "← E", "← ESE", "↖ SE", "↑ SSE",
        "↑ S", "↑ SSW", "↗ SW", "→ WSW", "→ W", "→ WNW", "↘ NW", "↓ NNW"
    )
    val degree = ((d % 360) + 360) % 360
    val index = (degree / (360.0 / dirs.size)).toInt()
    return dirs[index % dirs.size]
}
