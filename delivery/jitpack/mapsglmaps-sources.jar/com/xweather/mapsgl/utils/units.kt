package com.xweather.mapsgl.utils

import kotlin.math.pow

/** Fahrenheit to Celsius. */
fun FtoC(f: Double): Double = (f - 32) * (5.0 / 9.0)
/** Celsius to Fahrenheit. */
fun CtoF(c: Double): Double = (c * 1.8) + 32
/** Miles per hour to kilometres per hour. */
fun mphToKph(mph: Double): Double = mph * 1.609344
/** Miles per hour to metres per second (approximate factor `0.45`). */
fun mphToMs(mph: Double): Double = mph * 0.45
/** Kilometres per hour to miles per hour. */
fun kphToMph(kph: Double): Double = kph * 0.6213712
/** Kilometres per hour to metres per second. */
fun kphToMs(kph: Double): Double = kph * 0.2777777778
/** Metres per second to kilometres per hour. */
fun msToKph(ms: Double): Double = ms * 3.6
/** Metres per second to miles per hour. */
fun msToMph(ms: Double): Double = ms * 2.236936
/** Millibars (hPa) to pascals. */
fun mbToPa(mb: Double): Double = mb * 100
/** Millibars to inches of mercury. */
fun mbToHg(mb: Double): Double = mb * 0.029529983071445
/** Pascals to millibars. */
fun paToMb(pa: Double): Double = pa * 0.01
/** Inches of mercury to millibars. */
fun hgToMb(hg: Double): Double = hg * 33.86389
/** Metres to kilometres. */
fun mToKm(m: Double): Double = m * 0.001
/** Metres to feet. */
fun mToFt(m: Double): Double = m * 3.280839895
/** Metres to inches. */
fun mToIn(m: Double): Double = mToFt(m) * 12
/** Metres to miles (approximate factor `0.00062`). */
fun mToMi(m: Double): Double = m * 0.00062
/** Kilometres to metres. */
fun kmToM(km: Double): Double = km * 1000
/** Feet to metres. */
fun ftToM(ft: Double): Double = ft * 0.3048
/** Kilometres to miles (approximate factor `0.62`). */
fun kmToMi(km: Double): Double = km * 0.62
/** Miles to metres. */
fun miToM(mi: Double): Double = mi * 1609.34
/** Millimetres to inches. */
fun mmToIn(mm: Double): Double = mm * 0.03937
/** Inches to millimetres. */
fun inToMM(ins: Double): Double = ins * 25.4
/** Inches per hour to millimetres per second. */
fun inToMMRate(ins: Double): Double = inToMM(ins) / 3600
/** Inches to metres. */
fun inToM(ins: Double): Double = ins * 0.0254
/** Millimetres per hour to millimetres per second. */
fun mmToMMRate(mm: Double): Double = mm / 3600
/** A Celsius *difference* to a Fahrenheit difference (scale only, no offset). */
fun CtoFUnit(c: Double): Double = c * 1.8
/** A Fahrenheit *difference* to a Celsius difference (scale only, approximate factor `0.555`). */
fun FtoCUnit(f: Double): Double = f * 0.555
/** A miles-per-hour difference to metres per second (approximate factor `0.45`). */
fun mphToMsUnit(mph: Double): Double = mph * 0.45
/** A metres-per-second difference to miles per hour (approximate factor `2.24`). */
fun msToMphUnit(ms: Double): Double = ms * 2.24

/**
 * Radar reflectivity to rain rate with the Marshall-Palmer relation (`Z = 200 R^1.6`).
 *
 * @param dbz Reflectivity in dBZ.
 * @param perSecond When true, returns millimetres per second instead of per hour.
 * @return Rain rate in millimetres per hour, or per second when [perSecond] is true.
 */
fun dbzToMMRate(dbz: Double, perSecond: Boolean = false): Double {
    var rate = (10.0.pow(dbz * .1) * .005).pow(5.0 * .125)
    if (perSecond) {
        return rate / 3600.0
    }
    return rate
}

/**
 * Compass glyph + abbreviation for a bearing in degrees clockwise from north. Accepts any finite
 * bearing, normalizing it into `[0, 360)` first.
 *
 * Two fixes from the original, both matching the already-correct
 * [com.xweather.mapsgl.weather.common.Units.degToDir] used by the data inspector:
 *  - full modulo normalization instead of a single `+-360` nudge, which threw an
 *    [IndexOutOfBoundsException] for any bearing below -360 (negative index) and picked the wrong
 *    bucket above 720; and
 *  - a 22.5 degree bucket width. `360 / dirs.size` was Int/Int division and evaluated to 22, so
 *    every boundary drifted progressively (a bearing of 89 read "E" instead of "ENE"). All eight
 *    cardinal and inter-cardinal bearings are unchanged by this; only intermediate bearings shift,
 *    by at most one bucket.
 *
 * Buckets run `[0, 22.5)` = N, `[22.5, 45)` = NNE, and so on, so the first bucket starts at north
 * rather than being centred on it. That is left as-is: it is what `Units.degToDir` has always done,
 * and changing it would move every reported direction.
 */
fun degToDir(d: Double): String {
    val dirs = listOf(
        "↓ N", "↓ NNE", "↙ NE", "← ENE", "← E", "← ESE", "↖ SE", "↑ SSE",
        "↑ S", "↑ SSW", "↗ SW", "→ WSW", "→ W", "→ WNW", "↘ NW", "↓ NNW"
    )
    val degree = ((d % 360) + 360) % 360
    val index = (degree / (360.0 / dirs.size)).toInt()
    return dirs[index % dirs.size]
}
