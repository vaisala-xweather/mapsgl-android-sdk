package com.xweather.mapsgl.utils

/**
 * String-keyed unit conversion, mirroring MapsGL JS `convert(type, value, from, to)`.
 *
 * The typed [com.xweather.mapsgl.extensions.Measurement] API is the one to reach for in Kotlin
 * code; this exists because expressions name their units as strings (`["to-unit", …, "temperature",
 * "C", "F"]`), so a shared layer configuration has to convert from whatever text the style carries.
 *
 * An unrecognised measurement type or unit pair returns [value] unchanged, exactly as JS does —
 * a style asking for a conversion nobody implements gets the number it started with rather than a
 * failed layer.
 *
 * @suppress
 */
fun convertUnits(type: String, value: Double, from: String, to: String): Double {
    if (from == to) return value

    return when (type) {
        "temperature" -> when {
            from == "C" && to == "F" -> CtoF(value)
            from == "F" && to == "C" -> FtoC(value)
            else -> value
        }

        // A temperature *difference* has no offset: 5 C of change is 9 F of change, not 41 F.
        "temperature-change" -> when {
            from == "C" && to == "F" -> CtoFUnit(value)
            from == "F" && to == "C" -> FtoCUnit(value)
            else -> value
        }

        "speed" -> when {
            from == "km/h" && to == "mph" -> kphToMph(value)
            from == "mph" && to == "km/h" -> mphToKph(value)
            from == "m/s" && to == "mph" -> msToMph(value)
            from == "m/s" && to == "km/h" -> msToKph(value)
            from == "mph" && to == "m/s" -> mphToMs(value)
            from == "km/h" && to == "m/s" -> kphToMs(value)
            else -> value
        }

        "pressure" -> when {
            from == "mb" && to == "hPa" -> mbToPa(value)
            from == "mb" && to == "inHg" -> mbToHg(value)
            from == "hPa" && to == "mb" -> paToMb(value)
            from == "inHg" && to == "mb" -> hgToMb(value)
            else -> value
        }

        "distance" -> when {
            from == "m" && to == "km" -> mToKm(value)
            from == "m" && to == "ft" -> mToFt(value)
            from == "m" && to == "in" -> mToIn(value)
            from == "m" && to == "mi" -> mToMi(value)
            from == "km" && to == "m" -> kmToM(value)
            from == "ft" && to == "m" -> ftToM(value)
            from == "km" && to == "mi" -> kmToMi(value)
            from == "mi" && to == "m" -> miToM(value)
            else -> value
        }

        "precipitation", "snowfall" -> when {
            // An hourly accumulation first: a rate in mm/sec is an hour's worth of millimetres.
            from == "mm/sec" -> convertUnits(type, value * 3600, "mm", to)
            from == "in" && to == "mm" -> inToMM(value)
            from == "in" && to == "m" -> inToM(value)
            from == "in" && to == "mm/sec" -> inToMMRate(value)
            from == "m" && to == "in" -> mToIn(value)
            from == "m" && to == "cm" -> value * 100
            from == "cm" && to == "m" -> value / 100
            from == "cm" && to == "mm" -> value * 10
            from == "mm" && to == "mm/sec" -> mmToMMRate(value)
            from == "mm" && to == "in" -> mmToIn(value)
            else -> value
        }

        "time" -> when {
            from == "hr" && to == "min" -> value * 60
            from == "hr" && to == "sec" -> value * 3600
            from == "hr" && to == "ms" -> value * 3_600_000
            from == "min" && to == "hr" -> value / 60
            from == "min" && to == "sec" -> value * 60
            from == "min" && to == "ms" -> value * 60_000
            from == "sec" && to == "hr" -> value / 3600
            from == "sec" && to == "min" -> value / 60
            from == "sec" && to == "ms" -> value * 1000
            from == "ms" && to == "hr" -> value / 3_600_000
            from == "ms" && to == "min" -> value / 60_000
            from == "ms" && to == "sec" -> value / 1000
            else -> value
        }

        "rate" -> when {
            from == "mm/hr" && to == "mm/sec" -> value / 3600
            from == "mm/sec" && to == "mm/hr" -> value * 3600
            from == "mm/sec" && to == "in/hr" -> value * 3600 * 0.03937
            from == "in/hr" && to == "mm/sec" -> value / 3600 / 0.03937
            from == "dbz" && to == "mm/hr" -> dbzToMMRate(value)
            from == "dbz" && to == "mm/sec" -> dbzToMMRate(value, perSecond = true)
            else -> value
        }

        else -> value
    }
}

/**
 * Default decimal places for a display unit, matching MapsGL JS `getUnitPrecision`.
 *
 * Used by `["to-unit", …]` when the expression names no precision of its own: inches and inches of
 * mercury get two places, centimetres one, everything else a whole number.
 *
 * @suppress
 */
fun unitPrecisionForSymbol(unit: String): Int = when (unit.trim()) {
    "in", "in/hr", "inHg" -> 2
    "cm" -> 1
    else -> 0
}
