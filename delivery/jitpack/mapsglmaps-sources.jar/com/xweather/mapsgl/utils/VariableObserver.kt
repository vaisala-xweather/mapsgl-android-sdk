import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer

class VariableObserver {
    // Internal MutableLiveData that we update
    private val _variable = MutableLiveData<String>()
    // Public immutable LiveData that others observe
    val variable: LiveData<String> = _variable

    lateinit var layerId: String
    private val observers = mutableMapOf<Observer<String>, Observer<String>>()


    fun observeVariable(observer: Observer<String>, id: String) {
        layerId = id
        val wrappedObserver = Observer<String> { value ->
            // This onChanged block provided by LiveData will always execute on the main thread,
            // regardless of whether setValue or postValue was used.
            observer.onChanged(value)
        }
        observers[observer] = wrappedObserver
        // Observe the internal mutable version
        _variable.observeForever(wrappedObserver)
    }

    fun observeVariableAndQuit(observer: Observer<String>, id: String) {
        layerId = id
        val wrappedObserver = Observer<String> { value ->
            // This onChanged block provided by LiveData will always execute on the main thread,
            // regardless of whether setValue or postValue was used.
            observer.onChanged(value)
        }
        observers[observer] = wrappedObserver
        // Observe the internal mutable version
        _variable.observeForever(wrappedObserver)
        variable.removeObserver(observer)
    }

    fun stopObserving(observer: Observer<String>) {
        observers[observer]?.let { wrappedObserver ->
            // Remove the observer from the internal mutable version
            _variable.removeObserver(wrappedObserver)
            observers.remove(observer)
        }
    }

    // --- Update method changed to use postValue ---
    /**
     * Updates the LiveData's value asynchronously.
     * This method uses postValue() and is safe to call from any thread (Main or Background).
     * The LiveData observers will receive the update on the main thread shortly after this call.
     * If postValue() is called multiple times rapidly from background threads, only the last
     * value posted before the main thread processes the update will be delivered.
     *
     * @param newValue The new string value to post.
     */
    fun updateVariable(newValue: String) {
        // Use postValue() instead of .value = (which is setValue)
        _variable.postValue(newValue)
    }

    // --- Deprecated old method (optional, but good practice) ---
    @Deprecated("Use observeVariable instead for proper observer management", ReplaceWith("observeVariable(observer, id)"))
    fun observeVariableOld(observer: Observer<String>, id: String) {
        variable.observeForever(observer) // Still observes the public immutable one here
        layerId = id
    }
}