package com.xweather.mapsgl.util

import android.util.Log

/**
 * The few diagnostics that must still reach logcat from the published AAR.
 *
 * Two separate mechanisms silence the SDK's ordinary logging in release, both deliberately:
 * [MapsGLDebug] compiles its bodies out when `BuildConfig.DEBUG` is false, and
 * `proguard-rules-sdk-release.pro` applies `-assumenosideeffects` to every
 * `android.util.Log.v/d/i/w/e` overload, so R8 deletes even direct calls from the artifact we
 * ship. That is right for tile bookkeeping and render chatter, and wrong for the handful of
 * failures a host app can neither see nor fix without a message: a layer refused because the
 * device lacks OpenGL ES 3.1, or a shader the driver rejected and the reason it gave.
 *
 * `Log.println` - the primitive `Log.v/d/i/w/e` all delegate to - is intentionally absent from
 * that `-assumenosideeffects` block, so calls routed through here survive minification. Two
 * things would silently undo that: rewriting these calls as `Log.e`/`Log.w`, or adding
 * `println(int, java.lang.String, java.lang.String)` to the block. Either leaves the SDK with no
 * account at all of a layer that failed in a release build, which is what
 * [issue #39](https://github.com/vaisala-xweather/mapsgl-android-sdk/issues/39) asked us to fix.
 *
 * Keep the call sites few and bounded. Anything that can fire per frame or per tile belongs in
 * [MapsGLDebug]; this is for one-shot, per-layer or per-process facts.
 */
internal object MapsGLLog {

    @JvmStatic
    fun info(tag: String, message: String) = write(Log.INFO, tag, message, null)

    @JvmStatic
    fun warn(tag: String, message: String, throwable: Throwable? = null) =
        write(Log.WARN, tag, message, throwable)

    @JvmStatic
    fun error(tag: String, message: String, throwable: Throwable? = null) =
        write(Log.ERROR, tag, message, throwable)

    private fun write(priority: Int, tag: String, message: String, throwable: Throwable?) {
        // Log.getStackTraceString is likewise not in the -assumenosideeffects block, so the cause
        // survives with the message rather than being dropped on the way out.
        val body =
            if (throwable == null) message
            else message + "\n" + Log.getStackTraceString(throwable)
        Log.println(priority, tag, body)
    }
}
