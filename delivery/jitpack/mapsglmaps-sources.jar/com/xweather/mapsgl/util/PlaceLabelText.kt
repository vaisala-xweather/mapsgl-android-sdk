package com.xweather.mapsgl.util

import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import com.mapbox.geojson.Feature

/**
 * Place / city label display helpers.
 *
 * Maghreb OSM/`name` strings often pack Latin + Tifinagh + Arabic into one field. Android's
 * default typeface covers Latin/Arabic/Cyrillic/Greek but not Tifinagh, which shows up as
 * nonsense symbols (Casablanca, Tamanrasset, …). Prefer English when present; when Latin is
 * already in the string, keep the Latin run only; otherwise drop glyphs the font cannot draw.
 */
object PlaceLabelText {

    private val glyphProbe: Paint by lazy {
        Paint().apply {
            typeface = Typeface.DEFAULT
            textSize = 24f
        }
    }

    /**
     * English name when available, else local [name], then [sanitizeForDisplay].
     */
    fun resolvePreferredName(feature: Feature, labelKeyPath: String = "name"): String? {
        feature.getStringProperty("name:en")?.trim()?.takeIf { it.isNotEmpty() }?.let {
            return sanitizeForDisplay(it)
        }
        // Flat / nested authored key (data-query labelKeyPath), then plain name.
        readProperty(feature, labelKeyPath)?.let { return sanitizeForDisplay(it) }
        if (labelKeyPath != "name") {
            feature.getStringProperty("name")?.trim()?.takeIf { it.isNotEmpty() }?.let {
                return sanitizeForDisplay(it)
            }
        }
        return null
    }

    /**
     * Cleans a resolved label string for GLES atlas drawing.
     * - If the string contains Latin letters, keep Latin / digits / common punctuation only
     *   (drops Tifinagh and other packed scripts while leaving "Casablanca").
     * - Otherwise keep the string but strip codepoints the default typeface cannot draw.
     */
    fun sanitizeForDisplay(raw: String): String {
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return trimmed

        val hasLatin = trimmed.any { it.isLatinLetter() }
        val filtered =
            if (hasLatin) {
                buildString(trimmed.length) {
                    for (ch in trimmed) {
                        if (ch.isAllowedWithLatinPrimary()) append(ch)
                    }
                }
            } else {
                buildString(trimmed.length) {
                    for (ch in trimmed) {
                        if (ch.isWhitespace() || canDraw(ch)) append(ch)
                    }
                }
            }

        return filtered
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    private fun readProperty(feature: Feature, keyPath: String): String? {
        if (keyPath.isBlank()) return null
        feature.getStringProperty(keyPath)?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        val props = feature.properties() ?: return null
        props.get(keyPath)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }
            ?.asString?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        if (keyPath.contains('.')) {
            val leaf = keyPath.substringAfterLast('.')
            props.get(leaf)?.takeIf { it.isJsonPrimitive && it.asJsonPrimitive.isString }
                ?.asString?.trim()?.takeIf { it.isNotEmpty() }?.let { return it }
        }
        return null
    }

    private fun Char.isLatinLetter(): Boolean =
        this in 'A'..'Z' || this in 'a'..'z' ||
            Character.UnicodeScript.of(code) == Character.UnicodeScript.LATIN

    private fun Char.isAllowedWithLatinPrimary(): Boolean {
        if (isWhitespace()) return true
        if (this in '0'..'9') return true
        if (isLatinLetter()) return true
        // Common in place names + temperature suffixes (°, -, ', ., /).
        if (this in ".'’`-—–°/") return true
        return false
    }

    private fun canDraw(ch: Char): Boolean {
        if (ch.isISOControl()) return false
        if (Build.VERSION.SDK_INT >= 23) {
            return glyphProbe.hasGlyph(ch.toString())
        }
        // Pre-23: keep Arabic / Cyrillic / Greek / Han / common marks; drop Tifinagh block.
        val code = ch.code
        if (code in 0x2D30..0x2D7F) return false // Tifinagh
        val script = Character.UnicodeScript.of(code)
        return script != Character.UnicodeScript.UNKNOWN &&
            script != Character.UnicodeScript.INHERITED
    }
}
