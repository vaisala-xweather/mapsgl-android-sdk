package com.xweather.mapsgl

/**
 * Master switches for SDK features that are built but not yet signed off.
 *
 * Each flag gates one feature area completely: with it `false`, the feature's layer codes are absent
 * from [com.xweather.mapsgl.weather.LayerCode.availableEntries] and
 * [com.xweather.mapsgl.map.MapController.addWeatherLayer] refuses them, so a host app can neither
 * list nor add them. That is the same contract
 * [com.xweather.mapsgl.weather.groups.DataQuery.enabled] provides for the `*-text` catalog, and the
 * reason it is a hard gate rather than a hint: half-enabled features leak into layer pickers and
 * customers find them before QA does.
 *
 * **1.8.0 ships with the set Apple MapsGL 1.8.0 has.** [expressionOperators] and
 * [tropicalConvectiveTimeFilter] are on, because the Apple SDK evaluates those operators and gates
 * tropical positions and convective outlooks on `map-time`. The rest are off: Apple 1.8.0 has no
 * derived sleet/ice layers, no filter migration, no layer `minZoom` / `maxZoom` /
 * `preloadLowQuality`, and no data inspector options.
 *
 * Internal in 1.8.0, as Apple has no such switches: host apps get exactly this set and cannot change
 * it. Making it public is a decision for a later release, since it becomes API that has to stay.
 */
internal object MapsGLFeatures {

    /**
     * Derived precipitation layers: `sleet`, `ice`, their `-accum` variants and the `*-text`
     * companions of all four.
     *
     * These are computed on the client from a pack of rate, precipitation-type and temperature
     * datasets rather than served directly. Rendering is verified against live data; the accumulated
     * totals are covered by unit tests against the MapsGL JS reference but have not been checked
     * against real weather, which is what has to happen before this ships on.
     */
    @JvmStatic
    var derivedPrecipLayers: Boolean = false

    /**
     * Breaking changes and deprecations carried over from MapsGL JS 1.9.x — expression-only filter
     * inputs, `text.value` paint, the `map-time` operator replacing `time`, and the rest.
     *
     * Gates the migration, not an addition: with it off the legacy contracts stay in force.
     *
     * XMAPSGLSDK-295
     */
    @JvmStatic
    var jsBreakingChanges: Boolean = false

    /**
     * The Mapbox-style expression operator set from MapsGL JS 1.9.x, including `regex`,
     * `to-locale-string`, `to-unit`, `now` and `to-date`.
     *
     * XMAPSGLSDK-296
     */
    @JvmStatic
    var expressionOperators: Boolean = true

    /**
     * Layer specification options from MapsGL JS 1.9.x: `minZoom` / `maxZoom`, `filter` on any vector
     * layer, and `preloadLowQuality`.
     *
     * XMAPSGLSDK-297
     */
    @JvmStatic
    var layerSpecOptions: Boolean = false

    /**
     * Timeline-driven feature filtering for the tropical and convective layers.
     *
     * Tropical `trackPoint` / `trackLine` features reveal as the playhead advances while the current
     * position marker and name stay visible, and convective outlooks are gated to the range in
     * `details.range.minTimestamp` / `maxTimestamp`.
     *
     * Unlike the other switches here this one guards behaviour that already shipped (it landed in
     * June and August 2026, before the 1.9.x work) — it is a kill-switch for support rather than a
     * gate on something in progress. With it off, both families draw every feature regardless of the
     * playhead, which is what Android did before that parity work.
     *
     * XMAPSGLSDK-298
     */
    @JvmStatic
    var tropicalConvectiveTimeFilter: Boolean = true

    /**
     * Data inspector options from MapsGL JS 1.9.0. Currently gates only the alert swatch colours in
     * results ([com.xweather.mapsgl.weather.common.Presentation.resolvedSwatchColors]);
     * `DataInspectorControl.showCoordinates` is not behind this flag.
     *
     * XMAPSGLSDK-299
     */
    @JvmStatic
    var dataInspectorOptions: Boolean = false
}
