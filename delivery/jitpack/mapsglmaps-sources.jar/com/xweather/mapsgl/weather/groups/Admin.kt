//
//  Admin.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:16.298Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.TextPaint
import com.xweather.mapsgl.types.TextTransform
import com.xweather.mapsgl.weather.BaseVectorConfiguration
import com.xweather.mapsgl.weather.CompositeWeatherLayerConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.toColor

object Admin {
    class Admin2Boundaries(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ADMIN_2_BOUNDARIES
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.admin_2_boundaries.line",
                source.id,
                sourceLayer = "boundary",
                filter =
                    Expression.and(
                        listOf(
                            Expression.contains(
                                Expression.geometryType,
                                listOf(
                                    "LineString",
                                    "MultiLineString",
                                ),
                            ),
                            Expression.equals(Expression.get("admin_level"), 2),
                            Expression.notEquals(Expression.get("maritime"), 1),
                        ),
                    ),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#333")),
                                thickness =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 1),
                                                Expression.Step(2, result = 2),
                                            ),
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class Admin34Boundaries(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ADMIN_3_4_BOUNDARIES
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.admin_3_4_boundaries.line",
                source.id,
                sourceLayer = "boundary",
                filter =
                    Expression.and(
                        listOf(
                            Expression.contains(
                                Expression.geometryType,
                                listOf(
                                    "LineString",
                                    "MultiLineString",
                                ),
                            ),
                            Expression.greaterThanOrEqual(Expression.get("admin_level"), 3),
                            Expression.lessThanOrEqual(Expression.get("admin_level"), 4),
                            Expression.notEquals(Expression.get("maritime"), 1),
                        ),
                    ),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#333")),
                                thickness = StyleValue.Constant(1.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class Admin56Boundaries(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ADMIN_5_6_BOUNDARIES
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.admin_5_6_boundaries.line",
                source.id,
                sourceLayer = "boundary",
                filter =
                    Expression.and(
                        listOf(
                            Expression.contains(
                                Expression.geometryType,
                                listOf(
                                    "LineString",
                                    "MultiLineString",
                                ),
                            ),
                            Expression.greaterThanOrEqual(Expression.get("admin_level"), 5),
                            Expression.lessThanOrEqual(Expression.get("admin_level"), 6),
                            Expression.notEquals(Expression.get("maritime"), 1),
                        ),
                    ),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#333")),
                                thickness = StyleValue.Constant(1.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class Boundaries(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.BOUNDARIES
        override val layers =
            listOf(
                Admin2Boundaries(service),
                Admin34Boundaries(service),
                Admin56Boundaries(service),
                WaterwayOceanBoundaries(service),
                WaterwayLakeRiverBoundaries(service),
            )
    }

    class Land(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, FillLayerDescriptor>() {
        override val code: LayerCode = LayerCode.LAND
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: FillLayerDescriptor =
            FillLayerDescriptor(
                "admin.land.fill",
                source.id,
                sourceLayer = "water::inverted",
                paint =
                    FillLayerPaint(
                        fill =
                            FillPaint(
                                color = StyleValue.Constant(toColor("#FCFCFD")),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class PlaceCity(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PLACE_CITY
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "admin.place_city.text",
                source.id,
                sourceLayer = "place",
                filter =
                    Expression.contains(
                        Expression.get("class"),
                        listOf(
                            "city",
                            "town",
                        ),
                    ),
                paint =
                    GridLayerPaint(
                        text =
                            listOf(
                                TextPaint(
                                    value =
                                        StyleValue.Expression(
                                            Expression.coalesce(
                                                listOf(
                                                    Expression.get("name:en"),
                                                    Expression.get("name"),
                                                ),
                                            ),
                                        ),
                                    color = StyleValue.Constant(toColor("#333")),
                                    outlineColor = StyleValue.Constant(toColor("#fff")),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class PlaceCountry(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PLACE_COUNTRY
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "admin.place_country.text",
                source.id,
                sourceLayer = "place",
                filter =
                    Expression.contains(
                        Expression.get("class"),
                        listOf(
                            "country",
                            "continent",
                        ),
                    ),
                paint =
                    GridLayerPaint(
                        text =
                            listOf(
                                TextPaint(
                                    value =
                                        StyleValue.Expression(
                                            Expression.coalesce(
                                                listOf(
                                                    Expression.get("name:en"),
                                                    Expression.get("name"),
                                                ),
                                            ),
                                        ),
                                    color = StyleValue.Constant(toColor("#666")),
                                    outlineColor = StyleValue.Constant(toColor("#fff")),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class PlaceNeighborhood(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PLACE_NEIGHBORHOOD
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "admin.place_neighborhood.text",
                source.id,
                sourceLayer = "place",
                filter =
                    Expression.contains(
                        Expression.get("class"),
                        listOf(
                            "village",
                            "neighbourhood",
                            "hamlet",
                            "suburb",
                        ),
                    ),
                paint =
                    GridLayerPaint(
                        text =
                            listOf(
                                TextPaint(
                                    value =
                                        StyleValue.Expression(
                                            Expression.coalesce(
                                                listOf(
                                                    Expression.get("name:en"),
                                                    Expression.get("name"),
                                                ),
                                            ),
                                        ),
                                    color = StyleValue.Constant(toColor("#333")),
                                    outlineColor = StyleValue.Constant(toColor("#fff")),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class PlaceState(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PLACE_STATE
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: SymbolLayerDescriptor =
            SymbolLayerDescriptor(
                "admin.place_state.text",
                source.id,
                sourceLayer = "place",
                filter =
                    Expression.contains(
                        Expression.get("class"),
                        listOf(
                            "state",
                            "province",
                        ),
                    ),
                paint =
                    GridLayerPaint(
                        text =
                            listOf(
                                TextPaint(
                                    value =
                                        StyleValue.Expression(
                                            Expression.coalesce(
                                                listOf(
                                                    Expression.get("name:en"),
                                                    Expression.get("name"),
                                                ),
                                            ),
                                        ),
                                    color = StyleValue.Constant(toColor("#999")),
                                    outlineColor = StyleValue.Constant(toColor("#fff")),
                                    transform = StyleValue.Constant(TextTransform.UPPERCASE),
                                    letterSpacing = StyleValue.Constant(0.1),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class Places(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.PLACES
        override val layers =
            listOf(
                PlaceCountry(service),
                PlaceState(service),
                PlaceCity(service),
                PlaceNeighborhood(service),
            )
    }

    class RoadAll(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ROAD_ALL
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.road_all.line",
                source.id,
                sourceLayer = "transportation",
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#000")),
                                thickness = StyleValue.Constant(3.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class RoadMotorway(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ROAD_MOTORWAY
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.road_motorway.line",
                source.id,
                sourceLayer = "transportation",
                filter = Expression.equals(Expression.get("class"), "motorway"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#000")),
                                thickness =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 1),
                                                Expression.Step(5, result = 2),
                                                Expression.Step(10, result = 4),
                                                Expression.Step(15, result = 10),
                                            ),
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class RoadPrimary(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ROAD_PRIMARY
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.road_primary.line",
                source.id,
                sourceLayer = "transportation",
                filter = Expression.equals(Expression.get("class"), "primary"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#000")),
                                thickness = StyleValue.Constant(1.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class RoadSecondaryTertiary(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ROAD_SECONDARY_TERTIARY
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.road_secondary_tertiary.line",
                source.id,
                sourceLayer = "transportation",
                filter =
                    Expression.contains(
                        Expression.get("class"),
                        listOf(
                            "secondary",
                            "tertiary",
                        ),
                    ),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#000")),
                                thickness =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 1),
                                                Expression.Step(12, result = 2),
                                            ),
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class RoadStreet(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ROAD_STREET
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.road_street.line",
                source.id,
                sourceLayer = "transportation",
                filter =
                    Expression.contains(
                        Expression.get("class"),
                        listOf(
                            "minor",
                            "service",
                        ),
                    ),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#000")),
                                thickness = StyleValue.Constant(1.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class RoadTrunk(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.ROAD_TRUNK
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.road_trunk.line",
                source.id,
                sourceLayer = "transportation",
                filter = Expression.equals(Expression.get("class"), "trunk"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#000")),
                                thickness =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 1),
                                                Expression.Step(10, result = 2),
                                            ),
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class Roads(
        val service: WeatherService,
    ) : CompositeWeatherLayerConfiguration {
        override val code: LayerCode = LayerCode.ROADS
        override val layers =
            listOf(
                RoadMotorway(service),
                RoadTrunk(service),
                RoadPrimary(service),
                RoadSecondaryTertiary(service),
                RoadStreet(service),
            )
    }

    class Water(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, FillLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WATER
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: FillLayerDescriptor =
            FillLayerDescriptor(
                "admin.water.fill",
                source.id,
                sourceLayer = "water",
                paint =
                    FillLayerPaint(
                        fill =
                            FillPaint(
                                color = StyleValue.Constant(toColor("#333")),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class WaterwayLakeRiverBoundaries(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WATERWAY_LAKE_RIVER_BOUNDARIES
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.waterway_lake.line",
                source.id,
                sourceLayer = "water",
                filter =
                    Expression.or(
                        listOf(
                            Expression.equals(Expression.get("class"), "river"),
                            Expression.equals(Expression.get("class"), "lake"),
                        ),
                    ),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#333")),
                                thickness = StyleValue.Constant(1.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class WaterwayOceanBoundaries(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WATERWAY_OCEAN_BOUNDARIES
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: LineLayerDescriptor =
            LineLayerDescriptor(
                "admin.waterway_ocean.line",
                source.id,
                sourceLayer = "water",
                filter = Expression.equals(Expression.get("class"), "ocean"),
                paint =
                    LineLayerPaint(
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#333")),
                                thickness =
                                    StyleValue.Expression(
                                        Expression.step(
                                            Expression.zoom,
                                            listOf(
                                                Expression.Step(null, result = 1),
                                                Expression.Step(2, result = 2),
                                            ),
                                        ),
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }
}
