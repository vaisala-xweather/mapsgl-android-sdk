package com.xweather.mapsgl.weather.groups

import androidx.core.graphics.toColorInt
import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.Point.PointLegendItem
import com.xweather.mapsgl.controls.legend.bar.BarLegend
import com.xweather.mapsgl.controls.legend.bar.BarLegendItem
import com.xweather.mapsgl.controls.legend.bar.BarLegendLabels
import com.xweather.mapsgl.extensions.UnitLength
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.utils.inToMMRate
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.WeatherType
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.toColor

/**
 * Hand-written conditions layers that the generated [Conditions] does not provide.
 *
 * [Conditions] is generated from product metadata, and a regen would discard anything added to it.
 * Layers live here instead, and the generated `LayerCodes.kt` points at them from one marked block.
 * `LayerCodeAdditionsTest` fails if a regen drops that block.
 *
 * If the generator starts emitting one of these itself, delete it here and point `LayerCodes.kt`
 * back at the generated class.
 */
object ConditionsAdditions {

    /** The first non-transparent `prate` stop, in mm/s. */
    private const val PRATE_FIRST_VISIBLE = 0.00002

    /**
     * Where the `prate` colors change, in mm/s, ending at the layer's 25 in/hr top. The stops run
     * from 0.003 to 17 in/hr, so on a linear bar everything below 2 in/hr - nearly all real rain -
     * would squeeze into the first pixels. The legend gives each knot an equal share of the bar
     * instead.
     */
    private val PRATE_KNOTS = doubleArrayOf(0.00002, 0.00004, 0.00117, 0.0032, 0.01351, 0.05696, 0.11696, inToMMRate(25.0))

    /** Bar position (0..1) to the fraction of the knot range, piecewise linear between knots. */
    private fun prateBarToValueFraction(t: Double): Double {
        val segments = PRATE_KNOTS.size - 1
        val scaled = t.coerceIn(0.0, 1.0) * segments
        val i = scaled.toInt().coerceAtMost(segments - 1)
        val value = PRATE_KNOTS[i] + (scaled - i) * (PRATE_KNOTS[i + 1] - PRATE_KNOTS[i])
        return (value - PRATE_KNOTS.first()) / (PRATE_KNOTS.last() - PRATE_KNOTS.first())
    }

    /** The inverse of [prateBarToValueFraction]: where a rate in mm/s sits on the bar. */
    internal fun prateBarPosition(mmPerSec: Double): Double {
        val v = mmPerSec.coerceIn(PRATE_KNOTS.first(), PRATE_KNOTS.last())
        val segments = PRATE_KNOTS.size - 1
        for (i in 0 until segments) {
            if (v <= PRATE_KNOTS[i + 1]) {
                return (i + (v - PRATE_KNOTS[i]) / (PRATE_KNOTS[i + 1] - PRATE_KNOTS[i])) / segments
            }
        }
        return 1.0
    }

    /**
     * The `precip-rate` legend: the layer's own `prate` colors, knots spaced evenly, labelled per hour
     * in inches or millimetres. The labels skip 0.1 in/hr and 2 mm/hr: each lands close enough to the
     * first label that the bar drops it for overlapping. Its id is not [com.xweather.mapsgl.weather.LegendCode.PRECIP_RATE]'s:
     * that one is the 1-hour precipitation legend, and the two layers can be on the map together.
     */
    private fun precipRateLegend(): Legend =
        BarLegend(
            id = "conditions.precip_rate",
            title = "Precipitation Rate",
            measurement = MeasurementUnits.MeasurementType.PRECIPITATION,
            resample = ::prateBarToValueFraction,
            units = MeasurementUnits.IMPERIAL,
            items = listOf(
                BarLegendItem(
                    colorScaleOptions = ColorScaleOptions(
                        stops = ColorScales.prate.stops,
                        range = PRATE_KNOTS.first()..PRATE_KNOTS.last(),
                        normalized = false,
                        interpolate = true,
                    ),
                    labels = BarLegendLabels(
                        currentUnits = MeasurementUnits.IMPERIAL.precipitationRate,
                        values = BarLegendLabels.Values.FromLabels { unit ->
                            when (unit) {
                                is UnitLength.Inches -> listOf(0.01, 0.5, 2.0, 8.0).mapIndexed { i, inches ->
                                    val text = if (inches < 1) inches.toString() else inches.toInt().toString()
                                    prateBarPosition(inToMMRate(inches)) to (if (i == 0) "$text in/hr" else text)
                                }
                                is UnitLength.Millimeters -> listOf(0.2, 10.0, 50.0, 200.0).mapIndexed { i, mm ->
                                    val text = if (mm < 1) mm.toString() else mm.toInt().toString()
                                    prateBarPosition(mm / 3600.0) to (if (i == 0) "$text mm/hr" else text)
                                }
                                else -> emptyList()
                            }
                        },
                    ),
                ),
            ),
        )

    /**
     * Stepped stops for the `weather` layer over the whole 0..255 byte range: transparent below the
     * first code, each code's color from half a code below it, transparent again from half a code
     * past the last code up to 255.
     *
     * The stops must span the full range. For a stepped scale the renderer lays the lookup texture
     * out across `range` but indexes it between the first and last stop, and the two only agree when
     * those stops sit at the ends of the range. With the bands alone (0..12.5) every code indexed
     * past the bands and drew in the last color.
     */
    private fun weatherTypeStops(): List<ColorStop> {
        val clear = toColor("rgba(0,0,0,0)")
        val bands = WeatherType.ENTRIES.sortedBy { it.code }
        return buildList {
            add(ColorStop(0.0, clear))
            bands.forEach { add(ColorStop(it.code - 0.5, toColor(it.color))) }
            add(ColorStop(bands.last().code + 0.5, clear))
            add(ColorStop(255.0, clear))
        }
    }

    /**
     * `precip-rate`: instantaneous precipitation rate, the green channel of the cloud-cover /
     * precip-rate / UV source. Matches MapsGL JS `conditions.precip_rate.fill`: `prate` stops over
     * 0..25 in/hr, in mm/s as the encoded product stores it.
     *
     * Restored from the configuration that was commented out of [Conditions] at v1.0.0, and the
     * product `precip-rate-text` samples. Its legend is its own (`precipRateLegend`); JS borrows the
     * radar legend, which titles it "Radar". No inspector presentation yet.
     *
     * Unlike JS it has a draw range, starting at the first visible stop. The color lookup table
     * cannot resolve stops that close to zero, so without one a dry pixel picked up the first green
     * and the whole map drew a translucent wash. The range also keeps `precip-rate-text` off dry
     * cities, as `precip` and `precip-text` already are.
     */
    class PrecipitationRate(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PRECIPITATION_RATE
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_TCDC_PRECIP_UVI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.precip_rate.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                drawRange = PRATE_FIRST_VISIBLE..inToMMRate(25.0),
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.prate.stops,
                                        range = 0.0..inToMMRate(25.0),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = precipRateLegend()
    }

    /**
     * `weather`: the precipitation type at each pixel — rain, snow, freezing rain and so on — as the
     * red channel of the precip-type / precip / temperature source. Matches MapsGL JS
     * `conditions.weather.fill`, and is what `weather-text` samples.
     *
     * The channel holds codes, not amounts, so nothing may blend them: no spatial interpolation, and
     * `meld = false` so a frame between rain (1) and snow (5) does not read as freezing rain (3).
     * Colors are stepped stops from `WeatherType` (see `weatherTypeStops`), each starting half a code
     * below its own, and the draw range runs half a code past either end. The renderer's decoded
     * value lands a hair off the whole number, and with the draw range on the codes themselves rain
     * (1) fell just under it and never drew. Centred bands take either side of the rounding.
     *
     * One deliberate difference from JS: the draw range stops at the highest real code rather than
     * 255. 255 is the product's "none", and JS's range would let it draw.
     */
    class Weather(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.WEATHER
        override val source: EncodedSourceDescriptor = WeatherSource.conditions_PTYPE_PRECIP_TMP2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "conditions.weather.fill",
                source.id,
                quality = DataQuality.exact,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.NONE,
                                drawRange = (WeatherType.MIN_CODE - 0.5)..(WeatherType.MAX_CODE + 0.5),
                                meld = false,
                                colorScale =
                                    ColorScaleOptions(
                                        stops = weatherTypeStops(),
                                        range = 0.0..255.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = PointLegend(
            id = "weather-type",
            title = "Weather Type",
            items = WeatherType.ENTRIES.map { PointLegendItem(it.color.toColorInt(), it.label) },
        )
    }
}
