package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.weather.LayerCode

/**
 * Stand-in used by builds that do not include the data-query catalog.
 *
 * The full implementation lives in the `full` source set and is selected with
 * `-PwithDataQuery=true`. This variant keeps the same call sites compiling: the catalog is empty
 * and [enabled] is always `false`, so no product, legend, or sampling coordinator is ever created.
 *
 * @suppress
 */
object DataQuery {

    /**
     * Always `false` in this build.
     *
     * @suppress
     */
    const val enabled: Boolean = false

    /**
     * One catalog entry: public [code] samples [sampled] at place points.
     *
     * @property group Style-id prefix (`conditions` or `airquality`).
     * @suppress
     */
    data class Spec(
        val code: LayerCode,
        val sampled: LayerCode,
        val group: String = "conditions",
    ) {
        val layerId: String
            get() = "$group.${code.value.replace('-', '_')}.symbol"
    }

    /**
     * Empty in this build.
     *
     * @suppress
     */
    val CATALOG: List<Spec> = emptyList()

    internal val ALL_CODES: Set<LayerCode> = emptySet()

    /**
     * Always `false` in this build.
     *
     * @suppress
     */
    fun isValueTextLayerId(layerId: String?): Boolean = false
}
