package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.layers.spec.DataQueryLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.style.SymbolRank
import com.xweather.mapsgl.style.SymbolRankDirection
import com.xweather.mapsgl.style.TextPaint
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.weather.BaseVectorConfiguration
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.toColor

/**
 * Hand-configured data-query (`*-text`) layers: sample an encoded weather product at OSM
 * city/town points and publish value + name labels.
 *
 * Matches the iOS/JS catalog of ~30 built-in query text layers (conditions + air quality).
 * Excluded (same as iOS): waterways-text; accum / min / max variants.
 * Skipped here until Android has the sample products: ice-text, sleet-text.
 *
 * @suppress
 */
object DataQuery {

    /**
     * Master switch for the entire `*-text` data-query family. **This is the one flag.**
     *
     * Leave `true` for normal builds. Set it to `false` — here in source, or once from the host
     * app before any map is built — and these layers stop existing as far as anything outside the
     * SDK can tell: [CATALOG] is empty, [LayerCode.availableEntries] omits every `*-text` code, and
     * [com.xweather.mapsgl.map.MapController.addWeatherLayer] refuses them, so no layer, sampled
     * product, legend, or sampling coordinator is ever created. Nothing in the SDK exposes it to
     * an app's UI, so end users can neither see the layers nor reach the switch.
     */
    var enabled: Boolean = false

    /**
     * One catalog entry: public [code] samples [sampled] at place points.
     * @property group Style-id prefix (`conditions` or `airquality`).
     */
    data class Spec(
        val code: LayerCode,
        val sampled: LayerCode,
        val group: String = "conditions",
    ) {
        val layerId: String
            get() = "$group.${code.value.replace('-', '_')}.symbol"
    }

    /**
     * Every data-query spec the SDK knows how to build, regardless of [enabled]. Internal so that
     * a `*-text` [LayerCode] still resolves to a configuration (callers that ask by code get a
     * usable object rather than a crash); [CATALOG] is what the outside world sees.
     */
    private val ALL_SPECS: List<Spec> = listOf(
        // Conditions
        Spec(LayerCode.TEMPERATURES_TEXT, LayerCode.TEMPERATURES),
        Spec(LayerCode.TEMPERATURES_24_HOUR_CHANGE_TEXT, LayerCode.TEMPERATURES_24_HOUR_CHANGE),
        Spec(LayerCode.FEELS_LIKE_TEXT, LayerCode.FEELS_LIKE),
        Spec(LayerCode.DEW_POINTS_TEXT, LayerCode.DEW_POINTS),
        Spec(LayerCode.HUMIDITY_TEXT, LayerCode.HUMIDITY),
        Spec(LayerCode.PRESSURE_MSL_TEXT, LayerCode.PRESSURE_MEAN_SEA_LEVEL),
        Spec(LayerCode.WIND_SPEEDS_TEXT, LayerCode.WIND_SPEEDS),
        Spec(LayerCode.WIND_GUSTS_TEXT, LayerCode.WIND_GUSTS),
        Spec(LayerCode.WIND_CHILL_TEXT, LayerCode.WIND_CHILL),
        Spec(LayerCode.HEAT_INDEX_TEXT, LayerCode.HEAT_INDEX),
        Spec(LayerCode.PRECIP_TEXT, LayerCode.PRECIPITATION),
        Spec(LayerCode.SNOW_TEXT, LayerCode.SNOW),
        Spec(LayerCode.VISIBILITY_TEXT, LayerCode.VISIBILITY),
        Spec(LayerCode.UVI_TEXT, LayerCode.ULTRAVIOLET_INDEX),
        // Air quality
        Spec(LayerCode.AIR_QUALITY_CO_TEXT, LayerCode.CARBON_MONOXIDE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_NO_TEXT, LayerCode.NITRIC_OXIDE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_NO2_TEXT, LayerCode.NITROGEN_DIOXIDE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_O3_TEXT, LayerCode.OZONE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_PM10_TEXT, LayerCode.PARTICULATE_MATTER_10_MICRON, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_PM2P5_TEXT, LayerCode.PARTICULATE_MATTER_2P5_MICRON, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_SO2_TEXT, LayerCode.SULFUR_DIOXIDE, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_TEXT, LayerCode.AIR_QUALITY_INDEX, group = "airquality"),
        Spec(LayerCode.AIR_QUALITY_INDEX_CAI_TEXT, LayerCode.AIR_QUALITY_INDEX_CAI_CATEGORIES, group = "airquality"),
        Spec(
            LayerCode.AIR_QUALITY_INDEX_CHINA_TEXT,
            LayerCode.AIR_QUALITY_INDEX_CHINA_CATEGORIES,
            group = "airquality"
        ),
        Spec(LayerCode.AIR_QUALITY_INDEX_EAQI_TEXT, LayerCode.AIR_QUALITY_INDEX_EAQI_CATEGORIES, group = "airquality"),
        Spec(
            LayerCode.AIR_QUALITY_INDEX_INDIA_TEXT,
            LayerCode.AIR_QUALITY_INDEX_INDIA_CATEGORIES,
            group = "airquality"
        ),
        Spec(
            LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_TEXT,
            LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_CATEGORIES,
            group = "airquality"
        ),
        Spec(
            LayerCode.AIR_QUALITY_INDEX_UK_DAQI_TEXT,
            LayerCode.AIR_QUALITY_INDEX_UK_DAQI_CATEGORIES,
            group = "airquality"
        ),
    )

    /**
     * Full Android data-query catalog (sampled layer must already exist as a [LayerCode]).
     * Order matches typical conditions → air-quality listing. Empty while [enabled] is `false`,
     * so menus built from it simply have nothing to list.
     */
    val CATALOG: List<Spec>
        get() = if (enabled) ALL_SPECS else emptyList()

    private val byCode: Map<LayerCode, Spec> = ALL_SPECS.associateBy { it.code }

    /** Every `*-text` code, independent of [enabled]. */
    internal val ALL_CODES: Set<LayerCode> = ALL_SPECS.map { it.code }.toSet()

    /** True when [layerId] is a catalog data-query symbol layer (value + name stack). */
    fun isValueTextLayerId(layerId: String?): Boolean {
        if (!enabled || layerId.isNullOrEmpty()) return false
        return ALL_SPECS.any { it.layerId == layerId }
    }

    /**
     * Builds the weather configuration for a data-query (`*-text`) [code] from [CATALOG].
     *
     * @throws IllegalStateException if [code] has no catalog entry.
     * @see LayerCode.DataQueryText
     * @see LayerCode.TemperaturesText
     */
    fun configuration(
        service: WeatherService,
        code: LayerCode,
    ): BaseVectorConfiguration<VectorSourceDescriptor, DataQueryLayerDescriptor> {
        val spec = byCode[code]
            ?: error("No DataQuery catalog entry for $code")
        return PlaceValueText(service, spec)
    }

    /** @deprecated Prefer [configuration]; kept for existing TemperaturesText call sites. */
    class TemperaturesText(
        service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, DataQueryLayerDescriptor>() {
        private val inner = PlaceValueText(service, byCode.getValue(LayerCode.TEMPERATURES_TEXT))
        override val code: LayerCode = inner.code
        override val source: VectorSourceDescriptor = inner.source
        override val layer: DataQueryLayerDescriptor = inner.layer
        override var presentation: Presentation? = null
    }

    /**
     * Shared place-point value+name text layer. Only [Spec.code] / [Spec.sampled] / [Spec.layerId] differ.
     */
    class PlaceValueText(
        val service: WeatherService,
        val spec: Spec,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, DataQueryLayerDescriptor>() {
        override val code: LayerCode = spec.code
        override val source: VectorSourceDescriptor = WeatherSource.base_osm(service)
        override val layer: DataQueryLayerDescriptor =
            DataQueryLayerDescriptor(
                id = spec.layerId,
                source = source.id,
                sourceLayer = "place",
                sampledLayerCode = spec.sampled,
                labelKeyPath = "name",
                rankKeyPath = "rank",
                filter =
                    Expression.contains(
                        Expression.get("class"),
                        listOf("city", "town"),
                    ),
                paint =
                    SymbolLayerPaint(
                        rank = SymbolRank("rank", SymbolRankDirection.ASC),
                        pitchWithMap = false,
                        rotateWithMap = false,
                        text =
                            listOf(
                                // Light glyph on a dark halo: these labels sit on saturated weather
                                // fills rather than a light basemap, where a dark fill with a white
                                // halo reads as a pale blob. Also matches the JS data-query config,
                                // which draws the value and name in `#fff` over a dark outline.
                                TextPaint(
                                    value = StyleValue.Expression(Expression.get("value")),
                                    size = StyleValue.Constant(14.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#222")),
                                    anchor = StyleValue.Constant(Anchor.CENTER),
                                ),
                                TextPaint(
                                    value = StyleValue.Expression(Expression.get("name")),
                                    size = StyleValue.Constant(11.0),
                                    color = StyleValue.Constant(toColor("#fff")),
                                    outlineColor = StyleValue.Constant(toColor("#333")),
                                    anchor = StyleValue.Constant(Anchor.TOP),
                                    offset = StyleValue.Constant(AnchorOffset(0.0, 0.15)),
                                ),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
    }
}
