//
//  AirQuality.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:16.301Z
//

package com.xweather.mapsgl.weather.groups

import androidx.core.graphics.toColorInt
import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.controls.legend.Point.PointLegend
import com.xweather.mapsgl.controls.legend.Point.PointLegendItem
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.BaseVectorConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.LegendCode
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations
import com.xweather.mapsgl.weather.toColor

object AirQuality {
    class AirQuality(
        val service: WeatherService,
    ) : BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY
        override val source: VectorSourceDescriptor = WeatherSource.airquality_points(service)
        override val layer: CircleLayerDescriptor =
            CircleLayerDescriptor(
                "air_quality.point",
                source.id,
                paint =
                    CircleLayerPaint(
                        fill =
                            FillPaint(
                                color =
                                    StyleValue.Expression(
                                        Expression.match(
                                            Expression.downcase(Expression.get("periods.0.category")),
                                            ColorScales.airQuality.toExpressionSteps(),
                                            "#999999",
                                        ),
                                    ),
                            ),
                        stroke =
                            StrokePaint(
                                color = StyleValue.Constant(toColor("#fff")),
                                thickness = StyleValue.Constant(2.0),
                            ),
                        circle =
                            CirclePaint(
                                radius = StyleValue.Constant(4.0),
                            ),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null

        init {
            // JS `groups/airquality/layers.ts` `'air-quality'` → `legend: legends.points`
            // (`legends.ts`: id `airquality-aqi-categories`, six AQI category swatches).
            legend =
                PointLegend(
                    id = "airquality-aqi-categories",
                    title = "Air Quality",
                    layerId = null,
                    itemResolver = null,
                    items =
                        listOf(
                            PointLegendItem("#29e11f".toColorInt(), "Good"),
                            PointLegendItem("#f8f92a".toColorInt(), "Moderate"),
                            PointLegendItem("#f9681b".toColorInt(), "Sensitive Groups"),
                            PointLegendItem("#f60115".toColorInt(), "Unhealthy"),
                            PointLegendItem("#7a2c83".toColorInt(), "Very Unhealthy"),
                            PointLegendItem("#65001b".toColorInt(), "Hazardous"),
                        ),
                )
        }
    }

    class CarbonMonoxide(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.CARBON_MONOXIDE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_CO_NO_NO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.co.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityCo.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("CO")
        override var legend: Legend? = null

        init {
            legend = LegendCode.CARBON_MONOXIDE.getLegend()
        }
    }

    class AirQualityHealthIndexCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_HEALTH_INDEX_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AQHI_AQI_China_AQI_India(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.aqhi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityHealthIndexCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQHI")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_HEALTH_INDEX.getLegend()
        }
    }

    class AirQualityIndex(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AirNow_PM2P5_PM10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.index.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndex.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX.getLegend()
        }
    }

    class AirQualityIndexCaiCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_CAI_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_CAI_AQI_CAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.cai.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndexCaiCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("CAI")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_CAI.getLegend()
        }
    }

    class AirQualityIndexCaqiCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_CAQI_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_CAI_AQI_CAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.caqi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndexCaqiCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("CAQI")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_CAQI.getLegend()
        }
    }

    class AirQualityIndexCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AirNow_PM2P5_PM10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.index_categories.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndexCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_CATEGORIES.getLegend()
        }
    }

    class AirQualityIndexChinaCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_CHINA_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AQHI_AQI_China_AQI_India(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.china.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndexChinaCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI (China)")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_CHINA.getLegend()
        }
    }

    class AirQualityIndexEaqiCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_EAQI_CATEGORIES
        override val source: EncodedSourceDescriptor =
            WeatherSource.airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.eaqi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndexEaqiCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI (EAQI)")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_EAQI.getLegend()
        }
    }

    class AirQualityIndexIndiaCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_INDIA_CATEGORIES
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AQHI_AQI_China_AQI_India(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.india.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndexIndiaCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("AQI (India)")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_INDIA.getLegend()
        }
    }

    class AirQualityIndexUbaDaqiCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_CATEGORIES
        override val source: EncodedSourceDescriptor =
            WeatherSource.airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.uba_daqi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndexUbaDaqiCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("UBA DAQI")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_UBA_DAQI.getLegend()
        }
    }

    class AirQualityIndexUkDaqiCategories(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.AIR_QUALITY_INDEX_UK_DAQI_CATEGORIES
        override val source: EncodedSourceDescriptor =
            WeatherSource.airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.uk_daqi.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityIndexUkDaqiCategories.stops,
                                        interval = 0.0,
                                        interpolate = false,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.INDEX]?.setTitle("UK DAQI")
        override var legend: Legend? = null

        init {
            legend = LegendCode.AIR_QUALITY_INDEX_UK_DAQI.getLegend()
        }
    }

    class NitricOxide(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.NITRIC_OXIDE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_CO_NO_NO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.no.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityNo.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("NO")
        override var legend: Legend? = null

        init {
            legend = LegendCode.NITRIC_OXIDE.getLegend()
        }
    }

    class NitrogenDioxide(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.NITROGEN_DIOXIDE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_CO_NO_NO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.no2.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityNo2.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("NO2")
        override var legend: Legend? = null

        init {
            legend = LegendCode.NITROGEN_DIOXIDE.getLegend()
        }
    }

    class Ozone(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.OZONE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_O3_SO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.o3.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.red),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        ColorScales.airQualityO3.stops,
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("O3")
        override var legend: Legend? = null

        init {
            legend = LegendCode.OZONE.getLegend()
        }
    }

    class ParticulateMatter10Micron(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PARTICULATE_MATTER_10_MICRON
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AirNow_PM2P5_PM10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.pm10.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.blue),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                                            ColorStop(50.0, toColor("#0B8ACE")),
                                            ColorStop(100.0, toColor("#F2D538")),
                                            ColorStop(250.0, toColor("#F28012")),
                                            ColorStop(500.0, toColor("#DF0612")),
                                            ColorStop(1000.0, toColor("#980657")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("PM10")
        override var legend: Legend? = null

        init {
            legend = LegendCode.PARTICULATE_MATTER_10_MICRON.getLegend()
        }
    }

    class ParticulateMatter2p5Micron(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.PARTICULATE_MATTER_2P5_MICRON
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_AQI_AirNow_PM2P5_PM10(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.pm2p5.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                                            ColorStop(25.0, toColor("#0B8ACE")),
                                            ColorStop(50.0, toColor("#F2D538")),
                                            ColorStop(100.0, toColor("#F28012")),
                                            ColorStop(200.0, toColor("#DF0612")),
                                            ColorStop(300.0, toColor("#980657")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("PM2.5")
        override var legend: Legend? = null

        init {
            legend = LegendCode.PARTICULATE_MATTER_2P5_MICRON.getLegend()
        }
    }

    class SulfurDioxide(
        val service: WeatherService,
    ) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.SULFUR_DIOXIDE
        override val source: EncodedSourceDescriptor = WeatherSource.airquality_O3_SO2(service)
        override val layer: SampleLayerDescriptor =
            SampleLayerDescriptor(
                "air_quality.so2.fill",
                source.id,
                quality = DataQuality.high,
                paint =
                    SampleLayerPaint(
                        sample =
                            SamplePaint(
                                channel = listOf(ColorBand.green),
                                interpolation = InterpolationMode.BICUBIC,
                                colorScale =
                                    ColorScaleOptions(
                                        listOf(
                                            ColorStop(0.0, toColor("rgba(7, 54, 161, 0)")),
                                            ColorStop(5.0, toColor("#0B8ACE")),
                                            ColorStop(10.0, toColor("#F2D538")),
                                            ColorStop(25.0, toColor("#F28012")),
                                            ColorStop(50.0, toColor("#DF0612")),
                                            ColorStop(100.0, toColor("#980657")),
                                        ),
                                        interval = 0.0,
                                    ),
                            ),
                    ),
            )
        override var presentation = presentations[PresentationType.POLLUTANT]?.setTitle("SO2")
        override var legend: Legend? = null

        init {
            legend = LegendCode.SULFUR_DIOXIDE.getLegend()
        }
    }
}
