//
//  Raster.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2025-10-22T18:06:35.572Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.layers.spec.RasterLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.RasterPaint
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.WeatherLayerConfiguration
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.Presentation

object Raster {
    class Satellite(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
        override val code: LayerCode = LayerCode.SATELLITE
        override val source: ImageSourceDescriptor = WeatherSource.satellite_infrared(service)
        override val layer: RasterLayerDescriptor =
            RasterLayerDescriptor(
                "raster.satellite.infrared",
                source.id,
                paint =
                    RasterLayerPaint(
                        raster = RasterPaint(),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class SatelliteGeocolor(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
        override val code: LayerCode = LayerCode.SATELLITE_GEOCOLOR
        override val source: ImageSourceDescriptor = WeatherSource.satellite_geocolor(service)
        override val layer: RasterLayerDescriptor =
            RasterLayerDescriptor(
                "raster.satellite.geocolor",
                source.id,
                paint =
                    RasterLayerPaint(
                        raster = RasterPaint(),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class SatelliteInfraredColor(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
        override val code: LayerCode = LayerCode.SATELLITE_INFRARED_COLOR
        override val source: ImageSourceDescriptor = WeatherSource.satellite_infrared_color(service)
        override val layer: RasterLayerDescriptor =
            RasterLayerDescriptor(
                "raster.satellite.infrared-color",
                source.id,
                paint =
                    RasterLayerPaint(
                        raster = RasterPaint(),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class SatelliteVisible(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
        override val code: LayerCode = LayerCode.SATELLITE_VISIBLE
        override val source: ImageSourceDescriptor = WeatherSource.satellite_visible(service)
        override val layer: RasterLayerDescriptor =
            RasterLayerDescriptor(
                "raster.satellite.visible",
                source.id,
                paint =
                    RasterLayerPaint(
                        raster = RasterPaint(),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    class SatelliteWaterVapor(
        val service: WeatherService,
    ) : WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
        override val code: LayerCode = LayerCode.SATELLITE_WATER_VAPOR
        override val source: ImageSourceDescriptor = WeatherSource.satellite_water_vapor(service)
        override val layer: RasterLayerDescriptor =
            RasterLayerDescriptor(
                "raster.satellite.water-vapor",
                source.id,
                paint =
                    RasterLayerPaint(
                        raster = RasterPaint(),
                    ),
            )
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }
}
