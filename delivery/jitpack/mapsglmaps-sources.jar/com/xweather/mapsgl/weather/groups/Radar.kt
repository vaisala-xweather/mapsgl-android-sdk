//
//  Radar.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-08-19T17:54:07.087Z
//

package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorMaskOptions
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.weather.BaseEncodedConfiguration
import com.xweather.mapsgl.weather.ColorScales
import com.xweather.mapsgl.weather.LayerCode
import com.xweather.mapsgl.weather.LegendCode
import com.xweather.mapsgl.weather.WeatherService
import com.xweather.mapsgl.weather.WeatherSource
import com.xweather.mapsgl.weather.common.PresentationType
import com.xweather.mapsgl.weather.common.presentations

object Radar {
    class Radar(val service: WeatherService) : BaseEncodedConfiguration<SampleLayerDescriptor>() {
        override val code: LayerCode = LayerCode.RADAR
        override val source: EncodedSourceDescriptor = WeatherSource.radar_REFC_PTYPESMPL_REFC_ARCHIVE(service)
        override val layer: SampleLayerDescriptor = SampleLayerDescriptor(
            "conditions.radar.fill",
            source.id,
            quality = DataQuality.exact,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    // Padded radar tiles keep reflectivity in alpha and split the green-byte
                    // precip type into R/G/B flags (1 rain → G, 3 mix → R, 2 snow → B).
                    // The nested stop lists are the 1.7.0 paint shape. Masks add the rain
                    // floor; mix and snow have no draw range, so they keep the full scale.
                    // Replacing this scale with nested stops and no masks draws like 1.7.0.
                    colorScale = ColorScaleOptions(
                        range = 0.0..87.0,
                        stops = listOf(
                            ColorScales.radarRain.stops,
                            ColorScales.radarMix.stops,
                            ColorScales.radarSnow.stops,
                        ),
                        masks = listOf(
                            ColorMaskOptions(
                                channel = ColorBand.green,
                                value = 1,
                                colorscale = ColorScaleOptions(
                                    stops = ColorScales.radarRain.stops,
                                    range = 0.0..87.0,
                                ),
                                drawRange = 10.0..87.0,
                            ),
                            ColorMaskOptions(
                                channel = ColorBand.green,
                                value = 3,
                                colorscale = ColorScaleOptions(
                                    stops = ColorScales.radarMix.stops,
                                    range = 0.0..87.0,
                                ),
                            ),
                            ColorMaskOptions(
                                channel = ColorBand.green,
                                value = 2,
                                colorscale = ColorScaleOptions(
                                    stops = ColorScales.radarSnow.stops,
                                    range = 0.0..87.0,
                                ),
                            ),
                        ),
                    )
                )
            )
        )
        override var presentation = presentations[PresentationType.RADAR]?.setTitle("Radar")
        override var legend: Legend? = null


        init {
            legend = LegendCode.RADAR.getLegend()
        }

    }
}