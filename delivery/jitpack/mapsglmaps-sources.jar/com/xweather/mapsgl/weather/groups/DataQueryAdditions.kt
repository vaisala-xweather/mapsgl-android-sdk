package com.xweather.mapsgl.weather.groups

import com.xweather.mapsgl.weather.LayerCode

/**
 * `*-text` layers the iOS / JS catalog has and the original Android [DataQuery] catalog did not.
 *
 * Kept apart from [DataQuery]'s own list so that closing the gap with iOS is one reviewable file. The
 * matching [LayerCode] constants and their `getConfigurationForLayerCode` branch are the only part that
 * has to sit in the generated `LayerCodes.kt`, because a Kotlin enum cannot gain constants from another
 * file. `LayerCodeAdditionsTest` fails if a regen drops them.
 *
 * Each sampled product needs a formatting case in `DataQueryCoordinator.formatNumber` and `withUnit`,
 * or its labels fall through to a bare whole number. `weather-text` is the one whose label is not a
 * number: it samples precipitation-type codes and prints the condition name from
 * [com.xweather.mapsgl.weather.WeatherType].
 */
internal object DataQueryAdditions {

    val SPECS: List<DataQuery.Spec> = listOf(
        // Conditions
        DataQuery.Spec(LayerCode.CLOUD_COVER_TEXT, LayerCode.CLOUD_COVER),
        DataQuery.Spec(LayerCode.TEMPERATURES_1_HOUR_CHANGE_TEXT, LayerCode.TEMPERATURES_1_HOUR_CHANGE),
        DataQuery.Spec(LayerCode.PRECIP_RATE_TEXT, LayerCode.PRECIPITATION_RATE),
        DataQuery.Spec(LayerCode.SNOW_DEPTH_TEXT, LayerCode.SNOW_DEPTH),
        DataQuery.Spec(LayerCode.WEATHER_TEXT, LayerCode.WEATHER),
        // Air quality
        DataQuery.Spec(
            LayerCode.AIR_QUALITY_INDEX_CAQI_TEXT,
            LayerCode.AIR_QUALITY_INDEX_CAQI_CATEGORIES,
            group = "airquality",
        ),
    )
}
