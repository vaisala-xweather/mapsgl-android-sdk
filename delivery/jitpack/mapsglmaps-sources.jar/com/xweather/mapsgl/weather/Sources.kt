//
//  Sources.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-05-01T15:06:46.802Z
//

@file:Suppress("EnumEntryName")

package com.xweather.mapsgl.weather

import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor

object WeatherSource {
    enum class SourceCode(val value: String) {
        base_osm("base.osm"),
		base_cities("base.cities"),
		conditions_TMP2_UGRD10_VGRD10("conditions.TMP_2:UGRD_10:VGRD_10"),
		conditions_TMP2_DELTA("conditions.TMP_2:DELTA"),
		conditions_TMP2_DPT2_RH2("conditions.TMP_2:DPT_2:RH_2"),
		conditions_APTMP2_DPT2_RH2("conditions.APTMP_2:DPT_2:RH_2"),
		conditions_PRMSL_VIS_GUST10("conditions.PRMSL_0:VIS_0:GUST_10"),
		conditions_SNOD("conditions.SNOD_0"),
		conditions_TCDC_PRECIP_UVI("conditions.TCDC_0:PRECIP_0:UVI_0"),
		conditions_PTYPE_PRECIP_TMP2("conditions.PTYPE_0:PRECIP_0:TMP_2"),
		conditions_PRECIP("conditions.PRECIP_0"),
		conditions_SNOW_PRECIP_TMP2("conditions.SNOW-PRECIP_0:TMP_2"),
		@Deprecated("Use radar_REFC_PTYPESMPL_REFC_ARCHIVE")
		radar_REFC_PRATE_PTYPESMPL("radar.REFC_0:PRATE_0:PTYPESMPL_0"),
		radar_REFC_PTYPESMPL_REFC_ARCHIVE("radar.REFC_0:PTYPESMPL_0:REFC_0-ARCHIVE"),
		airquality_points("airquality.points"),
		airquality_AQI_AirNow_PM2P5_PM10("airquality.AQI-AirNow:PM2P5_0:PM10_0"),
		airquality_AQI_AQHI_AQI_China_AQI_India("airquality.AQI-AQHI:AQI-China:AQI-India"),
		airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI("airquality.AQI-EAQI:AQI-UBA_DAQI:AQI-UK_DAQI"),
		airquality_AQI_CAI_AQI_CAQI("airquality.AQI-CAI:AQI-CAQI"),
		airquality_CO_NO_NO2("airquality.CO_0:NO_0:NO2_0"),
		airquality_O3_SO2("airquality.O3_0:SO2_0"),
		maritime_HTSGW_DIRPW_PERPW("maritime.HTSGW_0:DIRPW_0:PERPW_0"),
		maritime_SWELL1_SWPER1_SWDIR1("maritime.SWELL_1:SWPER_1:SWDIR_1"),
		maritime_SWELL2_SWPER2_SWDIR2("maritime.SWELL_2:SWPER_2:SWDIR_2"),
		maritime_SWELL3_SWPER3_SWDIR3("maritime.SWELL_3:SWPER_3:SWDIR_3"),
		maritime_WTMP_UOGRD_VOGRD("maritime.WTMP_0:UOGRD_0:VOGRD_0"),
		maritime_SURGE_TIDE("maritime.SURGE_0:TIDE_0"),
		severe_alerts("severe.alerts"),
		severe_stormcells("severe.stormcells"),
		severe_stormreports("severe.stormreports"),
		severe_lightning("severe.lightning"),
		severe_lightning_all("severe.lightning.all"),
		severe_lightning_flash("severe.lightning.flash"),
		severe_lightning_threats("severe.lightning.threats"),
		severe_hail_threats("severe.hail.threats"),
		severe_convective("severe.convective"),
		severe_hail_MESH_POSH_us("severe.hail.MESH:POSH.us"),
		severe_hail_MESH_POSH_europe("severe.hail.MESH:POSH.europe"),
		severe_hail_MESH_POSH_japan("severe.hail.MESH:POSH.japan"),
		severe_hail_MESH_POSH_australia("severe.hail.MESH:POSH.australia"),
		severe_lightning_LGT_IC_LGT_CG_us("severe.lightning.LGT-IC:LGT-CG.us"),
		severe_lightning_LGT_IC_LGT_CG_europe("severe.lightning.LGT-IC:LGT-CG.europe"),
		severe_lightning_LGT_IC_LGT_CG_japan("severe.lightning.LGT-IC:LGT-CG.japan"),
		severe_lightning_LGT_IC_LGT_CG_australia("severe.lightning.LGT-IC:LGT-CG.australia"),
		fires_obs("fires.obs"),
		fires_perimeter("fires.perimeter"),
		fires_outlook("fires.outlook"),
		drought("drought"),
		earthquakes("earthquakes"),
		rivers("rivers"),
		tropical_active("tropical.active"),
		tropical_archive("tropical.archive"),
		tropical_invests("tropical.invests"),
		roadweather_nowcast_us("roadweather.nowcast.us"),
		roadweather_nowcast_europe("roadweather.nowcast.europe"),
		roadweather_nowcast_japan("roadweather.nowcast.japan"),
		roadweather_nowcast_australia("roadweather.nowcast.australia"),
		roadweather_nowcast_new_zealand("roadweather.nowcast.new_zealand"),
		roadweather_forecast_us("roadweather.forecast.us"),
		roadweather_forecast_europe("roadweather.forecast.europe"),
		roadweather_forecast_japan("roadweather.forecast.japan"),
		roadweather_forecast_australia("roadweather.forecast.australia"),
		roadweather_forecast_new_zealand("roadweather.forecast.new_zealand"),
		satellite_infrared("satellite.infrared"),
		satellite_infrared_color("satellite.infrared_color"),
		satellite_visible("satellite.visible"),
		satellite_water_vapor("satellite.water_vapor"),
		satellite_geocolor("satellite.geocolor")
    }

    fun base_osm(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.base_osm.toString(),
		code = "open-street-map"
		)
	}
	
	fun base_cities(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.base_cities.toString(),
		code = "base.cities"
		)
	}
	
	fun conditions_TMP2_UGRD10_VGRD10(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_TMP2_UGRD10_VGRD10)
	}
	
	fun conditions_TMP2_DELTA(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_TMP2_DELTA)
	}
	
	fun conditions_TMP2_DPT2_RH2(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_TMP2_DPT2_RH2)
	}
	
	fun conditions_APTMP2_DPT2_RH2(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_APTMP2_DPT2_RH2)
	}
	
	fun conditions_PRMSL_VIS_GUST10(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_PRMSL_VIS_GUST10)
	}
	
	fun conditions_SNOD(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_SNOD)
	}
	
	fun conditions_TCDC_PRECIP_UVI(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_TCDC_PRECIP_UVI)
	}
	
	fun conditions_PTYPE_PRECIP_TMP2(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_PTYPE_PRECIP_TMP2)
	}
	
	fun conditions_PRECIP(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_PRECIP)
	}
	
	fun conditions_SNOW_PRECIP_TMP2(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.conditions_SNOW_PRECIP_TMP2)
	}
	
	@Deprecated("Use radar_REFC_PTYPESMPL_REFC_ARCHIVE")
	fun radar_REFC_PRATE_PTYPESMPL(service: WeatherService): EncodedSourceDescriptor {
		// Legacy alias — same datasets as the archive-backed radar composite.
		return radar_REFC_PTYPESMPL_REFC_ARCHIVE(service)
	}

	fun radar_REFC_PTYPESMPL_REFC_ARCHIVE(service: WeatherService): EncodedSourceDescriptor {
		return service.makeEncodedSourceDescriptor(DatasetGroups.radar_REFC_PTYPESMPL_REFC_ARCHIVE)
	}

	/** True when [id] is a radar encoded source that needs padBitmapRadar / multiband path. */
	fun isRadarEncodedSourceId(id: String): Boolean =
		id == SourceCode.radar_REFC_PTYPESMPL_REFC_ARCHIVE.name ||
			id == SourceCode.radar_REFC_PRATE_PTYPESMPL.name
	
	fun airquality_points(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.airquality_points.toString(),
		code = "air-quality"
		)
	}
	
	fun airquality_AQI_AirNow_PM2P5_PM10(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.airquality_AQI_AirNow_PM2P5_PM10)
	}
	
	fun airquality_AQI_AQHI_AQI_China_AQI_India(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.airquality_AQI_AQHI_AQI_China_AQI_India)
	}
	
	fun airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.airquality_AQI_EAQI_AQI_UBA_DAQI_AQI_UK_DAQI)
	}
	
	fun airquality_AQI_CAI_AQI_CAQI(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.airquality_AQI_CAI_AQI_CAQI)
	}
	
	fun airquality_CO_NO_NO2(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.airquality_CO_NO_NO2)
	}
	
	fun airquality_O3_SO2(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.airquality_O3_SO2)
	}
	
	fun maritime_HTSGW_DIRPW_PERPW(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.maritime_HTSGW_DIRPW_PERPW)
	}
	
	fun maritime_SWELL1_SWPER1_SWDIR1(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.maritime_SWELL1_SWPER1_SWDIR1)
	}
	
	fun maritime_SWELL2_SWPER2_SWDIR2(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.maritime_SWELL2_SWPER2_SWDIR2)
	}
	
	fun maritime_SWELL3_SWPER3_SWDIR3(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.maritime_SWELL3_SWPER3_SWDIR3)
	}
	
	fun maritime_WTMP_UOGRD_VOGRD(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.maritime_WTMP_UOGRD_VOGRD)
	}
	
	fun maritime_SURGE_TIDE(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.maritime_SURGE_TIDE)
	}
	
	fun severe_alerts(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.severe_alerts.toString(),
		code = "alerts"
		)
	}
	
	fun severe_stormcells(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.severe_stormcells.toString(),
		code = "stormcells"
		)
	}
	
	fun severe_stormreports(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.severe_stormreports.toString(),
		code = "stormreports"
		)
	}
	
	fun severe_lightning(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.severe_lightning.toString(),
		code = "lightning-strikes"
		)
	}
	
	fun severe_lightning_all(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.severe_lightning_all.toString(),
		code = "lightning-all"
		)
	}
	
	fun severe_lightning_flash(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.severe_lightning_flash.toString(),
		code = "lightning-flash"
		)
	}
	
	fun severe_lightning_threats(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.severe_lightning_threats.toString(),
		code = "lightning-threat-zones"
		)
	}
	
	fun severe_hail_threats(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.severe_hail_threats.toString(),
		code = "hail-threats-nowcast"
		)
	}
	
	fun severe_convective(service: WeatherService): GeoJSONSourceDescriptor {
		return service.makeGeoJSONSourceDescriptor(
		id = SourceCode.severe_convective.toString(),
		route = "/convective/outlook/search",
		params = mapOf("filter" to "cat")
		)
	}
	
	fun severe_hail_MESH_POSH_us(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.severe_hail_MESH_POSH_us)
	}
	
	fun severe_hail_MESH_POSH_europe(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.severe_hail_MESH_POSH_europe)
	}
	
	fun severe_hail_MESH_POSH_japan(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.severe_hail_MESH_POSH_japan)
	}
	
	fun severe_hail_MESH_POSH_australia(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.severe_hail_MESH_POSH_australia)
	}
	
	fun severe_lightning_LGT_IC_LGT_CG_us(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.severe_lightning_LGT_IC_LGT_CG_us)
	}
	
	fun severe_lightning_LGT_IC_LGT_CG_europe(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.severe_lightning_LGT_IC_LGT_CG_europe)
	}
	
	fun severe_lightning_LGT_IC_LGT_CG_japan(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.severe_lightning_LGT_IC_LGT_CG_japan)
	}
	
	fun severe_lightning_LGT_IC_LGT_CG_australia(service: WeatherService): EncodedSourceDescriptor {
		return  service.makeEncodedSourceDescriptor(DatasetGroups.severe_lightning_LGT_IC_LGT_CG_australia)
	}
	
	fun fires_obs(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.fires_obs.toString(),
		code = "fires-obs-points"
		)
	}
	
	fun fires_perimeter(service: WeatherService): GeoJSONSourceDescriptor {
		return service.makeGeoJSONSourceDescriptor(
		id = SourceCode.fires_perimeter.toString(),
		route = "/fires/search",
		params = mapOf("query" to "area:1", "filter" to "all,geo", "limit" to "1000")
		)
	}
	
	fun fires_outlook(service: WeatherService): GeoJSONSourceDescriptor {
		return service.makeGeoJSONSourceDescriptor(
		id = SourceCode.fires_outlook.toString(),
		route = "/fires/outlook/search",
		params = mapOf("filter" to "firewx")
		)
	}
	
	fun drought(service: WeatherService): GeoJSONSourceDescriptor {
		return service.makeGeoJSONSourceDescriptor(
		id = SourceCode.drought.toString(),
		route = "/droughts/monitor/search",
		params = mapOf("filter" to "all,geo", "sort" to "code")
		)
	}
	
	fun earthquakes(service: WeatherService): GeoJSONSourceDescriptor {
		return service.makeGeoJSONSourceDescriptor(
		id = SourceCode.earthquakes.toString(),
		route = "/earthquakes/search",
		params = mapOf(
			"query" to "mag:0",
			"limit" to "1000",
			// Rolling window — not timeline bounds (a 4h animation range often has zero events).
			"from" to "-7days",
			"to" to "now",
		)
		)
	}
	
	fun rivers(service: WeatherService): VectorSourceDescriptor {
		return service.makeAmpVectorSourceDescriptor(
		id = SourceCode.rivers.toString(),
		code = "river-observations"
		)
	}
	
	fun tropical_active(service: WeatherService): GeoJSONSourceDescriptor {
		return service.makeGeoJSONSourceDescriptor(
		id = SourceCode.tropical_active.toString(),
		route = "/tropicalcyclones/archive/search",
		params = mapOf("filter" to "active,dateline", "limit" to 1000)
		)
	}
	
	fun tropical_archive(service: WeatherService): GeoJSONSourceDescriptor {
		return service.makeGeoJSONSourceDescriptor(
		id = SourceCode.tropical_archive.toString(),
		route = "/tropicalcyclones/archive/search",
		params = mapOf("filter" to "active;notactive,dateline", "limit" to 1000)
		)
	}
	
	fun tropical_invests(service: WeatherService): GeoJSONSourceDescriptor {
		return service.makeGeoJSONSourceDescriptor(
		id = SourceCode.tropical_invests.toString(),
		route = "/tropicalcyclones/archive/search",
		params = mapOf("filter" to "invests", "limit" to 1000)
		)
	}
	
	fun roadweather_nowcast_us(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_nowcast_us.toString(),
		code = "road-wx-nowcast-us"
		)
	}
	
	fun roadweather_nowcast_europe(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_nowcast_europe.toString(),
		code = "road-wx-nowcast-europe"
		)
	}
	
	fun roadweather_nowcast_japan(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_nowcast_japan.toString(),
		code = "road-wx-nowcast-japan"
		)
	}
	
	fun roadweather_nowcast_australia(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_nowcast_australia.toString(),
		code = "road-wx-nowcast-australia"
		)
	}
	
	fun roadweather_nowcast_new_zealand(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_nowcast_new_zealand.toString(),
		code = "road-wx-nowcast-new-zealand"
		)
	}
	
	fun roadweather_forecast_us(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_forecast_us.toString(),
		code = "road-wx-forecast-us"
		)
	}
	
	fun roadweather_forecast_europe(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_forecast_europe.toString(),
		code = "road-wx-forecast-europe"
		)
	}
	
	fun roadweather_forecast_japan(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_forecast_japan.toString(),
		code = "road-wx-forecast-japan"
		)
	}
	
	fun roadweather_forecast_australia(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_forecast_australia.toString(),
		code = "road-wx-forecast-australia"
		)
	}
	
	fun roadweather_forecast_new_zealand(service: WeatherService): VectorSourceDescriptor {
		return service.makeVectorSourceDescriptor(
		id = SourceCode.roadweather_forecast_new_zealand.toString(),
		code = "road-wx-forecast-new-zealand"
		)
	}
	
	fun satellite_infrared(service: WeatherService): ImageSourceDescriptor {
		return service.makeRasterSourceDescriptor(id = SourceCode.satellite_infrared.toString(), code = "satellite")
	}
	
	fun satellite_infrared_color(service: WeatherService): ImageSourceDescriptor {
		return service.makeRasterSourceDescriptor(id = SourceCode.satellite_infrared_color.toString(), code = "satellite-infrared-color")
	}
	
	fun satellite_visible(service: WeatherService): ImageSourceDescriptor {
		return service.makeRasterSourceDescriptor(id = SourceCode.satellite_visible.toString(), code = "satellite-visible")
	}
	
	fun satellite_water_vapor(service: WeatherService): ImageSourceDescriptor {
		return service.makeRasterSourceDescriptor(id = SourceCode.satellite_water_vapor.toString(), code = "satellite-water-vapor")
	}
	
	fun satellite_geocolor(service: WeatherService): ImageSourceDescriptor {
		return service.makeRasterSourceDescriptor(id = SourceCode.satellite_geocolor.toString(), code = "satellite-geocolor")
	}
}