//
//  TimeSeriesOperationLayers.kt
//
//  Hand-written companion to the generated Sources.kt and weather groups, like
//  TemporaryManualSources.kt. Not auto-generated; safe to edit.
//

package com.xweather.mapsgl.weather

import com.xweather.mapsgl.data.series.EncodedRasterOperations
import com.xweather.mapsgl.data.series.TimeSeriesOperationSpec
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode

// Implementation notes. EncodedRasterOperations has folded MAX and MIN since the operation engine
// landed, and its unit tests cover both, but no layer declared either one — so only the SUM half
// (the `*-accum` layers in ManualAccumLayers) was reachable from the public API. This wires the
// extrema products. Two things differ from the accumulation layers, and both follow from what an
// extremum is:
//
// - No TimeSeriesOperationSpec.remappedDataRange. A sum outgrows its source range — 48 hours of
//   precipitation will not fit in a one-hour rate scale — so the accumulation layers re-encode into
//   a wider range. The hottest temperature in a series is still a temperature, so extrema re-encode
//   into the source range and read against the hourly layer's own colorscale and legend.
// - No interval-duration weighting. A 3-hour gap contributes 3x to a sum; it does not make a
//   reading three times hotter. EncodedRasterOperations.Accumulator.add already applies
//   `valueMultiplier` rather than the time weight on the MAX/MIN path, so nothing is needed here
//   beyond leaving the multiplier alone.

/**
 * Time-series operation products, added with [addOperationLayer].
 *
 * Each folds every interval in the loaded timeline range per pixel, so a frame shows the total or
 * extreme through that moment. [PRECIP_ACCUM] sums and re-encodes into a wider range; the MAX / MIN
 * products re-encode into the hourly product's own range, so they read against its colour scale and
 * legend, and take no interval-duration weighting.
 *
 * @property value MapsGL product id, e.g. `"temperatures-max"`.
 * @property layerId Id of the layer [addOperationLayer] adds for this product.
 */
public enum class OperationLayerCode(
    public val value: String,
    public val layerId: String,
) {
    /** Running total precipitation across the loaded range. */
    PRECIP_ACCUM("precip-accum", "conditions.precip_accum.fill"),

    // snow-accum is deliberately absent: its source declares bandsPerValue = 3 while its third
    // dataset is temperature, a discriminator rather than the low byte of the quantity, so the
    // decoder folds the temperature byte into the snowfall total and every pixel on earth reads as
    // roughly ten inches of snow per interval against a 0.1 inch draw floor. Snow depth has to be
    // derived per interval from precipitation and temperature before it can be summed, which is
    // XMAPSGLSDK-309. Put this entry and its descriptorsFor branch back once that lands.

    /** Highest temperature reached at each pixel over the loaded range. */
    TEMPERATURES_MAX("temperatures-max", "conditions.temperatures_max.fill"),

    /** Lowest temperature reached at each pixel over the loaded range. */
    TEMPERATURES_MIN("temperatures-min", "conditions.temperatures_min.fill"),

    /** Strongest wind gust at each pixel over the loaded range. */
    WIND_GUSTS_MAX("wind-gusts-max", "conditions.wind_gusts_max.fill"),
    ;

    /** True when this product is a running sum. */
    public val isAccumulation: Boolean
        get() = this == PRECIP_ACCUM

    public companion object {
        /** Looks up a code by its MapsGL product id, or `null` when it is not an operation layer. */
        public fun from(value: String): OperationLayerCode? =
            entries.firstOrNull { it.value == value }
    }
}

/** Sources and layers for the extrema operation products. */
internal object ManualOperationLayers {

    /** Top of the gust dataset range, in m/s — see [WindGustDataset]. */
    private const val WIND_GUST_MAX = 53.64

    /**
     * An encoded source whose intervals fold to a running extremum.
     *
     * The id must differ from the hourly product's. The fold rewrites decoded pixels in place, so a
     * layer that wants the raw intervals must not share the cache entry — the same reasoning, and
     * the same id shape, as [ManualAccumLayers].
     */
    private fun extremaSource(
        service: WeatherService,
        id: String,
        datasets: List<EncodedDataset>,
        operation: EncodedRasterOperations.Operation,
    ): EncodedSourceDescriptor =
        service.makeEncodedSourceDescriptor(EncodedDataGroup(id = id, datasets = datasets)).apply {
            this.operation = TimeSeriesOperationSpec(
                operation = operation,
                // One value in one band: unlike precip, temperature and gust are not spread over rgb.
                bandsPerValue = 1,
                // Deliberately absent; see the class doc.
                remappedDataRange = null,
            )
        }

    private fun temperatureExtreme(
        service: WeatherService,
        code: OperationLayerCode,
        operation: EncodedRasterOperations.Operation,
    ): Pair<EncodedSourceDescriptor, SampleLayerDescriptor> {
        val dataset = TemperatureDataset()
        val source = extremaSource(
            service,
            id = "conditions_" + code.name,
            datasets = listOf(dataset),
            operation = operation,
        )
        val layer = SampleLayerDescriptor(
            code.layerId,
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    // A running extremum must not blend encoded frames: the mix is not an extremum.
                    meld = false,
                    // The hourly Temperature ramp over the hourly layer's range. addWeatherLayer
                    // fills that range in from the dataset; addOperationLayer does not, and without
                    // it the ramp spans its own stops and draws every value warmer than the hourly
                    // layer and JS (XMAPSGLSDK-444).
                    colorScale = ColorScaleOptions(
                        ColorScales.temperature.stops,
                        range = dataset.dataRange,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        return source to layer
    }

    /** `temperatures-max`: the highest temperature reached across the loaded range. */
    public fun temperaturesMax(
        service: WeatherService,
    ): Pair<EncodedSourceDescriptor, SampleLayerDescriptor> =
        temperatureExtreme(
            service,
            OperationLayerCode.TEMPERATURES_MAX,
            EncodedRasterOperations.Operation.MAX,
        )

    /** `temperatures-min`: the lowest temperature reached across the loaded range. */
    public fun temperaturesMin(
        service: WeatherService,
    ): Pair<EncodedSourceDescriptor, SampleLayerDescriptor> =
        temperatureExtreme(
            service,
            OperationLayerCode.TEMPERATURES_MIN,
            EncodedRasterOperations.Operation.MIN,
        )

    /** `wind-gusts-max`: the strongest gust across the loaded range. */
    public fun windGustsMax(
        service: WeatherService,
    ): Pair<EncodedSourceDescriptor, SampleLayerDescriptor> {
        val source = extremaSource(
            service,
            id = "conditions_" + OperationLayerCode.WIND_GUSTS_MAX.name,
            datasets = listOf(WindGustDataset()),
            operation = EncodedRasterOperations.Operation.MAX,
        )
        val layer = SampleLayerDescriptor(
            OperationLayerCode.WIND_GUSTS_MAX.layerId,
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red),
                    interpolation = InterpolationMode.BICUBIC,
                    meld = false,
                    // The hourly wind-gusts ramp, as JS's wind-gusts-max uses. A private ramp here read
                    // a 13 m/s gust as pale blue where JS shows orange (XMAPSGLSDK-444).
                    colorScale = ColorScaleOptions(
                        stops = ColorScales.windSpeed.stops,
                        range = 0.0..WIND_GUST_MAX,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        return source to layer
    }

    /** The source and layer for [code], ready to register. */
    public fun descriptorsFor(
        code: OperationLayerCode,
        service: WeatherService,
    ): Pair<EncodedSourceDescriptor, SampleLayerDescriptor> = when (code) {
        OperationLayerCode.PRECIP_ACCUM -> ManualAccumLayers.precipAccum(service)
        OperationLayerCode.TEMPERATURES_MAX -> temperaturesMax(service)
        OperationLayerCode.TEMPERATURES_MIN -> temperaturesMin(service)
        OperationLayerCode.WIND_GUSTS_MAX -> windGustsMax(service)
    }
}

/**
 * Adds one of the time-series operation layers.
 *
 * These have no [LayerCode], so they cannot go through `addWeatherLayer`; this mirrors
 * [MapController.addRasterLayer]. For precip-accum it replaces [addAccumLayer]; snow-accum is
 * reachable only through `addAccumLayer` and is not yet correct.
 *
 * ```kotlin
 * mapController.addOperationLayer(OperationLayerCode.TEMPERATURES_MAX)
 * ```
 *
 * @param code Which operation product to add.
 * @param beforeId Existing layer id to insert **below**; `null` appends on top.
 * @return The new [TileLayer], or `null` if it could not be added.
 */
public fun MapController.addOperationLayer(
    code: OperationLayerCode,
    beforeId: String? = null,
): TileLayer? {
    val (source, layer) = ManualOperationLayers.descriptorsFor(code, service)
    addSource(source)
    // addWeatherLayer sets the controller zoomOffset to 0 before addLayer; this path used to leave
    // the -1 default, so an operation layer rendered a whole zoom coarser than the hourly layer it
    // is read against. Retention is now bounded (fold each chronological chunk, promote those
    // pixels off the Java heap, at most one decoded chunk and three in-flight tile series), so
    // the hourly offset is safe.
    return addLayer(layer, beforeId)?.also { it.zoomOffset = 0 }
}
