package com.xweather.mapsgl.weather.common

import android.annotation.SuppressLint
import android.icu.text.SimpleDateFormat
import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.mapbox.geojson.Feature
import com.mapbox.maps.QueriedRenderedFeature
import java.util.Date
import java.util.Locale
import kotlin.math.abs


enum class PresentationType {
    ACCUM_PRECIP, ALERTS, ANGLE,
    /** Maritime wave/swell gridded layers only ([MaritimeGriddedArrows]): +180° before [Units.degToDir] (N↔S, E↔W). */
    ANGLE_REVERSED,
    BASIC, CONVECTIVE, DIRECTION, DISTANCE, DROUGHT, EARTHQUAKE, FIRE_OUTLOOK, TROPICAL_CYCLONE,
    HEIGHT, HEIGHT_CHANGE, HUMIDITY, INDEX, LIGHTNING_DENSITY, PERIOD, PERCENTAGE, POINTS, POLLUTANT, PRECIPITATION,
    PRESSURE, RADAR, RIVER_OBSERVATION, SIZE, SNOW_DEPTH, SNOWFALL, STORM_CELL, STORM_REPORT, TEMPERATURE,
    TEMPERATURE_CHANGE, THREAT, WAVE_HEIGHT, WILDFIRE, WIND_GUST, WIND_SPEED,
    /**
     * Compass string for [com.xweather.mapsgl.types.SampleExpression.ENCODED_WIND_UV] / instanced gridded arrows.
     * [value] is vertex **rotDeg** (vector blend of phases on GPU), not raw atan2(u,-v). Do not use [DIRECTION].
     */
    GRIDDED_ENC_WIND_UV_DIRECTION,
}

object Units {
    fun CtoF(celsius: Double): Double = celsius * 9.0 / 5.0 + 32.0
    fun CtoF(celsius: Number): Double = celsius.toDouble() * 9.0 / 5.0 + 32.0
    fun CtoFUnit(celsius: Double): Double = celsius * 9.0 / 5.0 // Assuming this is for change, so no +32
    fun msToKph(ms: Number): Double = ms.toDouble() * 3.6
    fun msToKph(ms: Double): Double = ms * 3.6
    fun msToMph(ms: Double): Double = ms * 2.23694
    fun msToMph(ms: Number): Double = ms.toDouble() * 2.23694
    fun degToDir(degrees: Double): String {
        val directions = listOf(
            "↓ N",
            "↓ NNE",
            "↙ NE",
            "← ENE",
            " ← E",
            "← ESE",
            "↖ SE",
            "↑ SSE",
            "↑ S",
            "↑ SSW",
            "↗ SW",
            "→ WSW",
            "→ W",
            "→ WNW",
            "↘ NW",
            "↓ NNW"
        )
        val index = ((degrees % 360 + 360) % 360 / 22.5).toInt()
        return directions[index]
    }

    fun degToDir(degrees: Float): String {
        return degToDir(degrees.toDouble())
    }

    /**
     * [vertexRotDeg] is the instanced-vertex rotation (after per-phase atan2(u,-v) → unit vectors → mix → atan2),
     * same as [com.xweather.mapsgl.layers.tile.EncodedTileLayer] returns for [SampleExpression.ENCODED_WIND_UV].
     * Maps to compass-from-north for [degToDir] glyphs (north-up map).
     */
    fun degToDirForGriddedWindUv(vertexRotDeg: Double): String {
        val bearingFromNorth = (vertexRotDeg + 90.0 + 720.0) % 360.0
        return degToDir(bearingFromNorth)
    }

    fun mbToHg(mb: Double): Double = mb * 0.02953
    fun mToKm(meters: Double): Double = meters / 1000.0
    fun mToMi(meters: Double): Double = meters * 0.000621371
    fun mToFt(meters: Double): Double = meters * 3.28084
    fun mmToIn(mm: Double): Double = mm / 25.4
}


/**
 * Recursively retrieves a nested value from a JsonObject using a dot-notated key path.
 *
 * Example:
 *   val dir = json.getValueAtPath("details.movement.dir")?.asString
 */
fun JsonObject.getValueAtPath(keyPath: String): JsonElement? {
    val keys = keyPath.split(".")
    var currentElement: JsonElement? = this

    for (key in keys) {
        if (currentElement == null || !currentElement.isJsonObject) {
            return null
        }
        val obj = currentElement.asJsonObject
        currentElement = obj.get(key)
    }

    return currentElement
}

/**
 * Rule: custom-hit-test-presentation-shape. Normalizes a [Presentation.fn] argument to the features
 * it describes, whichever shape the inspector delivered.
 *
 * `value` is a `List<QueriedRenderedFeature>` when Mapbox's native `queryRenderedFeatures` found the
 * hit, but a plain `List<Feature>` when the custom hit-test fallback supplied it instead -- that is
 * the *only* shape GL-only / custom-mesh layers ever produce, because their style layers never exist
 * for Mapbox to query natively (see `MapboxMapController.hitTestCustomVectorGlCached`). Type erasure
 * lets `as List<QueriedRenderedFeature>` succeed for either, so a mismatch does not fail the cast --
 * it throws ClassCastException later, on element access, out of a tap handler.
 *
 * Returns an empty list for anything unrecognized, so callers can format unconditionally.
 */
internal fun queriedFeatures(value: Any?): List<Feature> =
    (value as? List<*>)?.mapNotNull {
        when (it) {
            is QueriedRenderedFeature -> it.queriedFeature.feature
            is Feature -> it
            else -> null
        }
    } ?: emptyList()

data class Presentation(
    val title: Any, // Can be String or (value: Any) -> String
    val alwaysShow: Boolean? = null,
    val fn: (value: Any) -> String // Consider more specific types if possible, e.g., (value: Number) or (value: Map<String, Double>)
) {
    fun setTitle(newTitle: Any): Presentation {
        return this.copy(title = newTitle)
    }

    /** String title, or the result of a `(value: Any) -> String` title function. */
    fun resolvedTitle(value: Any): String {
        return when (val t = title) {
            is String -> t
            is Function1<*, *> -> {
                @Suppress("UNCHECKED_CAST")
                (t as (Any) -> String)(value)
            }
            else -> t.toString()
        }
    }
}


private fun formatTropicalStormCategory(stormCat: String): String {
    var category = stormCat
    Regex("^H(\\d)").find(category)?.let { match ->
        category = "Cat ${match.groupValues[1]} Hurricane"
    }
    return when (category) {
        "LO" -> "Low"
        "I" -> "Invest"
        "TD" -> "Tropical Depression"
        "TS" -> "Tropical Storm"
        "TY" -> "Typhoon"
        "STY" -> "Super Typhoon"
        else -> category
    }
}

private fun formatTropicalInspectorDate(timestampSec: Long): String {
    val dateFormat = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.ENGLISH)
    return dateFormat.format(Date(timestampSec * 1000))
}

/**
 * Raw `ob.status` → the wording the River Observations legend uses, so the inspector, the legend and
 * the circle colours all name a gauge state the same way (the Apple SDK derives this from
 * `ColorScales.river`; Android carries the same pairs in [com.xweather.mapsgl.weather.LegendCode]'s
 * `RIVER_OBSERVATION` legend and `climate.river_obs.point`'s colour match).
 */
private val riverStatusLabels: Map<String, String> = mapOf(
    "out_of_service" to "Out of Service",
    "obs_not_current" to "Old Data",
    "not_defined" to "Unavailable",
    "low_threshold" to "Low Threshold",
    "no_flooding" to "No Flooding",
    "action" to "Action",
    "minor" to "Minor",
    "moderate" to "Moderate",
    "major" to "Major",
)

/** Falls back to a title-cased form of the raw value for statuses the legend doesn't define. */
private fun riverStatusLabel(status: String): String {
    val key = status.lowercase()
    return riverStatusLabels[key] ?: capitalizeFirstLetterOfEachWord(key.replace('_', ' '))
}

/**
 * Uppercases a storm short name's trailing single-character suffix (`"invest-a"` → `"invest-A"`),
 * which is what distinguishes concurrent systems in the same basin. Names without one are unchanged.
 * Ported from the Apple SDK's `tropicalCycloneDisplayName`.
 */
private fun tropicalCycloneDisplayName(name: String): String {
    if (name.length < 2) return name
    val last = name.last()
    if (!last.isLetterOrDigit() && last != '_') return name
    if (name[name.length - 2] != '-') return name
    return name.dropLast(1) + last.uppercaseChar()
}

private fun jsonString(obj: JsonObject?, key: String): String? {
    val el = obj?.get(key) ?: return null
    if (!el.isJsonPrimitive || !el.asJsonPrimitive.isString) return null
    return el.asString.trim().takeIf { it.isNotEmpty() }
}

/** Map labels use [details.stormShortName]; fall back to stormName / name, then the generic layer title. */
internal fun tropicalCycloneInspectorTitle(value: Any): String {
    for (feature in queriedFeatures(value)) {
        val properties = feature.properties() ?: continue
        val details = properties.get("details")?.takeIf { it.isJsonObject }?.asJsonObject
        val name = jsonString(details, "stormShortName")
            ?: jsonString(details, "stormName")
            ?: jsonString(properties, "name")
        if (name != null) return name
    }
    return "Tropical Cyclones"
}

private fun tropicalCycloneInspectorText(properties: com.google.gson.JsonObject): String {
    val featureType = properties.get("featureType")?.asString
    if (featureType == "errorCone") return ""

    val timestampSec = properties.get("timestamp")?.asDouble?.toLong()
        ?: (System.currentTimeMillis() / 1000)
    val details = properties.get("details")?.asJsonObject

    val lines = mutableListOf<String>()
    // Storm name first, matching the Apple/JS reference — without it the inspector showed only the
    // panel title ("Tropical Cyclones") and never identified which storm was tapped.
    details?.get("stormShortName")?.takeIf { it.isJsonPrimitive }?.asString
        ?.let { lines.add(tropicalCycloneDisplayName(it)) }
    val header = when (featureType) {
        "forecastPoint" -> "Forecast"
        else -> details?.get("advisoryNumber")?.takeIf { it.isJsonPrimitive }?.let { advisory ->
            // The MVT carries this as a number; asString on a double would render "9.0".
            val number = advisory.asJsonPrimitive.let { p -> if (p.isNumber) p.asDouble.toInt().toString() else p.asString }
            "Advisory #$number"
        }
    }
    if (!header.isNullOrEmpty()) lines.add(header)
    lines.add(formatTropicalInspectorDate(timestampSec))

    details?.get("stormCat")?.asString?.let { formatTropicalStormCategory(it) }?.let { lines.add(it) }

    val windKts = details?.get("windSpeedKTS")?.asDouble
    val windKph = details?.get("windSpeedKPH")?.asDouble
    val windMph = details?.get("windSpeedMPH")?.asDouble
    if (windMph != null && windKts != null) {
        val kphPart = windKph?.let { "${to1d(it)} kph" } ?: ""
        val windLine = buildString {
            append("${to1d(windKts)} knots")
            if (kphPart.isNotEmpty()) append(", $kphPart")
            append(", ${to1d(windMph)} mph")
        }
        lines.add(windLine)
    }

    return lines.joinToString("\n")
}

private fun capitalizeFirstLetterOfEachWord(input: String): String {
    val lowercasedInput = input.lowercase()
    // 2. Split the string into words. This regex handles multiple spaces between words.
    val words = lowercasedInput.split(Regex("\\s+")).filter { it.isNotEmpty() }

    // 3. Capitalize the first letter of each word and join them back.
    return words.joinToString(" ") { word ->
        if (word.isNotEmpty()) {
            word.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
        } else {
            ""
        }
    }
}

private fun to1d(number: Double, useLocale: Locale = Locale.US): String {
    if (number.isNaN()) {
        return "NaN"
    } else if (number.isInfinite()) {
        return if (number > 0) "Infinity" else "-Infinity"
    }
    return String.format(useLocale, "%.1f", number)
}

private fun to1d(number: Float, useLocale: Locale = Locale.US): String {
    if (number.isNaN()) {
        return "NaN"
    } else if (number.isInfinite()) {
        return if (number > 0) "Infinity" else "-Infinity"
    }
    return String.format(useLocale, "%.1f", number)
}

private fun to2d(number: Double, useLocale: Locale = Locale.US): String {
    if (number.isNaN()) {
        return "NaN"
    } else if (number.isInfinite()) {
        return if (number > 0) "Infinity" else "-Infinity"
    }

    return String.format(useLocale, "%.2f", number)
}

private fun to2d(number: Float, useLocale: Locale = Locale.US): String {
    if (number.isNaN()) {
        return "NaN"
    } else if (number.isInfinite()) {
        return if (number > 0) "Infinity" else "-Infinity"
    }

    return String.format(useLocale, "%.2f", number)
}

@SuppressLint("DefaultLocale")
@Suppress("UNCHECKED_CAST") // Suppress for direct porting, refine as needed
val presentations: Map<PresentationType, Presentation> = mapOf(
    PresentationType.TEMPERATURE to Presentation(
        title = "Temperature", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${to2d(value)}°C, ${to2d(Units.CtoF(value))}°F"
        }),

    PresentationType.TEMPERATURE_CHANGE to Presentation(
        title = "Temp Change2", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation "e1"
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation "e2"
            val prefix = if (value > 0) "+" else ""
            "$prefix${to1d(value)}°C, $prefix${to2d(Units.CtoFUnit(value))}°F"
        }),

    PresentationType.WIND_SPEED to Presentation(
        title = "Winds", fn = { features ->
            val m = features as? Map<*, *> ?: return@Presentation ""
            val speedMs = (m["value"] as? Number)?.toDouble()
            val angleDeg = (m["angle"] as? Number)?.toDouble()
            if (speedMs == null || speedMs.isNaN()) return@Presentation ""
            if (speedMs < 1e-6) return@Presentation "Calm"
            if (angleDeg == null || angleDeg.isNaN()) return@Presentation ""
            val adjustedAngle = angleDeg - 180
            "${Units.degToDir(adjustedAngle)} ${to1d(Units.msToKph(speedMs))} kph, ${to1d(Units.msToMph(speedMs))} mph"
        }),

    PresentationType.WIND_GUST to Presentation(
        title = "Wind Gusts", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            "${to1d(Units.msToKph(value))} kph, ${to1d(Units.msToMph(value))} mph"
        }),

    PresentationType.HUMIDITY to Presentation(
        title = "Humidity", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${kotlin.math.round(value)}%"
        }),

    PresentationType.PRESSURE to Presentation(
        title = "Surface Pressure", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${to1d(value)} mb, ${to2d(Units.mbToHg(value))} in"
        }),

    PresentationType.DISTANCE to Presentation(
        title = "Visibility", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""

            "${to1d(Units.mToKm(value))} km, ${to1d(Units.mToMi(value))} mi"
        }),

    PresentationType.HEIGHT to Presentation(
        title = "Wave Height", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${to1d(value)} m, ${to1d(Units.mToFt(value))} ft"
        }),

    PresentationType.DIRECTION to Presentation(
        title = "Direction", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            val angle = value - 180
            Units.degToDir(angle)
        }),

    PresentationType.GRIDDED_ENC_WIND_UV_DIRECTION to Presentation(
        title = "Direction", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            Units.degToDirForGriddedWindUv(value)
        }),

    PresentationType.ANGLE_REVERSED to Presentation(
        title = "Direction", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            val deg = (value % 360.0 + 360.0) % 360.0
            val swapped = (deg + 180.0) % 360.0
            Units.degToDir(swapped)
        }),

    PresentationType.PERIOD to Presentation(
        title = "Period", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            "${kotlin.math.round(value)} sec"
        }),

    PresentationType.HEIGHT_CHANGE to Presentation(
        title = "Height Change", fn = { features ->
            //val numValue = (value as? Number)?.toDouble() ?: 0.0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            val prefix = if (value > 0) "+" else ""
            "$prefix${to2d(value)} m, $prefix${to1d(Units.mToFt(value))} ft"
        }),

    PresentationType.RADAR to Presentation(
        title = "Radar", fn = { features ->
            //val numValue = (value as? Number)?.toDouble() ?: 0.0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            if (value < 5) return@Presentation ""

            val intensity = when {
                value >= 60 -> "Extreme/Hail"
                value >= 55 -> "Intense"
                value >= 45 -> "Heavy"
                value >= 35 -> "Moderate"
                value >= 25 -> "Light"
                else -> "Very Light"
            }
            "$intensity: ${to2d(value)} dbz"
        }),

    PresentationType.ACCUM_PRECIP to Presentation(
        title = "Accum Precip", fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            val mmValue = value * 3600 // Assuming input 'value' is mm/s if it needs *3600 to be mm
            "${to1d(mmValue)} mm, ${to2d(Units.mmToIn(mmValue))} in"
        }),

    /**
     * [Conditions.Precipitation] — parity with MapsGL JS / iOS [PresentationFormat.precipitation]:
     * if [unit] is `mm/sec` or `mm/s`, multiply [value] by 3600 then show mm and inches (2 dp);
     * otherwise show raw [value] (2 dp).
     */
    PresentationType.PRECIPITATION to Presentation(
        title = "Precip",
        fn = { features ->
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: return@Presentation ""
            var unitSymbol = featureMap["unit"] as? String
            var mmValue = value
            if (unitSymbol == "mm/sec" || unitSymbol == "mm/s") {
                mmValue *= 3600.0
                unitSymbol = "mm"
            }
            if (unitSymbol == "mm") {
                val inches = Units.mmToIn(mmValue)
                return@Presentation "${to2d(mmValue)}mm, ${to2d(inches)}in"
            }
            return@Presentation to2d(value)
        },
    ),

    PresentationType.SNOWFALL to Presentation(
        title = "Accum Snow", fn = { features ->
            //val numValue = (value as? Number)?.toDouble() ?: 0.0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            "${(to1d(value * 100))} cm, ${to1d((value * 39.3701))} in"
        }),

    PresentationType.SNOW_DEPTH to Presentation(
        title = "Snow Depth", fn = { features ->
            //val numValue = (value as? Number)?.toDouble() ?: 0.0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            "${(to1d(value))} m, ${to1d((value * 39.3701))} in"
        }),

    PresentationType.INDEX to Presentation(
        title = "AQI", fn = { features ->
            //val numValue = (value as? Number)?.toInt() ?: 0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toInt() ?: 0
            "${value}"
        }),

    PresentationType.POINTS to Presentation(
        title = "Air Quality", fn = { features ->
            //val numValue = (value as? Number)?.toInt() ?: 0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toInt() ?: 0.0
            "$value ug/m^3"
        }),

    PresentationType.POLLUTANT to Presentation(
        title = "", fn = { features ->
            //val numValue = (value as? Number)?.toInt() ?: 0
            val featureMap = features as? Map<*, *> ?: return@Presentation ""
            val value = (featureMap["value"] as? Number)?.toInt() ?: 0
            "$value ug/m^3"
        }),

    PresentationType.ALERTS to Presentation(
        title = "Alerts",
        // Rule: custom-hit-test-presentation-shape. `value` is a List<QueriedRenderedFeature> when
        // Mapbox's native queryRenderedFeatures finds a hit, but a plain List<Feature> when the
        // custom hit-test fallback (hitTestCustomVectorFillCached, used for GL-only/custom-mesh
        // layers like alerts) supplies it instead — the unconditional `as List<QueriedRenderedFeature>`
        // cast threw for every custom-hit-test hit, so tap-to-inspect silently produced nothing for
        // alerts specifically (its style layer never exists for Mapbox to query natively). Accept
        // either element shape.
        fn = { value ->
            val features = queriedFeatures(value)
            val names = features.mapNotNull {
                it.getStringProperty("ADVISORY")
            }.distinct().joinToString(separator = "\n") { advisory ->
                capitalizeFirstLetterOfEachWord(advisory)
            }
            names
        }),

    PresentationType.DROUGHT to Presentation(
        title = "Drought Monitor",
        fn = { value ->
            val features = queriedFeatures(value)

            val names = features.mapNotNull { feature ->
                feature.properties()
                    ?.get("details")?.asJsonObject
                    ?.get("risk")?.asJsonObject
                    ?.get("name")?.asString
            }.distinct() // Get only unique names if multiple features have the same one.
                .joinToString(separator = "\n") // Join them with a newline if there are multiple distinct names.
            names
        }),

    PresentationType.TROPICAL_CYCLONE to Presentation(
        title = { value: Any -> tropicalCycloneInspectorTitle(value) },
        fn = { value ->
            val features = value as? List<*> ?: return@Presentation ""
            val item = features.firstOrNull() ?: return@Presentation ""
            val properties = when (item) {
                is QueriedRenderedFeature -> item.queriedFeature.feature.properties()
                is Feature -> item.properties()
                else -> return@Presentation ""
            } ?: return@Presentation ""
            tropicalCycloneInspectorText(properties)
        }),

    PresentationType.EARTHQUAKE to Presentation(
        title = "Earthquakes", fn = { value ->
            val features = value as? List<*> ?: return@Presentation ""

            val names = features.mapNotNull { item ->
                val properties = when (item) {
                    is QueriedRenderedFeature -> item.queriedFeature.feature.properties()
                    is Feature -> item.properties()
                    else -> null
                } ?: return@mapNotNull null

                val report = properties.get("report")?.asJsonObject ?: return@mapNotNull null

                val magnitude = report.get("mag")?.asDouble
                val type = report.get("type")?.asString
                val region = report.get("region")?.asString

                if (magnitude != null && type != null && region != null) {
                    val formattedType = capitalizeFirstLetterOfEachWord(type)
                    "$magnitude ($formattedType - $region)"
                } else {
                    null
                }

            }.distinct().joinToString(separator = "\n\n")
            names
        }),

    PresentationType.LIGHTNING_DENSITY to Presentation(
        title = "Index", fn = { value ->
            val featureMap = value as? Map<*, *> ?: return@Presentation ""
            val strikeValue = (featureMap["value"] as? Number)?.toFloat() ?: 0f
            val strikes = maxOf(1f, kotlin.math.round(strikeValue))
            val strikeText = if (strikes == 1f) "strike" else "strikes"
            String.format("%.0f %s/hr", strikes, strikeText)
        }),

    PresentationType.PERCENTAGE to Presentation(
        title = "percentage", fn = { value ->
            val featureMap = value as? Map<*, *> ?: return@Presentation ""
            val numValue = (featureMap["value"] as? Number)?.toDouble() ?: 0.0
            val final = "${to1d(numValue)}%"
            final
        }),

    PresentationType.SIZE to Presentation(
        title = "Size", fn = { value ->
            val number = value as Float
            "${(to1d(number * 100))} cm, ${to1d((number * 39.3701))} in"
        }),

    PresentationType.CONVECTIVE to Presentation(
        title = "Convective Outlook", fn = { value ->
            val features = queriedFeatures(value)
            val names = features.mapNotNull { feature ->
                // Safely access the nested "type" property within "details" -> "risk"
                feature.properties()
                    ?.get("details")?.asJsonObject?.get("risk")?.asJsonObject?.get("type")?.asString
            }.distinct() // Equivalent to Swift's .unique()
                .joinToString(separator = "\n") { riskType ->
                    // Use the existing helper function to format the string
                    capitalizeFirstLetterOfEachWord(riskType)
                }
            names
        }),

    PresentationType.FIRE_OUTLOOK to Presentation(
        title = "Fire Outlook",
        // Rule: custom-hit-test-presentation-shape. `climate.fire_outlook.fill` draws from a
        // GeoJSON source via custom GL meshes, so its hits arrive from hitTestCustomGeoJsonPolygons
        // as a plain List<Feature>, never as List<QueriedRenderedFeature> -- Mapbox has no style
        // layer to query natively. Accept either element shape, as [PresentationType.ALERTS] does.
        // (Note [PresentationType.CONVECTIVE] reads the same `details.risk.type` payload but still
        // casts unconditionally, so it has this bug for its own custom-hit-test path.)
        fn = { value ->
            val features = queriedFeatures(value)
            features.mapNotNull {
                it.properties()?.getValueAtPath("details.risk.type")?.asString
            }.distinct().joinToString(separator = "\n") { riskType ->
                capitalizeFirstLetterOfEachWord(riskType)
            }
        }),

    PresentationType.RIVER_OBSERVATION to Presentation(
        title = "River Obs", // Updated title for clarity
        fn = { value ->
            val features = queriedFeatures(value)

            // Matches the Apple/JS reference: "<Waterbody> - <legend label>", first entry only.
            // Titlecasing the raw status showed wording the legend never uses ("Not Defined" for a
            // gauge the legend calls "Unavailable"), which is what QA compared against the demo.
            features.mapNotNull { feature ->
                val properties = feature.properties() ?: return@mapNotNull null
                val status = properties.get("ob")?.asJsonObject?.get("status")?.asString
                    ?: return@mapNotNull null
                val waterbody = properties.get("profile")?.asJsonObject?.get("waterbody")?.asString
                buildString {
                    if (!waterbody.isNullOrBlank()) append("${capitalizeFirstLetterOfEachWord(waterbody)} - ")
                    append(riverStatusLabel(status))
                }
            }.distinct().firstOrNull() ?: ""
        }),

    PresentationType.STORM_CELL to Presentation(
        title = "Storm Cells", fn = { value ->
            val features = queriedFeatures(value)

            // `traits.type` is the required part and `ob.movement.dirTo` the optional suffix, as in
            // the Apple/JS reference. Requiring `ob` first meant a cell whose tile carries only
            // `traits` (the common case at low zoom) produced nothing at all on tap.
            features.mapNotNull { feature ->
                val properties = feature.properties() ?: return@mapNotNull null
                val type = properties.get("traits")?.asJsonObject?.get("type")?.asString
                if (type.isNullOrEmpty()) return@mapNotNull null

                val moving = properties.get("ob")?.asJsonObject
                    ?.get("movement")?.asJsonObject
                    ?.get("dirTo")?.asString

                val formattedType = capitalizeFirstLetterOfEachWord(type)
                if (!moving.isNullOrEmpty()) "$formattedType, moving $moving" else formattedType
            }.distinct().firstOrNull() ?: ""
        }),
    /*
    PresentationType.STORM_CanREPORT to Presentation(
        title = "Storm Report", fn = { features ->
            ""
        }),
    */
    PresentationType.STORM_REPORT to Presentation(
        title = "Storm Reports", fn = { value ->
            val features = queriedFeatures(value)

            val names = features.mapNotNull { feature ->
                val properties = feature.properties() ?: return@mapNotNull null
                // Navigate: report -> type
                val reportObj = properties.get("report")?.asJsonObject
                val type = reportObj?.get("type")?.asString
                if (!type.isNullOrEmpty()) {
                    capitalizeFirstLetterOfEachWord(type)
                } else {
                    // Fallback: If 'type' is missing but 'cat' exists, use that
                    val cat = reportObj?.get("cat")?.asString
                    if (!cat.isNullOrEmpty()) capitalizeFirstLetterOfEachWord(cat) else null
                }
            }.distinct().joinToString(separator = "\n")
            if (names == "Snow") {
                "   Snow"
            } else {
                names
            }


        }),
    PresentationType.THREAT to Presentation(
        title = "Severe Threat", // You can adjust the title
        fn = { value ->
            val features = queriedFeatures(value)

            val names = features.mapNotNull { feature ->
                val properties = feature.properties()

                // 1. Guard for required properties, like in Swift.
                val movingDir =
                    properties?.get("details")?.asJsonObject?.get("movement")?.asJsonObject?.get("dir")?.asString
                        ?: return@mapNotNull null

                val movingSpeedKPH =
                    properties.get("details")?.asJsonObject?.get("movement")?.asJsonObject?.get("speedKPH")?.asDouble
                        ?: return@mapNotNull null

                val timestamp =
                    properties.get("period")?.asJsonObject?.get("range")?.asJsonObject?.get("minTimestamp")?.asDouble
                        ?: return@mapNotNull null

                val details = mutableListOf<String>()

                // 3. Format the date.
                val date = Date(timestamp.toLong() * 1000) // Convert seconds to milliseconds
                val dateFormat = SimpleDateFormat("MMM d, yyyy h:mm a", Locale.ENGLISH)
                details.add(dateFormat.format(date))

                val issuedAt = properties.get("details")?.asJsonObject?.get("issuedTimestamp")?.asDouble
                val periodStart =
                    properties.get("period")?.asJsonObject?.get("range")?.asJsonObject?.get("minTimestamp")?.asDouble
                        ?: issuedAt

                if (issuedAt != null && periodStart != null) {
                    val leadTimeMinutes = abs(periodStart - issuedAt).toInt() / 60
                    if (leadTimeMinutes > 0) {
                        details.add("+$leadTimeMinutes minute lead time")
                    }

                }

                // 5. Format the movement speed string using your existing Units object.
                val movingSpeedMPH = Units.msToMph(movingSpeedKPH / 3.6) // Convert KPH to MPH via m/s
                val formattedSpeed = String.format(
                    "Moving %s at %.0fkph (%.0fmph)", movingDir, movingSpeedKPH, movingSpeedMPH
                )
                details.add(formattedSpeed)

                // 6. Join all details with a newline.
                details.joinToString("\n")
            }.distinct() // .unique() in Kotlin

            // 7. Return the first unique entry, or an empty string.
            names.firstOrNull() ?: ""
        }),

    PresentationType.WILDFIRE to Presentation(
        title = "Fires", fn = { value ->
            val items = value as? List<*> ?: return@Presentation ""

            val entries = items.mapNotNull { item ->
                val properties = when (item) {
                    is QueriedRenderedFeature -> item.queriedFeature.feature.properties()
                    is Feature -> item.properties()
                    else -> null
                } ?: return@mapNotNull null

                // 1. Get the 'report' object first, as it contains all the info we need.
                val report = properties.get("report")?.asJsonObject ?: return@mapNotNull null

                // 2. Extract required values safely from the 'report' object.
                val name = report.get("name")?.asString ?: "Unknown Fire"
                val areaAC = report.get("areaAC")?.asDouble
                val perContained = report.get("perContained")?.asDouble

                val details = mutableListOf<String>()

                // 3. Process and format the 'areaAC' value if it exists.
                if (areaAC != null && areaAC.isFinite()) {
                    val area = maxOf(areaAC, 1.0)
                    // Format the number to have 0 decimal places.
                    val formattedArea = String.format(Locale.US, "%.0f", area)
                    val unit = if (area > 1) "acres" else "acre"
                    details.add("$formattedArea $unit")

                    // 4. Process and format the 'perContained' value if it exists.
                    if (perContained != null && perContained.isFinite()) {
                        details.add(String.format(Locale.US, "(%.0f%% contained)", perContained))
                    }
                }

                // 5. Build the final display string.
                val detailsString = if (details.isNotEmpty()) {
                    " - " + details.joinToString(" ")
                } else {
                    "" // No details if area is not found
                }

                "$name$detailsString"

            }.distinct()

            entries.firstOrNull() ?: ""
        })
)