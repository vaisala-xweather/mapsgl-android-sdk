//
//  LayerCodes.kt
//
//  NOTE: This file is auto-generated and should not be edited directly!
//  Last updated: 2026-03-12T20:12:16.317Z
//

@file:Suppress("FunctionName")

package com.xweather.mapsgl.weather

import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.ContourLayerDescriptor
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.GridLayerDescriptor
import com.xweather.mapsgl.layers.spec.HeatmapLayerDescriptor
import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.RasterLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.weather.groups.Admin
import com.xweather.mapsgl.weather.groups.Climate
import com.xweather.mapsgl.weather.groups.Conditions
import com.xweather.mapsgl.weather.groups.Maritime
import com.xweather.mapsgl.weather.groups.Raster
import com.xweather.mapsgl.weather.groups.Severe
import com.xweather.mapsgl.weather.groups.Tropical

enum class LayerCode(
    val value: String,
) {
    ADMIN_2_BOUNDARIES("admin-2-boundaries"),
    ADMIN_3_4_BOUNDARIES("admin-3-4-boundaries"),
    ADMIN_5_6_BOUNDARIES("admin-5-6-boundaries"),
    AIR_QUALITY("air-quality"),
    CARBON_MONOXIDE("air-quality-co"),
    AIR_QUALITY_HEALTH_INDEX_CATEGORIES("air-quality-health-index-categories"),
    AIR_QUALITY_INDEX("air-quality-index"),
    AIR_QUALITY_INDEX_CAI_CATEGORIES("air-quality-index-cai-categories"),
    AIR_QUALITY_INDEX_CAQI_CATEGORIES("air-quality-index-caqi-categories"),
    AIR_QUALITY_INDEX_CATEGORIES("air-quality-index-categories"),
    AIR_QUALITY_INDEX_CHINA_CATEGORIES("air-quality-index-china-categories"),
    AIR_QUALITY_INDEX_EAQI_CATEGORIES("air-quality-index-eaqi-categories"),
    AIR_QUALITY_INDEX_INDIA_CATEGORIES("air-quality-index-india-categories"),
    AIR_QUALITY_INDEX_UBA_DAQI_CATEGORIES("air-quality-index-uba-daqi-categories"),
    AIR_QUALITY_INDEX_UK_DAQI_CATEGORIES("air-quality-index-uk-daqi-categories"),
    NITRIC_OXIDE("air-quality-no"),
    NITROGEN_DIOXIDE("air-quality-no2"),
    OZONE("air-quality-o3"),
    PARTICULATE_MATTER_10_MICRON("air-quality-pm10"),
    PARTICULATE_MATTER_2P5_MICRON("air-quality-pm2p5"),
    SULFUR_DIOXIDE("air-quality-so2"),
    ALERTS("alerts"),
    ALERTS_OUTLINE("alerts-outline"),
    BOUNDARIES("boundaries"),
    CLOUD_COVER("cloud-cover"),
    CONVECTIVE("convective"),
    CONVECTIVE_OUTLINE("convective-outline"),
    DEW_POINTS("dew-points"),
    DROUGHT_MONITOR("drought-monitor"),
    DROUGHT_MONITOR_OUTLINE("drought-monitor-outline"),
    EARTHQUAKES("earthquakes"),
    EARTHQUAKES_HEAT("earthquakes-heat"),
    FEELS_LIKE("feels-like"),
    FIRES("fires"),
    FIRES_ICONS("fires-icons"),
    FIRES_OBS("fires-obs"),
    FIRES_OBS_HEAT("fires-obs-heat"),
    FIRES_OBS_ICONS("fires-obs-icons"),
    FIRES_OBS_NAMES("fires-obs-names"),
    FIRES_OUTLOOK("fires-outlook"),
    FIRES_PERIMETER("fires-perimeter"),
    HAIL_SEVERE_PROBABILITY("hail-severe-probability"),
    HAIL_SEVERE_PROBABILITY_AUSTRALIA("hail-severe-probability-australia"),
    HAIL_SEVERE_PROBABILITY_EUROPE("hail-severe-probability-europe"),
    HAIL_SEVERE_PROBABILITY_JAPAN("hail-severe-probability-japan"),
    HAIL_SEVERE_PROBABILITY_UNITED_STATES("hail-severe-probability-us"),
    HAIL_SIZE("hail-size"),
    HAIL_SIZE_AUSTRALIA("hail-size-australia"),
    HAIL_SIZE_EUROPE("hail-size-europe"),
    HAIL_SIZE_JAPAN("hail-size-japan"),
    HAIL_SIZE_UNITED_STATES("hail-size-us"),
    HAIL_THREATS("hail-threats"),
    HAIL_THREATS_POINTS("hail-threats-points"),
    HAIL_THREATS_POLYGONS("hail-threats-polygons"),
    HAIL_THREATS_TRACKS("hail-threats-tracks"),
    HEAT_INDEX("heat-index"),
    HUMIDITY("humidity"),
    LAND("land"),
    LIGHTNING_ALL("lightning-all"),
    LIGHTNING_ALL_ICONS("lightning-all-icons"),
    LIGHTNING_DENSITY("lightning-density"),
    LIGHTNING_DENSITY_AUSTRALIA("lightning-density-australia"),
    LIGHTNING_DENSITY_CLOUD_TO_GROUND("lightning-density-cloud-to-ground"),
    LIGHTNING_DENSITY_CLOUD_TO_GROUND_AUSTRALIA("lightning-density-cloud-to-ground-australia"),
    LIGHTNING_DENSITY_CLOUD_TO_GROUND_EUROPE("lightning-density-cloud-to-ground-europe"),
    LIGHTNING_DENSITY_CLOUD_TO_GROUND_JAPAN("lightning-density-cloud-to-ground-japan"),
    LIGHTNING_DENSITY_CLOUD_TO_GROUND_UNITED_STATES("lightning-density-cloud-to-ground-us"),
    LIGHTNING_DENSITY_EUROPE("lightning-density-europe"),
    LIGHTNING_DENSITY_INTRACLOUD("lightning-density-intracloud"),
    LIGHTNING_DENSITY_INTRACLOUD_AUSTRALIA("lightning-density-intracloud-australia"),
    LIGHTNING_DENSITY_INTRACLOUD_EUROPE("lightning-density-intracloud-europe"),
    LIGHTNING_DENSITY_INTRACLOUD_JAPAN("lightning-density-intracloud-japan"),
    LIGHTNING_DENSITY_INTRACLOUD_UNITED_STATES("lightning-density-intracloud-us"),
    LIGHTNING_DENSITY_JAPAN("lightning-density-japan"),
    LIGHTNING_DENSITY_UNITED_STATES("lightning-density-us"),
    LIGHTNING_FLASH("lightning-flash"),
    LIGHTNING_STRIKES("lightning-strikes"),
    LIGHTNING_STRIKES_HEAT("lightning-strikes-heat"),
    LIGHTNING_STRIKES_ICONS("lightning-strikes-icons"),
    LIGHTNING_THREATS("lightning-threats"),
    LIGHTNING_THREATS_POINTS("lightning-threats-points"),
    LIGHTNING_THREATS_POLYGONS("lightning-threats-polygons"),
    LIGHTNING_THREATS_TRACKS("lightning-threats-tracks"),
    OCEAN_CURRENTS("ocean-currents"),
    OCEAN_CURRENTS_PARTICLES("ocean-currents-particles"),
    PLACE_CITY("place-city"),
    PLACE_COUNTRY("place-country"),
    PLACE_NEIGHBORHOOD("place-neighborhood"),
    PLACE_STATE("place-state"),
    PLACES("places"),
    PRECIPITATION("precip"),

    //PRECIPITATION_RATE("precip-rate"),
    PRESSURE_MEAN_SEA_LEVEL("pressure-msl"),
    PRESSURE_MEAN_SEA_LEVEL_CONTOUR("pressure-msl-contour"),
    RADAR("radar"),
    RIVER_OBSERVATIONS("river-observations"),
    ROAD_ALL("road-all"),
    ROAD_MOTORWAY("road-motorway"),
    ROAD_PRIMARY("road-primary"),
    ROAD_SECONDARY_TERTIARY("road-secondary-tertiary"),
    ROAD_STREET("road-street"),
    ROAD_TRUNK("road-trunk"),
    ROADS("roads"),
    SATELLITE("satellite"),
    SATELLITE_GEOCOLOR("satellite-geocolor"),
    SATELLITE_INFRARED_COLOR("satellite-infrared-color"),
    SATELLITE_VISIBLE("satellite-visible"),
    SATELLITE_WATER_VAPOR("satellite-water-vapor"),
    SNOW("snow"),
    SNOW_DEPTH("snow-depth"),
    SEA_SURFACE_TEMPERATURES("sst"),
    STORM_SURGE("storm-surge"),
    STORMCELLS("stormcells"),
    STORMCELLS_CONES("stormcells-cones"),
    STORMCELLS_HEAT("stormcells-heat"),
    STORMCELLS_POSITIONS("stormcells-positions"),
    STORMCELLS_TRACKS("stormcells-tracks"),
    STORMREPORTS("stormreports"),
    STORMREPORTS_HEAT("stormreports-heat"),
    SWELL_HEIGHTS("swell-heights"),
    SWELL_PARTICLES("swell-particles"),
    SWELL_PERIODS("swell-periods"),
    SWELL2_HEIGHTS("swell2-heights"),
    SWELL2_PARTICLES("swell2-particles"),
    SWELL2_PERIODS("swell2-periods"),
    SWELL3_HEIGHTS("swell3-heights"),
    SWELL3_PARTICLES("swell3-particles"),
    SWELL3_PERIODS("swell3-periods"),

    /** Gridded arrows: primary swell direction ([MaritimeGriddedArrows]). */
    SWELL_DIR("swell-dir"),
    SWELL2_DIR("swell2-dir"),
    SWELL3_DIR("swell3-dir"),
    TEMPERATURES("temperatures"),
    TEMPERATURES_1_HOUR_CHANGE("temperatures-1hr-change"),
    TEMPERATURES_24_HOUR_CHANGE("temperatures-24hr-change"),
    TEMPERATURES_CONTOUR("temperatures-contour"),
    TIDE_HEIGHTS("tide-heights"),
    TROPICAL_CYCLONES("tropical-cyclones"),
    TROPICAL_CYCLONES_ARCHIVE("tropical-cyclones-archive"),
    TROPICAL_CYCLONES_ARCHIVE_ICONS("tropical-cyclones-archive-icons"),
    TROPICAL_CYCLONES_BREAK_POINTS("tropical-cyclones-break-points"),
    TROPICAL_CYCLONES_FORECAST_ERROR_CONES("tropical-cyclones-forecast-error-cones"),
    TROPICAL_CYCLONES_FORECAST_LINES("tropical-cyclones-forecast-lines"),
    TROPICAL_CYCLONES_FORECAST_LINES_INVESTS("tropical-cyclones-forecast-lines-invests"),
    TROPICAL_CYCLONES_FORECAST_POINT_ICONS("tropical-cyclones-forecast-point-icons"),
    TROPICAL_CYCLONES_FORECAST_POINT_ICONS_INVESTS("tropical-cyclones-forecast-point-icons-invests"),
    TROPICAL_CYCLONES_FORECAST_POINTS("tropical-cyclones-forecast-points"),
    TROPICAL_CYCLONES_FORECAST_POINTS_INVESTS("tropical-cyclones-forecast-points-invests"),
    TROPICAL_CYCLONES_ICONS("tropical-cyclones-icons"),
    TROPICAL_CYCLONES_INVESTS("tropical-cyclones-invests"),
    TROPICAL_CYCLONES_INVESTS_ICONS("tropical-cyclones-invests-icons"),
    TROPICAL_CYCLONES_NAMES("tropical-cyclones-names"),
    TROPICAL_CYCLONES_NAMES_ARCHIVE("tropical-cyclones-names-archive"),
    TROPICAL_CYCLONES_NAMES_INVESTS("tropical-cyclones-names-invests"),
    TROPICAL_CYCLONES_POSITION_ICONS("tropical-cyclones-position-icons"),
    TROPICAL_CYCLONES_POSITION_ICONS_INVESTS("tropical-cyclones-position-icons-invests"),
    TROPICAL_CYCLONES_POSITIONS("tropical-cyclones-positions"),
    TROPICAL_CYCLONES_POSITIONS_INVESTS("tropical-cyclones-positions-invests"),
    TROPICAL_CYCLONES_TRACK_LINES("tropical-cyclones-track-lines"),
    TROPICAL_CYCLONES_TRACK_LINES_ARCHIVE("tropical-cyclones-track-lines-archive"),
    TROPICAL_CYCLONES_TRACK_LINES_INVESTS("tropical-cyclones-track-lines-invests"),
    TROPICAL_CYCLONES_TRACK_POINT_ICONS("tropical-cyclones-track-point-icons"),
    TROPICAL_CYCLONES_TRACK_POINT_ICONS_ARCHIVE("tropical-cyclones-track-point-icons-archive"),
    TROPICAL_CYCLONES_TRACK_POINT_ICONS_INVESTS("tropical-cyclones-track-point-icons-invests"),
    TROPICAL_CYCLONES_TRACK_POINTS("tropical-cyclones-track-points"),
    TROPICAL_CYCLONES_TRACK_POINTS_ARCHIVE("tropical-cyclones-track-points-archive"),
    TROPICAL_CYCLONES_TRACK_POINTS_INVESTS("tropical-cyclones-track-points-invests"),
    ULTRAVIOLET_INDEX("uvi"),
    VISIBILITY("visibility"),
    WATER("water"),
    WATERWAY_LAKE_RIVER_BOUNDARIES("waterway-lake-river-boundaries"),
    WATERWAY_OCEAN_BOUNDARIES("waterway-ocean-boundaries"),
    WAVE_HEIGHTS("wave-heights"),
    WAVE_PARTICLES("wave-particles"),
    WAVE_PERIODS("wave-periods"),

    /** Gridded arrows: maritime wave direction ([MaritimeGriddedArrows]). */
    WAVE_DIR("wave-dir"),
    WIND_CHILL("wind-chill"),
    WIND_GUSTS("wind-gusts"),
    WIND_PARTICLES("wind-particles"),
    WIND_BARBS("wind-barbs"),
    WIND_DIR("wind-dir"),
    WIND_SPEEDS("wind-speeds"),
    WIND_SPEEDS_CONTOUR("wind-speeds-contour"),
    ;

    companion object {
        /**
         * Retrieves the appropriate WeatherLayerConfiguration based on the given LayerCode.
         *
         * @param code The LayerCode enum representing the desired weather layer.
         * @param service The WeatherService instance to pass to the configuration factory.
         * @return The corresponding WeatherLayerConfiguration, or null if the code is not recognized.
         */
        fun getConfigurationForLayerCode(
            code: LayerCode,
            service: WeatherService,
        ): WeatherConfiguration =
            when (code) {
                LayerCode.ADMIN_2_BOUNDARIES -> WeatherConfigurations.Admin2Boundaries(service)
                LayerCode.ADMIN_3_4_BOUNDARIES -> WeatherConfigurations.Admin34Boundaries(service)
                LayerCode.ADMIN_5_6_BOUNDARIES -> WeatherConfigurations.Admin56Boundaries(service)
                LayerCode.AIR_QUALITY -> WeatherConfigurations.AirQuality(service)
                LayerCode.CARBON_MONOXIDE -> WeatherConfigurations.CarbonMonoxide(service)
                LayerCode.AIR_QUALITY_HEALTH_INDEX_CATEGORIES -> WeatherConfigurations.AirQualityHealthIndexCategories(
                    service
                )

                LayerCode.AIR_QUALITY_INDEX -> WeatherConfigurations.AirQualityIndex(service)
                LayerCode.AIR_QUALITY_INDEX_CAI_CATEGORIES -> WeatherConfigurations.AirQualityIndexCaiCategories(service)
                LayerCode.AIR_QUALITY_INDEX_CAQI_CATEGORIES -> WeatherConfigurations.AirQualityIndexCaqiCategories(
                    service
                )

                LayerCode.AIR_QUALITY_INDEX_CATEGORIES -> WeatherConfigurations.AirQualityIndexCategories(service)
                LayerCode.AIR_QUALITY_INDEX_CHINA_CATEGORIES -> WeatherConfigurations.AirQualityIndexChinaCategories(
                    service
                )

                LayerCode.AIR_QUALITY_INDEX_EAQI_CATEGORIES -> WeatherConfigurations.AirQualityIndexEaqiCategories(
                    service
                )

                LayerCode.AIR_QUALITY_INDEX_INDIA_CATEGORIES -> WeatherConfigurations.AirQualityIndexIndiaCategories(
                    service
                )

                LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_CATEGORIES -> WeatherConfigurations.AirQualityIndexUbaDaqiCategories(
                    service
                )

                LayerCode.AIR_QUALITY_INDEX_UK_DAQI_CATEGORIES -> WeatherConfigurations.AirQualityIndexUkDaqiCategories(
                    service
                )

                LayerCode.NITRIC_OXIDE -> WeatherConfigurations.NitricOxide(service)
                LayerCode.NITROGEN_DIOXIDE -> WeatherConfigurations.NitrogenDioxide(service)
                LayerCode.OZONE -> WeatherConfigurations.Ozone(service)
                LayerCode.PARTICULATE_MATTER_10_MICRON -> WeatherConfigurations.ParticulateMatter10Micron(service)
                LayerCode.PARTICULATE_MATTER_2P5_MICRON -> WeatherConfigurations.ParticulateMatter2p5Micron(service)
                LayerCode.SULFUR_DIOXIDE -> WeatherConfigurations.SulfurDioxide(service)
                LayerCode.ALERTS -> WeatherConfigurations.Alerts(service)
                LayerCode.ALERTS_OUTLINE -> WeatherConfigurations.AlertsOutline(service)
                LayerCode.BOUNDARIES -> WeatherConfigurations.Boundaries(service)
                LayerCode.CLOUD_COVER -> WeatherConfigurations.CloudCover(service)
                LayerCode.CONVECTIVE -> WeatherConfigurations.Convective(service)
                LayerCode.CONVECTIVE_OUTLINE -> WeatherConfigurations.ConvectiveOutline(service)
                LayerCode.DEW_POINTS -> WeatherConfigurations.DewPoints(service)
                LayerCode.DROUGHT_MONITOR -> WeatherConfigurations.DroughtMonitor(service)
                LayerCode.DROUGHT_MONITOR_OUTLINE -> WeatherConfigurations.DroughtMonitorOutline(service)
                LayerCode.EARTHQUAKES -> WeatherConfigurations.Earthquakes(service)
                LayerCode.EARTHQUAKES_HEAT -> WeatherConfigurations.EarthquakesHeat(service)
                LayerCode.FEELS_LIKE -> WeatherConfigurations.FeelsLike(service)
                LayerCode.FIRES -> WeatherConfigurations.Fires(service)
                LayerCode.FIRES_ICONS -> WeatherConfigurations.FiresIcons(service)
                LayerCode.FIRES_OBS -> WeatherConfigurations.FiresObs(service)
                LayerCode.FIRES_OBS_HEAT -> WeatherConfigurations.FiresObsHeat(service)
                LayerCode.FIRES_OBS_ICONS -> WeatherConfigurations.FiresObsIcons(service)
                LayerCode.FIRES_OBS_NAMES -> WeatherConfigurations.FiresObsNames(service)
                LayerCode.FIRES_OUTLOOK -> WeatherConfigurations.FiresOutlook(service)
                LayerCode.FIRES_PERIMETER -> WeatherConfigurations.FiresPerimeter(service)
                LayerCode.HAIL_SEVERE_PROBABILITY -> WeatherConfigurations.HailSevereProbability(service)
                LayerCode.HAIL_SEVERE_PROBABILITY_AUSTRALIA -> WeatherConfigurations.HailSevereProbabilityAustralia(
                    service
                )

                LayerCode.HAIL_SEVERE_PROBABILITY_EUROPE -> WeatherConfigurations.HailSevereProbabilityEurope(service)
                LayerCode.HAIL_SEVERE_PROBABILITY_JAPAN -> WeatherConfigurations.HailSevereProbabilityJapan(service)
                LayerCode.HAIL_SEVERE_PROBABILITY_UNITED_STATES -> WeatherConfigurations.HailSevereProbabilityUnitedStates(
                    service
                )

                LayerCode.HAIL_SIZE -> WeatherConfigurations.HailSize(service)
                LayerCode.HAIL_SIZE_AUSTRALIA -> WeatherConfigurations.HailSizeAustralia(service)
                LayerCode.HAIL_SIZE_EUROPE -> WeatherConfigurations.HailSizeEurope(service)
                LayerCode.HAIL_SIZE_JAPAN -> WeatherConfigurations.HailSizeJapan(service)
                LayerCode.HAIL_SIZE_UNITED_STATES -> WeatherConfigurations.HailSizeUnitedStates(service)
                LayerCode.HAIL_THREATS -> WeatherConfigurations.HailThreats(service)
                LayerCode.HAIL_THREATS_POINTS -> WeatherConfigurations.HailThreatsPoints(service)
                LayerCode.HAIL_THREATS_POLYGONS -> WeatherConfigurations.HailThreatsPolygons(service)
                LayerCode.HAIL_THREATS_TRACKS -> WeatherConfigurations.HailThreatsTracks(service)
                LayerCode.HEAT_INDEX -> WeatherConfigurations.HeatIndex(service)
                LayerCode.HUMIDITY -> WeatherConfigurations.Humidity(service)
                LayerCode.LAND -> WeatherConfigurations.Land(service)
                LayerCode.LIGHTNING_ALL -> WeatherConfigurations.LightningAll(service)
                LayerCode.LIGHTNING_ALL_ICONS -> WeatherConfigurations.LightningAllIcons(service)
                LayerCode.LIGHTNING_DENSITY -> WeatherConfigurations.LightningDensity(service)
                LayerCode.LIGHTNING_DENSITY_AUSTRALIA -> WeatherConfigurations.LightningDensityAustralia(service)
                LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND -> WeatherConfigurations.LightningDensityCloudToGround(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND_AUSTRALIA -> WeatherConfigurations.LightningDensityCloudToGroundAustralia(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND_EUROPE -> WeatherConfigurations.LightningDensityCloudToGroundEurope(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND_JAPAN -> WeatherConfigurations.LightningDensityCloudToGroundJapan(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_CLOUD_TO_GROUND_UNITED_STATES -> WeatherConfigurations.LightningDensityCloudToGroundUnitedStates(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_EUROPE -> WeatherConfigurations.LightningDensityEurope(service)
                LayerCode.LIGHTNING_DENSITY_INTRACLOUD -> WeatherConfigurations.LightningDensityIntracloud(service)
                LayerCode.LIGHTNING_DENSITY_INTRACLOUD_AUSTRALIA -> WeatherConfigurations.LightningDensityIntracloudAustralia(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_INTRACLOUD_EUROPE -> WeatherConfigurations.LightningDensityIntracloudEurope(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_INTRACLOUD_JAPAN -> WeatherConfigurations.LightningDensityIntracloudJapan(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_INTRACLOUD_UNITED_STATES -> WeatherConfigurations.LightningDensityIntracloudUnitedStates(
                    service
                )

                LayerCode.LIGHTNING_DENSITY_JAPAN -> WeatherConfigurations.LightningDensityJapan(service)
                LayerCode.LIGHTNING_DENSITY_UNITED_STATES -> WeatherConfigurations.LightningDensityUnitedStates(service)
                LayerCode.LIGHTNING_FLASH -> WeatherConfigurations.LightningFlash(service)
                LayerCode.LIGHTNING_STRIKES -> WeatherConfigurations.LightningStrikes(service)
                LayerCode.LIGHTNING_STRIKES_HEAT -> WeatherConfigurations.LightningStrikesHeat(service)
                LayerCode.LIGHTNING_STRIKES_ICONS -> WeatherConfigurations.LightningStrikesIcons(service)
                LayerCode.LIGHTNING_THREATS -> WeatherConfigurations.LightningThreats(service)
                LayerCode.LIGHTNING_THREATS_POINTS -> WeatherConfigurations.LightningThreatsPoints(service)
                LayerCode.LIGHTNING_THREATS_POLYGONS -> WeatherConfigurations.LightningThreatsPolygons(service)
                LayerCode.LIGHTNING_THREATS_TRACKS -> WeatherConfigurations.LightningThreatsTracks(service)
                LayerCode.OCEAN_CURRENTS -> WeatherConfigurations.OceanCurrents(service)
                LayerCode.OCEAN_CURRENTS_PARTICLES -> WeatherConfigurations.OceanCurrentsParticles(service)
                LayerCode.PLACE_CITY -> WeatherConfigurations.PlaceCity(service)
                LayerCode.PLACE_COUNTRY -> WeatherConfigurations.PlaceCountry(service)
                LayerCode.PLACE_NEIGHBORHOOD -> WeatherConfigurations.PlaceNeighborhood(service)
                LayerCode.PLACE_STATE -> WeatherConfigurations.PlaceState(service)
                LayerCode.PLACES -> WeatherConfigurations.Places(service)
                LayerCode.PRECIPITATION -> WeatherConfigurations.Precipitation(service)
                //LayerCode.PRECIPITATION_RATE -> WeatherConfigurations.PrecipitationRate(service)
                LayerCode.PRESSURE_MEAN_SEA_LEVEL -> WeatherConfigurations.PressureMeanSeaLevel(service)
                LayerCode.PRESSURE_MEAN_SEA_LEVEL_CONTOUR -> WeatherConfigurations.PressureMeanSeaLevelContour(service)
                LayerCode.RADAR -> WeatherConfigurations.Radar(service)
                LayerCode.RIVER_OBSERVATIONS -> WeatherConfigurations.RiverObservations(service)
                LayerCode.ROAD_ALL -> WeatherConfigurations.RoadAll(service)
                LayerCode.ROAD_MOTORWAY -> WeatherConfigurations.RoadMotorway(service)
                LayerCode.ROAD_PRIMARY -> WeatherConfigurations.RoadPrimary(service)
                LayerCode.ROAD_SECONDARY_TERTIARY -> WeatherConfigurations.RoadSecondaryTertiary(service)
                LayerCode.ROAD_STREET -> WeatherConfigurations.RoadStreet(service)
                LayerCode.ROAD_TRUNK -> WeatherConfigurations.RoadTrunk(service)
                LayerCode.ROADS -> WeatherConfigurations.Roads(service)
                LayerCode.SATELLITE -> WeatherConfigurations.Satellite(service)
                LayerCode.SATELLITE_GEOCOLOR -> WeatherConfigurations.SatelliteGeocolor(service)
                LayerCode.SATELLITE_INFRARED_COLOR -> WeatherConfigurations.SatelliteInfraredColor(service)
                LayerCode.SATELLITE_VISIBLE -> WeatherConfigurations.SatelliteVisible(service)
                LayerCode.SATELLITE_WATER_VAPOR -> WeatherConfigurations.SatelliteWaterVapor(service)
                LayerCode.SNOW -> WeatherConfigurations.Snow(service)
                LayerCode.SNOW_DEPTH -> WeatherConfigurations.SnowDepth(service)
                LayerCode.SEA_SURFACE_TEMPERATURES -> WeatherConfigurations.SeaSurfaceTemperatures(service)
                LayerCode.STORM_SURGE -> WeatherConfigurations.StormSurge(service)
                LayerCode.STORMCELLS -> WeatherConfigurations.Stormcells(service)
                LayerCode.STORMCELLS_CONES -> WeatherConfigurations.StormcellsCones(service)
                LayerCode.STORMCELLS_HEAT -> WeatherConfigurations.StormcellsHeat(service)
                LayerCode.STORMCELLS_POSITIONS -> WeatherConfigurations.StormcellsPositions(service)
                LayerCode.STORMCELLS_TRACKS -> WeatherConfigurations.StormcellsTracks(service)
                LayerCode.STORMREPORTS -> WeatherConfigurations.Stormreports(service)
                LayerCode.STORMREPORTS_HEAT -> WeatherConfigurations.StormreportsHeat(service)
                LayerCode.SWELL_HEIGHTS -> WeatherConfigurations.SwellHeights(service)
                LayerCode.SWELL_PARTICLES -> WeatherConfigurations.SwellParticles(service)
                LayerCode.SWELL_PERIODS -> WeatherConfigurations.SwellPeriods(service)
                LayerCode.SWELL2_HEIGHTS -> WeatherConfigurations.Swell2Heights(service)
                LayerCode.SWELL2_PARTICLES -> WeatherConfigurations.Swell2Particles(service)
                LayerCode.SWELL2_PERIODS -> WeatherConfigurations.Swell2Periods(service)
                LayerCode.SWELL3_HEIGHTS -> WeatherConfigurations.Swell3Heights(service)
                LayerCode.SWELL3_PARTICLES -> WeatherConfigurations.Swell3Particles(service)
                LayerCode.SWELL3_PERIODS -> WeatherConfigurations.Swell3Periods(service)
                LayerCode.TEMPERATURES -> WeatherConfigurations.Temperatures(service)
                LayerCode.TEMPERATURES_1_HOUR_CHANGE -> WeatherConfigurations.Temperatures1HourChange(service)
                LayerCode.TEMPERATURES_24_HOUR_CHANGE -> WeatherConfigurations.Temperatures24HourChange(service)
                LayerCode.TEMPERATURES_CONTOUR -> WeatherConfigurations.TemperaturesContour(service)
                LayerCode.TIDE_HEIGHTS -> WeatherConfigurations.TideHeights(service)
                LayerCode.TROPICAL_CYCLONES -> WeatherConfigurations.TropicalCyclones(service)
                LayerCode.TROPICAL_CYCLONES_ARCHIVE -> WeatherConfigurations.TropicalCyclonesArchive(service)
                LayerCode.TROPICAL_CYCLONES_ARCHIVE_ICONS -> WeatherConfigurations.TropicalCyclonesArchiveIcons(service)
                LayerCode.TROPICAL_CYCLONES_BREAK_POINTS -> WeatherConfigurations.TropicalCyclonesBreakPoints(service)
                LayerCode.TROPICAL_CYCLONES_FORECAST_ERROR_CONES -> WeatherConfigurations.TropicalCyclonesForecastErrorCones(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_FORECAST_LINES -> WeatherConfigurations.TropicalCyclonesForecastLines(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_FORECAST_LINES_INVESTS -> WeatherConfigurations.TropicalCyclonesForecastLinesInvests(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_FORECAST_POINT_ICONS -> WeatherConfigurations.TropicalCyclonesForecastPointIcons(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_FORECAST_POINT_ICONS_INVESTS -> WeatherConfigurations.TropicalCyclonesForecastPointIconsInvests(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_FORECAST_POINTS -> WeatherConfigurations.TropicalCyclonesForecastPoints(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_FORECAST_POINTS_INVESTS -> WeatherConfigurations.TropicalCyclonesForecastPointsInvests(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_ICONS -> WeatherConfigurations.TropicalCyclonesIcons(service)
                LayerCode.TROPICAL_CYCLONES_INVESTS -> WeatherConfigurations.TropicalCyclonesInvests(service)
                LayerCode.TROPICAL_CYCLONES_INVESTS_ICONS -> WeatherConfigurations.TropicalCyclonesInvestsIcons(service)
                LayerCode.TROPICAL_CYCLONES_NAMES -> WeatherConfigurations.TropicalCyclonesNames(service)
                LayerCode.TROPICAL_CYCLONES_NAMES_ARCHIVE -> WeatherConfigurations.TropicalCyclonesNamesArchive(service)
                LayerCode.TROPICAL_CYCLONES_NAMES_INVESTS -> WeatherConfigurations.TropicalCyclonesNamesInvests(service)
                LayerCode.TROPICAL_CYCLONES_POSITION_ICONS -> WeatherConfigurations.TropicalCyclonesPositionIcons(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_POSITION_ICONS_INVESTS -> WeatherConfigurations.TropicalCyclonesPositionIconsInvests(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_POSITIONS -> WeatherConfigurations.TropicalCyclonesPositions(service)
                LayerCode.TROPICAL_CYCLONES_POSITIONS_INVESTS -> WeatherConfigurations.TropicalCyclonesPositionsInvests(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_TRACK_LINES -> WeatherConfigurations.TropicalCyclonesTrackLines(service)
                LayerCode.TROPICAL_CYCLONES_TRACK_LINES_ARCHIVE -> WeatherConfigurations.TropicalCyclonesTrackLinesArchive(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_TRACK_LINES_INVESTS -> WeatherConfigurations.TropicalCyclonesTrackLinesInvests(
                    service
                )

                LayerCode.TROPICAL_CYCLONES_TRACK_POINT_ICONS -> WeatherConfigurations.TropicalCyclonesTrackPointIcons(
                    service
                )

                TROPICAL_CYCLONES_TRACK_POINT_ICONS_ARCHIVE -> WeatherConfigurations.TropicalCyclonesTrackPointIconsArchive(
                    service
                )

                TROPICAL_CYCLONES_TRACK_POINT_ICONS_INVESTS -> WeatherConfigurations.TropicalCyclonesTrackPointIconsInvests(
                    service
                )

                TROPICAL_CYCLONES_TRACK_POINTS -> WeatherConfigurations.TropicalCyclonesTrackPoints(service)
                TROPICAL_CYCLONES_TRACK_POINTS_ARCHIVE -> WeatherConfigurations.TropicalCyclonesTrackPointsArchive(
                    service
                )

                TROPICAL_CYCLONES_TRACK_POINTS_INVESTS -> WeatherConfigurations.TropicalCyclonesTrackPointsInvests(
                    service
                )

                ULTRAVIOLET_INDEX -> WeatherConfigurations.UltravioletIndex(service)
                LayerCode.VISIBILITY -> WeatherConfigurations.Visibility(service)
                WATER -> WeatherConfigurations.Water(service)
                WATERWAY_LAKE_RIVER_BOUNDARIES -> WeatherConfigurations.WaterwayLakeRiverBoundaries(service)
                LayerCode.WATERWAY_OCEAN_BOUNDARIES -> WeatherConfigurations.WaterwayOceanBoundaries(service)
                WAVE_HEIGHTS -> WeatherConfigurations.WaveHeights(service)
                LayerCode.WAVE_PARTICLES -> WeatherConfigurations.WaveParticles(service)
                LayerCode.WAVE_PERIODS -> WeatherConfigurations.WavePeriods(service)
                WAVE_DIR -> WeatherConfigurations.WaveDirectionGrid(service)
                SWELL_DIR -> WeatherConfigurations.SwellDirectionGrid(service)
                SWELL2_DIR -> WeatherConfigurations.Swell2DirectionGrid(service)
                SWELL3_DIR -> WeatherConfigurations.Swell3DirectionGrid(service)
                LayerCode.WIND_CHILL -> WeatherConfigurations.WindChill(service)
                LayerCode.WIND_GUSTS -> WeatherConfigurations.WindGusts(service)
                LayerCode.WIND_PARTICLES -> WeatherConfigurations.WindParticles(service)
                LayerCode.WIND_BARBS -> WeatherConfigurations.WindBarbs(service)
                LayerCode.WIND_DIR -> WeatherConfigurations.WindDirectionArrows(service)
                LayerCode.WIND_SPEEDS -> WeatherConfigurations.WindSpeeds(service)
                LayerCode.WIND_SPEEDS_CONTOUR -> WeatherConfigurations.WindSpeedsContour(service)
            }
    }
}

class WeatherConfigurations {
    companion object {


        fun Admin2Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.Admin2Boundaries(service)
        }

        fun Admin34Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.Admin34Boundaries(service)
        }

        fun Admin56Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.Admin56Boundaries(service)
        }

        fun AirQuality(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQuality(service)
        }

        fun CarbonMonoxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.CarbonMonoxide(service)
        }

        fun AirQualityHealthIndexCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityHealthIndexCategories(service)
        }

        fun AirQualityIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndex(service)
        }

        fun AirQualityIndexCaiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndexCaiCategories(service)
        }

        fun AirQualityIndexCaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndexCaqiCategories(service)
        }

        fun AirQualityIndexCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndexCategories(service)
        }

        fun AirQualityIndexChinaCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndexChinaCategories(service)
        }

        fun AirQualityIndexEaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndexEaqiCategories(service)
        }

        fun AirQualityIndexIndiaCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndexIndiaCategories(service)
        }

        fun AirQualityIndexUbaDaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndexUbaDaqiCategories(service)
        }

        fun AirQualityIndexUkDaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.AirQualityIndexUkDaqiCategories(service)
        }

        fun NitricOxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.NitricOxide(service)
        }

        fun NitrogenDioxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.NitrogenDioxide(service)
        }

        fun Ozone(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.Ozone(service)
        }

        fun ParticulateMatter10Micron(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.ParticulateMatter10Micron(service)
        }

        fun ParticulateMatter2p5Micron(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.ParticulateMatter2p5Micron(service)
        }

        fun SulfurDioxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return com.xweather.mapsgl.weather.groups.AirQuality.SulfurDioxide(service)
        }

        fun Alerts(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
            return Severe.Alerts(service)
        }

        fun AlertsOutline(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Severe.AlertsOutline(service)
        }

        fun Boundaries(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Admin.Boundaries(service)
        }

        fun CloudCover(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.CloudCover(service)
        }

        fun Convective(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
            return Severe.Convective(service)
        }

        fun ConvectiveOutline(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
            return Severe.ConvectiveOutline(service)
        }

        fun DewPoints(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.DewPoints(service)
        }

        fun DroughtMonitor(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
            return Climate.DroughtMonitor(service)
        }

        fun DroughtMonitorOutline(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
            return Climate.DroughtMonitorOutline(service)
        }

        fun Earthquakes(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
            return Climate.Earthquakes(service)
        }

        fun EarthquakesHeat(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, HeatmapLayerDescriptor> {
            return Climate.EarthquakesHeat(service)
        }

        fun FeelsLike(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.FeelsLike(service)
        }

        fun Fires(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Climate.Fires(service)
        }

        fun FiresIcons(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Climate.FiresIcons(service)
        }

        fun FiresObs(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
            return Climate.FiresObs(service)
        }

        fun FiresObsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> {
            return Climate.FiresObsHeat(service)
        }

        fun FiresObsIcons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> {
            return Climate.FiresObsIcons(service)
        }

        fun FiresObsNames(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> {
            return Climate.FiresObsNames(service)
        }

        fun FiresOutlook(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
            return Climate.FiresOutlook(service)
        }

        fun FiresPerimeter(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
            return Climate.FiresPerimeter(service)
        }

        fun HailSevereProbability(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.HailSevereProbability(service)
        }

        fun HailSevereProbabilityAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.HailSevereProbabilityAustralia(service)
        }

        fun HailSevereProbabilityEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.HailSevereProbabilityEurope(service)
        }

        fun HailSevereProbabilityJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.HailSevereProbabilityJapan(service)
        }

        fun HailSevereProbabilityUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.HailSevereProbabilityUnitedStates(service)
        }

        fun HailSize(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.HailSize(service)
        }

        fun HailSizeAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.HailSizeAustralia(service)
        }

        fun HailSizeEurope(service: WeatherService): SampleConfiguration {
            return Severe.HailSizeEurope(service)
        }

        fun HailSizeJapan(service: WeatherService): SampleConfiguration {
            return Severe.HailSizeJapan(service)
        }

        fun HailSizeUnitedStates(service: WeatherService): SampleConfiguration {
            return Severe.HailSizeUnitedStates(service)
        }

        fun HailThreats(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.HailThreats(service)
        }

        fun HailThreatsPoints(service: WeatherService): VCircleConfiguration {
            return Severe.HailThreatsPoints(service)
        }

        fun HailThreatsPolygons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
            return Severe.HailThreatsPolygons(service)
        }

        fun HailThreatsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Severe.HailThreatsTracks(service)
        }

        fun HeatIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.HeatIndex(service)
        }

        fun Humidity(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.Humidity(service)
        }

        fun LightningAll(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.LightningAll(service)
        }

        fun LightningAllIcons(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.LightningAllIcons(service)
        }

        fun LightningDensity(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.LightningDensity(service)
        }

        fun LightningDensityAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityAustralia(service)
        }

        fun LightningDensityCloudToGround(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.LightningDensityCloudToGround(service)
        }

        fun LightningDensityCloudToGroundAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityCloudToGroundAustralia(service)
        }

        fun LightningDensityCloudToGroundEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityCloudToGroundEurope(service)
        }

        fun LightningDensityCloudToGroundJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityCloudToGroundJapan(service)
        }

        fun LightningDensityCloudToGroundUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityCloudToGroundUnitedStates(service)
        }

        fun LightningDensityEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityEurope(service)
        }

        fun LightningDensityIntracloud(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.LightningDensityIntracloud(service)
        }

        fun LightningDensityIntracloudAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityIntracloudAustralia(service)
        }

        fun LightningDensityIntracloudEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityIntracloudEurope(service)
        }

        fun LightningDensityIntracloudJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityIntracloudJapan(service)
        }

        fun LightningDensityIntracloudUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityIntracloudUnitedStates(service)
        }

        fun LightningDensityJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityJapan(service)
        }

        fun LightningDensityUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Severe.LightningDensityUnitedStates(service)
        }

        fun LightningFlash(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
            return Severe.LightningFlash(service)
        }

        fun LightningStrikes(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
            return Severe.LightningStrikes(service)
        }

        fun LightningStrikesHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> {
            return Severe.LightningStrikesHeat(service)
        }

        fun LightningStrikesIcons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> {
            return Severe.LightningStrikesIcons(service)
        }

        fun LightningThreats(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.LightningThreats(service)
        }

        fun LightningThreatsPoints(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
            return Severe.LightningThreatsPoints(service)
        }

        fun LightningThreatsPolygons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
            return Severe.LightningThreatsPolygons(service)
        }

        fun LightningThreatsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Severe.LightningThreatsTracks(service)
        }

        fun OceanCurrents(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.OceanCurrents(service)
        }

        fun OceanCurrentsParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
            return Maritime.OceanCurrentsParticles(service)
        }

        fun PlaceCity(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> {
            return Admin.PlaceCity(service)
        }

        fun PlaceCountry(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> {
            return Admin.PlaceCountry(service)
        }

        fun PlaceNeighborhood(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> {
            return Admin.PlaceNeighborhood(service)
        }

        fun PlaceState(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> {
            return Admin.PlaceState(service)
        }

        fun Places(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Admin.Places(service)
        }

        fun Precipitation(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.Precipitation(service)
        }

        //fun PrecipitationRate(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
        //    return Conditions.PrecipitationRate(service)
        // }

        fun PressureMeanSeaLevel(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.PressureMeanSeaLevel(service)
        }

        fun PressureMeanSeaLevelContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> {
            return Conditions.PressureMeanSeaLevelContour(service)
        }

        fun Radar(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.Radar(service)
        }

        fun RiverObservations(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
            return Climate.RiverObservations(service)
        }

        fun RoadAll(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.RoadAll(service)
        }

        fun RoadMotorway(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.RoadMotorway(service)
        }

        fun RoadPrimary(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.RoadPrimary(service)
        }

        fun RoadSecondaryTertiary(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.RoadSecondaryTertiary(service)
        }

        fun RoadStreet(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.RoadStreet(service)
        }

        fun RoadTrunk(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.RoadTrunk(service)
        }

        fun Roads(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Admin.Roads(service)
        }

        fun Satellite(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
            return Raster.Satellite(service)
        }

        fun SatelliteGeocolor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
            return Raster.SatelliteGeocolor(service)
        }

        fun SatelliteInfraredColor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
            return Raster.SatelliteInfraredColor(service)
        }

        fun SatelliteVisible(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
            return Raster.SatelliteVisible(service)
        }

        fun SatelliteWaterVapor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> {
            return Raster.SatelliteWaterVapor(service)
        }

        fun Snow(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.Snow(service)
        }

        fun SnowDepth(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.SnowDepth(service)
        }

        fun SeaSurfaceTemperatures(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.SeaSurfaceTemperatures(service)
        }

        fun StormSurge(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.StormSurge(service)
        }

        fun Stormcells(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Severe.Stormcells(service)
        }

        fun StormcellsCones(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
            return Severe.StormcellsCones(service)
        }

        fun StormcellsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> {
            return Severe.StormcellsHeat(service)
        }

        fun StormcellsPositions(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
            return Severe.StormcellsPositions(service)
        }

        fun StormcellsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Severe.StormcellsTracks(service)
        }

        fun Stormreports(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> {
            return Severe.Stormreports(service)
        }

        fun StormreportsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> {
            return Severe.StormreportsHeat(service)
        }

        fun SwellHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.SwellHeights(service)
        }

        fun SwellParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
            return Maritime.SwellParticles(service)
        }

        fun SwellPeriods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.SwellPeriods(service)
        }

        fun Swell2Heights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.Swell2Heights(service)
        }

        fun Swell2Particles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
            return Maritime.Swell2Particles(service)
        }

        fun Swell2Periods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.Swell2Periods(service)
        }

        fun Swell3Heights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.Swell3Heights(service)
        }

        fun Swell3Particles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
            return Maritime.Swell3Particles(service)
        }

        fun Swell3Periods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.Swell3Periods(service)
        }

        fun Temperatures(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.Temperatures(service)
        }

        fun TemperaturesContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> {
            return Conditions.TemperaturesContour(service)
        }

        fun Temperatures1HourChange(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.Temperatures1HourChange(service)
        }

        fun Temperatures24HourChange(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.Temperatures24HourChange(service)
        }

        fun TideHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.TideHeights(service)
        }

        fun TropicalCyclones(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Tropical.TropicalCyclones(service)
        }

        fun TropicalCyclonesArchive(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Tropical.TropicalCyclonesArchive(service)
        }

        fun TropicalCyclonesArchiveIcons(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Tropical.TropicalCyclonesArchiveIcons(service)
        }

        fun TropicalCyclonesBreakPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
            return Tropical.TropicalCyclonesBreakPoints(service)
        }

        fun TropicalCyclonesForecastErrorCones(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> {
            return Tropical.TropicalCyclonesForecastErrorCones(service)
        }

        fun TropicalCyclonesForecastLines(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
            return Tropical.TropicalCyclonesForecastLines(service)
        }

        fun TropicalCyclonesForecastLinesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
            return Tropical.TropicalCyclonesForecastLinesInvests(service)
        }

        fun TropicalCyclonesForecastPointIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesForecastPointIcons(service)
        }

        fun TropicalCyclonesForecastPointIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesForecastPointIconsInvests(service)
        }

        fun TropicalCyclonesForecastPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
            return Tropical.TropicalCyclonesForecastPoints(service)
        }

        fun TropicalCyclonesForecastPointsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
            return Tropical.TropicalCyclonesForecastPointsInvests(service)
        }

        fun TropicalCyclonesIcons(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Tropical.TropicalCyclonesIcons(service)
        }

        fun TropicalCyclonesInvests(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Tropical.TropicalCyclonesInvests(service)
        }

        fun TropicalCyclonesInvestsIcons(service: WeatherService): CompositeWeatherLayerConfiguration {
            return Tropical.TropicalCyclonesInvestsIcons(service)
        }

        fun TropicalCyclonesNames(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesNames(service)
        }

        fun TropicalCyclonesNamesArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesNamesArchive(service)
        }

        fun TropicalCyclonesNamesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesNamesInvests(service)
        }

        fun TropicalCyclonesPositionIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesPositionIcons(service)
        }

        fun TropicalCyclonesPositionIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesPositionIconsInvests(service)
        }

        fun TropicalCyclonesPositions(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
            return Tropical.TropicalCyclonesPositions(service)
        }

        fun TropicalCyclonesPositionsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
            return Tropical.TropicalCyclonesPositionsInvests(service)
        }

        fun TropicalCyclonesTrackLines(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackLines(service)
        }

        fun TropicalCyclonesTrackLinesArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackLinesArchive(service)
        }

        fun TropicalCyclonesTrackLinesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackLinesInvests(service)
        }

        fun TropicalCyclonesTrackPointIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackPointIcons(service)
        }

        fun TropicalCyclonesTrackPointIconsArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackPointIconsArchive(service)
        }

        fun TropicalCyclonesTrackPointIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackPointIconsInvests(service)
        }

        fun TropicalCyclonesTrackPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackPoints(service)
        }

        fun TropicalCyclonesTrackPointsArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackPointsArchive(service)
        }

        fun TropicalCyclonesTrackPointsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> {
            return Tropical.TropicalCyclonesTrackPointsInvests(service)
        }

        fun UltravioletIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.UltravioletIndex(service)
        }

        fun Visibility(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.Visibility(service)
        }

        fun Water(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
            return Admin.Water(service)
        }

        fun Land(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> {
            return Admin.Land(service)
        }

        fun WaterwayLakeRiverBoundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.WaterwayLakeRiverBoundaries(service)
        }

        fun WaterwayOceanBoundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> {
            return Admin.WaterwayOceanBoundaries(service)
        }

        fun WaveHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.WaveHeights(service)
        }

        fun WaveParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
            return Maritime.WaveParticles(service)
        }

        fun WavePeriods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Maritime.WavePeriods(service)
        }

        fun WaveDirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> {
            return Maritime.waveDirectionGrid(service)
        }

        fun SwellDirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> {
            return Maritime.swellDirectionGrid(service)
        }

        fun Swell2DirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> {
            return Maritime.swell2DirectionGrid(service)
        }

        fun Swell3DirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> {
            return Maritime.swell3DirectionGrid(service)
        }

        fun WindChill(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.WindChill(service)
        }

        fun WindGusts(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.WindGusts(service)
        }

        fun WindParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> {
            return Conditions.WindParticles(service)
        }

        fun WindSpeeds(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> {
            return Conditions.WindSpeeds(service)
        }

        fun WindBarbs(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> {
            return Conditions.WindBarbs(service)
        }

        fun WindDirectionArrows(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> {
            return Conditions.WindDir(service)
        }

        fun WindSpeedsContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> {
            return Conditions.WindSpeedsContour(service)
        }


        //-----------------------------------------------------------------------------------------------------------------------------------


    }
}
