package com.xweather.mapsgl.weather

import kotlin.math.roundToInt

/**
 * The precipitation-type codes in the `weather-surface_PTYPE_0-SFC` channel, and how each one is
 * drawn and named.
 *
 * One table for the three places that need it — the `weather` layer's color scale, its Weather Type
 * legend, and the `weather-text` labels — so a color or a name cannot drift between them. Codes and
 * colors match MapsGL JS `PTYPE_VALUE_MAPPING` and its `weather` layer; labels match the JS legend.
 *
 * 255 is the product's "none" and 0 means no data. Neither has an entry, so neither draws nor labels.
 */
internal object WeatherType {

    data class Entry(val code: Int, val label: String, val color: String)

    /** In legend order: light to heavy liquid, then the frozen and mixed types. */
    val ENTRIES: List<Entry> = listOf(
        Entry(11, "Drizzle", "#8BF291"),
        Entry(1, "Rain", "#00A91E"),
        Entry(2, "Thunderstorms", "#C50000"),
        Entry(12, "Freezing Drizzle", "#F4A8A9"),
        Entry(3, "Freezing Rain", "#F45F61"),
        Entry(4, "Mixed Ice", "#DB73E6"),
        Entry(8, "Sleet", "#e6738e"),
        Entry(5, "Snow", "#D0ECF4"),
        Entry(6, "Wet Snow", "#757AF4"),
        Entry(7, "Rain/Snow Mix", "#B175F4"),
        Entry(9, "Graupel", "#40e0d0"),
        Entry(10, "Hail", "#ff00ff"),
    )

    private val byCode: Map<Int, Entry> = ENTRIES.associateBy { it.code }

    /** Lowest and highest real codes, the layer's draw range. */
    val MIN_CODE: Int = ENTRIES.minOf { it.code }
    val MAX_CODE: Int = ENTRIES.maxOf { it.code }

    /**
     * The condition name for a sampled value, or `null` for none, no data or an unknown code.
     *
     * The sample is a decoded byte, so it should already be whole; rounding guards against a
     * dataset range that decodes it a hair off.
     */
    fun labelFor(value: Double): String? {
        if (value.isNaN()) return null
        return byCode[value.roundToInt()]?.label
    }
}
