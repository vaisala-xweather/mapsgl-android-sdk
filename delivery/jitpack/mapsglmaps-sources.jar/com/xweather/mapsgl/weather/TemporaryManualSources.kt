//
//  TemporaryManualSources.kt
//
//  Hand-written companion to the generated Sources.kt, LayerCodes.kt and weather groups.
//  This file is NOT auto-generated and is safe to edit.
//

package com.xweather.mapsgl.weather

import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.controls.legend.Legend
import com.xweather.mapsgl.weather.common.Presentation
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.VectorLayerDescriptor
import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.data.series.EncodedRasterOperations
import com.xweather.mapsgl.data.series.TimeSeriesOperationSpec
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.utils.inToM
import com.xweather.mapsgl.utils.inToMMRate
import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.LineCap
import com.xweather.mapsgl.style.LineJoin
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.StyleValue

/**
 * Weather sources and layers that are not in the generated files.
 *
 * `Sources.kt`, `LayerCodes.kt` and every generated file under `weather/groups` carry
 * "This file is auto-generated and should not be edited directly!", and the generator lives outside
 * this repository. Anything added to them by hand survives only until the next regeneration. This
 * file is the hand-written side of that line: products MapsGL JS ships which Android's generated
 * sources have not caught up with yet.
 *
 * "Temporary" is the intent. Each entry here should move into the generator's input spec and be
 * deleted from this file; until then, keeping them separate means a regeneration cannot silently
 * revert them.
 *
 * Because [LayerCode] is a generated enum with no entries for these products, they cannot be
 * expressed as a [WeatherConfiguration] — that interface requires a [LayerCode]. So they are exposed
 * the same way `raster.<code>` is (XMAPSGLSDK-320): factories returning the source and layer
 * descriptors, plus a convenience that registers both.
 */
public object ManualWeatherSource {

    /**
     * OpenStreetMap power infrastructure — power lines, plants and generators.
     *
     * MapsGL JS: `base.osm.power`, built from the `open-street-map-power-infrastructure` vector
     * product. Distinct from the generated [WeatherSource.base_osm], which is plain OSM and carries
     * none of the `power_*` source layers.
     */
    public fun base_osm_power(service: WeatherService): VectorSourceDescriptor =
        service.makeVectorSourceDescriptor(
            id = "base.osm.power",
            code = "open-street-map-power-infrastructure",
        )
}

/**
 * The power layers MapsGL JS ships (MapsGL JS 1.8.1 / 1.8.5).
 *
 * Each has an equivalent [LayerCode] ([LayerCode.POWER_LINES] and the other power codes), so
 * [addPowerLayer] matches `addWeatherLayer(LayerCode.POWER_LINES, …)`; this enum is kept for callers
 * that use [PowerLayerCode].
 *
 * @property value The MapsGL product id, matching JS's weather code.
 * @property layerId The layer id JS registers, kept identical so ids are portable between platforms.
 */
public enum class PowerLayerCode(
    public val value: String,
    public val layerId: String,
) {
    POWER_LINES("power-lines", "base.power_lines.line"),
    POWER_PLANTS("power-plants", "base.power_plants.fill"),
    POWER_GENERATORS("power-generators", "base.power_generators.fill"),
    POWER_GENERATOR_BOUNDARIES("power-generator-boundaries", "base.power_generator_boundaries.fill"),
    POWER_GENERATOR_CENTROIDS("power-generator-centroids", "base.power_generator_centroids.circle"),
    ;

    public companion object {
        /** Looks up a code by its MapsGL product id, or null when it is not a power layer. */
        public fun from(value: String): PowerLayerCode? = entries.firstOrNull { it.value == value }
    }
}

/**
 * Source and layer descriptors for the [PowerLayerCode] products.
 *
 * Ids, source layers, filters and paint follow `packages/webgl-maps/src/weather/groups/admin.ts`.
 */
public object ManualWeatherLayers {

    /** JS's per-energy-source palette for generators. */
    private const val GAS = "#E83B1F"
    private const val OIL = "#555555"
    private const val WIND = "#009EFF"
    private const val SOLAR = "#FFB300"

    /** JS's fallback for a generator whose `energy_source` is absent or unrecognised. */
    private const val OTHER = "#333333"

    /** The four sources JS draws; anything else is filtered out rather than drawn in [OTHER]. */
    private val DRAWN_ENERGY_SOURCES = listOf("gas", "oil", "wind", "solar")

    /**
     * Only generators whose `energy_source` is one JS draws.
     *
     * Matches JS's `["in", ["get", "energy_source"], ["literal", [...]]]`;
     * [Expression.contains] compiles to the `match` form, which the Mapbox native engine supports
     * more widely and which is semantically identical as a boolean filter.
     */
    private fun energySourceFilter(): Expression =
        Expression.contains(Expression.get("energy_source"), DRAWN_ENERGY_SOURCES)

    /**
     * Colour by `energy_source`, downcased first exactly as JS's `data.energy_source?.toLowerCase()`
     * does — the tiles are not guaranteed to be lowercase, and a case mismatch would silently paint
     * every generator in the [OTHER] fallback.
     */
    private fun energySourceColor(): StyleValue<Color> = StyleValue.Expression(
        Expression.match(
            Expression.downcase(Expression.get("energy_source")),
            listOf(
                Expression.Step("gas", GAS),
                Expression.Step("oil", OIL),
                Expression.Step("wind", WIND),
                Expression.Step("solar", SOLAR),
            ),
            OTHER,
        ),
    )

    /** `power-lines`: OSM transmission lines. */
    public fun powerLines(service: WeatherService): Pair<VectorSourceDescriptor, LineLayerDescriptor> {
        val source = ManualWeatherSource.base_osm_power(service)
        val layer = LineLayerDescriptor(
            PowerLayerCode.POWER_LINES.layerId,
            source.id,
            sourceLayer = "power_lines",
            paint = LineLayerPaint(
                stroke = StrokePaint(
                    color = StyleValue.Constant(Color(0xFFB9713E)),
                    thickness = StyleValue.Constant(2.0),
                    lineJoin = StyleValue.Constant(LineJoin.ROUND),
                    lineCap = StyleValue.Constant(LineCap.ROUND),
                ),
            ),
        )
        return source to layer
    }

    /** `power-plants`: plant footprints. */
    public fun powerPlants(service: WeatherService): Pair<VectorSourceDescriptor, FillLayerDescriptor> {
        val source = ManualWeatherSource.base_osm_power(service)
        val layer = FillLayerDescriptor(
            PowerLayerCode.POWER_PLANTS.layerId,
            source.id,
            sourceLayer = "power_plants",
            paint = FillLayerPaint(
                fill = FillPaint(color = StyleValue.Constant(Color(0xFF895D3E))),
            ),
        )
        return source to layer
    }

    /** `power-generators`: individual generators as points, coloured by energy source. */
    public fun powerGenerators(service: WeatherService): Pair<VectorSourceDescriptor, CircleLayerDescriptor> {
        val source = ManualWeatherSource.base_osm_power(service)
        val layer = CircleLayerDescriptor(
            PowerLayerCode.POWER_GENERATORS.layerId,
            source.id,
            sourceLayer = "power_generators",
            paint = CircleLayerPaint(
                fill = FillPaint(color = energySourceColor()),
                stroke = StrokePaint(
                    color = StyleValue.Constant(Color.White),
                    thickness = StyleValue.Constant(2.0),
                ),
                circle = CirclePaint(radius = StyleValue.Constant(6.0)),
            ),
            filter = energySourceFilter(),
        )
        return source to layer
    }

    /** `power-generator-boundaries`: generator site outlines, half-opacity fill plus a matching stroke. */
    public fun powerGeneratorBoundaries(
        service: WeatherService,
    ): Pair<VectorSourceDescriptor, FillLayerDescriptor> {
        val source = ManualWeatherSource.base_osm_power(service)
        val layer = FillLayerDescriptor(
            PowerLayerCode.POWER_GENERATOR_BOUNDARIES.layerId,
            source.id,
            sourceLayer = "power_generator_bounds",
            // JS's `fill.opacity: 0.5`. This briefly had to be set twice, because the GL path read
            // only the layer-level opacity and the style path only this one; XMAPSGLSDK-323 made
            // the GL renderer compose both, so the single declaration is enough again -- and
            // setting both would now multiply to 0.25.
            paint = FillLayerPaint(
                fill = FillPaint(
                    color = energySourceColor(),
                    opacity = StyleValue.Constant(0.5),
                ),
                stroke = StrokePaint(
                    color = energySourceColor(),
                    thickness = StyleValue.Constant(2.0),
                ),
            ),
            filter = energySourceFilter(),
        )
        return source to layer
    }

    /** `power-generator-centroids`: one point per generator site. */
    public fun powerGeneratorCentroids(
        service: WeatherService,
    ): Pair<VectorSourceDescriptor, CircleLayerDescriptor> {
        val source = ManualWeatherSource.base_osm_power(service)
        val layer = CircleLayerDescriptor(
            PowerLayerCode.POWER_GENERATOR_CENTROIDS.layerId,
            source.id,
            sourceLayer = "power_generator_centroids",
            paint = CircleLayerPaint(
                fill = FillPaint(color = energySourceColor()),
                stroke = StrokePaint(
                    color = StyleValue.Constant(Color.White),
                    thickness = StyleValue.Constant(2.0),
                ),
                circle = CirclePaint(radius = StyleValue.Constant(6.0)),
            ),
            filter = energySourceFilter(),
        )
        return source to layer
    }

    /** The source and layer for [code], ready to register. */
    public fun descriptorsFor(
        code: PowerLayerCode,
        service: WeatherService,
    ): Pair<VectorSourceDescriptor, VectorLayerDescriptor<*>> = when (code) {
        PowerLayerCode.POWER_LINES -> powerLines(service)
        PowerLayerCode.POWER_PLANTS -> powerPlants(service)
        PowerLayerCode.POWER_GENERATORS -> powerGenerators(service)
        PowerLayerCode.POWER_GENERATOR_BOUNDARIES -> powerGeneratorBoundaries(service)
        PowerLayerCode.POWER_GENERATOR_CENTROIDS -> powerGeneratorCentroids(service)
    }
}

/**
 * Adds one of the power layers.
 *
 * Equivalent to `addWeatherLayer(LayerCode.POWER_LINES, …)` and the other power codes; kept for
 * callers that use [PowerLayerCode]. Mirrors [MapController.addRasterLayer].
 *
 * ```kotlin
 * mapController.addPowerLayer(PowerLayerCode.POWER_LINES)
 * ```
 *
 * All five share one source, so adding several is safe — `addSource` returns the existing source
 * when it is already registered.
 *
 * @param code Which power product to add.
 * @param beforeId Existing layer id to insert **below**; `null` appends on top.
 * @return The new [TileLayer], or `null` if it could not be added.
 */
public fun MapController.addPowerLayer(
    code: PowerLayerCode,
    beforeId: String? = null,
): TileLayer? {
    val (source, layer) = ManualWeatherLayers.descriptorsFor(code, service)
    addSource(source)
    return addLayer(layer, beforeId)
}

/**
 * Accumulation layers MapsGL JS ships (MapsGL JS 1.8.5) which have no [LayerCode] on Android.
 *
 * @property value The MapsGL product id, matching JS's weather code.
 * @property layerId The layer id JS registers.
 */
public enum class AccumLayerCode(
    public val value: String,
    public val layerId: String,
) {
    /** Total precipitation across the loaded range. */
    PRECIP_ACCUM("precip-accum", "conditions.precip_accum.fill"),

    /**
     * Total snowfall across the loaded range.
     *
     * **Known broken in 1.8.0:** folds the temperature band into the total and fills the whole map.
     * Not for production use.
     */
    SNOW_ACCUM("snow-accum", "conditions.snow_accum.fill"),
    ;

    public companion object {
        /** Looks up a code by its MapsGL product id, or null when it is not an accumulation layer. */
        public fun from(value: String): AccumLayerCode? = entries.firstOrNull { it.value == value }
    }
}

/**
 * Accumulated precipitation and snowfall — the two layers that exercise operation value remapping.
 *
 * Each folds its source's interval series into a running sum and re-encodes the total into a range
 * wider than the hourly layer's, so a multi-day total is not clipped at one hour's worth. That
 * widening is `remappedDataRange`, and these are the only layers that use it: `sleet-accum` and
 * `ice-accum` deliberately clamp at their hourly range, matching JS, where the remap is commented
 * out for `ice-accum`.
 *
 * Ranges, ids and paint follow the JS conditions group, where both layers are a merge over their
 * hourly counterpart that overrides only the domain.
 */
internal object ManualAccumLayers {

    /** JS: `remappedDataRange` max of `inToMMRate(20)`. */
    private val PRECIP_ACCUM_MAX = inToMMRate(20.0)

    /** JS: `remappedDataRange` max of `inToM(60)`. */
    private val SNOW_ACCUM_MAX = inToM(60.0)

    /**
     * An accumulation source is deliberately a **separate** source from its hourly counterpart, even
     * though it requests the same datasets: the aggregation folds decoded pixels in place, so a
     * layer wanting the raw intervals must not share it. [EncodedDataGroup] ids here follow the
     * shape the generated sources use, where `conditions_SLEET_ACCUM_PRECIP_TMP2` already coexists
     * with `conditions_SLEET_PRECIP_TMP2` on one product because the id is the enum name rather
     * than the product string.
     */
    private fun accumSource(
        service: WeatherService,
        id: String,
        datasets: List<EncodedDataset>,
        remappedMax: Double,
    ): EncodedSourceDescriptor =
        service.makeEncodedSourceDescriptor(EncodedDataGroup(id = id, datasets = datasets)).apply {
            operation = TimeSeriesOperationSpec(
                operation = EncodedRasterOperations.Operation.SUM,
                // One value spread across rgb, as the hourly layers encode it.
                bandsPerValue = 3,
                remappedDataRange = EncodedRasterOperations.DataRange(0.0, remappedMax),
            )
        }

    /** `precip-accum`: total precipitation across the loaded range, to 20 inches. */
    public fun precipAccum(
        service: WeatherService,
    ): Pair<EncodedSourceDescriptor, SampleLayerDescriptor> {
        val source = accumSource(
            service,
            id = "conditions_PRECIP_ACCUM",
            // The hourly precip bands: each covers a third of the rate range, as MapsGL JS's precip
            // source declares, so the value carries 765 steps rather than 255. Three full-range bands
            // quantised every hourly rate to about 0.00014 mm/s, so light precipitation folded to zero
            // in every interval and never accumulated (XMAPSGLSDK-444).
            datasets = DatasetGroups.conditions_PRECIP.datasets,
            remappedMax = PRECIP_ACCUM_MAX,
        )
        val layer = SampleLayerDescriptor(
            AccumLayerCode.PRECIP_ACCUM.layerId,
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red, ColorBand.green, ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    meld = false,
                    // Same floor as the hourly layer; the ceiling is the widened accumulation range.
                    drawRange = inToMMRate(0.01)..PRECIP_ACCUM_MAX,
                    colorScale = ColorScaleOptions(
                        stops = ColorScales.precip_accum.stops,
                        range = 0.0..PRECIP_ACCUM_MAX,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        return source to layer
    }

    /** `snow-accum`: total snowfall across the loaded range, to 60 inches. */
    public fun snowAccum(
        service: WeatherService,
    ): Pair<EncodedSourceDescriptor, SampleLayerDescriptor> {
        val source = accumSource(
            service,
            id = "conditions_SNOW_ACCUM",
            datasets = listOf(
                PrecipitationRateDataset(),
                PrecipitationRateDataset(),
                TemperatureDataset(),
            ),
            remappedMax = SNOW_ACCUM_MAX,
        )
        val layer = SampleLayerDescriptor(
            AccumLayerCode.SNOW_ACCUM.layerId,
            source.id,
            quality = DataQuality.high,
            paint = SampleLayerPaint(
                sample = SamplePaint(
                    channel = listOf(ColorBand.red, ColorBand.green, ColorBand.blue),
                    interpolation = InterpolationMode.BICUBIC,
                    meld = false,
                    drawRange = 0.00254..SNOW_ACCUM_MAX,
                    // The hourly Snow layer's ramp with the domain widened to the accumulation
                    // range. ColorScaleOptions infers its range from the stops when none is given,
                    // so passing one explicitly is what maps the same ramp across 0..60 inches.
                    colorScale = ColorScaleOptions(
                        stops = snowStops(),
                        range = 0.0..SNOW_ACCUM_MAX,
                        interval = 0.0,
                    ),
                ),
            ),
        )
        return source to layer
    }

    /** The hourly Snow layer's ramp, duplicated here because the conditions group is generated. */
    private fun snowStops(): List<ColorStop> = listOf(
        ColorStop(0.0, toColor("rgba(96,96,96,0)")),
        ColorStop(0.00025, toColor("rgba(96,96,96,0)")),
        ColorStop(0.00254, toColor("rgba(96,96,96,0.5)")),
        ColorStop(0.0254, toColor("#576066")),
        ColorStop(0.0762, toColor("#85D3FF")),
        ColorStop(0.1524, toColor("#25B4FF")),
        ColorStop(0.3048, toColor("#012DFF")),
        ColorStop(0.4572, toColor("#7000D9")),
        ColorStop(0.6096, toColor("#FF49C4")),
        ColorStop(1.2192, toColor("#FFECF7")),
        ColorStop(1.8288, toColor("#36E2F4")),
        ColorStop(3.048, toColor("#007682")),
        ColorStop(4.2672, toColor("#C38EF2")),
        ColorStop(6.096, toColor("#A34AF2")),
        ColorStop(7.62, toColor("#7100FF")),
    )

    /** The source and layer for [code], ready to register. */
    public fun descriptorsFor(
        code: AccumLayerCode,
        service: WeatherService,
    ): Pair<EncodedSourceDescriptor, SampleLayerDescriptor> = when (code) {
        AccumLayerCode.PRECIP_ACCUM -> precipAccum(service)
        AccumLayerCode.SNOW_ACCUM -> snowAccum(service)
    }
}

/**
 * Adds one of the accumulation layers.
 *
 * These have no [LayerCode], so they cannot go through `addWeatherLayer`; this mirrors
 * [MapController.addRasterLayer] and [addPowerLayer].
 *
 * ```kotlin
 * mapController.addAccumLayer(AccumLayerCode.PRECIP_ACCUM)
 * ```
 *
 * @param code Which accumulation product to add.
 * @param beforeId Existing layer id to insert **below**; `null` appends on top.
 * @return The new [TileLayer], or `null` if it could not be added.
 */
public fun MapController.addAccumLayer(
    code: AccumLayerCode,
    beforeId: String? = null,
): TileLayer? {
    val (source, layer) = ManualAccumLayers.descriptorsFor(code, service)
    addSource(source)
    return addLayer(layer, beforeId)?.also { it.zoomOffset = 0 }
}

/**
 * [LayerCode] configurations for the [PowerLayerCode] products, so they can be added with
 * `addWeatherLayer` as in MapsGL JS. Each one wraps the [ManualWeatherLayers] descriptors, so the
 * layer has one definition however it is added. Added by the 2026-10-06 additive regeneration: the
 * generator now emits these codes.
 */
public object PowerLayerConfigurations {
    /** Configuration for [LayerCode.POWER_LINES]. */
    public class PowerLines(public val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, LineLayerDescriptor>() {
        private val descriptors = ManualWeatherLayers.powerLines(service)
        override val code: LayerCode = LayerCode.POWER_LINES
        override val source: VectorSourceDescriptor = descriptors.first
        override val layer: LineLayerDescriptor = descriptors.second
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    /** Configuration for [LayerCode.POWER_PLANTS]. */
    public class PowerPlants(public val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, FillLayerDescriptor>() {
        private val descriptors = ManualWeatherLayers.powerPlants(service)
        override val code: LayerCode = LayerCode.POWER_PLANTS
        override val source: VectorSourceDescriptor = descriptors.first
        override val layer: FillLayerDescriptor = descriptors.second
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    /** Configuration for [LayerCode.POWER_GENERATORS]. */
    public class PowerGenerators(public val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        private val descriptors = ManualWeatherLayers.powerGenerators(service)
        override val code: LayerCode = LayerCode.POWER_GENERATORS
        override val source: VectorSourceDescriptor = descriptors.first
        override val layer: CircleLayerDescriptor = descriptors.second
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    /** Configuration for [LayerCode.POWER_GENERATOR_BOUNDARIES]. */
    public class PowerGeneratorBoundaries(public val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, FillLayerDescriptor>() {
        private val descriptors = ManualWeatherLayers.powerGeneratorBoundaries(service)
        override val code: LayerCode = LayerCode.POWER_GENERATOR_BOUNDARIES
        override val source: VectorSourceDescriptor = descriptors.first
        override val layer: FillLayerDescriptor = descriptors.second
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }

    /** Configuration for [LayerCode.POWER_GENERATOR_CENTROIDS]. */
    public class PowerGeneratorCentroids(public val service: WeatherService) :
        BaseVectorConfiguration<VectorSourceDescriptor, CircleLayerDescriptor>() {
        private val descriptors = ManualWeatherLayers.powerGeneratorCentroids(service)
        override val code: LayerCode = LayerCode.POWER_GENERATOR_CENTROIDS
        override val source: VectorSourceDescriptor = descriptors.first
        override val layer: CircleLayerDescriptor = descriptors.second
        override var presentation: Presentation? = null
        override var legend: Legend? = null
    }
}
