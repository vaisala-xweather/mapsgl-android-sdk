package com.xweather.mapsgl.weather

import com.xweather.mapsgl.layers.spec.LayerDescriptor
import com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.SymbolLayerPaint

/**
 * Generated [com.xweather.mapsgl.weather.groups.Tropical] symbol layers match icon image on
 * `details.stormType`. JS MapsGL matches on `upcase(details.stormCat)` with `H`/`H1`…`H5`/`TY`/`STY`
 * → hurricane, `TS`/`TD` → storm/depression, else `mapsgl:tropical-low`.
 *
 * Applied at add-time (same pattern as [WeatherMapTimeFilters]) so codegen Tropical.kt stays untouched.
 *
 * Post-tropical active tips (LO/I with prior TD/TS/H track) are handled in
 * [TropicalGeoJsonTransform] by promoting the last tropical track category onto position/forecast
 * features so Active All (Icons) keeps swirl + track-colored forecast instead of a blue low tip.
 */
internal object TropicalSymbolIconParity {

    /** JS `tropicalLayerConfig.symbol.paint.icon.image` parity. */
    private val stormCatIconExpression: Expression =
        Expression.match(
            Expression.upcase(Expression.get("details.stormCat")),
            listOf(
                Expression.Step(
                    listOf("H", "H1", "H2", "H3", "H4", "H5", "TY", "STY"),
                    result = "mapsgl:hurricane",
                ),
                Expression.Step("TS", result = "mapsgl:tropical-storm"),
                Expression.Step("TD", result = "mapsgl:tropical-depression"),
            ),
            "mapsgl:tropical-low",
        )

    /** JS `paint.icon.factor`: non-zero for cyclone `stormType` values, else `0`. */
    private val stormTypeFactorExpression: Expression =
        Expression.match(
            Expression.get("details.stormType"),
            listOf(
                Expression.Step(
                    listOf("H", "TY", "STY", "TS", "TD", "TC"),
                    result = 1,
                ),
            ),
            0,
        )

    fun applyToLayerDescriptor(layer: LayerDescriptor<*>) {
        val symbol = layer as? SymbolLayerDescriptor ?: return
        if (!symbol.id.startsWith("tropical.")) return
        val paint = symbol.paint as? SymbolLayerPaint ?: return
        val imageExpr = (paint.icon.image as? StyleValue.Expression)?.expression ?: return
        if (!expressionReferencesStormType(imageExpr.raw)) return
        paint.icon.image = StyleValue.Expression(stormCatIconExpression)
        if (paint.icon.factor == null) {
            paint.icon.factor = StyleValue.Expression(stormTypeFactorExpression)
        }
    }

    private fun expressionReferencesStormType(node: Any?): Boolean {
        when (node) {
            is Expression -> return expressionReferencesStormType(node.raw)
            is List<*> -> {
                if (node.isNotEmpty() && node[0] == "get") {
                    val key = node.getOrNull(1)
                    if (key == "stormType" || key == "details.stormType") return true
                }
                return node.any { expressionReferencesStormType(it) }
            }
            else -> return false
        }
    }
}
