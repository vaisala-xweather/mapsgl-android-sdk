package com.xweather.mapsgl.weather

/**
 * Stroke thickness defaults for built-in weather vector line layers (parity with `@xweather/mapsgl` JS registry).
 */
object WeatherLayerStrokeDefaults {
    /** JS `alerts-outline` → `paint.stroke.thickness: 3` (screen px). */
    const val ALERTS_OUTLINE_THICKNESS_PX = 3.0

    /** Custom GL polygon stroke on `severe.alerts.fill` (screen px). */
    const val ALERTS_FILL_OUTLINE_THICKNESS_PX = 1.0

    /** LineString alert geometry on the fill layer (matches [ALERTS_OUTLINE_THICKNESS_PX]). */
    const val ALERTS_FILL_LINE_RIBBON_THICKNESS_PX = ALERTS_OUTLINE_THICKNESS_PX
}
