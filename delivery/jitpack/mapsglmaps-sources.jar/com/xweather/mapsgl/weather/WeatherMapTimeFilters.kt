package com.xweather.mapsgl.weather

import com.xweather.mapsgl.layers.spec.LayerDescriptor
import com.xweather.mapsgl.layers.spec.VectorLayerDescriptor
import com.xweather.mapsgl.map.mapbox.VectorDrawTime
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.splitOnMapTime

/**
 * Applies iOS/JS map-time filter parity that weather codegen currently omits, and strips
 * playhead clauses for [LayerCode.ignoresMapTimeFilter] layers (tropical current positions).
 */
internal object WeatherMapTimeFilters {

    /** Flat dotted gets so [com.xweather.mapsgl.map.mapbox.StencilMaskFilter] can resolve nested JSON. */
    private val convectiveRangeFilter: Expression =
        Expression.and(
            listOf(
                Expression.greaterThanOrEqual(
                    Expression.mapTime,
                    listOf("get", "details.range.minTimestamp"),
                ).raw,
                Expression.lessThan(
                    Expression.mapTime,
                    listOf("get", "details.range.maxTimestamp"),
                ).raw,
            ),
        )

    /**
     * Mutates [layer] filter in place: inject convective range gating when missing, then strip
     * dynamic map-time clauses for exempt layer codes (keep static half only).
     */
    fun applyToLayerDescriptor(code: LayerCode, layer: LayerDescriptor<*>) {
        val vector = layer as? VectorLayerDescriptor<*> ?: return

        when (code) {
            LayerCode.CONVECTIVE, LayerCode.CONVECTIVE_OUTLINE -> {
                if (!VectorDrawTime.filterReferencesMapTime(vector.filter)) {
                    vector.filter = convectiveRangeFilter
                }
            }
            else -> Unit
        }

        if (!code.ignoresMapTimeFilter) return
        val filter = vector.filter ?: return
        val staticHalf = filter.splitOnMapTime().staticFilter
        // Mirror iOS: only replace when a static half exists; a pure map-time filter is left alone
        // so we do not accidentally admit every feature in the source.
        if (staticHalf != null) {
            vector.filter = staticHalf
        }
    }
}
