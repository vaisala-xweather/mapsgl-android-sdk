package com.xweather.mapsgl.weather

/**
 * iOS `WeatherService.LayerCode.mapTimeExempt` / `ignoresMapTimeFilter` parity.
 *
 * Position markers may declare `timestamp <= map-time` in JS/iOS configs so the expression
 * machinery stays consistent, but the current storm location must stay visible for the
 * whole timeline — so [com.xweather.mapsgl.map.MapController.addWeatherLayer] strips the
 * playhead half for these codes (keeping any static clauses).
 *
 * Kept outside generated [LayerCodes] so codegen can refresh without losing this behavior.
 *
 * **Do not "fix" this against the shared weather spec.** That spec now declares the playhead clause
 * on `tropical.positions_*.symbol|circle` and `tropical.names_*.text`, where the JS source it was
 * generated from has the same clause commented out:
 *
 * ```js
 * const positionFilter: Expression = [
 *     'all',
 *     ['==', ['get', 'featureType'], 'position']
 *     // mapTimeExpression
 * ];
 * ```
 *
 * Matching the spec was tried and reverted. Nothing else about a storm is gated on the playhead —
 * not the error cone, not the forecast points, not the forecast lines — so scrubbing back removed
 * the marker and the name while leaving the cone and its forecast track hanging in empty ocean,
 * attached to nothing. The commented-out line is the behaviour that actually ships and the one this
 * SDK matches. If positions are ever meant to scrub, the cone and forecast have to go with them.
 */
val LayerCode.ignoresMapTimeFilter: Boolean
    get() = MAP_TIME_EXEMPT.contains(this)

private val MAP_TIME_EXEMPT: Set<LayerCode> = setOf(
    LayerCode.TROPICAL_CYCLONES_POSITIONS,
    LayerCode.TROPICAL_CYCLONES_POSITION_ICONS,
    LayerCode.TROPICAL_CYCLONES_POSITIONS_INVESTS,
    LayerCode.TROPICAL_CYCLONES_POSITION_ICONS_INVESTS,
    // JS tropical name layers never scrub with map-time (same as live positions).
    LayerCode.TROPICAL_CYCLONES_NAMES,
    LayerCode.TROPICAL_CYCLONES_NAMES_ARCHIVE,
    LayerCode.TROPICAL_CYCLONES_NAMES_INVESTS,
)
