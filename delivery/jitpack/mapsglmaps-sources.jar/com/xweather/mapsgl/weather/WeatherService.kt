package com.xweather.mapsgl.weather

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.util.Log
import androidx.annotation.Keep
import com.xweather.mapsgl.config.weather.account.XweatherAccount
import com.xweather.mapsgl.layers.spec.CircleLayerDescriptor
import com.xweather.mapsgl.layers.spec.ContourLayerDescriptor
import com.xweather.mapsgl.layers.spec.FillLayerDescriptor
import com.xweather.mapsgl.layers.spec.GridLayerDescriptor
import com.xweather.mapsgl.layers.spec.HeatmapLayerDescriptor
import com.xweather.mapsgl.layers.spec.LineLayerDescriptor
import com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor
import com.xweather.mapsgl.layers.spec.RasterLayerDescriptor
import com.xweather.mapsgl.layers.spec.SampleLayerDescriptor
import com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor
import com.xweather.mapsgl.map.ImageRegisteringMap
import com.xweather.mapsgl.map.MapStyle
import com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor
import com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.utils.replaceVars
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import org.json.JSONObject
import java.net.URL

@Keep
/**
 * High-level factory/service for MapsGL weather products and source descriptors.
 *
 * `WeatherService` centralizes:
 * - account-aware authentication ([authenticator]) for MapsGL/AMP requests,
 * - sprite/style bootstrapping via [loadStyles],
 * - optional product metadata loading via [loadLayerMetadata],
 * - construction of source descriptors for raster, encoded, vector, AMP vector, and GeoJSON endpoints,
 * - and convenient static product builders in the companion object (for example [Temperatures], [Radar], [RoadMotorway]).
 *
 * Typical flow:
 * 1. Create service with [XweatherAccount].
 * 2. Call [loadStyles] once the map object is available.
 * 3. Build weather layer configurations (for example through companion product functions).
 * 4. Register resulting sources/layers with `MapController`.
 *
 * @property account Account credentials used to sign and build weather API requests.
 * @property authenticator Shared request authenticator used by descriptor factories that require MapsGL auth.
 * @property style Sprite/style loader used by [loadStyles].
 * @property isStyleLoaded `true` when [loadStyles] completes with no sprite generation/download failures.
 *
 * @see WeatherLayerConfiguration
 * @see WeatherConfigurations
 * @see LayerCodes
 */
class WeatherService(
    val account: XweatherAccount
) {
    val authenticator: XweatherAuthenticator = XweatherAuthenticator(account, mapsGLServer)
    val style: MapStyle = MapStyle()
    var isStyleLoaded: Boolean = false
        private set


    /**
     * Loads SDK sprite sheets and registers generated fallback assets used by weather symbol layers.
     *
     * Currently this loads entries from [XweatherStyle] and also creates/registers a local
     * `mapsgl:arrow` image used by gridded direction layers that rely on tintable icon rendering.
     * [isStyleLoaded] is set based on aggregate success.
     *
     * @param map Map image registry used to install sprite assets.
     * @param dpr Device pixel ratio for sprite variant selection.
     */
    suspend fun loadStyles(map: ImageRegisteringMap, dpr: Float = 1.0f) {
        var noLoadFailures = true
        coroutineScope {
            XweatherStyle.map { (key, urlPath) ->
                async {
                    // fix for issue 9, crash when app starts offline
                    try {
                        style.loadSprite("mapsgl", urlPath, map, dpr)
                    } catch (e: Exception) {
                        noLoadFailures = false
                        Log.e("WeatherService", "Failed to load sprite '$key' from $urlPath: ${e.message}", e)
                    }
                }
            }.forEach { it.await() }
        }

        // The CDN sprite sheets do not include a generic arrow icon, but gridded wind-direction
        // layers reference `mapsgl:arrow`. Register a small tintable SDF-style bitmap so Mapbox
        // can render + color it via `icon-color`.
        runCatching {
            val arrow = createSdfArrowBitmap(sizePx = 96)
            map.addImage("mapsgl:arrow", arrow, true)
        }.onFailure { e ->
            noLoadFailures = false
            Log.e("WeatherService", "Failed to register generated sprite 'mapsgl:arrow': ${e.message}", e)
        }

        isStyleLoaded = noLoadFailures
    }

    private fun createSdfArrowBitmap(sizePx: Int): Bitmap {
        val s = sizePx.coerceAtLeast(16)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(android.graphics.Color.TRANSPARENT)

        // Draw a right-pointing arrow in alpha; we then encode alpha into the red channel for SDF-style use.
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = android.graphics.Color.WHITE
        }
        val p = Path()
        val cx = s * 0.5f
        val cy = s * 0.5f
        val shaftHalfH = s * 0.10f
        val shaftL = s * 0.34f
        val headL = s * 0.22f
        val headHalfH = s * 0.22f

        val x0 = cx - shaftL
        val x1 = cx + shaftL
        val x2 = x1 + headL
        // Swallow/barbed head (deep center V), not a convex triangle on x1 — matches instanced GL wind arrow.
        val dNotch = s * 0.13f
        val dBarb = s * 0.038f
        var xNotch = x1 - dNotch
        val xBarb = x1 - dBarb
        val margin = s * 0.04f
        if (xNotch < x0 + margin) xNotch = x0 + margin
        p.moveTo(x2, cy)
        p.lineTo(xBarb, cy - headHalfH)
        p.lineTo(xNotch, cy)
        p.lineTo(xBarb, cy + headHalfH)
        p.lineTo(x1, cy + shaftHalfH)
        p.lineTo(x0, cy + shaftHalfH)
        p.lineTo(x0, cy - shaftHalfH)
        p.lineTo(x1, cy - shaftHalfH)
        p.close()

        c.drawPath(p, fill)

        // Encode ARGB alpha into the red channel and also keep it as alpha.
        val pixels = IntArray(s * s)
        bmp.getPixels(pixels, 0, s, 0, 0, s, s)
        for (i in pixels.indices) {
            val a = android.graphics.Color.alpha(pixels[i])
            pixels[i] = android.graphics.Color.argb(a, a, a, a)
        }
        bmp.setPixels(pixels, 0, s, 0, 0, s, s)
        return bmp
    }

    /**
     * Fetches user-facing weather product metadata from [layerMetadataURLPath].
     *
     * The response is parsed into [WeatherLayerMetadata] entries used by product browsers or docs-style UIs.
     *
     * @return `Result.success` with parsed metadata, or `Result.failure` when network/parsing fails.
     */
    suspend fun loadLayerMetadata(): Result<List<WeatherLayerMetadata>> {
        try {
            val request = URLRequest(layerMetadataURLPath)
            val response = request.execute()
            when (response.data) {
                is JSONObject -> {
                    val json = response.data.getJSONArray("layers")
                    val layers = mutableListOf<WeatherLayerMetadata>()
                    for (i in 0 until json.length()) {
                        val obj = json.getJSONObject(i)
                        val metadata = WeatherLayerMetadata(
                            id = obj.getString("id"),
                            title = obj.getString("title"),
                            description = obj.getString("description"),
                            type = obj.getString("type"),
                            imageUrl = URL(obj.getString("imageUrl")),
                            animatable = obj.getBoolean("animatable"),
                            categories = obj.getJSONArray("categories").let { arr ->
                                List(arr.length()) { arr.getString(it) }
                            },
                            dataRange = obj.getString("dataRange"),
                            dataCoverage = obj.getJSONArray("dataCoverage").let { arr ->
                                List(arr.length()) { arr.getString(it) }
                            },
                            updateInterval = obj.getString("updateInterval")
                        )
                        layers.add(metadata)
                    }
                    return Result.success(layers)
                }

                else -> {
                    return Result.failure(Exception("Layer metadata is not a valid JSON array"))
                }
            }
        } catch (e: Exception) {
            return Result.failure(e)
        }
    }

    /**
     * Creates a raster source descriptor for a weather product code using default id format `wx::raster.<code>`.
     */
    fun makeRasterSourceDescriptor(code: String): ImageSourceDescriptor =
        makeRasterSourceDescriptor("wx::raster.$code", code)

    /**
     * Creates a raster image source descriptor for tile-based weather imagery.
     *
     * @param id Source id to register on the map.
     * @param code Product code used in AMP raster tile and metadata endpoints.
     */
    fun makeRasterSourceDescriptor(id: String, code: String): ImageSourceDescriptor {
        val pathVars = mapOf(
            "accessKey" to "${account.id}_${account.secret}", "code" to code
        )

        val descriptor = ImageSourceDescriptor(id)
        descriptor.url = "$ampServer" + rasterTileURLPathTemplate.replaceVars(pathVars, true)
        descriptor.metadataUrl = "$ampServer" + rasterMetadataURLPath.replaceVars(pathVars, true)
        descriptor.tileSize = TileSize(512)
        //        descriptor.transformer = XweatherRasterSourceTransformer()
        //        descriptor.useTimeSeries = true

        return descriptor
    }

    /**
     * Creates an encoded source descriptor from a grouped dataset definition.
     */
    fun makeEncodedSourceDescriptor(group: EncodedDataGroup): EncodedSourceDescriptor =
        makeEncodedSourceDescriptor(group.id, group.datasets)

    // This function generates invalid metadata urls that look like this:
    // https://prod.v1.mapsgl.api.xweather.com//tile?api-key=id_secret&details=true
    /**
     * Creates a MapsGL encoded source descriptor for one or more encoded datasets.
     *
     * @param id Source id to register on the map.
     * @param datasets Encoded dataset list; each entry is assigned a [ColorBand] by index.
     */
    fun makeEncodedSourceDescriptor(
        id: String, datasets: List<EncodedDataset>
    ): EncodedSourceDescriptor {
        var queryParams = mapOf("api-key" to "${account.id}_${account.secret}")
        queryParams = queryParams + mapsGLTileMetadataURLQueryItems

        val queryString = queryParams.entries.joinToString("&") { (k, v) ->
            "${k}=${v}"
        }

        val descriptor = EncodedSourceDescriptor(id)
        descriptor.url = "$mapsGLServer$mapsGLTileURLPathTemplate"
        descriptor.metadataUrl = "$mapsGLServer$mapsGLTileMetadataURLPath"
        descriptor.tileSize = TileSize(512)
        descriptor.authenticator = authenticator

        descriptor.datasets = datasets.mapIndexed { index, dataset ->
            dataset.apply { band = ColorBand.fromRawValue(index) }
        }

        return descriptor
    }

    /**
     * Creates a vector source descriptor for a weather product code using default id format `wx::<code>`.
     */
    fun makeVectorSourceDescriptor(code: String): VectorSourceDescriptor = makeVectorSourceDescriptor("wx::$code", code)

    /**
     * Creates a MapsGL vector tile source descriptor.
     *
     * @param id Source id to register on the map.
     * @param code Product code used in MapsGL vector endpoints.
     */
    fun makeVectorSourceDescriptor(id: String, code: String): VectorSourceDescriptor {
        val pathVars = mapOf(
            "accessKey" to "${account.id}_${account.secret}", "code" to code
        )

        val descriptor = VectorSourceDescriptor(id)
        descriptor.url = "$mapsGLServer" + mapsGLVectorTileURLPathTemplate.replaceVars(pathVars)
        descriptor.metadataUrl = "$mapsGLServer" + mapsGLVectorMetadataURLPath.replaceVars(pathVars)
        descriptor.tileSize = TileSize(512)
        descriptor.authenticator = authenticator
        //        descriptor.transformer = XweatherRasterSourceTransformer()
        //        descriptor.useTimeSeries = true

        return descriptor
    }

    /**
     * Creates an AMP vector source descriptor for a weather product code using default id format `wx::<code>`.
     */
    fun makeAmpVectorSourceDescriptor(code: String): VectorSourceDescriptor =
        makeAmpVectorSourceDescriptor("wx::$code", code)

    /**
     * Creates an AMP vector tile source descriptor.
     *
     * @param id Source id to register on the map.
     * @param code Product code used in AMP vector endpoints.
     */
    fun makeAmpVectorSourceDescriptor(id: String, code: String): VectorSourceDescriptor {
        val pathVars = mapOf(
            "accessKey" to "${account.id}_${account.secret}", "code" to code
        )

        val descriptor = VectorSourceDescriptor(id)
        descriptor.url = "$ampServer" + vectorTileURLPathTemplate.replaceVars(pathVars)
        descriptor.metadataUrl = "$ampServer" + rasterMetadataURLPath.replaceVars(pathVars)
        descriptor.tileSize = TileSize(512)
        //        descriptor.transformer = XweatherRasterSourceTransformer()
        //        descriptor.useTimeSeries = true

        return descriptor
    }

    /**
     * Creates a GeoJSON source descriptor for an Xweather Data API route.
     *
     * This helper injects time placeholders and account credentials into query params, and forces
     * `format=geojson` so the source can be consumed by MapsGL vector-style layers.
     *
     * @param id Source id to register on the map.
     * @param route API route segment inserted into [geoJSONURLPathTemplate].
     * @param params Additional query parameters merged with required defaults.
     */
    fun makeGeoJSONSourceDescriptor(
        id: String, route: String, params: Map<String, Any> = emptyMap()
    ): GeoJSONSourceDescriptor {
        val pathVars = mapOf("route" to route)
        val queryParams = params.toMutableMap().apply {
            this["format"] = "geojson"
            if (!containsKey("from")) this["from"] = "{startDate::iso}"
            if (!containsKey("to")) this["to"] = "{endDate::iso}"
            this["client_id"] = account.id
            this["client_secret"] = account.secret
        }

        val queryString = queryParams.entries.joinToString("&") { (k, v) ->
            "${k}=${v}"
        }

        val descriptor = GeoJSONSourceDescriptor(id)
        descriptor.url = "$apiServer" + geoJSONURLPathTemplate.replaceVars(pathVars).removePrefix("/") + "?$queryString"

        return descriptor
    }


    /**
     * Product builders matching [LayerCode] entries (for example [Temperatures], [Radar]).
     *
     * Each function takes this [WeatherService] and returns a [WeatherLayerConfiguration]
     * ready for [com.xweather.mapsgl.map.MapController.addWeatherLayer]. Names follow the
     * product id (PascalCase). See [LayerCode] for the string ids.
     */
    companion object {
        /** Cap on timeline intervals requested from Xweather encoded metadata. */
        const val XweatherMaxIntervals = 50
        val XweatherStyle = mapOf(
            "icon" to "https://cdn.aerisapi.com/sdk/js/mapsgl/assets/sprite{suffix}.json",
            "sdf" to "https://cdn.aerisapi.com/sdk/js/mapsgl/assets/sprite-sdf{suffix}.json"
        )

        val apiServer = URL("https://data.api.xweather.com")
        val mapsGLServer = URL("https://prod.v1.mapsgl.api.xweather.com")
        val ampServer = URL("https://maps.api.xweather.com")
        val layerMetadataURLPath = "https://www.xweather.com/docs/mapsgl/api/layers"

        const val rasterMetadataURLPath = "/{accessKey}/{code}.json"
        const val rasterTileURLPathTemplate = "/{accessKey}/{code}/{z}/{x}/{y}/{time}@2x.png"
        const val vectorTileURLPathTemplate = "/{accessKey}/{code}/{z}/{x}/{y}/{time::utc:format[yyyyMMddhhmm00]}.pbf"
        const val geoJSONURLPathTemplate = "/{route}"

        const val mapsGLTileMetadataURLPath = "/tile?details=true&{datasets}&begin={startDate}&end={endDate}"
        const val mapsGLTileURLPathTemplate = "/tile/{z}/{x}/{y}/{width}x{height}/{time}.png"
        const val mapsGLVectorMetadataURLPath =
            "/vector/?details=true&products={code}&begin={startDate::iso}&end={endDate::iso}"
        const val mapsGLVectorTileURLPathTemplate = "/vector/{code}/{time::iso}/{z}/{x}/{y}.pbf"

        val mapsGLTileMetadataURLQueryItems = mapOf(
            "details" to "true"
        )


        @Keep
        fun Admin2Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.Admin2Boundaries(service)

        @Keep
        fun Admin34Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.Admin34Boundaries(service)

        @Keep
        fun Admin56Boundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.Admin56Boundaries(service)

        @Keep
        fun AirQuality(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.AirQuality(service)

        @Keep
        fun CarbonMonoxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.CarbonMonoxide(service)

        @Keep
        fun AirQualityHealthIndexCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityHealthIndexCategories(service)

        @Keep
        fun AirQualityIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndex(service)

        @Keep
        fun AirQualityIndexCaiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexCaiCategories(service)

        @Keep
        fun AirQualityIndexCaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexCaqiCategories(service)

        @Keep
        fun AirQualityIndexCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexCategories(service)

        @Keep
        fun AirQualityIndexChinaCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexChinaCategories(service)

        @Keep
        fun AirQualityIndexEaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexEaqiCategories(service)

        @Keep
        fun AirQualityIndexIndiaCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexIndiaCategories(service)

        @Keep
        fun AirQualityIndexUbaDaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexUbaDaqiCategories(service)

        @Keep
        fun AirQualityIndexUkDaqiCategories(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.AirQualityIndexUkDaqiCategories(service)

        @Keep
        fun NitricOxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.NitricOxide(service)

        @Keep
        fun NitrogenDioxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.NitrogenDioxide(service)

        @Keep
        fun Ozone(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Ozone(service)

        @Keep
        fun ParticulateMatter10Micron(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.ParticulateMatter10Micron(service)

        @Keep
        fun ParticulateMatter2p5Micron(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.ParticulateMatter2p5Micron(service)

        @Keep
        fun SulfurDioxide(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SulfurDioxide(service)

        @Keep
        fun Alerts(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.Alerts(service)

        @Keep
        fun AlertsOutline(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.AlertsOutline(service)

        @Keep
        fun Boundaries(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.Boundaries(service)

        @Keep
        fun CloudCover(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.CloudCover(service)

        @Keep
        fun Convective(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.Convective(service)

        @Keep
        fun ConvectiveOutline(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.ConvectiveOutline(service)

        @Keep
        fun DewPoints(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.DewPoints(service)

        @Keep
        fun DroughtMonitor(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.DroughtMonitor(service)

        @Keep
        fun DroughtMonitorOutline(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.DroughtMonitorOutline(service)

        @Keep
        fun Earthquakes(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.Earthquakes(service)

        @Keep
        fun EarthquakesHeat(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.EarthquakesHeat(service)

        @Keep
        fun FeelsLike(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.FeelsLike(service)

        @Keep
        fun Fires(service: WeatherService): CompositeWeatherLayerConfiguration = WeatherConfigurations.Fires(service)

        @Keep
        fun FiresIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.FiresIcons(service)

        @Keep
        fun FiresObs(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.FiresObs(service)

        @Keep
        fun FiresObsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.FiresObsHeat(service)

        @Keep
        fun FiresObsIcons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.FiresObsIcons(service)

        @Keep
        fun FiresObsNames(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.FiresObsNames(service)

        @Keep
        fun FiresOutlook(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.FiresOutlook(service)

        @Keep
        fun FiresPerimeter(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.FiresPerimeter(service)

        @Keep
        fun HailSevereProbability(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.HailSevereProbability(service)

        @Keep
        fun HailSevereProbabilityAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSevereProbabilityAustralia(service)

        @Keep
        fun HailSevereProbabilityEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSevereProbabilityEurope(service)

        @Keep
        fun HailSevereProbabilityJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSevereProbabilityJapan(service)

        @Keep
        fun HailSevereProbabilityUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSevereProbabilityUnitedStates(service)

        @Keep
        fun HailSize(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.HailSize(service)

        @Keep
        fun HailSizeAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HailSizeAustralia(service)

        @Keep
        fun HailSizeEurope(service: WeatherService): SampleConfiguration = WeatherConfigurations.HailSizeEurope(service)

        @Keep
        fun HailSizeJapan(service: WeatherService): SampleConfiguration = WeatherConfigurations.HailSizeJapan(service)

        @Keep
        fun HailSizeUnitedStates(service: WeatherService): SampleConfiguration =
            WeatherConfigurations.HailSizeUnitedStates(service)

        @Keep
        fun HailThreats(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.HailThreats(service)

        @Keep
        fun HailThreatsPoints(service: WeatherService): VCircleConfiguration =
            WeatherConfigurations.HailThreatsPoints(service)

        @Keep
        fun HailThreatsPolygons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.HailThreatsPolygons(service)

        @Keep
        fun HailThreatsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.HailThreatsTracks(service)

        @Keep
        fun HeatIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.HeatIndex(service)

        @Keep
        fun Humidity(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Humidity(service)

        @Keep
        fun LightningAll(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningAll(service)

        @Keep
        fun LightningAllIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningAllIcons(service)

        @Keep
        fun LightningDensity(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningDensity(service)

        @Keep
        fun LightningDensityAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityAustralia(service)

        @Keep
        fun LightningDensityCloudToGround(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningDensityCloudToGround(service)

        @Keep
        fun LightningDensityCloudToGroundAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityCloudToGroundAustralia(service)

        @Keep
        fun LightningDensityCloudToGroundEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityCloudToGroundEurope(service)

        @Keep
        fun LightningDensityCloudToGroundJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityCloudToGroundJapan(service)

        @Keep
        fun LightningDensityCloudToGroundUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityCloudToGroundUnitedStates(service)

        @Keep
        fun LightningDensityEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityEurope(service)

        @Keep
        fun LightningDensityIntracloud(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningDensityIntracloud(service)

        @Keep
        fun LightningDensityIntracloudAustralia(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityIntracloudAustralia(service)

        @Keep
        fun LightningDensityIntracloudEurope(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityIntracloudEurope(service)

        @Keep
        fun LightningDensityIntracloudJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityIntracloudJapan(service)

        @Keep
        fun LightningDensityIntracloudUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityIntracloudUnitedStates(service)

        @Keep
        fun LightningDensityJapan(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityJapan(service)

        @Keep
        fun LightningDensityUnitedStates(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.LightningDensityUnitedStates(service)

        @Keep
        fun LightningFlash(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.LightningFlash(service)

        @Keep
        fun LightningStrikes(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.LightningStrikes(service)

        @Keep
        fun LightningStrikesHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.LightningStrikesHeat(service)

        @Keep
        fun LightningStrikesIcons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.LightningStrikesIcons(service)

        @Keep
        fun LightningThreats(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.LightningThreats(service)

        @Keep
        fun LightningThreatsPoints(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.LightningThreatsPoints(service)

        @Keep
        fun LightningThreatsPolygons(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.LightningThreatsPolygons(service)

        @Keep
        fun LightningThreatsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.LightningThreatsTracks(service)

        @Keep
        fun OceanCurrents(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.OceanCurrents(service)

        @Keep
        fun OceanCurrentsParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.OceanCurrentsParticles(service)

        @Keep
        fun PlaceCity(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.PlaceCity(service)

        @Keep
        fun PlaceCountry(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.PlaceCountry(service)

        @Keep
        fun PlaceNeighborhood(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.PlaceNeighborhood(service)

        @Keep
        fun PlaceState(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.PlaceState(service)

        @Keep
        fun Places(service: WeatherService): CompositeWeatherLayerConfiguration = WeatherConfigurations.Places(service)

        @Keep
        fun Precipitation(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Precipitation(service)

        /*
        @Keep
        fun PrecipitationRate(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.PrecipitationRate(service)
        */
        @Keep
        fun PressureMeanSeaLevel(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.PressureMeanSeaLevel(service)

        @Keep
        fun PressureMeanSeaLevelContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> =
            WeatherConfigurations.PressureMeanSeaLevelContour(service)

        @Keep
        fun Radar(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Radar(service)

        @Keep
        fun RiverObservations(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.RiverObservations(service)

        @Keep
        fun RoadAll(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadAll(service)

        @Keep
        fun RoadMotorway(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadMotorway(service)

        @Keep
        fun RoadPrimary(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadPrimary(service)

        @Keep
        fun RoadSecondaryTertiary(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadSecondaryTertiary(service)

        @Keep
        fun RoadStreet(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadStreet(service)

        @Keep
        fun RoadTrunk(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.RoadTrunk(service)

        @Keep
        fun Roads(service: WeatherService): CompositeWeatherLayerConfiguration = WeatherConfigurations.Roads(service)

        @Keep
        fun Satellite(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.Satellite(service)

        @Keep
        fun SatelliteGeocolor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.SatelliteGeocolor(service)

        @Keep
        fun SatelliteInfraredColor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.SatelliteInfraredColor(service)

        @Keep
        fun SatelliteVisible(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.SatelliteVisible(service)

        @Keep
        fun SatelliteWaterVapor(service: WeatherService): WeatherLayerConfiguration<ImageSourceDescriptor, RasterLayerDescriptor> =
            WeatherConfigurations.SatelliteWaterVapor(service)

        @Keep
        fun Snow(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Snow(service)

        @Keep
        fun SnowDepth(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SnowDepth(service)

        @Keep
        fun SeaSurfaceTemperatures(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SeaSurfaceTemperatures(service)

        @Keep
        fun StormSurge(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.StormSurge(service)

        @Keep
        fun Stormcells(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.Stormcells(service)

        @Keep
        fun StormcellsCones(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.StormcellsCones(service)

        @Keep
        fun StormcellsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.StormcellsHeat(service)

        @Keep
        fun StormcellsPositions(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.StormcellsPositions(service)

        @Keep
        fun StormcellsTracks(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.StormcellsTracks(service)

        @Keep
        fun Stormreports(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.Stormreports(service)

        @Keep
        fun StormreportsHeat(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, HeatmapLayerDescriptor> =
            WeatherConfigurations.StormreportsHeat(service)

        @Keep
        fun SwellHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SwellHeights(service)

        @Keep
        fun SwellParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.SwellParticles(service)

        @Keep
        fun SwellPeriods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.SwellPeriods(service)

        @Keep
        fun Swell2Heights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Swell2Heights(service)

        @Keep
        fun Swell2Particles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.Swell2Particles(service)

        @Keep
        fun Swell2Periods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Swell2Periods(service)

        @Keep
        fun Swell3Heights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Swell3Heights(service)

        @Keep
        fun Swell3Particles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.Swell3Particles(service)

        @Keep
        fun Swell3Periods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Swell3Periods(service)

        @Keep
        fun Temperatures(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Temperatures(service)

        @Keep
        fun Temperatures1HourChange(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, /*SampleLayerPaint,*/ SampleLayerDescriptor> =
            WeatherConfigurations.Temperatures1HourChange(service)

        @Keep
        fun Temperatures24HourChange(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Temperatures24HourChange(service)

        @Keep
        fun TideHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.TideHeights(service)

        @Keep
        fun TropicalCyclones(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclones(service)

        @Keep
        fun TropicalCyclonesArchive(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesArchive(service)

        @Keep
        fun TropicalCyclonesArchiveIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesArchiveIcons(service)

        @Keep
        fun TropicalCyclonesBreakPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesBreakPoints(service)

        @Keep
        fun TropicalCyclonesForecastErrorCones(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastErrorCones(service)

        @Keep
        fun TropicalCyclonesForecastLines(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastLines(service)

        @Keep
        fun TropicalCyclonesForecastLinesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastLinesInvests(service)

        @Keep
        fun TropicalCyclonesForecastPointIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastPointIcons(service)

        @Keep
        fun TropicalCyclonesForecastPointIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastPointIconsInvests(service)

        @Keep
        fun TropicalCyclonesForecastPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastPoints(service)

        @Keep
        fun TropicalCyclonesForecastPointsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesForecastPointsInvests(service)

        @Keep
        fun TropicalCyclonesIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesIcons(service)

        @Keep
        fun TropicalCyclonesInvests(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesInvests(service)

        @Keep
        fun TropicalCyclonesInvestsIcons(service: WeatherService): CompositeWeatherLayerConfiguration =
            WeatherConfigurations.TropicalCyclonesInvestsIcons(service)

        @Keep
        fun TropicalCyclonesNames(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesNames(service)

        @Keep
        fun TropicalCyclonesNamesArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesNamesArchive(service)

        @Keep
        fun TropicalCyclonesNamesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesNamesInvests(service)

        @Keep
        fun TropicalCyclonesPositionIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesPositionIcons(service)

        @Keep
        fun TropicalCyclonesPositionIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesPositionIconsInvests(service)

        @Keep
        fun TropicalCyclonesPositions(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesPositions(service)

        @Keep
        fun TropicalCyclonesPositionsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesPositionsInvests(service)

        @Keep
        fun TropicalCyclonesTrackLines(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackLines(service)

        @Keep
        fun TropicalCyclonesTrackLinesArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackLinesArchive(service)

        @Keep
        fun TropicalCyclonesTrackLinesInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackLinesInvests(service)

        @Keep
        fun TropicalCyclonesTrackPointIcons(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointIcons(service)

        @Keep
        fun TropicalCyclonesTrackPointIconsArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointIconsArchive(service)

        @Keep
        fun TropicalCyclonesTrackPointIconsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, SymbolLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointIconsInvests(service)

        @Keep
        fun TropicalCyclonesTrackPoints(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPoints(service)

        @Keep
        fun TropicalCyclonesTrackPointsArchive(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointsArchive(service)

        @Keep
        fun TropicalCyclonesTrackPointsInvests(service: WeatherService): WeatherLayerConfiguration<GeoJSONSourceDescriptor, CircleLayerDescriptor> =
            WeatherConfigurations.TropicalCyclonesTrackPointsInvests(service)

        @Keep
        fun UltravioletIndex(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.UltravioletIndex(service)

        @Keep
        fun Visibility(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.Visibility(service)

        @Keep
        fun Water(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.Water(service)

        @Keep
        fun Land(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, FillLayerDescriptor> =
            WeatherConfigurations.Land(service)

        @Keep
        fun WaterwayLakeRiverBoundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.WaterwayLakeRiverBoundaries(service)

        @Keep
        fun WaterwayOceanBoundaries(service: WeatherService): WeatherLayerConfiguration<VectorSourceDescriptor, LineLayerDescriptor> =
            WeatherConfigurations.WaterwayOceanBoundaries(service)

        @Keep
        fun WaveHeights(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WaveHeights(service)

        @Keep
        fun WaveParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.WaveParticles(service)

        @Keep
        fun WavePeriods(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WavePeriods(service)

        @Keep
        fun WindChill(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WindChill(service)

        @Keep
        fun WindGusts(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WindGusts(service)

        @Keep
        fun WindParticles(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ParticleLayerDescriptor> =
            WeatherConfigurations.WindParticles(service)

        @Keep
        fun WindSpeeds(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
            WeatherConfigurations.WindSpeeds(service)

        @Keep
        fun WindBarbs(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.WindBarbs(service)

        @Keep
        fun WindDirectionArrows(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.WindDirectionArrows(service)

        @Keep
        fun WaveDirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.WaveDirectionGrid(service)

        @Keep
        fun SwellDirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.SwellDirectionGrid(service)

        @Keep
        fun Swell2DirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.Swell2DirectionGrid(service)

        @Keep
        fun Swell3DirectionGrid(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, GridLayerDescriptor> =
            WeatherConfigurations.Swell3DirectionGrid(service)


        //====================================================================================================================================


        //  @Keep
        //  fun PrecipitationRate(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, SampleLayerDescriptor> =
        //      WeatherConfigurations.PrecipitationRate(service)

        @Keep
        fun TemperaturesContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> =
            WeatherConfigurations.TemperaturesContour(service)

        @Keep
        fun WindSpeedsContour(service: WeatherService): WeatherLayerConfiguration<EncodedSourceDescriptor, ContourLayerDescriptor> =
            WeatherConfigurations.WindSpeedsContour(service)


    }


}
