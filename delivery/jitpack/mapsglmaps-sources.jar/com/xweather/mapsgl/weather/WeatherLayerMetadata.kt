package com.xweather.mapsgl.weather

import java.net.URL

data class WeatherLayerMetadata(
    val id: String,
    val title: String,
    val description: String,
    val type: String,
    val imageUrl: URL,
    val animatable: Boolean,
    val categories: List<String>,
    val dataRange: String,
    val dataCoverage: List<String>,
    val updateInterval: String
)