package com.xweather.mapsgl.tiles

import android.graphics.Bitmap
import android.opengl.GLES31
import android.opengl.GLUtils
import com.xweather.mapsgl.NativeLibCache
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.sources.DataPool
import com.xweather.mapsgl.utils.LRUCache
import java.nio.ByteBuffer
import kotlin.math.pow

private fun computeDefaultCacheCapacity(): Int {
    // Keep previously downloaded tiles longer so scroll-away/scroll-back doesn't trigger re-downloads.
    // We size this based on the runtime heap to avoid being overly aggressive on low-memory devices.
    val maxMemoryMb = Runtime.getRuntime().maxMemory() / (1024 * 1024)
    val target = when {
        maxMemoryMb < 512 -> 20_000
        maxMemoryMb < 1_024 -> 30_000
        else -> 60_000
    }
    return target.coerceIn(12_800, 60_000)
}

private val defaultCacheCapacity: Int = computeDefaultCacheCapacity()
private const val TAG = "TileCache"

/**
 * A `TileCache` is a cache of tiles that are currently in use by the map. It is used to keep track
 * of which tiles are currently in use, which tiles are pending, and which tiles are stale.
 * @template Data The type of data that the tiles contain.
 * @internal
 */
class TileCache<DataType : TileData>(val sourceID: String = "") {
    val tiles: LRUCache<String, Tile<DataType>> = LRUCache(
        capacity = defaultCacheCapacity,
        ttl = 0,
        onRemove = { key, value: Tile<DataType> ->
            //if (!_visibleTileBounds.contains(value.coord)) {
            //    trigger(TimeSeriesEvent.DATA_REMOVE, mapOf("tile" to value))
            //}
        }
    )


    companion object {
        var nativeCount = 0
        var bindCount = 0
        var lastBindCount = 0
        var concurrentCount = 0
        private var textureUnits: IntArray = IntArray(3072) //was 4096
        var hasInitialized = false

        // Global GPU bind budget shared across all layers.
        // This prevents a frame hitch when multiple layers bind in the same render pass.
        private var lastBindResetNs: Long = 0L
        private var globalBindCount: Int = 0
        private const val GLOBAL_MAX_BINDS_PER_FRAME = 8
        private const val FRAME_RESET_NS: Long = 16_000_000L // ~60fps

        private fun resetGlobalBindBudgetIfNeeded(nowNs: Long) {
            if (lastBindResetNs == 0L || nowNs - lastBindResetNs >= FRAME_RESET_NS) {
                lastBindResetNs = nowNs
                globalBindCount = 0
            }
        }

        private fun canBindMore(): Boolean = globalBindCount < GLOBAL_MAX_BINDS_PER_FRAME

        private fun recordBind() {
            globalBindCount++
        }
    }


    val _requestedTiles: MutableMap<String, Long> = mutableMapOf()
    val levels: MutableMap<Int, MutableList<Tile<DataType>>> = mutableMapOf()
    val _persistents: MutableMap<String, Tile<DataType>> = mutableMapOf()
    val _pending: MutableMap</*TileCoord*/String, Tile<DataType>> = mutableMapOf()
    val _pendingTime: MutableMap<String, Long> = mutableMapOf()
    val _stale: MutableMap<String, Boolean> = mutableMapOf()
    val bindList: MutableList<String> = mutableListOf()
    private val bindListLock: Any = Any()

    internal inline fun <T> withBindListLock(block: () -> T): T {
        return synchronized(bindListLock) { block() }
    }
    val removeFromGPUList: MutableList<Int> = mutableListOf()


    val hashList: HashMap<String, MutableList<String>> = hashMapOf()

    //val bindQueue: ConcurrentLinkedQueue<String> = ConcurrentLinkedQueue()

    //fixme: Below was set to 2. Keep at 0 until Partials and Persistents are better implemented.
    private val _persistentLevelCount: Int = 0 //2

    //private val _removeCallbacks: MutableList<(Tile<DataType>) -> Unit> = mutableListOf()
    private var textures: MutableMap<String, Bitmap>? = mutableMapOf()

    val hashMap = hashMapOf<String, Int>()

    lateinit var copyMap: MutableMap<String, Tile<DataType>>

    //var lastTileCount = 0
    var memUsage = 0f

    val capacity: Int
        get() = tiles.size + _persistentLevelCount.sumPowerOfFour()
    val keys: Set<String>
        get() = tiles.keys
    val count: Int
        get() = tiles.size
    val pendingCount: Int
        get() = _pending.size
    val staleCount: Int
        get() = _stale.size

    val nativeCache = NativeLibCache(sourceID)

    fun oneTimeCacheSetup() {
        if (hasInitialized) return
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glGenTextures(textureUnits.size, textureUnits, 0)
        hasInitialized = true
    }

    /**  Called from LayerHost. **/
    fun bindTextures(sourceId: String? = null): HashMap<String, Int> {
        val isEmpty = withBindListLock { bindList.isEmpty() }
        if (isEmpty) return hashMap
        if (pr.ON) {
            val size = withBindListLock { bindList.size }
            pr.p(TAG, pr.dataPool, "bindTextures() entered, bindList.size: $size")
        }

        var bindIncremented: Boolean
        val tempList = withBindListLock { bindList.toList() } // snapshot to avoid concurrent modification

        var count = 0
        val maxBindsPerFrame = 3
        val maxDeletesPerCall = 2

        //if (pr.ON) pr.p(TAG, pr.backfillEdge, "bindTextures() entered, bindList:${bindList}")

        resetGlobalBindBudgetIfNeeded(System.nanoTime())

        for (item in tempList) {
            if (count >= maxBindsPerFrame) break // per-layer cap
            if (!canBindMore()) break // global cap across all layers

            bindIncremented = false
            _requestedTiles.remove(item) // added 250305, to help notify when downloads are done

            if (removeFromGPUList.isNotEmpty()) {
                val deletes = minOf(removeFromGPUList.size, maxDeletesPerCall)
                val removeArray = removeFromGPUList.subList(0, deletes).toIntArray()
                GLES31.glDeleteTextures(deletes, removeArray, 0)
                println("$TAG bindTextures() removed ${deletes} textures from GPU (capped)")
                // Purge stale coordHash -> textureUnit mappings for any textures we just deleted.
                // Otherwise RenderPass can draw using a texture unit that no longer contains the expected tile.
                if (hashMap.isNotEmpty()) {
                    val deletedUnits = removeArray.toHashSet()
                    val toRemove = hashMap.entries.filter { it.value in deletedUnits }.map { it.key }
                    toRemove.forEach { hashMap.remove(it) }
                }
                removeFromGPUList.subList(0, deletes).clear()
            }
            try {
                val tile = tiles[item]!!
                if (tile.isEncoded) { //Encoded Tiles
                    if (pr.ON) pr.p(TAG, pr.backfillEdge, " bindTextures() binding ${item}")
                    //if (pr.ON) pr.p(TAG, pr.bindTextures, "before null check:")
                    //TODO: see if the null check triggers the catch
                    // If we've previously bound and freed `paddedData`, we can lazily restore it
                    // from native cache so the tile can be re-bound without re-downloading.
                    if (tile.encodedData?.paddedData == null) {
                        val nativeKey = "${sourceID}${tile.coordHash}"
                        val restored = nativeCache.getData(nativeKey)
                        if (restored != null) {
                            tile.encodedData?.paddedData = restored
                        }
                    }

                    if (tile.encodedData?.paddedData != null) {
                        val dim = tile.encodedData!!.dimension
                        val padded = tile.encodedData!!.paddedData!!
                        val expectedBytes = dim * dim * 4
                        if (padded.size != expectedBytes) {
                            android.util.Log.e(
                                TAG,
                                "Encoded tile buffer size mismatch: dim=$dim expectedBytes=$expectedBytes actual=${padded.size} " +
                                    "coord=${tile.coordHash} — upload may show banding/stripes",
                            )
                        }

                        if (pr.ON) pr.p(TAG, pr.edgeBlend, " bindTextures() binding $tile.coordHash}")

                        if (tile.bindNum < 0) {
                            tile.bindNum = bindCount
                            bindIncremented = true
                        } else {
                            bindIncremented = false
                        }

                        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureUnits[tile.bindNum])
                        hashMap[tile.coordHash] = textureUnits[tile.bindNum]
                        //GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_NEAREST)
                        //GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_NEAREST)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
                        GLES31.glTexImage2D(
                            GLES31.GL_TEXTURE_2D, 0, GLES31.GL_RGBA,
                            tile.encodedData!!.dimension, tile.encodedData!!.dimension,
                            0,
                            GLES31.GL_RGBA,
                            GLES31.GL_UNSIGNED_BYTE,
                            ByteBuffer.wrap(tile.encodedData!!.paddedData!!)
                        )
                        recordBind()

                        if (!nativeCache.containsKey("${sourceID}${tile.coordHash}")) {
                            nativeCount++
                        }

                        nativeCache.putData("${sourceID}${tile.coordHash}", tile.encodedData!!.paddedData!!)
                        tile.encodedData!!.paddedData = null

                        if (false && DataPool.paddedEnabled) {//fixme Testing false&&
                            DataPool.usedBBList.remove(tile.encodedData!!.paddedData)
                            DataPool.freepBBList.add(tile.encodedData!!.paddedData!!)
                            DataPool.paddedStatus()
                        } else if (false) {
                            tile.encodedData!!.paddedData = null  //fixme Testing this is default. test commenting out
                        }

                        if (pr.ON) pr.p(TAG, pr.infiniteLoad, " bindTextures() removing ${sourceId} ${tile.coordHash}")

                        Timeline.removePendingEncodedDownload(sourceID, tile.coordHash)
                        _pending.remove(tile.coordHash)
                        _pendingTime.remove(tile.coordHash)
                        withBindListLock { bindList.remove(item) }

                        if (bindIncremented) bindCount++
                        if (pr.ON) pr.p(TAG, pr.bindCount, "bindCount: $bindCount")
                    } else {
                    }

                } // end encoded
                else { // Raster Image
                    if (pr.ON) pr.p(
                        TAG,
                        pr.tileBind,
                        " bindTextures() doing ${tile.coordHash}, tile.data is null? ${tile.data == null} "
                    )
                    GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureUnits[bindCount])
                    hashMap[tile.coordHash] = textureUnits[bindCount]
                    GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
                    GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
                    GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
                    GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
                    GLUtils.texImage2D(GLES31.GL_TEXTURE_2D, 0, tile.data as Bitmap, 0)
                    recordBind()
                    bindCount++
                    tile.data = null
                    withBindListLock { bindList.remove(item) }
                }

            } catch (e: Exception) {
                concurrentCount++
                if (pr.ON) {
                    pr.p(TAG, pr.tileBind, "bindTextures() concurrent exception!\n$e", 2)
                    pr.p(
                        TAG,
                        pr.tileBind,
                        " bindTextures() error on $bindCount, number of errors:$concurrentCount  tile:${item}",
                        2
                    )
                }
            }
            count++
        }
        DataPool.bindCount = bindCount

        // Prevent drawing textures for tiles that are *not yet bound*.
        // Previously we removed hashMap entries for ALL tiles in `bindList`, which can cause
        // visible "on/off" flicker when scroll reveals add more tiles than we can bind this frame.
        // For tiles that were already bound earlier (bindNum >= 0), keep the existing texture mapping
        // until the re-bind actually happens.
        val pendingToBind = withBindListLock { bindList.toHashSet() }
        if (pendingToBind.isNotEmpty()) {
            pendingToBind.forEach { coordHash ->
                val tile = tiles[coordHash] ?: _persistents[coordHash]
                // Only purge mapping if the tile hasn't been bound yet.
                if (tile == null || tile.bindNum < 0) {
                    hashMap.remove(coordHash)
                }
            }
        }

        memoryLog()
        return hashMap
    }

    //** called from bindTextures(), used in testing to keep track of memory usage **/
    private fun memoryLog() {
        if (bindCount != lastBindCount) {
            val maxMemory = Runtime.getRuntime().maxMemory()
            val totalMemory = Runtime.getRuntime().totalMemory()
            memUsage = (totalMemory.toFloat() / maxMemory.toFloat())
            pr.p(
                TAG,
                pr.memoryMonitor,
                "bound: $bindCount, (${totalMemory / 1048576} / ${maxMemory / 1048576} MB)  (${(memUsage * 100).toInt()}%)  nc:${nativeCount}",
                2
            )

            lastBindCount = bindCount
        }
    }

    fun clearOutsideBounds(bounds: TileBounds?, clearNative: Boolean = true) {
        if (pr.ON) {
            pr.p(TAG, pr.clearMem, "clearOutsideBounds() ------------------------")
            pr.p(
                TAG,
                pr.clearMem,
                "clearOutsideBounds() want to clear outside top: ${bounds!!.top} bot: ${bounds.bottom} "
            )
            pr.p(TAG, pr.clearMem, "clearOutsideBounds() list of tiles in cache:")

            var remove: Boolean
            for (tile in tiles) {

                remove = false
                //pr.p(TAG, pr.clearMem, "     key ${tile.key}:")
                //pr.p(TAG, pr.clearMem, "     hashShort ${tile.value.coord.hashShort()}:")
                //pr.p(TAG, pr.clearMem, "     cordHash ${tile.value.coordHash}:")


                if (tile.value.coord.z != bounds.zoom) {
                    pr.p(
                        TAG,
                        pr.clearMem,
                        "clearOutsideBounds()  zoom: ${bounds.zoom} deleting other zoom ${tile.key}:",
                        2
                    )
                    remove = true
                } else if (tile.value.coord.x < bounds.left || tile.value.coord.x > bounds.right) {
                    pr.p(TAG, pr.clearMem, "clearOutsideBounds()  deleting outside x: ${tile.key}:", 2)
                    remove = true
                } else if (tile.value.coord.y > bounds.bottom || tile.value.coord.y < bounds.top) { //remember, bottom number is bigger than top number
                    pr.p(TAG, pr.clearMem, "clearOutsideBounds()  deleting outside y: ${tile.key}:", 2)
                    remove = true
                }

                if (remove) {
                    if (clearNative) {
                        // nativeCache keys are stored as: "${sourceID}${tile.coordHash}"
                        // (same as in bindTextures()).
                        nativeCache.removeData("$sourceID${tile.value.coordHash}")
                    }
                    // Capture texture unit mapping before removing from hashMap.
                    val existingUnit = hashMap[tile.value.coordHash]
                    hashMap.remove(tile.value.coordHash)

                    tile.value.data = null
                    //tile.value.encodedData.paddedData = null
                    _requestedTiles.remove(tile.key)
                    _pending.remove(tile.key)
                    _pendingTime.remove(tile.key)
                    textures!!.remove(tile.key)
                    tiles.remove(tile.key)


                    //remove from gpu
                    if (existingUnit != null) {
                        removeFromGPUList.add(existingUnit)
                    }


                }
            }
        }
    }

    fun contains(coord: TileCoord): Boolean {
        if (coord.z < _persistentLevelCount) {
            return _persistents.containsKey(coord.hash())
        } else {
            return tiles.containsKey(coord.hash())
        }
    }

    operator fun get(coord: TileCoord): Tile<DataType>? {
        return lookup(coord)
    }

    operator fun set(coord: TileCoord, tile: Tile<DataType>?) {
        if (tile != null) {
            updateTile(tile, coord)
        } else {
            removeTile(coord)
        }
    }

    private fun lookup(coord: TileCoord): Tile<DataType>? {
        return if (coord.z < _persistentLevelCount) {
            _persistents[coord.hash()]
        } else {
            tiles[coord.hash()]
        }
    }

    fun updateTile(tile: Tile<DataType>) {
        if (pr.ON) pr.p(
            "TileCache",
            pr.hashmapLong,
            "updateTile() tile.time: ${tile.time}  tile.coord.time: ${tile.coord.time} tile.coordHash: ${tile.coordHash}"
        )
        updateTile(tile, tile.coord)
    }

    fun updateTile(tile: Tile<DataType>, coord: TileCoord) {
        if (coord.z < _persistentLevelCount) {
            _persistents[tile.coordHash] = tile
        } else {
            if (pr.ON) pr.p(
                TAG,
                pr.tileReceived,
                "updateTile() putting tile in tiles[], data is null? ${tile.data == null}"
            )
            tiles[tile.coordHash] = tile
        }
        if (!levels.containsKey(tile.coord.z)) {
            levels[tile.coord.z] = mutableListOf()
        }
    }

    private fun removeTile(coord: TileCoord) {
        if (coord.z < _persistentLevelCount) {
            _persistents.remove(coord.hash())
        }
        if (levels.containsKey(coord.z)) {
            val removeIndex = levels[coord.z]?.indexOfFirst { tile -> tile.coord == coord }
            if (removeIndex != null && removeIndex != -1) {
                levels[coord.z]?.removeAt(removeIndex)
            }
            if (levels[coord.z]?.isEmpty() == true) {
                levels.remove(coord.z)
            }
        }
        textures?.remove(coord.hash())
    }

    fun isPending(coord: TileCoord): Boolean {
        return _pending.containsKey(coord.hash())
    }

    fun isStale(tile: Tile<DataType>): Boolean {
        return _stale.containsKey(tile.coordHash)
    }

    fun setPending(isPending: Boolean, tile: Tile<DataType>) {
        if (isPending) {
            if (!_pending.containsKey(tile.coordHash)) {
                _pending[tile.coordHash] = tile
                _pendingTime[tile.coordHash] = System.currentTimeMillis()
            }

        } else {
            _pending.remove(tile.coordHash)
            _pendingTime.remove(tile.coordHash)
        }
    }

    fun setStale(isStale: Boolean, tile: Tile<DataType>) {
        if (isStale) {
            _stale[tile.coordHash] = true
        } else {
            _stale.remove(tile.coordHash)
        }
    }

    fun removeAll() {
        tiles.clear()

    }

    fun cleanup() {
        GLES31.glDeleteTextures(textureUnits.size, textureUnits, 0)
        val error = GLES31.glGetError()
        if (error != GLES31.GL_NO_ERROR) {
            if (pr.ON) pr.p(TAG, pr.i13, "Error deleting texture names: $error")
        }
    }
}

private fun Int.sumPowerOfFour(): Int {
    return ((4.0.pow(this.toDouble()) - 1) / 3).toInt()
}