package com.xweather.mapsgl.tiles

import com.xweather.mapsgl.types.Point
import com.xweather.mapsgl.types.Rect
import kotlin.math.max
import kotlin.math.min

/**
 *  TileBoundsIOS.kt
 *  MapsGL Prototype
 *
 *  Created by Jason Suto on 12/22/23.
 *  Adapted from IOS
 **/

data class TileBounds(
    val zoom: Int,
    var left: Int,
    var right: Int,
    var top: Int,
    var bottom: Int
) {

    companion object {
        fun fromPointCoords(coords: List<Point>): TileBounds {
            var left = Double.POSITIVE_INFINITY
            var right = Double.NEGATIVE_INFINITY
            var top = Double.NEGATIVE_INFINITY
            var bottom = Double.POSITIVE_INFINITY

            coords.forEach { coord ->
                left = min(left, coord.x)
                right = max(right, coord.x)
                top = max(top, coord.y)
                bottom = min(bottom, coord.y)
            }

            return TileBounds( -1, left.toInt(), right.toInt(), top.toInt(), bottom.toInt())
        }

        fun fromCoords(coords: List<TileCoord>): TileBounds {
            var left = Double.POSITIVE_INFINITY
            var right = Double.NEGATIVE_INFINITY
            var top = Double.NEGATIVE_INFINITY
            var bottom = Double.POSITIVE_INFINITY

            coords.forEach { coord ->
                left = min(left, coord.x.toDouble())
                right = max(right, coord.x.toDouble())
                top = max(top, coord.y.toDouble())
                bottom = min(bottom, coord.y.toDouble())
            }

            return TileBounds( coords.first().z , left.toInt(), right.toInt(), top.toInt(), bottom.toInt())
        }
    }

    fun toHash(): String{
        return "$zoom,$left,$right,$top,$bottom"
    }

    fun contains(coord: TileCoord): Boolean {
        if (coord.z != zoom && coord.z != -1) {
            return false
        }
        if (coord.x < left || coord.x > right || coord.y < top || coord.y > bottom) {
            return false
        }
        return true
    }

    val info: Rect
        get() = Rect(top = this.top, bottom = this.bottom, left = this.left, right = this.right)
}

