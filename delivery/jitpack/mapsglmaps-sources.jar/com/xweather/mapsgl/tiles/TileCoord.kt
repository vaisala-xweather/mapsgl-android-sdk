package com.xweather.mapsgl.tiles

import android.graphics.Point
import com.xweather.mapsgl.coordinates.LatitudeLongitude
import com.xweather.mapsgl.coordinates.MapBounds
import com.xweather.mapsgl.coordinates.MapCoordinate
import com.xweather.mapsgl.coordinates.SIMD2
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import kotlin.math.floor

/**
 * TileCoord.kt
 *
 * Integer Coordinates for a Tile
 *
 * @author Jason Suto (11/30/23)
 * @param  x: Int
 * @param  y: Int
 * @param  z: Int */
class TileCoord(var x: Int, val y: Int, val z: Int, var offset: Int = 0, var time: String = ""/*, var timeOffset: Long = 0*/) {
    //class TileCoord(var x: Int, val y: Int, val z: Int, var offset: Int = 0/*, var timeOffset: Long = 0*/) {

    companion object {
        var tempMax = 0

        fun fromHash(hash: String): TileCoord? {
            kotlin.runCatching {
                val parts = hash.substring(hash.indexOf(":") + 1).split('/')
                return TileCoord(parts[1].toInt(), parts[2].toInt(), parts[0].toInt(), 0, parts[3])
            }
            return null
        }

        fun fromHashShort(hash: String): TileCoord? {
            kotlin.runCatching {
                val parts = hash.substring(hash.indexOf(":") + 1).split('/')
                return TileCoord(parts[1].toInt(), parts[2].toInt(), parts[0].toInt(), 0)
            }
            return null
        }
    }

    /** Used as a key in TileCache
     * @return ${wrap()}:${z}/${x}/${y} */
    fun hashShort(): String {
        return "${wrap().toInt()}:${z}/${x}/${y}"
    }

    /** Used as a key in TileCache
     * @return ${wrap()}:${z}/${x}/${y}/${time} */
    fun hash(): String {
        if(time.length<2)
            return "${wrap().toInt()}:${z}/${x}/${y}/"
        else
            return "${wrap().toInt()}:${z}/${x}/${y}/$time"
    }

    /**
     * @param  southwest: MapCoordinate<LatitudeLongitude>
     * @param  northEast: MapCoordinate<LatitudeLongitude> */
    val mapBounds: MapBounds<LatitudeLongitude>?
        get() {
            val northeast =
                MapCoordinate/*<MapTile>*/(SIMD2<Int>((x + 1).toDouble(), y.toDouble()), LatitudeLongitude())
                    .convertedTo(LatitudeLongitude())
            val southwest =
                MapCoordinate/*<MapTile>*/(SIMD2<Int>(x.toDouble(), (y + 1).toDouble()), LatitudeLongitude())
                    .convertedTo(LatitudeLongitude())
            return MapBounds(southwest, northeast)
        }

    /**
     * @return  "TileCoord: ${z}/${x}/${y}, wrap: ${this.wrap()}" */
    override fun toString() = "TileCoord: ${z}/${x}/${y}, wrap: ${this.wrap()}, time: $time"

    /**
     * Folds an out-of-world `x` back into the primary world copy.
     *
     * `x` uses [Math.floorMod], not `%`: Kotlin's remainder keeps the sign of the dividend, so a
     * west-copy tile (x = -1) stayed at -1 instead of folding to the east edge, and the
     * edge-blending neighbour lookup in `XweatherEncodedTileSource` — whose whole purpose is
     * "handle world wraparound (x < 0 or x > max)" — missed every tile across the antimeridian.
     *
     * `y` deliberately keeps plain `%`. Mercator does not wrap vertically, so a y outside the grid
     * is genuinely off-map (`getNeighbors` produces y = -1 above the top row); folding it would
     * silently substitute a tile from the opposite pole.
     */
    fun normalized(): TileCoord {
        val max = 1 shl z
        return TileCoord(Math.floorMod(x, max), y % max, z, 0, time)
    }

    fun wrap() =
        powerTableD[z].let {
            floor(x.toDouble() / it).toFloat()
        }

    fun isRoot() = z == 0

    fun equals(coord: TileCoord) = coord.let { z == it.z && y == it.y && x == it.x && time == it.time }

    /**
     * Returns the normalized coordinate. See [normalized] for why `x` uses [Math.floorMod] while
     * `y` keeps plain `%`.
     *
     * @returns {TileCoord}
     * @memberof TileCoord
     */
    fun normalize() = (1 shl z).let { max ->
        TileCoord(Math.floorMod(x, max), y % max, z, time = time)
    }

    fun getAncestor(offset: Int = 1) = powerTableD[offset].let {
        TileCoord(
            floor(x.toDouble() / it).toInt(),
            floor((y.toDouble() / it)).toInt(),
            z - offset,
            time = time
        )
    }

    fun getDescendants(offset: Int = 1): HashMap<Int, TileCoord> {
        val scale = powerTableI[offset]
        val coords = HashMap<Int, TileCoord>()
        for (x in 0 until scale) {
            val stride = x * scale
            for (y in 0 until scale) {
                coords[stride + y] =
                    TileCoord((x * scale + x).toInt(), (y * scale + y).toInt(), z + offset, time = time)
            }
        }
        return coords
    }

    fun getNeighbor(xOffset: Int, yOffset: Int): TileCoord {
        var nx: Int
        var ny = 0

        if (z == 0) {
            nx = x
            ny = y //new
        } else {
            val max = powerTableI[z]
            nx = x + xOffset
            ny = y + yOffset

            if (nx < 0) {
                nx += max
            } else if (nx > max - 1) {
                nx -= max
            }
        }

        return TileCoord(nx, ny, z, time = time);
    }

    fun getNeighbors(): HashMap<TileQuadrant, TileCoord> {


        val map = HashMap<TileQuadrant, Int>()
        map[TileQuadrant.Left] = -1
        map[TileQuadrant.Center] = 0
        map[TileQuadrant.Right] = 1
        map[TileQuadrant.Top] = -1
        map[TileQuadrant.Middle] = 0
        map[TileQuadrant.Bottom] = 1

        HashMap<TileQuadrant, TileCoord>().let {
            it[TileQuadrant.TopLeft] =
                getNeighbor(map[TileQuadrant.Left]!!, map[TileQuadrant.Top]!!)
            it[TileQuadrant.TopCenter] =
                getNeighbor(map[TileQuadrant.Center]!!, map[TileQuadrant.Top]!!)
            it[TileQuadrant.TopRight] =
                getNeighbor(map[TileQuadrant.Right]!!, map[TileQuadrant.Top]!!)
            it[TileQuadrant.MiddleLeft] =
                getNeighbor(map[TileQuadrant.Left]!!, map[TileQuadrant.Middle]!!)
            //it[TileQuadrant.MiddleCenter] = this
            it[TileQuadrant.MiddleRight] =
                getNeighbor(map[TileQuadrant.Right]!!, map[TileQuadrant.Middle]!!)
            it[TileQuadrant.BottomLeft] =
                getNeighbor(map[TileQuadrant.Left]!!, map[TileQuadrant.Bottom]!!)
            it[TileQuadrant.BottomCenter] =
                getNeighbor(map[TileQuadrant.Center]!!, map[TileQuadrant.Bottom]!!)
            it[TileQuadrant.BottomRight] =
                getNeighbor(map[TileQuadrant.Right]!!, map[TileQuadrant.Bottom]!!)

            return it
        }
    }

    fun getQuadrant() = Pair(x % 2, y % 2)

    /*
     * Check direct decendant 1 layer
     */
    fun isAncestorOf(coord: TileCoord): Boolean {
        if (this.z >= coord.z) {
            return false;
        }

        val diff = coord.z - this.z;
        val scale = powerTableD[diff]

        val xx = floor(coord.x / scale);
        val yy = floor(coord.y / scale);

        if (x != xx.toInt()) {
            return false
        }
        return y == yy.toInt()
    }

    fun isDescendantOf(coord: TileCoord) = coord.isAncestorOf(this)

    /**
     * Returns the normalized position for the top-left corner of the tile coordinate.
     *
     * @returns {Point}
     * @memberof TileCoord
     */
    fun getPosition() = powerTableD[z].let {
        Point((x / it).toInt(), (y / it).toInt())
    }

    /**
     * Returns the normalized position for the center of the tile coordinate.
     *
     * @returns {Point}
     * @memberof TileCoord
     */
    fun getCenter() = powerTableD[z].let {
        Point(x, y)
    }

}

enum class TileQuadrant(val str: String) {
    Left("l"),
    Center("c"),
    Right("r"),
    Top("t"),
    Middle("m"),
    Bottom("b"),
    TopLeft("tl"),
    TopCenter("tc"),
    TopRight("tr"),
    MiddleLeft("ml"),
    //MiddleCenter("mc"),
    MiddleRight("mr"),
    BottomLeft("bl"),
    BottomCenter("bc"),
    BottomRight("br")
}