package com.xweather.mapsgl.tiles

import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.math.Vector3
//import com.xweather.mapsgl.types.TextureCoordinateOffset

typealias AnyTileRenderable = TileRenderable<*>

interface TileRenderableProtocol {
}

/** Holds a Tile (TileCoord, data, hash, state, and bounds) along with scale, offset, */
data class TileRenderable<DataType : TileData>(
    val tile: Tile<DataType>,

    ) : TileRenderableProtocol {

    var scale = Vector3(1.0f, 1.0f, 1.0f)
    var offset = Vector3(0.0f, 0.0f, 0.0f)
    //var uvOffset: TextureCoordinateOffset = TextureCoordinateOffset()
    var coord: TileCoord = tile.coord
    var partialScale = 1f

    init {
        // Rule: dateline-world-copy. [TileCoord.offset] is the world-copy COUNT, so the world
        // column this renderable occupies is `x + offset * 2^z`. It used to be the raw tile-index
        // delta (already a multiple of 2^z), which is why adding it bare was correct here — until
        // db618023 ("resolve date-line rendering gap for wide zoomed-out playback") redefined it.
        // That commit updated every *vector* consumer to multiply by the world width but missed
        // this shared one, so from then on a world copy was shifted by a single tile instead of a
        // whole world: at the antimeridian the renderer drew z3 column 6 while the downloader
        // (which enumerates from the unmutated coords) fetched column 7, and that side of the
        // dateline stayed permanently blank while the offset-0 side rendered fine.
        coord.x += this.coord.offset * (1 shl coord.z)
    }

    /**
     * Returns the view matrix for the tile including its scale and translation transformations.
     */
    fun getViewMatrix(): ProjectionMatrix {
        val matrix = ProjectionMatrix()
        matrix.scale(scale)
        matrix.translate(offset)
        return matrix
    }
}


