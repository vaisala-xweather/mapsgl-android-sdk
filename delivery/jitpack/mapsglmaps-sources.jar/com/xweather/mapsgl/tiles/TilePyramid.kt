package com.xweather.mapsgl.tiles

import android.util.Log
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.coordinates.LatitudeLongitude
import com.xweather.mapsgl.coordinates.MapBounds
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.sources.TileSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.util.Calendar
import java.util.Date
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.floor

private const val TAG = "TilePyramid"

/**
 * A geographic bounding box in degrees (west/south/east/north extents), used throughout the SDK
 * to describe a layer or viewport's coverage region.
 *
 * @property wrapped True when this box crosses the antimeridian (its east extent wraps past ±180°).
 */
data class LatLonBounds(
    val westExtent: Double,
    val southExtent: Double,
    val eastExtent: Double,
    val northExtent: Double,
    val wrapped: Boolean = false
)

/** A 2D point in normalized global map coordinates (fraction of the world, 0.0-1.0 on each axis). */
data class GLCoordinate2D(var x: Double, var y: Double)

/**
 *  TilePyramid.kt
 *
 *  Adapted from IOS version.
 *  @author Jason Suto on 12/18/23.
 */
class TilePyramid<DataType : TileData>(private val layer: TileLayer) {
    /** Cache-scoping key combining this layer's account id and secret, identifying which account's credentials this pyramid's tile data was downloaded under. */
    val key: String = "${layer.mapController?.account?.id}_${layer.mapController?.account?.secret}"
    private val worldCoord = TileCoord(0, 0, 0)
    // ReentrantLock, not synchronized(this): this class's methods are called constantly from the
    // same hot download/bind paths that have already caused an R8/ART VerifyError on some devices
    // for a different lock elsewhere in this codebase.
    private val quietWorldTileJobLock = ReentrantLock()
    @Volatile
    private var quietWorldTileJob: Job? = null
    private var timesArray: Array<String>? = arrayOf("", "")
    private lateinit var timeline: Timeline
    /** The bracketed ISO-8601 UTC date string (see [bracketedRasterInterval]) resolved by [ensureFormattedDate]; null until the first request pass runs. */
    var formattedDate: String? = null
    /** The [TileRequestOptions] captured by [ensureFormattedDate] the first time it runs for this pyramid, retained for later fallback requests. */
    lateinit var fallbackOptions: TileRequestOptions
    /** Legacy per-layer interval cap; not consulted elsewhere in this class (superseded by the global caps in [Timeline]). */
    val maxIntervals = 8
    /** The [TileCache.memUsage] value observed on the last [checkAndClearMemory] call, used to detect memory-usage changes. */
    var memUsageLast = 0f

    /** The [TileSource] backing this pyramid; delegates to (and stays in sync with) [TileLayer.source]. */
    var tileSource: TileSource<TileData> //<DataType>
        get() = layer.source
        set(value) {
            layer.source = value
        }

    /** Convenience accessor for this pyramid's [tileSource]'s [TileCache]. */
    val tileCache: TileCache<com.xweather.mapsgl.sources.DataType>
        get() = tileSource.tileCache

    /**
     * Alternate time-string keys for the same instant (layer canonical vs global timeline format).
     * Tiles may have been stored under either string before [filterTimelineByValidTimes] was fixed.
     */
    private fun cacheLookupTimeKeys(layerLists: LayerTimeline?, canonicalTime: String, timeLong: Long?): List<String> {
        val keys = LinkedHashSet<String>()
        if (canonicalTime.length >= 2) {
            keys.add(canonicalTime)
        }
        if (timeLong != null) {
            val globalIdx = Timeline.timeLongs.indexOf(timeLong)
            if (globalIdx >= 0) {
                Timeline.timeStrings.getOrNull(globalIdx)?.let { global ->
                    if (global.length >= 2) keys.add(global)
                }
            }
            layerLists?.timeLongs?.indexOf(timeLong)?.takeIf { it >= 0 }?.let { layerIdx ->
                layerLists.timeStrings.getOrNull(layerIdx)?.let { layer ->
                    if (layer.length >= 2) keys.add(layer)
                }
            }
        }
        return keys.toList()
    }

    /**
     * True when this coord×time is actively downloading or has bindable pixels (GPU, native, or
     * padded Java heap).
     *
     * Do **not** treat [TileCache._requestedTiles] alone as satisfied — playback refresh cancels
     * leave those marks behind (Timeline pending is cleared in [releasePendingEncodedTimelineKeys],
     * but `_requestedTiles` was not), which permanently skips HTTP/re-bind and freezes the layer on
     * the last GPU-resident interval while the clock keeps advancing.
     *
     * Do **not** treat [TileList.readyList] or a hollow [TileCache.tiles] shell as satisfied either.
     */
    private fun encodedPairSatisfied(
        sourceId: String,
        coord: TileCoord,
        canonicalTime: String,
        timeLong: Long? = null,
        layerLists: LayerTimeline? = Timeline.sourceTimeHash[sourceId],
    ): Boolean = encodedPairSatisfiedMatch(sourceId, coord, canonicalTime, timeLong, layerLists) != null

    /**
     * Same check as [encodedPairSatisfied], but also returns *which* [cacheLookupTimeKeys] variant
     * (and its hash) actually matched. A tile can be cached under an alternate time-string format
     * (layer-canonical vs global-timeline) than [canonicalTime] itself — recomputing the hash from
     * [canonicalTime] alone (as the caller previously did for shell-reinsert/rebind) silently misses
     * that data, leaving the tile "satisfied" (skipped, never re-requested) but never actually
     * queued for GPU bind under the hash the renderer looks up. That permanently froze a small
     * number of tile/interval pairs even though their pixels were already cached.
     */
    private fun encodedPairSatisfiedMatch(
        sourceId: String,
        coord: TileCoord,
        canonicalTime: String,
        timeLong: Long? = null,
        layerLists: LayerTimeline? = Timeline.sourceTimeHash[sourceId],
    ): Pair<String, String>? {
        val keys = cacheLookupTimeKeys(layerLists, canonicalTime, timeLong)
        for (timeKey in keys) {
            val hash = TileCoord(coord.x, coord.y, coord.z, 0, timeKey).hash()
            // Active download only — not a stale `_requestedTiles` mark from a cancelled job.
            if (tileCache._pending.containsKey(hash)) {
                return timeKey to hash
            }
            if (tileCache.hasBindableEncodedPixels(hash)) {
                return timeKey to hash
            }
        }
        return null
    }

    /**
     * After scrub / playhead step, re-queue already-loaded visible tiles for GPU bind without HTTP.
     * Skips keys already in [TileCache.hashMap] (already drawable).
     * @return true if any new bind work was queued
     */
    internal fun requeueLoadedVisibleTilesForBind(coords: List<TileCoord>, times: Array<String>?): Boolean {
        if (!tileSource.isEncoded || times.isNullOrEmpty()) return false
        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val sourceId = layer.source.id
        var queued = false
        for (time in times) {
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            for (coord in coords) {
                if (!encodedPairSatisfied(sourceId, coord, time, timeLong, layerLists)) continue
                val lookupCoord = TileCoord(coord.x, coord.y, coord.z, time = time)
                val hash = lookupCoord.hash()
                if (tileCache.hashMap.containsKey(hash)) continue
                if (!tileCache.reinsertShellForNativeBindIfNeeded(lookupCoord, hash)) continue
                tileCache.withBindListLock {
                    if (!tileCache.bindList.contains(hash)) {
                        tileCache.bindList.add(hash)
                        queued = true
                    }
                }
            }
        }
        return queued
    }

    private fun kickGpuBindIfNeeded(queuedBindWork: Boolean) {
        if (!queuedBindWork && tileCache.bindList.isEmpty()) return
        val mapController = layer.mapController as? MapboxMapController ?: return
        mapController.layerHosts[layer.id]?.setTexturesToBind(true)
        mapController.mapboxMap?.executeOnRenderThread {
            mapController.layerHosts[layer.id]?.bindTextures(layer.source.id)
        }
        mapController.redraw()
    }

    /**
     * Maps a timeline instant to this layer's [LayerTimeline] valid-time list: exact match, else next valid time
     * at or after the scrub, else last valid time (same idea as [filterTimelineByValidTimes]).
     * Paused mode used to require an **exact** tick match, so new layers often requested **no** times until play().
     */
    private fun closestLayerValidTime(layerLists: LayerTimeline, timelineLong: Long): Pair<Long, String>? {
        if (layerLists.timeLongs.isEmpty()) return null
        val searchResult = layerLists.timeLongs.binarySearch(timelineLong)
        if (searchResult >= 0) {
            return layerLists.timeLongs[searchResult] to layerLists.timeStrings[searchResult]
        }
        val insertionPoint = -(searchResult + 1)
        if (insertionPoint < layerLists.timeLongs.size) {
            val j = insertionPoint
            return layerLists.timeLongs[j] to layerLists.timeStrings[j]
        }
        val last = layerLists.timeLongs.lastIndex
        return layerLists.timeLongs[last] to layerLists.timeStrings[last]
    }

    /**
     * Time strings to request while paused/scrubbing. Uses the same phase mapping as
     * [LayerTimeline.computeGlobalAnimationTarget] / [RenderPass] (sparse playback lists until
     * staggered fill is [com.xweather.mapsgl.anim.StaggeredIntervalPhase.Full]), not raw global
     * [Timeline.currentPhaseA]/[Timeline.currentPhaseB] indices via [filterABTimesByValidTimes].
     */
    internal fun timesForPausedOrScrubDownload(sourceId: String): Array<String> {
        val layerLists = Timeline.sourceTimeHash[sourceId] ?: return emptyArray()
        val collected = LinkedHashSet<String>()

        fun addRequestInOrder(timeLong: Long, timeString: String) {
            // reqStrings/reqLongs/reqGenerations are the full-range playback-readiness accounting
            // owned exclusively by [filterTimelineByValidTimes] while playing (its coarse,
            // fixed-size global-tick grid). This function is also invoked during active play via
            // [TileLayer.requeueVisibleBindsForScrub] on every ~2s loop-wrap rebind
            // ([MapController.schedulePlaybackLayerRefreshAfterScrub]), registering the
            // *instantaneous* interpolated animation target — a much finer-grained value (up to
            // the layer's full native resolution) that the coarse grid may never select again.
            // Left unguarded, this added a fresh orphan on every loop wrap, permanently inflating
            // neededIntervals and blocking full-range-ready even after everything the real
            // download grid needed had loaded. Only register while not playing (its stated,
            // original paused/scrub purpose).
            if (Timeline.isGloballyPlaying) return
            val insertionIndex = layerLists.reqLongs.binarySearch(timeLong)
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                layerLists.reqLongs.add(correctIndex, timeLong)
                layerLists.reqStrings.add(correctIndex, timeString)
                layerLists.reqGenerations.add(correctIndex, Timeline.reqGeneration)
            }
        }

        // Match the next draw frame (idle: one nearest interval; playing/scrub: phase A/B + meld).
        val target = layerLists.computeGlobalAnimationTarget()
        if (target.phaseA.length > 4) collected.add(target.phaseA)
        if (target.phaseB.length > 4 && target.phaseB != target.phaseA) collected.add(target.phaseB)

        if (collected.isEmpty()) {
            if (layerLists.phaseAString.length > 4) collected.add(layerLists.phaseAString)
            if (layerLists.phaseBString.length > 4) collected.add(layerLists.phaseBString)
        }

        if (collected.isEmpty()) {
            return filterABTimesByValidTimes(sourceId)
        }

        for (time in collected) {
            val idx = layerLists.timeStrings.indexOf(time)
            if (idx >= 0) {
                addRequestInOrder(layerLists.timeLongs[idx], time)
            }
        }
        return collected.toTypedArray()
    }

    /** Phase-A/B time strings used while the timeline is paused (scrub). */
    internal fun scrubPhaseTimesArray(): Array<String> =
        timesForPausedOrScrubDownload(layer.source.id)

    /** Legacy global-phase mapping; only used as last resort in [timesForPausedOrScrubDownload]. */
    private fun filterABTimesByValidTimes(sourceId: String): Array<String> {

        val layerLists = Timeline.sourceTimeHash[sourceId] ?: return emptyArray()
        val result = mutableListOf<String>()

        fun addRequestInOrder(timeLong: Long, timeString: String) {
            // See the identical guard in [timesForPausedOrScrubDownload] — this last-resort path
            // shares the same issue when invoked during active play via the scrub-rebind route.
            if (Timeline.isGloballyPlaying) return
            val insertionIndex = layerLists.reqLongs.binarySearch(timeLong)
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                layerLists.reqLongs.add(correctIndex, timeLong)
                layerLists.reqStrings.add(correctIndex, timeString)
                layerLists.reqGenerations.add(correctIndex, Timeline.reqGeneration)
            }
        }

        if (Timeline.prefersSingleIntervalIdleTarget()) {
            val target = layerLists.computeGlobalAnimationTarget()
            if (target.phaseA.length > 4) {
                val idx = layerLists.timeStrings.indexOf(target.phaseA)
                if (idx >= 0) {
                    addRequestInOrder(layerLists.timeLongs[idx], target.phaseA)
                }
                return arrayOf(target.phaseA)
            }
        }

        val timeLongA = Timeline.timeLongs[Timeline.currentPhaseA]

        closestLayerValidTime(layerLists, timeLongA)?.let { (validLongA, validStringA) ->
            result.add(validStringA)
            addRequestInOrder(validLongA, validStringA)
        }

        val timeLongB = Timeline.timeLongs[Timeline.currentPhaseB]

        if (timeLongA != timeLongB) {
            closestLayerValidTime(layerLists, timeLongB)?.let { (validLongB, validStringB) ->
                result.add(validStringB)
                addRequestInOrder(validLongB, validStringB)
            }
        }

        return result.toTypedArray()
    }

    /** Make sure you don't request times not included in valid times  **/
    private fun filterTimelineByValidTimes(): Array<String> =
        matchTimesToLayerValidTimes(Timeline.timeStrings, Timeline.timeLongs, isPass2 = false).toTypedArray()

    /**
     * Core of [filterTimelineByValidTimes], parameterized so callers can resolve an arbitrary set
     * of global-grid ticks (not just the currently-active [Timeline.timeStrings]) against this
     * layer's own native valid-time list — e.g. progressive playback's pass 2
     * ([prefetchAdditionalIntervalsQuietly]) resolves the *full* grid's skipped ticks this way
     * while [Timeline.timeStrings] is still the coarse grid, so the downloaded/cached tiles end up
     * keyed under the exact same layer-native time string the normal pathway will look up later —
     * using the raw global tick string instead caused a cache-key mismatch that silently forced a
     * second, real re-download/re-verify wave right after the loop-boundary swap.
     */
    internal fun matchTimesToLayerValidTimes(
        timeStrings: List<String>,
        timeLongs: List<Long>,
        isPass2: Boolean,
    ): List<String> {
        val layerLists = Timeline.sourceTimeHash[layer.source.id] ?: return emptyList()

        // Ensure the list is sorted before we begin, as binarySearch requires it.
        // This is a safeguard in case the list was modified incorrectly elsewhere.
        if (layerLists.timeLongs.isSorted().not()) {
            layerLists.timeLongs.sort()
        }

        val returnList: MutableList<String> = mutableListOf()

        // A helper extension function to add items while maintaining sort order.
        fun MutableList<Long>.addInOrder(element: Long, associatedString: String) {
            val insertionIndex = this.binarySearch(element)
            // If the item is not already present, add it.
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                this.add(correctIndex, element)
                layerLists.reqStrings.add(correctIndex, associatedString)
                layerLists.reqGenerations.add(correctIndex, Timeline.reqGeneration)
                layerLists.reqIsPass2.add(correctIndex, isPass2)
            }
        }

        for ((index, timeString) in timeStrings.withIndex()) {
            val timelineLong = timeLongs[index]

            // Search for the timeline time in the layer's valid times.
            val searchResult = layerLists.timeLongs.binarySearch(timelineLong)

            if (searchResult >= 0) {
                // --- Exact match found ---
                // Always use the layer's canonical time string for cache keys and HTTP requests.
                // Using global Timeline.timeStrings here caused scrub (filterABTimesByValidTimes,
                // which uses layer strings) to miss tiles that were downloaded during playback.
                if (layerLists.downloadAllowsLayerIndex(searchResult)) {
                    val layerTimeString = layerLists.timeStrings[searchResult]
                    returnList.add(layerTimeString)
                    layerLists.reqLongs.addInOrder(timelineLong, layerTimeString)
                }
            } else {
                // --- No exact match, find the next largest (closest) time ---
                val insertionPoint = -(searchResult + 1)

                if (insertionPoint < layerLists.timeLongs.size) {
                    if (layerLists.downloadAllowsLayerIndex(insertionPoint)) {
                        val nextClosestLong = layerLists.timeLongs[insertionPoint]
                        val nextClosestString = layerLists.timeStrings[insertionPoint]

                        returnList.add(nextClosestString)
                        layerLists.reqLongs.addInOrder(nextClosestLong, nextClosestString)
                    }
                } else {
                    if (layerLists.timeLongs.isNotEmpty()) {
                        val lastIdx = layerLists.timeLongs.lastIndex
                        if (layerLists.downloadAllowsLayerIndex(lastIdx)) {
                            val lastValidLong = layerLists.timeLongs[lastIdx]
                            val lastValidString = layerLists.timeStrings[lastIdx]
                            returnList.add(lastValidString)
                            layerLists.reqLongs.addInOrder(lastValidLong, lastValidString)
                        }
                    }
                }
            }
        }

        return returnList
    }

    // You might need to add this helper extension function to your project if it doesn't exist.
// It can be placed at the top level of any utility file.
    /**
     * True if this list is already in non-decreasing order. Used defensively to verify a layer's
     * valid-time list before [binarySearch], which silently returns wrong results on unsorted input.
     */
    fun <T : Comparable<T>> List<T>.isSorted(): Boolean {
        for (i in 0 until this.size - 1) {
            if (this[i] > this[i + 1]) {
                return false
            }
        }
        return true
    }

    /**
     * Read-only estimate of how many new encoded (coord×time) pairs would be queued for [coords],
     * using the same metadata, time filtering, and cache checks as [requestTilesForDownload]
     * but without mutating caches, Timeline pending lists, or requesting bytes.
     * Used to fix download % across multiple layers before any layer runs.
     */
    suspend fun preflightEncodedNewPairCount(
        coords: List<TileCoord>,
        options: TileRequestOptions,
    ): Int {
        if (!tileSource.isEncoded) return 0

        timeline = layer.mapController!!.timeline
        if (tileSource.metaDataNeeded > 0) {
            val startDate = if (this::timeline.isInitialized) timeline.start else null
            val endDate = if (this::timeline.isInitialized) timeline.end else null
            val metadataResult = tileSource.fetchMetadata(startDate, endDate)
            if (metadataResult.isFailure) return 0
        }

        ensureFormattedDate(options)

        val timesArrayLocal = resolveDownloadTimes()

        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val sourceId = layer.source.id
        var count = 0
        timesArrayLocal?.forEach { time ->
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            coords.forEach { coord ->
                if (!encodedPairSatisfied(sourceId, coord, time, timeLong, layerLists)) {
                    count++
                }
            }
        }
        return count
    }

    /**
     * Clears pending-download bookkeeping for [intervalChunk] when encoded work is cancelled
     * or fails before [TileCache.bindTextures] runs (which normally removes these entries).
     * Safe to call after successful bind: second remove is a no-op for completed counts.
     */
    private fun releasePendingEncodedTimelineKeysForChunk(
        sourceId: String,
        tileCoord: TileCoord,
        intervalChunk: List<String>,
    ) {
        releasePendingEncodedTimelineKeys(sourceId, tileCoord.hashShort(), intervalChunk)
    }

    /** Same as [releasePendingEncodedTimelineKeysForChunk] when only the short hash is available. */
    private fun releasePendingEncodedTimelineKeys(
        sourceId: String,
        coordShortHash: String,
        intervals: List<String>,
    ) {
        // Pending keys are always stamped with wrap 0 (see [requestTilesForDownload]).
        val unwrapped = "0:" + coordShortHash.substringAfter(':')
        for (interval in intervals) {
            TileList.pendingList.remove(sourceId, coordShortHash, interval)
            TileList.pendingList.remove(sourceId, unwrapped, interval)
            val hash = "$unwrapped/$interval"
            Timeline.removePendingEncodedDownload(sourceId, hash)
            // Cancelled playback waves must not leave these marks — otherwise
            // [encodedPairSatisfied] / early-outs permanently skip the pair.
            tileCache._requestedTiles.remove(hash)
            tileCache._pending.remove(hash)
            tileCache._pendingTime.remove(hash)
        }
    }

    /**
     * Fetches z=0 for the idle timeline interval(s) when missing, without progress UI.
     * Used during pan/zoom while the timeline is paused.
     */
    /**
     * @return true when the world tile is now handled for the current intervals (download launched,
     * or every interval already resident and queued for bind); false when a precondition was not
     * ready yet, so a caller priming on layer-add can retry instead of burning its one-shot.
     */
    internal suspend fun scheduleQuietIdleWorldTileDownload(
        options: TileRequestOptions,
        externalScope: CoroutineScope,
    ): Boolean {
        if (!layer.visible || !tileSource.isEncoded) return false
        timeline = layer.mapController?.timeline ?: return false
        if (timeline.state == AnimationState.playing) return false
        if (floor(tileSource.minZoom).toInt() > 0) return false

        ensureFormattedDate(options)
        val date = formattedDate ?: return false
        val times = timesForPausedOrScrubDownload(layer.source.id)
        if (times.isEmpty()) return false

        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val sourceId = layer.source.id
        val missingIntervals = times.filter { time ->
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            !encodedPairSatisfied(sourceId, worldCoord, time, timeLong, layerLists)
        }.distinct()
        // Rule: world-tile-bind-after-quiet-fetch. The quiet fetch lands the pixels in the tile /
        // native cache but never queues a GPU upload, so from the second pass onward
        // [encodedPairSatisfied] reports every interval satisfied while [TileCache.hashMap] never
        // gains a `0:0/0/0/<phase>` entry. That is why the world tile was never usable as a partial:
        // [com.xweather.mapsgl.gl.RenderPass.determinePartial]'s ancestor walk is uncapped and
        // reaches z=0 fine, but it looks tiles up in the *texture* map, and z=0 was never bound
        // (measured: `boundZooms` never contained 0, across every run). Queue the bind explicitly,
        // mirroring the reinsert+bindList pattern [requestTilesForDownload] already uses for its own
        // cached-but-not-GPU-ready case.
        for (time in times) {
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            val match = encodedPairSatisfiedMatch(sourceId, worldCoord, time, timeLong, layerLists) ?: continue
            val (matchedTimeKey, hash) = match
            if (tileCache.hashMap.containsKey(hash)) continue
            val lookupCoord = TileCoord(worldCoord.x, worldCoord.y, worldCoord.z, time = matchedTimeKey)
            if (tileCache.reinsertShellForNativeBindIfNeeded(lookupCoord, hash)) {
                tileCache.withBindListLock {
                    if (!tileCache.bindList.contains(hash)) tileCache.bindList.add(hash)
                }
            }
        }

        // Everything already resident (and queued for bind just above) — nothing left to fetch.
        if (missingIntervals.isEmpty()) return true

        val alreadyRunning = quietWorldTileJobLock.withLock {
            quietWorldTileJob?.isActive == true
        }
        if (alreadyRunning) return true

        for (interval in missingIntervals) {
            worldCoord.time = interval
            val hash = worldCoord.hash()
            tileCache._requestedTiles[hash] = System.currentTimeMillis()
        }

        quietWorldTileJob = externalScope.launch(Dispatchers.Default) {
            try {
                missingIntervals.chunked(24 / tileSource.datasets.size.coerceAtLeast(1)).forEach { intervalChunk ->
                    try {
                        tileSource.requestTiles(
                            worldCoord,
                            options,
                            date,
                            fromAnimation = false,
                            intervals = intervalChunk,
                            trackDownloadProgress = false,
                        )
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        Log.e(TAG, "Quiet world tile download failed for ${layer.id}", e)
                        for (interval in intervalChunk) {
                            worldCoord.time = interval
                            tileCache._requestedTiles.remove(worldCoord.hash())
                        }
                    }
                    val mapController = layer.mapController
                    if (mapController is MapboxMapController) {
                        mapController.mapboxMap?.executeOnRenderThread {
                            mapController.layerHosts[layer.id]?.bindTextures(layer.source.id)
                        }
                    }
                }
            } finally {
                quietWorldTileJobLock.withLock {
                    quietWorldTileJob = null
                }
            }
        }
        return true
    }

    /**
     * Progressive playback pass 2: fetches [globalTimeStrings] (the full-resolution intervals
     * skipped by the coarse first pass, see [Timeline.isCoarsePlayback]) for the currently visible
     * [coords]. Unlike [scheduleQuietIdleWorldTileDownload], this *does* track download progress —
     * the standing rule is that the visible load percent must keep climbing 50-100% through this
     * pass, not disappear — so these requests populate [TileList.pendingList]/[Timeline.currentDLCount]
     * normally (re-armed by the caller first) and awaits completion so the caller knows exactly
     * when the full grid is actually resident and ready to swap in at the next loop boundary.
     */
    internal suspend fun prefetchAdditionalIntervalsQuietly(
        coords: List<TileCoord>,
        options: TileRequestOptions,
        globalTimeStrings: List<String>,
        globalTimeLongs: List<Long>,
    ) {
        if (coords.isEmpty() || globalTimeStrings.isEmpty() || !tileSource.isEncoded) return
        // Resolve each *global* tick to this layer's own nearest native valid time — same matching
        // filterTimelineByValidTimes does for the active grid — and populate reqStrings/reqLongs as
        // a side effect (see [matchTimesToLayerValidTimes]'s doc comment for why: using the raw
        // global tick string as the download/cache key here caused a mismatch against what the
        // normal pathway looks up post-swap, forcing a redundant real re-download/re-verify wave).
        val intervals = matchTimesToLayerValidTimes(globalTimeStrings, globalTimeLongs, isPass2 = true)
        if (intervals.isEmpty()) return
        ensureFormattedDate(options)
        val date = formattedDate ?: return
        val chunkSize = 24 / tileSource.datasets.size.coerceAtLeast(1)
        // Unlike the initial catch-up load, this runs *while the coarse grid is actively playing*
        // — a wide Dispatchers.Default semaphore here competes with the render/decode work the
        // playing animation needs every frame and visibly stutters/stalls it. Same fix shape as
        // the phase-build burst-OOM fix (Semaphore(3)): keep this deliberately small, and use IO
        // (a separate, elastic pool) since the work here is network-bound, not CPU-bound.
        val semaphore = Semaphore(3)
        supervisorScope {
            val jobs = mutableListOf<Job>()
            for (coord in coords) {
                for (intervalChunk in intervals.chunked(chunkSize)) {
                    jobs.add(
                        launch(Dispatchers.IO) {
                            try {
                                semaphore.withPermit {
                                    tileSource.requestTiles(
                                        coord,
                                        options,
                                        date,
                                        fromAnimation = true,
                                        intervals = intervalChunk,
                                        trackDownloadProgress = true,
                                    )
                                }
                            } catch (e: CancellationException) {
                                throw e
                            } catch (e: Exception) {
                                Log.e(TAG, "Progressive full-grid prefetch failed for ${coord.hashShort()}", e)
                            }
                        },
                    )
                }
            }
            jobs.joinAll()
        }
        val mapController = layer.mapController
        if (mapController is MapboxMapController) {
            mapController.mapboxMap?.executeOnRenderThread {
                mapController.layerHosts[layer.id]?.bindTextures(layer.source.id)
            }
        }
    }

    /** Determine which tiles are already downloaded, and request the ones that aren't */
    suspend fun requestTilesForDownload(
        coords: List<TileCoord>,
        options: TileRequestOptions,
        externalScope: CoroutineScope,
    ): Result<Unit> { // Keep Result<Unit> signature

        timeline = layer.mapController!!.timeline
        if (tileSource.metaDataNeeded > 0 && tileSource.isEncoded) {
            val startDate = if (this::timeline.isInitialized) timeline.start else null
            val endDate = if (this::timeline.isInitialized) timeline.end else null

            if (pr.ON) pr.p(
                TAG,
                pr.tileReq,
                "requestTilesForDownload() calling and awaiting fetchMetadata() with $startDate / $endDate"
            )

            // Make fetchMetadata a suspend function and await its completion
            val metadataResult = tileSource.fetchMetadata(startDate, endDate)

            // If fetching fails, stop and propagate the failure.
            if (metadataResult.isFailure) {
                return Result.failure(
                    metadataResult.exceptionOrNull()
                        ?: IllegalStateException("Metadata fetch failed without an exception.")
                )
            }
            // If successful, the function will now continue instead of returning early.
            if (pr.ON) pr.p(
                TAG,
                pr.fetchMeta,
                "requestTilesForDownload() proceeding, hopefully AFTER metadata fetch  with $startDate / $endDate\""
            )

        } else {
            //if (pr.ON) pr.p(TAG, pr.tileReq, "requestTilesForDownload() SKIPPING METADATA FETCH", 2 )
        }

        ensureFormattedDate(options)

        timesArray = resolveDownloadTimes()

        if (pr.ON && pr.tileDownloadAudit.active) {
            timesArray?.let { arr ->
                val seen = HashMap<String, Int>()
                for (t in arr) {
                    seen[t] = (seen[t] ?: 0) + 1
                }
                val dups = seen.filter { it.value > 1 }
                if (dups.isNotEmpty()) {
                    pr.p(
                        TAG,
                        pr.tileDownloadAudit,
                        "timesArray contains duplicate time strings (same pass): $dups source=${layer.source.id} layer=${layer.id}"
                    )
                }
            }
            val zMin = floor(tileSource.minZoom).toInt()
            val zMax = floor(tileSource.maxZoom).toInt()
            for (coord in coords) {
                val n = powerTableI[coord.z]
                val badZoom = coord.z < zMin || coord.z > zMax
                val badXY = n <= 0 || coord.x < 0 || coord.y < 0 || coord.x >= n || coord.y >= n
                if (badZoom || badXY) {
                    pr.p(
                        TAG,
                        pr.tileDownloadAudit,
                        "download queue invalid tile (z not in [$zMin,$zMax] or x/y out of range): z=${coord.z} x=${coord.x} y=${coord.y} n=$n source=${layer.source.id} layer=${layer.id}"
                    )
                }
            }
        }

        val coordIntervalMap: HashMap<String, MutableList<String>> =
            HashMap() // Map: CoordHash -> List<TimeIntervalString>

        var newDownloadPairs = 0
        var skippedAlreadyTracked = 0
        var queuedResidentBinds = 0
        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        val sourceId = layer.source.id

        timesArray?.forEach { time ->
            val timeLong = layerLists?.timeLongs?.getOrNull(layerLists.timeStrings.indexOf(time))
            coords.forEach { coord ->
                val satisfiedMatch = encodedPairSatisfiedMatch(sourceId, coord, time, timeLong, layerLists)
                if (satisfiedMatch != null) {
                    skippedAlreadyTracked++
                    // Cached/native is not the same as GPU-ready. Re-bind so [buildReadyPlaybackList]
                    // can grow past a single hold interval after the load UI clears.
                    // Must reinsert/rebind under the timeKey that actually matched — the pixels may be
                    // cached under an alternate time-string format than [time] itself (see
                    // [encodedPairSatisfiedMatch]); recomputing the hash from [time] alone would look
                    // up a different, never-bound cache entry and silently skip the rebind forever.
                    val (matchedTimeKey, hash) = satisfiedMatch
                    val lookupCoord = TileCoord(coord.x, coord.y, coord.z, time = matchedTimeKey)
                    if (!tileCache.hashMap.containsKey(hash) &&
                        tileCache.reinsertShellForNativeBindIfNeeded(lookupCoord, hash)
                    ) {
                        tileCache.withBindListLock {
                            if (!tileCache.bindList.contains(hash)) {
                                tileCache.bindList.add(hash)
                                queuedResidentBinds++
                            }
                        }
                    }
                    return@forEach
                }
                val tempCoord = TileCoord(coord.x, coord.y, coord.z, 0, time)
                val hash = tempCoord.hash()
                Timeline.addPendingEncodedDownload(layer.source.id, hash)
                coordIntervalMap.getOrPut(coord.hashShort()) { mutableListOf() }.add(time)
                newDownloadPairs++
                tileCache._requestedTiles[hash] = System.currentTimeMillis() // Mark as requested
                if (pr.ON) pr.p(
                    TAG,
                    pr.infiniteLoad,
                    " requestTilesForDownload() pending size: ${layer.source.id} ${hash}"
                )
            }
        }

        if (pr.ON && pr.tileDownloadAudit.active) {
            coordIntervalMap.forEach { (shortHash, list) ->
                val dupTimes = list.groupingBy { it }.eachCount().filter { it.value > 1 }
                if (dupTimes.isNotEmpty()) {
                    pr.p(
                        TAG,
                        pr.tileDownloadAudit,
                        "DUPLICATE time in interval list for one tile (should not happen): hashShort=$shortHash counts=$dupTimes layer=${layer.id}"
                    )
                }
            }
            pr.p(
                TAG,
                pr.tileDownloadAudit,
                "requestTilesForDownload summary: layer=${layer.id} source=${layer.source.id} coords=${coords.size} timeSlots=${timesArray?.size ?: 0} newPairs=$newDownloadPairs skippedAlreadyPresent=$skippedAlreadyTracked coordGroups=${coordIntervalMap.size}"
            )
        }

        // Request WorldCoord when not playing.
        // This was causing zoom level 0 tiles to be requested every time the timeline is paused.
        // Commented out to avoid redundant zoom-0 requests during pause/play transitions.
        //
        // if (timeline.state != AnimationState.playing && tileSource.minZoom.toInt() == 0) {
        //     timesArray?.forEach { time ->
        //         worldCoord.time = time
        //         val hash = worldCoord.hash()
        //         if (!tileCache.tiles.containsKey(hash) && !tileCache._pending.containsKey(hash) && !tileCache._requestedTiles.containsKey(
        //                 hash
        //             )
        //         ) {
        //             coordIntervalMap.getOrPut(worldCoord.hashShort()) { mutableListOf() }.add(time)
        //             tileCache._requestedTiles[hash] = System.currentTimeMillis() // Mark as requested
        //         }
        //     }
        // }

        return try { // Wrap in try-catch for potential issues during launch/join
            // supervisorScope: one cancelled/failed tile must not abort siblings in the same wave.
            // coroutineScope previously cancelled the whole humidity download on any child cancel.
            supervisorScope {
                val downloadJobs = mutableListOf<Job>() // Keep track of launched jobs
                // Prevent too many concurrent download/processing jobs from contending for CPU,
                // cache state, and render-thread binds (can otherwise cause frame hitches).
                val maxConcurrentRequests = 30
                val semaphore = Semaphore(maxConcurrentRequests)

                if (tileSource.isEncoded) {//Encoded
                    coordIntervalMap.forEach { (coordShortHash, intervals) ->
                        val tileCoord = TileCoord.fromHashShort(coordShortHash)
                        if (tileCoord == null) {
                            // No coord to request with, so nothing will ever clear the keys added above.
                            releasePendingEncodedTimelineKeys(tileSource.id, coordShortHash, intervals)
                            return@forEach
                        }
                        intervals.chunked(24 / tileSource.datasets.size).forEach { intervalChunk ->
                            val job = launch {
                                try {
                                    semaphore.withPermit {
                                        tileSource.requestTiles(
                                            tileCoord,
                                            options,
                                            formattedDate!!,
                                            true,
                                            intervalChunk
                                        )
                                    }
                                } catch (e: CancellationException) {
                                    // Sibling-safe: do not rethrow into supervisorScope children.
                                    // Parent-scope cancellation still cancels this job via structured concurrency.
                                    Log.w(TAG, "Tile request cancelled for ${tileCoord.hashShort()}")
                                } catch (e: Exception) {
                                    Log.e(TAG, "Error in tile request job for ${tileCoord.hashShort()}", e)
                                }

                                if (layer.mapController != null) {
                                    val mapController = layer.mapController
                                    if (mapController is MapboxMapController) {
                                        mapController.mapboxMap?.executeOnRenderThread {
                                            mapController.layerHosts[layer.id]?.bindTextures(layer.source.id)
                                        }
                                    } else {
                                        //todo: Logic for other map types as needed
                                    }
                                }
                            }
                            // Only release on cancel/failure. Releasing on success raced a second
                            // wave's in-flight HTTP (cleared pending mid-download) and also dropped
                            // keys that [requestTiles] early-returned as alreadyExists while another
                            // job still owned them — leaving the load watchdog stuck until timeout.
                            job.invokeOnCompletion { cause ->
                                if (cause != null) {
                                    releasePendingEncodedTimelineKeysForChunk(
                                        tileSource.id,
                                        tileCoord,
                                        intervalChunk,
                                    )
                                }
                            }
                            downloadJobs.add(job)
                        }
                    }
                } else { // Raster
                    coordIntervalMap.forEach { (coordShortHash, intervals) ->
                        val tileCoord = TileCoord.fromHashShort(coordShortHash)
                        if (tileCoord != null) {
                            if (pr.ON) pr.p(
                                TAG,
                                pr.rasterFix,
                                "requestTilesForDownload() coordShortHash: $coordShortHash ----------------"
                            )
                            for (interval in intervals) {
                                if (pr.ON) pr.p(TAG, pr.rasterFix, "requestTilesForDownload() interval: ${interval}")

                                downloadJobs.add(launch {
                                    try {
                                        semaphore.withPermit {
                                            tileSource.requestTiles(tileCoord, options, interval, true)
                                        }
                                    } catch (e: CancellationException) {
                                        if (pr.ON) pr.p(TAG, pr.rasterFix, "requestTilesForDownload() CANCELLED", 2)
                                    } catch (e: Exception) {
                                        if (pr.ON) pr.p(TAG, pr.rasterFix, "requestTilesForDownload() ERROR: ${e}", 2)
                                    }
                                    // Ask the layer host to upload what just landed, exactly as the
                                    // encoded branch above does. [ImageTileSource.onTileLoaded] only
                                    // queues the tile into [TileCache.bindList]; something still has
                                    // to call [MapboxLayerHost.bindTextures] for it to reach the GPU.
                                    // Nothing did for raster: [MapboxLayerHost.needToBindTextures]
                                    // starts false and is only set by paths that bail early on
                                    // non-encoded sources ([requeueLoadedVisibleTilesForBind]), and
                                    // the post-loop [kickGpuBindIfNeeded] runs before these
                                    // fire-and-forget jobs have downloaded anything, so it always saw
                                    // an empty bindList. Result: raster layers (satellite geocolor,
                                    // infrared, …) downloaded every tile successfully and then never
                                    // rendered, with no error anywhere.
                                    kickGpuBindIfNeeded(false)
                                })
                            }
                        }
                    }
                } // end Raster

                if (!Timeline.threadDownload) { //original method that slows down while downloading
                    downloadJobs.joinAll()
                } else {
                    if (downloadJobs.isNotEmpty()) {
                        val batchSize = downloadJobs.size // Capture size for the log message
                        if (pr.ON) pr.p(
                            TAG,
                            pr.tileRequest,
                            "Launching completion logger coroutine for $batchSize jobs."
                        )
                        externalScope.launch(Dispatchers.Default) { // Use Default or IO for waiting
                            try {
                                if (pr.ON) pr.p(
                                    TAG,
                                    pr.tileRequest,
                                    "[CompletionLogger] Waiting for $batchSize jobs..."
                                )
                                downloadJobs.joinAll() // This coroutine suspends here
                            } catch (e: CancellationException) {
                                Log.w(TAG, "[CompletionLogger] Waiting coroutine cancelled.")
                            } catch (e: Exception) {
                                Log.e(TAG, "[CompletionLogger] Error waiting for job batch completion", e)
                            }
                        }
                        layer.mapController!!.checkDownloadStatus(
                            layer.id,
                            tileCache.pendingCount
                        ) // Check remaining pending

                    }
                }
            } // End supervisorScope

            // Resident intervals re-queued above never go through a download job's bindTextures()
            // call — without this kick they sit in bindList forever and the layer stays on 1–2 frames.
            kickGpuBindIfNeeded(queuedResidentBinds > 0)

            Result.success(Unit) // Indicate the overall process initiated successfully
        } catch (e: CancellationException) {
            // Parent cancelled the whole refresh — report failure so callers can skip abort storms,
            // but do not treat sibling tile failures as a wave failure (those stay in supervisorScope).
            println("$TAG Concurrent download process cancelled, $e")
            Result.failure(e)
        } catch (e: Exception) {
            println("$TAG Error during concurrent download process, $e")
            Result.failure(e) // Return failure if the scope or launching had issues
        }
    }

    /**
     * Tracks [TileCache.memUsage] (updating [memUsageLast]) and logs it whenever it changes.
     * The actual cache-trimming logic below is currently commented out, so this is presently a
     * no-op beyond logging/bookkeeping.
     */
    fun checkAndClearMemory(coords: List<TileCoord>) {
        if (true || tileCache.memUsage != memUsageLast) {
            if (pr.ON) pr.p(TAG, pr.clearMem, "from requestTileForDownload(), mem is ${tileSource.tileCache.memUsage}")
            memUsageLast = tileCache.memUsage

            if (coords.isNotEmpty()) {
                if (pr.ON) pr.p(TAG, pr.clearMem, "requestTileForDownload(), zoom from Coords: ${coords.first().z}")
                if (tileSource.tileCache.memUsage > .05f) {
                    //if(pr.ON) pr.p (TAG, pr.clearMem, "requestTileForDownload(),memUsage over 80%",2)
                    //tileCache.clearOtherZooms(coords.first().z)
                    //tileCache.clearOutsideBounds(this.layer.persistentTileBounds)
                    //tileCache.removeAll()

                    //tileSource.tileManager.pending.remove()
                    //_pending.remove(coord.hash())
                }
            }
        }
    }

    private fun removeOutOfBounds(
        bounds: MapBounds<LatitudeLongitude> /*LatLonBounds*/,
        coords: /*Mutable*/List<TileCoord>
    ) {
        coords.filter { coord ->
            coord.mapBounds?.let { coordBounds ->
                if (coordBounds.eastExtent < bounds.westExtent || coordBounds.westExtent > bounds.eastExtent) {
                    return@filter false
                } else return@filter !(coordBounds.southExtent > bounds.northExtent || coordBounds.northExtent < bounds.southExtent)
            } ?: true
        }
    }

    private fun sortAroundCenter(center: GLCoordinate2D, coords: MutableList<TileCoord>): MutableList<TileCoord> {
        if (coords.isNotEmpty()) {
            //Todo: further optimizations possible
            val numTiles = (powerTableD[coords.first().z])
            var dax: Double
            var day: Double
            var da: Double
            coords.sortBy { coord ->
                val aCenter = coord.getCenter()
                dax = (center.x * (numTiles)) - (aCenter.x + .5f)
                day = (center.y * (numTiles)) - (aCenter.y + .5f)
                da = (dax * dax) + (day * day)
                da
            }
        }
        return coords
    }

    private fun ensureFormattedDate(options: TileRequestOptions) {
        if (formattedDate != null) return
        val calendar = Calendar.getInstance()
        calendar.time = Date()
        calendar.add(Calendar.HOUR_OF_DAY, -12)
        formattedDate = bracketedRasterInterval(options.formatDate(calendar.time))
        fallbackOptions = options
    }

    /**
     * Image/raster tiles use bracketed validTimes strings (e.g. `["2025-05-19T12:00:00Z"]`) for URL
     * encoding and texture hash keys. [TileRequestOptions.formatDate] returns plain ISO without brackets.
     */
    private fun bracketedRasterInterval(isoUtc: String): String {
        val trimmed = isoUtc.trim()
        if (trimmed.startsWith("[\"")) return trimmed
        val inner = trimmed.removePrefix("[").removeSuffix("]").trim('"')
        return "[\"$inner\"]"
    }

    /**
     * When no timeline/valid-times exist for a raster source (e.g. satellite geocolor on a map without
     * a scrubber), still request and draw a single recent frame.
     */
    private fun ensureStaticRasterLayerTimeline(sourceId: String, interval: String) {
        val lt = Timeline.sourceTimeHash.getOrPut(sourceId) { LayerTimeline(sourceId) }
        if (lt.timeStrings.isNotEmpty()) return
        lt.timeStrings = mutableListOf(interval)
        lt.timeLongs = mutableListOf(System.currentTimeMillis() / 1000L)
        lt.phaseAString = interval
        lt.phaseBString = interval
        lt.onValidTimesUpdated()
    }

    /**
     * Time strings to request while the timeline is playing.
     *
     * Downloads a **contiguous** window ending at playhead+lookahead (and extending back toward the
     * last displayed/hold interval when possible). A tiny playhead-only window left gaps whenever
     * the clock advanced faster than HTTP — [RenderPass] then jumped between sparse ready frames
     * (sporadic animation). Must still NOT return the entire animation range (multi-GB).
     */
    internal fun timesForPlaybackDownload(sourceId: String, lookahead: Int = -1): Array<String> {
        val layerLists = Timeline.sourceTimeHash[sourceId] ?: return emptyArray()
        val collected = LinkedHashSet<String>()

        fun addRequestInOrder(timeLong: Long, timeString: String) {
            val insertionIndex = layerLists.reqLongs.binarySearch(timeLong)
            if (insertionIndex < 0) {
                val correctIndex = -(insertionIndex + 1)
                layerLists.reqLongs.add(correctIndex, timeLong)
                layerLists.reqStrings.add(correctIndex, timeString)
            }
        }

        val effectiveLookahead = if (lookahead >= 0) {
            lookahead
        } else {
            // ~2.5s of runway at the current phase rate; cap for memory.
            val durationSec = if (this::timeline.isInitialized) {
                timeline.duration.coerceAtLeast(0.25)
            } else {
                4.0
            }
            val total = Timeline.totalPhase.coerceAtLeast(1)
            ((total / durationSec) * 2.5).toInt().coerceIn(6, 18)
        }
        // Hard cap on how many intervals one pass may enqueue (visible tiles × this ≈ memory).
        val maxSpan = (effectiveLookahead + 6).coerceAtMost(24)

        val target = layerLists.computeGlobalAnimationTarget()
        if (target.phaseA.length > 4) collected.add(target.phaseA)
        if (target.phaseB.length > 4) collected.add(target.phaseB)

        val strings = layerLists.playbackTimeStrings()
        val longs = layerLists.playbackTimeLongs()
        val center = when {
            target.phaseA.length > 4 -> strings.indexOf(target.phaseA)
            target.phaseB.length > 4 -> strings.indexOf(target.phaseB)
            else -> -1
        }
        val holdIdx = listOf(
            layerLists.viewportHoldPhase,
            layerLists.phaseAString,
            layerLists.phaseBString,
        ).map { strings.indexOf(it) }.filter { it >= 0 }.minOrNull()

        if (strings.isNotEmpty()) {
            val hi = if (center >= 0) {
                (center + effectiveLookahead).coerceAtMost(strings.lastIndex)
            } else {
                strings.lastIndex
            }
            var lo = when {
                center >= 0 -> (center - 1).coerceAtLeast(0)
                holdIdx != null -> holdIdx
                else -> 0
            }
            if (holdIdx != null) {
                lo = minOf(lo, holdIdx)
            }
            // Prefer the window that ends at the playhead runway so we catch up to the clock
            // without enqueueing the entire multi-day gap behind the hold.
            if (hi - lo + 1 > maxSpan) {
                lo = (hi - maxSpan + 1).coerceAtLeast(0)
            }
            for (i in lo..hi) {
                collected.add(strings[i])
            }
        }

        if (collected.isEmpty()) {
            return timesForPausedOrScrubDownload(sourceId)
        }

        for (time in collected) {
            val idx = layerLists.timeStrings.indexOf(time)
            if (idx >= 0) {
                addRequestInOrder(layerLists.timeLongs[idx], time)
            } else {
                val pIdx = strings.indexOf(time)
                if (pIdx >= 0 && pIdx < longs.size) {
                    addRequestInOrder(longs[pIdx], time)
                }
            }
        }
        return collected.toTypedArray()
    }

    private fun resolveDownloadTimes(): Array<String> {
        // Explicit full-range preload, or active playback: the product loops the entire timeline
        // (often 30+ intervals) in ~2 seconds repeatedly, so every valid interval for the viewport
        // must be requested and kept resident — a playhead-only window causes sparse/sporadic
        // animation and re-download churn (stuck ~99% load UI).
        val wantsFullRange =
            timeline.opts.shouldPreloadData ||
                timeline.opts.forcePreloadOneTime ||
                Timeline.fullTimelinePreloadActive ||
                timeline.state == AnimationState.playing

        val base =
            when {
                wantsFullRange -> filterTimelineByValidTimes()
                else -> timesForPausedOrScrubDownload(layer.source.id)
            }
        if (base.isNotEmpty()) {
            return base
        }
        return fallbackDownloadTimesWhenNoneResolved()
    }

    /**
     * Paused demos often add the encoded layer before [LayerTimeline.phaseAString]/[phaseBString]
     * are set. Returning an empty list here left [preflightEncodedDownloadPairCount] at zero, so
     * [MapController.refreshVisibleLayers] skipped downloads until play/scrub.
     */
    private fun fallbackDownloadTimesWhenNoneResolved(): Array<String> {
        val layerLists = Timeline.sourceTimeHash[layer.source.id]
        if (layerLists != null && layerLists.timeStrings.isNotEmpty()) {
            val scrubLong = (
                timeline.start.time +
                    ((timeline.end.time - timeline.start.time) * timeline.position).toLong()
                ) / 1000L
            closestLayerValidTime(layerLists, scrubLong)?.let { (_, validString) ->
                layerLists.phaseAString = validString
                layerLists.phaseBString = validString
                // Do NOT register this in reqLongs/reqStrings: those lists are the full-range
                // playback-readiness accounting in RenderPass (every entry there must eventually
                // get its whole viewport tile set downloaded). This fallback only fires when the
                // real per-viewport resolution ([filterTimelineByValidTimes]) returned nothing —
                // a transient bootstrap/race window — and this is just a scrub-position display
                // placeholder for that moment. Registering it here left an orphan entry that no
                // subsequent real download pass ever revisits, permanently blocking
                // full-range-ready even after everything actually needed had loaded.
                return arrayOf(validString)
            }
        }
        val bracketed = bracketedRasterInterval(formattedDate!!)
        ensureStaticRasterLayerTimeline(layer.source.id, bracketed)
        return arrayOf(bracketed)
    }

    /**
     * Vestigial marker interface carried over from the iOS port's `Dictionary`-protocol conformance
     * (see the class-level "Adapted from IOS version" note). Not currently implemented by [TilePyramid]
     * or any other type in this codebase.
     */
    interface DictionaryProtocol {
        /** Whether [coord] is a member/key of the conforming collection. */
        fun contains(coord: TileCoord): Boolean
    }

    /**
     * Vestigial marker interface carried over from the iOS port's `Sequence`-protocol conformance
     * (see the class-level "Adapted from IOS version" note). Not currently implemented by [TilePyramid]
     * or any other type in this codebase.
     */
    interface Sequence {
        /** Whether [coord] occurs as an element of the conforming sequence. */
        fun contains(coord: TileCoord): Boolean
    }

    /**
     * Vestigial marker interface carried over from the iOS port's `Collection`-protocol conformance
     * (see the class-level "Adapted from IOS version" note). Not currently implemented by [TilePyramid]
     * or any other type in this codebase.
     */
    interface Collection {
        /** Whether [coord] is contained in the conforming collection. */
        fun contains(coord: TileCoord): Boolean
    }

    /** Enables `coord in pyramid` syntax; delegates to [tileSource]'s own containment check. */
    operator fun TilePyramid<DataType>.contains(coord: TileCoord): Boolean {
        return tileSource.contains(coord)
    }

    /** Enables `pyramid[coord]` syntax; delegates to [tileCache]'s indexed lookup. */
    operator fun TilePyramid<DataType>.get(coord: TileCoord): Tile<com.xweather.mapsgl.sources.DataType>? {
        return tileCache[coord]
    }
}