package com.xweather.mapsgl.tiles

import android.graphics.PointF
import com.xweather.mapsgl.sources.data.EncodedData

interface TileProtocol<DataType : TileData> {
    val coord: TileCoord
    //var state: TileState
    val data: DataType?
    //val rawData: ByteArray
}

/**  Stores TileCoord, data, hash, state, and bounds*/
class Tile<DataType : TileData>(val coord: TileCoord, var data: Any? = null) {
    var isEncoded = false
    companion object {
        private var id: Int = 0
        val uniqueId: Int
            get() {
                return id++
            }
    }

    var encodedLoaded = false
    var encodedData: EncodedData? = null

    /** Bytes received over the network on this tile's most recent fetch; -1 if never fetched this session. */
    var downloadedBytes: Int = -1
    /** Bytes currently retained as raw tile payload (e.g. native MVT cache); -1 if unknown, 0 if not retained. */
    var storedBytes: Int = -1

    //val uid: Int = uniqueId
    //var tileInt = 0
    var coordHash = coord.hash()
    var bindNum = -1

    var state: TileState
    var blendQuadrants = IntArray(8)
    var texInt = 0
    /** Triggered when neighboring tiles are loaded so that tilePadding can be added**/
    var needsBind = false
    /**
     * Raw interval of an operation layer that has not yet been folded (or whose folded pixels could
     * not be restored). [TileCache.bindTextures] must not upload these — a running max that draws
     * one interval's own value pulses.
     */
    internal var holdBindUntilFolded = false
    var time: String

    init {
        //val min = coord.let { Geo.tileToMeters(it.x, it.y, it.z) }
        //val max = coord.let { Geo.tileToMeters(it.x + 1, it.y + 1, it.z) }
        //_span = TileCoordinate(max.x - min.x, -(max.y - min.y))
        //_bounds = TileCoordinateBounds(TileCoordinate(min.x, max.y), TileCoordinate(max.x, min.y))
        state = TileState.Initial;
        time = "currentDate"
    }

    fun clone(wrap: Int = 0): Tile<TileData> {
        var c = coord
        if (wrap != 0) {
            val x = Math.pow(coord.x + wrap * 2.0, coord.z.toDouble())
            c = TileCoord(x.toInt(), coord.y, coord.z);
        }

        var clone = Tile<TileData>(c);
        clone.state = this.state;
        clone.data = this.data;
        return clone;
    }

    fun dispose() {
        data = null
    }

    override fun toString(): String {
        return "Tile: ${coord}"
    }
}

/** @suppress */
data class TileCoordinate(var x: Float, var y: Float) : PointF(x, y)
/** @suppress */
data class TileCoordinateBounds(var nw: TileCoordinate, var se: TileCoordinate)

enum class TileState {
    Initial,
    Loading,
    Processing,
    Ready,
    Expired,
    Failed,
    UpsampledOnly
}


