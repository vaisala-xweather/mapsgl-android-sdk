package com.xweather.mapsgl.gl

import android.opengl.GLES31
import android.opengl.GLES31.* // Use GLES 3.1 bindings
import android.util.Log
import com.xweather.mapsgl.gl.extensions.pr
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class ParticleSsboManager(

) {


    val startingTileBuffers = 1 //9
    var numTiles = startingTileBuffers

    // SSBO Handles (IDs)
    var staticSsboId: Int = -1
        private set
    var dynamicSsboId: Int = -1
        private set
    var renderSsboId: Int = -1
        private set

    // --- NEW: VBO Handle ---
    var renderVboId: Int = 0
    private val vboIdArray = IntArray(1) // Helper array for glGenBuffers

    private var particleCount: Int = 0
    var initialized = false

    // Buffer IDs stored in an array for glGenBuffers/glDeleteBuffers
    private val bufferIds = IntArray(3) // static, dynamic, render

    // Binding points (choose appropriate, unique values for your compute shaders)
    // IMPORTANT: These are used by COMPUTE SHADERS.
    // Vertex Shaders cannot access these SSBOs directly on many GLES 3.1 devices (Mail GPUs).
    val staticSsboBindingPoint = 0
    val dynamicSsboBindingPoint = 1
    val renderSsboBindingPoint = 2

    // Size constants for clarity
    companion object {
        private const val TAG = "ParticleSsboManager"
        const val VEC2_COMPONENTS = 2
        const val VEC4_COMPONENTS = 4
        const val FLOAT_SIZE_BYTES = 4 // Float.SIZE_BYTES is not a constant in older Kotlin/Android
    }

    init {
        /*   if (initialPositions.size != particleCount * VEC2_COMPONENTS) {
            throw IllegalArgumentException("Initial positions array size (${initialPositions.size}) does not match particleCount * 2 (${particleCount * VEC2_COMPONENTS})")
        } */

        //createAndInitializeBuffers(initialPositions)
    }

    fun createAndInitializeBuffers(particleCountInput: Int, initialPositionsData: FloatArray, /*newNumTiles: Int*/) {
        //numTiles = newNumTiles
        if(pr.ON) pr.p(TAG, pr.particleBuffer, "createAndInitializeBuffers() entered, numtiles = $numTiles",2)
        particleCount = particleCountInput
        if (initialPositionsData.size != particleCount * VEC2_COMPONENTS) {
            throw IllegalArgumentException("Initial positions array size (${initialPositionsData.size}) does not match particleCount * 2 (${particleCount * VEC2_COMPONENTS})")
        }

        // Generate buffer IDs
        glGenBuffers(bufferIds.size, bufferIds, 0)
        staticSsboId = bufferIds[0]
        dynamicSsboId = bufferIds[1]
        renderSsboId = bufferIds[2]

        if (staticSsboId <= 0 || dynamicSsboId <= 0 || renderSsboId <= 0) {
            Log.e(TAG, "Failed to generate buffer IDs.")
            checkGLError("glGenBuffers")
            cleanup() // Clean up any partially generated buffers
            return
        }
        Log.d(TAG, "Generated Buffer IDs: Static=$staticSsboId, Dynamic=$dynamicSsboId, Render=$renderSsboId")

        // --- 1. staticSsbo (Initial Positions - vec2) ---
        try {
            glBindBuffer(GL_SHADER_STORAGE_BUFFER, staticSsboId)
            checkGLError("glBindBuffer staticSsbo")

            val staticBufferSize = particleCount * VEC2_COMPONENTS * FLOAT_SIZE_BYTES
            val staticDataBuffer = allocateFloatBuffer(initialPositionsData.size)
            staticDataBuffer.put(initialPositionsData).flip()

            // Allocate and upload initial data
            // GL_STATIC_DRAW: Data set once by application, used many times by GPU (Compute Shader)
            glBufferData(GL_SHADER_STORAGE_BUFFER, staticBufferSize, staticDataBuffer, GL_STATIC_DRAW)
            checkGLError("glBufferData staticSsbo")
            Log.d(TAG, "  Static SSBO ($staticSsboId): Size=$staticBufferSize, Usage=GL_STATIC_DRAW")

            // Bind to specific binding point (for Compute Shader)
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, staticSsboBindingPoint, staticSsboId)
            checkGLError("glBindBufferBase staticSsbo")
            Log.d(TAG, "  Static SSBO ($staticSsboId) bound to CS binding point $staticSsboBindingPoint")

        } catch (e: Exception) {
            Log.e(TAG, "Error setting up staticSsbo", e)
            cleanup()
            return
        }

        // --- 2. dynamicSsbo (Current Pos/Lifetime - vec4) --- Stores dynamic data for persistance in compute shader
        try {
            glBindBuffer(GL_SHADER_STORAGE_BUFFER, dynamicSsboId)
            checkGLError("glBindBuffer dynamicSsbo")

            val dynamicBufferSize = particleCount * VEC4_COMPONENTS * FLOAT_SIZE_BYTES * numTiles

            // Allocate space. Data source is GPU (Compute Shader), Read by GPU (Compute Shader).
            // GL_DYNAMIC_COPY: Data modified and read by the GPU.
            // We are not initializing it from the CPU, the compute shader will write to it.
            glBufferData(GL_SHADER_STORAGE_BUFFER, dynamicBufferSize, null, GL_DYNAMIC_COPY)
            checkGLError("glBufferData dynamicSsbo")
            Log.d(TAG, "  Dynamic SSBO ($dynamicSsboId): Size=$dynamicBufferSize, Usage=GL_DYNAMIC_COPY")

            // Bind to specific binding point (for Compute Shader)
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, dynamicSsboBindingPoint, dynamicSsboId)
            checkGLError("glBindBufferBase dynamicSsbo")
            Log.d(TAG, "  Dynamic SSBO ($dynamicSsboId) bound to CS binding point $dynamicSsboBindingPoint")

        } catch (e: Exception) {
            Log.e(TAG, "Error setting up dynamicSsbo", e)
            cleanup()
            return
        }

        // --- 3. renderSsbo (Render Pos/Alpha - vec4) ---
        // IMPORTANT: Vertex Shaders usually CANNOT read this directly in GLES 3.1!
        // This buffer  written by a Compute Shader
        try {
            glBindBuffer(GL_SHADER_STORAGE_BUFFER, renderSsboId)
            checkGLError("glBindBuffer renderSsbo")

            val renderBufferSize = particleCount * VEC4_COMPONENTS * FLOAT_SIZE_BYTES * numTiles

            glBufferData(GL_SHADER_STORAGE_BUFFER, renderBufferSize, null, GL_DYNAMIC_COPY)
            checkGLError("glBufferData renderSsbo")
            Log.d(TAG, "  Render SSBO ($renderSsboId): Size=$renderBufferSize, Usage=GL_DYNAMIC_COPY")

            // Bind to specific binding point (for Compute Shader)
            glBindBufferBase(GL_SHADER_STORAGE_BUFFER, renderSsboBindingPoint, renderSsboId)
            checkGLError("glBindBufferBase renderSsbo")
            Log.d(TAG, "  Render SSBO ($renderSsboId) bound to CS binding point $renderSsboBindingPoint")

        } catch (e: Exception) {
            Log.e(TAG, "Error setting up renderSsbo", e)
            cleanup()
            return
        }

        // --- Unbind the target ---
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0)

        createRenderVBO()

        initialized = true
    }

    fun copyDataFromRenderSsboToVbo(numTilesToCopy: Int, drawNum: Int) {

        val renderSsbo = renderSsboId ?: return
        val renderVbo =  renderVboId  /* your VBO ID for particle vertex data */;
        //val dataSize = particleCount * VEC4_COMPONENTS * FLOAT_SIZE_BYTES * numTilesToCopy//numTiles
        val dataSize = drawNum * VEC4_COMPONENTS * FLOAT_SIZE_BYTES * numTilesToCopy//numTiles

        if (renderSsbo <= 0 || renderVbo <= 0) return

        // Bind SSBO as source, VBO as destination
        glBindBuffer(GL_COPY_READ_BUFFER, renderSsbo)
        glBindBuffer(GL_COPY_WRITE_BUFFER, renderVbo)
        //
        //    // Copy the data

        glCopyBufferSubData(
            GL_COPY_READ_BUFFER, // Read target
            GL_COPY_WRITE_BUFFER, // Write target
            0, // Read offset
            0, // Write offset
            dataSize // Size
        ).also { checkGLError("glCopyBufferSubData") }


        // Unbind copy targets
        glBindBuffer(GL_COPY_READ_BUFFER, 0)
        glBindBuffer(GL_COPY_WRITE_BUFFER, 0)

        // Ensure copy operation is visible before the vertex shader reads the VBO
        glMemoryBarrier(GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT)
    }

    //** Create the buffer that the vertex shader will read.
    private fun createRenderVBO(){

        glGenBuffers(1, vboIdArray, 0)
        renderVboId = vboIdArray[0]
        checkGLError("glGenBuffers (Render VBO)")

        if (renderVboId <= 0) { throw RuntimeException("Failed to generate Render VBO ID.")  }

        glBindBuffer(GLES31.GL_ARRAY_BUFFER, renderVboId)
        checkGLError("glBindBuffer (Render VBO)")

        // Calculate the size needed for vec4 (pos/alpha) per particle
        val renderVboSizeBytes = particleCount * VEC4_COMPONENTS * FLOAT_SIZE_BYTES * numTiles

        // Allocate buffer storage on the GPU. Pass null for data initially,
        // as it will be filled by glCopyBufferSubData from the render SSBO.
        // Usage hint GL_DYNAMIC_DRAW: updated frequently (by GPU copy), read frequently (by VS).
        glBufferData(
            GL_ARRAY_BUFFER,
            renderVboSizeBytes,
            null, // No initial data from CPU
            GL_DYNAMIC_DRAW // Usage hint
        )
        checkGLError("glBufferData (Render VBO)")

        Log.d(TAG, "Render VBO created successfully: ID=$renderVboId, Size=$renderVboSizeBytes bytes")

        // Unbind the VBO for now
        glBindBuffer(GL_ARRAY_BUFFER, 0)

    }

    /**
     * Binds the static, dynamic, and render SSBOs to their respective
     * designated binding points (0, 1, 2 by default) for use by a Compute Shader.
     *
     * Call this before dispatching the compute shader that needs access to these buffers.
     * Ensure the compute shader uses matching `layout(std430, binding = X)` qualifiers.
     */
    fun bindBuffersToCompute() {
        // Check if buffers have been successfully created before attempting to bind
        if (staticSsboId <= 0 || dynamicSsboId <= 0 || renderSsboId <= 0) {
            Log.e(TAG, "Cannot bind SSBOs: One or more buffer IDs are invalid.")
            // Depending on your error handling, you might want to throw an exception here
            // or just return to prevent GL errors.
            return
        }

        // Bind the static SSBO (initial positions) to its binding point
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, staticSsboBindingPoint, staticSsboId)
        //checkGLError("glBindBufferBase staticSsbo (point $staticSsboBindingPoint)")
        // Log.v(TAG, "Bound static SSBO ($staticSsboId) to point $staticSsboBindingPoint") // Optional verbose logging

        // Bind the dynamic SSBO (current pos/lifetime) to its binding point
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, dynamicSsboBindingPoint, dynamicSsboId)
        //checkGLError("glBindBufferBase dynamicSsbo (point $dynamicSsboBindingPoint)")
        // Log.v(TAG, "Bound dynamic SSBO ($dynamicSsboId) to point $dynamicSsboBindingPoint")

        // Bind the render SSBO (render pos/alpha) to its binding point
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, renderSsboBindingPoint, renderSsboId)
        //checkGLError("glBindBufferBase renderSsbo (point $renderSsboBindingPoint)")
        // Log.v(TAG, "Bound render SSBO ($renderSsboId) to point $renderSsboBindingPoint")

        // Note: You don't typically call glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0) immediately
        // after glBindBufferBase. The buffers need to remain bound to their *indexed*
        // binding points while the compute shader that uses them is dispatched.
        // The bindings persist until overwritten by another glBindBufferBase call to the
        // same index, or until the GL context is destroyed.
    }


    /** Helper to allocate a direct FloatBuffer with native byte order **/
    private fun allocateFloatBuffer(capacity: Int): FloatBuffer {
        return ByteBuffer.allocateDirect(capacity * FLOAT_SIZE_BYTES)
            .order(ByteOrder.nativeOrder()) // Crucial for GL interop
            .asFloatBuffer()
    }

    /** Helper for basic GL error checking **/
    private fun checkGLError(operation: String) {
        val error = glGetError()
        if (error != GL_NO_ERROR) {
            Log.e(TAG, "$operation: glError 0x${Integer.toHexString(error)}")
            // Consider throwing an exception in critical paths
            // throw RuntimeException("$operation: glError 0x${Integer.toHexString(error)}")
        }
    }

    /** Call this when cleaning up your OpenGL context (e.g., in onSurfaceDestroyed) **/
    fun cleanup() {
        Log.d(TAG, "Cleaning up SSBOs...")
        // Make sure buffer IDs were actually generated before trying to delete
        if (bufferIds[0] > 0 || bufferIds[1] > 0 || bufferIds[2] > 0) {
            glDeleteBuffers(bufferIds.size, bufferIds, 0)
            Log.d(TAG, "  Deleted buffers with IDs: ${bufferIds.contentToString()}")
            // Reset IDs to indicate they are no longer valid
            bufferIds.fill(0)
            staticSsboId = -1
            dynamicSsboId = -1
            renderSsboId = -1
        } else {
            Log.d(TAG, "  No valid buffer IDs to delete.")
        }
        checkGLError("glDeleteBuffers")
    }

    fun loadParticlesToStaticBuffer(particleVertexBuffer: FloatBuffer) {

        // 2. Bind the buffer ID to the generic target
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, staticSsboId)
        checkGLError("glBindBuffer staticSsbo for data upload")

        // 3. Allocate storage and upload the data from the FloatBuffer
        val staticBufferSize = particleCount * VEC2_COMPONENTS * FLOAT_SIZE_BYTES
        glBufferData(
            GL_SHADER_STORAGE_BUFFER, // Target
            staticBufferSize,                // Size in bytes
            particleVertexBuffer,                // The FloatBuffer containing the data
            GL_STATIC_DRAW            // Usage hint
        )
        checkGLError("glBufferData staticSsbo")
        Log.d(TAG, "  Static SSBO ($staticSsboId): Allocated $staticBufferSize bytes, uploaded initial data.")

        // 4. NOW bind it to the specific indexed binding point for shader access
        glBindBufferBase(GL_SHADER_STORAGE_BUFFER, staticSsboBindingPoint, staticSsboId)
        checkGLError("glBindBufferBase staticSsbo (point $staticSsboBindingPoint)")
        Log.d(TAG, "  Static SSBO ($staticSsboId) bound to binding point $staticSsboBindingPoint")

        // 5. Unbind from the generic target (optional but good practice)
        glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0)
    }
}