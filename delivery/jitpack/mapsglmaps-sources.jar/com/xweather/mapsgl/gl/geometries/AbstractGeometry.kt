package com.xweather.mapsgl.gl.geometries

import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeDataType
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import java.nio.ShortBuffer

abstract class AbstractGeometry() :
    Geometry {

    override var nextAttributeId: Int = 1

    override fun addAttribute(key: AttributeKey, attr: IBufferAttribute<*>) {
    }

    override fun getAttribute(key: AttributeKey) = map[key]

    fun setAttributeData(key: AttributeKey, attr: IBufferAttribute<*>) {
        map[key] = attr
    }

    override fun removeAttribute(key: AttributeKey) {
        map.remove(key)
    }

    override fun setVertices(vertices: FloatArray) {
        // Vertices
        val stride = 3
        val byteLength: Int = vertices.size * BufferAttribute.FLOAT_WIDTH
        val buffer: FloatBuffer = getFloatBufferFromFloatArray(vertices)
        this.addAttribute(
            AttributeKey.Position,
            BufferAttribute(
                buffer,
                byteLength,
                AttributeDataType.FloatBuffer,
                stride
            )
        )
    }

    override fun setNormals(normals: FloatArray) {
        // Normals
        val stride = 3
        val byteLength: Int = normals.size * BufferAttribute.FLOAT_WIDTH
        val buffer: FloatBuffer = getFloatBufferFromFloatArray(normals)
        this.addAttribute(
            AttributeKey.Normal,
            BufferAttribute(
                buffer,
                byteLength,
                AttributeDataType.FloatBuffer,
                stride
            )
        )
    }

    override fun setIndices(indices: ShortArray) {
        val stride = 1
        val byteLength: Int = indices.size * BufferAttribute.SHORT_WIDTH
        val buffer: ShortBuffer = getShortBufferFromShortArray(indices)
        val attribute = BufferAttribute(
            buffer,
            byteLength,
            AttributeDataType.ShortBuffer,
            stride
        )
        this.addAttribute(AttributeKey.Index, attribute)
    }

    override fun setColor(colors: FloatArray) {
        val RGBA = 4
        val byteLength: Int = colors.size * BufferAttribute.FLOAT_WIDTH
        var buffer: FloatBuffer = getFloatBufferFromFloatArray(colors)
        this.addAttribute(
            AttributeKey.Color,
            BufferAttribute(
                buffer,
                byteLength,
                AttributeDataType.FloatBuffer,
                RGBA
            )
        )
    }

    override fun setUVs(uvs: FloatArray) {
        val stride = 2
        val byteLength: Int = uvs.size * BufferAttribute.FLOAT_WIDTH
        val buffer: FloatBuffer = getFloatBufferFromFloatArray(uvs)
        this.addAttribute(
            AttributeKey.UV,
            BufferAttribute(buffer, byteLength, AttributeDataType.FloatBuffer, stride)
        )
    }

    private fun getByteBufferFromByteArray(array: ByteArray): ByteBuffer {
        val buffer = ByteBuffer.allocateDirect(array.size)
        buffer.put(array)
        buffer.position(0)
        return buffer
    }

    fun getFloatBufferFromFloatArray(array: FloatArray): FloatBuffer {
        val tempBuffer = ByteBuffer.allocateDirect(array.size * 4)
        tempBuffer.order(ByteOrder.nativeOrder())
        val buffer = tempBuffer.asFloatBuffer()
        buffer.put(array)
        buffer.position(0)
        return buffer
    }

    private fun getShortBufferFromShortArray(array: ShortArray): ShortBuffer {
        val tempBuffer = ByteBuffer.allocateDirect(array.size * 2)
        tempBuffer.order(ByteOrder.nativeOrder())
        val buffer = tempBuffer.asShortBuffer()
        buffer.put(array)
        buffer.position(0)
        return buffer
    }

    private fun getIntBufferFromIntArray(array: IntArray): IntBuffer {
        val tempBuffer = ByteBuffer.allocateDirect(array.size * 4)
        tempBuffer.order(ByteOrder.nativeOrder())
        val buffer = tempBuffer.asIntBuffer()
        buffer.put(array)
        buffer.position(0)
        return buffer
    }
}

