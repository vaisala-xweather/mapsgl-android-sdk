package com.xweather.mapsgl.gl.geometries

import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import com.xweather.mapsgl.gl.worldObjects.DrawMode
import java.nio.FloatBuffer

class BoxesGeometry(
    override val id: Int,
    override var map: HashMap<AttributeKey, IBufferAttribute<*>>,
    override val drawMode: DrawMode? = DrawMode.Triangles,
    override val drawRange: DrawRange? = null,
    override val instanced: Instanced? = null,
    override val geometryBuffer: FloatBuffer,
    override val bounds: GeometryBounds
) :
    AbstractGeometry(/*id, map, drawMode, drawRange, instanced*/), Geometry {

    /**
     * Depth, or the length along the z axis. Default value is `1`.
     *
     * @type {number}
     * @memberof BoxGeometryOpts
     */
    var depth: Int = 0

    /**
     * Number of depth segments. Default value is `1`.
     *
     * @type {number}
     * @memberof BoxGeometryOpts
     */
    var depthSegments: Int = 0

    init {
        var normals = ArrayList<Float>()
        var uvs = ArrayList<Float>()
        var vertices = ArrayList<Float>()
        var indices = ArrayList<Short>()
        var colors = ArrayList<Float>()

        /*
         * TODO remove all but 8 vertices (front + back)
         *  All triangles can be defined via indices
         *
         * No idea why tutorial has me define all vertices
         * https://arm-software.github.io/opengl-es-sdk-for-android/simple_cube.html
         */
        vertices = arrayListOf(
            // FRONT
            -0.002f, -0.002f, 0.002f,  // 0
            0.002f, -0.002f, 0.002f,  // 1
            -0.002f, 0.002f, 0.002f,  // 2
            0.002f, 0.002f, 0.002f,  // 3
            // BACK
            -0.002f, 0.002f, -0.002f,  // 4
            0.002f, 0.002f, -0.002f,  // 5
            -0.002f, -0.002f, -0.002f,  // 6
            0.002f, -0.002f, -0.002f,  // 7
        )

        indices = arrayListOf(
            0, 1, 2, 1, 3, 2, // FRONT
            4, 5, 6, 5, 7, 6, // BACK
            0, 2, 4, 0, 4, 6, // LEFT
            1, 7, 3, 3, 7, 5, // RIGHT
            2, 3, 4, 3, 5, 4, // TOP
            1, 0, 6, 1, 6, 7 // BOTTOM
        )

        colors = arrayListOf(
            1.0f, 0.0f, 0.0f,
            1.0f, 0.0f, 0.0f,
            1.0f, 0.0f, 0.0f,
            1.0f, 0.0f, 0.0f,

            0.0f, 1.0f, 0.0f,
            0.0f, 1.0f, 0.0f,
            0.0f, 1.0f, 0.0f,
            0.0f, 1.0f, 0.0f,

            0.0f, 0.0f, 1.0f,
            0.0f, 0.0f, 1.0f,
            0.0f, 0.0f, 1.0f,
            0.0f, 0.0f, 1.0f,

            1.0f, 1.0f, 0.0f,
            1.0f, 1.0f, 0.0f,
            1.0f, 1.0f, 0.0f,
            1.0f, 1.0f, 0.0f,

            0.0f, 1.0f, 1.0f,
            0.0f, 1.0f, 1.0f,
            0.0f, 1.0f, 1.0f,
            0.0f, 1.0f, 1.0f,

            1.0f, 0.0f, 1.0f,
            1.0f, 0.0f, 1.0f,
            1.0f, 0.0f, 1.0f,
            1.0f, 0.0f, 1.0f,
        )

        uvs = arrayListOf(
            1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
            1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
            1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
            1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
            1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
            1.0f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f,
        )

        normals = arrayListOf(
            // front
            0f, 0f, 1f,
            0f, 0f, 1f,
            0f, 0f, 1f,
            0f, 0f, 1f,

            // top
            0f, 1f, 0f,
            0f, 1f, 0f,
            0f, 1f, 0f,
            0f, 1f, 0f,

            // bottom
            0f, -1f, 0f,
            0f, -1f, 0f,
            0f, -1f, 0f,
            0f, -1f, 0f,

            // left
            1f, 0f, 0f,
            1f, 0f, 0f,
            1f, 0f, 0f,
            1f, 0f, 0f,

            // right
            -1f, 0f, 0f,
            -1f, 0f, 0f,
            -1f, 0f, 0f,
            -1f, 0f, 0f,

            // back
            0f, 0f, -1f,
            0f, 0f, -1f,
            0f, 0f, -1f,
            0f, 0f, -1f,
        )

        setVertices(vertices.toFloatArray())
        setIndices(indices.toShortArray())
        setColor(colors.toFloatArray())
    }
}