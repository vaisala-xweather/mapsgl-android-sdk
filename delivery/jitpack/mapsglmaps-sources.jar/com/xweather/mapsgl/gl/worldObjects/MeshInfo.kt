package com.xweather.mapsgl.gl.worldObjects

class MeshInfo(var x: Float, val y: Float, val z: Float, var hashCode: String) {
    var inspectorHash: String = hashCode
}