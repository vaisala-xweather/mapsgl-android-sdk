package com.xweather.mapsgl.gl.worldObjects

import android.opengl.GLES31
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.geometries.QuadGeometry
import com.xweather.mapsgl.gl.programs.Program

/*
 * TODO mesh world matrix is just identity
 *  No transform applied ... vertices are located where they are.
 */
interface IMesh {
    val id: Int
    var geometry: QuadGeometry
    //val program: IProgram

    var modelMatrix: Matrix4

    //    var normalMatrix: Matrix3
    val program: Program?
    var drawMode: DrawMode
    var renderOrder: Int
    var zDepth: Int
    var angle: Float

    fun updateModelMatrix()
}

enum class DrawMode() {
    Lines,
    Triangles,
    TriangleStrip,
    Points
}

/*
 * DrawMode Extension method
 */
inline fun <reified DrawMode : Enum<DrawMode>> DrawMode.toGLint(): Int {
    return when (this) {
        com.xweather.mapsgl.gl.worldObjects.DrawMode.Lines -> GLES31.GL_LINES
        com.xweather.mapsgl.gl.worldObjects.DrawMode.Points -> GLES31.GL_POINTS
        com.xweather.mapsgl.gl.worldObjects.DrawMode.TriangleStrip -> GLES31.GL_TRIANGLE_STRIP
//        com.xweather.mapsgl.gl.worldObjects.cameras.DrawMode.TriangleStrip
        else -> GLES31.GL_TRIANGLES
    }
}