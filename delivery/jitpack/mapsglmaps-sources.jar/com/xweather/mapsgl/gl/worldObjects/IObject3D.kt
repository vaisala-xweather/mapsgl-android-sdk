package com.xweather.mapsgl.gl.worldObjects

import com.xweather.mapsgl.gl.math.Euler
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.math.QuaternionTC
import com.xweather.mapsgl.gl.math.Vector3


interface IObject3D {
    var visible: Boolean

    var localMatrix: ProjectionMatrix
    var worldMatrix: ProjectionMatrix
    var matrixAutoUpdate: Boolean


    /** The object's local position. Default is `(0, 0, 0)`. */
    var position: Vector3

    // /** The object's local scale. Default is `(1, 1, 1)`. */
    var scale: Vector3

    // /** The object's local rotation, in radians. */
    var rotation: Euler

    // /** The object's local rotation as a quaternion. */
    var quaternion: QuaternionTC

    /**
     * Used by the `lookAt` method, for example, to determin the orientation of the result.
     * Default is `(0, 1, 0)`, which is up.
     */
    var up: Vector3

    fun lookAt(target: Vector3, invert: Boolean = false)
    fun updateMatrixWorld(force: Boolean = false)
    fun updateMatrix()
}