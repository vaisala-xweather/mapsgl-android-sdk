package com.xweather.mapsgl.gl.worldObjects

import android.opengl.GLES31
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.geometries.QuadGeometry
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.programs.Program
import com.xweather.mapsgl.gl.programs.TriangleProgram
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.style.ParticleLayerPaint
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

const val BYTES_PER_FLOAT = 4
const val COORDS_PER_VERTEX = 2
const val VERTEX_COUNT = 4
private const val TAG = "Mesh"

/**
 *  Mesh.kt
 *
 *
 *  @author Jason Suto on 12/11/23.
 */

class Mesh(
    override val id: Int,
    override var geometry: QuadGeometry,
    override val program: Program,
    val screenProgram: /*RasterTile*/Program? = null,
    val touchProgram: Program? = null,
) : IMesh, AbstractObject3D() {

    private val arrayOfHashMaps: Array<HashMap<String, FramebufferTexture>> = Array(23) { HashMap() }

    //val fbHashMap=hashMapOf<String, FBTex>()
    private var read = 1
    private var write = 0
    private var combinedBuffer = 4
    private var trailBuffer = 3
    private var tempBuffer = 2
    var fbTex: FramebufferTexture? = null
    override var modelMatrix: Matrix4 = Matrix4()   // default identity

    // override var normalMatrix: Matrix3 = Matrix3() // normal of camera x model -- for lighting or sort ?
    override var drawMode: DrawMode = DrawMode.Triangles
    override var renderOrder: Int = 0
    override var zDepth: Int = 0
    override var angle: Float = 0f
    private lateinit var hashString: String
    lateinit var prog: TriangleProgram
    var matrix = FloatArray(16)
    private var geometryBuffer: FloatBuffer =
        ByteBuffer.allocateDirect(VERTEX_COUNT * COORDS_PER_VERTEX * BYTES_PER_FLOAT).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }

    var textureProgram: Program? = null

    companion object {
        var FRAMEBUFFER_W = 1440
        var FRAMEBUFFER_H = 3200//FIXME: needs to be dynamic!

    }

    /*
    private val circleVertices = floatArrayOf( 0.0f, 0.0f,    // Center
        0.05f*.2f, 0.0f,   // 0 degrees
        0.035f*.2f, 0.035f*.1f, // 45 degrees
        0.0f, 0.05f*.1f,   // 90 degrees
        -0.035f*.2f, 0.035f*.1f, // 135 degrees
        -0.05f*.2f, 0.0f*.1f,  // 180 degrees
        -0.035f*.2f, -0.035f*.1f, // 225 degrees
        0.0f, -0.05f*.1f,  // 270 degrees
        0.035f*.2f, -0.035f*.1f, // 315 degrees
        0.05f*.2f, 0.0f  )  // 0 degrees to close the shape

    val circVertexBuffer = ByteBuffer.allocateDirect(circleVertices.size * 4)
        .order(ByteOrder.nativeOrder())
        .asFloatBuffer()
        .put(circleVertices)
        .position(0)
       */
    private val partTexCoords = floatArrayOf(
        0.0f, 0.0f,  // Top-left
        1.0f, 0.0f,  // Top-right
        0.0f, 1.0f,  // Bottom-left
        1.0f, 1.0f   // Bottom-right
    ) //unused. may be used to scale texture within part-vert buffer?


    init {
        geometryBuffer.apply {
            clear()
            put(geometry.geometryBuffer)
            rewind()
        }

    }

    override fun updateModelMatrix() { //model matrix is like local and world matrices from TS version
        /*
        Matrix.setIdentityM(matrix, 0); // initialize to identity matrix
        Matrix.scaleM(matrix, 0, 512f,512f,1f)
        Matrix.translateM(matrix, 0, position.x, position.y,0f)
        modelMatrix.fromArray(matrix)
         */
    }

    fun draw(texUnit: Int) {
        program.use() //  Texture binding to be moved here
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit)
        GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun draw2Textures(texUnit1: Int, texUnit2: Int) {
        program.use() //  Texture binding to be moved here
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit1)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE4)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit2)
        GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun drawParticleTile(
        texUnit: Int,
        drawNum: Int,
        programUse: Boolean = true,
        offset: Int
    ) { //draw a tile to framebuffer
        if (programUse) {
            program.use()
        }
        GLES31.glDisable(GLES31.GL_BLEND)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit)
        GLES31.glDrawArrays(GLES31.GL_POINTS, offset, drawNum)
    }

    fun drawParticleTileSquareNoUse(texUnit: Int) { //draw a tile to framebuffer
        GLES31.glDisable(GLES31.GL_BLEND)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit)
        GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun drawFrameBufferQuad(drawTrails: Boolean, paint: ParticleLayerPaint, fadeCalc: Float) {
        screenProgram!!.use()
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)

        if (drawTrails) {
            GLES31.glEnable(GLES31.GL_BLEND)
            GLES31.glBlendFunc(GLES31.GL_ONE, GLES31.GL_ONE_MINUS_SRC_ALPHA) //during meeting

            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, fbTex!!.framebufferIds[combinedBuffer])

            if (Camera.darkBackground) clearToColor(0f, 0f, 0f, 0f)
            else {
                clearToColor(.92f, .92f, .92f, 0f)
            }
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, fbTex!!.textureIds[trailBuffer]) //old trails to combined buffer
            (screenProgram as TriangleProgram).setFBPreMult(1)
            (screenProgram).setAlpha(1.00f)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
            GLES31.glEnable(GLES31.GL_BLEND)
            GLES31.glBlendFunc(GLES31.GL_ONE, GLES31.GL_ONE_MINUS_SRC_ALPHA)

            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, fbTex!!.textureIds[1]) //draw new particles to combined buffer
            screenProgram.setFBPreMult(1)
            screenProgram.setAlpha(1.0f)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)

            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, fbTex!!.framebufferIds[tempBuffer])
            clearToColor(0f, 0f, 0f, 0f)

            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, fbTex!!.textureIds[trailBuffer])
            screenProgram.setFBPreMult(0)
            screenProgram.setAlpha(fadeCalc) //.995
            GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)

            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, fbTex!!.framebufferIds[trailBuffer])
            GLES31.glDisable(GLES31.GL_BLEND);
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, fbTex!!.textureIds[tempBuffer])//draw faded trails to trailbuffer
            screenProgram.setFBPreMult(0)
            screenProgram.setAlpha(1.0f)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
            GLES31.glEnable(GLES31.GL_BLEND);
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, fbTex!!.textureIds[1])//draw new trails to trailbuffer
            screenProgram.setFBPreMult(1)
            screenProgram.setAlpha(1.0f)
            GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)

            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)//get ready to draw to screen
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, fbTex!!.textureIds[combinedBuffer])

        } else {

            GLES31.glEnable(GLES31.GL_BLEND)
            GLES31.glBlendFunc(GLES31.GL_ONE, GLES31.GL_ONE_MINUS_SRC_ALPHA)
            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, fbTex!!.framebufferIds[trailBuffer])
            clearToColor(1f, 1f, 1f, 0f)
            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)//get ready to draw to screen
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, fbTex!!.textureIds[1]) //draw new paritcles only

        }
        (screenProgram as TriangleProgram).setFBPreMult(1)
        screenProgram.setAlpha(paint.opacity)
        GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)

        GLES31.glDisable(GLES31.GL_BLEND)
        swapTrailBuffers()
    }

    private fun swapTrailBuffers() {
        if (write == 0) {
            write = 1
            read = 0
        } else {
            write = 0
            read = 1
        }
    }

    fun setWireFrame(isLine: Boolean) {
        drawMode = if (isLine) {
            DrawMode.Lines
        } else {
            DrawMode.Triangles
        }
    }

    fun clone(): IMesh {
        val mesh = Mesh(id, geometry, program)

        mesh.let {
            it.modelMatrix = this.modelMatrix
//            it.normalMatrix = this.normalMatrix
            it.drawMode = this.drawMode
            it.renderOrder = this.renderOrder
            it.zDepth = this.zDepth
            it.hashString = this.hashString
        }
        return mesh
    }

    fun clearZoomLevel(zoom: Int) {
        for (item in arrayOfHashMaps[zoom]) {
            item.value.cleanup()
        }
    }

    fun clearToColor(r: Float = 0f, g: Float = 0f, b: Float = 0f, a: Float = 0f) {
        GLES31.glClearColor(r, g, b, a)
        GLES31.glClear(GLES31.GL_COLOR_BUFFER_BIT)
    }

}

class FramebufferTexture {

    var framebufferIds = IntArray(NUMFRAMES)
    var textureIds = IntArray(NUMFRAMES)
    var complete = false

    companion object {
        const val NUMFRAMES = 5
    }

    init {
        createFramebuffers()
    }

    fun createFramebuffers() {
        GLES31.glGenFramebuffers(NUMFRAMES, framebufferIds, 0)
        GLES31.glGenTextures(NUMFRAMES, textureIds, 0)

        for (i in framebufferIds.indices) {
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureIds[i])
            GLES31.glTexImage2D(
                GLES31.GL_TEXTURE_2D, 0, GLES31.GL_RGBA,
                Mesh.FRAMEBUFFER_W, Mesh.FRAMEBUFFER_H,
                0, GLES31.GL_RGBA, GLES31.GL_UNSIGNED_BYTE, null
            )

            var error = GLES31.glGetError()
            if (error != GLES31.GL_NO_ERROR) {
                if (pr.ON) pr.p("FBTex", pr.i13, "OpenGL error after glTexImage2D for texture $i: $error")
            }

            error = GLES31.glGetError()
            if (error != GLES31.GL_NO_ERROR) {
                if (pr.ON) pr.p("FBTex", pr.i13, "OpenGL error after glFramebufferTexture2D for framebuffer $i: $error")
            }

            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
            //GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_NEAREST)
            //GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_NEAREST)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE);
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE);

            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, framebufferIds[i])
            GLES31.glFramebufferTexture2D(
                GLES31.GL_FRAMEBUFFER,
                GLES31.GL_COLOR_ATTACHMENT0,
                GLES31.GL_TEXTURE_2D,
                textureIds[i],
                0
            )

            if (GLES31.glCheckFramebufferStatus(GLES31.GL_FRAMEBUFFER) != GLES31.GL_FRAMEBUFFER_COMPLETE) {
                throw RuntimeException("Framebuffer ${i} is not complete")
            }
        }
        complete = true
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)

    }

    fun cleanup() {
        // Delete the framebuffers
        // GLES31.glDeleteFramebuffers can take an array of IDs.
        // It's important that framebufferIds contains the actual IDs generated.
        // If some FBOs failed to create and their IDs were set to 0, glDeleteFramebuffers ignores 0.
        GLES31.glDeleteFramebuffers(NUMFRAMES, framebufferIds, 0)
        GLES31.glDeleteTextures(NUMFRAMES, textureIds, 0)
        for (i in framebufferIds.indices) {
            framebufferIds[i] = 0
        }
        for (i in textureIds.indices) {
            textureIds[i] = 0
        }

        if (pr.ON) pr.p("FBTex", pr.i13, "cleanup() - Framebuffers and textures deleted.")
    }
}

