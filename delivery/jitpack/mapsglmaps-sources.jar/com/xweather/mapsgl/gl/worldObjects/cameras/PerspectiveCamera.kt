package com.xweather.mapsgl.gl.worldObjects.cameras

import android.graphics.RectF

class PerspectiveCamera(
    override var type: CameraType = CameraType.Perspective,
    override var near: Float,
    override var far: Float,
    override var fov: Float,
    override var aspect: Float,
    override var bounds: RectF,
    override var zoom: Double
) : Camera(type, near, far, fov, aspect, bounds, zoom) {
    fun updateProjectionMatrix() {
        this.projectionMatrix.fromPerspective(this.fov, this.aspect, this.near, this.far);
    }
}