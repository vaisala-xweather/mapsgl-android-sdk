package com.xweather.mapsgl.gl

import android.opengl.GLES20.glUniform1i
import android.opengl.GLES31
import android.opengl.GLES31.glUniform1f
import android.opengl.Matrix
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.ParticleSsboManager.Companion.FLOAT_SIZE_BYTES
import com.xweather.mapsgl.gl.ParticleSsboManager.Companion.VEC4_COMPONENTS
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.programs.TriangleProgram
import com.xweather.mapsgl.gl.util.Map3D
import com.xweather.mapsgl.gl.worldObjects.FramebufferTexture
import com.xweather.mapsgl.gl.worldObjects.Mesh
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import java.lang.Integer.max
import java.lang.Integer.min
import kotlin.math.floor
import kotlin.math.pow
import kotlin.random.Random
import java.util.ArrayDeque
import com.xweather.mapsgl.map.mapbox.GlStencilMaskRendererHolder

/**
 *   ParticleRenderPass.kt
 *
 *  A `RenderPass` draws a list of Meshes that share the same `RenderMaterial`/`RenderShader`
 *  and the same `GeometryVertexElementLayout` and thus all can use the same `RenderPipeline`
 *  @author Jason Suto 02/05/24.
 * @suppress
 */
open class ParticleRenderPass(
    override val label: String,
    paint: LayerPaint, //PaintStyle,
    override var meshes: List<Mesh>?,
    override var meshInfoList: List<MeshInfo>?
) : RenderPass(label, paint) {

    private companion object {
        const val PARTICLE_POOL_MAX_SLOTS = 128
    }

    //region variables
    override lateinit var id: String
    override val map3D = Map3D<Int, String>()
    override var hashString: String? = null
    private var modelMatrixHandle = 0
    private var projectionMatrixHandle = 0
    private val matrixArray = FloatArray(16)
    private val cameraArray = FloatArray(16)
    private val projectionMatrixArray = FloatArray(16)
    private val modelViewMatrixArray = FloatArray(16)

    //private val checkErrorString = "glUniformMatrix4fv"
    private val checkErrorUse = "glUseProgram"
    private lateinit var progPtr: RasterTileProgram
    private lateinit var texProgPtr: RasterTileProgram
    private var currentMesh: Mesh? = null
    private var scale = 1f
    private var newX = 0
    private var newY = 0
    private var scale2 = 1f
    private var newX2 = 0
    private var newY2 = 0
    private var altDataZoom = 1
    private var numTiles = 1
    private var speedCalc = 0f
    private var drawNum = 0
    private var fractionalZoom = 0.0
    private var scaleFactor = 0.0
    private var drawTrails = true
    private var paintStyle: ParticleLayerPaint
    private var fractionalZoomScale = 1.0
    private var speedScale = 1.0
    private var fpsFactor = 1f
    private var totalParticles = 0
    private var megaTexture: MegaTexture
    private var boundsInfo: BoundsInfo = BoundsInfo()
    private var enableParticles: Boolean = false
    private var enableFB: Boolean = false
    private var enableTexture: Boolean = false
    private lateinit var timeStringPtr: MutableList<String>
    private var particles: Particles

    /** Pooled SSBO/VBO for batched particle compute (see [syncParticleTileGpuFrame]). */
    private var particleTilePool: ParticleTileBufferPool? = null

    /** Canonical tile key → storage slot in [particleTilePool]. */
    private val particleSlotByTileKey = LinkedHashMap<String, Int>()

    private val freeParticleStorageSlots = ArrayDeque<Int>()
    private val staticParticleUploadedKeys = HashSet<String>()

    private val txParticleFrameScratch = FloatArray(PARTICLE_POOL_MAX_SLOTS)
    private val tyParticleFrameScratch = FloatArray(PARTICLE_POOL_MAX_SLOTS)
    private val storageSlotFrameScratch = IntArray(PARTICLE_POOL_MAX_SLOTS)

    /** Production uses true. If false, draws megatexture directly to the screen instead of to texture **/
    private var enableTextureFB: Boolean = true

    /** Production uses false. If true, draws underlying wind texture instead of particles **/
    private var enableTestTiles: Boolean = false

    /** Must match `local_size_x` in [assets/shaders/particles/tilePartComp31.glsl]. */
    private val particleComputeLocalSizeX = 128

    private val intArr = IntArray(10)

    //endregion variables

//region constructor
    /**
     * Initializes a `RenderPass` with the given parameters.
     */
    constructor(
        label: String = "null",
        paint: LayerPaint //PaintStyle

    ) : this(
        label,
        paint,
        null,
        null,
    ) {
        if (pr.ON) pr.p("ParticleRenderpath", pr.waaveRenderpath, ">> constructor: renderpass label is $label")
        paintStyle = (paint as ParticleLayerPaint)
    }
//endregion constructor

    init {
        if (false) { //For testing, draw fb directly to screen. Normally false.
            enableParticles = false
            enableFB = false
            enableTexture = true
            enableTextureFB = false
            enableTestTiles = false

        } else { // production code, particle tiles from megatexture
            enableParticles = true
            enableFB = true
            enableTexture = true
            enableTextureFB = true
            enableTestTiles = false // Test: draw sample tiles instead of particles. normally FALSE
        }
        paintStyle = (paint as ParticleLayerPaint)
        totalParticles = calculateTotalParticles() * 5
        particles = Particles(totalParticles)
        totalParticles
        megaTexture = MegaTexture()
    }

    /**
     * Re-reads the particle count from paint and resizes to match if it changed.
     *
     * The count is otherwise fixed when the pass is built, so changing
     * [com.xweather.mapsgl.style.ParticlePaint.density] or
     * [com.xweather.mapsgl.style.ParticlePaint.count] on a live layer moved a uniform and left the
     * simulation at its original size. This is the counterpart of the JS SDK dropping its memoized
     * particle count when those properties change.
     *
     * Dropping the pool is what actually resizes it: [cleanupSSBO] deletes the buffers and clears
     * the slot bookkeeping, and the pool is rebuilt lazily at the new size on the next frame.
     * [Particles] holds no GL objects - an array and a direct buffer - so replacing it is free.
     *
     * **GL thread only**, because [cleanupSSBO] deletes buffers. Reached through
     * `TileLayerRenderer.resetPaint`, which is consumed at the top of a draw.
     *
     * @return `true` if the count changed and the pass was resized.
     */
    fun refreshParticleCount(): Boolean {
        val target = calculateTotalParticles() * 5
        if (target == totalParticles) return false

        totalParticles = target
        particles = Particles(totalParticles)
        cleanupSSBO()
        return true
    }

    private fun calculateTotalParticles(): Int {
        var totalParticles = paintStyle.particle.count
        if (totalParticles == 0) {
            totalParticles = (paintStyle.particle.density.value.toInt())
        }
        totalParticles = max(0, min(256, totalParticles))
        //println("paintStyle.count: ${paintStyle.count}  paintStyle.density.value: ${paintStyle.density.value}, totalParticles: $totalParticles")
        return totalParticles.toDouble().pow(2.0).toInt()
    }

    /**
     * The step is a fraction of the tile. Once the tile is drawn larger than its 512px data
     * grid, that step is wider than the dot and strong wind breaks into separate stamps.
     */
    private fun fitSpeedToTile(speed: Float, camera: Camera): Float {
        val tilesAcross = boundsInfo.numX
        if (tilesAcross <= 0f || camera.resX <= 0) return speed
        val tilePx = camera.resX / tilesAcross
        return speed * (512f / tilePx).coerceAtMost(1f)
    }

    /**
     *
     * Loop through renderables and call draw() on each.
     *
     * Called from TileLayerRenderer.draw()
     *
     */
    override fun render(texHashMap: HashMap<String, Int>, camera: Camera) {

        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)

        intArr[0]++
        if (intArr[0] > 100) {
            intArr[0] = 0
        }

        if (meshes != null && meshes!!.isNotEmpty()) {
            currentMesh = meshes!!.first()
            setupCamera(camera)

            var phaseAString = ""
            var phaseBString = ""
            var finalMeld = 0f
            val layerInfo = Timeline.sourceTimeHash[label]
            val aInt: Int
            val bInt: Int

            if (layerInfo != null) {
                val viewportMeshesForPlayback = meshInfoList.orEmpty()
                val resolved = if (viewportMeshesForPlayback.isNotEmpty()) {
                    applyLayerViewportPlayback(layerInfo, viewportMeshesForPlayback, texHashMap)
                } else {
                    val target = layerInfo.computeGlobalAnimationTarget()
                    LayerDrawPhases(target.phaseA, target.phaseB, target.meld).also {
                        layerInfo.commitDisplayPhases(it.phaseA, it.phaseB, it.meld, true, null)
                    }
                }
                phaseAString = resolved.phaseA
                phaseBString = resolved.phaseB
                finalMeld = resolved.meld
                aInt = layerInfo.timeStrings.indexOf(phaseAString).coerceAtLeast(0)
                bInt = layerInfo.timeStrings.indexOf(phaseBString).coerceAtLeast(0)
                timeStringPtr = layerInfo.timeStrings

            } else {
                val global = Timeline.fallbackGlobalRenderPhases()
                phaseAString = global.first
                phaseBString = global.second
                finalMeld = global.third
                aInt = Timeline.timeStrings.indexOf(phaseAString).coerceAtLeast(0)
                bInt = Timeline.timeStrings.indexOf(phaseBString).coerceAtLeast(aInt)
                timeStringPtr = Timeline.timeStrings
            }
            finalMeld = applySampleMeldOption(finalMeld)

            if (timeStringPtr.isEmpty()) {
                return
            }

            //region Logic to draw to megatexture
            if (enableTexture) { //normally true
                boundsInfo.calcBounds(meshInfoList)
                texProgPtr = (currentMesh!!.textureProgram as RasterTileProgram)
                texProgPtr.bind()//.also { checkError("texProgPtr.bind") }

                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, texProgPtr.positionHandle)
                GLES31.glVertexAttribPointer(
                    texProgPtr.positionHandle,
                    COORDS_PER_VERTEX,
                    GLES31.GL_FLOAT,
                    false,
                    VERTEX_STRIDE,
                    megaTexture.vertexBuffer
                ).also { checkError("glVertexAttribPointer") }//vertexBuffer
                GLES31.glEnableVertexAttribArray(texProgPtr.positionHandle)

                texProgPtr.useOncePerFrame()

                //glUniform1f(texProgPtr.dataMeldLocation, Timeline.dataMeld) // moved below, using finalmeld

                fillProjectionAndViewFromMapboxOrCamera(camera)
                projectionMatrixHandle = GLES31.glGetUniformLocation(texProgPtr.programInt, "projectionMatrix")
                GLES31.glUniformMatrix4fv(projectionMatrixHandle, 1, false, projectionMatrixArray, 0)
                modelMatrixHandle = GLES31.glGetUniformLocation(texProgPtr.programInt, "modelViewMatrix")

                //DRAW TILES TO MEGATEXTURE ========================================================================
                if (enableTextureFB) { //Normal mode
                    megaTexture.createFramebuffer(512 * boundsInfo.numX.toInt(), 512 * boundsInfo.numY.toInt())
                    GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, megaTexture.framebufferId[0])
                    GLES31.glViewport(0, 0, 512 * boundsInfo.numX.toInt(), 512 * boundsInfo.numY.toInt())
                } else { //TEST:  Draw tiles directly to the screen
                    GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
                }

                GLES31.glClearColor(0f, 0f, 0f, 0f)
                GLES31.glClear(GLES31.GL_COLOR_BUFFER_BIT)
                GLES31.glEnable(GLES31.GL_BLEND)
                GLES31.glUniform1i(texProgPtr.nextTextureUniformLocation, 4) //this fixed the "no meld" issue

                if (pr.ON) {
                    if (lastMeshCount != meshInfoList!!.size) {
                        pr.p(
                            "ParticleRenderPass",
                            pr.tileCount,
                            "render() meshInfoList.size: ${meshInfoList!!.size}  meshes.size  ${meshes!!.size}"
                        )
                        lastMeshCount = meshInfoList!!.size
                        //for (mesh in meshInfoList!!) {
                        //    pr.p("ParticleRenderPass",  pr.tileCount,"render()         ${mesh.hashCode}  " )
                        //}
                    }
                }

                // Draw unprocessed encoded tiles to megatexture ------------------------------------------------

                meshInfoList?.forEach { meshInfo ->
                    //pr.p("ParticleRenderPass",  pr.tileCount,"render()      inLoop " )
                    val needsA = finalMeld < 1.0f
                    val needsB = finalMeld > 0.0f
                    val layerHolding = layerInfo != null && !layerInfo.viewportPlaybackReady
                    var foundA = false
                    var foundB = false
                    var newMX: Float
                    var hashStringB: String? = null


                    glUniform1f(texProgPtr.tXScaleLocation, (2f / boundsInfo.numX))
                    glUniform1f(
                        texProgPtr.tXOffsetLocation,
                        (meshInfo.x - boundsInfo.x1) * (2f / boundsInfo.numX) - (1 - (2f / boundsInfo.numX))
                    )

                    glUniform1f(texProgPtr.tYScaleLocation, (2f / boundsInfo.numY))
                    glUniform1f(
                        texProgPtr.tYOffsetLocation,
                        (meshInfo.y - boundsInfo.y1) * (2f / boundsInfo.numY) - (1 - (2f / boundsInfo.numY))
                    )

                    if (needsA) {
                        newMX = meshInfo.x
                        var newHashA = meshInfo.hashCode
                        if (newMX >= powerTableI[meshInfo.z.toInt()]) {
                            newMX -= powerTableI[meshInfo.z.toInt()]
                            newHashA = "0:${newMX.toInt()}/${meshInfo.y.toInt()}/${meshInfo.z.toInt()}/"
                        }

                        hashString = null
                        val tempString = "${newHashA}${phaseAString}"
                        if (pr.ON) pr.p("ParticleRenderPass", pr.partPartial, "render() A is looking for: $tempString")
                        if (texHashMap[tempString] != null) {
                            glUniform1f(texProgPtr.xScaleLocation, 1f)
                            glUniform1f(texProgPtr.xOffsetLocation, 0f)
                            glUniform1f(texProgPtr.yOffsetLocation, 0f)
                            texProgPtr.updateTexture1Size(1f, 1f, 0f, 0f)
                            hashString = tempString
                            foundA = true
                        } else {
                            foundA = false
                            hashString = determineMegatexturePartial(meshInfo, texHashMap, aInt, phaseAString, 1)

                            if (hashString != null) {
                                if (pr.ON) pr.p(
                                    "ParticleRenderPass",
                                    pr.partPartial,
                                    "render() scale1: $scale, nX: $newX  nY: $newY"
                                )
                                updateTextureSizes(meshInfo, scale, newX, newY, 1)
                                glUniform1f(texProgPtr.xScaleLocation, texProgPtr.xScale)
                                glUniform1f(texProgPtr.xOffsetLocation, texProgPtr.xOffset)
                                glUniform1f(texProgPtr.yOffsetLocation, texProgPtr.yOffset)
                                foundA = true
                            }
                        }


                        if (!foundA && !layerHolding) finalMeld = 1f

                        if (pr.ON && intArr[0] == 0) {
                            pr.p(
                                "ParticleRenderPass",
                                pr.windTilesR,
                                "render() needs A. hashString: $hashString, foundA: $foundA, meld: $finalMeld MIL.size: ${meshInfoList!!.size}"
                            )
                            if (!foundA) {
                                pr.p(
                                    "ParticleRenderPass",
                                    pr.windTilesR,
                                    "render() needs A. $phaseAString not found",
                                    2
                                )
                            }

                        }

                    } else if (!layerHolding) finalMeld = 1f

                    if (needsB /*&& bInt < timeStringPtr.size*/) {
                        newMX = meshInfo.x
                        var newHashB = meshInfo.hashCode
                        if (newMX >= powerTableI[meshInfo.z.toInt()]) {
                            newMX -= powerTableI[meshInfo.z.toInt()]
                            newHashB = "0:${newMX.toInt()}/${meshInfo.y.toInt()}/${meshInfo.z.toInt()}/"
                        }

                        val tempStringB = "${newHashB}${phaseBString}"
                        //if(pr.ON) pr.p("ParticleRenderPass", pr.partPartial, "render() B is looking for: $tempString")
                        if (texHashMap[tempStringB] != null) {
                            glUniform1f(texProgPtr.xScale2Location, 1f)
                            glUniform1f(texProgPtr.xOffset2Location, 0f)
                            glUniform1f(texProgPtr.yOffset2Location, 0f)
                            texProgPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                            hashStringB = tempStringB
                            foundB = true
                        } else {
                            //if(pr.ON) pr.p("PRenderPass", pr.partPartial, "render() looking for partial!!!")
                            foundB = false
                            hashStringB = determineMegatexturePartial(meshInfo, texHashMap, bInt, phaseBString, 2)
                            if (hashStringB != null) {
                                if (pr.ON) pr.p(
                                    "ParticleRenderPass",
                                    pr.partPartial,
                                    "render() scale2: $scale2, nX2: $newX2  nY2: $newY2"
                                )
                                updateTextureSizes(meshInfo, scale2, newX2, newY2, 2)
                                glUniform1f(texProgPtr.xScale2Location, texProgPtr.xScale2)
                                glUniform1f(texProgPtr.xOffset2Location, texProgPtr.xOffset2)
                                glUniform1f(texProgPtr.yOffset2Location, texProgPtr.yOffset2)
                                foundB = true
                            }
                        }

                        if (!foundB && !layerHolding) finalMeld = 0f

                        if (pr.ON && intArr[0] == 0) {
                            pr.p(
                                "ParticleRenderPass",
                                pr.windTilesR,
                                "render() needs B. hashStringB: $hashStringB, foundB: $foundB meld: $finalMeld, MIL.size: ${meshInfoList!!.size}"
                            )
                            if (!foundB) {
                                pr.p(
                                    "ParticleRenderPass",
                                    pr.windTilesR,
                                    "render() needs B. did not find ${phaseBString} ",
                                    2
                                )
                            }
                        }


                    } else {
                        finalMeld = 0f
                    }

                    if (pr.ON && intArr[0] == 0) {
                        pr.p(
                            "ParticleRenderPass",
                            pr.windTilesR,
                            "render() about to draw with finalMeld: $finalMeld"
                        )
                    }


                    glUniform1f(texProgPtr.dataMeldLocation, finalMeld)

                    if (pr.ON) pr.p(
                        "ParticleRenderPass",
                        pr.partPartial,
                        "render() nA: $needsA, nB: $needsB, fA:$foundA, fB, $foundB, dM: ${Timeline.dataMeld}"
                    )

                    megaTexture.drawTilesToTexture(texHashMap[hashString], texHashMap[hashStringB])

                } //end tile for-each

                // end Draw unprocessed encoded tiles to megatexture -------------------------------------
                boundsInfo.needsUpdate = false

                GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
                texProgPtr.unbind()
                GLES31.glViewport(0, 0, camera.resX, camera.resY)
            }  // end if(enableTexture)

            //endregion Logic to draw to megatexture


            /** Speed needs to gradually be scaled by half when tiles are rendered at fractional zooms otherwise
            particles will speed up as their parent tiles are scaled up towards the next integer zoom level
            (e.g. 1.x > 2.0) **/
            fractionalZoomScale = 1 - (camera.zoom % 1) * 0.5
            speedScale = 2.0 / camera.dpiMult // Speed is always calculated based on a base DPI of 2

            //If the camera is moving or zooming, re-use the last speedCalc to avoid "rewinding"
            if (camera.moveState != Camera.MOVING) {
                // Final speed is a combination of the particle speed, the zoom scale, and the speed scale
                speedCalc = (paintStyle.particle.speed * fractionalZoomScale * speedScale).toFloat()
                // Reduce speed when zoomed out at lower zoom levels (below zoom 3)
                speedCalc *= kotlin.math.min(1.0.toFloat(), (0.3 + 0.5 * (camera.zoom / 3.0)).toFloat())
                speedCalc = fitSpeedToTile(speedCalc, camera)
            }

            //region setup particles

            // Scale speed based on screen fps, but clamp it to a min of 1.0
            fpsFactor = kotlin.math.min(1f, camera.refreshRateFactor)

            if (enableParticles) {
                progPtr = (currentMesh!!.program as RasterTileProgram)

                /*
                if (enableTestTiles) { // Show the underlying wind texture instead of drawing particles
                    GLES31.glVertexAttribPointer(
                        progPtr.positionHandle,
                        COORDS_PER_VERTEX,
                        GLES31.GL_FLOAT,
                        false,
                        VERTEX_STRIDE,
                        megaTexture.testGeometryBuffer
                    ).also { checkError("glVertexAttribPointer") }//vertexBuffer
                }
                */

                // Bind velocity texture
                GLES31.glActiveTexture(GLES31.GL_TEXTURE0) // Use texture unit 0 for compute
                GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, megaTexture.textureIds[0])
                //endregion setup particles

                //region compute particles
                progPtr.bindCompute() // glUseProgram(computeProgramId)
                val particleTileCount = syncParticleTileGpuFrame()
                val pool = getParticleTilePool()
                pool.bindSsboBasesForCompute()
                // Set uniforms common to all compute dispatches
                glUniform1f(progPtr.speedMultLocationC, speedCalc * fpsFactor)
                glUniform1f(
                    GLES31.glGetUniformLocation(progPtr.computeProgramInt, "frameScaleC"),
                    fpsFactor
                )
                glUniform1f(
                    GLES31.glGetUniformLocation(progPtr.computeProgramInt, "randomSeedC"),
                    Random.nextFloat()
                )
                glUniform1f(progPtr.vectorOffsetLocationC, .5f /*paintStyle.vectorOffset*/)
                glUniform1f(progPtr.noDataLocationC, progPtr.noDataC)
                glUniform1i(progPtr.bufferItemsPerTileLocationC, totalParticles)
                GLES31.glUniform1i(
                    GLES31.glGetUniformLocation(progPtr.computeProgramInt, "uTexture"),
                    0
                ) //fixme: is this needed? Tell shader sampler uses unit 0

                fractionalZoom = camera.zoom % 1f
                scaleFactor = 4.0.pow(fractionalZoom)
                drawNum = particleDrawCountPerTile(totalParticles, camera.zoom, meshInfoList?.firstOrNull()?.z)
                glUniform1i(progPtr.drawNumLocationC, drawNum)

                val invBoundsComputeX = 1f / boundsInfo.numX
                val invBoundsComputeY = 1f / boundsInfo.numY
                glUniform1f(progPtr.tx_scaleLocationC, invBoundsComputeX)
                glUniform1f(progPtr.ty_scaleLocationC, invBoundsComputeY)

                val numGroupsX = (drawNum + particleComputeLocalSizeX - 1) / particleComputeLocalSizeX
                if (particleTileCount > 0 && numGroupsX > 0) {
                    GLES31.glDispatchCompute(numGroupsX, particleTileCount, 1)
                }
                if (particleTileCount > 0) {
                    pool.copyRenderToVboPooledSlots(storageSlotFrameScratch, particleTileCount, drawNum, false)
                    GLES31.glMemoryBarrier(GLES31.GL_VERTEX_ATTRIB_ARRAY_BARRIER_BIT)
                }

                // end Determine positions with compute shader all at once in a loop

                //region DRAW TILES TO FB ========================================================================
                progPtr.bind()//.also { checkError(checkErrorUse) }// Add program to OpenGL ES environment

                // Bind the VBO containing particle data for rendering
                GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, currentMesh!!.fbTex!!.framebufferIds[1])

                GLES31.glClear(GLES31.GL_COLOR_BUFFER_BIT)

                GLES31.glEnable(GLES31.GL_BLEND)

                val useMapboxNativeMv = fillProjectionAndViewFromMapboxOrCamera(camera)
                projectionMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "projectionMatrix")
                //.also { checkError("glGetUniformLocation") }
                GLES31.glUniformMatrix4fv(projectionMatrixHandle, 1, false, projectionMatrixArray, 0)
                modelMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "modelViewMatrix")
                //.also { checkError("glGetUniformLocation") }

                //endregion compute particles

                //region draw particles to FB
                progPtr.setBufferItemsPerTile(totalParticles)//.also { checkError("glGetUniformLocation") }
                progPtr.updateSpeedMult(speedCalc * fpsFactor)//.also { checkError("glGetUniformLocation") }
                if (paintStyle.particle.size.width == paintStyle.particle.size.height) {
                    progPtr.setPointSize(paintStyle.particle.size.width.toFloat() * camera.dpiMult * 2f)
                } else {
                    progPtr.setPointSize(
                        paintStyle.particle.size.width.toFloat() * camera.dpiMult * 2f,
                        paintStyle.particle.size.height.toFloat() * camera.dpiMult * 2f
                    )
                }

                glUniform1f(progPtr.vectorOffsetLocation, .5f /*paintStyle.vectorOffset*/)
                progPtr.useOncePerFrame()

                GLES31.glActiveTexture(GLES31.GL_TEXTURE1)//.also { checkError(checkErrorString) } // fixme: crash here on vankyo
                GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, (progPtr as TriangleProgram).colorBandTexHandles[0])

                //calculate how many particles to draw, accounting for fractional zoom levels
                // Without adjustment, particles were ~4x more dense at zoom 2.0 than 1.99

                val drawInvNx = 1f / boundsInfo.numX
                val drawInvNy = 1f / boundsInfo.numY

                var i = 0
                val poolDraw = getParticleTilePool()
                poolDraw.ensureParticleVao(2, VEC4_COMPONENTS, VEC4_COMPONENTS * FLOAT_SIZE_BYTES)
                if (poolDraw.particleVaoId != 0) {
                    GLES31.glBindVertexArray(poolDraw.particleVaoId)
                } else {
                    GLES31.glEnableVertexAttribArray(2)
                }

                if (enableTextureFB) {
                    progPtr.use()
                    glUniform1f(progPtr.tXScaleLocation, drawInvNx)
                    glUniform1f(progPtr.tYScaleLocation, drawInvNy)
                }

                meshInfoList?.forEach { meshInfo ->
                    val baseVert = storageSlotFrameScratch[i] * totalParticles
                    glUniform1i(
                        progPtr.bindingPointLocation,
                        0 /*i*/
                    ) // Determine which section of the position buffer to use
                    Matrix.setIdentityM(matrixArray, 0) // initialize to identity matrix
                    val mapZoomNow = CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom
                    val overscale = if (useMapboxNativeMv) {
                        CameraSync.tileRasterOverscale(mapZoomNow, meshInfo.z.toInt())
                    } else {
                        1f
                    }
                    Matrix.scaleM(matrixArray, 0, 512f * overscale, 512f * overscale, 1f)
                    Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
                    Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, matrixArray, 0) //works
                    GLES31.glUniformMatrix4fv(modelMatrixHandle, 1, false, modelViewMatrixArray, 0)

                    datelineAdjustment(meshInfo)

                    if (enableTextureFB) {  //normal

                        progPtr.use()
                        //if(pr.ON) pr.p("ParticleRenderPass", pr.particles, "enableTextureFB: $enableTextureFB ")
                        glUniform1f(progPtr.tXOffsetLocation, (meshInfo.x - boundsInfo.x1) * drawInvNx)
                        glUniform1f(progPtr.tYOffsetLocation, (meshInfo.y - boundsInfo.y1) * drawInvNy)

                        if (enableTestTiles) {
                            currentMesh?.drawParticleTileSquareNoUse(megaTexture.textureIds[0]) //draw test square
                        } else {
                            //if(pr.ON) pr.p("ParticleRenderPass", pr.compute, "before draw $i, drawNum: $drawNum")
                            currentMesh?.drawParticleTile(
                                megaTexture.textureIds[0],
                                drawNum,
                                false,
                                baseVert
                            ) //draw particles
                        }
                    } else {
                        texHashMap[meshInfo.hashCode]?.let {
                            progPtr.updateTexture1Size(1f, 1f, 0f, 0f)
                            var hash2: String? = "${meshInfo.hashCode}${phaseBString}"

                            if (texHashMap[hash2] != null) { //found full version of both textures
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                                currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                            } else {
                                hash2 = determinePartial(meshInfo, texHashMap, bInt, 2)
                                if (hash2 != null) {
                                    currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                } else {
                                    currentMesh?.draw(it)
                                }
                            }
                        } ?: run {
                            val meshString1 = determinePartial(meshInfo, texHashMap, aInt, 1)
                            var meshString2: String? =
                                "${meshInfo.hashCode}${phaseBString}" // the exact tile
                            if (texHashMap[meshString2] == null) { // if exact tile not found, use partial
                                meshString2 = determinePartial(meshInfo, texHashMap, bInt, 2)
                            } else {
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                            }

                            if (meshString1 != null) {
                                if (meshString2 != null) {
                                    currentMesh?.draw2Textures(texHashMap[meshString1]!!, texHashMap[meshString2]!!)
                                } else {
                                    currentMesh?.draw(texHashMap[meshString1]!!)
                                }
                                if (pr.ON) pr.p(
                                    "ParticleRenderer",
                                    pr.obs_play_rp,
                                    "found partial for ${meshInfo.hashCode}, using: $meshString1",
                                    1
                                )
                            } else {
                                if (pr.ON) pr.p(
                                    "ParticleRenderer",
                                    pr.obs_play_rp,
                                    "DID NOT FIND PARTIAL for ${meshInfo.hashCode}",
                                    2
                                )
                            }
                        }
                    } //end else !FBTEX
                    //GLES31.glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0) // Unbind
                    i++
                } //end tile for-each

                GLES31.glBindVertexArray(0)
                GLES31.glDisableVertexAttribArray(0) // Disable attribute
                GLES31.glDisableVertexAttribArray(2)
                GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0) // Unbind VBO
                //currentMesh!!.swapParticleBuffers()
                progPtr.unbind()
            }

            //endregion draw particles to FB

            //region DRAW FB TO SCREEN

            if (enableFB) {
                //if(pr.ON) pr.p("ParticleRenderPass", pr.i13, "render() enableFB")
                currentMesh = meshes!!.first()

                if (currentMesh!!.fbTex == null) {
                    currentMesh!!.fbTex = FramebufferTexture()

                    if (pr.ON) pr.p("ParticleRenderPass", pr.i13, "render() currentMesh!!.fbTex == null")
                }

                val sProgPtr: RasterTileProgram = (currentMesh!!.screenProgram as RasterTileProgram)
                // The layer's mask, for every visible tile, before the composite quad. Built before the
                // screen program is bound: the mask draw binds its own.
                val useMapboxMv = fillProjectionAndViewFromMapboxOrCamera(camera)
                val masked = compositeStencil?.invoke(
                    meshInfoList.orEmpty(),
                    projectionMatrixArray,
                    cameraArray,
                    useMapboxMv,
                    sProgPtr,
                ) == true
                sProgPtr.bind().also { checkError(checkErrorUse) }// Add program to OpenGL ES environment
                sProgPtr.useOncePerFrame()
                sProgPtr.use() //?
                //particle verts
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, sProgPtr.positionHandle).also { checkError("glBindBuffer") }
                GLES31.glVertexAttribPointer(
                    sProgPtr.positionHandle,
                    COORDS_PER_VERTEX,
                    GLES31.GL_FLOAT,
                    false,
                    VERTEX_STRIDE,
                    vertexBuffer
                )

                drawTrails =
                    (camera.moveState != Camera.MOVING && paintStyle.particle.trails && !Timeline.clearParticles)

                // Calculate and set trails fade
                val opacity = if (drawTrails) paintStyle.particle.trailsFade.toFloat() else paintStyle.opacity
                val opacityDelta = 1.0 - opacity
                val fadeCalc = 1.0 - opacityDelta * fpsFactor
                currentMesh?.drawFrameBufferQuad(drawTrails, paintStyle, fadeCalc.toFloat())
                if (masked) GlStencilMaskRendererHolder.renderer.disableStencil()

                GLES31.glDisable(GLES31.GL_BLEND)
                GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
                sProgPtr.unbind()

            }//end enableFB

            //endregion DRAW FB TO SCREEN

        } // end  if(meshes!=null&& meshes!!.isNotEmpty()){
    }

    /*
    fun renderOld(texHashMap: HashMap<String, Int>, camera: Camera) {

        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_STENCIL_TEST)

        if (pr.ON) pr.p("ParticleRenderPass", pr.waavePRP, "render() entered()")

        if (meshes != null && meshes!!.isNotEmpty()) {
            currentMesh = meshes!!.first()
            setupCamera(camera)

            //region Logic to draw to megatexture
            if (enableTexture) { //normally true
                boundsInfo.calcBounds(meshInfoList)
                texProgPtr = (currentMesh!!.textureProgram as RasterTileProgram)
                texProgPtr.bind()//.also { checkError("texProgPtr.bind") }

                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, texProgPtr.positionHandle)
                GLES31.glVertexAttribPointer(
                    texProgPtr.positionHandle,
                    COORDS_PER_VERTEX,
                    GLES31.GL_FLOAT,
                    false,
                    VERTEX_STRIDE,
                    megaTexture.vertexBuffer
                ).also { checkError("glVertexAttribPointer") }//vertexBuffer
                GLES31.glEnableVertexAttribArray(texProgPtr.positionHandle)

                texProgPtr.useOncePerFrame()

                glUniform1f(texProgPtr.dataMeldLocation, Timeline.dataMeld)

                matrixToFloatArray(camera.projectionMatrix, projectionMatrixArray)
                projectionMatrixHandle = GLES31.glGetUniformLocation(texProgPtr.programInt, "projectionMatrix")
                GLES31.glUniformMatrix4fv(projectionMatrixHandle, 1, false, projectionMatrixArray, 0)
                modelMatrixHandle = GLES31.glGetUniformLocation(texProgPtr.programInt, "modelViewMatrix")
                matrixToFloatArray(camera.viewMatrix, cameraArray)

                //DRAW TILES TO MEGATEXTURE ========================================================================
                if (enableTextureFB) { //Normal mode
                    megaTexture.createFramebuffer(512 * boundsInfo.numX.toInt(), 512 * boundsInfo.numY.toInt())
                    GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, megaTexture.framebufferId[0])
                    GLES31.glViewport(0, 0, 512 * boundsInfo.numX.toInt(), 512 * boundsInfo.numY.toInt())
                } else { //TEST:  Draw tiles directly to the screen
                    GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
                }

                GLES31.glClearColor(0f, 0f, 0f, 0f)
                GLES31.glClear(GLES31.GL_COLOR_BUFFER_BIT)
                GLES31.glEnable(GLES31.GL_BLEND)
                GLES31.glUniform1i(texProgPtr.nextTextureUniformLocation, 4) //this fixed the "no meld" issue

                if (pr.ON) {
                    if (lastMeshCount != meshInfoList!!.size) {
                        pr.p(
                            "ParticleRenderPass",
                            pr.tileCount,
                            "render() meshInfoList.size: ${meshInfoList!!.size}  meshes.size  ${meshes!!.size}"
                        )
                        lastMeshCount = meshInfoList!!.size
                        //for (mesh in meshInfoList!!) {
                        //    pr.p("ParticleRenderPass",  pr.tileCount,"render()         ${mesh.hashCode}  " )
                        //}
                    }
                }

                // Draw unprocessed encoded tiles to megatexture ------------------------------------------------

                //pr.p("ParticleRenderPass",  pr.tileCount,"render()      starting loop for ${meshInfoList!!.size} " )
                meshInfoList?.forEach { meshInfo ->
                    //pr.p("ParticleRenderPass",  pr.tileCount,"render()      inLoop " )
                    var needsA = true
                    var needsB = true
                    var foundA = false
                    var foundB = false
                    var newMX: Float
                    var hashStringB: String? = null
                    if (Timeline.dataMeld == 0f) needsB = false
                    else if (Timeline.dataMeld == 1f) needsA = false

                    glUniform1f(texProgPtr.tXScaleLocation, (2f / boundsInfo.numX))
                    glUniform1f(
                        texProgPtr.tXOffsetLocation,
                        (meshInfo.x - boundsInfo.x1) * (2f / boundsInfo.numX) - (1 - (2f / boundsInfo.numX))
                    )

                    glUniform1f(texProgPtr.tYScaleLocation, (2f / boundsInfo.numY))
                    glUniform1f(
                        texProgPtr.tYOffsetLocation,
                        (meshInfo.y - boundsInfo.y1) * (2f / boundsInfo.numY) - (1 - (2f / boundsInfo.numY))
                    )

                    if (needsA) {
                        newMX = meshInfo.x
                        var newHashA = meshInfo.hashCode
                        if (newMX >= powerTableI[meshInfo.z.toInt()]) {
                            newMX -= powerTableI[meshInfo.z.toInt()]
                            newHashA = "0:${newMX.toInt()}/${meshInfo.y.toInt()}/${meshInfo.z.toInt()}/"
                        }

                        hashString = null
                        val tempString = "${newHashA}${Timeline.timeStrings!![Timeline.currentPhaseA]}"
                        if (pr.ON) pr.p("ParticleRenderPass", pr.partPartial, "render() A is looking for: $tempString")
                        if (texHashMap[tempString] != null) {
                            glUniform1f(texProgPtr.xScaleLocation, 1f)
                            glUniform1f(texProgPtr.xOffsetLocation, 0f)
                            glUniform1f(texProgPtr.yOffsetLocation, 0f)
                            texProgPtr.updateTexture1Size(1f, 1f, 0f, 0f)
                            hashString = tempString
                            foundA = true
                        } else {
                            hashString = determineMegatexturePartial(meshInfo, texHashMap, Timeline.currentPhaseA, 1)
                            if (hashString != null) {
                                if (pr.ON) pr.p(
                                    "ParticleRenderPass",
                                    pr.partPartial,
                                    "render() scale1: $scale, nX: $newX  nY: $newY"
                                )
                                updateTextureSizes(meshInfo, scale, newX, newY, 1)
                                glUniform1f(texProgPtr.xScaleLocation, texProgPtr.xScale)
                                glUniform1f(texProgPtr.xOffsetLocation, texProgPtr.xOffset)
                                glUniform1f(texProgPtr.yOffsetLocation, texProgPtr.yOffset)
                                foundA = true
                            }
                        }
                    }
                    if (needsB && Timeline.currentPhaseB < Timeline.timeStrings.size) {
                        newMX = meshInfo.x
                        var newHashB = meshInfo.hashCode
                        if (newMX >= powerTableI[meshInfo.z.toInt()]) {
                            newMX -= powerTableI[meshInfo.z.toInt()]
                            newHashB = "0:${newMX.toInt()}/${meshInfo.y.toInt()}/${meshInfo.z.toInt()}/"
                        }

                        val tempStringB = "${newHashB}${Timeline.timeStrings!![Timeline.currentPhaseB]}"
                        //if(pr.ON) pr.p("ParticleRenderPass", pr.partPartial, "render() B is looking for: $tempString")
                        if (texHashMap[tempStringB] != null) {
                            glUniform1f(texProgPtr.xScale2Location, 1f)
                            glUniform1f(texProgPtr.xOffset2Location, 0f)
                            glUniform1f(texProgPtr.yOffset2Location, 0f)
                            texProgPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                            hashStringB = tempStringB
                            foundB = true
                        } else {
                            //if(pr.ON) pr.p("PRenderPass", pr.partPartial, "render() looking for partial!!!")
                            hashStringB = determineMegatexturePartial(meshInfo, texHashMap, Timeline.currentPhaseB, 2)
                            if (hashStringB != null) {
                                if (pr.ON) pr.p(
                                    "ParticleRenderPass",
                                    pr.partPartial,
                                    "render() scale2: $scale2, nX2: $newX2  nY2: $newY2"
                                )
                                updateTextureSizes(meshInfo, scale2, newX2, newY2, 2)
                                glUniform1f(texProgPtr.xScale2Location, texProgPtr.xScale2)
                                glUniform1f(texProgPtr.xOffset2Location, texProgPtr.xOffset2)
                                glUniform1f(texProgPtr.yOffset2Location, texProgPtr.yOffset2)
                                foundB = true
                            }
                        }
                    }
                    if (pr.ON) pr.p(
                        "ParticleRenderPass",
                        pr.partPartial,
                        "render() nA: $needsA, nB: $needsB, fA:$foundA, fB, $foundB, dM: ${Timeline.dataMeld}"
                    )

                    megaTexture.drawTilesToTexture(texHashMap[hashString], texHashMap[hashStringB])

                } //end tile for-each

                // end Draw unprocessed encoded tiles to megatexture -------------------------------------
                boundsInfo.needsUpdate = false

                GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
                texProgPtr.unbind()
                GLES31.glViewport(0, 0, camera.resX, camera.resY)
            }  // end if(enableTexture)

            //endregion Logic to draw to megatexture


            /** Speed needs to gradually be scaled by half when tiles are rendered at fractional zooms otherwise
            particles will speed up as their parent tiles are scaled up towards the next integer zoom level
            (e.g. 1.x > 2.0) **/
            fractionalZoomScale = 1 - (camera.zoom % 1) * 0.5
            speedScale = 2.0 / camera.dpiMult // Speed is always calculated based on a base DPI of 2

            //If the camera is moving or zooming, re-use the last speedCalc to avoid "rewinding"
            if (camera.moveState != Camera.MOVING) {
                // Final speed is a combination of the particle speed, the zoom scale, and the speed scale
                speedCalc = (paintStyle.particle.speed * fractionalZoomScale * speedScale).toFloat()
                // Reduce speed when zoomed out at lower zoom levels (below zoom 3)
                speedCalc *= kotlin.math.min(1.0.toFloat(), (0.3 + 0.5 * (camera.zoom / 3.0)).toFloat());
                speedCalc = fitSpeedToTile(speedCalc, camera)
            }

            //region setup particles

            // Scale speed based on screen fps, but clamp it to a min of 1.0
            fpsFactor = kotlin.math.min(1f, camera.refreshRateFactor)

            if (enableParticles) {
                progPtr = (currentMesh!!.program as RasterTileProgram)

                /*
                if (enableTestTiles) { // Show the underlying wind texture instead of drawing particles
                    GLES31.glVertexAttribPointer(
                        progPtr.positionHandle,
                        COORDS_PER_VERTEX,
                        GLES31.GL_FLOAT,
                        false,
                        VERTEX_STRIDE,
                        megaTexture.testGeometryBuffer
                    ).also { checkError("glVertexAttribPointer") }//vertexBuffer
                }
                */

                // Bind velocity texture
                GLES31.glActiveTexture(GLES31.GL_TEXTURE0) // Use texture unit 0 for compute
                GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, megaTexture.textureIds[0])
                //endregion setup particles

                //region compute particles
                progPtr.bindCompute() // glUseProgram(computeProgramId)
                // Set uniforms common to all compute dispatches
                glUniform1f(progPtr.speedMultLocationC, speedCalc * fpsFactor)
                glUniform1f(
                    GLES31.glGetUniformLocation(progPtr.computeProgramInt, "frameScaleC"),
                    fpsFactor
                )
                glUniform1f(
                    GLES31.glGetUniformLocation(progPtr.computeProgramInt, "randomSeedC"),
                    Random.nextFloat()
                )
                glUniform1f(progPtr.vectorOffsetLocationC, .5f /*paintStyle.vectorOffset*/)
                glUniform1f(progPtr.noDataLocationC, progPtr.noDataC)
                glUniform1i(progPtr.bufferItemsPerTileLocationC, totalParticles)
                GLES31.glUniform1i(
                    GLES31.glGetUniformLocation(progPtr.computeProgramInt, "uTexture"),
                    0
                ) //fixme: is this needed? Tell shader sampler uses unit 0


                val frameParticleBuffers = particleBuffersForCurrentMeshes()

                var currentTileIndex = 0

                fractionalZoom = camera.zoom % 1f
                scaleFactor = 4.0.pow(fractionalZoom)
                drawNum = particleDrawCountPerTile(totalParticles, camera.zoom, meshInfoList?.firstOrNull()?.z)
                glUniform1i(progPtr.drawNumLocationC, drawNum /*currentTileIndex*/)


                meshInfoList?.forEach { meshInfo ->
                    frameParticleBuffers[currentTileIndex].bindBuffersToCompute() // Implement this in ParticleSsboManager
                    // Set tile-specific uniforms for the compute shader
                    glUniform1i(progPtr.currentTileBindingPointLocationC, 0 /*currentTileIndex*/)

                    val txScale = 1f / (boundsInfo.numX)
                    val txOffset = (meshInfo.x - boundsInfo.x1) * (1f / boundsInfo.numX)
                    val tyScale = 1f / (boundsInfo.numY)
                    val tyOffset = (meshInfo.y - boundsInfo.y1) * (1.0f / boundsInfo.numY)

                    glUniform1f(progPtr.tx_scaleLocationC, txScale)
                    glUniform1f(progPtr.tx_offsetLocationC, txOffset)
                    glUniform1f(progPtr.ty_scaleLocationC, tyScale)
                    glUniform1f(progPtr.ty_offsetLocationC, tyOffset)

                    //val numGroupsX = (totalParticles + 128 - 1) / 128
                    val numGroupsX = (drawNum + 128 - 1) / 128
                    GLES31.glDispatchCompute(numGroupsX, 1, 1)
                    frameParticleBuffers[currentTileIndex].copyDataFromRenderSsboToVbo(1, drawNum)
                    currentTileIndex++
                }

                //positionBuffer.copyDataFromRenderSsboToVbo(min(meshInfoList!!.size, positionBuffer.numTiles))//.also{ checkError("Copy SSBO->VBO")}
                // end Determine positions with compute shader all at once in a loop

                //region DRAW TILES TO FB ========================================================================
                progPtr.bind()//.also { checkError(checkErrorUse) }// Add program to OpenGL ES environment
                // Bind the VBO containing particle data for rendering
                //GLES31.glDisableVertexAttribArray(progPtr.positionHandle).also { checkError("GLES31.GLES31.glDisableVertexAttribArray") }

                //GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, positionBuffer.renderVboId)

                //.also { checkError("GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, positionBuffer2.renderVboId)") }
                // Ensure attributes are enabled (if not using VAOs, or re-enable if needed)
                // Assuming attribute location 0 is already setup in setupVertexAttributes()
                GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, currentMesh!!.fbTex!!.framebufferIds[1])
                //.also { checkError("GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, currentMesh!!.fbTex!!.framebufferIds[1])") }
                //draw new particles to the write buffer
                //GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0 ) //test drawing directly to the screen
                GLES31.glClear(GLES31.GL_COLOR_BUFFER_BIT)
                //.also { checkError("GLES31.glClear(GLES31.GL_COLOR_BUFFER_BIT") }
                GLES31.glEnable(GLES31.GL_BLEND)
                //.also { checkError("GLES31.glEnable(GLES31.GL_BLEND)") }


                matrixToFloatArray(camera.projectionMatrix, projectionMatrixArray)
                projectionMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "projectionMatrix")
                //.also { checkError("glGetUniformLocation") }
                GLES31.glUniformMatrix4fv(projectionMatrixHandle, 1, false, projectionMatrixArray, 0)
                modelMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "modelViewMatrix")
                //.also { checkError("glGetUniformLocation") }
                matrixToFloatArray(camera.viewMatrix, cameraArray)

                //endregion compute particles

                //region draw particles to FB
                progPtr.setBufferItemsPerTile(totalParticles)//.also { checkError("glGetUniformLocation") }
                progPtr.updateSpeedMult(speedCalc * fpsFactor)//.also { checkError("glGetUniformLocation") }
                if (paintStyle.particle.size.width == paintStyle.particle.size.height) {
                    progPtr.setPointSize(paintStyle.particle.size.width.toFloat() * camera.dpiMult * 2f)
                } else {
                    progPtr.setPointSize(
                        paintStyle.particle.size.width.toFloat() * camera.dpiMult * 2f,
                        paintStyle.particle.size.height.toFloat() * camera.dpiMult * 2f
                    )
                }

                glUniform1f(progPtr.vectorOffsetLocation, .5f /*paintStyle.vectorOffset*/)
                progPtr.useOncePerFrame()

                GLES31.glActiveTexture(GLES31.GL_TEXTURE1)//.also { checkError(checkErrorString) } // fixme: crash here on vankyo
                GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, (progPtr as TriangleProgram).colorBandTexHandles[0])

                //calculate how many particles to draw, accounting for fractional zoom levels
                // Without adjustment, particles were ~4x more dense at zoom 2.0 than 1.99

                //println("ParticleRenderPass render()  drawNum: $drawNum / $totalParticles  scaleFactor: $scaleFactor")

                var i = 0
                GLES31.glEnableVertexAttribArray(2) // Re-enable just in case state changed, the 3 is from setup()

                meshInfoList?.forEach { meshInfo ->
                    setupVertexAttributes(frameParticleBuffers[i], 2)
                    GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, frameParticleBuffers[i].renderVboId)
                    glUniform1i(
                        progPtr.bindingPointLocation,
                        0 /*i*/
                    ) // Determine which section of the position buffer to use
                    Matrix.setIdentityM(matrixArray, 0); // initialize to identity matrix
                    Matrix.scaleM(matrixArray, 0, 512f, 512f, 1f)
                    Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
                    Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, matrixArray, 0) //works
                    GLES31.glUniformMatrix4fv(modelMatrixHandle, 1, false, modelViewMatrixArray, 0)

                    datelineAdjustment(meshInfo)

                    if (enableTextureFB) {  //normal

                        progPtr.use()
                        //if(pr.ON) pr.p("ParticleRenderPass", pr.particles, "enableTextureFB: $enableTextureFB ")
                        glUniform1f(progPtr.tXScaleLocation, 1f / (boundsInfo.numX))
                        glUniform1f(progPtr.tXOffsetLocation, (meshInfo.x - boundsInfo.x1) * (1f / boundsInfo.numX))
                        glUniform1f(progPtr.tYScaleLocation, 1f / (boundsInfo.numY))
                        glUniform1f(progPtr.tYOffsetLocation, (meshInfo.y - boundsInfo.y1) * (1.0f / boundsInfo.numY))

                        if (enableTestTiles) {
                            currentMesh?.drawParticleTileSquareNoUse(megaTexture.textureIds[0]) //draw test square
                        } else {
                            //if(pr.ON) pr.p("ParticleRenderPass", pr.compute, "before draw $i, drawNum: $drawNum")
                            currentMesh?.drawParticleTile(
                                megaTexture.textureIds[0],
                                drawNum,
                                false,
                                0 /*i*totalParticles*/
                            ) //draw particles
                        }
                    } else {
                        texHashMap[meshInfo.hashCode]?.let {
                            progPtr.updateTexture1Size(1f, 1f, 0f, 0f)
                            var hash2: String? = "${meshInfo.hashCode}${Timeline.timeStrings!![Timeline.currentPhaseB]}"

                            if (texHashMap[hash2] != null) { //found full version of both textures
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                                currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                            } else {
                                hash2 = determinePartial(meshInfo, texHashMap, Timeline.currentPhaseB, 2)
                                if (hash2 != null) {
                                    currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                } else {
                                    currentMesh?.draw(it)
                                }
                            }
                        } ?: run {
                            val meshString1 = determinePartial(meshInfo, texHashMap, Timeline.currentPhaseA, 1)
                            var meshString2: String? =
                                "${meshInfo.hashCode}${Timeline.timeStrings!![Timeline.currentPhaseB]}" // the exact tile
                            if (texHashMap[meshString2] == null) { // if exact tile not found, use partial
                                meshString2 = determinePartial(meshInfo, texHashMap, Timeline.currentPhaseB, 2)
                            } else {
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                            }

                            if (meshString1 != null) {
                                if (meshString2 != null) {
                                    currentMesh?.draw2Textures(texHashMap[meshString1]!!, texHashMap[meshString2]!!)
                                } else {
                                    currentMesh?.draw(texHashMap[meshString1]!!)
                                }
                                if (pr.ON) pr.p(
                                    "ParticleRenderer",
                                    pr.obs_play_rp,
                                    "found partial for ${meshInfo.hashCode}, using: $meshString1",
                                    1
                                )
                            } else {
                                if (pr.ON) pr.p(
                                    "ParticleRenderer",
                                    pr.obs_play_rp,
                                    "DID NOT FIND PARTIAL for ${meshInfo.hashCode}",
                                    2
                                )
                            }
                        }
                    } //end else !FBTEX
                    //GLES31.glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0) // Unbind
                    i++
                } //end tile for-each

                GLES31.glDisableVertexAttribArray(0) // Disable attribute
                GLES31.glDisableVertexAttribArray(2)
                GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0) // Unbind VBO
                //currentMesh!!.swapParticleBuffers()
                progPtr.unbind()
            }

            //endregion draw particles to FB

            //region DRAW FB TO SCREEN

            if (enableFB) {
                //if(pr.ON) pr.p("ParticleRenderPass", pr.i13, "render() enableFB")
                currentMesh = meshes!!.first()

                if (currentMesh!!.fbTex == null) {
                    currentMesh!!.fbTex = FramebufferTexture()

                    if (pr.ON) pr.p("ParticleRenderPass", pr.i13, "render() currentMesh!!.fbTex == null")
                }

                val sProgPtr: RasterTileProgram = (currentMesh!!.screenProgram as RasterTileProgram)
                sProgPtr.bind().also { checkError(checkErrorUse) }// Add program to OpenGL ES environment
                sProgPtr.useOncePerFrame()
                sProgPtr.use() //?
                //particle verts
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, sProgPtr.positionHandle).also { checkError("glBindBuffer") }
                GLES31.glVertexAttribPointer(
                    sProgPtr.positionHandle,
                    COORDS_PER_VERTEX,
                    GLES31.GL_FLOAT,
                    false,
                    VERTEX_STRIDE,
                    vertexBuffer
                )

                drawTrails =
                    (camera.moveState != Camera.MOVING && paintStyle.particle.trails && !Timeline.clearParticles)

                // Calculate and set trails fade
                val opacity = if (drawTrails) paintStyle.particle.trailsFade.toFloat() else paintStyle.opacity
                val opacityDelta = 1.0 - opacity
                val fadeCalc = 1.0 - opacityDelta * fpsFactor
                currentMesh?.drawFrameBufferQuad(drawTrails, paintStyle, fadeCalc.toFloat())

                GLES31.glDisable(GLES31.GL_BLEND)
                GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
                sProgPtr.unbind()

            }//end enableFB

            //endregion DRAW FB TO SCREEN

        } // end  if(meshes!=null&& meshes!!.isNotEmpty()){
    }
     */

    private fun determinePartial(
        meshInfo: MeshInfo,
        texHashMap: HashMap<String, Int>,
        currentPhase: Int,
        textureNumber: Int
    ): String? {
        scale = 1.0f //was .5f. Changed to fix low-res across the dateline.
        altDataZoom = floor(meshInfo.z  /*- 1*/).toInt()
        var partialHashString: String
        while (altDataZoom > -1) {
            if (pr.ON) pr.p("ParticleRenderer", pr.partial, "render() in the loop, altDataZoom:$altDataZoom")
            newX = (meshInfo.x * scale).toInt()
            newY = (meshInfo.y * scale).toInt()
            partialHashString = "0:${(altDataZoom)}/${newX}/${newY}/${Timeline.timeStrings[currentPhase]}"

            if (texHashMap[partialHashString] != null) {
                updateTextureSizes(meshInfo, scale, newX, newY, textureNumber)
                return partialHashString
            } else {
                altDataZoom--
            }
            scale *= .5f
        }
        return null
    }

    private fun determineMegatexturePartial(
        meshInfo: MeshInfo,
        texHashMap: HashMap<String, Int>,
        currentPhase: Int,
        currentPhaseString: String,
        textureNumber: Int
    ): String? {

        altDataZoom = (meshInfo.z /*- 1*/).toInt()

        if (textureNumber == 1) {
            scale = 1f
        } else {
            scale2 = 1f
        }

        var tHashString: String
        while (altDataZoom > -1) { //check lower and lower zoom levels until you find the low rez tile.

            if (textureNumber == 1) {
                newX = floor(meshInfo.x * scale).toInt() //was newMX...
                newY = floor(meshInfo.y * scale).toInt()

                numTiles = 2f.pow(altDataZoom).toInt()
                if (newX < 0) {
                    newX += numTiles
                } else if (newX >= numTiles) {
                    newX -= numTiles
                }
                //tHashString = "0:${(altDataZoom)}/${newX}/${newY}/${timeStringPtr[currentPhase]}"
                tHashString = "0:${(altDataZoom)}/${newX}/${newY}/$currentPhaseString"
                //if(pr.ON) pr.p("PRenderPass", pr.partPartial, "render() looking for partial  ${tHashString}")
                if (texHashMap[tHashString] != null) {
                    updateTextureSizes(meshInfo, scale, newX, newY, textureNumber)
                    if (pr.ON) pr.p("PRenderPass", pr.partPartial, "render() FOUND PARTIAL  $tHashString")
                    return tHashString
                } else {
                    altDataZoom--
                }
                scale *= .5f

            } else {

                newX2 = floor(meshInfo.x * scale2).toInt() //was newMX...
                newY2 = floor(meshInfo.y * scale2).toInt()

                numTiles = 2f.pow(altDataZoom).toInt()
                if (newX2 < 0) {
                    newX2 += numTiles
                } else if (newX2 >= numTiles) {
                    newX2 -= numTiles
                }
                //tHashString = "0:${(altDataZoom)}/${newX2}/${newY2}/${timeStringPtr[currentPhase]}"
                tHashString = "0:${(altDataZoom)}/${newX2}/${newY2}/$currentPhaseString"
                //if(pr.ON) pr.p("PRenderPass", pr.partPartial, "render() looking for partial  ${tHashString}")

                if (texHashMap[tHashString] != null) {
                    updateTextureSizes(meshInfo, scale2, newX2, newY2, textureNumber)
                    if (pr.ON) pr.p("PRenderPass", pr.partPartial, "render() FOUND PARTIAL  $tHashString")
                    return tHashString
                } else {
                    altDataZoom--
                }
                scale2 *= .5f
            }
        }
        return null
    }

    /** Used to calculate the scale value for the texture in the shader. Used for tile partial scaling **/
    override fun updateTextureSizes(mInfo: MeshInfo, scale: Float, nX: Int, nY: Int, textureNumber: Int) {
        if (scale >= 1f - 1e-5f) {
            if (textureNumber == 1) {
                texProgPtr.updateTexture1Size(1f, 1f, 0f, 0f)
            } else {
                texProgPtr.updateTexture2Size(1f, 1f, 0f, 0f)
            }
            return
        }
        val divisor = (1f / scale).toInt().coerceAtLeast(1)
        val maxOff = (1f - scale).coerceAtLeast(0f)
        val xOffs = ((mInfo.x - nX.toFloat() * divisor) / divisor.toFloat()).coerceIn(0f, maxOff)
        val yOffs = ((mInfo.y - nY.toFloat() * divisor) / divisor.toFloat()).coerceIn(0f, maxOff)
        if (textureNumber == 1) {
            texProgPtr.updateTexture1Size(scale, scale, xOffs, yOffs)
        } else {
            texProgPtr.updateTexture2Size(scale, scale, xOffs, yOffs)
        }
    }

    /** Same convention as [RenderPass]: Mapbox custom-layer native P/MV when present. */
    private fun fillProjectionAndViewFromMapboxOrCamera(camera: Camera): Boolean {
        val mapboxProj = CameraSync.mapboxProjectionMatrix
        val mapboxMv = CameraSync.mapboxModelViewMatrix
        val useNative =
            mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
        if (useNative) {
            System.arraycopy(mapboxProj, 0, projectionMatrixArray, 0, 16)
            System.arraycopy(mapboxMv, 0, cameraArray, 0, 16)
        } else {
            matrixToFloatArray(camera.projectionMatrix, projectionMatrixArray)
            matrixToFloatArray(camera.viewMatrix, cameraArray)
        }
        return useNative
    }

    private fun matrixToFloatArray(m: ProjectionMatrix, r: FloatArray): FloatArray { //reuse existing array
        r[0] = m.elements[0]; r[1] = m.elements[1]; r[2] = m.elements[2]; r[3] = m.elements[3]
        r[4] = m.elements[4]; r[5] = m.elements[5]; r[6] = m.elements[6]; r[7] = m.elements[7]
        r[8] = m.elements[8]; r[9] = m.elements[9]; r[10] = m.elements[10]; r[11] = m.elements[11]
        r[12] = m.elements[12]; r[13] = m.elements[13]; r[14] = m.elements[14]; r[15] = m.elements[15]
        return r
    }

    private fun checkError(cmd: String? = null) {
        if (MapsGLDebug.enabled) {
            when (val error = GLES31.glGetError()) {
                GLES31.GL_NO_ERROR -> {/*println("TAG $cmd -> no error")*/
                }

                GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM: ${error}")
                GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                else -> throw RuntimeException("$cmd -> error in gl: $error")
            }
        }
    }

    fun setupCamera(camera: Camera) {
        if (currentMesh!!.fbTex == null) {
            // Set up framebuffer if it doesn't exist
            Mesh.FRAMEBUFFER_W = camera.resX
            Mesh.FRAMEBUFFER_H = camera.resY
            currentMesh!!.fbTex = FramebufferTexture()
            Mesh.FRAMEBUFFER_W = camera.resX
            Mesh.FRAMEBUFFER_H = camera.resY
        } else if (camera.needsRotationHandled) {
            // Rebuild framebuffer if rotation has changed
            Mesh.FRAMEBUFFER_W = camera.resX
            Mesh.FRAMEBUFFER_H = camera.resY
            currentMesh!!.fbTex!!.cleanup()
            currentMesh!!.fbTex!!.createFramebuffers()
            camera.needsRotationHandled = false
        }
    }

    private fun getParticleTilePool(): ParticleTileBufferPool {
        if (particleTilePool == null) {
            particleTilePool = ParticleTileBufferPool(PARTICLE_POOL_MAX_SLOTS, totalParticles)
        }
        return particleTilePool!!
    }

    private fun acquireStorageSlot(key: String): Int {
        particleSlotByTileKey[key]?.let { return it }
        val slot = freeParticleStorageSlots.pollFirst()
            ?: (0 until PARTICLE_POOL_MAX_SLOTS).firstOrNull { idx ->
                idx !in particleSlotByTileKey.values
            } ?: run {
                val e = particleSlotByTileKey.entries.first()
                particleSlotByTileKey.remove(e.key)
                staticParticleUploadedKeys.remove(e.key)
                e.value
            }
        particleSlotByTileKey[key] = slot
        return slot
    }

    /**
     * Uploads per-frame tile UV offsets + storage slot indices, and static spawn data for new tile keys.
     * @return number of visible tiles (mesh list size).
     */
    private fun syncParticleTileGpuFrame(): Int {
        val list = meshInfoList ?: return 0
        val keysInView = list.map { canonicalParticleTileKey(it) }.toSet()
        for (k in particleSlotByTileKey.keys.toList()) {
            if (k !in keysInView) {
                freeParticleStorageSlots.add(particleSlotByTileKey.remove(k)!!)
                staticParticleUploadedKeys.remove(k)
            }
        }
        val pool = getParticleTilePool()
        val invX = 1f / boundsInfo.numX
        val invY = 1f / boundsInfo.numY
        var n = 0
        for (mesh in list) {
            val key = canonicalParticleTileKey(mesh)
            val slot = acquireStorageSlot(key)
            storageSlotFrameScratch[n] = slot
            txParticleFrameScratch[n] = (mesh.x - boundsInfo.x1) * invX
            tyParticleFrameScratch[n] = (mesh.y - boundsInfo.y1) * invY
            if (key !in staticParticleUploadedKeys) {
                particles.particleVertexBuffer.position(0)
                pool.uploadStaticSlot(slot, particles.particleVertexBuffer, totalParticles * 2)
                staticParticleUploadedKeys.add(key)
            }
            n++
        }
        if (n > 0) {
            pool.uploadFrameTileUv(n, txParticleFrameScratch, tyParticleFrameScratch)
            pool.uploadFrameTileSlots(n, storageSlotFrameScratch)
        }
        return n
    }

    /** Same z/x/y identity as [datelineAdjustment] after wrapping x, without mutating [meshInfo]. */
    private fun canonicalParticleTileKey(meshInfo: MeshInfo): String {
        val zi = meshInfo.z.toInt()
        if (zi !in powerTableI.indices) return meshInfo.hashCode
        val n = powerTableI[zi]
        if (n <= 0) return meshInfo.hashCode
        var x = meshInfo.x
        while (x < 0f) x += n
        while (x >= n) x -= n
        return "0:$zi/${x.toInt()}/${meshInfo.y.toInt()}"
    }

    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private fun datelineAdjustment(meshInfo: MeshInfo) {
        if (pr.ON) pr.p(
            "ParticleRenderPass",
            pr.hashmapLong,
            "datelineAdjustment(), hashString: ${hashString}    meshInfo.hashcode:, ${meshInfo.hashCode}  "
        )
        val n = powerTableI[meshInfo.z.toInt()]
        if (n <= 0) return
        var x = meshInfo.x
        while (x < 0f) x += n
        while (x >= n) x -= n
        meshInfo.x = x
        meshInfo.hashCode = "0:${meshInfo.z.toInt()}/${meshInfo.x.toInt()}/${meshInfo.y.toInt()}"
        if (pr.ON) pr.p(
            "ParticleRenderPass",
            pr.hashmapLong,
            "datelineAdjustment(), at the end returning meshInfo.hashCode: ${meshInfo.hashCode}  "
        )
    }

    fun cleanupSSBO() {
        particleTilePool?.deleteGpu()
        particleTilePool = null
        particleSlotByTileKey.clear()
        freeParticleStorageSlots.clear()
        staticParticleUploadedKeys.clear()
        if (pr.ON) pr.p("ParticleRenderpass", pr.i13, "cleanupSSBO")
    }

    private val powerTableI = intArrayOf(
        1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048,
        4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576, 2097152, 4194304
    )
}

/** @suppress */
class Particle {
    val x: Float = Random.nextFloat()
    val y: Float = Random.nextFloat()
}

/**
 * Particles to draw in each particle tile this frame.
 *
 * The render count runs from a quarter of the per-tile count at an integer zoom to all of it just
 * below the next, as MapsGL JS does. JS sizes that count for tiles drawn 1:1 with map tiles. Here the
 * particle tiles are the encoded layer's data tiles, a zoom finer than the map at the default sample
 * quality, so each covers a quarter of the area and the full count per tile put about four times
 * JS's particles on screen (XMAPSGLSDK-241 QA item 8). The count is divided by the area ratio so a
 * particle tile carries the share of a map tile it covers.
 */
internal fun particleDrawCountPerTile(perTile: Int, cameraZoom: Double, tileZoom: Float?): Int {
    val fractionalZoom = cameraZoom % 1.0
    var count = perTile * 4.0.pow(fractionalZoom) * 0.25
    if (tileZoom != null) {
        val finer = floor(tileZoom.toDouble()) - floor(cameraZoom)
        if (finer > 0) count /= 4.0.pow(finer)
    }
    return count.toInt()
}
