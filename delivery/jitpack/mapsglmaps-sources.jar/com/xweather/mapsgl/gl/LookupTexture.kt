package com.xweather.mapsgl.gl

import android.opengl.GLES31
import com.xweather.mapsgl.gl.extensions.pr
import java.nio.ByteBuffer
import java.nio.ByteOrder

class LookupTexture {

    var framebufferId = IntArray(1) { 0 } // Initialize with 0
    var textureIds = IntArray(1) { 0 }    // Initialize with 0
    private var currentWidth: Int = -1
    private var currentHeight: Int = -1

    private val vertexArray = UnitQuad2DGeometry.genQuad1x1()
    private val textureArray = UnitQuad2DGeometry.genTexCoords1Quad()
    val vertexBuffer =
        ByteBuffer.allocateDirect(vertexArray.size * 4).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }

    val textureCoordinatesBuffer = ByteBuffer.allocateDirect(textureArray.size * 4).run {
        order(ByteOrder.nativeOrder())
        asFloatBuffer()
    }


    private val pboIds = IntArray(2) // Using two PBOs for ping-pong
    private var pboIndex = 0        // To alternate between PBOs
    private val pboSize = 1 * 1 * 4 // Bytes for 1 RGBA pixel (or your desired readback size)
    private val pboBuffers = arrayOfNulls<ByteBuffer>(2) // To store mapped ByteBuffers
    var pboNeedsInit = true

    /*
    val testGeometryBuffer: FloatBuffer = ByteBuffer.allocateDirect(4 * 2 * 4).run {
        order(ByteOrder.nativeOrder())
        asFloatBuffer()
    }
    */
    init {
        vertexBuffer.apply {
            clear()
            put(vertexArray)
            rewind()
        }

        textureCoordinatesBuffer.apply {
            clear()
            put(textureArray)
            rewind()
        }

    }


    fun setupPBOs() {
        GLES31.glGenBuffers(2, pboIds, 0)
        for (i in 0..1) {
            GLES31.glBindBuffer(GLES31.GL_PIXEL_PACK_BUFFER, pboIds[i])
            GLES31.glBufferData(
                GLES31.GL_PIXEL_PACK_BUFFER,
                pboSize,
                null, // Initialize with null data; we're reading into it
                GLES31.GL_STREAM_READ // Hint: Data will be read by CPU once, modified by GPU once
            )
        }
        GLES31.glBindBuffer(GLES31.GL_PIXEL_PACK_BUFFER, 0) // Unbind
        pboNeedsInit = false
    }


    fun ensureFramebuffer(width: Int, height: Int): Boolean {
        if (width <= 0 || height <= 0) {
            println("LookupTexture: Invalid dimensions for framebuffer ($width, $height)")
            return false
        }

        // Check if recreation is needed (different size or not yet created)
        if (framebufferId[0] != 0 && textureIds[0] != 0 && currentWidth == width && currentHeight == height) {
            // Framebuffer already exists with the correct dimensions, no need to recreate.
            return true // Or check status again if paranoid, but generally not needed if it was complete before
        }

        println("LookupTexture: Creating/Recreating framebuffer to ${width}x${height}. Previous: ${currentWidth}x${currentHeight}")

        // --- Cleanup old resources if they exist ---
        if (framebufferId[0] != 0) {
            GLES31.glDeleteFramebuffers(1, framebufferId, 0)
            framebufferId[0] = 0
        }
        if (textureIds[0] != 0) {
            GLES31.glDeleteTextures(1, textureIds, 0)
            textureIds[0] = 0
        }

        // --- Generate new framebuffer and texture ---
        GLES31.glGenFramebuffers(1, framebufferId, 0)
        if (framebufferId[0] == 0) {
            println("LookupTexture: Failed to generate framebuffer ID.")
            return false
        }

        GLES31.glGenTextures(1, textureIds, 0)
        if (textureIds[0] == 0) {
            println("LookupTexture: Failed to generate texture ID.")
            GLES31.glDeleteFramebuffers(1, framebufferId, 0) // Clean up FBO if texture fails
            framebufferId[0] = 0
            return false
        }

        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureIds[0])
        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D, 0, GLES31.GL_RGBA8, // Consider GL_RGBA8 for standard 8-bit color
            width, height,
            0, GLES31.GL_RGBA, GLES31.GL_UNSIGNED_BYTE, null
        )
        // Check for GL errors after glTexImage2D if issues occur

        GLES31.glTexParameteri(
            GLES31.GL_TEXTURE_2D,
            GLES31.GL_TEXTURE_MIN_FILTER,
            GLES31.GL_NEAREST
        ) // NEAREST might be better for lookup textures
        GLES31.glTexParameteri(
            GLES31.GL_TEXTURE_2D,
            GLES31.GL_TEXTURE_MAG_FILTER,
            GLES31.GL_NEAREST
        ) // depending on use case
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0) // Unbind texture

        // --- Attach texture to FBO ---
        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, framebufferId[0])
        GLES31.glFramebufferTexture2D(
            GLES31.GL_FRAMEBUFFER,
            GLES31.GL_COLOR_ATTACHMENT0,
            GLES31.GL_TEXTURE_2D,
            textureIds[0],
            0
        )

        // --- Check FBO status ---
        val status = GLES31.glCheckFramebufferStatus(GLES31.GL_FRAMEBUFFER)
        if (status != GLES31.GL_FRAMEBUFFER_COMPLETE) {
            println("LookupTexture createFrameBuffer() Framebuffer is not complete. Status: $status. Error: ${GLES31.glGetError()}")
            // Cleanup incomplete FBO
            GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)
            GLES31.glDeleteTextures(1, textureIds, 0)
            textureIds[0] = 0
            GLES31.glDeleteFramebuffers(1, framebufferId, 0)
            framebufferId[0] = 0
            currentWidth = -1 // Reset dimensions as creation failed
            currentHeight = -1
            return false
        }

        println("LookupTexture: Framebuffer successfully created/configured.")
        currentWidth = width
        currentHeight = height

        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0) // Unbind FBO by default
        return true
    }

    // Call this in your onSurfaceCreated or when the GL context might have been lost
    fun invalidateFramebuffer() {
        currentWidth = -1
        currentHeight = -1
        // The actual deletion will happen in ensureFramebuffer if needed,
        // or you can explicitly delete here if you want to force it.
        // Forcing deletion here means ensureFramebuffer will always recreate on next call.
        if (framebufferId[0] != 0) {
            GLES31.glDeleteFramebuffers(1, framebufferId, 0)
            framebufferId[0] = 0
        }
        if (textureIds[0] != 0) {
            GLES31.glDeleteTextures(1, textureIds, 0)
            textureIds[0] = 0
        }
    }

    fun createFramebuffer(width: Int, height: Int): Boolean {
        // Check if we need to delete the old framebuffer and texture.

        if (framebufferId[0] != 0) {
            GLES31.glDeleteFramebuffers(1, framebufferId, 0)
            framebufferId[0] = 0 // Reset the framebuffer ID.
        }

        if (textureIds[0] != 0) {
            GLES31.glDeleteTextures(1, textureIds, 0)
            textureIds[0] = 0 // Reset the texture ID.
        }

        // Generate new framebuffer and texture.
        GLES31.glGenFramebuffers(1, framebufferId, 0)
        GLES31.glGenTextures(1, textureIds, 0)


        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureIds[0])

        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D, 0, GLES31.GL_RGBA,
            width, height,
            0, GLES31.GL_RGBA, GLES31.GL_UNSIGNED_BYTE, null
        )

        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)

        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, framebufferId[0])
        GLES31.glFramebufferTexture2D(
            GLES31.GL_FRAMEBUFFER,
            GLES31.GL_COLOR_ATTACHMENT0,
            GLES31.GL_TEXTURE_2D,
            textureIds[0],
            0
        )

        if (GLES31.glCheckFramebufferStatus(GLES31.GL_FRAMEBUFFER) != GLES31.GL_FRAMEBUFFER_COMPLETE) {
            //throw RuntimeException("Framebuffer 0 is not complete")
            println("MegaTexture createFrameBuffer() Framebuffer 0 is not complete")
            return false
        }

        GLES31.glBindFramebuffer(GLES31.GL_FRAMEBUFFER, 0)


        return true
    }

    fun drawTileToTexture(texUnit: Int) { //draw a tile to framebuffer
        GLES31.glDisable(GLES31.GL_BLEND)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit)
        GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun drawTilesToTexture(texUnit1: Int?, texUnit2: Int? = null) { //draw a tile to framebuffer
        GLES31.glDisable(GLES31.GL_BLEND)

        if (texUnit1 != null) {
            GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit1)
            //GLES31.glActiveTexture(GLES31.GL_TEXTURE1)
        }
        if (texUnit2 != null) {
            GLES31.glActiveTexture(GLES31.GL_TEXTURE4)
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, texUnit2)
        }

        GLES31.glDrawArrays(GLES31.GL_TRIANGLE_STRIP, 0, 4)
    }

    fun cleanup() {
        if (pr.ON) pr.p("MegaTexture", pr.i13, "cleanup() called.")

        // Delete the framebuffer if it exists
        if (framebufferId[0] != 0) {
            GLES31.glDeleteFramebuffers(1, framebufferId, 0)
            if (pr.ON) pr.p("MegaTexture", pr.i13, "Deleted framebuffer ID: ${framebufferId[0]}")
            framebufferId[0] = 0 // Reset the ID
        } else {
            if (pr.ON) pr.p("MegaTexture", pr.i13, "Framebuffer ID was already 0.")
        }

        // Delete the texture if it exists
        if (textureIds[0] != 0) {
            GLES31.glDeleteTextures(1, textureIds, 0)
            if (pr.ON) pr.p("MegaTexture", pr.i13, "Deleted texture ID: ${textureIds[0]}")
            textureIds[0] = 0 // Reset the ID
        } else {
            if (pr.ON) pr.p("MegaTexture", pr.i13, "Texture ID was already 0.")
        }

        // Note: The NIO buffers (vertexBuffer, textureCoordinatesBuffer) are managed by the JVM's
        // garbage collector for their direct memory. You don't explicitly "delete" them in OpenGL terms.
        // They will be garbage collected when the MegaTexture instance itself is no longer referenced
        // and garbage collected.
    }


}

