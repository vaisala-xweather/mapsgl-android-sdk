package com.xweather.mapsgl.gl

interface ResourceOptions {
    val name: String
    // handle?: Type
}

open class Resource {

    var id = 1
    var name = ""
    // var handle = 0

    var _handle: Int = 0
    val handle: Int
        get() = _handle

    val _resources: MutableSet<Int> = mutableSetOf()

    protected fun incrementResourceCount() {
        if (!_resources.contains(this.id)) {
            _resources.add(this.id)
        }
    }

    protected fun decrementResourceCount() {
        _resources.remove(this.id)
    }
}