package com.xweather.mapsgl.gl;

import android.content.Context;
import android.opengl.GLES31;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ShaderUtils {

    public static String readRawTextFileFromAssets(Context context, String filename)
            throws IOException {
        try (InputStream inputStream = context.getAssets().open(filename);
             BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
            return sb.toString();
        }
    }

    public static int loadGLShader(String tag, String shaderCode, int type) {
        int shader = GLES31.glCreateShader(type);
        GLES31.glShaderSource(shader, shaderCode);
        GLES31.glCompileShader(shader);

        // Get the compilation status.
        final int[] compileStatus = new int[1];
        GLES31.glGetShaderiv(shader, GLES31.GL_COMPILE_STATUS, compileStatus, 0);

        // If the compilation failed, delete the shader.
        if (compileStatus[0] == 0) {
            // Read the driver's reason before deleting the shader - the info log dies with it.
            // This message is the only account of the failure that reaches a crash report or an
            // error callback, so it carries the log rather than logcat alone.
            final String infoLog = GLES31.glGetShaderInfoLog(shader);
            Log.e(tag, "Error compiling shader: " + infoLog);
            GLES31.glDeleteShader(shader);
            throw new RuntimeException(describeShaderFailure(tag, type, infoLog));
        }

        if (shader == 0) {
            throw new RuntimeException(
                    describeShaderFailure(tag, type, "glCreateShader returned 0"));
        }

        return shader;
    }

    private static String describeShaderFailure(String tag, int type, String infoLog) {
        final String reason = (infoLog == null || infoLog.trim().isEmpty())
                ? "driver supplied no info log"
                : infoLog.trim();
        return "Error creating " + shaderTypeName(type) + " shader in " + tag + ": " + reason;
    }

    private static String shaderTypeName(int type) {
        switch (type) {
            case GLES31.GL_VERTEX_SHADER:
                return "vertex";
            case GLES31.GL_FRAGMENT_SHADER:
                return "fragment";
            case GLES31.GL_COMPUTE_SHADER:
                return "compute";
            default:
                return "type " + type;
        }
    }

    public static void checkGLError(String tag, String label) {
        int lastError = GLES31.GL_NO_ERROR;
        // Drain the queue of all errors.
        int error;
        while ((error = GLES31.glGetError()) != GLES31.GL_NO_ERROR) {
            Log.e(tag, label + ": glError " + error);
            lastError = error;
        }
        if (lastError != GLES31.GL_NO_ERROR) {
            throw new RuntimeException(label + ": glError " + lastError);
        }
    }
}
