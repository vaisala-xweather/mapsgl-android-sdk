package com.xweather.mapsgl.gl.programs

import com.xweather.mapsgl.gl.ResourceOptions
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute
import com.xweather.mapsgl.gl.worldObjects.IMesh
import com.xweather.mapsgl.gl.worldObjects.cameras.ICamera

interface UniformInfo {
    val name: String?
    val type: Int?

    val value: Any?
    val isStruct: Boolean
    val isStructArray: Boolean
    val structIndex: Number?
    val structProperty: String?
}

interface ProgramOptions : ResourceOptions {
    val uniforms: HashMap<String, Any>
    val transparent: Boolean;
}

/**
 *  Program.kt
 *
 * Holds vertex and fragment shaders and for Mesh
 *  @author Jason Suto
 * */
abstract class Program(var vertexShader: Int?, open var fragmentShader: Int?, var computeShader: Int?) {
    val uniforms: HashMap<String, Any> = HashMap()

    private val _uniforms = HashMap<String, UniformInfo>()

    open var handle: Int? = null

    var texUnit = -1

    abstract fun setupShaderInputs(
        map: HashMap<AttributeKey, IBufferAttribute<*>>,
        iResolution: IntArray,
        iChannels: IntArray,
        iChannelResolutions: Array<IntArray>
    )

    abstract fun setUniform(name: String, value: Any)

    abstract fun setupModelViewProjectMatrix(camera: ICamera, mesh: IMesh)

    /** Called from Mesh.draw().
     *
     *  To be used to set up textures
     * */
    open fun use() {
        texUnit = -1
    }
}