package com.xweather.mapsgl.gl.programs

import android.content.Context
import android.opengl.GLES31
import android.opengl.GLES31.glUniform1f
import android.opengl.GLES31.glUniform1i
import com.xweather.mapsgl.gl.ShaderUtils
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.renderers.ProgramType
open class TriangleProgram(
    context: Context,
    vertPath: String,
    fragPath: String,
    expression: String,
    val type: Int,
    compPath: String? = null
) :
    AbstractProgram(0, 0, 0)/*, Program*/ {
    val TAG = "TriangleProgram"
    final override var handle: Int? = null
    val defineList: MutableList<String> = mutableListOf()
    var programInt = 0
    var computeProgramInt = 0
    var positionHandle = 0

    //var colorHandle = 0
    var texPositionHandle = 0
    var textureNextHandle = 0

    var alphaUniformLocation = 0
    var noDataLocation = 0
    var multLocation = 0
    var addLocation = 0
    var colorBandUniformLocation = IntArray(3) { 0 }
    var uTranslationHandle = 0
    var uScaleHandle = 0
    var colorBandTexHandles: IntArray = IntArray(3) { 0 }
    var nextTextureUniformLocation = 0
    var TrailTexHandle = 0
    var opacityLocation = 0
    var blurRadiusLocation = 0
    var blurSizeLocation = 0
    var trailTexUniformLocation = 0
    var speedMultLocation = 0
    var speedMultLocationC = 0
    var blurSize = 0f
    var blurRadius = 0f
    var modeLocation = 0
    var seedLocation = 0
    var xScaleLocation = 0
    var xScale2Location = 0
    var tileTestLocation = 0
    var yScaleLocation = 0
    private var yScale2Location = 0
    var tXScaleLocation = 0
    var tYScaleLocation = 0
    var xOffsetLocation = 0
    var yOffsetLocation = 0
    var xOffset2Location = 0
    var yOffset2Location = 0
    var dataMeldLocation = 0
    var tYOffsetLocation = 0
    var tXOffsetLocation = 0
    private var bufferItemsPerTileLocation = 0
    var frameCounterLocation = 0
    var outputRangeMinLocation = 0
    var outputRangeMaxLocation = 0
    var frameRateMultLocation = 0
    var drawRangeMinLocation = 0
    var drawRangeMaxLocation = 0
    var dataRangeMinLocation = 0
    var dataRangeMaxLocation = 0
    var sampleDataMinLocation = 0
    var sampleDataMaxLocation = 0
    var interpolationLocation = 0
    var alphaLocation = 0
    var tileModeLocation = 0
    var fbPremultLocation = 0
    var numStepLocation = 0
    var timeLocation = 0
    var userParticleWidthLocation = 0
    var userParticleHeightLocation = 0
    var vectorOffsetLocation = 0
    var timeStepLocation = 0
    var channelLocation1 = 0
    var channelLocation2 = 0
    var colorRangeFactorLocation = 0
    var colorSampleOffsetLocation = 0
    var fadeMultLocation = 0
    var bindingPointLocation = 0
    var totalParticleCountLocationC = 0
    var bufferItemsPerTileLocationC = 0
    var drawNumLocationC = 0
    var vectorOffsetLocationC = 0
    var currentTileBindingPointLocationC = 0
    var tx_scaleLocationC = 0 // These are uses to draw from a section of the megatexture
    var tx_offsetLocationC = 0
    var ty_scaleLocationC = 0
    var ty_offsetLocationC = 0
    var smoothingLocation = 0

    var xScale = 1f
    var yScale = 1f
    var tXScale = 1f
    var tYScale = 1f
    var xOffset = 0f
    var yOffset = 0f
    var xScale2 = 1f
    var yScale2 = 1f
    var xOffset2 = 0f
    var yOffset2 = 0f
    var interpolation = 2 //2
    var mode = 0
    var smoothing = 1f
    private var outputRangeMin = 0f
    private var trailTexHandle = 0f
    private var outputRangeMax = 1f
    private var drawRangeMin = 0f
    private var drawRangeMax = 1f
    private var dataRangeMin = 0f
    private var noData = 0f
    private var dataRangeMax = 1f
    private var sampleDataRangeMin = 0f
    private var sampleDataRangeMax = 1f
    private var channel1 = 0
    private var channel2 = 0
    private var colorRangeFactor = 1f
    private var colorSampleOffset = 0f
    private var time = 0f
    private var fadeMult = 1f
    private var speedMult = 0f
    private var speedMultC = 0f
    private var alpha = 1f
    private var frameRateMult = 1f
    var add = 0f
    var mult = 0f

    var singlePointModeLoc = 0
    var getXLoc = 0
    var getYLoc = 0
    var useRawColorsLocation = 0

    // Contour uniforms
    private var valueIntervalLocation = 0
    private var majorValueIntervalLocation = 0
    private var widthLocation = 0
    private var majorWidthLocation = 0
    private var valueInterval = 0f
    private var majorValueInterval = 0f
    private var width = 0f
    private var majorWidth = 0f


    init {
        val vertexShaderSource = ShaderUtils.readRawTextFileFromAssets(context, vertPath)
        vertexShader = ShaderUtils.loadGLShader(TAG, vertexShaderSource, GLES31.GL_VERTEX_SHADER)

        if (vertexShader == 0) {
            throw java.lang.Exception("$TAG Failed load VertexShader")
        }

        val colorLookup = ShaderUtils.readRawTextFileFromAssets(context, "shaders/chunks/color_lookup.glsl")
        val fragmentShaderSource = ShaderUtils.readRawTextFileFromAssets(context, fragPath)
        var shaderString = fragmentShaderSource.replace("#include <color_lookup>", colorLookup)

        if (expression != "raster") {

            if (!expression.equals("NUMBER")) {
                //println("TriangleProgram #define $expression")
                defineList.add("#define $expression")
                //println("$TAG init define: #define $expression")
            }
            defineList.add("#define COLOR_LOOKUP")

            /*
            //#define NO_DATA
            //#define EXPRESSION_VECTOR
            //#define EXPRESSION_ANGLE
            //#define EXPRESSION_SUM
            //#define EXPRESSION_DIFF
            //#define DEBUG_EDGE
            * */

        } else {
            defineList.add("#define RASTER_IMAGE") //TODO: Bring naming in line with JS version
        }

        for (define in defineList) { //todo: Use a static stringbuilder for all shader concatenation

            //println("$TAG DEFINELIST: $define------------------------------------------------------")
            //shaderString = define + "\n" + shaderString

            val firstNewlineIndex = shaderString.indexOf('\n')

            if (firstNewlineIndex != -1) {
                // Extract the first line (including the newline character at the end)
                val firstLine = shaderString.substring(0, firstNewlineIndex + 1)
                // Extract the rest of the shader content
                val restOfString = shaderString.substring(firstNewlineIndex + 1)

                // Construct the new string
                shaderString = """
                ${(firstLine + define)}
                $restOfString
                """.trimIndent()
            } else { //shader string had no newline. Likely impossible
                shaderString = """
                $shaderString
                $define
                """.trimIndent()
            }

        }

        fragmentShader = ShaderUtils.loadGLShader(TAG, shaderString, GLES31.GL_FRAGMENT_SHADER)
        if (fragmentShader == 0) {
            throw java.lang.Exception("$TAG Failed load fragmentShader")
        }

        createHandle()

        handle?.let { hd ->
            vertexShader?.let { GLES31.glAttachShader(hd, it) }
            fragmentShader?.let { GLES31.glAttachShader(hd, it) }
            GLES31.glLinkProgram(hd)
        }

        programInt = GLES31.glCreateProgram().also {
            GLES31.glAttachShader(it, vertexShader!!)// add the vertex shader to program
            GLES31.glAttachShader(it, fragmentShader!!) // add the fragment shader to program
            if (computeShader != null) {
            }
            GLES31.glLinkProgram(it)// creates OpenGL ES program executables

            val linkStatus = IntArray(1)
            GLES31.glGetProgramiv(it, GLES31.GL_LINK_STATUS, linkStatus, 0)
            checkError("After glGetProgramiv LINK_STATUS") // Check if glGetProgramiv itself failed

            if (linkStatus[0] == GLES31.GL_FALSE) {
                // Link failed! Get the error log.
                val infoLog = GLES31.glGetProgramInfoLog(it)
                println("ShaderLinkError | $TAG | Failed to link program $it: $infoLog")
                // !!! CRITICAL: Handle the failure !!!
                // Do NOT store or use this programId.
                GLES31.glDeleteProgram(it) // Clean up the failed program object
                // Maybe throw an exception, return null/0, or set a flag indicating failure.
                // Example: throw RuntimeException("Failed to link shader program: $infoLog")
            } else {
                // Link successful
                //println("ShaderLinkInfo | $TAG | Successfully linked program $it")
            }
        }

        if (compPath != null) {
            //if(pr.ON) pr.p(TAG, pr.newCompute, "init{} creating compute shader")
            val compShaderSource = ShaderUtils.readRawTextFileFromAssets(context, compPath)
            //println("$TAG, compute source: $compShaderSource ")
            computeShader = ShaderUtils.loadGLShader(TAG, compShaderSource, GLES31.GL_COMPUTE_SHADER)
            if (computeShader == 0) {
                throw java.lang.Exception("$TAG | Failed load ComputeShader")
            }

            computeProgramInt = GLES31.glCreateProgram()

            if (computeShader != null) {
                GLES31.glAttachShader(computeProgramInt, computeShader!!)
                GLES31.glLinkProgram(computeProgramInt)
            }

            val linkStatus = IntArray(1)
            GLES31.glGetProgramiv(computeProgramInt, GLES31.GL_LINK_STATUS, linkStatus, 0)
            checkError("After glGetProgramiv compute LINK_STATUS") // Check if glGetProgramiv itself failed

            if (linkStatus[0] == GLES31.GL_FALSE) {
                val infoLog = GLES31.glGetProgramInfoLog(computeProgramInt)
                println("ShaderLinkError | $TAG | Failed to link compute program $computeProgramInt: $infoLog")
                GLES31.glDeleteProgram(computeProgramInt) // Clean up the failed program object
            } else {
                //println("ShaderLinkInfo | $TAG | Successfully linked compute program $computeProgramInt")
            }
        }

        //region locations and handles
        opacityLocation = GLES31.glGetUniformLocation(programInt, "opacity")
        blurRadiusLocation = GLES31.glGetUniformLocation(programInt, "blur_radius")
        blurSizeLocation = GLES31.glGetUniformLocation(programInt, "blur_size")
        alphaUniformLocation = GLES31.glGetUniformLocation(programInt, "u_Alpha");
        colorBandUniformLocation[0] = GLES31.glGetUniformLocation(programInt, "colorScale")
        colorBandUniformLocation[1] = GLES31.glGetUniformLocation(programInt, "colorScale1")
        colorBandUniformLocation[2] = GLES31.glGetUniformLocation(programInt, "colorScale2")
        nextTextureUniformLocation = GLES31.glGetUniformLocation(programInt, "dataTextureNext")
        noDataLocation = GLES31.glGetUniformLocation(programInt, "noData")
        xOffsetLocation = GLES31.glGetUniformLocation(programInt, "x_offset")
        yOffsetLocation = GLES31.glGetUniformLocation(programInt, "y_offset")
        xScaleLocation = GLES31.glGetUniformLocation(programInt, "x_scale");
        yScaleLocation = GLES31.glGetUniformLocation(programInt, "y_scale");
        xOffset2Location = GLES31.glGetUniformLocation(programInt, "x_offset2")
        yOffset2Location = GLES31.glGetUniformLocation(programInt, "y_offset2")
        xScale2Location = GLES31.glGetUniformLocation(programInt, "x_scale2");
        yScale2Location = GLES31.glGetUniformLocation(programInt, "y_scale2");
        tXOffsetLocation = GLES31.glGetUniformLocation(programInt, "tx_offset")
        tYOffsetLocation = GLES31.glGetUniformLocation(programInt, "ty_offset")
        frameCounterLocation = GLES31.glGetUniformLocation(programInt, "frameCounter");
        frameRateMultLocation = GLES31.glGetUniformLocation(programInt, "frameRateMult");
        xScaleLocation = GLES31.glGetUniformLocation(programInt, "x_scale");
        yScaleLocation = GLES31.glGetUniformLocation(programInt, "y_scale");
        tXScaleLocation = GLES31.glGetUniformLocation(programInt, "tx_scale");
        tYScaleLocation = GLES31.glGetUniformLocation(programInt, "ty_scale");
        tileTestLocation = GLES31.glGetUniformLocation(programInt, "tile_test");
        seedLocation = GLES31.glGetUniformLocation(programInt, "seed");
        multLocation = GLES31.glGetUniformLocation(programInt, "mult");
        addLocation = GLES31.glGetUniformLocation(programInt, "add");
        modeLocation = GLES31.glGetUniformLocation(programInt, "mode");
        interpolationLocation = GLES31.glGetUniformLocation(programInt, "interpolation");
        //numStepLocation = GLES31.glGetUniformLocation(programInt, "numSteps");
        speedMultLocation = GLES31.glGetUniformLocation(programInt, "speedMult");
        dataMeldLocation = GLES31.glGetUniformLocation(programInt, "dataMeld");
        outputRangeMinLocation = GLES31.glGetUniformLocation(programInt, "outputRangeMin")
        smoothingLocation = GLES31.glGetUniformLocation(programInt, "smoothing")
        outputRangeMaxLocation = GLES31.glGetUniformLocation(programInt, "outputRangeMax")
        drawRangeMinLocation = GLES31.glGetUniformLocation(programInt, "drawRangeMin")
        drawRangeMaxLocation = GLES31.glGetUniformLocation(programInt, "drawRangeMax")
        dataRangeMinLocation = GLES31.glGetUniformLocation(programInt, "dataRangeMin")
        dataRangeMaxLocation = GLES31.glGetUniformLocation(programInt, "dataRangeMax")
        userParticleWidthLocation = GLES31.glGetUniformLocation(programInt, "particleSize")
        userParticleHeightLocation = GLES31.glGetUniformLocation(programInt, "particleHeight")
        vectorOffsetLocation = GLES31.glGetUniformLocation(programInt, "vectorOffset")
        alphaLocation = GLES31.glGetUniformLocation(programInt, "alpha")
        tileModeLocation = GLES31.glGetUniformLocation(programInt, "tileMode")
        fbPremultLocation = GLES31.glGetUniformLocation(programInt, "preMult");
        timeLocation = GLES31.glGetUniformLocation(programInt, "time")
        sampleDataMinLocation = GLES31.glGetUniformLocation(programInt, "sampleDataMin")
        sampleDataMaxLocation = GLES31.glGetUniformLocation(programInt, "sampleDataMax")
        channelLocation1 = GLES31.glGetUniformLocation(programInt, "channel1")
        channelLocation2 = GLES31.glGetUniformLocation(programInt, "channel2")
        colorSampleOffsetLocation = GLES31.glGetUniformLocation(programInt, "colorSampleOffset")
        fadeMultLocation = GLES31.glGetUniformLocation(programInt, "fadeMult")
        colorRangeFactorLocation = GLES31.glGetUniformLocation(programInt, "colorRangeFactor")
        bindingPointLocation = GLES31.glGetUniformLocation(programInt, "bindingPoint")
        bufferItemsPerTileLocation = GLES31.glGetUniformLocation(programInt, "bufferItemsPerTile")

        singlePointModeLoc = GLES31.glGetUniformLocation(programInt, "singlePointMode")
        getXLoc = GLES31.glGetUniformLocation(programInt, "getX")
        getYLoc = GLES31.glGetUniformLocation(programInt, "getY")
        useRawColorsLocation = GLES31.glGetUniformLocation(programInt, "u_useRawTextureColors")

        valueIntervalLocation = GLES31.glGetUniformLocation(programInt, "valueInterval")
        majorValueIntervalLocation = GLES31.glGetUniformLocation(programInt, "majorValueInterval")
        widthLocation = GLES31.glGetUniformLocation(programInt, "width")
        majorWidthLocation = GLES31.glGetUniformLocation(programInt, "majorWidth")


        if (computeProgramInt != 0) {
            bufferItemsPerTileLocationC = GLES31.glGetUniformLocation(computeProgramInt, "bufferItemsPerTileC")
            drawNumLocationC = GLES31.glGetUniformLocation(computeProgramInt, "drawNumC")
            speedMultLocationC = GLES31.glGetUniformLocation(computeProgramInt, "speedMultC");
            totalParticleCountLocationC = GLES31.glGetUniformLocation(computeProgramInt, "totalParticleCountC")
            vectorOffsetLocationC = GLES31.glGetUniformLocation(computeProgramInt, "vectorOffsetC")
            currentTileBindingPointLocationC =
                GLES31.glGetUniformLocation(computeProgramInt, "currentTileBindingPointC")

            tx_scaleLocationC = GLES31.glGetUniformLocation(computeProgramInt, "tx_scaleC")
            tx_offsetLocationC = GLES31.glGetUniformLocation(computeProgramInt, "tx_offsetC")
            ty_scaleLocationC = GLES31.glGetUniformLocation(computeProgramInt, "ty_scaleC")
            ty_offsetLocationC = GLES31.glGetUniformLocation(computeProgramInt, "ty_offsetC")


        }

        if (type != ProgramType.PARTICLE) {
            texPositionHandle = GLES31.glGetAttribLocation(programInt, "a_TexCoord")
        }
        positionHandle = GLES31.glGetAttribLocation(programInt, "a_position")
        //endregion locations and handles
    }

    /** Called from RenderPass render(), for uniforms that are the same across the tileset.
     * Done once per layer instead of per renderable.
     *  re-combine with use() if it gets to be too much of an issue.
     * **/
    fun useOncePerFrame() {
        if (uniforms.containsKey("colorBandTexHandle")) {
            //TODO: Find where "colorBandTexHandle" applies....
            colorBandTexHandles[0] = uniforms["colorBandTexHandle"] as Int
            glUniform1i(colorBandUniformLocation[0], 1)

            if (uniforms.containsKey("colorBandTexHandle1")) {
                colorBandTexHandles[1] = uniforms["colorBandTexHandle1"] as Int
                colorBandTexHandles[2] = uniforms["colorBandTexHandle2"] as Int
                glUniform1i(colorBandUniformLocation[1], 2)
                glUniform1i(colorBandUniformLocation[2], 3)
            }
        }

        //===============================================================================================
        glUniform1f(alphaUniformLocation, 1.0f)
        glUniform1f(blurSizeLocation, blurSize)
        glUniform1f(blurRadiusLocation, blurRadius)
        glUniform1f(addLocation, add)
        glUniform1f(multLocation, mult)
        glUniform1f(smoothingLocation, smoothing)

        //glUniform1f(dataMeldLocation, Timeline.dataMeld)
        glUniform1f(outputRangeMinLocation, outputRangeMin)
        glUniform1f(outputRangeMaxLocation, outputRangeMax)
        glUniform1f(drawRangeMinLocation, drawRangeMin)
        glUniform1f(drawRangeMaxLocation, drawRangeMax)
        glUniform1f(dataRangeMinLocation, dataRangeMin)
        glUniform1f(dataRangeMaxLocation, dataRangeMax)

        glUniform1f(sampleDataMinLocation, sampleDataRangeMin)
        glUniform1f(sampleDataMaxLocation, sampleDataRangeMax)
        glUniform1i(interpolationLocation, interpolation)
        glUniform1i(modeLocation, mode)
        glUniform1i(channelLocation1, channel1)
        glUniform1i(channelLocation2, channel2)
        glUniform1f(colorSampleOffsetLocation, colorSampleOffset)
        glUniform1f(colorRangeFactorLocation, colorRangeFactor)

        glUniform1f(noDataLocation, 0f) //FIXME: This is hardcoded

        if (type != ProgramType.PARTICLE) {
            GLES31.glEnableVertexAttribArray(texPositionHandle) //needed for raster and encoded
        }
        if (computeProgramInt == 0) {
            GLES31.glEnableVertexAttribArray(positionHandle) // a_position should not be used for particle vertex shader with compute
        }
    }

    /** Called from Mesh.draw().
     *
     *  To be used to set up textures
     * */
    override fun use() {
        glUniform1f(xScaleLocation, xScale)
        glUniform1f(yScaleLocation, yScale)
        glUniform1f(xOffsetLocation, xOffset)
        glUniform1f(yOffsetLocation, yOffset)
        glUniform1f(xScale2Location, xScale2)
        glUniform1f(yScale2Location, yScale2)
        glUniform1f(xOffset2Location, xOffset2)
        glUniform1f(yOffset2Location, yOffset2)

        glUniform1f(fadeMultLocation, fadeMult)
        //glUniform1i(numStepLocation, numSteps)
        glUniform1f(speedMultLocation, speedMult)
        glUniform1i(nextTextureUniformLocation, 4)
        //textureNextHandle = GLES31.glGetUniformLocation(programInt, "dataTextureNext")
    }

    fun useContour() {
        glUniform1f(valueIntervalLocation, valueInterval)
        glUniform1f(majorValueIntervalLocation, majorValueInterval)
        glUniform1f(widthLocation, width)
        glUniform1f(majorWidthLocation, majorWidth)
    }

    fun setContourUniforms(valueInterval: Float, majorValueInterval: Float, width: Float, majorWidth: Float) {
        this.valueInterval = valueInterval
        this.majorValueInterval = majorValueInterval
        this.width = width
        this.majorWidth = majorWidth
    }

    fun setColorBandTexture() {
        GLES31.glEnable(GLES31.GL_BLEND);
        GLES31.glBlendFunc(GLES31.GL_ONE, GLES31.GL_ONE_MINUS_SRC_ALPHA)

        if (uniforms.containsKey("colorBandTexHandle1")) { // Radar
            (0..2).forEach { i ->
                if (colorBandTexHandles[i] != 0) {
                    GLES31.glActiveTexture(GLES31.GL_TEXTURE1 + i)
                    GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, colorBandTexHandles[i])
                }
            }
        } else { // Normal Encoded
            GLES31.glActiveTexture(GLES31.GL_TEXTURE1)
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, colorBandTexHandles[0])
            // GLES31.glEnable(GLES31.GL_BLEND);
            //GLES31.glBlendFunc(GLES31.GL_ONE, GLES31.GL_ONE_MINUS_SRC_ALPHA)
        }
    }

    fun bindCompute() {
        GLES31.glUseProgram(computeProgramInt)
    }

    override fun unbind() {
        //println("$TAG unbind() entered")

        if (computeProgramInt == 0) {
            GLES31.glDisableVertexAttribArray(positionHandle)
        }

        //GLES31.glDisableVertexAttribArray(progPtr.colorHandle).also { checkError("glDisableVertexAttribArray") }
        if (type != ProgramType.PARTICLE) { //3 is particle
            GLES31.glDisableVertexAttribArray(texPositionHandle)//.also { checkError("glDisableVertexAttribArray") }
        }
    }

    override fun setUniform(name: String, value: Any) {
        // if (this.uniforms[name]!=null) {
        this.uniforms[name] = value;
        // }
    }

    //region helper setters
    /** Used for set the blur in the shader **/
    fun updateBlur(size: Float, radius: Float) {
        blurSize = size
        blurRadius = radius
    }

    /** Used for set the scale of the texture in the shader for tile partials **/
    fun updateTexture1Size(xScale: Float, yScale: Float, xOffset: Float, yOffset: Float) {
        if (pr.ON) pr.p(TAG, pr.shader, "updateTexture1Size xScale: $xScale, xOffs: $xOffset")
        this.xScale = xScale
        this.yScale = yScale
        this.xOffset = xOffset
        this.yOffset = yOffset
    }

    /** Used for set the scale of the texture in the shader for tile partials **/
    fun updateTexture2Size(xScale2: Float, yScale2: Float, xOffset2: Float, yOffset2: Float) {
        if (pr.ON) pr.p(TAG, pr.shader, "updateTexture2Size xScale: $xScale, xOffs: $xOffset")
        this.xScale2 = xScale2
        this.yScale2 = yScale2
        this.xOffset2 = xOffset2
        this.yOffset2 = yOffset2
    }

    /** Used for set the scale of the texture in the shader for tile partials **/
    fun setMeld(meld: Float) {
        glUniform1f(dataMeldLocation, meld)
    }

    /** Used for set the outputRange in the shader **/
    fun updateOutputRange(min: Float, max: Float) {
        if (pr.ON) pr.p(TAG, pr.shader, "updateOutputRange() min:$min  max:$max")
        this.outputRangeMin = min
        this.outputRangeMax = max
    }

    /** Used for set the outputRange in the shader **/
    fun updateSmoothing(smoothing: Float) {
        this.smoothing = smoothing
    }

    /** Used for set the drawRange in the shader **/
    fun updateDrawRange(min: Float, max: Float) {
        if (pr.ON) pr.p(TAG, pr.shader, "updateDrawRange() min:$min  max:$max")
        this.drawRangeMin = min
        this.drawRangeMax = max
    }

    /** Used for set the dataRange in the shader **/
    fun updateDataRange(min: Float, max: Float) {
        this.dataRangeMin = min
        this.dataRangeMax = max
    }

    fun updateNoData(value: Float) {
        this.noData = value
    }

    fun updateMode(mode: Int) {
        this.mode = mode
    }

    /** Used for set the channels in the shader **/
    fun updateChannels(channel1: Int, channel2: Int) {
        //println("TAG updateChannels: $channel1      $channel2")
        this.channel1 = channel1
        this.channel2 = channel2
    }

    /** Used for set the updateSampleData in the shader **/
    fun updateSampleDataRange(sdMin: Float, sdMax: Float) {
        if (pr.ON) pr.p(TAG, pr.shader, "updateDataSampleData() cl1 min:$sdMin  max:$sdMax")
        this.sampleDataRangeMin = sdMin
        this.sampleDataRangeMax = sdMax
    }

    /** Used for set the updateColorSampleOffset in the shader **/
    fun updateColorSampleOffset(value: Float) {
        if (pr.ON) pr.p(TAG, pr.shader, "updateColorSampleOffset() value:$value")
        this.colorSampleOffset = value
    }

    /** Used for set the updateColorRangeFactor in the shader **/
    fun updateColorRangeFactor(value: Float) {
        if (pr.ON) pr.p(TAG, pr.shader, "updateColorRangeFactor() value:$value")
        this.colorRangeFactor = value
    }

    //fun updateTimeStep(timeStepValue: Float) { this.timeStep = timeStepValue  }

    fun updateFadeMult(value: Float) {
        //if(pr.ON)pr.p(TAG,pr.shader,"updateTime() value:$value" )
        this.fadeMult = value;
    }

    //fun updateNumSteps(value: Int) { this.numSteps = value }

    fun updateSpeedMult(value: Float) {
        this.speedMult = value;
    }

    fun updateSpeedMultC(value: Float) {
        //if(pr.ON)pr.p(TAG,pr.shader,"updateSpeedMult() value:$value" )
        glUniform1f(speedMultLocationC, value)
        this.speedMultC = value;
    }

    fun setAlpha(value: Float) {
        glUniform1f(alphaLocation, value)
    }

    fun setPointSize(value: Float) {
        glUniform1f(userParticleWidthLocation, value)
    }

    fun setPointSize(value1: Float, value2: Float) {
        glUniform1f(userParticleWidthLocation, value1)
        glUniform1f(userParticleHeightLocation, value2)
    }

    fun setTileMode(value: Int) {
        glUniform1i(tileModeLocation, value)
    }

    fun setBufferItemsPerTile(value: Int) {
        glUniform1i(bufferItemsPerTileLocation, value)
    }

    fun setFBPreMult(value: Int) {
        glUniform1i(fbPremultLocation, value)
    }

    fun setOpacity(value: Float) {
        glUniform1f(opacityLocation, value)
    }

    fun setFrameRateMult(frameRateMult: Float) {
        glUniform1f(frameRateMultLocation, frameRateMult)
    }
    //endregion helper setters

    private fun checkError(cmd: String? = null) {
        if (true /*BuildConfig.DEBUG*/) {
            when (val error = GLES31.glGetError()) {
                GLES31.GL_NO_ERROR -> {/*println("TAG $cmd -> no error")*/
                }

                GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM: ${error}")
                GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                else -> throw RuntimeException("$cmd -> error in gl: $error")
            }
        }
    }
}