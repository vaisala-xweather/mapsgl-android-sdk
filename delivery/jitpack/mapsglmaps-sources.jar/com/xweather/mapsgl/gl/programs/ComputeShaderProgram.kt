package com.xweather.mapsgl.gl.programs

import android.content.Context
import com.xweather.mapsgl.gl.geometries.bufferAttributes.AttributeKey
import com.xweather.mapsgl.gl.geometries.bufferAttributes.IBufferAttribute

class ComputeShaderProgram(
    val context: Context, val computeShaderPath: String, vertexShader: Int?,
    fragmentShader: Int?, compShader: Int?
) : AbstractProgram(
    vertexShader, fragmentShader, compShader
) {
    override fun setupShaderInputs(
        map: HashMap<AttributeKey, IBufferAttribute<*>>,
        iResolution: IntArray,
        iChannels: IntArray,
        iChannelResolutions: Array<IntArray>
    ) {
        super.setupShaderInputs(map, iResolution, iChannels, iChannelResolutions)

        handle?.let {
            /*
             * TODO add custom storager buffer(s) for communication
             */
        }
    }

    override fun setUniform(name: String, value: Any) {
        TODO("Not yet implemented")
    }


}