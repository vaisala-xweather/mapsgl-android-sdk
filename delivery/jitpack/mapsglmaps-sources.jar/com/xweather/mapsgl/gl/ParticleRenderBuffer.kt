package com.xweather.mapsgl.gl

import android.opengl.GLES20.glGenBuffers
import android.opengl.GLES30.GL_DYNAMIC_COPY
import android.opengl.GLES31
import android.opengl.GLES31.GL_SHADER_STORAGE_BUFFER
import com.xweather.mapsgl.util.MapsGLDebug
import java.nio.FloatBuffer

/** Shader Storage Buffer Objects (SSBOs) for persistant location storage, one for each rendered tile.  **/
class ParticlePositionBuffer {
    var numMeshes = 0
    var posSSBO: Int = 0
    private var numVertices = 0
    private var posDataSize = 0
    private val bindingPoint = 0
    var hasBeenInitialized = false

    /** Sets up buffer for persistent particle data. Needs to be run from a place with render context.**/
    private fun initialize(totalParticles: Int, numMeshesMult: Int){ //
        //println("ParticleRenderBuffer initialize() hasBeenInitialized: $hasBeenInitialized"  )
        if(!hasBeenInitialized) {
            numMeshes = numMeshesMult
            numVertices = totalParticles * numMeshes
            posDataSize = numVertices * 4 * 4 // 4 floats (x, y, z, w) * 4 bytes per float
            val ssbo = IntArray(1)
            glGenBuffers(1, ssbo, 0) .also { checkError("glGenBuffers") }
            posSSBO = ssbo[0]
            //println("ParticleRenderBuffer initialize() posSSBO: $posSSBO"  )
            //println("ParticleRenderBuffer initialize() gl version: ${GLES31.glGetString(GLES31.GL_VERSION)}")

            GLES31.glBindBuffer(GL_SHADER_STORAGE_BUFFER, posSSBO) .also { checkError("glBindBuffer") } //fixme: CRASH HERE
            GLES31.glBufferData(GL_SHADER_STORAGE_BUFFER, posDataSize, null, GL_DYNAMIC_COPY).also { checkError("glBufferData") }
            // Initialize the SSBO with some initial values (e.g., original vertex positions)
            val initialPosData = FloatArray(numVertices * 4) { 0.0f } // Initialize to 0
            val posBuffer = FloatBuffer.wrap(initialPosData)
            GLES31.glBufferSubData(GL_SHADER_STORAGE_BUFFER, 0, posDataSize, posBuffer).also { checkError("glBufferSubData") }
            GLES31.glBindBufferBase(GL_SHADER_STORAGE_BUFFER, bindingPoint, posSSBO).also { checkError("glBindBufferBase") }  // Bind to binding point
            GLES31.glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0).also { checkError("glBindBuffer") }  // Unbind
            hasBeenInitialized = true
        }
    }

    private fun resize(totalParticles: Int, numMeshesMult: Int ){
        //println("ParticleRenderBuffer resize(totParticles: $totalParticles, numMeshes: $numMeshes)")
        //println("ParticleRenderBuffer resize() numMeshes was $numMeshes ")
        numMeshes = numMeshesMult
        numVertices = totalParticles * numMeshes
        posDataSize = numVertices * 4 * 4 // 4 floats (x, y, z, w) * 4 bytes per float
        GLES31.glBindBuffer(GL_SHADER_STORAGE_BUFFER, posSSBO)
        GLES31.glBufferData(GL_SHADER_STORAGE_BUFFER, posDataSize, null, GL_DYNAMIC_COPY)
        // Initialize the SSBO with some initial values (e.g., original vertex positions)
        //val initialPosData = FloatArray(numVertices * 4) { 0.0f } // Initialize to 0
        //val posBuffer = FloatBuffer.wrap(initialPosData)
        //GLES31.glBufferSubData(GL_SHADER_STORAGE_BUFFER, 0, posDataSize, posBuffer)
        //GLES31.glBindBufferBase(GL_SHADER_STORAGE_BUFFER, bindingPoint, posSSBO)  // Bind to binding point
        GLES31.glBindBuffer(GL_SHADER_STORAGE_BUFFER, 0) // Unbind
    }

    fun createStorageBufferIfNeeded(totalParticles: Int, numMeshesMult: Int){
        //println("ParticleRenderBuffer checkStorageBuffer(totParticles: $totalParticles, numMeshes: $numMeshes)")
        if(numMeshes == 0){
            initialize(totalParticles, numMeshesMult)
        } else if (numMeshesMult > numMeshes) {
            resize(totalParticles, numMeshesMult)
        }
    }


    private fun checkError(cmd: String? = null) {
        if (MapsGLDebug.enabled) {
            when (val error = GLES31.glGetError()) {
                GLES31.GL_NO_ERROR -> {/*println("TAG $cmd -> no error")*/
                }

                GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM: ${error}" )
                GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                else -> throw RuntimeException("$cmd -> error in gl: $error")
            }
        }
    }

}