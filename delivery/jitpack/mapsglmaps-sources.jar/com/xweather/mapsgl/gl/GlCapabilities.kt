package com.xweather.mapsgl.gl

import android.app.ActivityManager
import android.content.Context

/**
 * What the device's OpenGL ES implementation can actually do.
 *
 * The SDK baseline is ES 3.0 and the library manifest requires exactly that. The particle layers
 * are the only part that needs more: their vertex, fragment and compute shaders declare
 * `#version 310 es`, and the pipeline uses compute dispatch, shader storage buffers and image
 * load/store, none of which exist before ES 3.1. Everything else - encoded raster, vector fill,
 * line, circle, symbol and heatmap layers, stencil masks, data query text - runs on 3.0.
 *
 * The check reads the version the platform advertises rather than querying a live GL context,
 * because layers are added from the main thread, often before any context is current.
 */
object GlCapabilities {

    /** `reqGlEsVersion` for OpenGL ES 3.1: major in the high 16 bits, minor in the low 16. */
    private const val ES_3_1 = 0x00030001

    @Volatile
    private var cachedReqGlEsVersion: Int? = null

    /**
     * The device's advertised OpenGL ES version as a packed `reqGlEsVersion`, e.g. `0x00030002`
     * for ES 3.2. Cached; the value cannot change while the process lives.
     */
    fun reqGlEsVersion(context: Context): Int =
        cachedReqGlEsVersion ?: synchronized(this) {
            cachedReqGlEsVersion ?: run {
                val am = context.applicationContext
                    .getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                am.deviceConfigurationInfo.reqGlEsVersion.also { cachedReqGlEsVersion = it }
            }
        }

    /**
     * Whether this device can render the particle layers (`wind-particles` and the other
     * `*-particles` codes). False below ES 3.1, where their shaders cannot compile.
     *
     * Apps that offer particle layers in their own UI should call this to hide the option rather
     * than letting the add fail; [com.xweather.mapsgl.map.MapController.addWeatherLayer] refuses
     * such a layer and returns null.
     */
    fun supportsParticleLayers(context: Context): Boolean = reqGlEsVersion(context) >= ES_3_1

    /** Human-readable form of [reqGlEsVersion], e.g. `3.1`. */
    fun glEsVersionString(context: Context): String {
        val v = reqGlEsVersion(context)
        return "${v shr 16}.${v and 0xFFFF}"
    }
}
