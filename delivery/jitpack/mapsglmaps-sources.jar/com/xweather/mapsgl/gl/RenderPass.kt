package com.xweather.mapsgl.gl

import android.opengl.EGL14
import android.opengl.EGLContext
import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLES31
import android.opengl.Matrix
import com.xweather.mapsgl.anim.LayerAnimationTarget
import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.util.Map3D
import com.xweather.mapsgl.gl.worldObjects.Mesh
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.GlStencilMaskRendererHolder
import com.xweather.mapsgl.map.mapbox.meshTileXYForEncodedLookup
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.effectiveSampleMeldProgress
import com.xweather.mapsgl.utils.encodedIntervalKeyAliases
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor

/*
 *   RenderPass.kt
 *
 *  A `RenderPass` draws a list of Meshes that share the same `RenderMaterial`/`RenderShader`
 *  and the same `GeometryVertexElementLayout` and thus all can use the same `RenderPipeline`
 *  @author Jason Suto 02/05/24.
 */

/**
 * Base GL render pass for a single tile layer: draws whatever [meshes]/[meshInfoList] the owning
 * [com.xweather.mapsgl.renderers.TileLayerRenderer] hands it for the current frame, resolving each
 * tile's texture(s) against the shared timeline (via [Timeline] / [LayerTimeline]) and a caller-owned
 * map of already-bound GL texture ids (`texHashMap` in [render]). This class implements the raster
 * tile path directly; `open`/subclassable so other layer kinds (e.g. [ContourRenderPass], [ParticleRenderPass],
 * [EmptyRenderPass]) can reuse the shared viewport-playback gating, dateline handling, and
 * partial-texture fallback logic while swapping in their own draw loop and style handling.
 *
 * @property label Identifies this pass's source/layer for timeline lookups (keys
 * [Timeline.sourceTimeHash]); normally the owning [com.xweather.mapsgl.layers.tile.TileLayer]'s source id.
 * @property meshes The tile meshes to draw this frame, sharing one GL program/vertex layout.
 * Populated by [com.xweather.mapsgl.renderers.TileLayerRenderer] each frame; [render] is a no-op
 * while this is null or empty.
 * @property meshInfoList Per-tile metadata (tile coordinate, dateline-adjusted x/y, hash key)
 * parallel to [meshes], consumed by [render] to place and texture each tile.
 * @suppress
 */
open class RenderPass(
    open val label: String,
    open var meshes: List<Mesh>?,
    open var meshInfoList: List<MeshInfo>?
) {

    /**
     * Identifier for this pass, independent of [label]. Defaults to [label] but may be reassigned
     * by the owning renderer (see `RasterLayerRenderer.setUpRenderPass`) when the pass needs a
     * different identity than its source label.
     */
    open var id: String = label
    private var modelMatrixHandle = 0
    private var projectionMatrixHandle = 0
    private val matrixArray = FloatArray(16)
    private val cameraArray = FloatArray(16)
    private val projectionMatrixArray = FloatArray(16)
    private val modelViewMatrixArray = FloatArray(16)
    private val checkErrorString = "glUniformMatrix4fv"
    private val checkErrorUse = "glUseProgram"
    private lateinit var progPtr: RasterTileProgram
    private var currentMesh: Mesh? = null
    private var scale = 1f
    private var newX = 0
    private var newY = 0
    private var altDataZoom = 1
    /**
     * Per-instance 3D lookup table declared here so every layer-type subclass shares the same
     * shape; not read or written by this class's own [render] implementation.
     */
    open val map3D = Map3D<Int, String>()

    /**
     * Scratch slot for the most recently resolved texture hash key, intended for subclass
     * debug logging (see the `hashString` trace in `datelineAdjustment`); not assigned by this
     * class's own [render] implementation.
     */
    open var hashString: String? = null

    /**
     * The layer's paint/style configuration, set from the constructor's `paint` argument
     * ([ParticleLayerPaint], [SampleLayerPaint], or [RasterLayerPaint]). [render] reads it each
     * frame for values such as opacity.
     */
    open lateinit var sampleStyle: LayerPaint  //RasterStyle //was sampleStyle

    /**
     * Applies JS `paint.sample.meld`: when false, returns `0` so draw stays on the current interval.
     * Safe to call when [sampleStyle] was never assigned (primary ctor path).
     */
    protected fun applySampleMeldOption(timelineMeld: Float): Float =
        if (::sampleStyle.isInitialized) {
            sampleStyle.effectiveSampleMeldProgress(timelineMeld)
        } else {
            timelineMeld.coerceIn(0f, 1f)
        }

    /** Reserved debug bookkeeping slot for subclasses; not read by this class's own [render] implementation. */
    open var debugLast = -1L

    /**
     * Mesh count from the most recent [render] call, updated every frame. Intended to gate
     * debug logging when the visible tile count changes; currently write-only in this class.
     */
    open var lastMeshCount = 0

    /**
     * Optional per-tile hooks for GLES stencil masking on encoded weather layers.
     * Invoked after the tile [modelViewMatrixArray] is computed and before any `Mesh.draw` for that tile.
     */
    var stencilBeforeTile: ((
        meshInfo: MeshInfo,
        projectionMatrix: FloatArray,
        modelViewMatrix: FloatArray,
    ) -> Unit)? =
        null

    /** Optional per-tile hook invoked immediately after each tile is drawn; pairs with [stencilBeforeTile]. */
    var stencilAfterTile: (() -> Unit)? = null

    /** Optional once-per-frame hook before the tile loop (stencil is reset per tile when [stencilBeforeTile] is set; see [com.xweather.mapsgl.map.mapbox.GlStencilMaskRenderer.clearStencilForWeatherTileScreenBounds]). */
    var stencilPassBegin: (() -> Unit)? = null

    /**
     * Stencil mask for a layer drawn as one screen composite rather than per tile — particles, which
     * simulate into a framebuffer and then draw it as a single full-screen quad. Builds the layer's
     * mask for every visible tile into the stencil and leaves the stencil test set for the composite;
     * returns `true` when it did, so the caller restores the stencil afterwards.
     *
     * @param useMapboxModelView Whether [cameraModelView] is Mapbox's own model-view (tiles then scale
     *   by the raster overscale, as in the tile loop of [render]).
     */
    var compositeStencil: ((
        meshInfoList: List<MeshInfo>,
        projectionMatrix: FloatArray,
        cameraModelView: FloatArray,
        useMapboxModelView: Boolean,
        rasterProgram: RasterTileProgram,
    ) -> Boolean)? = null

    /**
     * Optional once-per-frame hook to build a JS-style viewport mask texture (`com.xweather.mapsgl.map.mapbox.GlTextureMaskBuilder`)
     * before the weather tile loop. When set, [stencilBeforeTile] should remain null.
     */
    var textureMaskBeforeTileLoop: ((
        meshInfoList: List<MeshInfo>,
        projectionMatrix: FloatArray,
        modelViewBase: FloatArray,
        viewportWidth: Int,
        viewportHeight: Int,
    ) -> Unit)? = null

    /** Set by [textureMaskBeforeTileLoop] to bind on the weather program for this frame. */
    var textureMaskBind: ((
        program: RasterTileProgram,
        viewportWidth: Int,
        viewportHeight: Int,
    ) -> Unit)? = null

    //var lastTime = System.currentTimeMillis()-1000L
    /** Timestamp of the most recent [render] call, refreshed every frame; reserved for subclass timing/debug use. */
    open var currentTime = 0L

    /** Open flag for subclasses to track their own one-time setup; not read or set by this class's own [render] implementation. */
    open var initialized = false
    private val shouldDisplayRawColors = false

    private fun weatherDebugMatchesMesh(meshInfo: MeshInfo): Boolean {
        if (WEATHER_DEBUG_TARGETS.isEmpty()) return false
        val key = weatherDebugKey(meshInfo)
        return WEATHER_DEBUG_TARGETS.split(',').any { it.trim() == key }
    }

    private fun weatherDebugKey(meshInfo: MeshInfo): String {
        val zInt = meshInfo.z.toInt()
        val nx = normalizedTileXForTextureHash(meshInfo)
        return "$zInt/$nx/${meshInfo.y.toInt()}"
    }

    /**
     * Errors that can occur during the rendering process.
     */
    sealed class Error {
        /** No meshes were supplied to a render pass that requires at least one to draw. */
        object MustSupplyAtLeastOneMesh : Error()
        /** A replacement set of mesh elements doesn't match the vertex descriptor already in use. */
        object NewElementsDontMatchVertexDescriptor : Error()
        /** The GPU command encoder needed for this pass could not be created. */
        object CouldntCreateCommandEncoder : Error()
    }

    /**
     * Prepared members of the `RenderPass`.
     */

    constructor(
        label: String = "null",
        paint: LayerPaint //PaintStyle
    ) : this(
        label,
        null,
        null,
    ) {

        if (pr.ON) pr.p(TAG, pr.waaveRenderpath, ">> renderpass label is $label")

        if (paint is ParticleLayerPaint) {
            sampleStyle = paint as ParticleLayerPaint
        } else if (paint is SampleLayerPaint) {
            sampleStyle = paint
        } else {
            sampleStyle = paint as RasterLayerPaint
        }
    }

    /**
     *
     * Should loop through renderables and call draw() on each.
     *
     * Called from TileLayerRenderer.draw()
     *
     */
    open fun render(texHashMap: HashMap<String, Int>, camera: Camera) {
        var phaseAString = ""
        var phaseBString = ""
        var finalMeld = 0f
        val layerInfo = Timeline.sourceTimeHash[label]
        val viewportMeshes = meshInfoList.orEmpty()
        // [datelineAdjustment] rewrites [MeshInfo.hashCode]. Readiness used to run first, then
        // this wrap ran at draw — a tile could count as ready under one key and miss the texture
        // under the other. Normalize before we pick a phase so both use the same hash.
        for (mesh in viewportMeshes) {
            datelineAdjustment(mesh)
        }

        if (layerInfo != null) {
            if (pr.ON) pr.p(TAG, pr.noLoad, "render() layerInfo was NOT null, using layerInfo")
            val resolved = if (viewportMeshes.isNotEmpty()) {
                applyLayerViewportPlayback(layerInfo, viewportMeshes, texHashMap)
            } else {
                val target = layerInfo.computeGlobalAnimationTarget()
                LayerDrawPhases(target.phaseA, target.phaseB, target.meld).also {
                    layerInfo.commitDisplayPhases(it.phaseA, it.phaseB, it.meld, true, null)
                }
            }
            phaseAString = Timeline.getTimeString(0, resolved.phaseA)
            phaseBString = Timeline.getTimeString(1, resolved.phaseB)
            finalMeld = resolved.meld
        } else {
            if (pr.ON) pr.p(TAG, pr.noLoad, "render() layerInfo was  null, falling back to TimeLine", 2)
            val global = Timeline.fallbackGlobalRenderPhases()
            phaseAString = global.first
            phaseBString = global.second
            finalMeld = global.third
            if (viewportMeshes.isNotEmpty()) {
                val timelineLongA = Timeline.timeLongs.getOrElse(Timeline.currentPhaseA) { 0L }
                val timelineLongB = Timeline.timeLongs.getOrElse(Timeline.currentPhaseB) { timelineLongA }
                val targetLong = (timelineLongA + (timelineLongB - timelineLongA) * finalMeld).toLong()
                val target = LayerAnimationTarget(phaseAString, phaseBString, finalMeld, targetLong)
                // Snapshot global timeline lists; they are mutated off the GL thread when valid
                // times update, so passing the raw references can race with downstream indexed reads.
                val resolved = resolveLayerViewportDrawPhases(
                    viewportMeshes = viewportMeshes,
                    texHashMap = texHashMap,
                    sourceId = null,
                    target = target,
                    intervalStrings = safeSnapshotInterval(Timeline.timeStrings),
                    intervalLongs = safeSnapshotInterval(Timeline.timeLongs),
                    retainPhases = emptyList(),
                )
                phaseAString = resolved.phaseA
                phaseBString = resolved.phaseB
                finalMeld = resolved.meld
            }
        }
        // JS `paint.sample.meld`: when false, draw the current interval only (no blend).
        finalMeld = applySampleMeldOption(finalMeld)

        if (meshes != null && meshes!!.isNotEmpty()) {

            currentMesh = meshes!!.first()

            //if (pr.ON) pr.p(TAG, pr.noLoad, "render() about to assign progPtr")
            progPtr = (currentMesh!!.program as RasterTileProgram)
            progPtr.bind().also { checkError(checkErrorUse) }// Add program to OpenGL ES environment
            progPtr.useOncePerFrame()
            progPtr.use()
            progPtr.setColorBandTexture()

            currentTime = System.currentTimeMillis()

            GLES31.glUniform1i(progPtr.singlePointModeLoc, 0)
            GLES31.glUniform1i(progPtr.useRawColorsLocation, if (shouldDisplayRawColors) 1 else 0)
            // GLES 3.x: vertex attributes must come from buffer objects; client-side pointers are invalid.
            bindRasterTileVertexAttributes(progPtr)
            // In Mapbox [CustomLayerHost], use native projection + model-view from the same frame as
            // the basemap so encoded rasters sit on the map surface under pitch/bearing. Mixing
            // Mapbox P with [camera.viewMatrix] (or the inverse) leaves a separate "floating" plane.
            val mapboxProj = CameraSync.mapboxProjectionMatrix
            val mapboxMv = CameraSync.mapboxModelViewMatrix
            val useMapboxNativeMv =
                mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
            if (useMapboxNativeMv) {
                System.arraycopy(mapboxProj, 0, projectionMatrixArray, 0, 16)
                System.arraycopy(mapboxMv, 0, cameraArray, 0, 16)
            } else {
                matrixToFloatArray(camera.projectionMatrix, projectionMatrixArray)
                matrixToFloatArray(camera.viewMatrix, cameraArray)
            }

            projectionMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "projectionMatrix")
                .also { checkError("glGetUniformLocation") }
            GLES31.glUniformMatrix4fv(projectionMatrixHandle, 1, false, projectionMatrixArray, 0)
                .also { checkError("glUniformMatrix4fv") }

            modelMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "modelViewMatrix")
                .also { checkError("glGetUniformLocation") }
            progPtr.useOncePerFrame()
            progPtr.setColorBandTexture()
            sampleStyle.let { progPtr.setOpacity(it.opacity) }


            // if (pr.ON) {
            // if (lastMeshCount != meshInfoList!!.size) {
            //     pr.p(TAG, pr.tileCount, "render() meshInfoList.size: ${meshInfoList!!.size}")
            lastMeshCount = meshInfoList!!.size
            // }
            // }

            if (true /*|| phaseA < Timeline.timeStrings.size*/) {
                GLES31.glViewport(0, 0, camera.resX, camera.resY)
                stencilPassBegin?.invoke()
                meshInfoList?.let { infos ->
                    textureMaskBeforeTileLoop?.invoke(
                        infos,
                        projectionMatrixArray,
                        cameraArray,
                        camera.resX,
                        camera.resY,
                    )
                }
                if (textureMaskBind != null) {
                    textureMaskBind?.invoke(progPtr, camera.resX, camera.resY)
                } else {
                    progPtr.bindTextureMask(0, camera.resX, camera.resY, enabled = false, invert = false)
                }
                progPtr.setMeld(finalMeld)
                meshInfoList?.forEach { meshInfo ->
                    if (true /*|| searchKey == meshInfo.hashCode*/) {
                        Matrix.setIdentityM(matrixArray, 0); // initialize to identity matrix
                        val mapZoomNow =
                            CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom
                        val overscale = if (useMapboxNativeMv) {
                            CameraSync.tileRasterOverscale(mapZoomNow, meshInfo.z.toInt())
                        } else {
                            1f
                        }
                        Matrix.scaleM(matrixArray, 0, 512f * overscale, 512f * overscale, 1f)
                        Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
                        Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, matrixArray, 0) //works
                        GLES31.glUniformMatrix4fv(
                            modelMatrixHandle,
                            1,
                            false,
                            modelViewMatrixArray,
                            0
                        )

                        if (stencilBeforeTile != null) {
                            // Must reset stencil for each tile; otherwise REPLACE/INCR from earlier tiles
                            // leaves ref=2 in framebuffer pixels and weather draws "masked" worldwide.
                            // Scissor to the tile quad’s screen bounds — a full FBO stencil clear per tile
                            // was tens of clears per frame and dominated pan cost even with cached road VBOs.
                            GlStencilMaskRendererHolder.renderer.clearStencilForWeatherTileScreenBounds(
                                projectionMatrixArray,
                                modelViewMatrixArray,
                                camera.resX,
                                camera.resY,
                            )
                        }
                        stencilBeforeTile?.invoke(
                            meshInfo,
                            projectionMatrixArray,
                            modelViewMatrixArray,
                        )
                        // Stencil / mask code binds other VBOs; restore quad attribs before draw.
                        bindRasterTileVertexAttributes(progPtr)

                        datelineAdjustment(meshInfo)
                        val hashKey = resolveBoundTextureKey(texHashMap, meshInfo.hashCode, phaseAString)

                        hashKey?.let { resolvedA ->
                            val it = texHashMap[resolvedA] ?: return@let
                            if (weatherDebugMatchesMesh(meshInfo)) {
                                MapsGLDebug.trace("[WeatherDebug][GL] draw exact key=${weatherDebugKey(meshInfo)} phaseA=$phaseAString phaseB=$phaseBString meld=$finalMeld")
                            }

                            if (pr.ON) pr.p(TAG, pr.noLoad, "render() found Ideal for phaseA: ${hashKey}")

                            progPtr.updateTexture1Size(1f, 1f, 0f, 0f)
                            var hash2: String? = resolveBoundTextureKey(texHashMap, meshInfo.hashCode, phaseBString)
                            if (hash2 != null) { //found full version of both textures
                                if (pr.ON) pr.p(TAG, pr.downloadRequest, "h2: $hash2 found, trying to draw!")
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                                currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                //println("$TAG, render() draw $it, ${texHashMap[hash2]}")
                            } else {
                                if (pr.ON) pr.p(TAG, pr.downloadRequest, "h2: ${hash2} NOT FOUND found")
                                hash2 = determinePartial(meshInfo, texHashMap, phaseBString, 2)
                                if (hash2 != null) {
                                    pr.p(TAG, pr.tilePick, "render() A drawing 2 tiles ", 2)
                                    currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                    //println("$TAG, render() draw $it, ${texHashMap[hash2]}")
                                } else if (finalMeld != 1f) {
                                    pr.p(TAG, pr.rasterPart, "render() A drawing 1st tile ", 2)
                                    currentMesh?.draw(it)
                                    //println("$TAG, render() draw $it")
                                } else {
                                    pr.p(
                                        TAG,
                                        pr.rasterPart,
                                        "render() A wanted to draw last tile, can only find first: ",
                                        2
                                    )
                                    //println("$TAG, render() draw $it")
                                    currentMesh?.draw(it)
                                }
                            }
                        } ?: run { //Display lower-res texture if available. Also accounts for world-wrap


                            if (pr.ON) pr.p(TAG, pr.noLoad, "render() DID NOT find Ideal for phaseA: ${hashKey}")

                            val meshString1 = determinePartial(meshInfo, texHashMap, phaseAString, 1)

                            var meshString2: String? =
                                resolveBoundTextureKey(texHashMap, meshInfo.hashCode, phaseBString)
                            if (meshString2 == null) { // if exact tile not found, use partial
                                meshString2 = determinePartial(meshInfo, texHashMap, phaseBString, 2)
                            } else {
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                            }
                            if (meshString1 != null) {
                                if (meshString2 != null) {
                                    if (weatherDebugMatchesMesh(meshInfo)) {
                                        MapsGLDebug.trace("[WeatherDebug][GL] draw partial+exact key=${weatherDebugKey(meshInfo)} a=$meshString1 b=$meshString2 meld=$finalMeld")
                                    }
                                    if (pr.ON) pr.p(TAG, pr.rasterPart, "B1 draw 2")
                                    currentMesh?.draw2Textures(texHashMap[meshString1]!!, texHashMap[meshString2]!!)
                                } else {
                                    if (texHashMap.containsKey(meshString1)) {
                                        if (weatherDebugMatchesMesh(meshInfo)) {
                                            MapsGLDebug.trace("[WeatherDebug][GL] draw partial-only key=${weatherDebugKey(meshInfo)} a=$meshString1 meld=$finalMeld")
                                        }
                                        pr.p(TAG, pr.rasterPart, "render() B2 drawing 1st tile ", 2)
                                        currentMesh?.draw(texHashMap[meshString1]!!)
                                    } else {
                                    }
                                }
                            } else { // Used in case of the timeline being all the way at the right end, just draw the last interval
                                if (texHashMap[meshString2] != null) {
                                    if (weatherDebugMatchesMesh(meshInfo)) {
                                        MapsGLDebug.trace("[WeatherDebug][GL] draw phaseB fallback key=${weatherDebugKey(meshInfo)} b=$meshString2 meld=$finalMeld")
                                    }
                                    if (finalMeld == 1f) {
                                        determinePartial(
                                            meshInfo,
                                            texHashMap,
                                            phaseBString,
                                            1
                                        ) // 250424 fix for raster tiles when meld is 1.0
                                    }
                                    currentMesh?.draw2Textures(texHashMap[meshString2]!!, texHashMap[meshString2]!!)
                                } else {
                                    if (weatherDebugMatchesMesh(meshInfo)) {
                                        MapsGLDebug.trace("[WeatherDebug][GL] no drawable texture key=${weatherDebugKey(meshInfo)} phaseA=$phaseAString phaseB=$phaseBString meld=$finalMeld")
                                    }
                                    pr.p(TAG, pr.flicker, "render() NOT DRAWING ANYTHING", 2)
                                }
                            }
                        } // end run
                        stencilAfterTile?.invoke()
                    } // MATCH TOUCH TILE
                } // end for each

            }      // end if(phaseA < Timeline.times!!.size){


            progPtr.unbind()
        } // end  if (meshes != null && meshes!!.isNotEmpty()) {
        //if(pr.ON)pr.p(TAG, pr.trackRender,"render() exited")
    } // end render()

    private fun determinePartial(
        meshInfo: MeshInfo,
        texHashMap: HashMap<String, Int>,
        currentPhaseString: String,
        textureNumber: Int
    ): String? {
        // A parent's fold is the aggregate over a different footprint. Using it as a stand-in
        // then replacing it with the child is a visible pulse on a max layer.
        if (Timeline.foldedSourceIds.contains(label)) return null
        val startAltDataZoom = floor(meshInfo.z /*- 1*/).toInt()
        val zInt = startAltDataZoom
        val (childX, childY) = meshTileXYForEncodedLookup(meshInfo, zInt)
        altDataZoom = startAltDataZoom
        var partialHashString: String
        while (altDataZoom > -1) {
            if (pr.ON) pr.p(TAG, pr.partial, "render() in the loop, altDataZoom:$altDataZoom")

            // Avoid float rounding drift when walking the mip/partial chain.
            val shift = startAltDataZoom - altDataZoom
            val divisor = 1 shl shift
            newX = Math.floorDiv(childX, divisor)
            newY = Math.floorDiv(childY, divisor)
            //consider trying to give this it's own String, may fix when pulls wrong tile?
            partialHashString = "0:${altDataZoom}/${newX}/${newY}/${currentPhaseString}"
            //if(pr.ON) pr.p(TAG, pr.obs_play, "hashString: ${hashString3}")

            if (texHashMap[partialHashString] != null) {
                val localScale = 1.0f / divisor.toFloat()
                updateTextureSizes(meshInfo, localScale, newX, newY, textureNumber)
                return partialHashString as String
            } else {
                altDataZoom--
            }
        }
        return null
    }

    /** Used to calculate the scale value for the texture in the shader. Used for tile partial scaling **/
    open fun updateTextureSizes(mInfo: MeshInfo, scale: Float, nX: Int, nY: Int, textureNumber: Int) {
        if (scale >= 1f - 1e-5f) {
            if (textureNumber == 1) {
                progPtr.updateTexture1Size(1f, 1f, 0f, 0f)
            } else {
                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
            }
            return
        }
        // Offset is the child tile's origin within the parent, in parent tile-UV [0, 1].
        // Must stay in [0, 1 - scale]; wrapping with ±1 (old dateline hack) misplaces samples
        // near parent edges and causes a visible horizontal jump when the exact tile replaces a partial.
        val divisor = (1f / scale).toInt().coerceAtLeast(1)
        val maxOff = (1f - scale).coerceAtLeast(0f)
        // [nX]/[nY] come from the wrapped child column ([meshTileXYForEncodedLookup]); measure the
        // child against them in the same wrapped space. [MeshInfo.x] itself carries the world copy,
        // so a tile just west of the antimeridian (x = -1) would otherwise clamp to offset 0.
        val (childX, childY) = meshTileXYForEncodedLookup(mInfo, mInfo.z.toInt())
        val xOffs = ((childX - nX * divisor) / divisor.toFloat()).coerceIn(0f, maxOff)
        val yOffs = ((childY - nY * divisor) / divisor.toFloat()).coerceIn(0f, maxOff)
        if (textureNumber == 1) {
            progPtr.updateTexture1Size(scale, scale, xOffs, yOffs)
        } else {
            progPtr.updateTexture2Size(scale, scale, xOffs, yOffs)
        }
    }

    /** Puts a given Matrix4 into a given FloatArray
     * @return FloatArray
     */
    open fun matrixToFloatArray(m: Matrix4, r: FloatArray): FloatArray { //reuse existing array
        r[0] = m.elements[0]; r[1] = m.elements[1]; r[2] = m.elements[2]; r[3] = m.elements[3]
        r[4] = m.elements[4]; r[5] = m.elements[5]; r[6] = m.elements[6]; r[7] = m.elements[7]
        r[8] = m.elements[8]; r[9] = m.elements[9]; r[10] = m.elements[10]; r[11] = m.elements[11]
        r[12] = m.elements[12]; r[13] = m.elements[13]; r[14] = m.elements[14]; r[15] = m.elements[15]
        return r
    }

    private fun checkError(cmd: String? = null) {
        if (MapsGLDebug.enabled) {
            when (val error = GLES31.glGetError()) {
                GLES31.GL_NO_ERROR -> {/*println("TAG $cmd -> no error")*/
                }

                GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM")
                GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                else -> throw RuntimeException("$cmd -> error in gl: $error")
            }
        }
    }

    /**
     * Finds the two values in a sorted list that a target value falls between,
     * and calculates the fractional distance between them.
     *
     * @param targetValue The long value to locate within the list.
     * @param sortedList The sorted list of longs to search within.
     * @return An [InterpolationResult] containing the lower and upper bound values and the fraction (0.0f to 1.0f).
     *         Returns null if the list has fewer than two elements or the target is outside the list's range.
     */
    open fun findInterpolationValues(targetValue: Long, sortedList: List<Long>): InterpolationResult? {
        // We need at least two points to form a range.
        if (sortedList.size < 2) {
            return null
        }

        // Use binarySearch to find the index or the insertion point.
        val searchResult = sortedList.binarySearch(targetValue)

        if (searchResult >= 0) {
            // Exact match found. The value is exactly on a point, so the fraction is 0.
            val value = sortedList[searchResult]
            return InterpolationResult(value, value, 0.0f, searchResult, searchResult)
        }

        // The value was not found. Convert the negative searchResult to an insertion point.
        val insertionPoint = -(searchResult + 1)

        // Handle edge cases: target is outside the entire range of the list.
        if (insertionPoint == 0 || insertionPoint == sortedList.size) {
            return null // Target is before the first element or after the last one.
        }

        // The target is between two elements.
        val lowerIndex = insertionPoint - 1
        val upperIndex = insertionPoint
        val lowerBound = sortedList[lowerIndex]
        val upperBound = sortedList[upperIndex]

        // Prevent division by zero if the bounds are identical.
        val range = (upperBound - lowerBound).toFloat()
        if (range == 0f) {
            return InterpolationResult(lowerBound, upperBound, 0.0f, lowerIndex, upperIndex)
        }

        // Calculate the fractional position of the target within the range.
        val position = (targetValue - lowerBound).toFloat()
        val fraction = position / range

        return InterpolationResult(
            lowerBound,
            upperBound,
            fraction.coerceIn(0.0f, 1.0f),
            lowerIndex,
            upperIndex
        )
    }

    protected data class LayerDrawPhases(val phaseA: String, val phaseB: String, val meld: Float)

    protected fun meshInfoToTileHashShort(meshInfo: MeshInfo): String {
        val zInt = meshInfo.z.toInt()
        val nx = normalizedTileXForTextureHash(meshInfo)
        return "0:$zInt/$nx/${meshInfo.y.toInt()}"
    }

    protected fun meshInfoToExactHashKey(meshInfo: MeshInfo, phaseString: String): String {
        return "${meshInfoToTileHashShort(meshInfo)}/$phaseString"
    }

    /**
     * `texHashMap` key for [tilePrefix] + [phaseString], including ISO aliases (`Z` vs `+00:00`).
     * MapsGL JS indexes `tileData.getData(interval)` by instant; Android keys are the raw
     * valid-time text, so a playhead string that does not match the fold's wrapper misses and
     * the sampler keeps the last uploaded (end-of-range) fold until one hour matches.
     */
    protected fun resolveBoundTextureKey(
        texHashMap: HashMap<String, Int>,
        tilePrefix: String,
        phaseString: String,
    ): String? {
        if (phaseString.isEmpty() || tilePrefix.isEmpty()) return null
        for (phase in encodedIntervalKeyAliases(phaseString)) {
            val key = "$tilePrefix$phase"
            if (texHashMap.containsKey(key)) return key
        }
        return null
    }

    protected fun meshInfoHasDrawableTexture(
        meshInfo: MeshInfo,
        phaseString: String,
        texHashMap: HashMap<String, Int>,
    ): Boolean {
        if (phaseString.isEmpty()) return false
        // [render] looks up this exact key before calling [determinePartial]. A folded parent is a
        // different quantity, and [determinePartial] already refuses it — counting ancestors (or
        // an alternate hash [render] never uses) as "ready" advances the shared phase, then the
        // child draws nothing. That is the rectangular hole on a max layer during playback.
        if (resolveBoundTextureKey(texHashMap, meshInfo.hashCode, phaseString) != null) {
            // A leftover GPU slot from a previous series still hashes. After a reset the
            // fold count is 0 until that prefix is folded again — do not treat the leftover
            // as ready or the neighbour still on the new series shows a different max.
            if (Timeline.foldedSourceIds.contains(label)) {
                val spatial = meshInfoToTileHashShort(meshInfo)
                val count = Timeline.operationFoldedCountByTile[Timeline.operationTileKey(label, spatial)] ?: 0
                if (count <= 0) return false
            }
            return true
        }
        if (Timeline.foldedSourceIds.contains(label)) return false
        if (texHashMap.containsKey(meshInfoToExactHashKey(meshInfo, phaseString))) return true
        val startAltDataZoom = floor(meshInfo.z).toInt()
        var alt = startAltDataZoom
        while (alt > -1) {
            val shift = startAltDataZoom - alt
            val divisor = 1 shl shift
            val nx = normalizedTileXForTextureHash(meshInfo)
            val newX = Math.floorDiv(nx, divisor)
            val newY = Math.floorDiv(meshInfo.y.toInt(), divisor)
            val partialHashString = "0:$alt/$newX/$newY/$phaseString"
            if (texHashMap.containsKey(partialHashString)) return true
            alt--
        }
        return false
    }

    protected fun phasePendingForTile(
        meshInfo: MeshInfo,
        phaseString: String,
    ): Boolean {
        if (phaseString.isEmpty()) return false
        return TileList.pendingList.containsTimeInTile(label, meshInfoToTileHashShort(meshInfo), phaseString)
    }

    protected fun encodedBindPendingForTile(
        sourceId: String?,
        meshInfo: MeshInfo,
        phaseString: String,
    ): Boolean {
        if (sourceId.isNullOrEmpty() || phaseString.isEmpty()) return false
        return Timeline.isEncodedBindPending(
            sourceId,
            meshInfoToTileHashShort(meshInfo),
            phaseString,
        )
    }

    protected fun meshReadyForTargetPhase(
        meshInfo: MeshInfo,
        phaseString: String,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
    ): Boolean {
        if (phaseString.isEmpty()) return false
        // GPU-resident textures are drawable even if pending bookkeeping has not cleared yet.
        if (meshInfoHasDrawableTexture(meshInfo, phaseString, texHashMap)) return true
        if (phasePendingForTile(meshInfo, phaseString)) return false
        if (encodedBindPendingForTile(sourceId, meshInfo, phaseString)) return false
        return false
    }

    protected fun allViewportMeshesReadyForPhase(
        viewportMeshes: List<MeshInfo>,
        phaseString: String,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
    ): Boolean {
        if (phaseString.isEmpty() || viewportMeshes.isEmpty()) return false
        // Timeline rule: while playing, a layer must not treat an interval as ready until
        // *every* visible tile for that interval is loaded. Partial readiness raced the clock.
        return viewportMeshes.all { mesh ->
            meshReadyForTargetPhase(mesh, phaseString, texHashMap, sourceId)
        }
    }

    protected fun allViewportMeshesReadyForAnimation(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        targetPhaseA: String,
        targetPhaseB: String,
        targetMeld: Float,
    ): Boolean {
        if (viewportMeshes.isEmpty()) return true
        val interpolating = targetMeld > 0f && targetMeld < 1f && targetPhaseA != targetPhaseB
        return if (interpolating) {
            allViewportMeshesReadyForPhase(viewportMeshes, targetPhaseA, texHashMap, sourceId) &&
                allViewportMeshesReadyForPhase(viewportMeshes, targetPhaseB, texHashMap, sourceId)
        } else {
            val phase = if (targetMeld <= 0f) targetPhaseA else targetPhaseB
            allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId)
        }
    }

    /**
     * Defensively copies [source] into an immutable [List]. The backing list may live on
     * [LayerTimeline] or [Timeline] and be mutated off the GL render thread (insertions in
     * [com.xweather.mapsgl.tiles.TilePyramid], clear/refresh in
     * [LayerTimeline.refreshSparseLists]). Iterating it directly here races and can throw
     * [ConcurrentModificationException] or [IndexOutOfBoundsException]. Retry once on
     * concurrent change; fall back to empty if we still cannot get a stable copy.
     */
    private fun <T> safeSnapshotInterval(source: List<T>): List<T> {
        repeat(2) {
            try {
                return ArrayList(source)
            } catch (_: ConcurrentModificationException) {
            } catch (_: IndexOutOfBoundsException) {
            } catch (_: ArrayIndexOutOfBoundsException) {
            } catch (_: NullPointerException) {
            }
        }
        return emptyList()
    }

    /** Timeline lists are epoch seconds; some callers pass millis. Do not mix them in `>`. */
    private fun epochSeconds(epoch: Long): Long =
        if (epoch > 1_000_000_000_000L) epoch / 1000L else epoch

    /**
     * Latest interval (chronological, at or before [targetLong]) where every viewport tile is ready.
     */
    protected fun findLatestViewportCompletePhaseAtOrBefore(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
        targetLong: Long,
    ): String? {
        var latest: String? = null
        val size = minOf(intervalStrings.size, intervalLongs.size)
        val targetSec = epochSeconds(targetLong)
        for (i in 0 until size) {
            val timeLong = intervalLongs.getOrNull(i) ?: break
            if (epochSeconds(timeLong) > targetSec) continue
            val phase = intervalStrings.getOrNull(i) ?: break
            if (phase.isNotEmpty() &&
                allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId) &&
                allViewportMeshesShareFold(viewportMeshes, sourceId, i + 1)
            ) {
                latest = phase
            }
        }
        return latest
    }

    /**
     * Latest interval at or before [targetLong] that *any* viewport tile can draw as a fold
     * of that prefix. Neighbours still loading stay blank. Requiring every mesh — including
     * ocean 404s that never fold — kept the whole screen empty until the slowest tile finished.
     */
    protected fun findLatestDrawableFoldedPhaseAtOrBefore(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
        targetLong: Long,
    ): String? {
        var latest: String? = null
        val size = minOf(intervalStrings.size, intervalLongs.size)
        val targetSec = epochSeconds(targetLong)
        for (i in 0 until size) {
            val timeLong = intervalLongs.getOrNull(i) ?: break
            if (epochSeconds(timeLong) > targetSec) continue
            val phase = intervalStrings.getOrNull(i) ?: break
            if (phase.isEmpty()) continue
            val anyReady = viewportMeshes.any { mesh ->
                if (!meshInfoHasDrawableTexture(mesh, phase, texHashMap)) return@any false
                if (sourceId.isNullOrEmpty()) return@any true
                val key = Timeline.operationTileKey(sourceId, meshInfoToTileHashShort(mesh))
                val count = Timeline.operationFoldedCountByTile[key] ?: 0
                count >= i + 1
            }
            if (anyReady) latest = phase
        }
        return latest
    }

    /**
     * Same series and the same prefix length. A GPU hit on a time key is not enough: one tile
     * can be the 48-hour max at that instant while its neighbour is a 12-hour max.
     */
    private fun allViewportMeshesShareFold(
        viewportMeshes: List<MeshInfo>,
        sourceId: String?,
        minFoldedCount: Int,
    ): Boolean {
        if (sourceId.isNullOrEmpty() || !Timeline.foldedSourceIds.contains(sourceId)) return true
        if (viewportMeshes.isEmpty()) return false
        var series: Int? = null
        for (mesh in viewportMeshes) {
            val key = Timeline.operationTileKey(sourceId, meshInfoToTileHashShort(mesh))
            val sid = Timeline.operationSeriesByTile[key] ?: return false
            if (series == null) series = sid else if (sid != series) return false
            val count = Timeline.operationFoldedCountByTile[key] ?: 0
            if (count < minFoldedCount) return false
        }
        return true
    }

    protected fun displayPhaseForTarget(targetPhaseA: String, targetPhaseB: String, targetMeld: Float): String {
        return if (targetMeld <= 0f) targetPhaseA else targetPhaseB
    }

    /** True if at least one viewport tile has a bound texture for [phaseString] (ignores pending flags). */
    protected fun anyViewportMeshHasDrawablePhase(
        viewportMeshes: List<MeshInfo>,
        phaseString: String,
        texHashMap: HashMap<String, Int>,
    ): Boolean {
        if (phaseString.isEmpty()) return false
        return viewportMeshes.any { mesh ->
            meshInfoHasDrawableTexture(mesh, phaseString, texHashMap)
        }
    }

    /** Latest viewport-complete interval in [intervalStrings] (any time). */
    protected fun findLatestViewportCompletePhase(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        intervalStrings: List<String>,
    ): String? {
        var latest: String? = null
        for ((i, phase) in intervalStrings.withIndex()) {
            if (phase.isNotEmpty() &&
                allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId) &&
                allViewportMeshesShareFold(viewportMeshes, sourceId, i + 1)
            ) {
                latest = phase
            }
        }
        return latest
    }

    /**
     * Subset of [intervalStrings] / [intervalLongs] whose tiles are fully viewport-ready.
     * Used so playback can keep advancing through loaded intervals instead of freezing on one
     * while waiting for the global target's exact pair to finish downloading.
     */
    protected data class ReadyPlaybackList(val strings: List<String>, val longs: List<Long>)

    protected fun buildReadyPlaybackList(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
    ): ReadyPlaybackList {
        val size = minOf(intervalStrings.size, intervalLongs.size)
        if (size == 0) return ReadyPlaybackList(emptyList(), emptyList())
        val strings = ArrayList<String>(size)
        val longs = ArrayList<Long>(size)
        for (i in 0 until size) {
            val phase = intervalStrings.getOrNull(i) ?: break
            val timeLong = intervalLongs.getOrNull(i) ?: break
            if (phase.isEmpty()) continue
            if (allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId) &&
                allViewportMeshesShareFold(viewportMeshes, sourceId, i + 1)
            ) {
                strings.add(phase)
                longs.add(timeLong)
            }
        }
        return ReadyPlaybackList(strings, longs)
    }

    /**
     * Builds draw phases from the viewport-ready interval subset for the current [targetLong],
     * letting the layer animate through loaded frames while the global timeline advances.
     */
    protected fun drawPhasesFromReadyList(
        ready: ReadyPlaybackList,
        targetLong: Long,
    ): LayerDrawPhases? {
        if (ready.strings.isEmpty()) return null
        if (ready.strings.size == 1) {
            val only = ready.strings.first()
            return LayerDrawPhases(only, only, 0f)
        }
        if (targetLong <= ready.longs.first()) {
            val first = ready.strings.first()
            return LayerDrawPhases(first, first, 0f)
        }
        if (targetLong >= ready.longs.last()) {
            val last = ready.strings.last()
            return LayerDrawPhases(last, last, 0f)
        }
        var lower = 0
        for (i in 1 until ready.longs.size) {
            if (ready.longs[i] > targetLong) {
                lower = i - 1
                break
            }
            lower = i
        }
        val upper = (lower + 1).coerceAtMost(ready.longs.lastIndex)
        if (lower == upper) {
            val phase = ready.strings[lower]
            return LayerDrawPhases(phase, phase, 0f)
        }
        val lowerLong = ready.longs[lower]
        val upperLong = ready.longs[upper]
        val range = (upperLong - lowerLong).toFloat()
        val meld = if (range <= 0f) {
            0f
        } else {
            ((targetLong - lowerLong).toFloat() / range).coerceIn(0f, 1f)
        }
        return LayerDrawPhases(ready.strings[lower], ready.strings[upper], meld)
    }

    /**
     * Freezes this layer on a viewport-complete covering interval until **all** timeline intervals
     * needed for looping playback have every visible tile loaded. Global clock keeps advancing;
     * this layer does not animate (crossfade / advance) until that full set is ready.
     */
    protected fun applyLayerViewportPlayback(
        layerInfo: LayerTimeline,
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
    ): LayerDrawPhases {
        val target = layerInfo.computeGlobalAnimationTarget()
        val retainPhases = layerInfo.retainPhaseCandidates()
        // The interval list driving draw-phase resolution (ready-list building, hold-phase
        // resolution, target interpolation) must match what [TilePyramid.filterTimelineByValidTimes]
        // actually requests during playback — the closest layer-valid-time per *global* timeline
        // step (reqStrings/reqLongs) — not the layer's full native-resolution valid-time list
        // ([LayerTimeline.playbackTimeStrings], which can be far finer-grained, e.g. 136 native
        // intervals vs. 41 playback steps for a 5-day range). [computeGlobalAnimationTarget] picks
        // target.phaseA/phaseB from that same native list, so an exact-match texture lookup for it
        // (`allViewportMeshesReadyForAnimation`) almost always misses — nothing outside the coarse
        // 41-tick grid is ever downloaded. That's fine (the interpolation fallback inside
        // [resolveLayerViewportDrawPhases] handles it), *except* that function independently computes
        // its own "neededIntervals" from whatever interval list it's handed — if that's still the
        // native list, `readyCount (41) >= neededIntervals (136)` is never true, so it takes the
        // hold-forever branch regardless of the caller's own (correctly computed) readiness. Passing
        // the coarse, correct list here fixes both call sites at once.
        //
        // reqStrings/reqLongs have three independent writers in TilePyramid (the main global-tick
        // loop, the idle/scrub fallback, and the paused/scrub-rebind path) that can race a range
        // change or play-start: an in-flight coroutine from an earlier grid/viewport state can
        // insert an orphan entry that no longer corresponds to any tick the current grid will ever
        // select again, permanently blocking full-range-ready. Every insertion is tagged with
        // [Timeline.reqGeneration] at write time (see its doc comment) — filter to only the
        // current generation here so stale entries are ignored regardless of insertion order.
        val requestedGenerations = safeSnapshotInterval(layerInfo.reqGenerations)
        val currentGeneration = Timeline.reqGeneration
        // While coarse playback is active, the background pass-2 prefetch resolves its own
        // (temporally interleaved via addInOrder, not appended) set of intervals into this same
        // layer's reqStrings/reqLongs/reqGenerations under the *same* generation tag (the swap
        // deliberately doesn't bump generation — see maybeUpgradeToFullGridAtLoopBoundary). Left
        // unfiltered, neededIntervals below balloons to include those not-yet-needed pass-2
        // entries the moment prefetch starts, freezing the coarse loop until pass 2 finishes even
        // though coarse playback never needed them. reqIsPass2 (tagged at insertion time, see
        // TilePyramid.matchTimesToLayerValidTimes) lets us exclude pass-2 entries while still coarse.
        val requestedIsPass2 = safeSnapshotInterval(layerInfo.reqIsPass2)
        val stillCoarse = Timeline.isCoarsePlayback
        val intervalStrings = ArrayList<String>()
        val intervalLongs = ArrayList<Long>()
        if (Timeline.foldedSourceIds.contains(layerInfo.id)) {
            // The aggregator folds the product's full valid-time list. reqStrings often only
            // holds the playhead hour, so searching that list cannot see the prefix already
            // on the GPU and the screen stays blank until the last chunk of every tile.
            val (longs, strings) = layerInfo.playbackTimeListsSnapshot()
            intervalStrings.addAll(strings)
            intervalLongs.addAll(longs)
        } else {
            val allStrings = safeSnapshotInterval(layerInfo.reqStrings)
            val allLongs = safeSnapshotInterval(layerInfo.reqLongs)
            val size = minOf(allStrings.size, allLongs.size, requestedGenerations.size, requestedIsPass2.size)
            for (i in 0 until size) {
                if (requestedGenerations[i] == currentGeneration && !(stillCoarse && requestedIsPass2[i])) {
                    intervalStrings.add(allStrings[i])
                    intervalLongs.add(allLongs[i])
                }
            }
        }
        val resolved = resolveLayerViewportDrawPhases(
            viewportMeshes = viewportMeshes,
            texHashMap = texHashMap,
            sourceId = layerInfo.id,
            target = target,
            intervalStrings = intervalStrings,
            intervalLongs = intervalLongs,
            retainPhases = retainPhases,
        )
        val displayReady = allViewportMeshesReadyForAnimation(
            viewportMeshes,
            texHashMap,
            layerInfo.id,
            resolved.phaseA,
            resolved.phaseB,
            resolved.meld,
        )
        val neededIntervals = intervalStrings.count { it.length > 4 }
        val readyCount = buildReadyPlaybackList(
            viewportMeshes,
            texHashMap,
            layerInfo.id,
            intervalStrings,
            intervalLongs,
        ).strings.size
        // Playing + still downloading any interval in the range → not ready to animate yet.
        val fullRangeReady =
            !Timeline.isGloballyPlaying ||
                neededIntervals == 0 ||
                readyCount >= neededIntervals
        val playbackReady = displayReady && fullRangeReady
        val holdPhase = if (playbackReady) {
            null
        } else if (Timeline.foldedSourceIds.contains(layerInfo.id)) {
            // Hourly hold can fall back to the latest complete interval *anywhere* in the
            // range. On a running max that is the end-of-range total; storing it as the retain
            // candidate makes the next wrap (or a gap in early tiles) flash that total.
            resolved.phaseA.takeIf { it.isNotEmpty() }
        } else {
            resolveViewportHoldPhase(
                viewportMeshes,
                texHashMap,
                layerInfo.id,
                target,
                intervalStrings,
                intervalLongs,
                retainPhases,
            )
        }
        layerInfo.commitDisplayPhases(
            resolved.phaseA,
            resolved.phaseB,
            resolved.meld,
            playbackReady,
            holdPhase,
        )
        if (layerInfo.updateStaggeredPlaybackState { phase ->
                allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, layerInfo.id)
            }
        ) {
            // Fill pass downloads odd intervals in the background; only schedule while playing so
            // pausing does not immediately enqueue a new HTTP wave the user did not ask for.
            if (Timeline.isGloballyPlaying) {
                Timeline.requestStaggeredFillDownload(layerInfo.id)
            }
        }
        return resolved
    }

    /**
     * Keeps the frame the user was already seeing (e.g. timeline stopped on a loaded interval)
     * instead of blanking while a new target loads.
     */
    protected fun pickDrawableRetainPhase(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        retainPhases: List<String>,
    ): String? {
        for (phase in retainPhases) {
            if (phase.isEmpty()) continue
            if (allViewportMeshesReadyForPhase(viewportMeshes, phase, texHashMap, sourceId) ||
                anyViewportMeshHasDrawablePhase(viewportMeshes, phase, texHashMap)
            ) {
                return phase
            }
        }
        return null
    }

    protected fun resolveViewportHoldPhase(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        target: LayerAnimationTarget,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
        retainPhases: List<String>,
    ): String? {
        pickDrawableRetainPhase(viewportMeshes, texHashMap, sourceId, retainPhases)?.let { return it }

        if (Timeline.isAtEndPosition()) {
            val displayPhase = displayPhaseForTarget(target.phaseA, target.phaseB, target.meld)
            if (allViewportMeshesReadyForPhase(viewportMeshes, displayPhase, texHashMap, sourceId)) {
                return displayPhase
            }
            if (anyViewportMeshHasDrawablePhase(viewportMeshes, displayPhase, texHashMap)) {
                return displayPhase
            }
            // Last interval not drawable yet — keep the latest frame we can actually show.
            return findLatestViewportCompletePhaseAtOrBefore(
                viewportMeshes,
                texHashMap,
                sourceId,
                intervalStrings,
                intervalLongs,
                target.targetLong,
            ) ?: findLatestViewportCompletePhase(viewportMeshes, texHashMap, sourceId, intervalStrings)
        }
        return findLatestViewportCompletePhaseAtOrBefore(
            viewportMeshes,
            texHashMap,
            sourceId,
            intervalStrings,
            intervalLongs,
            target.targetLong,
        ) ?: findLatestViewportCompletePhase(viewportMeshes, texHashMap, sourceId, intervalStrings)
    }

    /**
     * Per-layer viewport gating: global timeline keeps advancing, but while this layer still has
     * intervals downloading it must **not** animate — hold a covering complete interval until
     * every playback interval has all visible tiles loaded, then follow the playhead.
     */
    protected fun resolveLayerViewportDrawPhases(
        viewportMeshes: List<MeshInfo>,
        texHashMap: HashMap<String, Int>,
        sourceId: String?,
        target: LayerAnimationTarget,
        intervalStrings: List<String>,
        intervalLongs: List<Long>,
        retainPhases: List<String>,
    ): LayerDrawPhases {
        if (viewportMeshes.isEmpty()) {
            return LayerDrawPhases(target.phaseA, target.phaseB, target.meld)
        }
        val ready = buildReadyPlaybackList(
            viewportMeshes,
            texHashMap,
            sourceId,
            intervalStrings,
            intervalLongs,
        )
        // A folded layer's later interval is a *later running result*, not a blurrier version of
        // the current one. The hourly hold — freeze on the latest complete frame until every
        // interval is on the GPU — therefore shows the end-of-range max, then jumps back to the
        // playhead when the rest of the series binds. That jump lands near mid-timeline, which is
        // when the last tiles typically finish. Follow the playhead through folded frames only.
        if (sourceId != null && Timeline.foldedSourceIds.contains(sourceId)) {
            // Draw the latest prefix any tile has folded. Waiting for every visible tile
            // (including ones that 404) left the map blank for the whole series.
            val hold = findLatestDrawableFoldedPhaseAtOrBefore(
                viewportMeshes,
                texHashMap,
                sourceId,
                intervalStrings,
                intervalLongs,
                target.targetLong,
            )
            return if (hold != null) {
                LayerDrawPhases(hold, hold, 0f)
            } else {
                // Do not fall back to target.phaseA: that key usually misses, and the sampler
                // keeps the last uploaded fold (end-of-range max). JS draws the interval or
                // nothing — never a later frame's leftover.
                LayerDrawPhases("", "", 0f)
            }
        }
        val neededIntervals = intervalStrings.count { it.length > 4 }
        val fullRangeReady = neededIntervals == 0 || ready.strings.size >= neededIntervals

        // Timeline rule: while playing and still waiting on tiles, do not animate through a
        // partial ready list — freeze on a covering complete interval until the full set loads.
        if (Timeline.isGloballyPlaying && neededIntervals > 0 && !fullRangeReady) {
            val holdPhase = resolveViewportHoldPhase(
                viewportMeshes,
                texHashMap,
                sourceId,
                target,
                intervalStrings,
                intervalLongs,
                retainPhases,
            ) ?: ready.strings.lastOrNull()
            if (!holdPhase.isNullOrEmpty()) {
                return LayerDrawPhases(holdPhase, holdPhase, 0f)
            }
            pickDrawableRetainPhase(viewportMeshes, texHashMap, sourceId, retainPhases)?.let { retained ->
                return LayerDrawPhases(retained, retained, 0f)
            }
            val displayTarget = displayPhaseForTarget(target.phaseA, target.phaseB, target.meld)
            if (anyViewportMeshHasDrawablePhase(viewportMeshes, displayTarget, texHashMap)) {
                return LayerDrawPhases(displayTarget, displayTarget, 0f)
            }
            return LayerDrawPhases(target.phaseA, target.phaseB, 0f)
        }

        if (allViewportMeshesReadyForAnimation(
                viewportMeshes,
                texHashMap,
                sourceId,
                target.phaseA,
                target.phaseB,
                target.meld,
            )
        ) {
            return LayerDrawPhases(target.phaseA, target.phaseB, target.meld)
        }
        drawPhasesFromReadyList(ready, target.targetLong)?.let { readyPhases ->
            return readyPhases
        }
        val holdPhase = resolveViewportHoldPhase(
            viewportMeshes,
            texHashMap,
            sourceId,
            target,
            intervalStrings,
            intervalLongs,
            retainPhases,
        )
        if (holdPhase.isNullOrEmpty()) {
            pickDrawableRetainPhase(viewportMeshes, texHashMap, sourceId, retainPhases)?.let { retained ->
                return LayerDrawPhases(retained, retained, 0f)
            }
            val displayTarget = displayPhaseForTarget(target.phaseA, target.phaseB, target.meld)
            if (anyViewportMeshHasDrawablePhase(viewportMeshes, displayTarget, texHashMap)) {
                return LayerDrawPhases(displayTarget, displayTarget, 0f)
            }
            return LayerDrawPhases(target.phaseA, target.phaseB, 0f)
        }
        return LayerDrawPhases(holdPhase, holdPhase, 0f)
    }

    /**
     * Shared, process-wide state and constants for the unit-quad VBOs every [RenderPass] (and its
     * raster-tile subclasses) draws through: the vertex/texture-coordinate buffers, their cached
     * GL buffer names, and [bindRasterTileVertexAttributes] to bind them for a draw call.
     */
    companion object {
        /**
         * Checks if a `Mesh` element conforms to the given `GeometryVertexElementLayout`.
         */
        private fun meshesElementConforms(element: Mesh /*geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
            //return element.geometry.vertexElementLayout == geometryVertexElementLayout
            return true
        }

        /**
         * Checks if all `Mesh` elements conform to the given `GeometryVertexElementLayout`.
         */
        private fun meshesElementsConform(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
            //return elements.all { meshesElementConforms(it, geometryVertexElementLayout) }
            return true
        }

        /**
         * Filters out `Mesh` elements that do not conform to the given `GeometryVertexElementLayout`.
         */
        private fun conformingMeshesElements(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): List<Mesh>? {
            //return elements.filter { meshesElementConforms(it, geometryVertexElementLayout) }
            return null
        }

        private const val TAG = "RenderPass"
        // Comma-separated "z/x/y" weather tiles to trace draw decisions.
        private const val WEATHER_DEBUG_TARGETS = "6/19/21,6/19/22,6/20/21,6/20/22,6/19/23,6/20/23"
        private const val BYTES_PER_FLOAT = 4
        /** Number of `Float` components per vertex position (x, y) in the shared raster tile quad. */
        const val COORDS_PER_VERTEX = 2
        private const val NUM_TILES = 1
        private const val VERTEX_COUNT = NUM_TILES * 4
        /** Byte stride between consecutive vertex positions in [vertexBuffer], as passed to `glVertexAttribPointer`. */
        const val VERTEX_STRIDE = COORDS_PER_VERTEX * BYTES_PER_FLOAT
        /** Number of `Float` components per texture coordinate (u, v) in the shared raster tile quad. */
        const val TEXTURE_SIZE = 2
        /** Byte stride between consecutive texture coordinates in [textureCoordinatesBuffer], as passed to `glVertexAttribPointer`. */
        const val TEXTURE_STRIDE = TEXTURE_SIZE * BYTES_PER_FLOAT
        //private var textureAlpha = .5f

        // ReentrantLock, not synchronized: called on every raster tile draw, from inside large
        // render-pass methods — the shape that has already caused an R8/ART VerifyError on some
        // devices for a different lock elsewhere in this codebase.
        private val rasterQuadVboLock = ReentrantLock()
        private var rasterQuadPosVbo: Int = 0
        private var rasterQuadTexVbo: Int = 0

        /**
         * EGL context the cached [rasterQuadPosVbo] / [rasterQuadTexVbo] handles were generated in.
         * GL buffer names are scoped to their owning context, so a second `MapView` (e.g. in
         * another activity) seeing the cached integers will bind something unrelated — typically a
         * Mapbox-owned buffer — and tile draws read garbage vertex data, making the layer invisible
         * even though basemap tiles render normally. Re-allocate whenever the current context
         * differs from this snapshot. We do *not* rely on [notifyRasterQuadVbosContextLost] alone:
         * Mapbox v11 preserves the old context across activity pause and only fires `contextLost`
         * on view detach, which is too late.
         */
        private var rasterQuadVboContext: EGLContext? = null

        /** GLES3 requires VBO-backed attributes for the unit quad used by raster/sample layers. */
        fun bindRasterTileVertexAttributes(prog: RasterTileProgram) {
            rasterQuadVboLock.withLock {
                val currentContext = EGL14.eglGetCurrentContext()
                val sameContext = rasterQuadPosVbo != 0
                    && rasterQuadVboContext != null
                    && rasterQuadVboContext == currentContext
                    && currentContext != EGL14.EGL_NO_CONTEXT
                if (!sameContext) {
                    val ids = IntArray(2)
                    GLES31.glGenBuffers(2, ids, 0)
                    rasterQuadPosVbo = ids[0]
                    rasterQuadTexVbo = ids[1]
                    rasterQuadVboContext = currentContext
                    val posBytes = VERTEX_COUNT * COORDS_PER_VERTEX * BYTES_PER_FLOAT
                    GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, rasterQuadPosVbo)
                    vertexBuffer.position(0)
                    GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, posBytes, vertexBuffer, GLES31.GL_STATIC_DRAW)
                    val texBytes = VERTEX_COUNT * TEXTURE_SIZE * BYTES_PER_FLOAT
                    GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, rasterQuadTexVbo)
                    textureCoordinatesBuffer.position(0)
                    GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, texBytes, textureCoordinatesBuffer, GLES31.GL_STATIC_DRAW)
                    GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
                }
            }
            // Stencil renderer uses attribute location 0 and disables it in cleanup.
            // Re-enable both raster attributes before each tile draw to avoid invisible quads.
            GLES31.glEnableVertexAttribArray(prog.positionHandle)
            GLES31.glEnableVertexAttribArray(prog.texPositionHandle)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, rasterQuadPosVbo)
            GLES31.glVertexAttribPointer(
                prog.positionHandle,
                COORDS_PER_VERTEX,
                GLES31.GL_FLOAT,
                false,
                VERTEX_STRIDE,
                0,
            )
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, rasterQuadTexVbo)
            GLES31.glVertexAttribPointer(
                prog.texPositionHandle,
                TEXTURE_SIZE,
                GLES31.GL_FLOAT,
                false,
                TEXTURE_STRIDE,
                0,
            )
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        }

        /** Invalidate cached quad VBO names after EGL/GL context loss (handles are not portable). */
        fun notifyRasterQuadVbosContextLost() {
            rasterQuadVboLock.withLock {
                rasterQuadPosVbo = 0
                rasterQuadTexVbo = 0
                rasterQuadVboContext = null
            }
        }

        private val vertexArray = UnitQuad2DGeometry.genQuad1x1()
        /**
         * Direct, native-order `FloatBuffer` backing the shared unit-quad position VBO used by
         * [bindRasterTileVertexAttributes]; populated once from `vertexArray` in the companion `init` block.
         */
        val vertexBuffer =
            ByteBuffer.allocateDirect(VERTEX_COUNT * COORDS_PER_VERTEX * BYTES_PER_FLOAT).run {
                order(ByteOrder.nativeOrder())// use the device hardware's native byte order
                asFloatBuffer()       // create a floating point buffer from the ByteBuffer
            }
        private val textureArray = UnitQuad2DGeometry.genTexCoords1Quad()
        /**
         * Direct, native-order `FloatBuffer` backing the shared unit-quad texture-coordinate VBO used by
         * [bindRasterTileVertexAttributes]; populated once from `textureArray` in the companion `init` block.
         */
        val textureCoordinatesBuffer = ByteBuffer.allocateDirect(textureArray.size * 4).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }

        init {
            vertexBuffer.apply {
                clear()
                put(vertexArray)
                rewind()
            }

            textureCoordinatesBuffer.apply {
                clear()
                put(textureArray)
                rewind()
                // position(0)
            }
        }
    }

    /**
     * Maps a possibly multi-world tile column [MeshInfo.x] into `[0, n)` for cache/texture hash keys.
     * Single ±n wraps are insufficient (e.g. `x = -8`, `n = 4` stays negative).
     */
    private fun normalizedTileXForTextureHash(mi: MeshInfo): Int {
        val zInt = mi.z.toInt()
        val n = powerTableI[zInt]
        if (n <= 0) return floor(mi.x.toDouble()).toInt()
        var x = floor(mi.x.toDouble()).toInt()
        x %= n
        if (x < 0) x += n
        return x
    }

    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private fun datelineAdjustment(meshInfo: MeshInfo) {
        if (pr.ON) pr.p(
            TAG,
            pr.hashmapLong,
            "datelineAdjustment(), hashString: ${hashString}    meshInfo.hashcode:, ${meshInfo.hashCode}  "
        )
        val n = powerTableI[meshInfo.z.toInt()]
        if (n <= 0) return
        var x = meshInfo.x
        while (x < 0f) x += n
        while (x >= n) x -= n
        // Rule: dateline-world-copy. Wrap the lookup KEY only - never [MeshInfo.x]. That is the
        // tile's world column including its world copy (TileRenderable folds `offset * 2^z` in),
        // and the draw matrix translates by it. Writing the wrapped column back moved the tile
        // west of the antimeridian a whole world away: harmless while this only ran after the
        // tile's matrix was built, but once [render] began normalizing every mesh up front, every
        // encoded layer drew nothing west of 180 with the camera on the line. The partial and
        // stencil lookups ([meshTileXYForEncodedLookup]) wrap X themselves.
        // Keep hash format consistent with `TileCoord.hash()` when time is empty:
        // "wrap:z/x/y/" (note trailing slash).
        meshInfo.hashCode = "0:${meshInfo.z.toInt()}/${x.toInt()}/${meshInfo.y.toInt()}/"
    }


    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private val powerTableI = intArrayOf(
        1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048,
        4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576, 2097152, 4194304
    )
}

/**
 * Number of texture image units available to fragment shaders (`GL_MAX_TEXTURE_IMAGE_UNITS`),
 * queried against GLES30 first and falling back to GLES20 if the GLES30 query is unavailable or errors.
 * @suppress
 */
fun getMaxFragmentTextureUnits(): Int {
    val params = IntArray(1)
    // Try GLES30 first if available, otherwise fallback or assume GLES20 context
    // In a real app, you'd know your GLES context version.
    try {
        GLES30.glGetIntegerv(GLES30.GL_MAX_TEXTURE_IMAGE_UNITS, params, 0)
        if (GLES30.glGetError() == GLES30.GL_NO_ERROR) {
            return params[0]
        }
    } catch (e: Throwable) {
        // GLES30 might not be available or context not 3.0
    }

    // Fallback to GLES20 if GLES30 query failed or not applicable
    GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_IMAGE_UNITS, params, 0)
    return params[0]
}

/**
 * Result of [RenderPass.findInterpolationValues]: the two adjacent values in a sorted list that
 * bracket a target value, plus the fractional position between them.
 *
 * @property lowerBound The list value at or below the target (equal to [upperBound] on an exact match).
 * @property upperBound The list value at or above the target (equal to [lowerBound] on an exact match).
 * @property fraction Fractional distance from [lowerBound] to [upperBound], in `[0, 1]`.
 * @property aInt Index of [lowerBound] in the source list.
 * @property bInt Index of [upperBound] in the source list.
 * @suppress
 */
data class InterpolationResult(
    val lowerBound: Long,
    val upperBound: Long,
    val fraction: Float,
    val aInt: Int,
    val bInt: Int
)