package com.xweather.mapsgl.gl

import android.opengl.GLES20
import android.opengl.GLES30
import android.opengl.GLES31
import android.opengl.Matrix
import android.util.Log
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.util.Map3D
import com.xweather.mapsgl.gl.worldObjects.Mesh
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor

/** Set false to disable [Log] lines tagged [LOG_TAG_TILE_DRAW] in [RenderPass.render]. */
private const val LOG_TILE_DRAW_HASHES = true

/** Logcat filter: `adb logcat -s MapsGLTileDraw` */
private const val LOG_TAG_TILE_DRAW = "MapsGLTileDraw"

/**
 *   RenderPass.kt
 *
 *  A `RenderPass` draws a list of Meshes that share the same `RenderMaterial`/`RenderShader`
 *  and the same `GeometryVertexElementLayout` and thus all can use the same `RenderPipeline`
 *  @author Jason Suto 02/05/24.
 */

open class RenderPass(
    open val label: String,
    open var meshes: List<Mesh>?,
    open var meshInfoList: List<MeshInfo>?
) {

    open var id: String = label
    private var modelMatrixHandle = 0
    private var projectionMatrixHandle = 0
    private val matrixArray = FloatArray(16)
    private val cameraArray = FloatArray(16)
    private val projectionMatrixArray = FloatArray(16)
    private val modelViewMatrixArray = FloatArray(16)
    private val checkErrorString = "glUniformMatrix4fv"
    private val checkErrorUse = "glUseProgram"
    private lateinit var progPtr: RasterTileProgram
    private var currentMesh: Mesh? = null
    private var scale = 1f
    private var newX = 0
    private var newY = 0
    private var altDataZoom = 1
    open val map3D = Map3D<Int, String>()
    open var hashString: String? = null
    open lateinit var sampleStyle: LayerPaint  //RasterStyle //was sampleStyle
    open var debugLast = -1L
    open var lastMeshCount = 0

    // Hysteresis to prevent phase thrashing (and visible tile on/off) while downloads are in-flight.
    // When we enter a "needsFreeze" state, we compute a stable phase once and keep it until
    // the pending condition clears for the visible tile set.
    private var frozenForIncomplete: Boolean = false
    private var lastStablePhaseAString: String? = null
    private var freezeHoldFrames: Int = 0
    private val freezeHoldFramesMax: Int = 6

    //var lastTime = System.currentTimeMillis()-1000L
    open var currentTime = 0L

    open var initialized = false
    private val shouldDisplayRawColors = false

    /**
     * Errors that can occur during the rendering process.
     */
    sealed class Error {
        object MustSupplyAtLeastOneMesh : Error()
        object NewElementsDontMatchVertexDescriptor : Error()
        object CouldntCreateCommandEncoder : Error()
    }

    /**
     * Prepared members of the `RenderPass`.
     */

    constructor(
        label: String = "null",
        paint: LayerPaint //PaintStyle
    ) : this(
        label,
        null,
        null,
    ) {

        if (pr.ON) pr.p(TAG, pr.waaveRenderpath, ">> renderpass label is $label")

        if (paint is ParticleLayerPaint) {
            sampleStyle = paint as ParticleLayerPaint
        } else if (paint is SampleLayerPaint) {
            sampleStyle = paint
        } else {
            sampleStyle = paint as RasterLayerPaint
        }
    }

    /**
     *
     * Should loop through renderables and call draw() on each.
     *
     * Called from TileLayerRenderer.draw()
     *
     */
    open fun render(texHashMap: HashMap<String, Int>, camera: Camera) {
        var phaseAString = ""
        var phaseBString = ""
        var finalMeld = 0f
        val layerInfo = Timeline.sourceTimeHash[label]

        if (layerInfo != null) {
            if (pr.ON) pr.p(TAG, pr.noLoad, "render() layerInfo was NOT null, using layerInfo")

            layerInfo.calcRenderVarFromDownloadedTimes()
            phaseAString = Timeline.getTimeString(0, layerInfo.phaseAString)
            phaseBString = Timeline.getTimeString(1, layerInfo.phaseBString)
            finalMeld = layerInfo.meld
        } else {
            if (pr.ON) pr.p(TAG, pr.noLoad, "render() layerInfo was  null, falling back to TimeLine", 2)
            if (Timeline.currentPhaseA < Timeline.timeStrings.size && Timeline.currentPhaseB < Timeline.timeStrings.size) {
                phaseAString = Timeline.timeStrings[Timeline.currentPhaseA]
                phaseBString = Timeline.timeStrings[Timeline.currentPhaseB]
                finalMeld = Timeline.dataMeld
            }
        }

        if (meshes != null && meshes!!.isNotEmpty()) {
            
            currentMesh = meshes!!.first()

            // If the next interval time-string(s) for this layer are still pending downloads,
            // freeze rendering to the latest fully completed interval <= target.
            // This prevents incomplete A/B interval flicker, while still letting the timeline advance.
            run {
                val layerInfoLocal = Timeline.sourceTimeHash[label]
                val reqLongsLocal = layerInfoLocal?.reqLongs ?: Timeline.timeLongs
                val reqStringsLocal = layerInfoLocal?.reqStrings ?: Timeline.timeStrings

                val meshInfos = meshInfoList
                if (!meshInfos.isNullOrEmpty()) {
                    fun meshInfoToTileHashShort(mi: MeshInfo): String {
                        val zInt = mi.z.toInt()
                        val nx = normalizedTileXForTextureHash(mi)
                        return "0:$zInt/${nx}/${mi.y.toInt()}"
                    }

                    fun meshInfoToExactHashKey(mi: MeshInfo, phaseString: String): String {
                        val zInt = mi.z.toInt()
                        val nx = normalizedTileXForTextureHash(mi)
                        return "0:$zInt/${nx}/${mi.y.toInt()}/$phaseString"
                    }

                    fun meshInfoHasAnyTextureForPhase(
                        mi: MeshInfo,
                        phaseString: String
                    ): Boolean {
                        if (phaseString.isEmpty()) return false

                        // 1) Exact tile
                        if (texHashMap.containsKey(meshInfoToExactHashKey(mi, phaseString))) return true

                        // 2) Partial chain (mirrors determinePartial() hash generation, without GL side-effects)
                        val startAltDataZoom = floor(mi.z).toInt()
                        var alt = startAltDataZoom
                        while (alt > -1) {
                            val shift = startAltDataZoom - alt
                            val divisor = 1 shl shift

                            // determinePartial() uses meshInfo.x after [datelineAdjustment] (in draw loop);
                            // freeze checks run earlier with raw multi-world x — use full modulo here.
                            val nx = normalizedTileXForTextureHash(mi)

                            val newX = Math.floorDiv(nx, divisor)
                            val newY = Math.floorDiv(mi.y.toInt(), divisor)

                            val partialHashString = "0:$alt/$newX/$newY/$phaseString"
                            if (texHashMap.containsKey(partialHashString)) return true
                            alt--
                        }

                        return false
                    }

                    fun phasePendingForAnyVisibleMesh(phaseString: String): Boolean {
                        if (phaseString.isEmpty()) return false
                        return meshInfos.any { mi ->
                            TileList.pendingList.containsTimeInTile(label, meshInfoToTileHashShort(mi), phaseString)
                        }
                    }

                    val interpolating = finalMeld > 0f && finalMeld < 1f && phaseAString != phaseBString
                    val phaseAHasPending = phasePendingForAnyVisibleMesh(phaseAString)
                    val phaseBHasPending = phasePendingForAnyVisibleMesh(phaseBString)

                    // If we can't draw even a partial for the active phase for any visible mesh,
                    // tiles will "pop" (on/off). Treat that as incomplete and freeze.
                    val phaseAHasDrawable = meshInfos.all { mi ->
                        meshInfoHasAnyTextureForPhase(mi, phaseAString)
                    }
                    val phaseBHasDrawable = meshInfos.all { mi ->
                        meshInfoHasAnyTextureForPhase(mi, phaseBString)
                    }

                    // Only freeze when the currently-active base phase(s) are pending for the visible set.
                    val needsFreeze = if (interpolating) {
                        phaseAHasPending || phaseBHasPending || !phaseAHasDrawable || !phaseBHasDrawable
                    } else {
                        val activeA = finalMeld <= 0f
                        val hasPending = if (activeA) phaseAHasPending else phaseBHasPending
                        val hasDrawable = if (activeA) phaseAHasDrawable else phaseBHasDrawable
                        hasPending || !hasDrawable
                    }

                    if (needsFreeze) {
                        freezeHoldFrames = freezeHoldFramesMax
                        if (!frozenForIncomplete) {
                            val targetLong = (Timeline.timeLongs[Timeline.currentPhaseA] +
                                    (Timeline.timeLongs[Timeline.currentPhaseB] - Timeline.timeLongs[Timeline.currentPhaseA]) *
                                    Timeline.dataMeld).toLong()

                            var stablePhase: String? = null
                            val size = minOf(reqLongsLocal.size, reqStringsLocal.size)
                            for (i in 0 until size) {
                                val reqLong = reqLongsLocal[i]
                                if (reqLong > targetLong) break
                                val candidate = reqStringsLocal[i]

                                val candidateReadyForAllVisibleTiles = meshInfos.all { mi ->
                                    val tilePending = TileList.pendingList.containsTimeInTile(
                                        label,
                                        meshInfoToTileHashShort(mi),
                                        candidate
                                    )
                                    !tilePending && meshInfoHasAnyTextureForPhase(mi, candidate)
                                }
                                if (candidateReadyForAllVisibleTiles) {
                                    stablePhase = candidate
                                }
                            }

                            // If nothing is ready yet (rare), fall back to the previous stable phase
                            // (prevents tiles from popping off/on when we're waiting on the first completion).
                            stablePhase = stablePhase ?: lastStablePhaseAString ?: phaseAString

                            lastStablePhaseAString = stablePhase
                            frozenForIncomplete = true
                        }
                    } else {
                        if (freezeHoldFrames > 0) freezeHoldFrames--
                    }

                    if (frozenForIncomplete) {
                        // Hold the stable phase while we're in freeze, even if pending briefly flips false.
                        val stableA = lastStablePhaseAString ?: phaseAString
                        phaseAString = stableA
                        phaseBString = stableA
                        finalMeld = 0f
                        if (!needsFreeze && freezeHoldFrames <= 0) {
                            frozenForIncomplete = false
                            lastStablePhaseAString = null
                        }
                    }
                }
            }

            //if (pr.ON) pr.p(TAG, pr.noLoad, "render() about to assign progPtr")
            progPtr = (currentMesh!!.program as RasterTileProgram)
            progPtr.bind().also { checkError(checkErrorUse) }// Add program to OpenGL ES environment
            progPtr.useOncePerFrame()
            progPtr.use()
            progPtr.setColorBandTexture()
            progPtr.setMeld(finalMeld)

            currentTime = System.currentTimeMillis()

            GLES31.glUniform1i(progPtr.singlePointModeLoc, 0)
            GLES31.glUniform1i(progPtr.useRawColorsLocation, if (shouldDisplayRawColors) 1 else 0)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, progPtr.positionHandle)
            GLES31.glVertexAttribPointer(
                progPtr.positionHandle,
                COORDS_PER_VERTEX,
                GLES31.GL_FLOAT,
                false,
                VERTEX_STRIDE,
                vertexBuffer
            )
            GLES31.glVertexAttribPointer(
                progPtr.texPositionHandle,
                TEXTURE_SIZE,
                GLES31.GL_FLOAT,
                false,
                TEXTURE_STRIDE,
                textureCoordinatesBuffer
            )
            // In Mapbox [CustomLayerHost], use native projection + model-view from the same frame as
            // the basemap so encoded rasters sit on the map surface under pitch/bearing. Mixing
            // Mapbox P with [camera.viewMatrix] (or the inverse) leaves a separate "floating" plane.
            val mapboxProj = CameraSync.mapboxProjectionMatrix
            val mapboxMv = CameraSync.mapboxModelViewMatrix
            val useMapboxNativeMv =
                mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
            if (useMapboxNativeMv) {
                System.arraycopy(mapboxProj, 0, projectionMatrixArray, 0, 16)
                System.arraycopy(mapboxMv, 0, cameraArray, 0, 16)
            } else {
                matrixToFloatArray(camera.projectionMatrix, projectionMatrixArray)
                matrixToFloatArray(camera.viewMatrix, cameraArray)
            }

            projectionMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "projectionMatrix")
                .also { checkError("glGetUniformLocation") }
            GLES31.glUniformMatrix4fv(projectionMatrixHandle, 1, false, projectionMatrixArray, 0)
                .also { checkError("glUniformMatrix4fv") }

            modelMatrixHandle = GLES31.glGetUniformLocation(progPtr.programInt, "modelViewMatrix")
                .also { checkError("glGetUniformLocation") }
            progPtr.useOncePerFrame()
            progPtr.setColorBandTexture()
            sampleStyle.let { progPtr.setOpacity(it.opacity) }


            // if (pr.ON) {
            // if (lastMeshCount != meshInfoList!!.size) {
            //     pr.p(TAG, pr.tileCount, "render() meshInfoList.size: ${meshInfoList!!.size}")
            lastMeshCount = meshInfoList!!.size
            // }
            // }

            if (true /*|| phaseA < Timeline.timeStrings.size*/) {
                GLES31.glViewport(0, 0, camera.resX, camera.resY)
                meshInfoList?.forEach { meshInfo ->
                    if (true /*|| searchKey == meshInfo.hashCode*/) {

                        Matrix.setIdentityM(matrixArray, 0); // initialize to identity matrix
                        val mapZoomNow =
                            CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom
                        val overscale = if (useMapboxNativeMv) {
                            CameraSync.tileRasterOverscale(mapZoomNow, meshInfo.z.toInt())
                        } else {
                            1f
                        }
                        Matrix.scaleM(matrixArray, 0, 512f * overscale, 512f * overscale, 1f)
                        Matrix.translateM(matrixArray, 0, meshInfo.x, meshInfo.y, 0f)
                        Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, matrixArray, 0) //works
                        GLES31.glUniformMatrix4fv(
                            modelMatrixHandle,
                            1,
                            false,
                            modelViewMatrixArray,
                            0
                        )

                        val drawTileX = meshInfo.x
                        val drawTileY = meshInfo.y
                        datelineAdjustment(meshInfo)
                        //val hashKey = "${meshInfo.hashCode}${Timeline.timeStrings[phaseA]}"
                        val hashKey = "${meshInfo.hashCode}${phaseAString}"
                        //val hashKey =  "0:0/0/0/[\"2025-04-22T21:00:00Z\"]"


                        texHashMap[hashKey]?.let { // found ideal tile for phase A

                            if (pr.ON) pr.p(TAG, pr.noLoad, "render() found Ideal for phaseA: ${hashKey}")

                            progPtr.updateTexture1Size(1f, 1f, 0f, 0f)
                            var hash2: String? = "${meshInfo.hashCode}${phaseBString}"
                            if (texHashMap[hash2] != null) { //found full version of both textures
                                if (pr.ON) pr.p(TAG, pr.downloadRequest, "h2: $hash2 found, trying to draw!")
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                                currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                //println("$TAG, render() draw $it, ${texHashMap[hash2]}")
                            } else {
                                if (pr.ON) pr.p(TAG, pr.downloadRequest, "h2: ${hash2} NOT FOUND found")
                                hash2 = determinePartial(meshInfo, texHashMap, phaseBString, 2)
                                if (hash2 != null) {
                                    pr.p(TAG, pr.tilePick, "render() A drawing 2 tiles ", 2)
                                    currentMesh?.draw2Textures(it, texHashMap[hash2]!!)
                                    //println("$TAG, render() draw $it, ${texHashMap[hash2]}")
                                } else if (finalMeld != 1f) {
                                    pr.p(TAG, pr.rasterPart, "render() A drawing 1st tile ", 2)
                                    currentMesh?.draw(it)
                                    //println("$TAG, render() draw $it")
                                } else {
                                    pr.p(
                                        TAG,
                                        pr.rasterPart,
                                        "render() A wanted to draw last tile, can only find first: ",
                                        2
                                    )
                                    //println("$TAG, render() draw $it")
                                    currentMesh?.draw(it)
                                }
                            }
                        } ?: run { //Display lower-res texture if available. Also accounts for world-wrap


                            if (pr.ON) pr.p(TAG, pr.noLoad, "render() DID NOT find Ideal for phaseA: ${hashKey}")

                            val meshString1 = determinePartial(meshInfo, texHashMap, phaseAString, 1)

                            var meshString2: String? =
                                "${meshInfo.hashCode}${phaseBString}" // the exact tile
                            if (texHashMap[meshString2] == null) { // if exact tile not found, use partial
                                meshString2 = determinePartial(meshInfo, texHashMap, phaseBString, 2)
                            } else {
                                progPtr.updateTexture2Size(1f, 1f, 0f, 0f)
                            }
                            if (meshString1 != null) {
                                if (meshString2 != null) {
                                    if (pr.ON) pr.p(TAG, pr.rasterPart, "B1 draw 2")
                                    currentMesh?.draw2Textures(texHashMap[meshString1]!!, texHashMap[meshString2]!!)
                                } else {
                                    if (texHashMap.containsKey(meshString1)) {
                                        pr.p(TAG, pr.rasterPart, "render() B2 drawing 1st tile ", 2)
                                        currentMesh?.draw(texHashMap[meshString1]!!)
                                    } else {
                                    }
                                }
                            } else { // Used in case of the timeline being all the way at the right end, just draw the last interval
                                if (texHashMap[meshString2] != null) {
                                    if (finalMeld == 1f) {
                                        determinePartial(
                                            meshInfo,
                                            texHashMap,
                                            phaseBString,
                                            1
                                        ) // 250424 fix for raster tiles when meld is 1.0
                                    }
                                    currentMesh?.draw2Textures(texHashMap[meshString2]!!, texHashMap[meshString2]!!)
                                } else {
                                    pr.p(TAG, pr.flicker, "render() NOT DRAWING ANYTHING", 2)
                                }
                            }
                        } // end run
                    } // MATCH TOUCH TILE
                } // end for each

            }      // end if(phaseA < Timeline.times!!.size){


            progPtr.unbind()
        } // end  if (meshes != null && meshes!!.isNotEmpty()) {
        //if(pr.ON)pr.p(TAG, pr.trackRender,"render() exited")
    } // end render()

    private fun determinePartial(
        meshInfo: MeshInfo,
        texHashMap: HashMap<String, Int>,
        currentPhaseString: String,
        textureNumber: Int
    ): String? {
        val startAltDataZoom = floor(meshInfo.z /*- 1*/).toInt()
        altDataZoom = startAltDataZoom
        var partialHashString: String
        while (altDataZoom > -1) {
            if (pr.ON) pr.p(TAG, pr.partial, "render() in the loop, altDataZoom:$altDataZoom")

            // Avoid float rounding drift when walking the mip/partial chain.
            val shift = startAltDataZoom - altDataZoom
            val divisor = 1 shl shift
            // Use floor-division semantics to avoid truncation errors when coordinates are negative
            // (e.g. world-wrap / dateline edges). This matters especially during partial fallback.
            newX = Math.floorDiv(meshInfo.x.toInt(), divisor)
            newY = Math.floorDiv(meshInfo.y.toInt(), divisor)
            //consider trying to give this it's own String, may fix when pulls wrong tile?
            partialHashString = "0:${altDataZoom}/${newX}/${newY}/${currentPhaseString}"
            //if(pr.ON) pr.p(TAG, pr.obs_play, "hashString: ${hashString3}")

            if (texHashMap[partialHashString] != null) {
                val localScale = 1.0f / divisor.toFloat()
                updateTextureSizes(meshInfo, localScale, newX, newY, textureNumber)
                return partialHashString as String
            } else {
                altDataZoom--
            }
        }
        return null
    }

    /** Used to calculate the scale value for the texture in the shader. Used for tile partial scaling **/
    open fun updateTextureSizes(mInfo: MeshInfo, scale: Float, nX: Int, nY: Int, textureNumber: Int) {
        var xOffs = (mInfo.x * scale) - nX
        while (xOffs < 0f) xOffs += 1f // To handle wrapping around date line
        while (xOffs >= 1f) xOffs -= 1f
        val yOffs = (mInfo.y * scale) - nY
        if (textureNumber == 1) {
            progPtr.updateTexture1Size(scale, scale, xOffs, yOffs)
        } else {
            progPtr.updateTexture2Size(scale, scale, xOffs, yOffs)
        }
    }

    /** Puts a given Matrix4 into a given FloatArray
     * @return FloatArray
     */
    open fun matrixToFloatArray(m: Matrix4, r: FloatArray): FloatArray { //reuse existing array
        r[0] = m.elements[0]; r[1] = m.elements[1]; r[2] = m.elements[2]; r[3] = m.elements[3]
        r[4] = m.elements[4]; r[5] = m.elements[5]; r[6] = m.elements[6]; r[7] = m.elements[7]
        r[8] = m.elements[8]; r[9] = m.elements[9]; r[10] = m.elements[10]; r[11] = m.elements[11]
        r[12] = m.elements[12]; r[13] = m.elements[13]; r[14] = m.elements[14]; r[15] = m.elements[15]
        return r
    }

    private fun checkError(cmd: String? = null) {
        if (true /*BuildConfig.DEBUG*/) {
            when (val error = GLES31.glGetError()) {
                GLES31.GL_NO_ERROR -> {/*println("TAG $cmd -> no error")*/
                }

                GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM")
                GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                else -> throw RuntimeException("$cmd -> error in gl: $error")
            }
        }
    }

    /**
     * Finds the two values in a sorted list that a target value falls between,
     * and calculates the fractional distance between them.
     *
     * @param targetValue The long value to locate within the list.
     * @param sortedList The sorted list of longs to search within.
     * @return An [InterpolationResult] containing the lower and upper bound values and the fraction (0.0f to 1.0f).
     *         Returns null if the list has fewer than two elements or the target is outside the list's range.
     */
    open fun findInterpolationValues(targetValue: Long, sortedList: List<Long>): InterpolationResult? {
        // We need at least two points to form a range.
        if (sortedList.size < 2) {
            return null
        }

        // Use binarySearch to find the index or the insertion point.
        val searchResult = sortedList.binarySearch(targetValue)

        if (searchResult >= 0) {
            // Exact match found. The value is exactly on a point, so the fraction is 0.
            val value = sortedList[searchResult]
            return InterpolationResult(value, value, 0.0f, searchResult, searchResult)
        }

        // The value was not found. Convert the negative searchResult to an insertion point.
        val insertionPoint = -(searchResult + 1)

        // Handle edge cases: target is outside the entire range of the list.
        if (insertionPoint == 0 || insertionPoint == sortedList.size) {
            return null // Target is before the first element or after the last one.
        }

        // The target is between two elements.
        val lowerIndex = insertionPoint - 1
        val upperIndex = insertionPoint
        val lowerBound = sortedList[lowerIndex]
        val upperBound = sortedList[upperIndex]

        // Prevent division by zero if the bounds are identical.
        val range = (upperBound - lowerBound).toFloat()
        if (range == 0f) {
            return InterpolationResult(lowerBound, upperBound, 0.0f, lowerIndex, upperIndex)
        }

        // Calculate the fractional position of the target within the range.
        val position = (targetValue - lowerBound).toFloat()
        val fraction = position / range

        return InterpolationResult(
            lowerBound,
            upperBound,
            fraction.coerceIn(0.0f, 1.0f),
            lowerIndex,
            upperIndex
        )
    }

    companion object {
        /**
         * Checks if a `Mesh` element conforms to the given `GeometryVertexElementLayout`.
         */
        private fun meshesElementConforms(element: Mesh /*geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
            //return element.geometry.vertexElementLayout == geometryVertexElementLayout
            return true
        }

        /**
         * Checks if all `Mesh` elements conform to the given `GeometryVertexElementLayout`.
         */
        private fun meshesElementsConform(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): Boolean {
            //return elements.all { meshesElementConforms(it, geometryVertexElementLayout) }
            return true
        }

        /**
         * Filters out `Mesh` elements that do not conform to the given `GeometryVertexElementLayout`.
         */
        private fun conformingMeshesElements(elements: Collection<Mesh>/*, geometryVertexElementLayout: GeometryVertexElementLayout*/): List<Mesh>? {
            //return elements.filter { meshesElementConforms(it, geometryVertexElementLayout) }
            return null
        }

        private const val TAG = "RenderPass"
        private const val BYTES_PER_FLOAT = 4
        const val COORDS_PER_VERTEX = 2
        private const val NUM_TILES = 1
        private const val VERTEX_COUNT = NUM_TILES * 4
        const val VERTEX_STRIDE = COORDS_PER_VERTEX * BYTES_PER_FLOAT
        const val TEXTURE_SIZE = 2
        const val TEXTURE_STRIDE = TEXTURE_SIZE * BYTES_PER_FLOAT
        //private var textureAlpha = .5f

        private val vertexArray = UnitQuad2DGeometry.genQuad1x1()
        val vertexBuffer =
            ByteBuffer.allocateDirect(VERTEX_COUNT * COORDS_PER_VERTEX * BYTES_PER_FLOAT).run {
                order(ByteOrder.nativeOrder())// use the device hardware's native byte order
                asFloatBuffer()       // create a floating point buffer from the ByteBuffer
            }
        private val textureArray = UnitQuad2DGeometry.genTexCoords1Quad()
        val textureCoordinatesBuffer = ByteBuffer.allocateDirect(textureArray.size * 4).run {
            order(ByteOrder.nativeOrder())
            asFloatBuffer()
        }

        init {
            vertexBuffer.apply {
                clear()
                put(vertexArray)
                rewind()
            }

            textureCoordinatesBuffer.apply {
                clear()
                put(textureArray)
                rewind()
                // position(0)
            }
        }
    }

    /**
     * Maps a possibly multi-world tile column [MeshInfo.x] into `[0, n)` for cache/texture hash keys.
     * Single ±n wraps are insufficient (e.g. `x = -8`, `n = 4` stays negative).
     */
    private fun normalizedTileXForTextureHash(mi: MeshInfo): Int {
        val zInt = mi.z.toInt()
        val n = powerTableI[zInt]
        if (n <= 0) return floor(mi.x.toDouble()).toInt()
        var x = floor(mi.x.toDouble()).toInt()
        x %= n
        if (x < 0) x += n
        return x
    }

    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private fun datelineAdjustment(meshInfo: MeshInfo) {
        if (pr.ON) pr.p(
            TAG,
            pr.hashmapLong,
            "datelineAdjustment(), hashString: ${hashString}    meshInfo.hashcode:, ${meshInfo.hashCode}  "
        )
        val n = powerTableI[meshInfo.z.toInt()]
        if (n <= 0) return
        var x = meshInfo.x
        while (x < 0f) x += n
        while (x >= n) x -= n
        meshInfo.x = x
        // Keep hash format consistent with `TileCoord.hash()` when time is empty:
        // "wrap:z/x/y/" (note trailing slash).
        meshInfo.hashCode = "0:${meshInfo.z.toInt()}/${meshInfo.x.toInt()}/${meshInfo.y.toInt()}/"
    }


    /**  Fix for not finding tiles across dateline (-180 or 180) **/
    private val powerTableI = intArrayOf(
        1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048,
        4096, 8192, 16384, 32768, 65536, 131072, 262144, 524288, 1048576, 2097152, 4194304
    )
}

fun getMaxFragmentTextureUnits(): Int {
    val params = IntArray(1)
    // Try GLES30 first if available, otherwise fallback or assume GLES20 context
    // In a real app, you'd know your GLES context version.
    try {
        GLES30.glGetIntegerv(GLES30.GL_MAX_TEXTURE_IMAGE_UNITS, params, 0)
        if (GLES30.glGetError() == GLES30.GL_NO_ERROR) {
            return params[0]
        }
    } catch (e: Throwable) {
        // GLES30 might not be available or context not 3.0
    }

    // Fallback to GLES20 if GLES30 query failed or not applicable
    GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_IMAGE_UNITS, params, 0)
    return params[0]
}

data class InterpolationResult(
    val lowerBound: Long,
    val upperBound: Long,
    val fraction: Float,
    val aInt: Int,
    val bInt: Int
)