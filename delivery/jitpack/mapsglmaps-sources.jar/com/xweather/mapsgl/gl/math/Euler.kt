package com.xweather.mapsgl.gl.math

/**
 * Euler angles describe a rotational transformation by rotating an object on its various axes in
 * specified amounts per axis, and a specified axis order. Euler angles consist of three
 * components: roll, pitch and yaw angles.
 *
 * @see https://en.wikipedia.org/wiki/Euler%27s_rotation_theorem
 */
class Euler(var x: Float = 0f, var y: Float = 0f, var z: Float = 0f, var w: Float = 0f) {
    companion object {
        val DEFAULT_ORDER = EulerOrder.ZYX;
        val ALMOST_ONE = 0.99999;
    }

    /*
     * TODO callback when (x,y,z) changes ?
     */

    var roll: Float
        get() {
            return this.x
        }
        set(value: Float) {
            this.x = value
        }

    var pitch: Float
        get() {
            return this.y
        }
        set(value: Float) {
            this.y = value
        }

    var yaw: Float
        get() {
            return this.z
        }
        set(value: Float) {
            this.z = value
        }

    var order: Float
        get() {
            return this.w
        }
        set(value: Float) {
            this.w = value
        }

    fun fromArray(array: FloatArray, offset: Int = 0): Euler {
        this.x = array[offset + 0];
        this.y = array[offset + 1];
        this.z = array[offset + 2];
        this.order = array[offset + 3];
        this.triggerChange();
        return this;
    }

    fun toArray(array: FloatArray, offset: Int = 0): FloatArray {
        array[offset + 0] = this.x;
        array[offset + 1] = this.y;
        array[offset + 2] = this.z;
        array[offset + 3] = this.order;
        return array;
    }

    fun triggerChange() {
        /*
         * TODO Callback
         */
    }

    fun fromRotationMatrix(m: Matrix4, order: EulerOrder = DEFAULT_ORDER): Euler {
        // assumes the upper 3x3 of m is a pure rotation matrix (i.e, unscaled)
        val te = m.elements.toList()
        val m11 = te[0].toDouble()
        val m12 = te[4].toDouble()
        val m13 = te[8].toDouble()
        val m21 = te[1].toDouble()
        val m22 = te[5].toDouble()
        val m23 = te[9].toDouble()
        val m31 = te[2].toDouble()
        val m32 = te[6].toDouble()
        val m33 = te[10].toDouble()

        val eulerOrder = when (order) {
            EulerOrder.ZYX,
            EulerOrder.RollPitchYaw ->
                EulerOrder.fromInt(this.order.toInt())

            else -> order
        }

        when (eulerOrder) {
            EulerOrder.XYZ -> {
                this.y = Math.asin(m13.coerceIn(-1.0, 1.0)).toFloat()

                if (Math.abs(m13) < ALMOST_ONE) {
                    this.x = Math.atan2(-m23, m33).toFloat()
                    this.z = Math.atan2(-m12, m11).toFloat()
                } else {
                    this.x = Math.atan2(m32, m22).toFloat()
                    this.z = 0f
                }
            }

            EulerOrder.YXZ -> {
                this.x = Math.asin(m23.coerceIn(-1.0, 1.0)).toFloat()

                if (Math.abs(m23) < ALMOST_ONE) {
                    this.y = Math.atan2(m13, m33).toFloat()
                    this.z = Math.atan2(m21, m22).toFloat()
                } else {
                    this.y = Math.atan2(-m31, m11).toFloat()
                    this.z = 0f
                }
            }

            EulerOrder.ZXY -> {
                this.x = Math.asin(m32.coerceIn(-1.0, 1.0)).toFloat()

                if (Math.abs(m32) < ALMOST_ONE) {
                    this.y = Math.atan2(-m31, m33).toFloat()
                    this.z = Math.atan2(-m12, m22).toFloat()
                } else {
                    this.y = 0f
                    this.z = Math.atan2(m21, m11).toFloat()
                }
            }

            EulerOrder.ZYX -> {
                this.y = Math.asin(m31.coerceIn(-1.0, 1.0)).toFloat()

                if (Math.abs(m31) < ALMOST_ONE) {
                    this.x = Math.atan2(m32, m33).toFloat()
                    this.z = Math.atan2(m21, m11).toFloat()
                } else {
                    this.x = 0f
                    this.z = Math.atan2(-m12, m22).toFloat()
                }
            }

            EulerOrder.YZX -> {
                this.z = Math.asin(m21.coerceIn(-1.0, 1.0)).toFloat()

                if (Math.abs(m21) < ALMOST_ONE) {
                    this.x = Math.atan2(-m23, m22).toFloat()
                    this.y = Math.atan2(-m31, m11).toFloat()
                } else {
                    this.x = 0f
                    this.y = Math.atan2(m13, m33).toFloat()
                }
            }

            EulerOrder.XZY -> {
                this.z = Math.asin(m12.coerceIn(-1.0, 1.0)).toFloat()

                if (Math.abs(m12) < ALMOST_ONE) {
                    this.x = Math.atan2(m32, m22).toFloat()
                    this.y = Math.atan2(m13, m11).toFloat()
                } else {
                    this.x = Math.atan2(-m23, m33).toFloat()
                    this.y = 0f
                }
            }

            else -> throw java.lang.Exception("Unknown Euler angle order")
        }

        this.triggerChange();

        return this;
    }

    fun fromQuaternion(q: QuaternionTC): Euler {
        val ysqr = q.y * q.y;
        val t0 = -2 * (ysqr + q.z * q.z) + 1;
        val t1 = +2 * (q.x * q.y + q.w * q.z);
        var t2 = -2 * (q.x * q.z - q.w * q.y);
        val t3 = +2 * (q.y * q.z + q.w * q.x);
        val t4 = -2 * (q.x * q.x + ysqr) + 1;

        t2 = if (t2 > 1f) {
            1f
        } else {
            t2
        }
        t2 = if (t2 < -1f) {
            -1f
        } else {
            t2
        };

        val roll = Math.atan2(t3.toDouble(), t4.toDouble());
        val pitch = Math.asin(t2.toDouble());
        val yaw = Math.atan2(t1.toDouble(), t0.toDouble());

        return Euler(
            roll.toFloat(),
            pitch.toFloat(),
            yaw.toFloat(),
            EulerOrder.RollPitchYaw.value.toFloat()
        );
    }

    fun toQuaternion(): QuaternionTC {
        val cy = Math.cos(this.yaw * 0.5);
        val sy = Math.sin(this.yaw * 0.5);
        val cr = Math.cos(this.roll * 0.5);
        val sr = Math.sin(this.roll * 0.5);
        val cp = Math.cos(this.pitch * 0.5);
        val sp = Math.sin(this.pitch * 0.5);

        val w = cy * cr * cp + sy * sr * sp;
        val x = cy * sr * cp - sy * cr * sp;
        val y = cy * cr * sp + sy * sr * cp;
        val z = sy * cr * cp - cy * sr * sp;

        return QuaternionTC(x.toFloat(), y.toFloat(), z.toFloat(), w.toFloat());
    }

    fun fromVector3(v: Vector3, order: EulerOrder = EulerOrder.fromInt(this.order.toInt())): Euler {
        /*
         * TODO order of EulerOrder does not support infinite.
         *  Not 100% sure what JS is say about infinite ?
         */
        this.x = v.x
        this.y = v.y
        this.z = v.z
        this.w = order.value.toFloat()
        return this
    }

    fun toVector3(): Vector3 {
        return Vector3(this.x, this.y, this.z);
    }

    fun clone() = Euler(this.x, this.y, this.z, this.w)

    fun copy(e: Euler): Euler {
        this.x = e.x
        this.y = e.y
        this.z = e.z
        this.w = e.w
        this.triggerChange();
        return this;
    }

    fun isEqual(e: Euler) = (this.x == e.x && this.y == e.y && this.z == e.z && this.w == e.w)
}

enum class EulerOrder(val value: Int) {
    ZYX(0),
    YXZ(1),
    XZY(2),
    ZXY(3),
    YZX(4),
    XYZ(5),
    RollPitchYaw(0);

    companion object {
        fun fromInt(value: Int) = EulerOrder.values().first { it.value == value }
    }
}