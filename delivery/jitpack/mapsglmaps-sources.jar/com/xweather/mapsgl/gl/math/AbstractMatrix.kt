package com.xweather.mapsgl.gl.math

abstract class AbstractMatrix : IMatrix {
    override var elements = ArrayList<Float>()

    override fun fromArray(array: List<Float>, offset: Int): IMatrix {
        this.elements.clear()
        for (i in offset until array.size) {
            elements.add(array[i])
        }
        return this
    }

    fun fromArray(array: FloatArray): IMatrix {
        this.elements.clear()
        for (item in array) {
            elements.add(item)
        }
        return this
    }

    override fun toArray(array: ArrayList<Float>, offset: Int): ArrayList<Float> {
        for (i in offset until elements.size) {
            array.add(elements[i])
        }
        return array
    }

    override fun isEqual(m: IMatrix): Boolean {
        if (m.elements.size != this.elements.size)
            return false

        for (i in 0 until elements.size) {
            if (m.elements[i] != elements[i])
                return false
        }
        return true
    }

    override fun clone() = fromArray(elements.toList(), 0)
}