package com.xweather.mapsgl.layers.style

import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ParticleDensity
import com.xweather.mapsgl.style.ParticleTrailLength
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.ColorSampling
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.SampleChannel

/**
 * Interface used by rasterStyle, SampleStyle, and ParticleStyle
 */
interface PaintStyle {
    var opacity: Float
}

/**
 * Raster style.
 *
 * @property opacity Opacity of the rendered data from 0 (full transparent) to 1 (fully opaque).
 * @constructor Create [RasterStyle]
 */
open class RasterStyle(
    override var opacity: Float = 1.0f,
    open var quality: DataQuality = DataQuality.normal,
) : PaintStyle {}

/**
 * Sample style.
 *
 * @property expression Determines how data should be sampled from the encoded data texture.
 * @property channels
 * @property quality ntrols the data resolution that gets requested by the layer’s data source and rendered to the map. Data will be interpolated when rendering to the map to ensure low resolution/quality data is still smooth.
 * @property interpolation Type of interpolation to perform on the data.
 * @property smoothing Amount of smoothing to apply on the data from 0 (no smoothing) to 1 (full smoothing). Increasing this value is useful for low resolution data sets or when higher detail is not desired or needed.
 * @property offset Normalized amount to shift the interpolated sample values from 0 to 1. This is typically used for expression operations like diff where interpolated values can be negative and you need to start values half way (0.5) between the colorscale.range.
 * @property drawRange Limits the data range that should be rendered from the sampled data. If not provided, then the full data range provided by the associated data source will be rendered by default.
 * @property colorScale A ColorScale maps numeric values to a color palette. The scale can then be used to generate a set of colors for a given range of values and options.
 * @property opacity Opacity of the rendered data from 0 (full transparent) to 1 (fully opaque).
 * @property multiband
 * @property meld
 * @constructor Create [SampleStyle]
 */
class SampleStyle(
    override var expression: SampleExpression = SampleExpression.NUMBER,
    override var channel: List<ColorBand> = listOf(ColorBand.red),
    override var quality: DataQuality = DataQuality.normal,
    override var interpolation: InterpolationMode = InterpolationMode.BICUBIC,
    override var smoothing: Float = 0.0f,
    override var offset: Float = 0.0f,
    override var drawRange: ClosedRange<Double>? = null,
    override var colorScale: ColorScaleOptions = ColorScaleOptions(),
    override var opacity: Float = 1.0f,
    var multiband: Boolean = false,
    var meld: Boolean = true
) : RasterStyle(opacity), ColorSampling {

}

/**
 * Particle style.
 *
 * @property expression Determines how data should be sampled from the encoded data texture.
 * @property channels Which of 3 rgb channels from the source image to use. Default is ColorBand.red
 * @property quality The resolution of the underlying texture. Default is DataQuality.normal
 * @property interpolation The type of blending done on the source texture. The default is InterpolationMode.BICUBIC.
 * @property smoothing The amount of smoothing used on the the source texture.
 * @property offset Normalized amount to shift the interpolated sample values from 0 to 1. This is typically used for expression operations like diff where interpolated values can be negative and you need to start values half way (0.5) between the colorscale.range.
 * @property drawRange Limits the data range that should be rendered from the sampled data. If not provided, then the full data range provided by the associated data source will be rendered by default.
 * @property colorScale A ColorScale maps numeric values to a color palette. The scale can then be used to generate a set of colors for a given range of values and options.
 * @property opacity  The opacity of the particles, from 0f to 1f. Default is 1f.
 * @property density  The density of the particles. default is ParticleDensity.NORMAL.
 * @property size  The size of the individual particles. Default is 2f
 * @property speedFactor How fast the particles travel. Default is 1f.
 * @property trails The transparent tails can be endabled or disabled. Default is true.
 * @property trailsFadeFactor The rate at which the transparent trails fade, from 0 to 1.
 * This affects trail length. .9f fades quickly, 1f never fades. Default is .97f
 * @property dropRate
 * @property dropRateBump
 * @property vectorOffset
 * @constructor Create [ParticleStyle]
 */
class ParticleStyle(
    /** Determines how data should be sampled from the encoded data texture. **/
    override var expression: SampleExpression = SampleExpression.NUMBER,
    /** Which of 3 rgb channels from the source image to use. Default is ColorBand.red **/
    override var channel: List<ColorBand> = listOf(ColorBand.red),
    override var quality: DataQuality = DataQuality.normal,
    override var interpolation: InterpolationMode = InterpolationMode.BICUBIC,
    override var smoothing: Float = 0.0f,
    override var offset: Float = 0.0f,
    override var drawRange: ClosedRange<Double>? = null,
    override var colorScale: ColorScaleOptions = ColorScaleOptions(),
    /** The opacity of the particles, from 0f to 1f. Default is 1f. **/
    override var opacity: Float = 1.0f,
    var density: ParticleDensity = ParticleDensity.NORMAL,
    var count: Int = 0,
    var size: Float = 2.0f,
    /** How fast the particles travel. Default is 1f. **/
    var speedFactor: Float = 1f,
    var trails: Boolean = true,
    var trailsFadeFactor: Double = ParticleTrailLength.NORMAL,
    var dropRate: Float = 1f,
    var dropRateBump: Float = 1f,
    val vectorOffset: Float = .5f
) : RasterStyle(opacity), ColorSampling {
    var needsRotationHandled = false
    var darkBackground = false
}


class VectorStyle(
    /** Determines how data should be sampled from the encoded data texture. **/
    override var expression: SampleExpression = SampleExpression.NUMBER,
    /** Which of 3 rgb channels from the source image to use. Default is ColorBand.red **/
    override var channel: List<ColorBand> = listOf(ColorBand.red),
    override var quality: DataQuality = DataQuality.normal,
    override var interpolation: InterpolationMode = InterpolationMode.BICUBIC,
    override var smoothing: Float = 0.0f,
    override var offset: Float = 0.0f,
    override var drawRange: ClosedRange<Double>? = null,
    override var colorScale: ColorScaleOptions = ColorScaleOptions(),
    /** The opacity of the particles, from 0f to 1f. Default is 1f. **/
    override var opacity: Float = 1.0f,
    var density: ParticleDensity = ParticleDensity.NORMAL,
    var count: Int = 0,
    var size: Float = 2.0f,
    /** How fast the particles travel. Default is 1f. **/
    var trailsFadeFactor: Double = ParticleTrailLength.NORMAL,
) : RasterStyle(opacity), ColorSampling {
    var needsRotationHandled = false
}
