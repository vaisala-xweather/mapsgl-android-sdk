package com.xweather.mapsgl.layers.tile

/**
 * What a [TileLayer] does after a tile request wave fails — most often an encoded source whose
 * metadata fetch did not complete because the network dropped for a moment.
 *
 * That failure used to be rethrown out of [TileLayer.requestVisibleTiles] onto the main
 * dispatcher, which killed the host app. Now the layer keeps going without metadata, reports once
 * per failure streak, and retries on a backoff so a layer added while the camera is idle does not
 * stay blank until the user happens to pan. A camera move retries as well, since the source's
 * `metaDataNeeded` stays set until a fetch succeeds.
 *
 * Extracted from [TileLayer] so the streak and backoff rules can be exercised without a map.
 * Not thread-safe; [TileLayer] synchronises on it.
 */
internal class LoadFailureRetry(
    private val baseDelayMs: Long = BASE_DELAY_MS,
    private val maxDelayMs: Long = MAX_DELAY_MS,
    private val maxRetries: Int = MAX_RETRIES,
) {
    /**
     * @property report Whether this failure starts a new streak and should be logged and handed to
     *   the host app. Later failures in the same streak stay quiet.
     * @property retryDelayMs How long to wait before the automatic retry, or null once the streak
     *   has used up its retries (camera moves still retry).
     */
    data class Decision(val report: Boolean, val retryDelayMs: Long?)

    /** Consecutive failures since the last success. */
    var consecutiveFailures = 0
        private set

    fun onFailure(): Decision {
        val attempt = ++consecutiveFailures
        val delay = if (attempt > maxRetries) {
            null
        } else {
            // 1x, 2x, 4x … of the base, capped; shift bounded so it cannot overflow.
            (baseDelayMs shl (attempt - 1).coerceAtMost(20)).coerceAtMost(maxDelayMs)
        }
        return Decision(report = attempt == 1, retryDelayMs = delay)
    }

    /** @return true when this success ends a failure streak, so the recovery is worth a log line. */
    fun onSuccess(): Boolean {
        val recovered = consecutiveFailures > 0
        consecutiveFailures = 0
        return recovered
    }

    companion object {
        const val BASE_DELAY_MS = 2_000L
        const val MAX_DELAY_MS = 30_000L
        const val MAX_RETRIES = 6
    }
}
