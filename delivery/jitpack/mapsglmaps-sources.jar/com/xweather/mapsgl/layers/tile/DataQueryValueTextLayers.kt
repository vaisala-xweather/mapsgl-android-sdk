package com.xweather.mapsgl.layers.tile

import com.xweather.mapsgl.weather.groups.DataQuery
import java.util.concurrent.ConcurrentHashMap

/**
 * Which symbol layers are data-query value labels - the built-in `*-text` catalog, plus any
 * data-query layer an app added through [com.xweather.mapsgl.map.MapController.addLayer].
 *
 * The symbol renderer lays these out as one value-over-name block: a tighter line gap, lines
 * centred on each other, a heavier halo, and a collision box that contains the whole stack.
 * [DataQuery.isValueTextLayerId] only knows the catalog's fixed ids, so a custom layer used to get
 * generic text layout instead, with its two lines drawn apart and crowding its neighbours.
 *
 * Read from the render thread and written from the main thread, hence the concurrent set.
 */
internal object DataQueryValueTextLayers {

    private val customLayerIds: MutableSet<String> = ConcurrentHashMap.newKeySet()

    fun register(layerId: String) {
        customLayerIds.add(layerId)
    }

    fun unregister(layerId: String) {
        customLayerIds.remove(layerId)
    }

    fun contains(layerId: String?): Boolean {
        if (layerId.isNullOrEmpty()) return false
        return layerId in customLayerIds || DataQuery.isValueTextLayerId(layerId)
    }
}
