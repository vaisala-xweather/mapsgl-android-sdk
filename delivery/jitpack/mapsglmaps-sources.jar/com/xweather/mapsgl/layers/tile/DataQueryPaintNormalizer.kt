package com.xweather.mapsgl.layers.tile

import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.style.SymbolRank
import com.xweather.mapsgl.style.SymbolRankDirection
import com.xweather.mapsgl.style.TextPaint

/**
 * Retargets authored data-query paint onto the properties the coordinator publishes
 * (`value`, `name`, `rankScore`). Matches iOS `DataQueryPaintNormalizer` / JS `to-unit` rewrite.
 *
 * @suppress
 */
object DataQueryPaintNormalizer {

    fun normalize(
        paint: SymbolLayerPaint,
        labelKeyPath: String,
        rankKeyPath: String,
    ): SymbolLayerPaint {
        val rewrittenText = paint.text.map { entry ->
            rewriteTextEntry(entry, labelKeyPath)
        }
        val rewrittenRank = rewriteRank(paint.rank, rankKeyPath)
        return paint.copy(
            text = rewrittenText,
            rank = rewrittenRank,
        )
    }

    private fun rewriteTextEntry(entry: TextPaint, labelKeyPath: String): TextPaint {
        val value = entry.value
        val rewritten: StyleValue<String> = when (value) {
            is StyleValue.Expression -> {
                when {
                    isToUnitExpression(value.expression) ->
                        StyleValue.Expression(Expression.get("value"))
                    isGetKeyPath(value.expression, labelKeyPath) ->
                        StyleValue.Expression(Expression.get("name"))
                    isGetKeyPath(value.expression, "name") ->
                        StyleValue.Expression(Expression.get("name"))
                    isGetKeyPath(value.expression, "value") ->
                        StyleValue.Expression(Expression.get("value"))
                    else -> value
                }
            }
            else -> value
        }
        return entry.copy(value = rewritten)
    }

    private fun rewriteRank(rank: SymbolRank?, rankKeyPath: String): SymbolRank {
        val property = rank?.property
        val direction = rank?.direction ?: SymbolRankDirection.ASC
        return when {
            property == null -> SymbolRank("rankScore", direction)
            property == rankKeyPath || property == "rank" || property == "rankScore" ||
                property.endsWith(".rankScore") || property.endsWith(".rank") ->
                SymbolRank("rankScore", direction)
            else -> SymbolRank("rankScore", direction)
        }
    }

    /** Spec `to-unit` / nested unit conversion head. */
    private fun isToUnitExpression(expr: Expression): Boolean {
        val raw = expr.raw
        if (raw is List<*> && raw.isNotEmpty()) {
            val head = raw[0]
            if (head == "to-unit" || head == "toUnit") return true
            // Nested: ["format", ["to-unit", ...], ...] — treat as value line if any child is to-unit.
            return raw.any { child ->
                child is List<*> && child.isNotEmpty() &&
                    (child[0] == "to-unit" || child[0] == "toUnit")
            }
        }
        return false
    }

    /**
     * True when [expr] is `get <key>` or a nested dotted get that resolves to [keyPath]
     * (e.g. `["get","b",["get","a"]]` → `a.b`).
     */
    private fun isGetKeyPath(expr: Expression, keyPath: String): Boolean {
        val resolved = resolveGetPath(expr.raw) ?: return false
        return resolved == keyPath || resolved == keyPath.substringAfterLast('.')
    }

    private fun resolveGetPath(raw: Any?): String? {
        if (raw !is List<*> || raw.isEmpty() || raw[0] != "get") return null
        return when (raw.size) {
            2 -> raw[1] as? String
            3 -> {
                val leaf = raw[1] as? String ?: return null
                val parent = resolveGetPath(raw[2]) ?: return null
                "$parent.$leaf"
            }
            else -> null
        }
    }
}
