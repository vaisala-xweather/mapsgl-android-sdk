package com.xweather.mapsgl.layers.tile

import com.mapbox.geojson.Feature
import com.mapbox.geojson.FeatureCollection
import com.mapbox.geojson.Point
import com.xweather.mapsgl.anim.Timeline
import android.util.Log
import com.google.gson.JsonElement
import com.xweather.mapsgl.extensions.UnitLength
import com.xweather.mapsgl.extensions.UnitPressure
import com.xweather.mapsgl.extensions.UnitSpeed
import com.xweather.mapsgl.extensions.UnitTemperature
import com.xweather.mapsgl.layers.spec.DataQueryLayerDescriptor
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.renderers.VectorSymbolPlacementDefaults
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.style.effectiveSampleMeldProgress
import com.xweather.mapsgl.style.sampleMeldEnabled
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.util.PlaceLabelText
import com.xweather.mapsgl.weather.LayerCode
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * Owns the sampling loop and value cache for one data-query layer.
 *
 * Collects visible point geometry from a tiled vector source (via a private collector layer),
 * samples the configured weather layer at each point, formats values, and publishes features
 * into a private [GeoJSONSource] consumed by a stock symbol layer.
 *
 * @suppress
 */
class DataQueryCoordinator(
    private val controller: MapController,
    private val queryLayerId: String,
    private val descriptor: DataQueryLayerDescriptor,
    private val publishSource: GeoJSONSource,
    private val pointCollectorLayerId: String,
    private val sampledLayerIdProvider: () -> String?,
) {
    companion object {
        private const val TAG = "DataQueryCoordinator"
        private const val DEDUP_QUANTIZE = 100_000.0
        private const val IDENTITY_BUCKETS = 10_000.0
        private const val SUB_INTERVAL_BUCKETS = 20
        private const val MAX_HELD_MISSES = 12
        /**
         * Label lerp / publish cadence. Matches GPU fill (every vsync-ish). Endpoint tile samples
         * are **not** on this path — they run on [SAMPLE_DEBOUNCE_MS] so playback is not 1 fps.
         */
        private const val LERP_INTERVAL_MS = 16L
        /** Coalesces encoded-tile endpoint (re)samples. Matches iOS refresh debounce (120 ms). */
        private const val SAMPLE_DEBOUNCE_MS = 120L
        private const val RETRY_DELAY_MS = 250L
        private const val CONCURRENT_SAMPLES = 8
        /**
         * Cap published / sampled place points per viewport. Unbounded tile membership (no hard
         * bounds cull) can yield hundreds of city/town points; sampling + symbol collision then
         * stalls and leaves the map blank.
         */
        private const val MAX_LABEL_POINTS = 180
        /** Expand [getBounds] slightly so a lagging viewport does not drop all tile members. */
        private const val VIEWPORT_PAD_FRACTION = 0.2
    }

    private data class CollectedPoint(
        val lon: Double,
        val lat: Double,
        val name: String,
        val rankScore: Double,
        val dedupKey: String,
        val cacheKey: String,
    )

    private data class CacheEntry(
        var intervalA: Int,
        var intervalB: Int,
        var progressBucket: Int,
        var zoom: Int,
        var valueA: Double?,
        var valueB: Double?,
        var value: Double?,
        var unit: UnitTemperature,
        var stale: Boolean,
        var dataRevision: Long,
        var missStreak: Int,
    ) {
        val isSettled: Boolean get() = value != null && !stale
        val isResolved: Boolean get() = isSettled || missStreak >= MAX_HELD_MISSES

        fun lerp(t: Float): Double? {
            val a = valueA
            val b = valueB
            return when {
                a != null && b != null -> a * (1.0 - t) + b * t
                a != null -> a
                b != null -> b
                else -> null
            }
        }

        /** Roll B→A when the playhead steps one interval so we only fetch the new B grid. */
        fun alignToPlayhead(newA: Int, newB: Int) {
            if (intervalA == newA && intervalB == newB) return
            if (intervalB == newA && valueB != null) {
                valueA = valueB
                valueB = null
                intervalA = newA
                intervalB = newB
                stale = true
                return
            }
            valueA = null
            valueB = null
            intervalA = newA
            intervalB = newB
            stale = true
        }
    }

    private val valueCache = linkedMapOf<String, CacheEntry>()
    /** Last published display label per point (`null` = name-only). Gate GeoJSON writes on this. */
    private val publishedLabels = linkedMapOf<String, String?>()
    private var collectionCacheKey: String? = null
    private var collectionCache: List<CollectedPoint> = emptyList()
    private var collectionComplete = false

    @Volatile
    private var dataRevision: Long = 0L

    @Volatile
    private var generation: Long = 0L

    private var lastPassInterval: Int = Int.MIN_VALUE
    private var lastPassIntervalB: Int = Int.MIN_VALUE
    private var lastPassProgress: Int = Int.MIN_VALUE
    private var lastPassZoom: Int = Int.MIN_VALUE
    private var lastPassRevision: Long = -1L
    /** Quantized viewport — pan at fixed zoom/time must not hit the playhead early-out. */
    private var lastPassBoundsKey: String? = null

    private var lerpJob: Job? = null
    private var sampleJob: Job? = null
    private var retryJob: Job? = null
    private var destroyed = false

    /** Set while a refresh is scheduled/running; further triggers coalesce instead of canceling. */
    @Volatile
    private var refreshPending = false

    /** When true, the next coalesced pass skips the debounce sleep (viewport / enable). */
    @Volatile
    private var refreshImmediate = false

    @Volatile
    private var samplePending = false

    @Volatile
    private var sampleImmediate = false

    /**
     * Set when a pass collected zero visible points but we held the prior GeoJSON. Prevents the
     * playhead early-out from locking that hold forever without retrying collection.
     */
    @Volatile
    private var holdLabelsPendingRetry = false

    fun bumpDataRevision() {
        dataRevision++
        if (valueCache.values.any { !it.isResolved }) {
            scheduleRefresh(immediate = false)
        }
    }

    /**
     * Schedule a sample/publish pass.
     *
     * Playback ticks must **lerp and publish** on a short cadence (iOS display-link style) without
     * waiting for encoded-tile endpoint samples. Sampling runs on a separate job so a slow native
     * cache fill cannot pin labels at ~1 fps.
     */
    fun scheduleRefresh(immediate: Boolean = false, reformatOnly: Boolean = false) {
        if (destroyed) return
        if (reformatOnly) {
            controller.viewModelScope.launch {
                republishFromCache(reformatOnly = true)
            }
            return
        }
        refreshPending = true
        if (immediate) {
            refreshImmediate = true
            sampleImmediate = true
            samplePending = true
        }
        ensureLerpLoop()
        if (immediate) ensureSampleLoop()
    }

    fun destroy() {
        destroyed = true
        lerpJob?.cancel()
        sampleJob?.cancel()
        retryJob?.cancel()
        valueCache.clear()
        publishedLabels.clear()
        collectionCache = emptyList()
    }

    private fun ensureLerpLoop() {
        if (destroyed) return
        if (lerpJob?.isActive == true) return
        lerpJob = controller.viewModelScope.launch {
            while (!destroyed && (refreshPending || refreshImmediate || Timeline.isGloballyPlaying)) {
                val runNow = refreshImmediate
                refreshImmediate = false
                refreshPending = false
                if (!runNow) delay(LERP_INTERVAL_MS)
                if (destroyed) break
                runLerpPublish()
                if (Timeline.isGloballyPlaying) refreshPending = true
            }
            lerpJob = null
            if (!destroyed && (refreshPending || refreshImmediate || Timeline.isGloballyPlaying)) {
                ensureLerpLoop()
            }
        }
    }

    private fun ensureSampleLoop() {
        if (destroyed) return
        if (sampleJob?.isActive == true) return
        sampleJob = controller.viewModelScope.launch {
            while (!destroyed && (samplePending || sampleImmediate)) {
                val runNow = sampleImmediate
                sampleImmediate = false
                samplePending = false
                if (!runNow && !Timeline.isGloballyPlaying) delay(SAMPLE_DEBOUNCE_MS)
                if (destroyed) break
                val forced = runNow || sampleImmediate
                sampleImmediate = false
                samplePending = false
                runEndpointSamplePass(force = forced)
            }
            sampleJob = null
            if (!destroyed && (samplePending || sampleImmediate)) {
                ensureSampleLoop()
            }
        }
    }

    private fun playheadMeld(sampledLayer: EncodedTileLayer?): Float {
        val meldEnabled = sampledLayer?.paint?.sampleMeldEnabled() ?: true
        return if (meldEnabled) {
            sampledLayer?.paint?.effectiveSampleMeldProgress(Timeline.dataMeld)
                ?: Timeline.dataMeld.coerceIn(0f, 1f)
        } else {
            0f
        }
    }

    /** Cheap: lerp cached A/B and republish if the formatted integer/string changed. */
    private fun runLerpPublish() {
        if (destroyed) return
        if (!collectionComplete || collectionCache.isEmpty()) {
            samplePending = true
            ensureSampleLoop()
            return
        }
        val sampledLayer = sampledLayerIdProvider()?.let { controller.getLayer(it) as? EncodedTileLayer }
        val meldEnabled = sampledLayer?.paint?.sampleMeldEnabled() ?: true
        val intervalA = Timeline.currentPhaseA
        val intervalB = Timeline.currentPhaseB
        val t = playheadMeld(sampledLayer)
        var needEndpoints = false
        for (point in collectionCache) {
            val entry = valueCache[point.cacheKey]
            if (entry == null) {
                needEndpoints = true
                continue
            }
            entry.alignToPlayhead(intervalA, intervalB)
            val lerped = entry.lerp(t)
            if (lerped != null) {
                entry.value = lerped
                entry.stale = meldEnabled && entry.valueB == null
            }
            entry.progressBucket = progressBucket(t)
            if (entry.valueA == null || (meldEnabled && entry.valueB == null && !entry.isResolved)) {
                needEndpoints = true
            }
        }
        republishFromCache(reformatOnly = false, points = collectionCache)
        if (needEndpoints) {
            samplePending = true
            ensureSampleLoop()
        }
    }

    private suspend fun runEndpointSamplePass(force: Boolean) {
        if (destroyed) return
        val myGen = ++generation

        val bounds = try {
            controller.getBounds()
        } catch (_: Throwable) {
            scheduleRetry()
            return
        }
        if (!boundsAreUsable(bounds)) {
            scheduleRetry()
            return
        }

        val snapshotIntervalA = Timeline.currentPhaseA
        val snapshotIntervalB = Timeline.currentPhaseB
        val sampledLayer = sampledLayerIdProvider()?.let { controller.getLayer(it) as? EncodedTileLayer }
        val meldEnabled = sampledLayer?.paint?.sampleMeldEnabled() ?: true
        val t = playheadMeld(sampledLayer)
        val snapshotProgress = if (meldEnabled) progressBucket(t) else 0
        val dataZoom = sampledLayer?.let {
            floor(it.zoomForVisibleTilesPublic()).toInt().coerceAtLeast(0)
        } ?: controller.zoomInt
        val revisionAtStart = dataRevision
        val boundsKey = quantizedBoundsKey(bounds)

        val canSkipCollect =
            !force &&
                collectionComplete &&
                boundsKey == lastPassBoundsKey &&
                collectionCache.isNotEmpty()
        val points = if (canSkipCollect) {
            collectionCache
        } else {
            collectPoints(bounds, myGen) ?: return
        }
        if (myGen != generation) return

        val collectionIncomplete = !collectionComplete
        if (points.isEmpty() && (collectionIncomplete || coordsWereEmpty)) {
            holdLabelsPendingRetry = publishedLabels.isNotEmpty()
            scheduleRetry()
            return
        }
        if (points.isEmpty() && publishedLabels.isNotEmpty()) {
            holdLabelsPendingRetry = true
            scheduleRetry()
            return
        }
        holdLabelsPendingRetry = false

        val visibleKeys = HashSet<String>(points.size)
        val toSample = ArrayList<CollectedPoint>(points.size)
        for (point in points) {
            visibleKeys.add(point.cacheKey)
            val entry = valueCache[point.cacheKey]
            entry?.alignToPlayhead(snapshotIntervalA, snapshotIntervalB)
            if (needsEndpointSample(point.cacheKey, snapshotIntervalA, snapshotIntervalB, dataZoom, meldEnabled)) {
                toSample.add(point)
            }
        }

        if (toSample.isNotEmpty()) {
            val results = withContext(Dispatchers.Default) {
                val sampleSemaphore = Semaphore(CONCURRENT_SAMPLES)
                coroutineScope {
                    toSample.map { point ->
                        async {
                            sampleSemaphore.withPermit {
                                if (myGen != generation) return@withPermit null
                                point.cacheKey to sampleEndpoints(point.lon, point.lat, sampledLayer)
                            }
                        }
                    }.awaitAll()
                }
            }
            if (myGen != generation) return
            for (pair in results) {
                val (key, endpoints) = pair ?: continue
                applyEndpointResult(
                    key = key,
                    endpoints = endpoints,
                    intervalA = snapshotIntervalA,
                    intervalB = snapshotIntervalB,
                    progressBucket = snapshotProgress,
                    dataZoom = dataZoom,
                    dataRevision = revisionAtStart,
                    t = t,
                )
            }
        }

        val evict = valueCache.keys.filter { it !in visibleKeys }
        evict.forEach { valueCache.remove(it) }

        if (myGen != generation) return
        runLerpPublish()

        lastPassInterval = snapshotIntervalA
        lastPassIntervalB = snapshotIntervalB
        lastPassProgress = snapshotProgress
        lastPassZoom = dataZoom
        lastPassRevision = revisionAtStart
        lastPassBoundsKey = boundsKey

        val unresolved = points.any { p ->
            val e = valueCache[p.cacheKey]
            e == null || !e.isResolved
        }
        if (unresolved || collectionIncomplete) {
            scheduleRetry()
        } else {
            retryJob?.cancel()
        }
    }

    /** Set by [collectPoints] when the collector had no viewport tile coords yet. */
    private var coordsWereEmpty = false

    private fun quantizedBoundsKey(bounds: LatLonBounds): String {
        fun q(v: Double) = (v * 200.0).roundToInt()
        return "${q(bounds.westExtent)},${q(bounds.southExtent)},${q(bounds.eastExtent)},${q(bounds.northExtent)}"
    }

    private fun scheduleRetry() {
        if (destroyed) return
        if (sampleJob?.isActive == true) {
            samplePending = true
            return
        }
        if (retryJob?.isActive == true) return
        retryJob = controller.viewModelScope.launch {
            delay(RETRY_DELAY_MS)
            scheduleRefresh(immediate = true)
        }
    }

    private fun boundsAreUsable(bounds: LatLonBounds): Boolean {
        val w = bounds.westExtent
        val e = bounds.eastExtent
        val s = bounds.southExtent
        val n = bounds.northExtent
        if (!w.isFinite() || !e.isFinite() || !s.isFinite() || !n.isFinite()) return false
        if (abs(e - w) < 1e-9 || abs(n - s) < 1e-9) return false
        return true
    }

    private suspend fun collectPoints(bounds: LatLonBounds, myGen: Long): List<CollectedPoint>? {
        val collector = controller.getLayer(pointCollectorLayerId) as? VectorTileLayer
        val source = collector?.source as? VectorTileSource
        if (collector == null || source == null) {
            MapsGLDebug.trace("[$TAG] missing point collector for $queryLayerId")
            scheduleRetry()
            return null
        }

        collector.bounds = bounds
        val mapZoomNow = CameraSync.zoomForCustomLayerInstancing()
        val placeCap = VectorSymbolPlacementDefaults.placeLabelMaxDataZoom(collector.id)
        var coords =
            if (placeCap != null) {
                collector.visibleTileCoordsForMapboxVectorCacheAtDataZoom(
                    mapZoomNow.coerceAtMost(placeCap),
                )
            } else {
                collector.visibleTileCoordsForMapboxVectorCache()
            }
        if (coords.isEmpty()) {
            val zHint = floor(mapZoomNow).toInt().coerceAtLeast(0)
            coords = (zHint downTo (zHint - 2).coerceAtLeast(0)).flatMap { z ->
                source.cachedTileCoordsWithDataAtZ(z)
            }.distinctBy { "${it.z}/${it.x}/${it.y}" }
        }
        coordsWereEmpty = coords.isEmpty()
        val tileKey = coords.joinToString(",") { "${it.z}/${it.x}/${it.y}" }

        // Geometry is timeline-invariant — reuse during playback/scrub when the tile set matches.
        // Return the full cached set (do not re-cull with getBounds). Confirmed live: after a good
        // collect, the same tileKey + isPointVisible filter returned 0 points while complete=true,
        // which held forever and never refreshed labels for the settled viewport.
        if (collectionComplete && collectionCacheKey == tileKey && coords.isNotEmpty()) {
            return collectionCache
        }

        // Same tile zoom / prefetch path as VectorSymbolLayerRenderer — requestVisibleTiles uses
        // zoomOffset and misses the CustomGeometrySource cache (see TileLayer KDoc).
        try {
            collector.prefetchVectorTilesForGlRendering(bypassThrottle = true)
        } catch (t: Throwable) {
            MapsGLDebug.trace("[$TAG] point tile prefetch failed: ${t.message}")
        }
        if (myGen != generation) return null

        // Viewport may have shifted while prefetch ran; recompute coords once.
        coords =
            if (placeCap != null) {
                collector.visibleTileCoordsForMapboxVectorCacheAtDataZoom(
                    CameraSync.zoomForCustomLayerInstancing().coerceAtMost(placeCap),
                )
            } else {
                collector.visibleTileCoordsForMapboxVectorCache()
            }
        if (coords.isEmpty()) {
            val zHint = floor(CameraSync.zoomForCustomLayerInstancing()).toInt().coerceAtLeast(0)
            coords = (zHint downTo (zHint - 2).coerceAtLeast(0)).flatMap { z ->
                source.cachedTileCoordsWithDataAtZ(z)
            }.distinctBy { "${it.z}/${it.x}/${it.y}" }
        }
        coordsWereEmpty = coords.isEmpty()
        val tileKeyAfter = coords.joinToString(",") { "${it.z}/${it.x}/${it.y}" }
        if (collectionComplete && collectionCacheKey == tileKeyAfter && coords.isNotEmpty()) {
            return collectionCache
        }

        val byDedup = linkedMapOf<String, CollectedPoint>()
        var anyMissing = false
        var featureCount = 0
        var rejectFilter = 0
        var rejectGeom = 0
        var rejectName = 0
        for (coord in coords) {
            val tile = source.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y)
            @Suppress("UNCHECKED_CAST")
            val vectorData = (tile as? Tile<*>)?.data as? VectorData
            if (vectorData == null) {
                anyMissing = true
                continue
            }
            for (feature in vectorData.features) {
                featureCount++
                if (!passesFilter(feature)) {
                    rejectFilter++
                    continue
                }
                val geometry = feature.geometry() as? Point
                if (geometry == null) {
                    rejectGeom++
                    continue
                }
                val lon = geometry.longitude()
                val lat = geometry.latitude()
                // Soft viewport cull with pad. Hard [isPointVisible] against getBounds() was
                // confirmed live to disagree with visible tile coords after pan (553 → kept=0).
                // Prefer a padded cull for density; if that empties a non-empty tile set, keep
                // tile members (Mapbox collision drops off-screen points).
                val name = resolveLabel(feature)
                if (name == null) {
                    rejectName++
                    continue
                }
                val rank = resolveRank(feature)
                val dedup = dedupKey(lon, lat)
                val cache = cacheKey(lon, lat, name)
                val existing = byDedup[dedup]
                if (existing == null || rank < existing.rankScore) {
                    byDedup[dedup] = CollectedPoint(lon, lat, name, rank, dedup, cache)
                }
            }
        }

        // Empty coords or missing tiles are incomplete — never treat as a settled empty ocean.
        // Confirmed live: a force pass mid-pan saw 5 tiles / 450 place features but kept=0
        // (bounds vs tile mismatch while the camera settled), marked complete, published an empty
        // FeatureCollection, and wiped the prior 39 labels — then the playhead early-out locked
        // that empty GeoJSON forever.
        val allPoints = byDedup.values.toList()
        val nearViewport = allPoints.filter { isPointNearViewport(it.lon, it.lat, bounds) }
        val scoped =
            if (nearViewport.isNotEmpty()) nearViewport
            else allPoints
        val capped =
            if (scoped.size <= MAX_LABEL_POINTS) scoped
            else scoped.sortedBy { it.rankScore }.take(MAX_LABEL_POINTS)
        val keptEmptyDespiteFeatures = capped.isEmpty() && featureCount > 0
        collectionComplete = coords.isNotEmpty() && !anyMissing && !keptEmptyDespiteFeatures
        if (collectionComplete) {
            collectionCacheKey = tileKeyAfter
            collectionCache = capped
        }
        Log.i(
            TAG,
            "collect coords=${coords.size} z=${coords.firstOrNull()?.z} features=$featureCount " +
                "kept=${capped.size} near=${nearViewport.size} all=${allPoints.size} " +
                "complete=$collectionComplete missing=$anyMissing " +
                "rej(filter=$rejectFilter geom=$rejectGeom name=$rejectName) " +
                "bounds=${"%.2f".format(bounds.westExtent)},${"%.2f".format(bounds.southExtent)}," +
                "${"%.2f".format(bounds.eastExtent)},${"%.2f".format(bounds.northExtent)}",
        )
        return capped
    }

    private fun passesFilter(feature: Feature): Boolean {
        val filter = descriptor.filter ?: return true
        val raw = filter.raw
        if (raw is List<*> && raw.isNotEmpty()) {
            val classVal =
                feature.getStringProperty("class")
                    ?: feature.properties()?.get("class")?.takeIf { it.isJsonPrimitive }?.asString
                    ?: return false
            return classVal == "city" || classVal == "town"
        }
        return true
    }

    private fun resolveLabel(feature: Feature): String? =
        PlaceLabelText.resolvePreferredName(feature, descriptor.labelKeyPath)

    private fun resolveRank(feature: Feature): Double {
        nestedProperty(feature, descriptor.rankKeyPath)?.let { v ->
            return (v as? Number)?.toDouble() ?: v.toString().toDoubleOrNull() ?: Double.MAX_VALUE
        }
        feature.getNumberProperty("rank")?.let { return it.toDouble() }
        return Double.MAX_VALUE
    }

    private fun nestedProperty(feature: Feature, keyPath: String): Any? {
        if (keyPath.isBlank()) return null
        val props = feature.properties() ?: return null
        // Flat key first (guide: try literal flat key of the same name).
        jsonValue(props.get(keyPath))?.let { return it }
        if (!keyPath.contains('.')) return null
        val leaf = keyPath.substringAfterLast('.')
        return jsonValue(props.get(leaf))
    }

    private fun jsonValue(el: JsonElement?): Any? {
        if (el == null || el.isJsonNull) return null
        if (!el.isJsonPrimitive) return null
        val p = el.asJsonPrimitive
        return when {
            p.isNumber -> p.asDouble
            p.isString -> p.asString
            p.isBoolean -> p.asBoolean
            else -> p.toString()
        }
    }

    private fun isPointVisible(lon: Double, lat: Double, bounds: LatLonBounds): Boolean {
        if (lat < bounds.southExtent || lat > bounds.northExtent) return false
        val west = bounds.westExtent
        val east = bounds.eastExtent
        // World-wrap: shift lon into [west, west+360…) span that may cross ±180.
        val shifted = lon + 360.0 * ceil((west - lon) / 360.0)
        return shifted <= east + 1e-9
    }

    /** Like [isPointVisible] but expands the viewport so lagging getBounds() still keep tile members. */
    private fun isPointNearViewport(lon: Double, lat: Double, bounds: LatLonBounds): Boolean {
        val lonSpan = abs(bounds.eastExtent - bounds.westExtent).coerceAtLeast(1e-6)
        val latSpan = abs(bounds.northExtent - bounds.southExtent).coerceAtLeast(1e-6)
        val padLon = lonSpan * VIEWPORT_PAD_FRACTION
        val padLat = latSpan * VIEWPORT_PAD_FRACTION
        val padded = LatLonBounds(
            westExtent = bounds.westExtent - padLon,
            southExtent = bounds.southExtent - padLat,
            eastExtent = bounds.eastExtent + padLon,
            northExtent = bounds.northExtent + padLat,
        )
        return isPointVisible(lon, lat, padded)
    }

    private fun dedupKey(lon: Double, lat: Double): String {
        val qLon = (lon * DEDUP_QUANTIZE).roundToInt()
        val qLat = (lat * DEDUP_QUANTIZE).roundToInt()
        return "$qLon,$qLat"
    }

    private fun cacheKey(lon: Double, lat: Double, name: String): String {
        // Mercator-ish normalized buckets (~4 km) + label — zoom-stable.
        val x = ((lon + 180.0) / 360.0).coerceIn(0.0, 1.0)
        val sinLat = kotlin.math.sin(Math.toRadians(lat)).coerceIn(-0.9999, 0.9999)
        val y = (0.5 - kotlin.math.ln((1 + sinLat) / (1 - sinLat)) / (4 * Math.PI)).coerceIn(0.0, 1.0)
        val bx = (x * IDENTITY_BUCKETS).roundToInt()
        val by = (y * IDENTITY_BUCKETS).roundToInt()
        return "$bx:$by:$name"
    }

    private fun progressBucket(meld: Float): Int =
        (meld.coerceIn(0f, 1f) * SUB_INTERVAL_BUCKETS).roundToInt().coerceIn(0, SUB_INTERVAL_BUCKETS)

    private fun needsEndpointSample(
        key: String,
        intervalA: Int,
        intervalB: Int,
        dataZoom: Int,
        meldEnabled: Boolean,
    ): Boolean {
        val entry = valueCache[key] ?: return true
        if (dataZoom > entry.zoom) return true
        if (entry.intervalA != intervalA || entry.intervalB != intervalB) return true
        if (entry.valueA == null && entry.valueB == null) return !entry.isResolved
        if (meldEnabled && entry.valueA != null && entry.valueB == null) return !entry.isResolved
        return false
    }

    private fun sampleEndpoints(
        lon: Double,
        lat: Double,
        layer: EncodedTileLayer?,
    ): EncodedTileLayer.EncodedNumericEndpoints? {
        if (layer == null) return null
        val zoomBase = CameraSync.customLayerRenderZoom ?: CameraSync.camera.zoom
        val zoomVar = floor(zoomBase + layer.zoomOffset).toInt().coerceAtLeast(0)
        val latTile = TileConversions.latToTile(lat, zoomVar)
        val lonTile = TileConversions.lonToTileNormalized(lon, zoomVar)
        val latPix = TileConversions.getLatPixelInTile(lat, zoomVar, 512).toInt()
        val lonPix = TileConversions.getLonPixelInTile(lon, zoomVar, 512).toInt()
        return layer.queryNumericEndpoints(zoomVar, latTile, lonTile, latPix, lonPix)
    }

    private fun applyEndpointResult(
        key: String,
        endpoints: EncodedTileLayer.EncodedNumericEndpoints?,
        intervalA: Int,
        intervalB: Int,
        progressBucket: Int,
        dataZoom: Int,
        dataRevision: Long,
        t: Float,
    ) {
        val existing = valueCache[key]
        if (endpoints != null && (endpoints.valueA != null || endpoints.valueB != null)) {
            val valueA = endpoints.valueA ?: existing?.valueA
            val valueB = endpoints.valueB ?: existing?.valueB
            val lerped = when {
                valueA != null && valueB != null -> valueA * (1.0 - t) + valueB * t
                valueA != null -> valueA
                valueB != null -> valueB
                else -> null
            }
            valueCache[key] = CacheEntry(
                intervalA = intervalA,
                intervalB = intervalB,
                progressBucket = progressBucket,
                zoom = dataZoom,
                valueA = valueA,
                valueB = valueB,
                value = lerped,
                unit = UnitTemperature.celsius,
                stale = valueB == null && t > 0f,
                dataRevision = dataRevision,
                missStreak = 0,
            )
            return
        }
        if (existing?.value != null && existing.missStreak < MAX_HELD_MISSES) {
            existing.missStreak++
            existing.stale = true
            existing.dataRevision = dataRevision
            existing.alignToPlayhead(intervalA, intervalB)
            existing.progressBucket = progressBucket
            return
        }
        valueCache[key] = CacheEntry(
            intervalA = intervalA,
            intervalB = intervalB,
            progressBucket = progressBucket,
            zoom = dataZoom,
            valueA = existing?.valueA,
            valueB = existing?.valueB,
            value = existing?.value,
            unit = UnitTemperature.celsius,
            stale = false,
            dataRevision = dataRevision,
            missStreak = (existing?.missStreak ?: 0) + 1,
        )
    }

    private fun republishFromCache(
        reformatOnly: Boolean,
        points: List<CollectedPoint>? = null,
    ) {
        val pts = points ?: collectionCache.filter {
            try {
                isPointNearViewport(it.lon, it.lat, controller.getBounds())
            } catch (_: Throwable) {
                true
            }
        }
        var changed = reformatOnly
        val nextPublished = linkedMapOf<String, String?>()
        val features = ArrayList<Feature>(pts.size)
        val units = controller.units

        for (point in pts) {
            val entry = valueCache[point.cacheKey]
            val numeric = entry?.value
            // Gate on the *displayed* label, not raw float — meld ticks often re-sample without
            // changing what the user sees, and GeoJSON writes rebuild symbols.
            val label = numeric?.let { formatValue(it, units) }
            nextPublished[point.cacheKey] = label

            if (!changed) {
                if (point.cacheKey !in publishedLabels || publishedLabels[point.cacheKey] != label) {
                    changed = true
                }
            }

            val props = HashMap<String, Any>(4)
            props["name"] = point.name
            props["rankScore"] = point.rankScore
            if (label != null) {
                props["value"] = label
            }
            val feature = Feature.fromGeometry(Point.fromLngLat(point.lon, point.lat), null, point.cacheKey)
            for ((k, v) in props) {
                when (v) {
                    is String -> feature.addStringProperty(k, v)
                    is Number -> feature.addNumberProperty(k, v)
                    else -> feature.addStringProperty(k, v.toString())
                }
            }
            features.add(feature)
        }

        if (!changed) {
            for (key in publishedLabels.keys) {
                if (key !in nextPublished) {
                    changed = true
                    break
                }
            }
        }

        if (!changed && !reformatOnly) return

        publishedLabels.clear()
        publishedLabels.putAll(nextPublished)
        publishSource.data = FeatureCollection.fromFeatures(features)
        Log.i(TAG, "publish features=${features.size} reformatOnly=$reformatOnly")
        (controller.getLayer(queryLayerId) as? TileLayer)?.setNeedsUpdate(force = true)
        controller.redraw()
    }

    /**
     * Format a raw encoded sample for display. Source units match [encodedQueryUnitForLayerId]
     * / inspector conventions (°C, %, m/s, mbar, m, mm/s). The early sampled-value path
     * always treated samples as Celsius — that incorrectly °F-converted humidity and other
     * catalog products after the shared PlaceValueText expansion.
     */
    private fun formatValue(raw: Double, units: MeasurementUnits): String {
        return when (descriptor.sampledLayerCode) {
            LayerCode.TEMPERATURES,
            LayerCode.FEELS_LIKE,
            LayerCode.DEW_POINTS,
            LayerCode.WIND_CHILL,
            LayerCode.HEAT_INDEX,
            -> formatTemperature(raw, units.temperature)

            LayerCode.TEMPERATURES_24_HOUR_CHANGE,
            LayerCode.TEMPERATURES_1_HOUR_CHANGE,
            -> formatTemperatureDelta(raw, units.temperatureDelta)

            LayerCode.HUMIDITY,
            -> "${roundHalfUp(raw).toInt()}%"

            LayerCode.WIND_SPEEDS,
            LayerCode.WIND_GUSTS,
            -> formatSpeedMetersPerSecond(raw, units.speed)

            LayerCode.PRESSURE_MEAN_SEA_LEVEL,
            -> formatPressureMillibars(raw, units.pressure)

            LayerCode.VISIBILITY,
            -> formatDistanceMeters(raw, units.distance)

            LayerCode.PRECIPITATION,
            -> formatPrecipMmPerSec(raw, units.precipitationRate)

            LayerCode.SNOW,
            -> formatSnowMm(raw, units.snowfall)

            LayerCode.ULTRAVIOLET_INDEX,
            LayerCode.AIR_QUALITY_INDEX,
            LayerCode.AIR_QUALITY_INDEX_CAI_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_CHINA_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_EAQI_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_INDIA_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_UBA_DAQI_CATEGORIES,
            LayerCode.AIR_QUALITY_INDEX_UK_DAQI_CATEGORIES,
            -> "${roundHalfUp(raw).toInt()}"

            LayerCode.CARBON_MONOXIDE,
            LayerCode.NITRIC_OXIDE,
            LayerCode.NITROGEN_DIOXIDE,
            LayerCode.OZONE,
            LayerCode.PARTICULATE_MATTER_10_MICRON,
            LayerCode.PARTICULATE_MATTER_2P5_MICRON,
            LayerCode.SULFUR_DIOXIDE,
            -> {
                val rounded = roundHalfUp(raw * 10.0) / 10.0
                if (rounded == floor(rounded)) "${rounded.toInt()}" else rounded.toString()
            }

            else -> "${roundHalfUp(raw).toInt()}"
        }
    }

    private fun formatTemperature(celsius: Double, target: UnitTemperature): String {
        val display = when (target) {
            is UnitTemperature.Fahrenheit -> celsius * 9.0 / 5.0 + 32.0
            is UnitTemperature.Kelvin -> celsius + 273.15
            else -> celsius
        }
        return "${roundHalfUp(display).toInt()}${target.symbol}"
    }

    private fun formatTemperatureDelta(celsiusDelta: Double, target: UnitTemperature): String {
        val display = when (target) {
            is UnitTemperature.Fahrenheit -> celsiusDelta * 9.0 / 5.0
            else -> celsiusDelta
        }
        val rounded = roundHalfUp(display).toInt()
        val sign = if (rounded > 0) "+" else ""
        return "$sign$rounded${target.symbol}"
    }

    private fun formatSpeedMetersPerSecond(metersPerSecond: Double, target: UnitSpeed): String {
        val display = when (target) {
            is UnitSpeed.MilesPerHour -> metersPerSecond / 0.44704
            is UnitSpeed.KilometersPerHour -> metersPerSecond * 3.6
            is UnitSpeed.Knots -> metersPerSecond / 0.514444
            else -> metersPerSecond
        }
        return "${roundHalfUp(display).toInt()}${target.symbol.trim()}"
    }

    private fun formatPressureMillibars(mbar: Double, target: UnitPressure): String {
        return when (target) {
            is UnitPressure.InchesOfMercury -> {
                val inHg = mbar * 0.0295299830714
                String.format(java.util.Locale.US, "%.2f%s", inHg, target.symbol)
            }
            else -> "${roundHalfUp(mbar).toInt()}${target.symbol}"
        }
    }

    private fun formatDistanceMeters(meters: Double, target: UnitLength): String {
        val display = when (target) {
            is UnitLength.Miles -> meters / 1609.34
            is UnitLength.Kilometers -> meters / 1000.0
            is UnitLength.Feet -> meters / 0.3048
            else -> meters
        }
        return when (target) {
            is UnitLength.Miles, is UnitLength.Kilometers ->
                String.format(java.util.Locale.US, "%.1f%s", display, target.symbol)
            else -> "${roundHalfUp(display).toInt()}${target.symbol}"
        }
    }

    /** Encoded precip samples are mm/s; legends display as mm/h or in/h (×3600). */
    private fun formatPrecipMmPerSec(mmPerSec: Double, target: UnitLength): String {
        val perHour = mmPerSec * 3600.0
        val display = when (target) {
            is UnitLength.Inches -> perHour / 25.4
            else -> perHour
        }
        return String.format(java.util.Locale.US, "%.2f%s", display, target.symbol.trim())
    }

    /** Snow depth samples are mm liquid-equivalent depth in the encoded product. */
    private fun formatSnowMm(mm: Double, target: UnitLength): String {
        val display = when (target) {
            is UnitLength.Inches -> mm / 25.4
            is UnitLength.Centimeters -> mm / 10.0
            else -> mm
        }
        return String.format(java.util.Locale.US, "%.1f%s", display, target.symbol.trim())
    }

    private fun roundHalfUp(value: Double): Double = floor(value + 0.5)
}

/** Expose zoom helper used by the coordinator without widening TileLayer's public API further. */
internal fun EncodedTileLayer.zoomForVisibleTilesPublic(): Double = zoomForVisibleTiles()
