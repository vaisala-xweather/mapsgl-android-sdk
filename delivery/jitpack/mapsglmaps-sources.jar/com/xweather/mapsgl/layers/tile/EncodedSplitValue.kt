package com.xweather.mapsgl.layers.tile

import com.xweather.mapsgl.weather.EncodedDataset

/**
 * Reading a value that a source spreads across several bands.
 *
 * MapsGL JS packs one precipitation rate into `rgb` with each band covering a third of the range
 * (`dataRange` 0–⅓, ⅓–⅔, ⅔–1 of the same `PRATE` dataset), filling one band before spilling into the
 * next. That carries 765 steps instead of 255. The value is the bands' total over the whole span, from
 * the first band's minimum to the last band's maximum (native-port handoff B4.5, B7.4).
 *
 * The CPU readers (data inspector, `*-text` labels) used to decode the first band alone against its own
 * range. That is exact only while every band repeats the full range, and wrong as soon as the bands
 * split. [combine] turns the bands into one equivalent byte over the whole span, so the readers keep
 * their single-byte logic and give identical results for full-range packs.
 */
internal object EncodedSplitValue {

    /**
     * The datasets of a value spread across [channels]: every sampled channel, when there is more than
     * one and each reads the same dataset code with no no-data byte. Null otherwise, including for
     * packs of different variables (sleet and ice carry temperature in their third band).
     */
    fun valueBands(datasets: List<EncodedDataset>, channels: List<Int>): List<EncodedDataset>? {
        if (channels.size < 2) return null
        val bands = channels.map { datasets.getOrNull(it) ?: return null }
        val code = bands.first().code
        if (bands.any { it.code != code || it.noData != null }) return null
        return bands
    }

    /** The real-world range a value spread across [bands] covers. */
    fun span(bands: List<EncodedDataset>): ClosedRange<Double> =
        bands.first().dataRange.start..bands.last().dataRange.endInclusive

    /**
     * The real-world range a layer sampling [channels] reads: the whole span when they hold one split
     * value, otherwise the first channel's own dataset range. This is what a colour scale, a legend and
     * the decode must agree on; the first band of a split value covers only part of it.
     */
    fun valueRange(datasets: List<EncodedDataset>, channels: List<Int>): ClosedRange<Double>? =
        valueBands(datasets, channels)?.let { span(it) }
            ?: channels.firstOrNull()?.let { datasets.getOrNull(it)?.dataRange }

    /**
     * One equivalent byte (0–255 over [span]) for a value spread across bands: their average, since
     * the bands' total over `255 × n` is the value's position in the span. Null if any band is missing.
     */
    fun combine(bytes: List<Float?>): Float? {
        if (bytes.isEmpty()) return null
        var total = 0f
        for (b in bytes) total += b ?: return null
        return total / bytes.size
    }

    /**
     * The `sampleColorValue` channel code in `sample.frag.combined.glsl` that averages [channels] on
     * the GPU, the shader's counterpart of [combine]; null for a set it has no code for. Reading the
     * first band alone against the whole span draws every value in that band's slice several times
     * too high.
     */
    fun shaderChannel(channels: List<Int>): Int? = when (channels.toSortedSet().toList()) {
        listOf(0, 1) -> 4
        listOf(1, 2) -> 5
        listOf(0, 2) -> 6
        listOf(0, 3) -> 7
        listOf(1, 3) -> 8
        listOf(2, 3) -> 9
        listOf(0, 1, 2) -> 10
        listOf(1, 2, 3) -> 11
        listOf(0, 1, 2, 3) -> 12
        else -> null
    }
}
