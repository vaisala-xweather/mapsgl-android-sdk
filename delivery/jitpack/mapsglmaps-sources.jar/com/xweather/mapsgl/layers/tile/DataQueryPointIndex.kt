package com.xweather.mapsgl.layers.tile

import kotlin.math.ceil
import kotlin.math.floor

/**
 * A coarse lat/lon grid over a fixed set of points, for answering "which points are in this
 * viewport" without walking all of them.
 *
 * Built once per point set - [DataQueryCoordinator] rebuilds it when a GeoJSON point source's data
 * changes - and queried on every collect pass. A tiled point source never needs this, since tiles
 * already hand over only the points near the viewport; a GeoJSON collection holds every point in
 * memory, and scanning all of them on each pan grows linearly with the collection.
 *
 * Coordinates are held in primitive arrays and each cell in an [IntArray] of point indices, so a
 * query allocates only its result list. Longitudes are normalized into `[-180, 180)`, and a query
 * whose longitude span crosses the antimeridian or exceeds 360 degrees wraps, the same way a map
 * viewport does.
 */
internal class DataQueryPointIndex<T>(
    private val points: List<T>,
    lon: (T) -> Double,
    lat: (T) -> Double,
    private val cellDegrees: Double = DEFAULT_CELL_DEGREES,
) {
    private val cols = ceil(360.0 / cellDegrees).toInt()
    private val rows = ceil(180.0 / cellDegrees).toInt()
    private val lons = DoubleArray(points.size) { normalizeLon(lon(points[it])) }
    private val lats = DoubleArray(points.size) { lat(points[it]).coerceIn(-90.0, 90.0) }
    private val cells: Array<IntArray>

    init {
        // Two passes - count, then fill - so each cell is one exact-size IntArray rather than a
        // growable list of boxed indices.
        val counts = IntArray(cols * rows)
        val cellOf = IntArray(points.size) { i -> cellIndex(colOf(lons[i]), rowOf(lats[i])).also { counts[it]++ } }
        val filled = IntArray(cols * rows)
        cells = Array(cols * rows) { IntArray(counts[it]) }
        for (i in points.indices) {
            val c = cellOf[i]
            cells[c][filled[c]++] = i
        }
    }

    val size: Int get() = points.size

    /**
     * Points inside the box, grouped by cell. [east] may exceed 180 or be less than [west] - both
     * describe a box across the antimeridian - and a span of 360 degrees or more returns every
     * longitude.
     */
    fun query(west: Double, south: Double, east: Double, north: Double): List<T> {
        if (points.isEmpty()) return emptyList()
        val lo = minOf(south, north).coerceIn(-90.0, 90.0)
        val hi = maxOf(south, north).coerceIn(-90.0, 90.0)
        // A box written across the antimeridian as (170, -170) means 170 through 190.
        val eastUnwrapped = if (east < west) east + 360.0 else east
        val span = eastUnwrapped - west
        val wholeWorld = span >= 360.0

        val rowFrom = rowOf(lo)
        val rowTo = rowOf(hi)
        val colFrom = colOf(normalizeLon(west))
        val colCount = if (wholeWorld) cols else (ceil(span / cellDegrees).toInt() + 1).coerceIn(1, cols)

        val result = ArrayList<T>()
        for (step in 0 until colCount) {
            val col = (colFrom + step) % cols
            for (row in rowFrom..rowTo) {
                for (i in cells[cellIndex(col, row)]) {
                    val pointLat = lats[i]
                    if (pointLat < lo || pointLat > hi) continue
                    if (!wholeWorld && !lonWithin(lons[i], west, eastUnwrapped)) continue
                    result.add(points[i])
                }
            }
        }
        return result
    }

    private fun colOf(normalizedLon: Double): Int =
        floor((normalizedLon + 180.0) / cellDegrees).toInt().coerceIn(0, cols - 1)

    private fun rowOf(lat: Double): Int =
        floor((lat + 90.0) / cellDegrees).toInt().coerceIn(0, rows - 1)

    private fun cellIndex(col: Int, row: Int) = row * cols + col

    companion object {
        /**
         * Five degrees: 72 x 36 cells. Small enough that a city-scale viewport visits a handful of
         * cells, large enough that a sparse world-wide set does not spread one point per cell.
         */
        const val DEFAULT_CELL_DEGREES = 5.0

        fun normalizeLon(lon: Double): Double {
            val wrapped = ((lon + 180.0) % 360.0 + 360.0) % 360.0 - 180.0
            return if (wrapped >= 180.0) wrapped - 360.0 else wrapped
        }

        /** True when [lon] falls in `[west, east]`, shifting it by whole turns to meet [west]. */
        fun lonWithin(lon: Double, west: Double, east: Double): Boolean {
            val shifted = lon + 360.0 * ceil((west - lon) / 360.0)
            return shifted <= east + 1e-9
        }
    }
}
