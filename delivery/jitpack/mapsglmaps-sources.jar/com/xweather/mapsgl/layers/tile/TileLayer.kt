/**
 * TileLayer.kt
 *
 *  Adapted from IOS version
 *
 * @author Jason Suto 12/22/23
 *
 **/

package com.xweather.mapsgl.layers.tile

import android.content.Context
import android.os.Looper
import com.xweather.mapsgl.MapsGLFeatures
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.series.AnyTimeSeries
import com.xweather.mapsgl.data.series.Data
import com.xweather.mapsgl.data.series.TimeSeries
import com.xweather.mapsgl.data.series.TimeSeriesAnimator
import com.xweather.mapsgl.data.series.TimeSeriesAnimatorOptions
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.geo.Viewport
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableD
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.spec.MaskLayerKind
import com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.MapsGLLayerError
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.LayerRenderer
import com.xweather.mapsgl.renderers.TileLayerRenderer
import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TilePyramid
import com.xweather.mapsgl.tiles.TileRenderable
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType
import com.xweather.mapsgl.types.math_type.ValueRange
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.util.MapsGLLog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.coroutines.cancellation.CancellationException
import com.xweather.mapsgl.camera.TILE_SIZE
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.sinh
import kotlin.time.Duration

private const val TAG = "TileLayer"

/** Rule: world-tile-first-on-add. Poll interval / attempt cap while waiting for the source
 * timeline to publish intervals (~16s total) before giving up on priming the z=0 world tile. */
private const val WORLD_TILE_PRIME_RETRY_MS = 400L
private const val WORLD_TILE_PRIME_ATTEMPTS = 40

/**
 * Per-frame render state passed to a [TileLayerRenderer]: the paint style to render with, the
 * renderables to draw, elapsed animation time, and the current zoom level.
 */
data class RenderContext<RenderableType>(
    /** The paint/style configuration to render this frame's [renderables] with. */
    override var paintStyle: LayerPaint, //PaintStyle,
    /** Time elapsed since the layer's animation began; drives time-based rendering effects. */
    override var elapsedTime: Duration = Duration.ZERO,
    /** The drawable items to render this frame, e.g. tiles resolved for the current viewport. */
    override var renderables: List<RenderableType> = listOf(), //List<TileRenderable<DataType>> = emptyList()
    //var projectionMatrix: ProjectiveTransform3D = ProjectiveTransform3D.identity,
    /** The map zoom level in effect for this frame, used for zoom-dependent rendering decisions. */
    override var zoomLevel: Double = 0.0
) : LayerRenderContext<RenderableType>

/** Configuration shared by layers that render data from a tile-based data source. */
interface TileLayerConfig /*: WebGLLayerConfig*/ {
    /** * Quality to use when rendering data.   */
    var quality: DataQuality

    /**  * Range of values to use when rendering data.  */
    var dataRange: ValueRange
    /**
     * Offset to apply to the map's zoom level when requesting data from the data source. This is useful to render data
     * at a different zoom level than the map's zoom level.
     */
    //var zoomOffset: Int
}

/** Represents a layer that renders data from a tile-based data source.
 *   This is the base class for all tile-based layers and is not intended to be used directly.
 */
open class TileLayer(
    /** Unique identifier for this layer within the map, used to look it up (e.g. via [MapController]). */
    final override var id: String,
    /** The tile data source this layer downloads and renders tiles from. */
    override var source: TileSource<TileData>,
    /** The paint/style configuration used to render this layer's data. */
    override var paint: LayerPaint,//SampleLayerPaint, //PaintStyle
    /** The GL renderer that builds and draws this layer's tile geometry each frame. */
    var tileLayerRenderer: TileLayerRenderer<TileData, LayerRenderContext<Any>>, //private?
    /** Offset applied to the map's zoom level when computing which tile z/x/y to request and draw for this layer. */
    var zoomOffset: Int,
    /** Coroutine scope used for this layer's background tile-download and prep work. */
    val externalScope: CoroutineScope,
    /** Data quality/resolution to request and render tiles at. Defaults to [DataQuality.exact]. */
    var quality: DataQuality = DataQuality.exact,

    ) : MapLayer<TileData, LayerRenderContext<Any>> {

    /**
     * Set by [TileLayerRenderer] when this layer uses the special multiband p-type radar shader
     * path (currently only for the "conditions.radar.fill" layer), selecting the radar fragment
     * shader/program variant instead of the standard sample-layer one.
     */
    var isRadar = false
    /** GLES stencil base mask kind for this layer (LAND/WATER/TRANSPORTATION/COUNTRY). */
    var glStencilMaskKind: MaskLayerKind = MaskLayerKind.NONE
    /** Optional ISO alpha-2 for COUNTRY base masks. */
    var glStencilMaskCountryIso: String? = null
    /** Optional custom multi-layer stencil mask (JS-style `mask.layerIds`). */
    var stencilLayerMask: StencilLayerMaskSpec? = null
    /**
     * When true, [glStencilMaskKind] [MaskLayerKind.LAND] runs first (marine clip), then line-only
     * [stencilLayerMask] layers are intersected on land (highways on land, not oceans).
     */
    var hybridLandWithCustomLineMask: Boolean = false

    /** Holds the internal [DataQuality]-to-scale-factor lookup used to compute [dataQualityMult]. */
    companion object {
        private val dataQualityHash = mapOf(
            DataQuality.exact to 1f,
            DataQuality.high to 0.75f,
            DataQuality.medium to 0.5f,
            DataQuality.normal to 0.5f,
            DataQuality.low to 0.25f,
            DataQuality.minimal to 0.25f
        )
    }

    /** Event types this layer can notify [TileLayerEventListener]s about via [triggerEvent]. */
    enum class TileLayerEventType {
        TILES_LOADING_STATUS_CHANGED, // Example: pass a boolean or count
        DATA_UPDATED,              // Example: pass metadata about the update
        SPECIFIC_ACTION_TRIGGERED,
        FINISHED_DRAWING,
        // Your custom event
        // Add more event types as needed
    }

    /** Listener for per-layer lifecycle/data events dispatched via [addTileLayerEventListener]. */
    interface TileLayerEventListener {
        /** Called when this layer fires [eventType] for the layer identified by [layerId], with optional [data] payload. */
        fun onTileLayerEvent(layerId: String, eventType: TileLayerEventType, data: Any? = null)
    }

    private val eventListeners = mutableListOf<TileLayerEventListener>() // Or TileLayerEventListenerV2


    /** Registers [listener] to receive this layer's [TileLayerEventType] events. No-op if already registered. */
    fun addTileLayerEventListener(listener: TileLayerEventListener) { // Or TileLayerEventListenerV2
        if (!eventListeners.contains(listener)) {
            eventListeners.add(listener)
        }
    }

    /** Unregisters a previously added [TileLayerEventListener]; no-op if not registered. */
    fun removeTileLayerEventListener(listener: TileLayerEventListener) { // Or TileLayerEventListenerV2
        eventListeners.remove(listener)
    }

    /**
     * Triggers a specific event to all registered listeners.
     * @param eventType A string identifying the type of event.
     * @param data Optional data associated with the event.
     */
    protected fun triggerEvent(eventType: TileLayerEventType, data: Any? = null) { // Or eventType: TileLayerEventType
        // Consider running on a specific thread if needed (e.g., main thread for UI updates)
        // For simplicity, this triggers on the calling thread.
        externalScope.launch { // Or another appropriate scope
            eventListeners.forEach { listener ->
                listener.onTileLayerEvent(id, eventType, data)
            }
        }
    }

    private var zoomVar = 0.0
    /**
     * The current visible geographic bounds for this layer, kept in sync with the map camera by
     * [onMove]/[onMoveEnd]. Also used by renderers (e.g. gridded sidecar sampling) as a fallback
     * source of the visible bounds when the map controller isn't directly reachable.
     */
    var bounds: LatLonBounds? = null
    private var oldBounds: LatLonBounds? = null
    private var tileBounds: TileBounds? = null
    private var oldTileBounds: TileBounds? = null
    final override var eventDispatcher = EventDispatcher()
    private var visibleTileCoords: List<TileCoord> = mutableListOf()
    /** Last tile set [TileCache.evictTilesOutsideViewport] ran against — skip the eviction scan
     * when the viewport tile set hasn't actually changed (this runs on every requestVisibleTiles
     * call, including frequent playback-refresh re-confirmations of the same viewport). */
    private var lastViewportEvictionKeySet: Set<String>? = null
    /** Manages this layer's tile download requests, tile cache, and per-source timeline/interval bookkeeping. */
    val pyramid: TilePyramid<DataType> = TilePyramid(this)
    /** Opacity multiplier applied to this layer's rendered output, from 0 (fully transparent) to 1 (fully opaque). */
    override var alpha = 1.0f
    /** Reserved tile-grid width (column count); not currently populated by this layer. */
    override var numW: Int = 0
    /** Reserved tile-grid height (row count); not currently populated by this layer. */
    override var numH: Int = 0
    /** Whether this layer is currently waiting on a tile download to complete. */
    override var waitingOnDL: Boolean = false
    /** Whether this layer was waiting on a tile download as of the previous check. */
    override var wasWaitingOnDL: Boolean = false
    private var offset = 0
    private var zoom = 0.0
    private var initialLoad = true

    /**
     * Rule: world-tile-first-on-add. One-shot guard for priming the z=0 world tile when the layer
     * is first added, so [com.xweather.mapsgl.gl.RenderPass.determinePartial]'s ancestor walk has
     * something to substitute everywhere while the exact-zoom tiles download.
     *
     * Kept separate from [initialLoad], which is consumed by whichever `getVisibleTileCoords` call
     * happens first — and since `getRenderables` runs every frame while the download path only runs
     * on move, that is almost always the *render* call, which puts the root in the renderables list
     * where nothing downloads it. Measured live: the z=0 tile was never bound at all
     * (`boundZooms=[3,4]`, `z0Bound=false`) even though the walk itself resolved fine (a z6 mesh hit
     * a z4 partial), so the world tile could never act as a partial.
     */
    private var worldTilePrimed = false

    /** In-flight [primeWorldTileWhenTimelineReady] retry, so only one poll runs per layer. */
    private var worldTilePrimeJob: kotlinx.coroutines.Job? = null

    /** Streak and backoff for failed request waves; see [handleRequestFailure]. */
    private val loadFailureRetry = LoadFailureRetry()

    /** Pending automatic retry after a failed request wave, so only one waits per layer. */
    private var loadFailureRetryJob: kotlinx.coroutines.Job? = null
    private var oldRequestBounds: LatLonBounds? = null
    /** Tile bounds computed by the most recent [requestVisibleTiles] call, retained for later reference. */
    var persistentTileBounds: TileBounds? = null
    private var renderables: MutableList<TileRenderable<DataType>> = mutableListOf()

    // Rendering coordinates do not need to be recomputed every frame.
    // We only mark them dirty when bounds/viewport are updated via requestVisibleTiles().
    private var renderBoundsDirty: Boolean = true
    private var renderablesDirty: Boolean = true
    /**
     * [onMove] skips [requestVisibleTiles] while the timeline plays to limit download churn, but the
     * render path still recomputes meshes at the new map zoom each frame. Without a request at the new
     * Z, encoded tiles stay one or more levels behind until map idle or an extra zoom gesture.
     */
    private var lastOnMoveDisplayTileZ: Int? = null
    /** Tile coordinates already queued for download by [requestVisibleTiles] this session. */
    var alreadyRequested: MutableList<TileCoord> = mutableListOf()
    /** The time-series animator driving this layer's timeline playback, if timing is configured. */
    override var animator: TimeSeriesAnimator<Data>? = null
    /**
     * Unimplemented on [TileLayer]; the actual GL renderer used is [tileLayerRenderer], a more
     * specific [TileLayerRenderer] type.
     */
    override var renderer: LayerRenderer<Any>
        get() = TODO("Not yet implemented")
        set(value) {}

    /** Current data/render zoom level for this layer. */
    var z = 0.0
    private var maxVal = 0
    private var latRad = 0.0
    /** The per-frame render state (paint style, renderables, elapsed time, zoom) passed to [tileLayerRenderer]. */
    override var layerRenderContext: LayerRenderContext<Any> = RenderContext(paint)
    /** Android [Context] used to build this layer's GL shaders/programs; set in [onAdd]. */
    lateinit var drawContext: Context
    /** The time series associated with this layer, if any. */
    override var timeSeries: AnyTimeSeries? = null
    /** Identifies the weather product/configuration this layer was created for (e.g. a composite layer's shared code). */
    var code = ""
    /** Reserved for future status/error text alongside [code]; not currently populated. */
    var message = ""

    /** The map controller this layer is attached to; set by [onAdd] when the layer is added to the map. */
    override var mapController: MapController? = null
        get() = field
        set(value) {
            field = value
        }

    /** Whether this layer needs to be redrawn; set via [setNeedsUpdate]. */
    override var isDirty: Boolean = false
    /** Whether this layer is shown on the map. Toggle via the layer's show/hide API. */
    override var visible: Boolean = true

    /**
     * Lowest map zoom at which this layer draws. Null means no bound.
     *
     * **Not active in 1.8.0:** this option is recorded but ignored. Layers draw at every zoom, and
     * every encoded layer preloads its low-quality world tile whatever this is set to.
     *
     * @see isVisibleAtZoom
     */
    var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Null means no bound.
     *
     * **Not active in 1.8.0:** this option is recorded but ignored. Layers draw at every zoom, and
     * every encoded layer preloads its low-quality world tile whatever this is set to.
     *
     * @see isVisibleAtZoom
     */
    var maxZoom: Float? = null

    /**
     * Whether this layer preloads a coarse whole-world tile as pan/zoom fallback.
     *
     * Off by default: the preload is one world tile per drawn interval, so it is a real download for
     * every layer that opts in. With it off, an area the camera reaches before its own tiles arrive
     * draws blank rather than blurry.
     *
     * **Not active in 1.8.0:** this option is recorded but ignored. Layers draw at every zoom, and
     * every encoded layer preloads its low-quality world tile whatever this is set to.
     *
     * @see com.xweather.mapsgl.layers.spec.LayerDescriptor.preloadLowQuality
     */
    var preloadLowQuality: Boolean = false

    /**
     * Whether [zoom] falls inside this layer's configured range.
     *
     * Bounds are inclusive, and either end may be absent. Says nothing about [visible].
     */
    fun isWithinZoomRange(zoom: Double): Boolean =
        LayerZoomRange.contains(zoom, minZoom, maxZoom)

    /**
     * Whether the layer should draw at [zoom].
     *
     * A zoom range makes a layer visible *within* it, but never overrides a deliberate [visible] of
     * false — hiding a layer keeps it hidden at every zoom. That is the MapsGL JS rule: "a layer only
     * becomes visible inside its range if it hasn't been explicitly hidden".
     */
    fun isVisibleAtZoom(zoom: Double): Boolean =
        LayerZoomRange.isVisible(zoom, visible, minZoom, maxZoom)

    /**
     * Layer ids that depend on this layer staying live while hidden (data-query consumers).
     * When non-empty, tile requests and timeline work continue even if [visible] is false.
     */
    private val dependentLayerIds: MutableSet<String> = linkedSetOf()

    fun registerDependentLayer(dependentId: String) {
        dependentLayerIds.add(dependentId)
    }

    fun unregisterDependentLayer(dependentId: String) {
        dependentLayerIds.remove(dependentId)
    }

    val hasDependentLayers: Boolean
        get() = dependentLayerIds.isNotEmpty()

    /** Whether this layer's current animation date is within its configured valid/showable range. */
    override var enabled: Boolean = false

    /** The map's current viewport, or `null` if this layer is not attached to a map controller. */
    override val viewport: Viewport?
        get() = mapController?.viewport

    /** HTTP request options (method, headers, reload/pending behavior, radar flag, etc.) used for this layer's tile downloads. */
    val tileRequestOptions: TileRequestOptions = TileRequestOptions(isRadar = com.xweather.mapsgl.weather.WeatherSource.isRadarEncodedSourceId(id))

    /** Tile bounds computed prior to the current [currentTileBounds]. */
    var lastTileBounds: TileBounds? = null
    /** The most recently computed tile bounds for this layer's viewport. */
    var currentTileBounds: TileBounds? = null
    /** Whether the tile bounds have changed since they were last checked. */
    var tileBoundsChanged = true
    /** Most recently computed visible tile coordinates. */
    var coords: List<TileCoord>? = null
    /** Visible tile coordinates prior to the current [coords]. */
    val oldCoords: List<TileCoord>? = null
    /** Scale factor derived from [quality] via the internal [DataQuality] lookup table, applied in `zoomForVisibleTiles`. */
    val dataQualityMult: Float

    /** The time series associated with the layer, if any.
     * @internal
     */

    init {

        dataQualityMult = dataQualityHash.getOrDefault(quality, 1f)

        //should this just be MapboxMapController.
        zoomOffset += 1 //leave this be, passed from MapboxMapController
        tileLayerRenderer.id = id

        // TODO: only set up time series and animator if timing series mode is not NONE
        timeSeries = TimeSeries()
        setupTimeSeriesAnimator()
        if (pr.ON) pr.p(TAG, pr.radarFix2, "init{} isRadar:$isRadar")

    }

    /**
     * Marks this layer dirty so it redraws on the next frame, propagates the request to
     * [tileLayerRenderer], and asks [mapController] to redraw. Does nothing if the layer is
     * currently hidden, unless [force] is `true`.
     */
    override fun setNeedsUpdate(force: Boolean) {
        if (!visible && !force) {
            return
        }
        isDirty = true
        tileLayerRenderer.setNeedsUpdate()
        mapController?.redraw()
    }

    /**
     * Returns the current tile-index bounds (zoom/left/right/top/bottom) covering this layer's
     * visible viewport, recomputing from [bounds] only when the render bounds are dirty or the
     * zoom tier has changed since the last call.
     */
    fun getTileBounds(): TileBounds {
        if (bounds == null) {
            // Avoid blocking the caller thread (often UI/render) while waiting for Main.
            // On initial render, bounds should already be available from `onMove()`,
            // but this fallback prevents hard freezes if it's not.
            bounds = mapController?.getBounds()
                ?: LatLonBounds(westExtent = -180.0, southExtent = -85.0, eastExtent = 180.0, northExtent = 85.0)
        }

        //println(">>> TileLayer getTileBounds() bounds: W to E: ${bounds?.westExtent} to ${bounds?.eastExtent}")

        val zoomVarNext = zoomForVisibleTiles()
        val zoomIntNext = floor(zoomVarNext).toInt().coerceAtLeast(0)

        if (!renderBoundsDirty && tileBounds != null && tileBounds!!.zoom == zoomIntNext) {
            return tileBounds!!
        }

        zoom = mapZoomForVisibleTiles()
        zoomVar = zoomVarNext

        // Renderables follow map zoom (uncapped by encoded [source.maxZoom]) so land/water mask and
        // stencil can use native vector z; encoded rasters still use partial/parent textures as needed.
        tileBounds = getVisibleTileBounds(bounds!!, zoomVar, true)
        renderBoundsDirty = false
        return tileBounds!!
    }

    /**  gets a list of normalized renderables using getVisibleTileCoords()  */
    private fun getRenderables(): List<TileRenderable<DataType>> {
        if (!renderablesDirty) {
            return renderables
        }

        val tileBounds = getTileBounds()
        renderables.clear()

        //println(">>> TileLayer getRenderables() tileBounds: z ${tileBounds.zoom}   (${tileBounds.left} to ${tileBounds.right})")

        val visibleCoords = mapController?.let {
            getVisibleTileCoords(
                bounds!!,
                tileBounds,
                zoomVar,
                true,
            )
        }
        if (visibleCoords != null) {
            for (coord in visibleCoords) {
                renderables.add(TileRenderable(Tile(coord, null)))
            }
            oldTileBounds = tileBounds
        }
        renderablesDirty = false
        return renderables
    }

    /** * Recieves CoordinateBounds (Lat/Lon),
     * Calls  pyramid.requestTiles(coords, TileRequestOptions(reload = reload))
     * */
    suspend fun requestVisibleTiles(
        bounds: LatLonBounds,
        reload: Boolean = false,
        fromAnimation: Boolean = false
    ) {
        // After a completed play load, idle map-move / scrub must not open another HTTP wave.
        // While playing, still download missing intervals (hold only protects eviction / scrub).
        if (Timeline.holdFullTimelineResidency &&
            source.isEncoded &&
            !reload &&
            !Timeline.isGloballyPlaying
        ) {
            requeueVisibleBindsForScrub()
            return
        }
        mapController?.let { map ->
            if (visible || hasDependentLayers) {
                if (source.isEncoded) {
                    source.tileCache.publishPixelsForQuery = !visible && hasDependentLayers
                }
                // Bounds/viewport changed; re-compute renderables for the next render.
                renderBoundsDirty = true
                renderablesDirty = true

                // Match [getTileBounds] / custom-layer zoom so requested z/x/y matches GLES renderables.
                // [DataQuality] scaling lives inside [zoomForVisibleTiles] precisely so this download
                // path and the draw path cannot disagree: lowering download z on its own used to leave
                // visible rows (e.g. mid zoom) with no exact or partial texture.
                zoomVar = zoomForVisibleTiles()

                //println(">>> TileLayer requestVisibleTiles zoomOffset: ${zoomOffset}, zoomVar: $zoomVar, getDataZoom(): ${getDataZoom()} ${this.quality}")
                val tileBounds = getVisibleTileBounds(bounds, zoomVar)
                oldRequestBounds = bounds
                persistentTileBounds = tileBounds
                visibleTileCoords = getVisibleTileCoords(bounds, tileBounds, 0.0, false)

                val filteredVisibleTileCoords =
                    visibleTileCoords.filter { vtc -> //Ensure you don't request OOB tiles from server.
                        vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
                    }

                if (pr.ON && pr.tileDownloadAudit.active) {
                    val nTiles = { z: Int -> powerTableI[z] }
                    for (c in visibleTileCoords) {
                        if (c.x < 0 || c.y < 0 || c.x >= nTiles(c.z) || c.y >= nTiles(c.z)) {
                            pr.p(
                                TAG,
                                pr.tileDownloadAudit,
                                "requestVisibleTiles OOB tile not sent to download: z=${c.z} x=${c.x} y=${c.y} (n=${nTiles(c.z)}) layer=$id"
                            )
                        }
                    }
                }

                val finalTileCoords: List<TileCoord> = if (source.bounds != null) {
                    val region = source.bounds!!
                    val kept = filteredVisibleTileCoords.filter { coord -> isWithinRegionBounds(coord, region) }
                    if (pr.ON && pr.tileDownloadAudit.active) {
                        for (c in filteredVisibleTileCoords.filterNot { isWithinRegionBounds(it, region) }) {
                            pr.p(
                                TAG,
                                pr.tileDownloadAudit,
                                "requestVisibleTiles outside source.region bounds (skipped): z=${c.z} x=${c.x} y=${c.y} layer=$id source=${source.id}"
                            )
                        }
                    }
                    kept
                } else {
                    filteredVisibleTileCoords
                }

                cancelHttpOutsideVisible(finalTileCoords)

                // Release cached tile×time data for viewports no longer visible. Rule 7 ("never
                // evict the current timeline") means the *current* viewport's full range, not
                // every viewport ever visited this session — without this, GPU/native memory for
                // stale viewports never comes back and grows unbounded across pans.
                if (source.isEncoded) {
                    val sharedCoords = withSiblingSourceCoords(finalTileCoords)
                    val viewportKeySet = sharedCoords.mapTo(HashSet()) { it.hashShort() }
                    val protectedAncestorKeySet = ancestorHashShorts(sharedCoords)
                    notifyOperationViewport(viewportKeySet, protectedAncestorKeySet)
                    if (viewportKeySet != lastViewportEvictionKeySet) {
                        lastViewportEvictionKeySet = viewportKeySet
                        // Protect zoom-ancestors of the new viewport: RenderPass.determinePartial
                        // falls back to exactly these coarser tiles while the new zoom's exact
                        // tiles are still downloading, so evicting them the instant the zoom
                        // changes (racing that very fallback lookup) turned "blurry parent while
                        // loading" into a hard blank instead.
                        pyramid.tileCache.evictTilesOutsideViewport(viewportKeySet, protectedAncestorKeySet)
                    }
                }

                // Rule: world-tile-first-on-add. Prime z=0 before the viewport batch goes out, so a
                // newly-added layer has coarse global coverage for the ancestor walk to fall back on
                // instead of a blank map. Delegates to the existing quiet path rather than pushing a
                // bare TileCoord(0,0,0) into [finalTileCoords]: that path fetches the world tile for
                // the intervals actually being drawn — [TilePyramid.timesForPausedOrScrubDownload]
                // returns phase A/B, which is exactly the `currentPhaseString` determinePartial
                // looks up — whereas a bare coord carries no interval of its own. It also skips
                // intervals already satisfied, and stays out of the load indicator
                // (`trackDownloadProgress = false`).
                //
                // Only while paused: playback wants the current viewport×interval tiles first, and a
                // whole-world tile per interval would just delay them. The flag is consumed only
                // when we actually prime, so a layer added mid-playback still gets its world tile on
                // the first request after playback stops.
                //
                // The prime cannot run inline here: on the first request after a layer is added
                // [Timeline.sourceTimeHash] is still empty, so timesForPausedOrScrubDownload returns
                // nothing and the quiet path no-ops — and requestVisibleTiles does not run again
                // until a camera move, so the world tile ended up being fetched only once the user
                // panned, which is precisely the moment it was supposed to already be covering.
                // Measured: z0Bound stayed false for the whole 30s load after switching the layer on
                // and only flipped true at the instant of the first pan. Hand off to a bounded
                // retry that waits for the timeline instead.
                primeWorldTileWhenTimelineReady()

                alreadyRequested.addAll(finalTileCoords)
                tileRequestOptions.reload = reload

                val result = pyramid.requestTilesForDownload(
                    finalTileCoords,
                    tileRequestOptions,
                    externalScope,
                )

                if (result.isFailure) {
                    val err = result.exceptionOrNull()
                    if (err is CancellationException) {
                        // Parent cancelled this refresh (e.g. layer teardown). Do not abort the
                        // caller with a throw — that previously cancelled follow-up pan/play waves.
                        return
                    }
                    // Never rethrow: this runs on the main dispatcher, so a transient network
                    // failure (e.g. "Metadata load did not complete") used to kill the host app.
                    handleRequestFailure(err, reload)
                    return
                }
                if (synchronized(loadFailureRetry) { loadFailureRetry.onSuccess() }) {
                    MapsGLLog.info(TAG, "MapsGL layer $id recovered after a failed data load")
                }

                val encLayer = this as? EncodedTileLayer
                if (encLayer != null && source.isEncoded) {
                    val stencilTb = getVisibleTileBounds(bounds, zoomVar, fromGetRenderables = true)
                    val stencilCoords = getVisibleTileCoords(bounds, stencilTb, 0.0, fromGetRenderables = true)
                    if (encLayer.glStencilMaskKind != MaskLayerKind.NONE) {
                        map.schedulePrefetchGlStencilMaskTilesForWeatherRender(
                            stencilCoords,
                            encLayer.glStencilMaskKind,
                            encLayer.glStencilMaskCountryIso,
                        )
                    }
                    val customStencil = encLayer.stencilLayerMask
                    if (customStencil != null &&
                        (customStencil.layers.isNotEmpty() || customStencil.clipBounds != null)
                    ) {
                        map.schedulePrefetchGlStencilOsmTilesForCustomMask(stencilCoords)
                    }
                }

                if (mapController == null) return

                mapController!!.checkDownloadStatus(id, pyramid.tileCache.pendingCount)

                drainDeferredEncodedTiles()
            }
        }
    }

    /**
     * Same viewport and coord selection as [requestVisibleTiles], but only counts how many new
     * encoded (coord×time) pairs would be queued — no HTTP, no cache or pending-list mutation.
     * Summed across layers in [MapController.refreshVisibleLayers] to set a fixed download % denominator.
     */
    suspend fun preflightEncodedDownloadPairCount(): Int {
        if ((!visible && !hasDependentLayers) || !source.isEncoded) return 0
        val mc = mapController ?: return 0
        val b = liveTileBounds() ?: mc.getBounds().also { bounds = it }

        zoomVar = zoomForVisibleTiles()
        val tileBounds = getVisibleTileBounds(b, zoomVar)
        visibleTileCoords = getVisibleTileCoords(b, tileBounds, 0.0, false)

        val filteredVisibleTileCoords =
            visibleTileCoords.filter { vtc ->
                vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
            }

        val finalTileCoords: List<TileCoord> = if (source.bounds != null) {
            val region = source.bounds!!
            filteredVisibleTileCoords.filter { coord -> isWithinRegionBounds(coord, region) }
        } else {
            filteredVisibleTileCoords
        }

        return pyramid.preflightEncodedNewPairCount(finalTileCoords, tileRequestOptions)
    }

    private fun isWithinRegionBounds(coord: TileCoord, bounds: com.xweather.mapsgl.coordinates.LatLonBounds): Boolean {
        val n = powerTableD[coord.z]
        val lonDegPerTile = 360.0 / n
        val latRad = atan(sinh(Math.PI * (1 - 2 * coord.y / n)))
        val minLon = coord.x * lonDegPerTile - 180.0
        val maxLon = (coord.x + 1) * lonDegPerTile - 180.0
        val minLat = Math.toDegrees(atan(sinh(Math.PI * (1 - 2 * (coord.y + 1) / n))))
        val maxLat = Math.toDegrees(latRad)

        if (minLon < bounds.eastExtent && maxLon > bounds.westExtent) {
            if (minLat < bounds.northExtent && maxLat > bounds.southExtent) {
                return true
            }
        }
        return false
    }

    /** Not yet implemented on [TileLayer]; always returns an empty string. */
    override fun getInfoForLocation(lat: Double, lng: Double, zoom: Int): String {
        return ""
    }

    /** Not yet implemented on [TileLayer]. */
    override fun queryFeatures(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double?,
        queryLat: Double?,
    ): Any? {
        TODO("Not yet implemented")
    }

    /**
     * Inclusive tile-row span the viewport can physically show at [zoomInt], derived entirely from
     * live camera state: viewport height, live map zoom, and the live camera latitude.
     *
     * Returns null when any input is unreadable, so the caller can fall back to the cached
     * [bounds]-derived span. See the commentary at the call site for why this is the primary
     * computation rather than a corrective clamp.
     *
     * [MapController.getCenter] is safe on either thread; off the owning thread it returns the
     * cached centre kept current by updateCamera. Do NOT reach for [MapController.getSize] here --
     * the base implementation throws, and [MapboxMapController] does not override it.
     */
    private fun geometricLatRowSpan(zoomInt: Int): Pair<Int, Int>? {
        val viewportPx = runCatching { mapController?.mapView?.height ?: 0 }.getOrDefault(0)
        if (viewportPx <= 0) return null

        val tilePx = TILE_SIZE * Math.pow(2.0, mapZoomForVisibleTiles() - zoomInt)
        if (!tilePx.isFinite() || tilePx < 1.0) return null

        val camRow = runCatching {
            mapController?.getCenter()?.let { TileConversions.latToTile(it.lat, zoomInt) }
        }.getOrNull() ?: return null

        // +4: partial rows at the top and bottom edges, plus slack for pitch/bearing.
        val rows = ceil(viewportPx / tilePx).toInt() + 4
        if (rows < 1) return null

        val centre = camRow.coerceIn(0, maxVal)
        var newTop = centre - rows / 2
        if (newTop < 0) newTop = 0
        var newBottom = newTop + rows - 1
        if (newBottom > maxVal) {
            newBottom = maxVal
            newTop = (newBottom - rows + 1).coerceAtLeast(0)
        }
        return newTop to newBottom
    }

    /**
     * Visible bounds for tile indexing, preferring the accessor whose latitude extent is derived
     * against the **live** zoom.
     *
     * [bounds] is only refreshed on [onMove], so during a zoom animation its latitude extent still
     * belongs to the previous zoom while [zoomForVisibleTiles] is read live. Applying a deeper zoom
     * to a wider extent is what produced viewports of 102, 201, 399, 794, 1585 and 3167 rows for a
     * single screen -- and 809,987 rows at z21 -- driving tiles x intervals into OOM. The geometric
     * row clamp in [getVisibleTileBounds] caps the damage; this stops introducing the mismatch.
     *
     * [MapboxMapController.getBoundsForRenderThread] recomputes north/south from the cached camera
     * box against the current zoom, and is safe on the render thread and on tile workers. It was
     * already wired in at the call sites but only as a *fallback* after [bounds], which is non-null
     * after the first move -- so it never actually ran. Preferring it is the whole fix.
     *
     * Falls back to [bounds] when the camera box is not cached yet (early startup), then to a
     * main-thread live query.
     */
    private fun liveTileBounds(): LatLonBounds? =
        (mapController as? MapboxMapController)?.getBoundsForRenderThread()
            ?: bounds
            ?: if (Looper.myLooper() == Looper.getMainLooper()) mapController?.getBounds() else null

    internal fun getVisibleTileBounds(
        bounds: LatLonBounds,
        zoom: Double, //this zoom has offset baked in
        fromGetRenderables: Boolean = false
    ): TileBounds {
        var z = floor(zoom) //this zoom has offset baked in

        if (!fromGetRenderables) {
            if (z > source.maxZoom) z = source.maxZoom.toDouble()
        }

        var zoomInt = floor(z).toInt()
        if (zoomInt < 0) zoomInt = 0
        // Clamp the top as well as the bottom. [powerTableI] covers z0..z22; `zoom` here has
        // [zoomOffset] baked in and the maxZoom clamp above is skipped when [fromGetRenderables],
        // which is the render path. At data zoom 23 this threw ArrayIndexOutOfBoundsException on the
        // render thread, and because that leaves a pending exception, Mapbox's next JNI call aborted
        // the process: "JNI DETECTED ERROR IN APPLICATION: JNI NewString called with pending
        // exception java.lang.ArrayIndexOutOfBoundsException: length=23; index=23" (SIGABRT).
        if (zoomInt > powerTableI.lastIndex) zoomInt = powerTableI.lastIndex

        maxVal = (powerTableI[zoomInt] - 1)
        if (pr.ON) pr.p(TAG, pr.dateLine, "getVisibleTileBounds() using: ${bounds.westExtent} to ${bounds.eastExtent} ")

        lastTileBounds = currentTileBounds

        // Latitude rows are derived from the LIVE camera, not from [bounds].
        //
        // In Mercator a data tile has a fixed on-screen pixel size, so the number of rows a viewport
        // can show is viewportHeight / tilePx regardless of zoom. Every input to that is read live
        // per frame, which makes it the authoritative span.
        //
        // [bounds] is only refreshed on [onMove], so during a zoom animation its latitude extent
        // still belongs to the previous zoom while `zoom` here is live. Deriving rows from it gave
        // 15 rows at z5, 28 at z6 and 102 at z8 for one 2076px screen against a true 9-13 --
        // doubling per zoom level, reaching 809,987 rows at z21 and driving tiles x intervals into
        // OOM. Longitude never had this problem because [getVisibleTileCoords] reads the camera
        // longitude live via [MapProvider.getUnwrappedCameraLonBoundsForTiles].
        //
        // Preferring [MapboxMapController.getBoundsForRenderThread] did NOT fix it. That recomputes
        // north/south against the live zoom, but from a cached camera box that goes stale the same
        // way -- measured afterwards: still 102 rows at z8. So this computes the span instead of
        // correcting it after the fact. The previous code kept the stale span and clamped it only
        // when it looked absurd, which left the clamp load-bearing for correctness.
        //
        // The cached-bounds span remains the fallback for when the viewport height or camera centre
        // cannot be read (early startup, or a controller that is not Mapbox-backed).
        var top: Int
        var bottom: Int

        val geoSpan = geometricLatRowSpan(zoomInt)
        if (geoSpan != null) {
            top = geoSpan.first
            bottom = geoSpan.second
        } else {
            // Degraded path: the live span could not be computed, so this falls back to the cached
            // extent and inherits the zoom skew described above. Worth surfacing -- it is the only
            // way the old row-explosion behaviour can still occur.
            if (_latFallbackLog++ % 200L == 0L) {
                MapsGLDebug.logW(
                    TAG,
                    "getVisibleTileBounds: no live camera span at z=$zoomInt; falling back to the " +
                        "cached latitude extent, which lags the live zoom. (1 in 200)"
                )
            }
            val yNorth = TileConversions.latToTile(bounds.northExtent, zoomInt)
            val ySouth = TileConversions.latToTile(bounds.southExtent, zoomInt)
            // Tile y grows south; northern latitudes map to smaller y. If north/south were ever
            // inverted, min/max still yields the correct inclusive span.
            top = minOf(yNorth, ySouth).coerceAtLeast(0)
            bottom = maxOf(yNorth, ySouth).coerceAtMost(maxVal)
            // Camera lat bounds can fall just inside a row while the viewport still shows the
            // neighbor row.
            top = (top - 1).coerceAtLeast(0)
            bottom = (bottom + 1).coerceAtMost(maxVal)
        }


        currentTileBounds = TileBounds(
            zoom = zoomInt,
            //swapped for the line below 250306 to fix dateline (to the left) issues on zoomOffset == -1
            // left = lonToTileNormalized(bounds.westExtent, zoomInt, fromGetRenderables),
            left = TileConversions.lonToTileNonNormalized(bounds.westExtent, zoomInt),
            right = TileConversions.lonToTileNormalized(bounds.eastExtent, zoomInt, fromGetRenderables),
            top = top,
            bottom = bottom
        )

        return currentTileBounds!!
    }

    /** Rate-limiter for the latitude-span clamp warning. */
    private var _latFallbackLog: Long = 0

    private fun tileBoundsChanged(current: TileBounds, last: TileBounds): Boolean {
        if (current.top != last.top) return true
        if (current.bottom != last.bottom) return true
        if (current.left != last.left) return true
        if (current.right != last.right) return true
        if (current.zoom != last.zoom) return true

        return false
    }

    /**
     * Recieves LatLonBounds and zoom level
     * @return List of tile coords. Ex: (TileCoord: 4/2/2, TileCoord: 4/3/2)
     */
    override fun getVisibleTileCoords(
        latLonBounds: LatLonBounds,
        tileBounds: TileBounds,
        zoom: Double,
        fromGetRenderables: Boolean,
    ): List<TileCoord> {
        val coords: MutableList<TileCoord> = mutableListOf()

        if (fromGetRenderables) {
            // Enumerate every horizontal tile index the geographic bounds cover, across any number of
            // world copies (Mapbox can show many repeats when zoomed out). Older logic only stitched
            // one adjacent copy (-1/0/1), which capped encoded layers to ~2 worlds.
            //
            // Use [MapProvider.getUnwrappedCameraLonBoundsForTiles] (raw Mapbox unwrapped longitudes), not
            // [latLonBounds] from [getBounds] alone: [VisibleGeoBounds.fromMapboxUnwrappedCamera] can
            // collapse to a single world strip, which would limit xMin..xMax to one copy.
            val finalZoom = tileBounds.zoom.coerceAtLeast(0)
            val numTiles = powerTableI[finalZoom]
            if (numTiles <= 0) return coords

            val (westRaw, eastRaw) = mapController?.getUnwrappedCameraLonBoundsForTiles()
                ?: (latLonBounds.westExtent.toDouble() to latLonBounds.eastExtent.toDouble())
            var eastUnwrapped = eastRaw
            if (eastUnwrapped < westRaw) {
                eastUnwrapped += 360.0
            }

            val xMin = floor((westRaw + 180.0) / 360.0 * numTiles).toInt()
            val xMax = ceil((eastUnwrapped + 180.0) / 360.0 * numTiles).toInt() - 1


            for (y in tileBounds.top..tileBounds.bottom) {
                if (xMax < xMin) continue
                for (xi in xMin..xMax) {
                    val nx = ((xi % numTiles) + numTiles) % numTiles
                    // Rule: dateline-world-copy. (xi - nx) is always an exact multiple of numTiles (by
                    // construction of the modulo above) — it's the raw tile-index delta, not a world-
                    // copy COUNT. Every consumer of TileCoord.offset (VectorGeometryRenderer.
                    // meshInfoForCoord's worldX formula, and VectorFillLayerRenderer/
                    // VectorLineLayerRenderer's per-vertex translate) multiplies offset by numTiles
                    // again to get the pixel/tile-unit shift — so storing the raw delta here double-
                    // scaled it by numTiles, silently correct only at zoom 0 (numTiles=1, where
                    // dividing by 1 is a no-op) and wrong by a factor of numTiles at every other zoom,
                    // translating the extra world copy to a wildly wrong position instead of the
                    // adjacent one. Store the copy COUNT instead.
                    val offset = (xi - nx) / numTiles
                    coords.add(TileCoord(nx, y, finalZoom, offset))
                }
            }
        } else {
            // This branch handles simple tile requests (like for downloading)
            // where we only need tile coordinates normalized to a single world map.
            //
            // Use the same unwrapped camera longitudes as the renderables branch for horizontal
            // extent. [latLonBounds] / [getVisibleTileBounds] use [MapController.getBounds], which
            // passes through [VisibleGeoBounds.fromMapboxUnwrappedCamera] and can collapse the
            // viewport to a narrow longitude strip. At high pitch with many world copies, that strip
            // depends on bearing: facing E vs W yields different collapsed west/east, so tile
            // columns from [tileBounds.left]..[tileBounds.right] would miss tiles that are already
            // drawn (unwrapped) and force extra downloads after rotating.
            //
            // Several raw tile indices still map to the same normalized z/x/y; dedupe below.
            val finalZoom = tileBounds.zoom.coerceIn(
                floor(source.minZoom).toInt(),
                floor(source.maxZoom).toInt()
            )
            val numTiles = powerTableI[finalZoom]
            if (numTiles > 0) {
                val seenNorm = LinkedHashSet<String>()
                val (xMin, xMax) = mapController?.getUnwrappedCameraLonBoundsForTiles()?.let { (westRaw, eastRaw) ->
                    var eastUnwrapped = eastRaw
                    if (eastUnwrapped < westRaw) {
                        eastUnwrapped += 360.0
                    }
                    val minX = floor((westRaw + 180.0) / 360.0 * numTiles).toInt()
                    val maxX = ceil((eastUnwrapped + 180.0) / 360.0 * numTiles).toInt() - 1
                    minX to maxX
                } ?: (tileBounds.left to tileBounds.right)

                for (y in tileBounds.top..tileBounds.bottom) {
                    if (xMax < xMin) continue
                    for (xi in xMin..xMax) {
                        val nx = ((xi % numTiles) + numTiles) % numTiles
                        val key = "$finalZoom/$nx/$y"
                        if (seenNorm.add(key)) {
                            coords.add(TileCoord(nx, y, finalZoom))
                        }
                    }
                }
            }
        }

        if (initialLoad) { // Always download zoomLevel 0 first
            initialLoad = false
            // Except for a layer that folds a series. The world tile is primed so the ancestor walk
            // in RenderPass.determinePartial has coarse global coverage to fall back on instead of a
            // blank map, which is right when it is a blurrier version of the same field. A fold makes
            // it a different quantity - the aggregate over one whole-world tile at its own
            // resolution, declared independently of the tiles on screen - so falling back to it draws
            // values that were never computed for the area being shown.
            val folds = (source as? XweatherEncodedTileSource)?.operationSpec != null
            if (!folds && tileBounds.zoom != 0) {
                val hasZ0Root = coords.any { it.z == 0 && it.x == 0 && it.y == 0 }
                if (!hasZ0Root) {
                    coords.add(TileCoord(0, 0, 0))
                }
            }
        }

        return coords
    }

    /**
     * [MapboxMap.getCameraState] must run on the map-owning thread; [getTileBounds] / render can run on
     * the GL thread. On main, read live zoom; otherwise use [CameraSync] (filled by custom-layer render / main).
     */
    private fun getDataZoom(): Double {
        val mc = mapController ?: return CameraSync.mapZoom
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return mc.getZoom()
        }
        return CameraSync.zoomForCustomLayerInstancing()
    }

    /** Map zoom (no [zoomOffset]), matching Mapbox custom-layer render zoom. */
    private fun mapZoomForVisibleTiles(): Double =
        CameraSync.zoomForCustomLayerInstancing().coerceAtLeast(0.0)

    /**
     * Effective data tile zoom: [mapZoomForVisibleTiles] plus [zoomOffset], scaled down by the
     * layer's [quality] via [dataQualityMult]. Used for render and download tile indices so both
     * paths agree.
     *
     * Mirrors the JS SDK's `TileLayer.getDataZoom()`: [DataQuality.exact] keeps the 1:1 map-zoom
     * relationship (returning the unscaled value unchanged), while lower qualities floor
     * `zoom * ratio` so one data tile is shared across several map zoom levels. A scaled zoom is
     * clamped up to [TileSource.minZoom] so we never ask for a z the source does not publish, and
     * never allowed above the unscaled zoom. Nothing is clamped down to `maxZoom` here: renderables
     * deliberately follow map zoom past the encoded source's max (see [getTileBounds]).
     */
    internal fun zoomForVisibleTiles(): Double {
        val offsetZoom = (mapZoomForVisibleTiles() + zoomOffset).coerceAtLeast(0.0)
        if (dataQualityMult >= 1f) return offsetZoom
        return floor(offsetZoom * dataQualityMult)
            .coerceAtLeast(source.minZoom.toDouble())
            .coerceAtMost(offsetZoom)
    }

    /** Used in TileTimeSeriesDataProvider. Needs testing */
    fun getVisibleTileCoords(): List<TileCoord> {
        return visibleTileCoords
    }

    /**
     * Tile coords for gridded sidecar sampling (e.g. GL wind barbs). Uses [visibleTileCoords] when
     * [requestVisibleTiles] has run; otherwise derives from current [bounds] / [getTileBounds] so
     * sampling still works when [onMove] skips downloads (timeline playing, etc.).
     */
    internal fun visibleTileCoordsForSidecarSampling(): List<TileCoord> {
        // Do not reuse [visibleTileCoords] from [requestVisibleTiles]: that path uses
        // [getVisibleTileCoords] with fromGetRenderables=false (download-style enumeration).
        // Gridded sidecar sampling must use fromGetRenderables=true (unwrapped camera, world copies)
        // and must track programmatic zoom changes even when [renderBoundsDirty] was not set yet.
        val b = bounds ?: mapController?.getBounds() ?: return emptyList()
        val tb = getTileBounds()
        val coords = getVisibleTileCoords(b, tb, zoomVar, true)
        var filtered = coords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        filtered = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        // At world / near-world zoom, tile enumeration can be empty before the first camera sync or while
        // unwrapped longitudes are still settling — instanced wind then gathers zero instances until a pan.
        if (filtered.isEmpty() && tb.zoom <= 0) {
            val root = TileCoord(0, 0, 0)
            val inRegion = source.bounds == null || isWithinRegionBounds(root, source.bounds!!)
            if (inRegion) return listOf(root)
        }
        return filtered
    }

    /**
     * Visible tile keys at **native map zoom** (no layer [zoomOffset]). Mapbox
     * [com.mapbox.maps.extension.style.sources.CustomGeometrySource] requests MVT at
     * `CanonicalTileID.z` tied to the camera zoom, while [zoomForVisibleTiles] applies [zoomOffset]
     * for encoded layers — one level off makes [com.xweather.mapsgl.sources.VectorTileSource]
     * cache lookups miss every tile for custom vector mesh fills.
     *
     * Custom GL layers render on Mapbox's GL thread — must not call [com.xweather.mapsgl.map.MapController.getBounds],
     * which reads [com.mapbox.maps.MapboxMap.cameraState] (wrong-thread bindgen errors and empty tile lists).
     */
    internal fun visibleTileCoordsForMapboxVectorCache(): List<TileCoord> {
        val raw =
            mapZoomForVisibleTiles().coerceAtLeast(0.0).coerceAtMost(source.maxZoom.toDouble())
        return visibleTileCoordsForMapboxVectorCacheAtDataZoom(raw)
    }

    /**
     * Visible MVT tile keys at [dataZoom] for custom GL vector cache lookup / prefetch.
     */
    internal fun visibleTileCoordsForMapboxVectorCacheAtDataZoom(dataZoom: Double): List<TileCoord> {
        val b: LatLonBounds = liveTileBounds() ?: return emptyList()
        val raw = dataZoom.coerceAtLeast(0.0).coerceAtMost(source.maxZoom.toDouble())
        val tb = getVisibleTileBounds(b, raw, true)
        val coords = getVisibleTileCoords(b, tb, raw, true)
        var filtered = coords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        filtered = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        if (filtered.isEmpty() && tb.zoom <= 0) {
            val root = TileCoord(0, 0, 0)
            val inRegion = source.bounds == null || isWithinRegionBounds(root, source.bounds!!)
            if (inRegion) return listOf(root)
        }
        return filtered
    }

    /**
     * Rule: fallback-must-stay-in-viewport. [VectorTileSource.cachedTileCoordsWithDataAtZ] returns
     * every tile cached anywhere in the source at [z] with no geographic filter — it is meant for
     * "is there SOMETHING at this zoom we could show" checks, not "what's near the camera". Renderer
     * fallback paths (draw a coarser cached tile for one frame while the real viewport tiles at the
     * new zoom are still loading) called it directly and, after navigating through several regions,
     * ended up drawing whatever unrelated tiles happened to still be cached from anywhere in the
     * world, all at once — each individually correct-for-its-own-coordinate, but nowhere near the
     * current camera. Reported as "place-city labels invisible / a garbled cluster of world cities"
     * at low zoom after visiting multiple regions. Intersecting against the tiles [z] would actually
     * enumerate for the current viewport keeps the fallback geographically relevant.
     */
    internal fun cachedTileCoordsWithDataAtZInViewport(vts: VectorTileSource, z: Int): List<TileCoord> {
        val cached = vts.cachedTileCoordsWithDataAtZ(z)
        if (cached.isEmpty()) return cached
        val viewportAtZ = visibleTileCoordsForMapboxVectorCacheAtDataZoom(z.toDouble())
        if (viewportAtZ.isEmpty()) return emptyList()
        val viewportXY = HashSet<Long>(viewportAtZ.size * 2).apply {
            viewportAtZ.forEach { add(it.x.toLong() shl 32 or it.y.toLong()) }
        }
        return cached.filter { (it.x.toLong() shl 32 or it.y.toLong()) in viewportXY }
    }

    /**
     * Native camera zoom for GL vector timeline playback. Previously fetched one zoom below camera
     * (≈¼ tile count vs native Z) to cut playback prefetch request volume, scaling the coarser parent
     * tile back up via [com.xweather.mapsgl.map.mapbox.CameraSync.tileRasterOverscale]. Removed:
     * for products with large per-tile payloads (e.g. fires-obs), that traded request count for tile
     * weight without a clear win, and kept playback tiles a zoom level removed from what the static
     * (non-playback) draw path fetches — worth re-examining if playback prefetch volume becomes a
     * problem again.
     */
    internal fun glVectorPlaybackDataZoom(mapZoom: Double = mapZoomForVisibleTiles()): Int =
        floor(mapZoom).toInt().coerceAtLeast(0).coerceAtMost(source.maxZoom.toInt())

    /** Viewport tile coords at [glVectorPlaybackDataZoom]; falls back to camera-Z coords when empty. */
    internal fun visibleTileCoordsForGlVectorPlayback(): List<TileCoord> {
        val playbackCoords =
            visibleTileCoordsForMapboxVectorCacheAtDataZoom(glVectorPlaybackDataZoom().toDouble())
        if (playbackCoords.isNotEmpty()) return playbackCoords
        return visibleTileCoordsForMapboxVectorCache()
    }

    /** Cached-tile zoom search order for GL vector draw fallbacks during timeline playback. */
    internal fun glVectorPlaybackFallbackZoomCandidates(mapZoom: Double): List<Int> {
        val cameraZ = floor(mapZoom).toInt().coerceAtLeast(0).coerceAtMost(source.maxZoom.toInt())
        return listOf(cameraZ, cameraZ - 1, cameraZ + 1).filter { it >= 0 }
    }

    /**
     * Recomputes [visibleTileCoords] from the current viewport without issuing tile HTTP requests.
     * Custom GL vector layers skip [requestVisibleTiles] during timeline playback; the time-series
     * animator still reads [visibleTileCoords] when prefetching interval MVT data.
     */
    internal fun refreshVisibleTileCoordsForVectorGl(): Boolean {
        val b = liveTileBounds() ?: return false
        if (bounds == null) {
            bounds = b
        }
        zoomVar = zoomForVisibleTiles()
        val tileBounds = getVisibleTileBounds(b, zoomVar)
        val coords = getVisibleTileCoords(b, tileBounds, 0.0, false)
        var filtered = coords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        filtered = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        val prevKeys = visibleTileCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
        val nextKeys = filtered.map { "${it.z}/${it.x}/${it.y}" }.toSet()
        visibleTileCoords = filtered
        cancelHttpOutsideVisible(filtered)
        renderBoundsDirty = true
        renderablesDirty = true
        if (prevKeys != nextKeys && this is VectorTileLayer && glRenderingActive()) {
            // During playback, viewport MVT prefetch is rate-limited via prefetchVectorTilesForGlRendering;
            // marking the provider dirty here would duplicate the same coord×interval wave.
            if (!Timeline.isGloballyPlaying) {
                animator?.provider?.setNeedsUpdate()
            }
        }
        return filtered.isNotEmpty()
    }

    /**
     * Single tile at map center when [visibleTileCoordsForMapboxVectorCache] is empty (e.g. first
     * custom-layer frame before [cachedMapboxBounds] is populated). Keeps MVT prefetch alive for GL symbols.
     */
    internal fun viewportCenterTileCoordsForPrefetch(): List<TileCoord> {
        val mc = mapController ?: return emptyList()
        val mapZoomNow = CameraSync.zoomForCustomLayerInstancing()
        val z = floor(mapZoomNow).toInt()
            .coerceAtLeast(0)
            .coerceAtMost(source.maxZoom.toInt())
        val n = 1 shl z
        var x = TileConversions.lonToTileNonNormalized(mc.centerLatLng.lon, z) % n
        if (x < 0) x += n
        val y = TileConversions.latToTile(mc.centerLatLng.lat, z).coerceIn(0, n - 1)
        return listOf(TileCoord(x, y, z))
    }

    /** Refreshes [layerRenderContext]'s renderables/paint style for this frame, then delegates to [tileLayerRenderer]. */
    //** generates context.renderables can calls tileLayerRenderer.prerender(context)  */
    override fun prerender(elapsedTime: Double) {
        if (mapController == null || !visible) {
            return
        }
        layerRenderContext.renderables = getRenderables()
        layerRenderContext.paintStyle = paint
        tileLayerRenderer.prerender(layerRenderContext)
        return
    }

    /** No-op on [TileLayer]; there is no GL/listener state here that needs releasing on removal. */
    override fun onRemove() {}

    /** Called from LayerHost.render(), calls TileLayerRenderer.draw()*/
    override fun render(texUnit: HashMap<String, Int>, camera: Camera) {
        if (visible)
            tileLayerRenderer.draw(layerRenderContext, texUnit, camera)
        triggerEvent(TileLayerEventType.FINISHED_DRAWING)
    }

    /** The kind of layer this is (raster, fill, line, symbol, contour, particles, etc.). */
    override lateinit var type: LayerType

    /** This layer's time-series animation configuration (mode, clamp, valid date range, interval count, etc.). */
    override lateinit var timing: LayerTiming

    /** Unimplemented on [TileLayer]. */
    override var invertMaskLayer: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}

    /** Handlers registered via [MapLayer.addSourceEventHandler] to react to this layer's data-source events. */
    override var sourceEventHandlers: MutableList<MapLayer.SourceEventHandler> = mutableListOf()

    /** Attaches this layer to [controller], wires up its GL renderer, and starts observing the timeline's play/pause state. */
    override fun onAdd(context: Context, controller: MapController) {
        this.mapController = controller
        super.onAdd(context, controller)
        this.drawContext = context
        // need to trigger onMove to render initial tiles
        tileLayerRenderer.onAdd(this)

        (mapController)?.timeline?.playIsPressed?.observeForever { newValue ->
            // Avoid blocking the observer callback thread.
            externalScope.launch { handlePlayIsPressedChange(newValue) }
        }
    }

    /** Not yet implemented on [TileLayer]; simple no-context registration is not used by this layer. */
    override fun onAdd() {
        TODO("Not yet implemented")
    }

    /** Not yet implemented on [TileLayer]; this render-context/owning-layer overload is used by renderer classes instead. */
    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {
        TODO("Not yet implemented")
    }

    //triggers on play and pause
    private fun handlePlayIsPressedChange(newValue: Boolean) {
        if (newValue && bounds != null) {
            if (pr.ON) pr.p(TAG, pr.playPause, "handlePlayIsPressedChange(): Starting animation...")
            //println("TileLayer calling requestVisibleTiles with play button, looking")
            if (pr.ON) pr.p(TAG, pr.playLock, "handlePlayIsPressedChange($newValue) about to call requestVisibleTiles ")
            //requestVisibleTiles(bounds!!, fromAnimation = true) //commented this out 250320... was causing freeze when play pressed...

        } else {
            // if(pr.ON) pr.p(TAG, pr.obs_play,"TileLayer handlePlayIsPressedChange: Stopping animation...")
        }
    }

    /**
     * Rule: world-tile-first-on-add. Fetches the z=0 world tile once the source timeline has
     * intervals, so a newly-added layer has coarse global coverage for
     * [com.xweather.mapsgl.gl.RenderPass.determinePartial]'s ancestor walk to fall back on the
     * moment the camera moves somewhere new — instead of a blank map until the exact-zoom tiles
     * for that area download.
     *
     * Polled rather than inline because the timeline is not populated on the first
     * [requestVisibleTiles] after a layer is added, and that method does not run again until a
     * camera move — so an inline attempt silently deferred until the user panned, which is exactly
     * the case the world tile exists to cover.
     *
     * Skipped while playing: playback wants the viewport×interval tiles first. The one-shot flag is
     * only consumed on a successful prime, so a layer added mid-playback still gets its world tile
     * once playback stops.
     */
    /**
     * Lets the low-quality preload run again for a new set of intervals.
     *
     * The prime is a one-shot per layer, so without this a time-range change would leave the new
     * intervals with no coarse fallback — MapsGL JS clears the same flag on a time-series change.
     */
    internal fun resetLowQualityPreload() {
        if (!preloadLowQuality) return
        worldTilePrimed = false
    }

    /**
     * A request wave failed, most often because the encoded source's metadata did not load. The
     * layer is left without data rather than throwing: log and report the first failure of a
     * streak through [MapController.reportLayerError], then retry on a backoff. The source keeps
     * `metaDataNeeded` set until a fetch succeeds, so the retry (or any camera move) fetches again.
     */
    private fun handleRequestFailure(err: Throwable?, reload: Boolean) {
        // The map re-requests on every rendered frame while data is missing; those calls fail fast
        // during the source's own cooldown. Leave a scheduled retry alone so the streak counts
        // real attempts, not frames.
        if (loadFailureRetryJob?.isActive == true) return
        val decision = synchronized(loadFailureRetry) { loadFailureRetry.onFailure() }
        val reason = err?.message ?: err?.javaClass?.simpleName ?: "unknown error"
        if (decision.report) {
            val message = "data load failed, will retry: $reason"
            MapsGLLog.warn(TAG, "MapsGL layer $id $message", err)
            try {
                mapController?.reportLayerError(
                    MapsGLLayerError(
                        // 1.8.0 keeps the Reason enum unchanged; 1.9.0 adds DATA_LOAD_FAILED.
                        reason = MapsGLLayerError.Reason.RENDER_FAILED,
                        layerCode = code,
                        layerId = id,
                        message = message,
                        cause = err,
                    ),
                )
            } catch (t: Throwable) {
                MapsGLLog.warn(TAG, "MapsGL layer $id error report failed", t)
            }
        } else {
            MapsGLDebug.logW(TAG, "requestVisibleTiles() failed again for $id: $reason", err)
        }

        val delayMs = decision.retryDelayMs ?: return
        loadFailureRetryJob = externalScope.launch {
            kotlinx.coroutines.delay(delayMs)
            // Clear before retrying, so a failure of this very attempt schedules the next one.
            loadFailureRetryJob = null
            val b = liveTileBounds() ?: return@launch
            try {
                requestVisibleTiles(b, reload)
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                MapsGLDebug.logW(TAG, "Retry of requestVisibleTiles() threw for $id", t)
            }
        }
    }

    private fun primeWorldTileWhenTimelineReady() {
        // Opt-in from 1.9.x: this used to run for every encoded layer, which is what MapsGL JS turned
        // into `preloadLowQuality` with a default of false. Off means no world tile, so a camera move
        // beyond the loaded bounds has nothing coarse to fall back on until its own tiles land.
        if (!LowQualityPreload.shouldPrime(
                featureEnabled = MapsGLFeatures.layerSpecOptions,
                optedIn = preloadLowQuality,
                alreadyPrimed = worldTilePrimed,
                encoded = source.isEncoded,
            )
        ) {
            return
        }
        if (worldTilePrimeJob?.isActive == true) return
        worldTilePrimeJob = externalScope.launch {
            repeat(WORLD_TILE_PRIME_ATTEMPTS) {
                if (worldTilePrimed) return@launch
                // Only consume the one-shot when the prime actually scheduled. Several of its
                // preconditions (mapController/timeline wired, tileRequestOptions carrying a
                // resolved date, the source timeline publishing intervals) are still settling right
                // after a layer is added, and marking primed before the call meant the first bail
                // burned it — leaving the world tile unfetched until the user panned.
                if (!Timeline.isGloballyPlaying && scheduleQuietWorldTileIfNeededOnIdleCameraMove()) {
                    worldTilePrimed = true
                    return@launch
                }
                kotlinx.coroutines.delay(WORLD_TILE_PRIME_RETRY_MS)
            }
        }
    }

    /**
     * z=0 prefetch for ancestor partials while paused; does not drive the load indicator.
     * @return true when the world tile is handled for the current intervals (see
     * [TilePyramid.scheduleQuietIdleWorldTileDownload]); false when something was not ready yet.
     */
    private suspend fun scheduleQuietWorldTileIfNeededOnIdleCameraMove(): Boolean {
        if ((!visible && !hasDependentLayers) || !source.isEncoded) return false
        val tl = mapController?.timeline ?: animator?.animation?.timeline ?: return false
        if (tl.state == AnimationState.playing) return false
        return pyramid.scheduleQuietIdleWorldTileDownload(tileRequestOptions, externalScope)
    }

    /**
     * Processes encoded tiles that [XweatherEncodedTileSource] deferred while the map was moving.
     *
     * When [Timeline.movedOnTileLoaded] is set, a loaded encoded tile is parked in
     * [XweatherEncodedTileSource.threadSafeTileMap] instead of being handed to `onTileLoaded`. This
     * drains that hand-off. It is **not** optional bookkeeping: it is the deferred half of tile
     * loading, so leaving it undone means the pixels never land and the download accounting never
     * completes.
     *
     * This used to live inline in [requestVisibleTiles], which [onMove] deliberately skips during
     * playback unless the zoom tier changed. Panning at a constant zoom while the timeline played
     * therefore filled the map and never emptied it -- and every entry pins the tile's packed
     * `ByteArray`, documented at 1-8MB each. Measured at the point of failure: 365 arrays holding
     * 300MB, 68% of a 512MB heap, ending in OutOfMemoryError -> "JNI NewString called with pending
     * exception" -> SIGABRT. The same skipped drain also explains a loading indicator that never
     * reaches 100% and a layer that never animates, since both wait on work parked in this map.
     */
    internal suspend fun drainDeferredEncodedTiles() {
        if (!Timeline.movedOnTileLoaded) return
        val encoded = pyramid.tileSource as? XweatherEncodedTileSource ?: return
        if (encoded.threadSafeTileMap.isEmpty()) return
        withContext(Dispatchers.IO) {
            for (item in encoded.threadSafeTileMap) {
                encoded.onTileLoaded(item.value, encoded.threadSafeIntervalMap[item.key], 1)
            }
            encoded.threadSafeTileMap.clear()
            encoded.threadSafeIntervalMap.clear()
            mapController?.checkDownloadStatus(id, pyramid.tileCache.pendingCount)
        }
    }

    /**
     * Stops HTTP for tiles that have left [coords], keeping the visible set and the coarser
     * ancestors still used as a fallback while the new tiles download.
     */
    private fun cancelHttpOutsideVisible(coords: Iterable<TileCoord>) {
        val kept = withSiblingSourceCoords(coords)
        val keep = HashSet<String>()
        for (coord in kept) keep.add(coord.hashShort())
        if (keep.isEmpty()) return
        keep.addAll(ancestorHashShorts(kept))
        source.cancelInFlightHttpOutside(keep)
    }

    /**
     * [own] plus the visible tiles of every other drawn layer on the same [source].
     *
     * Layers that share a source share its tile cache, its in-flight downloads and its hand-off
     * maps, but each wants its own tiles: wind particles read zoom 3 where temperatures read zoom 2
     * from `conditions_TMP2_UGRD10_VGRD10`. Trimming or cancelling to one layer's tiles dropped the
     * other's, which then asked for them again on the next frame. With particles keeping the map
     * redrawing, that was hundreds of requests a second and a load indicator stuck short of 100%.
     */
    private fun withSiblingSourceCoords(own: Iterable<TileCoord>): List<TileCoord> {
        val ownList = own.toList()
        val siblings = runCatching { mapController?.layers?.values?.toList() }.getOrNull() ?: return ownList
        var merged: ArrayList<TileCoord>? = null
        for (layer in siblings) {
            val other = layer as? TileLayer ?: continue
            if (other === this || other.source !== source) continue
            if (!other.visible && !other.hasDependentLayers) continue
            val coords = other.visibleTileCoords
            if (coords.isEmpty()) continue
            (merged ?: ArrayList(ownList).also { merged = it }).addAll(coords)
        }
        return merged ?: ownList
    }

    private fun ancestorHashShorts(coords: Iterable<TileCoord>): HashSet<String> {
        val ancestors = HashSet<String>()
        for (coord in coords) {
            var az = coord.z
            var ax = coord.x
            var ay = coord.y
            while (az > 0) {
                az -= 1
                ax = Math.floorDiv(ax, 2)
                ay = Math.floorDiv(ay, 2)
                ancestors.add("0:$az/$ax/$ay")
            }
        }
        return ancestors
    }

    private fun notifyOperationViewport(visible: Set<String>, ancestors: Set<String>) {
        (pyramid.tileSource as? XweatherEncodedTileSource)
            ?.takeIf { it.operationSpec != null }
            ?.setWantedAggregateTiles(visible, ancestors)
    }

    /**
     * Trims the tile cache to the actual working set: every interval for the tiles that are visible
     * right now, and nothing for tiles that are not.
     *
     * The residency rule is "keep what the current timeline needs **for the current viewport**".
     * [TileCache.canEvict] implemented it as "evict nothing while playing", which is the same thing
     * only while the camera is still. Pan during playback and the resident set becomes (every
     * viewport visited) x (all intervals) instead of (current viewport) x (all intervals). Measured
     * at the point of failure: 365 encoded `byte[]` holding 300MB of a 459MB heap -- the packed
     * payloads are 1-8MB each -- ending in OutOfMemoryError and then a SIGABRT, because the pending
     * exception aborts Mapbox's next `JNI NewString`.
     *
     * The bound is the visible tile set itself, not a constant: a larger screen legitimately shows
     * more tiles, and the cap should follow the screen rather than a guess about it.
     *
     * Keyed on the **spatial** hash only, so every interval of a visible tile stays resident. The
     * interval axis is already bounded, and deciding per-interval would mean second-guessing the
     * download accounting -- which is exactly what broke the earlier attempt at this (c6258d42): it
     * dropped tiles the fine pass still counted as required, so progress could never reach 100% and
     * readiness gating correctly refused to animate the layer.
     *
     * [TileCache.evictTilesOutsideViewport] performs the removal. It skips in-flight tiles, forces
     * the native/GPU free that playback normally suppresses, and its `onRemove` clears the
     * pending-download and ready bookkeeping, so the progress accounting stays consistent with what
     * was dropped rather than waiting forever on it.
     */
    private fun evictOutsideVisibleWorkingSet() {
        if (visibleTileCoords.isEmpty()) return

        val sharedCoords = withSiblingSourceCoords(visibleTileCoords)
        val viewportKeySet = HashSet<String>()
        for (coord in sharedCoords) {
            viewportKeySet.add(coord.hashShort())
        }
        val protectedAncestorKeySet = ancestorHashShorts(sharedCoords)
        pyramid.tileCache.evictTilesOutsideViewport(viewportKeySet, protectedAncestorKeySet)

        // The deferred hand-off holds the same packed ByteArray, so evicting the cache entry alone
        // does not free it. Drop the *reference* only: these tiles must NOT be processed here.
        // Calling onTileLoaded off this path mutates the shared representative tile while the render
        // thread reads it, which aborted the process (JNI NewString with a pending
        // NoSuchElementException -> SIGABRT). Releasing memory needs no processing; the cache's own
        // onRemove has already cleared the matching download bookkeeping.
        (pyramid.tileSource as? XweatherEncodedTileSource)?.let { encoded ->
            encoded.threadSafeTileMap.entries.removeAll { e ->
                e.value.coord.hashShort() !in viewportKeySet
            }
            encoded.threadSafeIntervalMap.keys.retainAll(encoded.threadSafeTileMap.keys)
        }
    }

    override suspend fun onMove() {
        oldBounds = bounds
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        // Keep renderables updated during movement.
        // Without this, the cached `tileBounds`/`renderables` can lag behind the camera,
        // producing temporary blank tiles until `onMoveEnd()` runs.
        renderBoundsDirty = true
        renderablesDirty = true

        if (this is VectorTileLayer) {
            if (glRenderingActive()) {
                val displayTileZ = floor(zoomForVisibleTiles()).toInt().coerceAtLeast(0)
                val zoomTierChanged =
                    lastOnMoveDisplayTileZ == null || displayTileZ != lastOnMoveDisplayTileZ
                if (zoomTierChanged) {
                    lastOnMoveDisplayTileZ = displayTileZ
                }
                refreshVisibleTileCoordsForVectorGl()
                externalScope.launch {
                    val playing = Timeline.isGloballyPlaying
                    val gateLoadUi = Timeline.isGlVectorFillPrefetchLoadUiActive()
                    prefetchVectorTilesForGlRendering(
                        minIntervalMs = if (zoomTierChanged && playing) {
                            250L
                        } else {
                            400L
                        },
                        requestBudget = when {
                            gateLoadUi -> 0
                            playing -> 40
                            else -> Int.MAX_VALUE
                        },
                    )
                }
                if (Timeline.isGloballyPlaying) {
                    // Sliding-window interval prefetch is driven by timeline ADVANCE/INTERVAL_CHANGE.
                } else {
                    animator?.loadDataIfNeeded(debounced = true)
                }
            }
        } else { // Non-vector

            val timeline = animator?.animation?.timeline
            val playingBlocksMoveRequests = timeline != null &&
                timeline.state == AnimationState.playing &&
                !Timeline.pausedForDownload

            val displayTileZ = floor(zoomForVisibleTiles()).toInt().coerceAtLeast(0)
            val zoomTierChanged =
                lastOnMoveDisplayTileZ == null || displayTileZ != lastOnMoveDisplayTileZ
            if (zoomTierChanged) {
                lastOnMoveDisplayTileZ = displayTileZ
            }

            if (!playingBlocksMoveRequests || zoomTierChanged) {
                if (Timeline.holdFullTimelineResidency &&
                    source.isEncoded &&
                    !Timeline.isGloballyPlaying
                ) {
                    requeueVisibleBindsForScrub()
                } else {
                    if (pr.ON) pr.p(
                        TAG,
                        pr.infiniteLoad,
                        "onMove() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
                    )
                    bounds?.let { requestVisibleTiles(it) }
                }
            } else {
                // Playback with no zoom-tier change. Skipping requestVisibleTiles is deliberate --
                // it limits download churn -- but the cache trim lives inside it, so this is the
                // exact state in which residency grew without bound. Recompute what is visible and
                // trim to it; this issues no downloads.
                refreshVisibleTileCoordsForVectorGl()   // name is legacy; body is layer-agnostic
                evictOutsideVisibleWorkingSet()
            }
            // NOTE: do NOT drain the deferred encoded-tile hand-off here. Calling it from this path
            // (i.e. while the map is still moving during playback) crashed the process:
            //   JNI DETECTED ERROR: JNI NewString called with pending exception
            //   java.util.NoSuchElementException, in call to NewString, from com.mapbox.maps.Map.render()
            //   -> SIGABRT on MapboxRenderThread
            // Tiles are parked precisely BECAUSE the map is moving, and onMoveEnd's own comment
            // records the same hazard for a parallel requestVisibleTiles: it "raced the play wave
            // (shared representative tile + JobCancellationException cascades)". onTileLoaded mutates
            // the shared representative tile that the render thread is reading.
            //
            // The accumulation this was meant to fix is real and unfixed -- see
            // [drainDeferredEncodedTiles] for the measurement -- but the fix has to serialize with
            // the play wave rather than run beside it.
        }
    }

    /**
     * Like [onMove], but always calls [requestVisibleTiles] for the new bounds, without the
     * playback/zoom-tier gating [onMove] applies to limit download churn during timeline playback.
     */
    suspend fun onMoveUnrestricted() {
        oldBounds = bounds
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        if (this is VectorTileLayer) {
            if (glRenderingActive()) {
                externalScope.launch { prefetchVectorTilesForGlRendering() }
            }
        } else { // Non-vector

            //if(pr.ON) pr.p(TAG, pr.infiniteLoad, " onMove() calling requestVisibleTiles()")
            if (pr.ON) pr.p(
                TAG,
                pr.infiniteLoad,
                "onMoveUnrestricted() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
            )
            bounds?.let { requestVisibleTiles(it) }
        }
    }

    /** Calls requestVisibleTiles(), gets bounds if needed. */
    override suspend fun update() {
        //if (pr.ON) pr.p(TAG, pr.lagR, "update()")
        if (this is VectorTileLayer && glRenderingActive()) {
            if (bounds == null) {
                bounds = mapController?.getBounds()
            }
            refreshVisibleTileCoordsForVectorGl()
            if (!Timeline.isGloballyPlaying) {
                prefetchVectorTilesForGlRendering()
                animator?.loadDataIfNeeded(debounced = true)
            }
            return
        }
        if (bounds == null) {
            bounds = mapController?.getBounds()
        }
        bounds?.let { requestVisibleTiles(it) }
    }

    /**
     * Re-queues already-downloaded visible tiles for GPU bind after a scrub / playhead step,
     * without issuing another HTTP pass. Marks renderables dirty so the layer keeps animating
     * from resident intervals after the initial load session completes.
     */
    internal suspend fun requeueVisibleBindsForScrub() {
        if ((!visible && !hasDependentLayers) || !source.isEncoded) return
        val b = liveTileBounds() ?: return
        renderBoundsDirty = true
        renderablesDirty = true
        zoomVar = zoomForVisibleTiles()
        val tileBounds = getVisibleTileBounds(b, zoomVar)
        val visibleCoords = getVisibleTileCoords(b, tileBounds, 0.0, false)
        val filtered = visibleCoords.filter { vtc ->
            vtc.x >= 0 && vtc.x < powerTableI[vtc.z] && vtc.y >= 0 && vtc.y < powerTableI[vtc.z]
        }
        val finalCoords = if (source.bounds != null) {
            filtered.filter { coord -> isWithinRegionBounds(coord, source.bounds!!) }
        } else {
            filtered
        }
        visibleTileCoords = finalCoords.toMutableList()
        pyramid.requeueLoadedVisibleTilesForBind(finalCoords, pyramid.scrubPhaseTimesArray()).also { queued ->
            if (queued) {
                val mc = mapController
                if (mc is MapboxMapController) {
                    mc.layerHosts[id]?.setTexturesToBind(true)
                    mc.mapboxMap?.executeOnRenderThread {
                        mc.layerHosts[id]?.bindTextures(source.id)
                    }
                    mc.redraw()
                }
            }
        }
    }

    /** No-op on [TileLayer]; this layer does not need to react to the start of a camera move. */
    override fun onMoveStart() {
        //println("$TAG onMoveStart()")
    }

    /**
     * Called once a camera movement settles. Re-syncs [bounds], and either re-binds already-resident
     * tiles (when a full-range playback load is held resident and the timeline isn't playing) or
     * requests visible tiles for the settled viewport, skipping the request while playback is
     * already handling a coalesced refresh.
     */
    override suspend fun onMoveEnd() {
        //println("TileLayer OnMoveEnd")
        bounds = mapController?.getBounds() ?: return //These bounds are normalized

        // Keep renderables in sync even if we skip triggering downloads.
        renderBoundsDirty = true
        renderablesDirty = true

        // Full-range play load already resident — re-bind only while idle (map idle / scrub).
        // While playing, continue HTTP for holes.
        if (Timeline.holdFullTimelineResidency &&
            source.isEncoded &&
            !Timeline.isGloballyPlaying
        ) {
            requeueVisibleBindsForScrub()
            return
        }

        val vectorGlPlaying = this is VectorTileLayer && glRenderingActive()

        // While playing, MapController.onMoveEnd already schedules a coalesced playback refresh
        // after updating bounds above. A parallel requestVisibleTiles here raced the play wave
        // (shared representative tile + JobCancellationException cascades).
        if (Timeline.isGloballyPlaying && !vectorGlPlaying) {
            return
        }

        // Do not skip because [Timeline.isDownloading] is true. Playback keeps that flag set
        // almost continuously, so skipping here left pan/zoom on a stale viewport forever
        // ("never loads the new animations" while scrolling during play). MapIdle is already
        // gated on a real camera move, so this path is not the old idle spam.

        val tl = mapController?.timeline ?: animator?.animation?.timeline
        if (tl == null || tl.state != AnimationState.playing) {
            scheduleQuietWorldTileIfNeededOnIdleCameraMove()
        }

        //if(pr.ON) pr.p(TAG, pr.infiniteLoad, " onMoveEnd() calling requestVisibleTiles() with bounds: ${bounds}")
        if (pr.ON) pr.p(
            TAG,
            pr.infiniteLoad,
            "onMoveEnd() calling requestVisibleTiles() on bounds  ${bounds?.westExtent} - ${bounds?.eastExtent}"
        )
        if (vectorGlPlaying) {
            refreshVisibleTileCoordsForVectorGl()
            prefetchVectorTilesForGlRendering(
                requestBudget = if (Timeline.isGloballyPlaying) 40 else Int.MAX_VALUE,
            )
        } else {
            bounds?.let { requestVisibleTiles(it) }
        }
    }

    /** Not yet implemented on [TileLayer]. */
    override fun onResize() {
        TODO("Not yet implemented")
    }

    /** Not yet implemented on [TileLayer]. */
    override fun onClick() {
        TODO("Not yet implemented")
    }

    /** Notifies [tileLayerRenderer] that the layer became visible and marks it dirty so it redraws. */
    override fun onVisible() {
        tileLayerRenderer.onVisible()
        setNeedsUpdate()
    }

    /** Notifies [tileLayerRenderer] that the layer was hidden and marks it dirty so it updates accordingly. */
    override fun onHidden() {
        tileLayerRenderer.onHidden()
        setNeedsUpdate()
    }

    private fun setupTimeSeriesAnimator() {
        if (pr.ON) pr.p("MapLayer", pr.layerToAnimation, "setupTimeSeriesAnimator(), entered")
        //val (clamp, range, interleaved) = this.timing

        timing = LayerTiming()
        with(timing) {
            mode = TimeSeriesMode.NONE
            clamp = TimeClampMode.NONE
            range = null
            intervals = null
            interleaved = true
            operation = null
        }

        val clamp = timing.clamp
        val range = timing.range
        val interleaved = timing.interleaved


        val provider = createTimeSeriesDataProvider()

        if (pr.ON) pr.p(
            "TileLayer",
            pr.layerToAnimation,
            "setupTimeSeriesAnimator(), provider is null? ${provider == null}"
        )

        if (provider != null) {
            //if (interleaved != null) {
            provider.interleaveRequests = interleaved
            //} else provider.interleaveRequests = true
        }

        val animator = TimeSeriesAnimator(
            timeSeries as TimeSeries<Data>,
            provider,
            TimeSeriesAnimatorOptions(clamp!!),
            // mapOf("id" to this.id, "mode" to clamp!!)
        )

        this.animator = animator

        animator.animation.timeline = mapController?.timeline

        if (pr.ON) pr.p(
            "TileLayer",
            pr.layerToAnimation,
            "setupTimeSeriesAnimator() (this.animator == null) ? ${this.animator == null}"
        )

        if (range != null) {
            animator._timeRange = range
        }

        //if (true){ //TODO: Make sure this section works
        addSourceEventHandler(
            DataSourceEvents.TileLoad().toString(),
            { animator.updateEntryState() }
        )
        //}

        // TODO: note from javascript version: move this into TimeSeriesAnimator
        listOf(
            TimeSeriesEvent.DATA_ADVANCE,
            TimeSeriesEvent.LOAD_COMPLETE
        ).forEach { event ->

            animator.on(
                event,
                callback = object : EventDispatcher.MyEventListener<Any> {
                    override fun onEvent(v1: Any) {
                        if (true) {
                            //DriverManager.println("")
                        }
                        MapsGLDebug.trace("TileLayer _setupTimeSeriesAnimator() Event received with data: $v1")

                    }

                    override val eventDispatcher: EventDispatcher
                        get() = TODO("Not yet implemented")

                },
                null,
                this
            ).apply {
                //animator.on(event,   object : EventListener<TimeSeriesEvent> {},  context = this).apply {
                /*
                if (this.visible) {
                    this.setNeedsUpdate()
                }*/
            }

        }
        /*
        animator.on(TimeSeriesEvent.ADVANCE,object : EventListener {}, null,  this).apply{
            if (this.visible) {
                this.setNeedsUpdate()
                this.enabled = this.animator.canShowForDate(e as Date) ?: false
            }


        } //{ e ->
        */
        //}

        if (this.timing.mode == TimeSeriesMode.INTERVAL) {
            /*
            animator.on(TimeSeriesEvent.ADVANCE) {
                if (animator.provider == null) {
                    this.refresh(true)
                } else if (animator.isActive) {
                    animator.loadDataIfNeeded()
                }
            }
            animator.on(TimeSeriesEvent.INTERVAL_ADVANCE) { e ->
                if(animator.isActive == false) {
                    animator.loadDataForIntervals(listOf((e as? Any) ?: error("Type mismatch, event is not of type Any")))
                }
            }
        }  else if (this.timing.mode == TimeSeriesMode.ANY) {
            animator.on(TimeSeriesEvent.ADVANCE) {
                this.refresh(true)
            } */
        }

    }


}
/*
val DATA_ZOOM_RATIO = mapOf(
    DataQuality.exact to 1f,
    DataQuality.high to 0.95f,
    DataQuality.medium to 0.8f,
    DataQuality.normal to 0.65f,
    DataQuality.low to 0.4f,
    DataQuality.minimal to 0.25f
)
val DATA_TO_ZOOM = mapOf(
    DataQuality.exact to listOf(0),
    DataQuality.high to listOf(0, 1, 2, 3, 4, 4, 5, 5, 6, 7, 7, 8, 8, 9, 9, 10, 10, 10, 10, 10, 10),
    DataQuality.medium to listOf(0, 1, 1, 2, 3, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5),
    DataQuality.normal to listOf(0, 1, 1, 2, 3, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 9, 9),
    DataQuality.low to listOf(0, 0, 1, 1, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6),
    DataQuality.minimal to listOf(0, 0, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3)
)
val QUALITY_PIXEL_RATIO = mapOf(
    DataQuality.exact to 1,
    DataQuality.high to 2,
    DataQuality.medium to 4,
    DataQuality.normal to 6,
    DataQuality.low to 8,
    DataQuality.minimal to 15
)
*/