package com.xweather.mapsgl.layers.tile

/**
 * Whether a layer's coarse world-tile preload should run.
 *
 * Extracted from [TileLayer] so the rule can be exercised without a map: the preload used to be
 * unconditional for every encoded layer, and 1.9.x makes it the opt-in `preloadLowQuality` that
 * MapsGL JS specifies. Getting the gate wrong is invisible until a user pans into an area whose
 * tiles have not arrived and sees blank map instead of blurry data.
 */
internal object LowQualityPreload {

    /**
     * @param featureEnabled Whether the 1.9.x layer-specification options are switched on. With them
     *   off the pre-1.9 behaviour stands: every encoded layer primes.
     * @param optedIn The layer's `preloadLowQuality`.
     * @param alreadyPrimed Whether this layer has already primed for the current time range.
     * @param encoded Whether the layer's source is encoded; only those have a world tile to prime.
     */
    fun shouldPrime(
        featureEnabled: Boolean,
        optedIn: Boolean,
        alreadyPrimed: Boolean,
        encoded: Boolean,
    ): Boolean {
        if (alreadyPrimed || !encoded) return false
        return !featureEnabled || optedIn
    }
}
