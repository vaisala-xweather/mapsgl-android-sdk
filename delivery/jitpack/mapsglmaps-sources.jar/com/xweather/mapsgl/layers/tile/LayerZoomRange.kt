package com.xweather.mapsgl.layers.tile

/**
 * The layer-level zoom range rule, kept separate from [TileLayer] so it can be exercised directly.
 *
 * A `TileLayer` needs a controller, a source and a render context to exist, none of which a unit test
 * can reasonably stand up — and the interesting part here is two comparisons and one conjunction.
 */
public object LayerZoomRange {

    /**
     * Whether [zoom] falls inside `[minZoom, maxZoom]`.
     *
     * Bounds are inclusive and either end may be null, meaning unbounded.
     */
    public fun contains(zoom: Double, minZoom: Float?, maxZoom: Float?): Boolean {
        minZoom?.let { if (zoom < it) return false }
        maxZoom?.let { if (zoom > it) return false }
        return true
    }

    /**
     * Whether a layer should draw at [zoom].
     *
     * A zoom range makes a layer visible *within* it but never overrides a deliberate [visible] of
     * false — hiding a layer keeps it hidden at every zoom. That is the MapsGL JS rule: a layer only
     * becomes visible inside its range if it has not been explicitly hidden.
     */
    public fun isVisible(zoom: Double, visible: Boolean, minZoom: Float?, maxZoom: Float?): Boolean =
        visible && contains(zoom, minZoom, maxZoom)
}
