package com.xweather.mapsgl.layers.tile

import com.xweather.mapsgl.MapsGLFeatures

import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.series.AnyTimeSeries
import com.xweather.mapsgl.data.series.MAX_REQUEST_INTERVALS
import com.xweather.mapsgl.data.series.TiledTimeSeriesDataProvider
import com.xweather.mapsgl.data.series.TimeSeriesDataProvider
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.renderers.EncodedDataRenderer
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.LayerRenderer
import com.xweather.mapsgl.renderers.TileLayerRenderer
import com.xweather.mapsgl.sources.DataPool
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.sources.EncodedTileSource
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.effectiveSampleMeldProgress
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType
import com.xweather.mapsgl.types.SampleExpression
import kotlinx.coroutines.CoroutineScope
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * EncodedTileLayer.kt
 *
 * Adapted from IOS version
 *
 * @author Jason Suto 4/8/24
 *
 */
internal class EncodedTileLayer(
    id: String,
    source: TileSource<TileData>,
    paint: LayerPaint,
    tileLayerRenderer: TileLayerRenderer<TileData, LayerRenderContext<Any>>,
    zoomOffset: Int,
    externalScope: CoroutineScope,
    quality: DataQuality = DataQuality.exact
) : TileLayer(
    id,
    source,
    paint,
    tileLayerRenderer,
    zoomOffset,
    externalScope, quality
) {
    init {
        this.paint = paint
    }

    val dataSize = DataPool.originalSize
    val paddingSize = DataPool.padding

    private val TAG = "EncodedTileLayer"

    override var type: LayerType
        get() = TODO("Not yet implemented")
        set(value) {}
    override lateinit var timing: LayerTiming

    override var timeSeries: AnyTimeSeries? = null

    override var invertMaskLayer: Boolean
        get() = TODO("Not yet implemented")
        set(value) {}
    override var renderer: LayerRenderer<Any>
        get() = TODO("Not yet implemented")
        set(value) {}

    // Rule: local-channel-cache-thread-safety. Read from the GL render thread (per-frame pixel
    // sampling for drawing) and from DataQueryCoordinator's Dispatchers.Default sampling coroutines
    // (up to CONCURRENT_SAMPLES in parallel) — both paths can miss on the same key at the same time
    // and race to decode + insert it. A plain LinkedHashMap here isn't just missing synchronization
    // on the write; a memory-visibility gap means one thread's put() may not be visible to a
    // concurrent get() on another thread even without an interleaved write, which read as a
    // different, unpredictable subset of sampled cities missing their sampled value on
    // every pass (confirmed live: two consecutive static-viewport screenshots each had a different
    // set of value-less cities). ConcurrentHashMap fixes both the write race and the visibility gap.
    private val localChannelCache: MutableMap<String, ByteArray> = java.util.concurrent.ConcurrentHashMap()

    //private var featureCache: HashMap<String, GriddedDataFeature> = hashMapOf()
    var hasLandMask: Boolean = false

    /** Returns the time series data provider to use for animating the layer, if any.
     * @internal
     */
    override fun createTimeSeriesDataProvider(): TimeSeriesDataProvider<TileLayer> {
        val provider = TiledTimeSeriesDataProvider(this)
        if (source is EncodedTileSource) {
            // Allow batching multiple time intervals per HTTP request (like vector tiles),
            // but keep the request size bounded by what the server/client can reasonably handle.
            provider.maxIntervalsPerRequest = Math.min(
                MAX_REQUEST_INTERVALS.toInt(),
                floor(2048.0 / source.tileSize.width).toInt()
            ).coerceAtLeast(1)
        }

        return provider
    }

    override var sourceEventHandlers: MutableList<MapLayer.SourceEventHandler> = mutableListOf()
    override var waitingOnDL: Boolean = false
    override var wasWaitingOnDL: Boolean = false


    override fun onRemove() {
        tileLayerRenderer.onRemove()
        if (tileLayerRenderer.renderpassInitialized && tileLayerRenderer.renderPass.meshes != null && tileLayerRenderer.renderPass.meshes!!.isNotEmpty()) {
            tileLayerRenderer.renderPass.meshes?.first()?.fbTex?.cleanup()
        }
        //Todo: remove this cast
        (source as EncodedTileSource).cleanup()
    }

    /**
     * Whether this layer's zoom range allows it to answer a query right now.
     *
     * Deliberately uses the **map** zoom, not the tile zoom the query is addressed with: the tile zoom
     * is `floor(mapZoom + zoomOffset)`, and a layer with a non-zero offset would otherwise be judged
     * against a number that is not the one its bounds were written in.
     */
    private fun withinLayerZoomRangeForQuery(): Boolean {
        if (!MapsGLFeatures.layerSpecOptions) return true
        if (minZoom == null && maxZoom == null) return true
        val mapZoom = CameraSync.customLayerRenderZoom ?: CameraSync.camera.zoom
        return isWithinZoomRange(mapZoom)
    }

    /**
     * The timeline phases a query should read.
     *
     * While the playhead is moving or scrubbing, these are the two ends of the current interval.
     * [DataQueryCoordinator] lerps them with [Timeline.dataMeld]. Collapsing both ends onto the
     * single instant under the playhead made `valueA == valueB`, so a later meld inside the same
     * interval indices (00Z → 04Z on a 4-hour grid, where phase A stays 0 and meld goes to 1)
     * republished the old instant and never sampled the far end.
     *
     * Idle, before any scrub, the fill draws one nearest valid time. Match that, or a hidden
     * sample labels a different hour than the raster under it.
     */
    private fun queryPhaseStrings(layerTimeline: LayerTimeline): Pair<String, String> {
        val target = layerTimeline.computeGlobalAnimationTarget()
        val (globalLongs, globalStrings) = Timeline.globalTimeListsSnapshot()
        return queryIntervalEndpointStrings(
            singleInterval = Timeline.prefersSingleIntervalIdleTarget(),
            collapsedA = target.phaseA,
            collapsedB = target.phaseB,
            phaseAIndex = Timeline.currentPhaseA,
            phaseBIndex = Timeline.currentPhaseB,
            globalLongs = globalLongs,
            globalStrings = globalStrings,
            layerLongs = layerTimeline.timeLongs.toList(),
            layerStrings = layerTimeline.timeStrings.toList(),
        )
    }

    override fun queryFeatures(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double?,
        queryLat: Double?,
    ): Any? = queryFeaturesAt(zoomVar, latTile, lonTile, latPix, lonPix, queryLon, queryLat, null, null)

    /**
     * [queryFeatures] with the option to pin the timeline phases.
     *
     * The data inspector reads what is drawn, so it passes no phases and the layer's own are used.
     * `*-text` labels sample a layer that is added hidden and never draws, whose phases therefore
     * stay on the bootstrap interval - they pass [queryPhaseStrings] instead.
     */
    private fun queryFeaturesAt(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        queryLon: Double?,
        queryLat: Double?,
        phaseA: String?,
        phaseB: String?,
    ): Any? {
        // Outside its zoom range the layer is not drawn, so it reports nothing — the data inspector
        // must not read a value off a product that is not on screen.
        if (!withinLayerZoomRangeForQuery()) return null

        val layerTimeline = Timeline.sourceTimeHash[source.id] ?: return null

        //val message: MutableList<String> = mutableListOf("", "")
        val channelInts: List<Int> = when (paint) {
            is SampleLayerPaint -> (paint as SampleLayerPaint).sample.channel.map { it.rawValue }
            is ParticleLayerPaint -> (paint as ParticleLayerPaint).sample.channel.map { it.rawValue }
            is ContourLayerPaint -> (paint as ContourLayerPaint).sample.channel.map { it.rawValue }
            is GridLayerPaint -> {
                val s = (paint as GridLayerPaint).sample ?: return null
                s.channel.map { it.rawValue }
            }

            else -> return null
        }

        val pixelValsAUByte: MutableList<UByte?> = mutableListOf(null, null, null)
        val pixelValsBUByte: MutableList<UByte?> = mutableListOf(null, null, null)
        val channelsToQuery = if (isRadar) listOf(3) else channelInts
        val aString = phaseA
            ?: if (layerTimeline.phaseAString.length < 2) Timeline.timeStrings[Timeline.currentPhaseA] else layerTimeline.phaseAString
        val bString = phaseB
            ?: if (layerTimeline.phaseBString.length < 2) Timeline.timeStrings[Timeline.currentPhaseB] else layerTimeline.phaseBString

        pixelValsAUByte.indices.forEach { i ->
            pixelValsAUByte[i] = getPixelValue(
                channelsToQuery.getOrNull(i),
                aString,
                zoomVar,
                latTile,
                lonTile,
                latPix,
                lonPix
            )

            pixelValsBUByte[i] = getPixelValue(
                channelsToQuery.getOrNull(i),
                bString,
                zoomVar,
                latTile,
                lonTile,
                latPix,
                lonPix
            )
        }

        val finalVals = pixelValsAUByte.zip(pixelValsBUByte, ::interpolate)
        if (finalVals[0] == null) {
            return null
        }
        val expression: SampleExpression = when (paint) {
            is SampleLayerPaint -> (paint as SampleLayerPaint).sample.expression
            is ParticleLayerPaint -> (paint as ParticleLayerPaint).sample.expression
            is ContourLayerPaint -> (paint as ContourLayerPaint).sample.expression
            is GridLayerPaint -> {
                val s = (paint as GridLayerPaint).sample ?: return null
                s.expression
            }

            else -> return null
        }

        // [SourceMetadata.datasets] is `emptyList()` until source metadata resolves, and a paint may
        // sample a band the source never publishes (e.g. `air_quality.india.fill` samples
        // ColorBand.blue = 2). Either case made this raw subscript throw IndexOutOfBoundsException
        // out of a tap handler. Degrade to "no reading" instead. Mirrors the Apple SDK's
        // `bandIndex < datasets.count` guard (xweather-mapsgl-apple 9b9c56e).
        val dataset0 = source.datasets.getOrNull(channelInts.getOrNull(0) ?: return null) ?: return null
        // One value spread across bands is read as their total over the whole span (EncodedSplitValue).
        val splitBands = if (isRadar) null else EncodedSplitValue.valueBands(source.datasets, channelInts)
        // A folded total decodes against the operation's widened range, as the renderer draws it.
        val decodeRange = (source as? XweatherEncodedTileSource)?.foldedDecodeRange
            ?: splitBands?.let { EncodedSplitValue.span(it) }
            ?: dataset0.dataRange
        val dataRangeStart = decodeRange.start.toFloat()
        val dataRangeEnd = decodeRange.endInclusive.toFloat()
        val raw0 = if (splitBands != null) EncodedSplitValue.combine(finalVals.take(splitBands.size)) else finalVals[0]
        var finalVal: Any?
        val dx = mapValues(raw0 ?: return null, dataRangeStart, dataRangeEnd)

        if (expression == SampleExpression.NUMBER) {
            if (raw0 == null) {
                return null
            }
            if (isRadar) {
                if (dx == 0f) return null
                val slot = radarClaimingSlot(aString, bString, zoomVar, latTile, lonTile, latPix, lonPix)
                if (slot < 0) return null
                if (radarValueOutsideMask(slot, dx)) return null
            }
            val enc = tileLayerRenderer as? EncodedDataRenderer<*, *>
            if (enc != null) {
                val norm = raw0 / 255f
                if (norm > enc.drawHigh || norm < enc.drawLow) {
                    return null
                }
            }
            if (suppressZeroPrecipInspector(id, dx)) {
                return null
            }

            finalVal = mapOf("value" to dx)
        } else if (expression == SampleExpression.ANGLE) {
            val maritimeWaveDir = id.startsWith("maritime.") && id.endsWith("_dir.fill")
            val sidecarSample: Float? =
                if (maritimeWaveDir && queryLon != null && queryLat != null) {
                    val sidecar =
                        mapController?.getSource("${id}__encodedGridVectors_argb_v2") as? EncodedGridVectorTileSource
                    sidecar?.inspectorSampleMaritimeDirDeg(
                        queryLon,
                        queryLat,
                        CameraSync.zoomForCustomLayerInstancing(),
                    )
                } else {
                    null
                }
            if (sidecarSample != null) {
                finalVal = mapOf("value" to sidecarSample)
            } else {
                // Fallback: nearest tile pixel (can disagree with bilinear instanced grid + placement zoom).
                val rawA = pixelValsAUByte[0]?.toInt()?.toDouble()
                val rawB = pixelValsBUByte[0]?.toInt()?.toDouble()
                val dirA = rawA?.let { metDirDegFromAngleBlueByte(it) }
                val dirB = rawB?.let { metDirDegFromAngleBlueByte(it) }
                val fb =
                    when {
                        dirA != null && dirB != null ->
                            blendMetDirDegFromAngleUnitVectors(dirA, dirB, sampleMeldProgress().toDouble())

                        dirA != null -> dirA
                        dirB != null -> dirB
                        else -> return null
                    }
                finalVal = mapOf("value" to fb.toFloat())
            }
        } else if (expression == SampleExpression.ENCODED_WIND_UV) {
            val gA = pixelValsAUByte[0]?.toDouble()
            val bA = pixelValsAUByte[1]?.toDouble()
            val gB = pixelValsBUByte[0]?.toDouble()
            val bB = pixelValsBUByte[1]?.toDouble()
            val rotDeg = when {
                gA != null && bA != null && gB != null && bB != null ->
                    griddedWindVertexRotDeg(gA, bA, gB, bB, sampleMeldProgress().toDouble())

                gA != null && bA != null ->
                    griddedWindVertexRotDeg(gA, bA, null, null, 0.0)

                gB != null && bB != null ->
                    griddedWindVertexRotDeg(gB, bB, null, null, 0.0)

                else -> return null
            }
            finalVal = mapOf("value" to rotDeg)
        } else {
            if (finalVals[1] == null) {
                return null
            }
            // Same guard as the band-0 lookup above.
            val dataset1 = source.datasets.getOrNull(channelInts.getOrNull(1) ?: return null) ?: return null
            val dataRangeStart2 = dataset1.dataRange.start.toFloat()
            val dataRangeEnd2 = dataset1.dataRange.endInclusive.toFloat()
            val dy = (mapValues(finalVals[1]!!.toFloat(), dataRangeStart2, dataRangeEnd2))
            when (expression) {
                SampleExpression.VECTOR -> {
                    val speed = sqrt((dx * dx + dy * dy).toDouble())
                    val angleDeg =
                        if (speed < 1e-9) {
                            0f
                        } else {
                            val radians = atan2(dx / speed, dy / speed)
                            ((radians * 180 / Math.PI + 360) % 360).toFloat()
                        }
                    finalVal = mapOf("value" to speed.toFloat(), "angle" to angleDeg)
                }

                SampleExpression.SUM -> {
                    finalVal = mapOf("value" to dx + dy)
                }

                SampleExpression.DIFFERENCE -> {
                    finalVal = mapOf("value" to dx - dy)
                }

                else -> {
                    finalVal = mapOf("value" to finalVals[0], "angle" to finalVals[1])
                }
            }
        }

        return finalVal
    }

    /**
     * Decoded numeric samples at timeline phases A and B (no meld). Data-query labels cache these
     * and lerp with [Timeline.dataMeld] so playback does not re-hit encoded tiles every tick.
     */
    /**
     * Sampled endpoints for one point.
     *
     * [noData] distinguishes "the pixels were read and there is genuinely nothing here" from "the data
     * has not arrived yet", which both otherwise look like null values. The caller must not keep
     * re-sampling the former: a city in clear air would be re-queried on every pass forever.
     *
     * Mirrors the `nodata` flag MapsGL JS returns alongside the value.
     */
    internal data class EncodedNumericEndpoints(
        val valueA: Double?,
        val valueB: Double?,
        val noData: Boolean = false,
    )

    internal fun queryNumericEndpoints(
        zoomVar: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
    ): EncodedNumericEndpoints? {
        // Outside its own zoom range the layer is not drawn, so it reports no value — a `*-text` layer
        // must not label cities from a product the map is not showing.
        if (!withinLayerZoomRangeForQuery()) return null
        val layerTimeline = Timeline.sourceTimeHash[source.id] ?: return null
        val channelInts: List<Int> = when (paint) {
            is SampleLayerPaint -> (paint as SampleLayerPaint).sample.channel.map { it.rawValue }
            is ParticleLayerPaint -> (paint as ParticleLayerPaint).sample.channel.map { it.rawValue }
            is ContourLayerPaint -> (paint as ContourLayerPaint).sample.channel.map { it.rawValue }
            is GridLayerPaint -> {
                val s = (paint as GridLayerPaint).sample ?: return null
                s.channel.map { it.rawValue }
            }
            else -> return null
        }
        val expression: SampleExpression = when (paint) {
            is SampleLayerPaint -> (paint as SampleLayerPaint).sample.expression
            is ParticleLayerPaint -> (paint as ParticleLayerPaint).sample.expression
            is ContourLayerPaint -> (paint as ContourLayerPaint).sample.expression
            is GridLayerPaint -> {
                val s = (paint as GridLayerPaint).sample ?: return null
                s.expression
            }
            else -> return null
        }
        if (expression != SampleExpression.NUMBER) {
            // Derived readings - wind speed's vector magnitude, the temperature-change differences -
            // are computed in queryFeatures rather than decoded from one band, so they come back
            // through it. Pin the phases: left to its own, a hidden sample reads the bootstrap
            // interval, misses every tile the playhead actually fetched, and the labels draw a place
            // name with no value. Sample each endpoint on its own so the published label still lerps
            // across the timeline like a single-band one.
            val (aString, bString) = queryPhaseStrings(layerTimeline)
            fun endpointAt(phase: String): Double? {
                val sample = queryFeaturesAt(
                    zoomVar, latTile, lonTile, latPix, lonPix, null, null, phase, phase,
                ) as? Map<*, *>
                return (sample?.get("value") as? Number)?.toDouble()
            }
            val valueA = endpointAt(aString)
            val valueB = if (bString == aString) valueA else endpointAt(bString)
            return if (valueA == null && valueB == null) null else EncodedNumericEndpoints(valueA, valueB)
        }
        // The layer's own draw range, taken from the paint rather than the renderer. A `*-text` layer
        // samples a hidden product whose renderer may not exist yet, and the renderer check below is
        // skipped entirely when it does not — which is how a pixel with no precipitation at all used to
        // decode to the bottom of the data range and label a city "0.00 in".
        val sampleDrawRange: ClosedRange<Double>? = when (paint) {
            is SampleLayerPaint -> (paint as SampleLayerPaint).sample.drawRange
            is ParticleLayerPaint -> (paint as ParticleLayerPaint).sample.drawRange
            is ContourLayerPaint -> (paint as ContourLayerPaint).sample.drawRange
            is GridLayerPaint -> (paint as GridLayerPaint).sample?.drawRange
            else -> null
        }
        val dataset0 = source.datasets.getOrNull(channelInts.getOrNull(0) ?: return null) ?: return null
        // One value spread across bands is read as their total over the whole span (EncodedSplitValue).
        val splitBands = if (isRadar) null else EncodedSplitValue.valueBands(source.datasets, channelInts)
        // A folded total decodes against the operation's widened range, as the renderer draws it.
        val decodeRange = (source as? XweatherEncodedTileSource)?.foldedDecodeRange
            ?: splitBands?.let { EncodedSplitValue.span(it) }
            ?: dataset0.dataRange
        val dataRangeStart = decodeRange.start.toFloat()
        val dataRangeEnd = decodeRange.endInclusive.toFloat()
        // Same dataset the values decode against, so its sentinel is the right one to compare to.
        val noDataValue: Double? = dataset0.noData
        val (aString, bString) = queryPhaseStrings(layerTimeline)
        val channel0 = if (isRadar) 3 else channelInts.getOrNull(0)
        fun sampleByte(phase: String): Float? =
            if (splitBands != null) {
                EncodedSplitValue.combine(
                    channelInts.take(splitBands.size).map {
                        getPixelValue(it, phase, zoomVar, latTile, lonTile, latPix, lonPix)?.toFloat()
                    },
                )
            } else {
                getPixelValue(channel0, phase, zoomVar, latTile, lonTile, latPix, lonPix)?.toFloat()
            }
        val byteA = sampleByte(aString)
        val byteB = sampleByte(bString)
        val radarSlot = if (isRadar) {
            radarClaimingSlot(aString, bString, zoomVar, latTile, lonTile, latPix, lonPix)
        } else {
            -1
        }
        if (isRadar && radarSlot < 0) {
            return if (byteA != null || byteB != null) {
                EncodedNumericEndpoints(null, null, noData = true)
            } else {
                null
            }
        }
        // Whether any pixel was actually read, as opposed to the tile not being resident yet.
        var sawPixel = false
        fun decode(raw: Float?): Double? {
            if (raw == null) return null
            sawPixel = true
            val mapped = mapValues(raw, dataRangeStart, dataRangeEnd).toDouble()
            if (isRadar && mapped == 0.0) return null
            // The source's own no-data sentinel, where it declares one.
            if (noDataValue != null && mapped == noDataValue) return null
            // Outside what the layer would draw means there is nothing at this point worth labelling —
            // the same judgement the fill makes, applied to the text. This is what MapsGL JS expresses
            // as a `nodata` flag on the query result, which leaves the feature's value undefined.
            sampleDrawRange?.let { range ->
                if (mapped < range.start || mapped > range.endInclusive) return null
            }
            if (isRadar && radarValueOutsideMask(radarSlot, mapped.toFloat())) return null
            val enc = tileLayerRenderer as? EncodedDataRenderer<*, *>
            // Only trust the renderer's range once it has actually been populated; it defaults to
            // 0f..0f, which would reject every sample.
            if (enc != null && enc.drawHigh > enc.drawLow) {
                val norm = raw / 255f
                if (norm > enc.drawHigh || norm < enc.drawLow) return null
            }
            return mapped
        }
        val valueA = decode(byteA)
        val valueB = decode(byteB)
        if (valueA == null && valueB == null) {
            // Read the pixels and found nothing worth showing: a definitive answer, not a miss.
            return if (sawPixel) EncodedNumericEndpoints(null, null, noData = true) else null
        }
        return EncodedNumericEndpoints(valueA, valueB)
    }

    private fun Float.toTwoDecimalPlaceString(): String {
        return "%.2f".format(this)
    }

    /**
     * Precip-type slot for a radar query, using phase A when it has a flag and phase B otherwise.
     * `-1` means the texel has reflectivity with no rain/mix/snow classification.
     */
    private fun radarClaimingSlot(
        phaseA: String,
        phaseB: String,
        zoom: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
    ): Int {
        fun slot(timeString: String): Int {
            fun flag(channel: Int): Int =
                getPixelValue(channel, timeString, zoom, latTile, lonTile, latPix, lonPix)
                    ?.toInt()?.and(0xFF) ?: 0
            return EncodedDataRenderer.claimingRadarMaskSlot(flag(0), flag(1), flag(2))
        }
        val slotA = slot(phaseA)
        return if (slotA >= 0) slotA else slot(phaseB)
    }

    /** True when [value] sits outside the claiming mask's draw range. Slots with no range pass. */
    private fun radarValueOutsideMask(slot: Int, value: Float): Boolean {
        if (slot !in 0..2) return false
        val sample = (paint as? SampleLayerPaint)?.sample ?: return false
        val dataset = source.datasets.getOrNull(sample.channel.firstOrNull()?.rawValue ?: return false)
            ?: return false
        val bounds = EncodedDataRenderer.maskSlotDiscardBounds(
            sample.colorScale.masks,
            sample.drawRange,
            dataset.dataRange,
        )
        val lo = bounds[slot * 2]
        val hi = bounds[slot * 2 + 1]
        return hi > lo && (value < lo || value > hi)
    }

    private fun mapValues(input: Float, outputLow: Float, outputHigh: Float): Float {
        return outputLow + (outputHigh - outputLow) * ((input - 0f) / (255f))
    }

    /**
     * `conditions.precip.*` hourly rate: when decoded rate is zero, omit the inspector row (coordinates only),
     * matching radar no-echo behavior.
     */
    private fun suppressZeroPrecipInspector(layerId: String, decodedRate: Float): Boolean {
        if (decodedRate != 0f) return false
        return layerId.contains(".precip.") &&
            !layerId.contains("precip_rate") &&
            !layerId.contains("ptype")
    }


    /** [EncodedGridVectorTileSource.maritimeScalarDirDegFromBlueByte] / JS EXPRESSION_ANGLE. */
    private fun metDirDegFromAngleBlueByte(bRaw: Double): Double {
        val norm = bRaw / 255.0
        var deg = norm * 360.0 - 180.0
        if (deg < 0.0) deg += 360.0
        return deg
    }

    /**
     * Matches [WindArrowInstancedRenderer] maritime branch: unit vectors from met dir, mix with [t], normalize,
     * recover scalar met degrees for the data inspector (same as GPU).
     */
    private fun blendMetDirDegFromAngleUnitVectors(dirA: Double, dirB: Double, t: Double): Double {
        val tt = t.coerceIn(0.0, 1.0)
        val rA = Math.toRadians(dirA - 90.0)
        val rB = Math.toRadians(dirB - 90.0)
        var mx = (1.0 - tt) * cos(rA) + tt * cos(rB)
        var my = (1.0 - tt) * sin(rA) + tt * sin(rB)
        val len = hypot(mx, my)
        if (len < 1e-9) return dirA
        mx /= len
        my /= len
        return (Math.toDegrees(atan2(my, mx)) + 90.0 + 360.0) % 360.0
    }

    /**
     * Matches instanced wind/arrow vertex shaders ([com.xweather.mapsgl.renderers.WindArrowInstancedRenderer]):
     * per-phase G/B → met dir via atan2(u,-v), unit vectors (cos(dir−90°), sin(dir−90°)), mix with [t], normalize,
     * then rotDeg = atan2(mixed.y, mixed.x). This differs from interpolating G/B bytes then atan2 once.
     */
    private fun griddedWindVertexRotDeg(
        gA: Double,
        bA: Double,
        gB: Double?,
        bB: Double?,
        t: Double
    ): Float {
        fun metDirDegFromGb(g: Double, b: Double): Double {
            val u = (g / 255.0) * 107.28 - 53.64
            val v = (b / 255.0) * 107.28 - 53.64
            return Math.toDegrees(atan2(u, -v))
        }

        fun unitFromMetDir(dirDeg: Double): Pair<Double, Double> {
            val r = Math.toRadians(dirDeg - 90.0)
            return cos(r) to sin(r)
        }
        val (vax, vay) = unitFromMetDir(metDirDegFromGb(gA, bA))
        if (gB == null || bB == null) {
            return Math.toDegrees(atan2(vay, vax)).toFloat()
        }
        val (vbx, vby) = unitFromMetDir(metDirDegFromGb(gB, bB))
        val tt = t.coerceIn(0.0, 1.0)
        var mx = (1.0 - tt) * vax + tt * vbx
        var my = (1.0 - tt) * vay + tt * vby
        val len = hypot(mx, my)
        if (len < 1e-9) return Math.toDegrees(atan2(vay, vax)).toFloat()
        mx /= len
        my /= len
        return Math.toDegrees(atan2(my, mx)).toFloat()
    }

    /**
     * Interpolates between two nullable UByte values using [sampleMeldProgress]
     * (JS: `sampleMeld() ? progress : 0`).
     */
    private fun interpolate(valA: UByte?, valB: UByte?): Float? {
        val a = valA?.toFloat()
        val b = valB?.toFloat()
        val t = sampleMeldProgress()

        return when {
            a != null && b != null -> a * (1f - t) + b * t
            a != null -> a
            b != null -> b
            else -> null
        }
    }

    /** Effective timeline blend for queries — respects [SamplePaint.meld]. */
    private fun sampleMeldProgress(): Float = paint.effectiveSampleMeldProgress(Timeline.dataMeld)

    private fun getPixelValue(
        channel: Int?,
        timeString: String,
        zoom: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int
    ): UByte? {
        if (channel == null) return null
        return getPixelValFromLocalCache(
            this,
            zoom,
            latTile,
            lonTile,
            latPix,
            lonPix,
            timeString,
            channel
        )
    }

    private fun getPixel(hash: String, x: Int, y: Int): Byte? {
        val pickedCache = localChannelCache[hash] ?: return null
        val pixelIndex = (y * dataSize) + x
        return pickedCache[pixelIndex]
    }


    private fun getPixelValFromLocalCache(
        layer: MapLayer<*, *>,
        zoom: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        timeString: String,
        channel: Int
    ): UByte? {

        val layerTimeline = Timeline.sourceTimeHash[layer.source.id] ?: return null

        if (pr.ON) pr.p(TAG, pr.dIFix, "getPixelValFromLocalCache() timeString = $timeString")

        var pixelVal =
            getPixel(
                "${layer.source.id}0:$zoom/$lonTile/$latTile/${timeString}$channel",
                lonPix,
                latPix
            )

        if (pr.ON) pr.p(TAG, pr.dIFix, "getPixelValFromLocalCache() pixelVal = $pixelVal")

        if (pixelVal == null) {  // If not in local cache, get from native cache and store in local cache
            var byteArray: ByteArray?
            byteArray = getByteArrayFromNativeCache(layer, "0:$zoom/$lonTile/$latTile/${timeString}")
            if (byteArray == null /*  zoom > layer.source.maxZoom*/) {
                var finalLonPix = lonPix
                var finalLatPix = latPix
                var zoomCounter: Int = if (zoom > layer.source.maxZoom) {
                    layer.source.maxZoom.toInt()
                } else {
                    zoom - 1
                }
                while (byteArray == null && zoomCounter >= 0) {
                    val quint = getParentTileCoordinates(zoom, lonTile, latTile, zoomCounter, lonPix, latPix)
                    byteArray = getByteArrayFromNativeCache(
                        layer,
                        "0:${quint[0]}/${quint[1]}/${quint[2]}/${timeString}",
                    )
                    if (byteArray != null) {
                        finalLonPix = quint[3]
                        finalLatPix = quint[4]
                    }
                    zoomCounter--
                }
                if (byteArray == null) {
                    return null
                }
                val channelByteArray = nativeToLocalResized(byteArray, channel)
                val pixelIndex = (finalLatPix * dataSize) + finalLonPix
                pixelVal = channelByteArray[pixelIndex]
            } else {
                // Rule: no-redundant-native-cache-refetch. `byteArray` here is already the
                // successful result of the FIRST getByteArrayFromNativeCache call above — this
                // branch only runs when it's non-null. Re-fetching the identical key a second time
                // and using THAT result instead threw the already-good bytes away and raced against
                // concurrent DataQueryCoordinator sampling coroutines (CONCURRENT_SAMPLES=8) touching
                // the same native cache: two calls with the same key moments apart could return
                // different results, and a null second call failed a sample that had just succeeded.
                // Confirmed live: instrumented logs showed queryFeatures reporting a miss for zoom/tile
                // keys immediately after this exact direct-hit branch was reached — every city in the
                // affected tile lost its temperature value even though the tile was cached correctly.
                val channelByteArray = nativeToLocalResized(byteArray, channel)
                localChannelCache["${layer.source.id}0:$zoom/$lonTile/$latTile/${timeString}$channel"] =
                    channelByteArray
                pixelVal = getPixel(
                    "${layer.source.id}0:$zoom/$lonTile/$latTile/${timeString}$channel",
                    lonPix,
                    latPix
                )
            }
        }
        return pixelVal?.toUByte()
    }

    private fun getPixelValFromLocalCacheOld(
        layer: MapLayer<*, *>,
        zoom: Int,
        latTile: Int,
        lonTile: Int,
        latPix: Int,
        lonPix: Int,
        phase: Int,
        channel: Int
    ): UByte? {
        if (Timeline.timeStrings.size <= phase) return null

        if (pr.ON) pr.p(TAG, pr.dIFix, "getPixelValFromLocalCache() time used: ${Timeline.timeStrings[phase]}")

        var pixelVal =
            getPixel(
                "${layer.source.id}0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}$channel",
                lonPix,
                latPix
            )

        if (pixelVal == null) {  // If not in local cache, get from native cache and store in local cache
            var byteArray: ByteArray?
            byteArray = getByteArrayFromNativeCache(layer, "0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}")
            if (byteArray == null /*  zoom > layer.source.maxZoom*/) {
                var finalLonPix = lonPix
                var finalLatPix = latPix
                var zoomCounter: Int = if (zoom > layer.source.maxZoom) {
                    layer.source.maxZoom.toInt()
                } else {
                    zoom - 1
                }
                while (byteArray == null && zoomCounter >= 0) {
                    val quint = getParentTileCoordinates(zoom, lonTile, latTile, zoomCounter, lonPix, latPix)
                    byteArray = getByteArrayFromNativeCache(
                        layer,
                        "0:${quint[0]}/${quint[1]}/${quint[2]}/${Timeline.timeStrings[phase]}",
                    )
                    if (byteArray != null) {
                        finalLonPix = quint[3]
                        finalLatPix = quint[4]
                    }
                    zoomCounter--
                }
                if (byteArray == null) {
                    return null
                }
                val channelByteArray = nativeToLocalResized(byteArray, channel)
                val pixelIndex = (finalLatPix * dataSize) + finalLonPix
                pixelVal = channelByteArray[pixelIndex]
            } else {
                byteArray =
                    getByteArrayFromNativeCache(layer, "0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}")
                if (byteArray == null) {
                    return null
                }
                val channelByteArray = nativeToLocalResized(byteArray, channel)
                localChannelCache["${layer.source.id}0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}$channel"] =
                    channelByteArray
                pixelVal = getPixel(
                    "${layer.source.id}0:$zoom/$lonTile/$latTile/${Timeline.timeStrings[phase]}$channel",
                    lonPix,
                    latPix
                )
            }
        }
        return pixelVal?.toUByte()
    }

    private fun getParentTileCoordinates(
        currentZoom: Int,
        lonTile: Int,
        latTile: Int,
        targetZoom: Int,
        lonPix: Int,
        latPix: Int
    ): IntArray {
        val zoomDifference = currentZoom - targetZoom
        // Each level up divides the coordinates by 2. Going up N levels means dividing by 2^N.
        val divisor = 1 shl zoomDifference // Efficient way to calculate 2^zoomDifference

        // Find the parent tile coordinates
        val parentLonTile = lonTile / divisor
        val parentLatTile = latTile / divisor
        // Find the starting offset of the original tile within the parent's grid
        val lonOffsetInParent = lonTile % divisor
        val latOffsetInParent = latTile % divisor

        // Calculate the new pixel location within the parent tile
        // The original tile's pixels are scaled down and shifted by the offset
        val newLonPix = (lonPix / divisor) + (lonOffsetInParent * (dataSize / divisor))
        val newLatPix = (latPix / divisor) + (latOffsetInParent * (dataSize / divisor))

        return intArrayOf(targetZoom, parentLonTile, parentLatTile, newLonPix, newLatPix)
    }

    private fun getByteArrayFromNativeCache(layer: MapLayer<*, *>, hash: String): ByteArray? {
        if (layer is EncodedTileLayer) {
            if (layer.paint is SampleLayerPaint ||
                layer.paint is ParticleLayerPaint ||
                layer.paint is ContourLayerPaint ||
                layer.paint is GridLayerPaint
            ) {
                //val key = "0:1/1/0/[\"2025-09-17T13:00:00Z\"]"
                return (layer as TileLayer).source.tileCache.nativeCache.getData("${layer.source.id}${hash}")
            }
        }
        return null
    }

    private fun nativeToLocalResized(
        sourceRgbaArray: ByteArray,
        channel: Int
    ): ByteArray {

        val destinationArray = ByteArray(dataSize * dataSize)
        // Padded native buffers are (512+8+8)² RGBA; the 512×512 data block starts at (padding, padding),
        // same as [sample.frag.combined.glsl] / [PaddingManager] — not (2,2).
        val xPixelOffset = paddingSize
        val yPixelOffset = paddingSize

        for (destY in 0 until dataSize) {
            for (destX in 0 until dataSize) {
                // Calculate the corresponding pixel coordinates in the source image
                val sourcePixelX = destX + xPixelOffset
                val sourcePixelY = destY + yPixelOffset
                val sourcePixelStartIndex = (sourcePixelY * (dataSize + paddingSize + paddingSize) + sourcePixelX) * 4
                val greenByteIndexInSource = sourcePixelStartIndex + channel
                val destinationIndex = destY * dataSize + destX
                destinationArray[destinationIndex] = sourceRgbaArray[greenByteIndexInSource]
            }
        }
        return destinationArray
    }
}

/**
 * Time strings a data-query label should cache as interval ends.
 *
 * Scrubbing and playback lerp these with the playhead meld. Idle mode (no scrub yet) keeps the
 * single nearest valid time the fill is drawing. Layer valid times win over the global tick
 * string so the cache key matches the tile that was downloaded.
 */
internal fun queryIntervalEndpointStrings(
    singleInterval: Boolean,
    collapsedA: String,
    collapsedB: String,
    phaseAIndex: Int,
    phaseBIndex: Int,
    globalLongs: List<Long>,
    globalStrings: List<String>,
    layerLongs: List<Long>,
    layerStrings: List<String>,
): Pair<String, String> {
    if (singleInterval && collapsedA.length > 4) {
        val b = if (collapsedB.length > 4) collapsedB else collapsedA
        return collapsedA to b
    }
    fun at(index: Int): String {
        if (globalStrings.isEmpty()) return ""
        val i = index.coerceIn(0, globalStrings.lastIndex)
        val globalLong = globalLongs.getOrNull(i)
        if (globalLong != null && layerLongs.size >= 2 && layerStrings.size == layerLongs.size) {
            Timeline.closestValidTimeInLists(globalLong, layerLongs, layerStrings)
                ?.second
                ?.takeIf { it.length > 4 }
                ?.let { return it }
        }
        return globalStrings[i]
    }
    val a = at(phaseAIndex)
    val b = at(phaseBIndex).ifEmpty { a }
    if (a.length > 4) return a to b
    if (collapsedA.length > 4) {
        val b = if (collapsedB.length > 4) collapsedB else collapsedA
        return collapsedA to b
    }
    return a to b
}

/** Cache identity for the time strings [queryPhaseStrings] will read. Meld is not part of it. */
internal fun dataQueryEndpointKey(sourceId: String?): String {
    if (sourceId.isNullOrEmpty()) return ""
    val layerTimeline = Timeline.sourceTimeHash[sourceId] ?: return ""
    val target = layerTimeline.computeGlobalAnimationTarget()
    val (globalLongs, globalStrings) = Timeline.globalTimeListsSnapshot()
    val (a, b) = queryIntervalEndpointStrings(
        singleInterval = Timeline.prefersSingleIntervalIdleTarget(),
        collapsedA = target.phaseA,
        collapsedB = target.phaseB,
        phaseAIndex = Timeline.currentPhaseA,
        phaseBIndex = Timeline.currentPhaseB,
        globalLongs = globalLongs,
        globalStrings = globalStrings,
        layerLongs = layerTimeline.timeLongs.toList(),
        layerStrings = layerTimeline.timeStrings.toList(),
    )
    return "$a|$b"
}

/**
 * Samples already read for [previousKey] that are still ends of [nextKey].
 *
 * Playback steps one interval at a time, so the hour under the playhead is the
 * previous far end and the next near end. That sample may stay on screen.
 * A held number whose time is not either new end is a different hour — the 04Z
 * cache kept publishing 00Z because the interval index never moved — and must
 * be dropped. Null means drop both. A null end in the pair still has to be read.
 */
internal fun retainedSamplesForEndpointKey(
    previousKey: String,
    nextKey: String,
    valueA: Double?,
    valueB: Double?,
): Pair<Double?, Double?>? {
    if (previousKey.isEmpty() || nextKey.isEmpty() || previousKey == nextKey) return null
    val oldParts = previousKey.split('|', limit = 2)
    val newParts = nextKey.split('|', limit = 2)
    if (oldParts.size < 2 || newParts.size < 2) return null
    val oldA = oldParts[0]
    val oldB = oldParts[1]
    val newA = newParts[0]
    val newB = newParts[1]
    if (newA.length <= 4 || newB.length <= 4) return null
    fun sampleFor(time: String): Double? {
        if (time.length <= 4) return null
        if (time == oldA && valueA != null) return valueA
        if (time == oldB && valueB != null) return valueB
        return null
    }
    val keptA = sampleFor(newA)
    val keptB = if (newA == newB) keptA else sampleFor(newB)
    if (keptA == null && keptB == null) return null
    return keptA to keptB
}

