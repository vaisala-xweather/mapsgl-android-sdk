package com.xweather.mapsgl.layers


import com.mapbox.maps.ScreenCoordinate

/**
 * A screen- or map-space geometry used to query **rendered** features.
 *
 * Use this to describe *where* the hit-test should occur. The concrete meaning
 * of each case is engine-agnostic:
 * - `Coordinate` — A geographic coordinate in WGS84 (lat/lon). The renderer
 *   is responsible for projecting this to screen space and applying an appropriate
 *   tolerance for hit-testing at the current camera/zoom.
 * - `Point` — A point in *screen points* relative to the
 *   map view's bounds.
 * - `Rect` — A screen-space rectangle (in points) that selects features intersecting
 *   the given area.
 */
sealed class QueryGeometry {
    data class Coordinate(val value: com.mapbox.geojson.Point) : QueryGeometry()
    data class Point(val value: ScreenCoordinate) : QueryGeometry()
    data class Rect(val value: ScreenRect) : QueryGeometry()

    companion object {
        /**
         * Creates a QueryGeometry instance from an android.graphics.Rect.
         */
        fun rect(rect: android.graphics.Rect): QueryGeometry {
            // Convert the Android Rect to our custom ScreenRect
            val screenRect = ScreenRect(
                left = rect.left.toFloat(),
                top = rect.top.toFloat(),
                right = rect.right.toFloat(),
                bottom = rect.bottom.toFloat()
            )
            // Return an instance of the 'Rect' subclass of QueryGeometry
            return Rect(screenRect)
        }
    }

}

/**
 * A capability for querying **rendered** features from one or more visible layers.
 *
 * Conformers (e.g., a `MapboxMapController`) translate the engine-agnostic
 * `QueryGeometry` into the underlying SDK's query API and map the results into
 * `QueriedFeature` values that this module understands. This keeps callers decoupled
 * from any specific map engine.
 *
 * Implementations should be thread-safe and may execute work off the main thread.
 * Results are filtered to the provided `layerIds` when not `null`.
 */
interface RenderedFeatureQuerying {
    /**
     * Queries rendered features intersecting the given geometry.
     *
     * @param geometry The hit-test geometry in either screen space (`.point`, `.rect`)
     *                 or geographic space (`.coordinate`).
     * @param layerIds Optional array of layer identifiers to restrict the query to.
     *                 Pass `null` to query all visible layers (engine-dependent behavior).
     * @return A list of `QueriedFeature` values describing the matched features.
     * @throws Exception Any error produced by the underlying map engine's query API.
     */
    suspend fun queryFeatures(
        inGeometry: QueryGeometry,
        layerIds: List<String>? = null
    ): List<QueriedFeature>
}

/**
 * A type that can perform spatial queries against map layers or data sources.
 * Implementers are responsible for translating a geographic coordinate
 * and zoom level into one or more feature hits.
 */
interface FeatureQueryable {
    /**
     * Queries for features at a given geographic coordinate and zoom level.
     * @param geometry Geographic coordinate (latitude/longitude) to query.
     * @param zoom Zoom level at which to perform the query.
     * @param allowPartial When true, allows returning partial results (e.g., when some tile data is missing).
     * @return A `FeatureQueryResult` describing the matched features, or null if none were found.
     */
    suspend fun queryFeatures(
        inGeometry: QueryGeometry,
        zoom: Int,
        allowPartial: Boolean? = null
    ): FeatureQueryResult?
}

/**
 * The result of a feature query for a specific layer.
 * Contains the identifier of the queried layer and any matching features.
 */
data class FeatureQueryResult(
    /**
     * Identifier of the layer that was queried.
     */
    val layerId: String,

    /**
     * The list of features returned by the query.
     */
    val features: List<QueriedFeature>
)

/**
 * A single feature returned by a query. Wraps source metadata and the feature's data payload.
 */
data class QueriedFeature(
    /**
     * Optional identifier for the feature.
     */
    val id: String?,

    /**
     * The name of the source that produced this feature (e.g., vector tile source ID).
     */
    val source: String,

    /**
     * Optional source layer within the source (e.g., sublayer name for vector tiles).
     */
    val sourceLayer: String?,


    /**
     * The underlying map feature object.
     */
    //val feature: Feature,

    val properties: Map<String, Any?>,

    /**
     * Map style layer id for this hit (e.g. encoded tile layer id), when known.
     */
    val mapLayerId: String? = null,

) {
    /*
    /**
     * Arbitrary feature payload (attributes or properties).
     */
    val properties: Map<String, Any?>
        get() = feature.properties()?.entrySet()?.associate { entry ->
            entry.key to entry.value
        } ?: emptyMap()
        */
}


data class ScreenRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
)
