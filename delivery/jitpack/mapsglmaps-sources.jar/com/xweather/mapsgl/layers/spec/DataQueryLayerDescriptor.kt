package com.xweather.mapsgl.layers.spec

import com.xweather.mapsgl.layers.tile.LayerTiming
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.types.LayerType
import com.xweather.mapsgl.weather.LayerCode

/**
 * Descriptor for a **data-query** (`query`) layer: weather-value labels at point locations
 * sampled from a different layer.
 *
 * At add time the map controller owns a [com.xweather.mapsgl.layers.tile.DataQueryCoordinator]
 * that publishes pre-formatted features into a private GeoJSON source consumed by an ordinary
 * [SymbolLayerDescriptor]. Callers only see the public symbol layer.
 *
 * @property sampledLayerCode Weather product whose encoded tiles are sampled at each point.
 * @property labelKeyPath Property path on point features for the secondary label (e.g. `"name"`).
 * @property rankKeyPath Property path for collision rank (e.g. `"rank"`).
 * @property sourceLayer MVT layer name when [source] is tiled vector; `null` for GeoJSON points.
 *
 * @suppress
 */
data class DataQueryLayerDescriptor(
    override var id: String,
    override var source: String,
    var sampledLayerCode: LayerCode,
    var labelKeyPath: String = "name",
    var rankKeyPath: String = "rank",
    override var sourceLayer: String? = null,
    override var paint: SymbolLayerPaint = SymbolLayerPaint(
        icon = IconPaint(),
        text = emptyList(),
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
    override var useGlRendering: Boolean = true,
    override var timing: LayerTiming? = null,
    override var maskLayerIds: List<String> = emptyList(),
    override var maskLayerId: String? = null,
    override var layerMask: LayerMaskSpec? = null,
    override var stencilLayerMask: StencilLayerMaskSpec? = null,
) : VectorLayerDescriptor<SymbolLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.query
}
