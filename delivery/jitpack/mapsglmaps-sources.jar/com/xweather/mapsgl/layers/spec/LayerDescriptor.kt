package com.xweather.mapsgl.layers.spec

import com.xweather.mapsgl.layers.spec.MaskLayerKind.COUNTRY
import com.xweather.mapsgl.layers.spec.MaskLayerKind.LAND
import com.xweather.mapsgl.layers.spec.MaskLayerKind.TRANSPORTATION
import com.xweather.mapsgl.layers.spec.MaskLayerKind.WATER
import com.xweather.mapsgl.layers.spec.StencilLayerMaskSpec.Companion.MAX_STENCIL_MASK_LAYERS
import com.xweather.mapsgl.layers.tile.LayerTiming
import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.ContourPaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.HeatmapLayerPaint
import com.xweather.mapsgl.style.HeatmapPaint
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.ParticlePaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.RasterPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.tiles.LatLonBounds
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType
import com.xweather.mapsgl.weather.WeatherConfiguration

internal const val BINARY_COMPAT_SHIM: String =
    "Binary-compatibility shim for SDK 1.6.0 and earlier; not for source use."

/**
 * Built-in GLES stencil mask kinds for weather / bitmap layers (JS `mask: "land"|"water"|…`).
 *
 * Prefer [LayerMaskSpec] / [StencilLayerMaskSpec] on layer descriptors when clipping to arbitrary style
 * layers. [TRANSPORTATION] and [COUNTRY] draw along line ribbons; [LAND] / [WATER] fill area geometry.
 */
enum class MaskLayerKind {
    /** No built-in stencil mask; layer draws everywhere unless a custom stencil mask is also set. */
    NONE,

    /** Draw only on land (inverted water stencil from [com.xweather.mapsgl.map.mapbox.GlStencilOsm]). */
    LAND,

    /** Draw only on water (marine water stencil from [com.xweather.mapsgl.map.mapbox.GlStencilOsm]). */
    WATER,

    /**
     * GLES stencil: all features in the MVT `transportation` source-layer from
     * [com.xweather.mapsgl.map.mapbox.GlStencilOsm] (same tiles as marine land/water). Weather draws
     * only along road geometry (line ribbon), similar to [WATER].
     */
    TRANSPORTATION,

    /**
     * GLES stencil: country border geometry from [com.xweather.mapsgl.map.mapbox.GlStencilOsm] tiles —
     * Mapbox Streets `admin` (admin_level 0) or MapsGL `boundary` (admin_level 2). Requires
     * [BitmapLayerDescriptor.maskCountryIso3166Alpha2] (e.g. `"US"`, `"ES"`). Draw only along matched
     * borders (line ribbon), same stencil test as [WATER].
     */
    COUNTRY,
}

/**
 * How multiple [StencilMaskLayerRef] entries combine in the stencil buffer (mirrors JS `mask.mode`).
 */
enum class StencilMaskCombineMode {
    /** Every mask slot must be set (intersection). */
    ALL,

    /** At least one mask slot must be set (union). */
    ANY,
}

/**
 * References a Mapbox style layer (typically [com.xweather.mapsgl.layers.tile.VectorTileLayer]) by id.
 * That layer’s [com.xweather.mapsgl.layers.tile.VectorTileLayer.sourceLayer] and [filter] define which
 * MVT features fill this stencil slot.
 */
data class StencilMaskLayerRef(val layerId: String)

/**
 * JS-style layer mask convenience for weather layers:
 * - `layers`: explicit layer refs (optionally auto-create built-in weather masks with [overrides])
 * - `type`: quick `water`/`land` mask
 * - `mode`/`invert`: same semantics as JS SDK
 *
 * Resolved by [com.xweather.mapsgl.map.MapController.addWeatherLayer] into [StencilLayerMaskSpec].
 */
enum class LayerMaskType {
    /**
     * Mask to **water** geometry (built-in water mask layer); weather draws only where water stencil is set.
     */
    WATER,

    /**
     * Mask to **land**: uses the same water stencil source with inverted semantics so weather draws on land.
     */
    LAND,
}

/**
 * One entry in [LayerMaskSpec.layers]: either an existing map layer id or a **weather layer code**
 * used to auto-create a mask layer.
 *
 * When [id] matches an existing layer, that layer’s geometry is used as a stencil mask as-is.
 * When it does not exist but matches a [com.xweather.mapsgl.weather.LayerCode] (by [com.xweather.mapsgl.weather.LayerCode.value]
 * or enum name), [com.xweather.mapsgl.map.MapController.addWeatherLayer] creates a helper mask layer
 * (default id `"${id}::mask"`, or [maskId] if set) with optional [overrides].
 *
 * @property id Existing layer id **or** weather product id / enum name for auto-creation.
 * @property maskId Stable id for the auto-created mask layer; defaults to `"${id}::mask"` plus a
 *   short hash suffix when [maskFilter] is set (JS parity: unique ids per filter without an explicit [maskId]).
 * @property overrides Applied to the [com.xweather.mapsgl.weather.WeatherConfiguration] when a mask layer is auto-created
 *   (for example stroke width on road masks).
 * @property maskFilter Optional Mapbox-style filter applied to the auto-created weather mask layer’s
 *   vector descriptor, and used (with [maskId] null) to derive a unique default [maskId] suffix.
 *
 * @see LayerMaskSpec
 * @see com.xweather.mapsgl.map.MapController.addWeatherLayer
 */
data class LayerMaskLayerConfig(
    val id: String,
    val maskId: String? = null,
    val overrides: ((WeatherConfiguration) -> Unit)? = null,
    val maskFilter: Expression? = null,
)

/**
 * JavaScript SDK–style **`mask`** configuration for weather layers on Android.
 *
 * Set this on supported bitmap-style descriptors ([RasterLayerDescriptor], [SampleLayerDescriptor],
 * [ContourLayerDescriptor], [ParticleLayerDescriptor], [GridLayerDescriptor]) as `layerMask`. When
 * [com.xweather.mapsgl.map.MapController.addWeatherLayer] resolves it to a [StencilLayerMaskSpec]
 * (explicit stencil layer refs, combine mode, invert).
 *
 * **Semantics (aligned with JS)**
 * - [layers]: mask from one or more vector / mask layers. Each [LayerMaskLayerConfig] references an existing
 *   layer id or a known weather [com.xweather.mapsgl.weather.LayerCode] for auto-created masks.
 * - [type]: shorthand for built-in water/land masking; [LayerMaskType.LAND] uses the water mask layer with
 *   inverted semantics (land visible where water stencil is clear).
 * - [mode]: [StencilMaskCombineMode.ALL] (intersection) vs [StencilMaskCombineMode.ANY] (union), mirroring JS `mask.mode`.
 * - [invert]: optional; when `null`, resolution uses `true` for land-type shorthand and `false` otherwise
 *   (see implementation in `MapController`).
 *
 * **Limits**: resolution keeps at most [StencilLayerMaskSpec.MAX_STENCIL_MASK_LAYERS] distinct mask layers; extras are dropped
 * with a log line.
 *
 * At least one of [layers] or [type] must be non-null / non-empty (enforced in `init`).
 *
 * @property layers Ordered list of mask sources (existing layers or auto-created weather masks).
 * @property type Optional built-in water or land mask in addition to (or instead of) [layers].
 * @property mode How multiple mask slots combine in the stencil buffer.
 * @property invert When non-null, passed through to [StencilLayerMaskSpec]; when null, defaults depend on [type].
 *
 * @see StencilLayerMaskSpec
 * @see StencilMaskCombineMode
 * @see com.xweather.mapsgl.map.MapController.addWeatherLayer
 */
data class LayerMaskSpec(
    val layers: List<LayerMaskLayerConfig> = emptyList(),
    val type: LayerMaskType? = null,
    val mode: StencilMaskCombineMode = StencilMaskCombineMode.ALL,
    val invert: Boolean? = null,
) {
    init {
        require(layers.isNotEmpty() || type != null) {
            "layerMask requires non-empty [layers] and/or [type]"
        }
    }
}

/**
 * GLES stencil mask built from one triangle mesh per referenced vector layer, combined per [mode].
 * Up to [MAX_STENCIL_MASK_LAYERS] entries are supported (one stencil bit per slot in the non-sequential
 * combine path; typical GLES stencil buffers expose 8 bits — see [MAX_STENCIL_MASK_LAYERS]).
 *
 * Alternatively (or additionally), [clipBounds] fills a stencil slot from an axis-aligned lat/lon rectangle
 * intersected with each tile — no vector tiles required (e.g. mask to the continental US).
 */
data class StencilLayerMaskSpec(
    val layers: List<StencilMaskLayerRef> = emptyList(),
    val mode: StencilMaskCombineMode = StencilMaskCombineMode.ALL,
    val invert: Boolean = false,
    val clipBounds: LatLonBounds? = null,
) {
    init {
        require(layers.isNotEmpty() || clipBounds != null) {
            "stencilLayerMask requires non-empty [layers] and/or [clipBounds]"
        }
        require(layers.size <= MAX_STENCIL_MASK_LAYERS) {
            "stencilLayerMask supports at most $MAX_STENCIL_MASK_LAYERS layers (got ${layers.size})"
        }
    }

    companion object {
        /**
         * Maximum vector mask layers in one spec. Matches a typical 8-bit stencil buffer’s one-hot
         * bit budget for [com.xweather.mapsgl.map.mapbox.GlStencilMaskRenderer.drawCustomMaskSlotIntoStencil]
         * (`1 shl index`). The sequential-ALL path can combine more geometric passes without bit packing,
         * but this cap keeps the bitmask combine path well-defined. If [clipBounds] is used together with
         * vector masks in the non-sequential path, leave headroom (clip consumes one additional bit).
         */
        const val MAX_STENCIL_MASK_LAYERS = 8

        /** Approximate contiguous United States (WGS84), for demos without boundary vector tiles. */
        val US_CONTIGUOUS_BOUNDS = LatLonBounds(
            westExtent = -124.833,
            southExtent = 24.396,
            eastExtent = -66.949,
            northExtent = 49.384,
        )
    }
}

/**
 * Subscribe to layer paint/data events (`on` / `off` / `trigger`). Layer descriptors implement
 * this so host code can listen for `PAINT_CHANGE` and similar.
 */
interface LayerEventEmitter {
    fun on(eventName: String, callback: (Any?) -> Unit)
    fun off(eventName: String)
    fun trigger(eventName: String, data: Any? = null)
}

/** Default [LayerEventEmitter] used by layer descriptor data classes. */
class LayerEventManager : LayerEventEmitter {
    private val listeners = mutableMapOf<String, MutableList<(Any?) -> Unit>>()

    override fun on(eventName: String, callback: (Any?) -> Unit) {
        listeners.getOrPut(eventName) { mutableListOf() }.add(callback)
    }

    override fun off(eventName: String) {
        listeners.remove(eventName)
    }

    override fun trigger(eventName: String, data: Any?) {
        listeners[eventName]?.forEach { it(data) }
    }
}

/**
 * Declarative layer configuration passed to [com.xweather.mapsgl.map.MapController.addLayer].
 *
 * @param P Paint type for this layer ([RasterLayerPaint], [FillLayerPaint], …).
 * @property id Stable layer id (Mapbox style layer id and MapsGL registry key).
 * @property type Discriminator matching [LayerType].
 * @property source Id of a registered source ([SourceDescriptor.id]).
 * @property paint Type-specific paint/layout.
 */
interface LayerDescriptor<P : LayerPaint> : LayerEventEmitter {
    var id: String
    val type: LayerType
    var source: String
    var paint: P//LayerPaint

    /**
     * Lowest map zoom at which this layer draws, or null for no lower bound.
     *
     * A layer inside its zoom range becomes visible only if it has not been explicitly hidden, so a
     * range never overrides a deliberate [com.xweather.mapsgl.layers.tile.MapLayer.visible] of false.
     * Feature queries honour the same bounds, so a layer that is not drawn is not picked either.
     *
     * Distinct from the *source* bounds of the same name: those limit which tiles are fetched, this
     * limits where the layer is shown.
     *
     * **Not active in 1.8.0:** this option is recorded but ignored. Layers draw at every zoom, and
     * every encoded layer preloads its low-quality world tile whatever this is set to.
     */
    var minZoom: Float?

    /**
     * Highest map zoom at which this layer draws, or null for no upper bound. See [minZoom].
     *
     * **Not active in 1.8.0:** this option is recorded but ignored. Layers draw at every zoom, and
     * every encoded layer preloads its low-quality world tile whatever this is set to.
     */
    var maxZoom: Float?

    /**
     * Whether to preload low-resolution tiles when the layer is added or its time range changes, so
     * panning or zooming past the loaded tile bounds falls back to coarse data instead of blank map.
     *
     * Defaults to `false`: the preload is a whole-world request per drawn interval, so it is opt-in
     * rather than a cost every layer pays. Tile layers only; other layer types ignore it.
     *
     * **Not active in 1.8.0:** this option is recorded but ignored. Layers draw at every zoom, and
     * every encoded layer preloads its low-quality world tile whatever this is set to.
     */
    var preloadLowQuality: Boolean
}

/**
 * Bitmap-style layer (raster, sample, contour, particle, grid): encoded/image tiles plus optional
 * built-in [mask] and [timing].
 */
interface BitmapLayerDescriptor<P : LayerPaint> : LayerDescriptor<P> {
    var quality: DataQuality
    var mask: MaskLayerKind

    /**
     * When [mask] is [MaskLayerKind.COUNTRY], ISO 3166-1 alpha-2 (e.g. `"US"`, `"ES"`). Ignored for other mask kinds.
     */
    var maskCountryIso3166Alpha2: String?

    /**
     * Optional per-layer timing (Apple `timing`). When non-null, [com.xweather.mapsgl.map.MapController.addLayer]
     * copies these fields onto the created [com.xweather.mapsgl.layers.tile.TileLayer.timing].
     * Null keeps the layer's existing defaults.
     */
    var timing: LayerTiming?
}

/**
 * Marker for layer descriptors that map to Mapbox **vector** style layers (fill, line, circle, symbol, heatmap).
 * Implementations add [sourceLayer] (MVT layer name, or `null` for GeoJSON) and an optional feature [filter].
 *
 * The type parameter `P` is the paint type serialized via [VectorLayerPaint.asStyleJSON] when the layer is added.
 *
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see com.xweather.mapsgl.layers.tile.VectorTileLayer
 */
interface VectorLayerDescriptor<P : LayerPaint> : LayerDescriptor<P> {
    var sourceLayer: String?
    var filter: Expression?

    /**
     * When true, MapsGL does not register a Mapbox `fill` / `line` / `circle` / `symbol` / `heatmap` style layer.
     * The [com.xweather.mapsgl.layers.tile.VectorTileLayer] still exists for tile/GeoJSON consumers, MVT fetch
     * (e.g. `com.xweather.mapsgl.map.mapbox.GlStencilCustomMaskCoordinator`), and GLES stencil mesh build in
     * [com.xweather.mapsgl.renderers.TileLayerRenderer] — only screen drawing via Mapbox paint is skipped.
     */
    var stencilOnly: Boolean

    /**
     * When true, eligible fill/line/circle/symbol layers draw via MapsGL GLES instead of Mapbox
     * style layers. MVT sources use [com.xweather.mapsgl.renderers.VectorFillLayerRenderer] /
     * [com.xweather.mapsgl.renderers.VectorLineLayerRenderer] / etc. GeoJSON fill, line, circle,
     * symbol, and heatmap layers also support GLES when this flag is set.
     */
    var useGlRendering: Boolean

    /**
     * Optional per-layer timing (Apple `timing`). When non-null, [com.xweather.mapsgl.map.MapController.addLayer]
     * copies these fields onto the created [com.xweather.mapsgl.layers.tile.TileLayer.timing].
     * Null keeps the layer's existing defaults (time-series sources may still enable interval mode).
     */
    var timing: LayerTiming?

    /**
     * JS-style mask shorthand (`mask: { layerIds: [...] }`). Resolved to [stencilLayerMask] when
     * [stencilLayerMask] is unset. Apple's `maskConfiguration` maps here / to [stencilLayerMask].
     */
    var layerMask: LayerMaskSpec?

    /** List of mask layer ids (JS `mask.layerIds`). Lower precedence than [layerMask]. */
    var maskLayerIds: List<String>

    /** Single mask layer id shorthand. Lowest precedence among mask fields. */
    var maskLayerId: String?

    /**
     * Advanced custom stencil mask. Takes precedence over [layerMask] / [maskLayerIds] / [maskLayerId].
     */
    var stencilLayerMask: StencilLayerMaskSpec?
}

/**
 * Raster/image tile layer. Add with [com.xweather.mapsgl.map.MapController.addLayer] after
 * registering an [com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor].
 */
data class RasterLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: RasterLayerPaint = RasterLayerPaint(
        raster = RasterPaint()
    ),
    /**
     * JS-style convenience for custom stencil masks:
     * `mask: { layerIds: ["admin-mask"] }`
     *
     * When non-empty, [com.xweather.mapsgl.map.MapController.addLayer] maps these ids to a
     * [StencilLayerMaskSpec] under GLES stencil mode.
     */
    var maskLayerIds: List<String> = emptyList(),
    /**
     * Single mask layer id shorthand (JS `mask: "layerId"` on a layer). Lowest precedence among
     * stencil mask fields: after [stencilLayerMask], [layerMask], and [maskLayerIds].
     */
    var maskLayerId: String? = null,
    /** JS-style mask convenience; takes precedence over [maskLayerIds] and [maskLayerId] when provided. */
    var layerMask: LayerMaskSpec? = null,
    /**
     * Advanced custom stencil mask configuration. Takes precedence over [maskLayerIds] when set.
     */
    var stencilLayerMask: StencilLayerMaskSpec? = null,
    override var timing: LayerTiming? = null,
) : BitmapLayerDescriptor<RasterLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false


    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        quality: DataQuality = DataQuality.exact,
        paint: RasterLayerPaint = RasterLayerPaint(raster = RasterPaint()),
    ) : this(id, source, quality, paint, emptyList(), null, null, null, null)

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        quality: DataQuality = this.quality,
        paint: RasterLayerPaint = this.paint,
    ): RasterLayerDescriptor = RasterLayerDescriptor(
        id = id,
        source = source,
        quality = quality,
        paint = paint,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
        timing = this.timing,
    )

    override var mask: MaskLayerKind = MaskLayerKind.NONE
    override var maskCountryIso3166Alpha2: String? = null
    override val type: LayerType = LayerType.raster
}

/**
 * Encoded sample (color field) layer. Pair with an
 * [com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor].
 */
data class SampleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.high,
    override var paint: SampleLayerPaint = SampleLayerPaint(
        sample = SamplePaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE,
    /**
     * JS-style convenience for custom stencil masks:
     * `mask: { layerIds: ["admin-mask"] }`
     *
     * When non-empty, [com.xweather.mapsgl.map.MapController.addLayer] maps these ids to a
     * [StencilLayerMaskSpec] under GLES stencil mode.
     */
    var maskLayerIds: List<String> = emptyList(),
    /**
     * Single mask layer id shorthand (JS `mask: "layerId"` on a layer). Lowest precedence among
     * stencil mask fields: after [stencilLayerMask], [layerMask], and [maskLayerIds].
     */
    var maskLayerId: String? = null,
    /** JS-style mask convenience; takes precedence over [maskLayerIds] and [maskLayerId] when provided. */
    var layerMask: LayerMaskSpec? = null,
    /**
     * Advanced custom stencil mask configuration. Takes precedence over [maskLayerIds] when set.
     * Prefer this (or [layerMask]) over built-in [mask] for GLES stencil clipping from arbitrary vector layers.
     */
    var stencilLayerMask: StencilLayerMaskSpec? = null,
    override var maskCountryIso3166Alpha2: String? = null,
    override var timing: LayerTiming? = null,
) : BitmapLayerDescriptor<SampleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false


    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        quality: DataQuality = DataQuality.high,
        paint: SampleLayerPaint = SampleLayerPaint(sample = SamplePaint()),
        mask: MaskLayerKind = MaskLayerKind.NONE,
    ) : this(id, source, quality, paint, mask, emptyList(), null, null, null, null, null)

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        quality: DataQuality = this.quality,
        paint: SampleLayerPaint = this.paint,
        mask: MaskLayerKind = this.mask,
    ): SampleLayerDescriptor = SampleLayerDescriptor(
        id = id,
        source = source,
        quality = quality,
        paint = paint,
        mask = mask,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
        maskCountryIso3166Alpha2 = this.maskCountryIso3166Alpha2,
        timing = this.timing,
    )

    override val type: LayerType = LayerType.sample

    init {
        // This connects the paint's setter to this descriptor's event bus
        paint.sample.eventEmitter = this

        //println(">>> LayerDescriptor: SampleLayerDescriptor init linked to Emitter!")
    }
}

/**
 * Isoline layer on an encoded sample field.
 */
data class ContourLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.low,
    override var paint: ContourLayerPaint = ContourLayerPaint(
        sample = SamplePaint(),
        contour = ContourPaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE,
    /**
     * JS-style convenience for custom stencil masks:
     * `mask: { layerIds: ["admin-mask"] }`
     *
     * When non-empty, [com.xweather.mapsgl.map.MapController.addLayer] maps these ids to a
     * [StencilLayerMaskSpec] under GLES stencil mode.
     */
    var maskLayerIds: List<String> = emptyList(),
    /**
     * Single mask layer id shorthand (JS `mask: "layerId"` on a layer). Lowest precedence among
     * stencil mask fields: after [stencilLayerMask], [layerMask], and [maskLayerIds].
     */
    var maskLayerId: String? = null,
    /** JS-style mask convenience; takes precedence over [maskLayerIds] and [maskLayerId] when provided. */
    var layerMask: LayerMaskSpec? = null,
    /**
     * Advanced custom stencil mask configuration. Takes precedence over [maskLayerIds] when set.
     */
    var stencilLayerMask: StencilLayerMaskSpec? = null,
    override var maskCountryIso3166Alpha2: String? = null,
    override var timing: LayerTiming? = null,
) : BitmapLayerDescriptor<ContourLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false


    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        quality: DataQuality = DataQuality.low,
        paint: ContourLayerPaint = ContourLayerPaint(sample = SamplePaint(), contour = ContourPaint()),
        mask: MaskLayerKind = MaskLayerKind.NONE,
    ) : this(id, source, quality, paint, mask, emptyList(), null, null, null, null, null)

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        quality: DataQuality = this.quality,
        paint: ContourLayerPaint = this.paint,
        mask: MaskLayerKind = this.mask,
    ): ContourLayerDescriptor = ContourLayerDescriptor(
        id = id,
        source = source,
        quality = quality,
        paint = paint,
        mask = mask,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
        maskCountryIso3166Alpha2 = this.maskCountryIso3166Alpha2,
        timing = this.timing,
    )

    override val type: LayerType = LayerType.sample

    init {
        paint.sample.eventEmitter = this
    }
}

/**
 * Particle field over an encoded vector sample. Pair with an
 * [com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor].
 */
data class ParticleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: ParticleLayerPaint = ParticleLayerPaint(
        sample = SamplePaint(),
        particle = ParticlePaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE,
    /**
     * JS-style convenience for custom stencil masks:
     * `mask: { layerIds: ["admin-mask"] }`
     *
     * When non-empty, [com.xweather.mapsgl.map.MapController.addLayer] maps these ids to a
     * [StencilLayerMaskSpec] under GLES stencil mode.
     */
    var maskLayerIds: List<String> = emptyList(),
    /**
     * Single mask layer id shorthand (JS `mask: "layerId"` on a layer). Lowest precedence among
     * stencil mask fields: after [stencilLayerMask], [layerMask], and [maskLayerIds].
     */
    var maskLayerId: String? = null,
    /** JS-style mask convenience; takes precedence over [maskLayerIds] and [maskLayerId] when provided. */
    var layerMask: LayerMaskSpec? = null,
    /**
     * Advanced custom stencil mask configuration. Takes precedence over [maskLayerIds] when set.
     */
    var stencilLayerMask: StencilLayerMaskSpec? = null,
    override var maskCountryIso3166Alpha2: String? = null,
    override var timing: LayerTiming? = null,
) : BitmapLayerDescriptor<ParticleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false


    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        quality: DataQuality = DataQuality.exact,
        paint: ParticleLayerPaint = ParticleLayerPaint(sample = SamplePaint(), particle = ParticlePaint()),
        mask: MaskLayerKind = MaskLayerKind.NONE,
    ) : this(id, source, quality, paint, mask, emptyList(), null, null, null, null, null)

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        quality: DataQuality = this.quality,
        paint: ParticleLayerPaint = this.paint,
        mask: MaskLayerKind = this.mask,
    ): ParticleLayerDescriptor = ParticleLayerDescriptor(
        id = id,
        source = source,
        quality = quality,
        paint = paint,
        mask = mask,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
        maskCountryIso3166Alpha2 = this.maskCountryIso3166Alpha2,
        timing = this.timing,
    )

    override val type: LayerType = LayerType.particles
}

/**
 * Descriptor for a Mapbox **fill** layer: polygon features filled with optional outline, backed by a vector or
 * GeoJSON source.
 *
 * Add the source with [com.xweather.mapsgl.map.MapController.addSource], then register this descriptor via
 * [com.xweather.mapsgl.map.MapController.addLayer]. Renders as a [VectorTileLayer] using Mapbox’s native fill layer.
 *
 * For **vector tiles**, set [sourceLayer] to the MVT layer containing polygons. For **GeoJSON**, use `null` on
 * [sourceLayer] so the whole collection is used. [filter] restricts which features participate.
 *
 * @property id Unique layer id within the controller.
 * @property source Id of an existing vector or GeoJSON source.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON-only sources.
 * @property paint Fill color and opacity. Outline is drawn on a companion Mapbox `line` layer
 * (`{layerId}::stroke`); width comes from [com.xweather.mapsgl.style.FillLayerPaint.scaleOutlineThickness].
 * @property filter Optional Mapbox filter expression.
 *
 * @see com.xweather.mapsgl.style.FillLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class FillLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: FillLayerPaint = FillLayerPaint(
        fill = FillPaint(),
        stroke = StrokePaint()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
    override var useGlRendering: Boolean = true,
    override var timing: LayerTiming? = null,
    override var maskLayerIds: List<String> = emptyList(),
    override var maskLayerId: String? = null,
    override var layerMask: LayerMaskSpec? = null,
    override var stencilLayerMask: StencilLayerMaskSpec? = null,
) : VectorLayerDescriptor<FillLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false

    override val type: LayerType = LayerType.fill

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        sourceLayer: String? = null,
        paint: FillLayerPaint = FillLayerPaint(fill = FillPaint(), stroke = StrokePaint()),
        filter: Expression? = null,
    ) : this(id, source, sourceLayer, paint, filter, false, true, null, emptyList(), null, null, null)

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        sourceLayer: String? = this.sourceLayer,
        paint: FillLayerPaint = this.paint,
        filter: Expression? = this.filter,
    ): FillLayerDescriptor = FillLayerDescriptor(
        id = id,
        source = source,
        sourceLayer = sourceLayer,
        paint = paint,
        filter = filter,
        stencilOnly = this.stencilOnly,
        useGlRendering = this.useGlRendering,
        timing = this.timing,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
    )
}

/**
 * Descriptor for a Mapbox **line** layer: line strings (and polygon rings when applicable) stroked from a vector
 * or GeoJSON source.
 *
 * **Setup** matches other [VectorLayerDescriptor] types: add the source with
 * [com.xweather.mapsgl.map.MapController.addSource], then register this descriptor with
 * [com.xweather.mapsgl.map.MapController.addLayer]. The runtime implementation is a
 * [com.xweather.mapsgl.layers.tile.VectorTileLayer] backed by Mapbox’s native `line` style layer.
 *
 * **Sources**
 * - **Vector tiles**: set [sourceLayer] to the MVT layer name that contains line geometry.
 * - **GeoJSON**: set [sourceLayer] to `null` when the whole feature collection should be used.
 *
 * **Paint** ([paint]) is a [com.xweather.mapsgl.style.LineLayerPaint] wrapping [com.xweather.mapsgl.style.StrokePaint];
 * it maps to Mapbox `line-color`, `line-opacity`, `line-width`, `line-join`, `line-cap`, and `line-miter-limit`.
 * Join, cap, and miter limit are also honored when this layer is used as a **GLES stencil mask** source (road ribbons,
 * custom mask pipelines).
 *
 * **Stencil-only lines**: when [stencilOnly] is `true`, MapsGL still fetches tiles and builds stencil geometry from
 * this layer’s features, but does **not** add a visible Mapbox `line` layer. Use that for mask-only line sources
 * (for example motorways referenced from [LayerMaskSpec] on a weather layer), analogous to JS layers that exist
 * primarily for `mask.layers`.
 *
 * Example (visible road line, then reference its id from a weather layer’s [LayerMaskSpec]):
 * ```
 * controller.addSource(VectorSourceDescriptor(id = "roads", url = roadTileUrlTemplate))
 * controller.addLayer(
 *     LineLayerDescriptor(
 *         id = "road-motorway",
 *         source = "roads",
 *         sourceLayer = "transportation",
 *         paint = LineLayerPaint(stroke = StrokePaint().apply {
 *             thickness = StyleValue.Constant(5.0)
 *             lineJoin = StyleValue.Constant(LineJoin.MITER)
 *             lineCap = StyleValue.Constant(LineCap.ROUND)
 *         }),
 *         filter = Expression.equals(Expression.get("class"), "motorway"),
 *     ),
 *     beforeID = null,
 * )
 *
 * // Then mask a weather layer against it. The mask is declared on the weather layer's
 * // configuration, not as an addWeatherLayer parameter:
 * val temperature = WeatherService.Temperatures(controller.service)
 * temperature.layer.layerMask = LayerMaskSpec(
 *     layers = listOf(LayerMaskLayerConfig(id = "road-motorway")),
 * )
 * controller.addWeatherLayer(temperature)
 * ```
 *
 * @property id Unique layer id within the map controller (referenced by [LayerMaskSpec] / [StencilLayerMaskSpec]
 *   when used as a mask).
 * @property source Id of an already-added vector or GeoJSON source.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON-only usage.
 * @property paint Line stroke styling serialized to Mapbox `line-*` paint properties.
 * @property filter Optional Mapbox filter expression; narrows which features draw and which contribute to masks.
 * @property stencilOnly When `true`, skip registering a visible Mapbox line layer; still drive stencil mesh build.
 *   See [VectorLayerDescriptor.stencilOnly].
 *
 * @see com.xweather.mapsgl.style.LineLayerPaint
 * @see com.xweather.mapsgl.style.StrokePaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see LayerMaskSpec
 */
data class LineLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: LineLayerPaint = LineLayerPaint(
        stroke = StrokePaint()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
    override var useGlRendering: Boolean = true,
    override var timing: LayerTiming? = null,
    override var maskLayerIds: List<String> = emptyList(),
    override var maskLayerId: String? = null,
    override var layerMask: LayerMaskSpec? = null,
    override var stencilLayerMask: StencilLayerMaskSpec? = null,
) : VectorLayerDescriptor<LineLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false

    override val type: LayerType = LayerType.line

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        sourceLayer: String? = null,
        paint: LineLayerPaint = LineLayerPaint(stroke = StrokePaint()),
        filter: Expression? = null,
    ) : this(id, source, sourceLayer, paint, filter, false, true, null, emptyList(), null, null, null)

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        sourceLayer: String? = this.sourceLayer,
        paint: LineLayerPaint = this.paint,
        filter: Expression? = this.filter,
    ): LineLayerDescriptor = LineLayerDescriptor(
        id = id,
        source = source,
        sourceLayer = sourceLayer,
        paint = paint,
        filter = filter,
        stencilOnly = this.stencilOnly,
        useGlRendering = this.useGlRendering,
        timing = this.timing,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
    )
}

/**
 * Descriptor for a Mapbox **circle** layer: points rendered as filled disks with optional stroke, driven by a
 * vector or GeoJSON source.
 *
 * Register the backing source first ([com.xweather.mapsgl.map.MapController.addSource]), then add this layer with
 * [com.xweather.mapsgl.map.MapController.addLayer]. The layer is implemented as a [VectorTileLayer] over Mapbox’s
 * native circle layer.
 *
 * **Sources**
 * - **Vector tile** source ([com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor]): set [sourceLayer]
 *   to the MVT layer name. [filter] may narrow features.
 * - **GeoJSON** source ([com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor]): set [sourceLayer] to
 *   `null`; the whole [com.mapbox.geojson.FeatureCollection] is used (see product examples such as earthquakes).
 *
 * **Paint** is held in [paint] ([CircleLayerPaint]): fill color, stroke, and circle radius map to Mapbox
 * `circle-color`, `circle-radius`, `circle-stroke-*`, etc. Use [com.xweather.mapsgl.style.StyleValue] and
 * [Expression] for data-driven styling (e.g. magnitude-based radius).
 *
 * **Stacking**: the `beforeID` argument to [com.xweather.mapsgl.map.MapController.addLayer] controls insertion order
 * relative to existing style layers (see that method’s KDoc).
 *
 * @property id Stable layer identifier; must be unique within the map controller.
 * @property source Identifier of an already-added source whose features this layer draws.
 * @property sourceLayer For vector tiles, the source layer name inside the MVT; for GeoJSON-only sources, use `null`.
 * @property paint Circle fill, stroke, and geometry styling converted to Mapbox style JSON.
 * @property filter Optional Mapbox filter expression; combined with source-layer filtering when [sourceLayer] is set.
 *
 * @see com.xweather.mapsgl.style.CircleLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see com.xweather.mapsgl.layers.tile.VectorTileLayer
 */
data class CircleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: CircleLayerPaint = CircleLayerPaint(
        fill = FillPaint(),
        stroke = StrokePaint(),
        circle = CirclePaint()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
    override var useGlRendering: Boolean = true,
    override var timing: LayerTiming? = null,
    override var maskLayerIds: List<String> = emptyList(),
    override var maskLayerId: String? = null,
    override var layerMask: LayerMaskSpec? = null,
    override var stencilLayerMask: StencilLayerMaskSpec? = null,
) : VectorLayerDescriptor<CircleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false

    override val type: LayerType = LayerType.circle

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        sourceLayer: String? = null,
        paint: CircleLayerPaint = CircleLayerPaint(
            fill = FillPaint(),
            stroke = StrokePaint(),
            circle = CirclePaint(),
        ),
        filter: Expression? = null,
    ) : this(id, source, sourceLayer, paint, filter, false, true, null, emptyList(), null, null, null)

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        sourceLayer: String? = this.sourceLayer,
        paint: CircleLayerPaint = this.paint,
        filter: Expression? = this.filter,
    ): CircleLayerDescriptor = CircleLayerDescriptor(
        id = id,
        source = source,
        sourceLayer = sourceLayer,
        paint = paint,
        filter = filter,
        stencilOnly = this.stencilOnly,
        useGlRendering = this.useGlRendering,
        timing = this.timing,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
    )
}

/**
 * Descriptor for a Mapbox **symbol** layer using [SymbolLayerPaint]: icons, text labels, and optional fill/stroke.
 *
 * Use after the backing source is registered ([com.xweather.mapsgl.map.MapController.addSource]). Typical sources are
 * **vector tiles** with a named [sourceLayer]; **GeoJSON** point/line data can use `null` on [sourceLayer] when the
 * style does not target a specific MVT layer.
 *
 * For **gridded** encoded products (spacing, [SamplePaint], etc.), use [GridLayerDescriptor] with [GridLayerPaint]
 * instead—this type stays Mapbox-style-only so `paint` is not confused with grid sidecar fields.
 *
 * @property id Unique layer id.
 * @property source Vector or GeoJSON source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON when applicable.
 * @property paint Icon, text, and optional fill/stroke configuration.
 * @property filter Optional Mapbox filter.
 *
 * @see com.xweather.mapsgl.style.SymbolLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class SymbolLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: SymbolLayerPaint = SymbolLayerPaint(
        icon = IconPaint(),
        text = emptyList()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
    override var useGlRendering: Boolean = true,
    override var timing: LayerTiming? = null,
    override var maskLayerIds: List<String> = emptyList(),
    override var maskLayerId: String? = null,
    override var layerMask: LayerMaskSpec? = null,
    override var stencilLayerMask: StencilLayerMaskSpec? = null,
) : VectorLayerDescriptor<SymbolLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false

    override val type: LayerType = LayerType.symbol

    /**
     * Builds a symbol descriptor from a [GridLayerPaint], the paint type this descriptor took
     * through 1.6.0 before [SymbolLayerPaint] split the symbol-only fields out of it.
     *
     * Kept so `SymbolLayerDescriptor(id, source, sourceLayer, GridLayerPaint(...), filter)` still
     * compiles. The shared fields carry over as they are; [GridLayerPaint.grid] and
     * [GridLayerPaint.sample] have no symbol equivalent and are dropped, which is what the layer
     * did with them anyway — a Mapbox symbol layer never sampled an encoded field.
     *
     * Reading `paint` back returns a [SymbolLayerPaint]; that return type is the one part of this
     * change no shim can hide. Prefer passing a [SymbolLayerPaint] directly in new code.
     */
    constructor(
        id: String,
        source: String,
        sourceLayer: String? = null,
        paint: GridLayerPaint,
        filter: Expression? = null,
    ) : this(
        id = id,
        source = source,
        sourceLayer = sourceLayer,
        paint = paint.toSymbolLayerPaint(),
        filter = filter,
    )

    /**
     * @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM].
     *
     * Hidden rather than visible like the constructor above: an ordinary overload taking
     * [GridLayerPaint] would make the no-argument `copy()` ambiguous between two candidates that
     * both need every default filled in, and a bare `copy()` is far commoner than one passing a
     * 1.6.0 paint. Source callers that do pass a [GridLayerPaint] should call
     * [GridLayerPaint.toSymbolLayerPaint] themselves.
     */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        sourceLayer: String? = this.sourceLayer,
        paint: GridLayerPaint,
        filter: Expression? = this.filter,
    ): SymbolLayerDescriptor = SymbolLayerDescriptor(
        id = id,
        source = source,
        sourceLayer = sourceLayer,
        paint = paint.toSymbolLayerPaint(),
        filter = filter,
        stencilOnly = this.stencilOnly,
        useGlRendering = this.useGlRendering,
        timing = this.timing,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
    )
}

/**
 * Descriptor for **symbol-style** layers that share [GridLayerPaint] with [SymbolLayerDescriptor] but add **masking**
 * and **data quality** knobs used by gridded and dense icon workflows (e.g. encoded-grid sidecars).
 *
 * Register the source, then [com.xweather.mapsgl.map.MapController.addLayer]. [mask] participates in land/water
 * masking where the map pipeline supports it; [quality] hints requested tile or sampling fidelity for applicable
 * sources. The initializer wires [paint.sample]’s event emitter to this descriptor for paint-driven events.
 *
 * @property id Unique layer id.
 * @property source Backing source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON when applicable.
 * @property mask Land/water/none mask for symbol placement.
 * @property paint Icon, text, optional sample grid, and fill/stroke.
 * @property filter Optional feature filter.
 * @property quality Requested [DataQuality] for tile or asset resolution where used.
 *
 * @see com.xweather.mapsgl.style.GridLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class GridLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    var mask: MaskLayerKind = MaskLayerKind.NONE,
    override var paint: GridLayerPaint = GridLayerPaint(
        icon = IconPaint(),
        text = emptyList()
    ),
    override var filter: Expression? = null,
    var quality: DataQuality = DataQuality.medium,
    /**
     * JS-style convenience for custom stencil masks:
     * `mask: { layerIds: ["admin-mask"] }`
     *
     * When non-empty, [com.xweather.mapsgl.map.MapController.addLayer] maps these ids to a
     * [StencilLayerMaskSpec] under GLES stencil mode.
     */
    override var maskLayerIds: List<String> = emptyList(),
    /**
     * Single mask layer id shorthand (JS `mask: "layerId"` on a layer). Lowest precedence among
     * stencil mask fields: after [stencilLayerMask], [layerMask], and [maskLayerIds].
     */
    override var maskLayerId: String? = null,
    /** JS-style mask convenience; takes precedence over [maskLayerIds] and [maskLayerId] when provided. */
    override var layerMask: LayerMaskSpec? = null,
    /**
     * Advanced custom stencil mask configuration. Takes precedence over [maskLayerIds] when set.
     */
    override var stencilLayerMask: StencilLayerMaskSpec? = null,
    /** See [BitmapLayerDescriptor.maskCountryIso3166Alpha2] when [mask] is [MaskLayerKind.COUNTRY]. */
    var maskCountryIso3166Alpha2: String? = null,
    override var stencilOnly: Boolean = false,
    override var useGlRendering: Boolean = false,
    override var timing: LayerTiming? = null,
) : VectorLayerDescriptor<GridLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false

    override val type: LayerType = LayerType.symbol

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        sourceLayer: String? = null,
        mask: MaskLayerKind = MaskLayerKind.NONE,
        paint: GridLayerPaint = GridLayerPaint(icon = IconPaint(), text = emptyList()),
        filter: Expression? = null,
        quality: DataQuality = DataQuality.medium,
    ) : this(
        id, source, sourceLayer, mask, paint, filter, quality,
        emptyList(), null, null, null, null, false, false, null,
    )

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        sourceLayer: String? = this.sourceLayer,
        mask: MaskLayerKind = this.mask,
        paint: GridLayerPaint = this.paint,
        filter: Expression? = this.filter,
        quality: DataQuality = this.quality,
    ): GridLayerDescriptor = GridLayerDescriptor(
        id = id,
        source = source,
        sourceLayer = sourceLayer,
        mask = mask,
        paint = paint,
        filter = filter,
        quality = quality,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
        maskCountryIso3166Alpha2 = this.maskCountryIso3166Alpha2,
        stencilOnly = this.stencilOnly,
        useGlRendering = this.useGlRendering,
        timing = this.timing,
    )

    init {
        paint.sample?.eventEmitter = this
    }
}

/**
 * Descriptor for a Mapbox **heatmap** layer: point density visualized as a color ramp, backed by vector or GeoJSON
 * point data.
 *
 * Add the source first, then [com.xweather.mapsgl.map.MapController.addLayer]. [paint] ([HeatmapLayerPaint]) maps
 * to Mapbox `heatmap-color`, `heatmap-weight`, `heatmap-intensity`, `heatmap-radius`, and `heatmap-opacity`.
 *
 * Use [sourceLayer] for MVT point layers; `null` for GeoJSON when the source is a single feature collection of points.
 *
 * @property id Unique layer id.
 * @property source Point-capable vector or GeoJSON source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON.
 * @property paint Heatmap ramp, radius, intensity, and weight.
 * @property filter Optional feature filter.
 *
 * @see com.xweather.mapsgl.style.HeatmapLayerPaint
 * @see com.xweather.mapsgl.style.HeatmapPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class HeatmapLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: HeatmapLayerPaint = HeatmapLayerPaint(
        heatmap = HeatmapPaint()
    ),
    override var filter: Expression? = null,
    override var stencilOnly: Boolean = false,
    override var useGlRendering: Boolean = true,
    override var timing: LayerTiming? = null,
    override var maskLayerIds: List<String> = emptyList(),
    override var maskLayerId: String? = null,
    override var layerMask: LayerMaskSpec? = null,
    override var stencilLayerMask: StencilLayerMaskSpec? = null,
) : VectorLayerDescriptor<HeatmapLayerPaint>, LayerEventEmitter by LayerEventManager() {
    // In the class body rather than the constructor: these are published data classes in a minified
    // artifact, and a new constructor parameter would change the generated constructor, its default
    // bridge and the `copy` signatures — a `NoSuchMethodError` for an app linking an older AAR.

    /**
     * Lowest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.minZoom].
     */
    override var minZoom: Float? = null

    /**
     * Highest map zoom at which this layer draws. Not active in 1.8.0; see [LayerDescriptor.maxZoom].
     */
    override var maxZoom: Float? = null

    /**
     * Whether to preload low-resolution fallback tiles. Not active in 1.8.0; see
     * [LayerDescriptor.preloadLowQuality].
     */
    override var preloadLowQuality: Boolean = false

    override val type: LayerType = LayerType.heatmap

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    constructor(
        id: String,
        source: String,
        sourceLayer: String? = null,
        paint: HeatmapLayerPaint = HeatmapLayerPaint(heatmap = HeatmapPaint()),
        filter: Expression? = null,
    ) : this(id, source, sourceLayer, paint, filter, false, true, null, emptyList(), null, null, null)

    /** @suppress Binary-compatibility shim for the 1.6.0 parameter list; see [BINARY_COMPAT_SHIM]. */
    @Deprecated(BINARY_COMPAT_SHIM, level = DeprecationLevel.HIDDEN)
    fun copy(
        id: String = this.id,
        source: String = this.source,
        sourceLayer: String? = this.sourceLayer,
        paint: HeatmapLayerPaint = this.paint,
        filter: Expression? = this.filter,
    ): HeatmapLayerDescriptor = HeatmapLayerDescriptor(
        id = id,
        source = source,
        sourceLayer = sourceLayer,
        paint = paint,
        filter = filter,
        stencilOnly = this.stencilOnly,
        useGlRendering = this.useGlRendering,
        timing = this.timing,
        maskLayerIds = this.maskLayerIds,
        maskLayerId = this.maskLayerId,
        layerMask = this.layerMask,
        stencilLayerMask = this.stencilLayerMask,
    )
}