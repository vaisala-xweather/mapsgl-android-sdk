package com.xweather.mapsgl.layers.spec

import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.CirclePaint
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.ContourPaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.FillPaint
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.HeatmapLayerPaint
import com.xweather.mapsgl.style.HeatmapPaint
import com.xweather.mapsgl.style.IconPaint
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.ParticlePaint
import com.xweather.mapsgl.style.RasterLayerPaint
import com.xweather.mapsgl.style.RasterPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint
import com.xweather.mapsgl.style.StrokePaint
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.LayerType

enum class MaskLayerKind {
    NONE,
    LAND,
    WATER
}

interface LayerEventEmitter {
    fun on(eventName: String, callback: (Any?) -> Unit)
    fun off(eventName: String)
    fun trigger(eventName: String, data: Any? = null)
}

class LayerEventManager : LayerEventEmitter {
    private val listeners = mutableMapOf<String, MutableList<(Any?) -> Unit>>()

    override fun on(eventName: String, callback: (Any?) -> Unit) {
        listeners.getOrPut(eventName) { mutableListOf() }.add(callback)
    }

    override fun off(eventName: String) {
        listeners.remove(eventName)
    }

    override fun trigger(eventName: String, data: Any?) {
        listeners[eventName]?.forEach { it(data) }
    }
}

interface LayerDescriptor<P : LayerPaint> : LayerEventEmitter {
    var id: String
    val type: LayerType
    var source: String
    var paint: P//LayerPaint
}

interface BitmapLayerDescriptor<P : LayerPaint> : LayerDescriptor<P> {
    var quality: DataQuality
    var mask: MaskLayerKind
}

/**
 * Marker for layer descriptors that map to Mapbox **vector** style layers (fill, line, circle, symbol, heatmap).
 * Implementations add [sourceLayer] (MVT layer name, or `null` for GeoJSON) and an optional feature [filter].
 *
 * The type parameter `P` is the paint type serialized via [VectorLayerPaint.asStyleJSON] when the layer is added.
 *
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see com.xweather.mapsgl.layers.tile.VectorTileLayer
 */
interface VectorLayerDescriptor<P : LayerPaint> : LayerDescriptor<P> {
    var sourceLayer: String?
    var filter: Expression?
}

data class RasterLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: RasterLayerPaint = RasterLayerPaint(
        raster = RasterPaint()
    )
) : BitmapLayerDescriptor<RasterLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override var mask: MaskLayerKind = MaskLayerKind.NONE
    override val type: LayerType = LayerType.raster
}

data class SampleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: SampleLayerPaint = SampleLayerPaint(
        sample = SamplePaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE
) : BitmapLayerDescriptor<SampleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.sample

    init {
        // This connects the paint's setter to this descriptor's event bus
        paint.sample.eventEmitter = this

        //println(">>> LayerDescriptor: SampleLayerDescriptor init linked to Emitter!")
    }
}

data class ContourLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: ContourLayerPaint = ContourLayerPaint(
        sample = SamplePaint(),
        contour = ContourPaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE
) : BitmapLayerDescriptor<ContourLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.sample

    init {
        paint.sample.eventEmitter = this
    }
}

data class ParticleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var quality: DataQuality = DataQuality.exact,
    override var paint: ParticleLayerPaint = ParticleLayerPaint(
        sample = SamplePaint(),
        particle = ParticlePaint()
    ),
    override var mask: MaskLayerKind = MaskLayerKind.NONE
) : BitmapLayerDescriptor<ParticleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.particles
}

/**
 * Descriptor for a Mapbox **fill** layer: polygon features filled with optional outline, backed by a vector or
 * GeoJSON source.
 *
 * Add the source with [com.xweather.mapsgl.map.MapController.addSource], then register this descriptor via
 * [com.xweather.mapsgl.map.MapController.addLayer]. Renders as a [VectorTileLayer] using Mapbox’s native fill layer.
 *
 * For **vector tiles**, set [sourceLayer] to the MVT layer containing polygons. For **GeoJSON**, use `null` on
 * [sourceLayer] so the whole collection is used. [filter] restricts which features participate.
 *
 * @property id Unique layer id within the controller.
 * @property source Id of an existing vector or GeoJSON source.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON-only sources.
 * @property paint Fill color, opacity, and outline stroke mapped to Mapbox `fill-*` properties.
 * @property filter Optional Mapbox filter expression.
 *
 * @see com.xweather.mapsgl.style.FillLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class FillLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: FillLayerPaint = FillLayerPaint(
        fill = FillPaint(),
        stroke = StrokePaint()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<FillLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.fill
}

/**
 * Descriptor for a Mapbox **line** layer: line strings and polygon rings stroked from vector or GeoJSON geometry.
 *
 * Workflow matches other [VectorLayerDescriptor] types: [com.xweather.mapsgl.map.MapController.addSource] then
 * [com.xweather.mapsgl.map.MapController.addLayer]. Implemented as a [VectorTileLayer] over Mapbox’s line layer.
 *
 * Set [sourceLayer] for MVT sources; use `null` for GeoJSON. [paint] controls color, width, opacity, and join/cap
 * via [LineLayerPaint] → Mapbox `line-*` paint properties.
 *
 * @property id Unique layer id.
 * @property source Existing source id (vector or GeoJSON).
 * @property sourceLayer MVT layer name, or `null` for GeoJSON.
 * @property paint Line stroke styling.
 * @property filter Optional feature filter.
 *
 * @see com.xweather.mapsgl.style.LineLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class LineLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: LineLayerPaint = LineLayerPaint(
        stroke = StrokePaint()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<LineLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.line
}

/**
 * Descriptor for a Mapbox **circle** layer: points rendered as filled disks with optional stroke, driven by a
 * vector or GeoJSON source.
 *
 * Register the backing source first ([com.xweather.mapsgl.map.MapController.addSource]), then add this layer with
 * [com.xweather.mapsgl.map.MapController.addLayer]. The layer is implemented as a [VectorTileLayer] over Mapbox’s
 * native circle layer.
 *
 * **Sources**
 * - **Vector tile** source ([com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor]): set [sourceLayer]
 *   to the MVT layer name. [filter] may narrow features.
 * - **GeoJSON** source ([com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor]): set [sourceLayer] to
 *   `null`; the whole [com.mapbox.geojson.FeatureCollection] is used (see product examples such as earthquakes).
 *
 * **Paint** is held in [paint] ([CircleLayerPaint]): fill color, stroke, and circle radius map to Mapbox
 * `circle-color`, `circle-radius`, `circle-stroke-*`, etc. Use [com.xweather.mapsgl.style.StyleValue] and
 * [Expression] for data-driven styling (e.g. magnitude-based radius).
 *
 * **Stacking**: the `beforeID` argument to [com.xweather.mapsgl.map.MapController.addLayer] controls insertion order
 * relative to existing style layers (see that method’s KDoc).
 *
 * @property id Stable layer identifier; must be unique within the map controller.
 * @property source Identifier of an already-added source whose features this layer draws.
 * @property sourceLayer For vector tiles, the source layer name inside the MVT; for GeoJSON-only sources, use `null`.
 * @property paint Circle fill, stroke, and geometry styling converted to Mapbox style JSON.
 * @property filter Optional Mapbox filter expression; combined with source-layer filtering when [sourceLayer] is set.
 *
 * @see com.xweather.mapsgl.style.CircleLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 * @see com.xweather.mapsgl.layers.tile.VectorTileLayer
 */
data class CircleLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: CircleLayerPaint = CircleLayerPaint(
        fill = FillPaint(),
        stroke = StrokePaint(),
        circle = CirclePaint()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<CircleLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.circle
}

/**
 * Descriptor for a Mapbox **symbol** layer built from [GridLayerPaint]: icons, text labels, and optional fill/stroke
 * driven by the same paint model used for gridded symbol products.
 *
 * Use after the backing source is registered ([com.xweather.mapsgl.map.MapController.addSource]). Typical sources are
 * **vector tiles** with a named [sourceLayer]; **GeoJSON** point/line data can use `null` on [sourceLayer] when the
 * style does not target a specific MVT layer.
 *
 * [paint] combines [IconPaint], optional [FillPaint]/[StrokePaint] for halos or data-driven RGB fields, and a list of
 * [com.xweather.mapsgl.style.TextPaint] entries for labels. [filter] limits features.
 *
 * @property id Unique layer id.
 * @property source Vector or GeoJSON source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON when applicable.
 * @property paint Icon, text, and optional fill/stroke configuration.
 * @property filter Optional Mapbox filter.
 *
 * @see com.xweather.mapsgl.style.GridLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class SymbolLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: GridLayerPaint = GridLayerPaint(
        icon = IconPaint(),
        text = emptyList()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<GridLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.symbol
}

/**
 * Descriptor for **symbol-style** layers that share [GridLayerPaint] with [SymbolLayerDescriptor] but add **masking**
 * and **data quality** knobs used by gridded and dense icon workflows (e.g. encoded-grid sidecars).
 *
 * Register the source, then [com.xweather.mapsgl.map.MapController.addLayer]. [mask] participates in land/water
 * masking where the map pipeline supports it; [quality] hints requested tile or sampling fidelity for applicable
 * sources. The initializer wires [paint.sample]’s event emitter to this descriptor for paint-driven events.
 *
 * @property id Unique layer id.
 * @property source Backing source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON when applicable.
 * @property mask Land/water/none mask for symbol placement.
 * @property paint Icon, text, optional sample grid, and fill/stroke.
 * @property filter Optional feature filter.
 * @property quality Requested [DataQuality] for tile or asset resolution where used.
 *
 * @see com.xweather.mapsgl.style.GridLayerPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class GridLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    var mask: MaskLayerKind = MaskLayerKind.NONE,
    override var paint: GridLayerPaint = GridLayerPaint(
        icon = IconPaint(),
        text = emptyList()
    ),
    override var filter: Expression? = null,
    var quality: DataQuality = DataQuality.medium,
) : VectorLayerDescriptor<GridLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.symbol

    init {
        paint.sample?.eventEmitter = this
    }
}

/**
 * Descriptor for a Mapbox **heatmap** layer: point density visualized as a color ramp, backed by vector or GeoJSON
 * point data.
 *
 * Add the source first, then [com.xweather.mapsgl.map.MapController.addLayer]. [paint] ([HeatmapLayerPaint]) maps
 * to Mapbox `heatmap-color`, `heatmap-weight`, `heatmap-intensity`, `heatmap-radius`, and `heatmap-opacity`.
 *
 * Use [sourceLayer] for MVT point layers; `null` for GeoJSON when the source is a single feature collection of points.
 *
 * @property id Unique layer id.
 * @property source Point-capable vector or GeoJSON source id.
 * @property sourceLayer MVT layer name, or `null` for GeoJSON.
 * @property paint Heatmap ramp, radius, intensity, and weight.
 * @property filter Optional feature filter.
 *
 * @see com.xweather.mapsgl.style.HeatmapLayerPaint
 * @see com.xweather.mapsgl.style.HeatmapPaint
 * @see com.xweather.mapsgl.map.MapController.addLayer
 */
data class HeatmapLayerDescriptor(
    override var id: String,
    override var source: String,
    override var sourceLayer: String? = null,
    override var paint: HeatmapLayerPaint = HeatmapLayerPaint(
        heatmap = HeatmapPaint()
    ),
    override var filter: Expression? = null
) : VectorLayerDescriptor<HeatmapLayerPaint>, LayerEventEmitter by LayerEventManager() {
    override val type: LayerType = LayerType.heatmap
}