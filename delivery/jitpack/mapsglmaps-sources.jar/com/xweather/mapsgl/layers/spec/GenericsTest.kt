package com.xweather.mapsgl.layers.spec

import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.ParticlePaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.style.SamplePaint


// Generic LayerWrapper (equivalent class for 'config.layer')
    class GenericLayerWrapper<P : LayerPaint>(val paint: P)

    // Generic WeatherLayerConfiguration
    open class GenericWeatherLayerConfiguration<P : LayerPaint>(val layer: GenericLayerWrapper<P>) {



        val paint: P
            get() = layer.paint

        fun getSpecificPaint(): P {
            return layer.paint
        }
    }

    class TemperaturesConfiguration(
        layer: GenericLayerWrapper<SampleLayerPaint> // uses SampleLayerPaint
    ) : GenericWeatherLayerConfiguration<SampleLayerPaint>(layer)

    class WindParticlesConfiguration(
        layer: GenericLayerWrapper<ParticleLayerPaint> // uses ParticleLayerPaint
    ) : GenericWeatherLayerConfiguration<ParticleLayerPaint>(layer)


    object WeatherService2 {
        fun Temperatures2(service: Any /* service type */): TemperaturesConfiguration {
            val samplePaint = SamplePaint(/*...*/)
            val specificLayerWrapper = GenericLayerWrapper(SampleLayerPaint(1f, samplePaint))
            return TemperaturesConfiguration(specificLayerWrapper)
        }

        fun WindParticles2(service: Any /* your service type */): WindParticlesConfiguration {
            val samplePaint = SamplePaint(/*...*/)
            val particlePaint = ParticlePaint(/*...*/)
            val specificLayerWrapper = GenericLayerWrapper(ParticleLayerPaint(1f, samplePaint, particlePaint))
            return WindParticlesConfiguration(specificLayerWrapper)
        }


    }


