package com.xweather.mapsgl.anim

import java.util.Calendar
import java.util.Date
import java.util.Locale

import kotlin.math.roundToLong

/** @suppress **/
enum class TimeUnit(val singular: String, val plural: String, val calendarField: Int) {
    YEAR("year", "years", Calendar.YEAR),
    MONTH("month", "months", Calendar.MONTH),
    WEEK("week", "weeks", Calendar.WEEK_OF_YEAR),
    DAY("day", "days", Calendar.DAY_OF_YEAR),
    HOUR("hour", "hours", Calendar.HOUR_OF_DAY),
    MINUTE("minute", "minutes", Calendar.MINUTE),
    SECOND("second", "seconds", Calendar.SECOND);

    companion object {
        fun fromString(s: String): TimeUnit? {
            val lowerS = s.lowercase(Locale.ENGLISH)
            return entries.find { it.singular == lowerS || it.plural == lowerS }
        }
    }
}

/** @suppress **/
class TimeConverter {

    companion object {
        // Average days for approximations
        private const val AVG_DAYS_IN_MONTH = 30.4375
        private const val AVG_DAYS_IN_YEAR = 365.25

        private fun getMillisFactorForPreciseTimeUnit(timeUnit: TimeUnit): Long {
            return when (timeUnit) {
                TimeUnit.SECOND -> 1000L
                TimeUnit.MINUTE -> 60 * 1000L
                TimeUnit.HOUR -> 60 * 60 * 1000L
                TimeUnit.DAY -> 24 * 60 * 60 * 1000L
                TimeUnit.WEEK -> 7 * 24 * 60 * 60 * 1000L
                else -> 0L // YEAR/MONTH handled differently for date calculations
            }
        }


        fun stringToDate(
            timeOffsetString: String,
            referenceDate: Date = Date()
        ): Date? {
            val trimmedString = timeOffsetString.trim().lowercase(Locale.ENGLISH)

            if (trimmedString == "now") {
                return Date(referenceDate.time)
            }

            val regex = """(-?(?:\d*\.\d+|\d+))\s*([a-z]+)""".toRegex()
            val matchResult = regex.matchEntire(trimmedString)

            if (matchResult != null && matchResult.groups.size >= 3) {
                try {
                    var amountStr = matchResult.groups[1]?.value ?: return null
                    val unitStr = matchResult.groups[2]?.value ?: return null

                    if (amountStr.startsWith(".")) amountStr = "0$amountStr"
                    else if (amountStr.startsWith("-.")) amountStr = "-0${amountStr.substring(1)}"

                    val totalAmount = amountStr.toDouble()
                    val timeUnit = TimeUnit.fromString(unitStr) ?: return null

                    val calendar = Calendar.getInstance()
                    calendar.time = referenceDate

                    val integerPartOfAmount = totalAmount.toInt() // Whole units
                    val fractionalPartOfAmount = totalAmount - integerPartOfAmount // Fractional part

                    // Apply the integer part using Calendar.add for calendar-aware adjustments
                    if (integerPartOfAmount != 0) {
                        calendar.add(timeUnit.calendarField, integerPartOfAmount)
                    }

                    // Handle the fractional part
                    if (fractionalPartOfAmount != 0.0) {
                        var fractionalMillis: Long = 0
                        when (timeUnit) {
                            TimeUnit.YEAR -> {
                                // Convert fractional year to days (approx), then to millis
                                fractionalMillis = (fractionalPartOfAmount * AVG_DAYS_IN_YEAR * getMillisFactorForPreciseTimeUnit(TimeUnit.DAY)).roundToLong()
                                System.err.println("Warning: Applying fractional ${timeUnit.name} ('$fractionalPartOfAmount') as approx ${fractionalMillis / getMillisFactorForPreciseTimeUnit(TimeUnit.DAY)} days.")
                            }
                            TimeUnit.MONTH -> {
                                // Convert fractional month to days (approx), then to millis
                                fractionalMillis = (fractionalPartOfAmount * AVG_DAYS_IN_MONTH * getMillisFactorForPreciseTimeUnit(TimeUnit.DAY)).roundToLong()
                                System.err.println("Warning: Applying fractional ${timeUnit.name} ('$fractionalPartOfAmount') as approx ${fractionalMillis / getMillisFactorForPreciseTimeUnit(TimeUnit.DAY)} days.")
                            }
                            TimeUnit.WEEK -> {
                                fractionalMillis = (fractionalPartOfAmount * getMillisFactorForPreciseTimeUnit(TimeUnit.WEEK)).roundToLong()
                            }
                            TimeUnit.DAY -> {
                                fractionalMillis = (fractionalPartOfAmount * getMillisFactorForPreciseTimeUnit(TimeUnit.DAY)).roundToLong()
                            }
                            TimeUnit.HOUR, TimeUnit.MINUTE, TimeUnit.SECOND -> {
                                fractionalMillis = (fractionalPartOfAmount * getMillisFactorForPreciseTimeUnit(timeUnit)).roundToLong()
                            }
                        }
                        if (fractionalMillis != 0L) {
                            calendar.timeInMillis += fractionalMillis
                        }
                    }
                    return calendar.time
                } catch (e: NumberFormatException) {
                    System.err.println("Error parsing amount for stringToDate: '$timeOffsetString'. ${e.message}")
                    return null
                } catch (e: Exception) {
                    System.err.println("Error processing for stringToDate: '$timeOffsetString' - ${e.message}")
                    return null
                }
            }
            System.err.println("Invalid format for stringToDate: '$timeOffsetString'")
            return null
        }


        fun stringToMillis(timeOffsetString: String): Long? {
            val trimmedString = timeOffsetString.trim().lowercase(Locale.ENGLISH)
            if (trimmedString == "now") {
                System.err.println("\"now\" is not a duration. Returning null for stringToMillis.")
                return null
            }
            val regex = """(-?(?:\d*\.\d+|\d+))\s*([a-z]+)""".toRegex()
            val matchResult = regex.matchEntire(trimmedString)
            if (matchResult != null && matchResult.groups.size >= 3) {
                try {
                    var amountStr = matchResult.groups[1]?.value ?: return null
                    val unitStr = matchResult.groups[2]?.value ?: return null
                    if (amountStr.startsWith(".")) amountStr = "0$amountStr"
                    else if (amountStr.startsWith("-.")) amountStr = "-0${amountStr.substring(1)}"
                    val amount = amountStr.toDouble()
                    val timeUnit = TimeUnit.fromString(unitStr) ?: return null

                    return when (timeUnit) {
                        TimeUnit.SECOND -> (amount * 1000).roundToLong()
                        TimeUnit.MINUTE -> (amount * 60 * 1000).roundToLong()
                        TimeUnit.HOUR -> (amount * 60 * 60 * 1000).roundToLong()
                        TimeUnit.DAY -> (amount * 24 * 60 * 60 * 1000).roundToLong()
                        TimeUnit.WEEK -> (amount * 7 * 24 * 60 * 60 * 1000).roundToLong()
                        TimeUnit.MONTH -> (amount * AVG_DAYS_IN_MONTH * 24 * 60 * 60 * 1000).roundToLong()
                        TimeUnit.YEAR -> (amount * AVG_DAYS_IN_YEAR * 24 * 60 * 60 * 1000).roundToLong()
                    }
                } catch (e: Exception) { /* ... handle parsing errors ... */ return null }
            }
            /* ... handle invalid format ... */ return null
        }
    }
}