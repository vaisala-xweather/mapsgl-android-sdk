package com.xweather.mapsgl.anim

import com.xweather.mapsgl.anim.Timeline.Companion.currentPhaseA
import com.xweather.mapsgl.anim.Timeline.Companion.currentPhaseB
import com.xweather.mapsgl.anim.Timeline.Companion.generateHourlyIntervals
import com.xweather.mapsgl.anim.Timeline.Companion.intervalLength
import com.xweather.mapsgl.anim.Timeline.Companion.timeStrings
import com.xweather.mapsgl.anim.Timeline.Companion.totalPhase
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.TimeClampMode
import com.xweather.mapsgl.utils.relativeTimeToDate
import java.util.Date

/** @suppress **/
open class TimeAnimationInfo(
    open val isActive: Boolean,
    open val currentDate: Date,
    open val startDate: Date?,
    open val endDate: Date?,
    open val deltaTime: Long
)


/** @suppress **/
open class TimeAnimationOptions : AnimationOptionsInternal() {

    /** The start date of the animation.  */
    var start: DateOrString = DateOrString()

    /** The end date of the animation.  */
    var end: DateOrString = DateOrString()

    internal open lateinit var mode: TimeClampMode

    /** Whether the animation should always stop at the start date.  */
    var alwaysStopAtStart: Boolean = false
}

/** @suppress **/
open class DateOrString {
    data class DateValue(val date: Date) : DateOrString()
    data class StringValue(val string: String) : DateOrString()
}

/**
 * An animation that is based on time and is bound by a start and end date.
 * @suppress
 */

open class TimeAnimation : Animation {

    // Helper type to represent Partial<TimeAnimationOptions>
    data class PartialTimeAnimationOptions(
        val start: Any? = null, // Could be Date or String
        val end: Any? = null,   // Could be Date or String
        val alwaysStopAtStart: Boolean? = null,
        val animationOpts: AnimationOptions // Assuming this exists from previous conversions
    )

    internal val maxIntervals = 9200 // year is 8760 hours
    internal var storedDate: Date = Date()

    constructor(opts: AnimationOptions, start: Any = Date(), end: Any = Date()) : super(opts) {
        if (pr.ON) pr.p("TimeAnimation", pr.animationEvent, "constructor 1")

        this.start = start as Date
        this.end = end as Date

        this.duration = opts.duration
        this.delay = opts.delay
        this.endDelay = opts.endDelay
        this.enabled = opts.enabled


        //endDate = if (options.end is String) relativeTimeToDate(Date(), options.end) else options.end as Date
        now = Date()

        this.on(AnimationEvent.range_change) {
            if (pr.ON) pr.p("TimeAnimation", pr.timeMove, "this.on RangeChange 1")

            //this.stop()
            if (this.state == AnimationState.stopped) {
                //if (pr.ON) pr.p("TimeAnimation", pr.timeMove, "this.on RangeChange 1, advanceToStopPostion()")
                //this.advanceToStopPosition()
            }
        }
    }

    constructor(options: PartialTimeAnimationOptions) : super(options.animationOpts) {
        if (pr.ON) pr.p("TimeAnimation", pr.animationEvent, "constructor 2")
        alwaysStopAtStart = options.alwaysStopAtStart ?: false

        start = if (options.start is String) relativeTimeToDate(Date(), options.start) else options.start as Date
        end = if (options.end is String) relativeTimeToDate(Date(), options.end) else options.end as Date
        now = Date()


        this.on(AnimationEvent.range_change) {
            if (pr.ON) pr.p("TimeAnimation", pr.timeMove, "this.on RangeChange 2")
            this.stop()
            if (this.state == AnimationState.stopped) {
                this.advanceToStopPosition()
            }
        }
    }


    /** Start date of the timeline's time range. */
    var start: Date = Date(Date().time - (3600 * 24 * 1000))
        set(value) {
            if (pr.ON) pr.p("TimeAnimation", pr.pastInterval, "want to set start to ${value}")
            storedDate = currentDate

            if (value.time < end.time) {
                if (value.time < field.time) {
                    //todo: rethink this logic
                    val intervalHours = (intervalLength.toFloat() / 3600f)

                    val numHours = (((field.time - value.time)).toFloat() / (3600 * 1000)).toInt()
                    val numIntervals = numHours / intervalHours.toInt()
                    if (numIntervals + currentPhaseA <= maxIntervals) {
                        //println("TimeAnimation start()  currentPhaseA was: $currentPhaseA")
                        //println("TimeAnimation start()  intervalHours: $intervalHours")
                        //println("TimeAnimation start()  adding numHours: $numHours")
                        currentPhaseA += (numIntervals)
                        currentPhaseB += numIntervals
                        //println("TimeAnimation start()  currentPhaseA AFTER: $currentPhaseA")

                        if (currentPhaseA >= timeStrings.size) {
                            currentPhaseA = timeStrings.size - 1
                        }
                        if (currentPhaseB >= timeStrings.size) {
                            currentPhaseB = timeStrings.size - 1
                        }

                    } else {
                        end = Date(value.time + (3600L * 1000L * maxIntervals))
                    }
                    if (pr.ON) pr.p("TimeAnimation", pr.flicker2, " start: setting meld to 0")
                    Timeline.dataMeld = 0f
                    //Timeline.updateAllMelds()
                }
                field = value
                if (pr.ON) pr.p("TimeAnimation", pr.pastInterval, "setting startDate, triggering Range_Change")
                if (pr.ON) pr.p("TimeAnimation", pr.pastInterval, "setting startDate, B: ${Timeline.currentPhaseB}")
                this.triggerDates(AnimationEvent.range_change, mapOf("start" to this.start, "end" to this.end))
            } else {
                end = Date(value.time + (3600 * 1000 * 24))
                currentPhaseA = 0
                currentPhaseB = 0
                if (pr.ON) pr.p("TimeAnimation", pr.flicker2, " start 2: setting meld to 0")
                Timeline.dataMeld = 0f
                //Timeline.updateAllMelds()
                field = value
            }

            //println(">> TimeAnimation start set currentphaseA to ${currentPhaseA}")
        }

    /** End date of the timeline's time range. */
    var end: Date = Date()
        set(value) {
            storedDate = currentDate
            if (pr.ON) pr.p("TimeAnimation", pr.pastInterval, "want to set end to ${value}")
            if (value.time > start.time) {
                field = value
                if (pr.ON) pr.p("TimeAnimation", pr.flicker2, "end setting meld to 0")
                Timeline.dataMeld = 0f
                //Timeline.updateAllMelds()

                this.triggerDates(AnimationEvent.range_change, mapOf("start" to this.start, "end" to this.end))
            }
        }

    var currentDate: Date
        get() {
            if (pr.ON) pr.p("TimeAnimation", pr.timeMove, "currentDate.get()  returning")
            val offset = this.deltaTime * this.position
            if (pr.ON) pr.p(
                "TimeAnimation",
                pr.timeMove,
                "currentDate.get()  returning ${Date((this.start.time + offset.toLong()))}"
            )
            return Date((this.start.time + offset.toLong()))  //offset is 0 to 1?
        }

    internal var alwaysStopAtStart = false

    init {
        currentDate = Date()
    }

    val deltaTime: Long
        get() = this.end.time - this.start.time

    internal val deltaTimeHours: Long
        get() = deltaTime / (60 * 60 * 24 * 1000)


    private var now: Date = Date()
        get() {
            return Date()
        }

    internal val referenceDate: Date
        get() {
            if (this.timeline != null) {
                return this.timeline!!.referenceDate
            }
            return this.now
        }

    val containsPast: Boolean
        get() {
            val delta = this.start.time - this.referenceDate.time
            // add a slight buffer since the two times could be off by a few milliseconds
            return delta < -1000
        }

    val containsFuture: Boolean
        get() {
            val delta = this.end.time - this.referenceDate.time
            // add a slight buffer since the two times could be off by a few milliseconds
            return delta > 1000
        }

    val isPast: Boolean
        get() = !this.containsFuture

    val isFuture: Boolean
        get() = !this.containsPast

    internal open val info: TimeAnimationInfo
        get() = TimeAnimationInfo(this.isActive, this.currentDate, this.start, this.end, this.deltaTime)

    /**
     *Updates the timeline start date by applying the specified time offset to the relative date. If no relative date is provided, then the current time and date will be used.
     * @param  offset: Time offset, in seconds, from the relativeTo.
     * @param  relativeTo: Date from which to apply the offset to. Default value is new Date().
     */
    fun setStartDateUsingOffset(offset: Long, relativeTo: Date = Date()) {
        val tempDate = Date(relativeTo.time + offset)

        if (tempDate.time <= end.time - 3600 * 1000) {
            this.start = tempDate
        } else {
            this.start = Date(end.time - (3600 * 1000))
        }
        //println(">> TimeAnimation calling generateHourlyIntervals() from setStartDateUsingOffset")
        generateHourlyIntervals(start, end)
        massUpdate(Timeline.timeStrings)

        //println(">> TimeAnimation setStartDateUsingOffset() currentPhaseA = ${Timeline.currentPhaseA}")
        stop()
    }

    /**
     * Updates the timeline end date by applying the specified time offset to the relative date. If no relative date is provided, then the current time and date will be used.
     * @param offset: Time offset, in seconds, from the relativeTo.
     * @param relativeTo: Date from which to apply the offset to. Default value is new Date().
     */
    fun setEndDateUsingOffset(offset: Long, relativeTo: Date = Date()) {
        val tempDate = Date(relativeTo.time + offset)

        if (tempDate.time >= start.time + 3600 * 1000) {
            this.end = tempDate
        } else {
            this.end = Date(start.time + (3600 * 1000))
        }
        //println(">> TimeAnimation calling generateHourlyIntervals() from setEndDateUsingOffset")
        generateHourlyIntervals(start, end)
        massUpdate(Timeline.timeStrings)
        stop()
    }


    /**
     * Updates the timeline start date by calculating the date using a relative time string, such as "-2 hours" or "1 day".
     * @param relativeDate: Relative date string from which to calculate the start date. Format should be in the form "{offset} {units}", where offset is a positive or negative number and units is one of the following: seconds, minutes, hours, days, weeks, months or years.
     * @param relativeTo: Date from which to apply the offset to. Default value is new Date().
     */
    fun setStartDateUsingRelativeTime(offset: String, relativeTo: Date = Date()) {
        val newDate = TimeConverter.stringToDate(offset) ?: return
        val relativeMS = relativeTo.time - Date().time
        start = Date(newDate.time + relativeMS)
        //start.time = newDate.time + relativeMS
        //println(">> TimeAnimation calling generateHourlyIntervals() from setStartDateUsingRelativeTime")
        generateHourlyIntervals(start, end)
        massUpdate(Timeline.timeStrings)

    }

    /**
     * Updates the timeline end date by calculating the date using a relative time string, such as "-2 hours" or "1 day".
     * @param relativeDate: Relative date string from which to calculate the end date. Format should be in the form "{offset} {units}", where offset is a positive or negative number and units is one of the following: seconds, minutes, hours, days, weeks, months or years.
     * @param relativeTo: Date from which to apply the offset to. Default value is new Date().
     */
    fun setEndDateUsingRelativeTime(offset: String, relativeTo: Date = Date()) {
        val newDate = TimeConverter.stringToDate(offset) ?: return
        val relativeMS = relativeTo.time - Date().time
        end.time = newDate.time + relativeMS
        //println(">> TimeAnimation calling generateHourlyIntervals() from setEndDateUsingRelativeTime")
        generateHourlyIntervals(start, end)
        massUpdate(Timeline.timeStrings)
        if (pr.ON) pr.p(TAG, pr.interleave, "setEndDateUsingRelativeTime() returning $end")
    }

    /**
     * Advances the playhead to the specified date where date is within the time range between the timeline's startDate and endDate values.
     * @param date: The date between the start and end times to move the playhead to.
     * */
    open fun goToDate(date: Date) {

        val newDate: Date
        if (date.time < this.start.time) {
            newDate = this.start
        } else if (date.time > this.end.time) {
            newDate = this.end
        } else {
            newDate = date
        }
        val position = (newDate.time - this.start.time).toDouble() / this.deltaTime
        this.goTo(position)
    }

    /**
     * Advances the playhead past the start time by the given number of milliseconds.
     * @param offset: The number of milliseconds to advance the playhead past the start time.
     * */
    fun goToOffset(offset: Long) {
        this.goToDate(Date(this.start.time + offset))
    }

    override fun eventPayload(): Map<String, Any> {
        return mapOf("position" to this.position, "date" to this.currentDate)
    }

    override fun advanceToStopPosition() {
        if (this.timeline != null) return
        if (this.alwaysStopAtStart) {
            this.advance(0.0)
        } else if (this.isPast) {
            this.advance(100.0)
        } else {
            this.advance(0.0)
        }
    }

    internal fun massUpdate(times: MutableList<String>) {
        totalPhase = (times.size - 1)

        if (currentPhaseB > totalPhase) {
            currentPhaseB = totalPhase
            currentPhaseA = currentPhaseB - 1
            //println(">> TimeAnimation massUpdate() A set currentPhaseA to  ${currentPhaseA}")


            if (currentPhaseA < 0) {
                currentPhaseA = 0
            }
            if (currentPhaseB < 1) {
                currentPhaseB = 1
            }
        } else {
            if (currentPhaseA < 0) {
                currentPhaseA = 0
            }
            if (currentPhaseB < 1) {
                currentPhaseB = 1
            }
        }
    }
}