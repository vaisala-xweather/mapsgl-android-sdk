package com.xweather.mapsgl.anim

import com.mapbox.maps.extension.observable.model.Response
import com.xweather.mapsgl.AbortController
import com.xweather.mapsgl.Partial
import com.xweather.mapsgl.Promise
import com.xweather.mapsgl.data.series.TimeInterval
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.TileSource
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.weather.AuthenticatorError
import com.xweather.mapsgl.weather.AuthenticatorException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.coroutines.cancellation.CancellationException


/**
 *  TileRequestManager.kt
 *
 *  Created by Jason Suto on 12/12/23.
 *  Based on the IOS version.
 */

//TODO: AnyAuthenticator(), AbortSignal(), AbortController,

/** @suppress **/
typealias Headers = HashMap<Any, Any>

private val TAG = "TileRequestManager"

/** @suppress **/
const val MAX_RETRIES = 1

/** @suppress **/
typealias TimeSeriesDataState = Map<String, Boolean>

@Suppress("Dokka")
private data class RequestInfo(
    val coord: TileCoord,
    val interval: TimeInterval?
)

// The pending tile requests and their time intervals when applicable.
private var _pendingRequests: MutableMap<RequestInfo, TileResponse> = mutableMapOf()

/**
 * A response from a tile request.
 *
 * @property data The response data (often an image).
 * @property headers The response headers.
 * @suppress
 */

data class TileResponse(var data: Any, val headers: Headers, val isRadar: Boolean = false)
/**
 * @suppress
 * A function that fetches a tile from the given URL and options.
 *
 * @param coord The tile coordinate to load.
 * @param url The tile URL to load.
 * @param options The tile request options.
 * @return A promise that resolves with the response.
 */
typealias TileFetcher = (coord: TileCoord, url: String, options: Partial<TileRequestOptions>) -> Promise<Response>

/**
 * This class is responsible for keeping track of the time series intervals and which time intervals
 * we have data for for each tile. This information is then used to determine which intervals we can actually
 * show during an animation, which should only happen if we have data for all visible tiles for the
 * requested time interval.
 *
 * @template Data The type of data stored in a tile.
 * @suppress
 */
class TileRequestManager<Data>(
    private val source: TileSource<TileData>? = null,
    private var _tileFetcher: TileFetcher? = null
) {
    private val _pending = mutableMapOf<String, MutableSet<Int>>()
    private val _state = mutableMapOf<String, TimeSeriesDataState>()
    private val _requests = mutableMapOf<String, AbortController>()
    private val _retries = mutableMapOf<String, Int>()
    private var credential: String? = null
    private var minutesLeft: Double = -1.0
    val bundleID = MapController.packageName
    //private val client_id_key =  "${source?.account?.id} ${source?.account?.secret}"

    var totalRequests = 0

    val pending: MutableMap<String, MutableSet<Int>>
        get() = _pending

    /**
     * Returns the pending tile requests and their time intervals when applicable.
     */
    val totalPending: Int
        get() = _requests.size

    /**
     * Sets the tile fetcher function to use for loading tiles.
     * The fetcher function should return a Promise that resolves with a Response object.
     *
     * @param tileFetcher
     */
    fun setTileFetcher(tileFetcher: TileFetcher) {
        this._tileFetcher = tileFetcher
    }

    /**
     * Performs a tile request for the given tile coordinate and options.
     *
     * If the tile request fails, it will retry up to MAX_RETRIES times or reject the promise after MAX_RETRIES times.
     *
     * Called from ImageTileSource.requestTile()
     * @param coord The tile coordinate to load; kept for logging / error context.
     * @param request The prepared tile request (URL, method, headers, authenticator).
     * @return The response data and headers, or `null` when the request failed.
     */
// Returns `null` if all the work requested (`coord` + `options.intervals` combination) is already pending, and no new request is needed.
    suspend fun loadTile(
        coord: TileCoord, // Keep coord for potential logging/error context if needed
        request: URLRequest
    ): TileResponse? { // Return nullable TileResponse directly
        // No need for internal coroutineScope or async/await here
        try {
            val response = fetchTile(request) // Directly call the suspending fetch function
            // Optional: Add logging here if needed, using the coord
            // Log.d(TAG, "loadTile completed for ${coord.hash()}")
            return response // Return the result (or null if fetchTile failed)
        } catch (error: Throwable) {
            // Cancellation must propagate — mapping it to null caused single-interval retry storms
            // that raced overlapping multi-interval batches on the same representative tile.
            if (error is CancellationException) throw error

            //print("TileRequestManager response is ${error.message}")
            //print(">>>> TileRequestManager response is ${error.cause}")

            // Log or handle specific errors if necessary
            if (error is IOException && error.message?.contains("AuthenticationError") == true) { // Example check
                // Consider re-throwing a specific exception if needed upstream
                throw AuthenticatorException(AuthenticatorError.InvalidAuthToken)
            } else {
                // Rethrow other errors or return null depending on desired handling
                // Returning null might be sufficient if the caller handles it
                return null // Indicate failure
                // Or rethrow: throw error
            }
        }
    }

    private fun addPendingTask(
        task:/* Task<TileResponse, Error>*/ TileResponse,
        coord: TileCoord,
        intervals: List<TimeInterval>?
    ) {
        // for (interval in intervals) {
        _pendingRequests[RequestInfo(coord, /*interval*/ null)] = task
        // }
    }

    /**
     * Fetches a tile for the given request.
     *
     * @param request The prepared tile request (URL, method, headers, authenticator).
     * @return The response, or `null` when the fetch failed.
     */
    private suspend fun fetchTile(request: URLRequest): TileResponse? = withContext(Dispatchers.IO) {
        var tileResponse: TileResponse? = null
        if (pr.ON) {
            pr.p(TAG, pr.serverReq, request.urlString)
            pr.p(TAG, pr.serverReq, "REQUESTING: ${request.body}")
        }

        val response = request.execute()
        when (response.data) {
            is ByteArray -> {
                tileResponse = TileResponse(response.data, Headers(response.headers))
            }
        }
        return@withContext tileResponse
    }

    /**
     * Tile requests currently outstanding, as `hashShort()` -> (interval -> wall-clock ms marked).
     *
     * [isPending]/[setPending] were designed for this but [setPending] never had a caller, so the
     * de-duplication filter in `TiledTimeSeriesDataProvider.enqueueTileRequestIfNeeded` never
     * suppressed anything. `loadData` runs ~2x/second while a tile download takes seconds to land,
     * so every outstanding interval was re-requested 10-20 times before arriving -- measured at 92%
     * duplicate enqueues on the 2026-08-24 alerts soak.
     *
     * Keyed on [TileCoord.hashShort] deliberately: it omits the time component, so the marking site
     * (which uses the requested coord) and the clearing site (which uses the store coord) cannot
     * disagree about the key for the same spatial tile.
     *
     * Intervals are [Long] epoch millis. The existing [_pending] map keys on [Int], which silently
     * overflows for epoch-ms values -- see the `toInt()` TODO at the call site.
     */
    private val _inFlight = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.ConcurrentHashMap<Long, Long>>()

    /**
     * How long a mark survives without being cleared. A dropped or failed request must only *delay*
     * a retry, never suppress it forever -- an un-cleared mark would otherwise mean a tile that can
     * never reload.
     */
    private val inFlightTtlMs = 20_000L

    /**
     * Whether a request for [interval] on the tile keyed [coordKey] is already outstanding (and not
     * stale). Takes a precomputed key rather than a [TileCoord]: callers test many intervals against
     * one coord, and [TileCoord.hashShort] builds a String every call, so deriving it per interval
     * allocated once per interval on a hot path.
     */
    internal fun isRequestInFlight(coordKey: String, interval: TimeInterval, nowMs: Long): Boolean {
        val marks = _inFlight[coordKey] ?: return false
        val markedAt = marks[interval] ?: return false
        if (nowMs - markedAt > inFlightTtlMs) {
            marks.remove(interval)
            return false
        }
        return true
    }

    /** Marks [intervals] on the tile keyed [coordKey] as outstanding. */
    internal fun markRequestsInFlight(coordKey: String, intervals: List<TimeInterval>, nowMs: Long) {
        if (intervals.isEmpty()) return
        val marks = _inFlight.getOrPut(coordKey) { java.util.concurrent.ConcurrentHashMap() }
        for (interval in intervals) marks[interval] = nowMs
    }

    /** Clears the mark for [interval] on [coord]. Called where the data actually lands. */
    internal fun clearRequestInFlight(coord: TileCoord, interval: TimeInterval) {
        val key = coord.hashShort()
        val marks = _inFlight[key] ?: return
        marks.remove(interval)
        if (marks.isEmpty()) _inFlight.remove(key)
    }

    /** Drops every mark. Called when a provider invalidates and cancels its queues. */
    internal fun clearAllRequestsInFlight() = _inFlight.clear()

    /**
     * Returns whether the given tile coordinate is pending for the given time interval.
     *
     * @param coord The tile coordinate to check.
     * @param interval The time interval to check, or `0` for data sources not time-based.
     * @return `true` if the tile is pending, `false` otherwise.
     */
    fun isPending(coord: TileCoord, interval: Int): Boolean {
        val item = _pending[coord.hash()]
        return item?.contains(interval) ?: false
    }

    /**
     * Sets the pending state for the given tile coordinate and time intervals.
     *
     * @param coord The tile coordinate to set the pending state for.
     * @param intervals The time intervals to set the pending state for.
     * @param pending Whether the tile is pending or not.
     */
    fun setPending(coord: TileCoord, intervals: List<Int>?, pending: Boolean) {
        val item = _pending.getOrPut(coord.hash()) { mutableSetOf() }
        if (intervals != null) {
            if (pending) {
                item.addAll(intervals)
            } else {
                item.removeAll(intervals)
            }
        }
        if (item.isEmpty()) {
            _pending.remove(coord.hash())
        }
    }

    /**
     * Aborts the tile request for the given request hash string.
     * @param hash
     */
    fun abort(hash: String) {
        val request = this._requests[hash];
        request?.abort("Requested Abort")
    }
}