package com.xweather.mapsgl.anim

import android.view.Choreographer
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.xweather.mapsgl.gl.InterpolationResult
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.atomic.AtomicInteger

/**
 * A TimeAnimation that manages and controls one or more individual animations. Using a timeline, you can
 * control the playback of multiple animations at once and keep them in sync.
 * @remarks
 * When an animation is added to a `Timeline`, it will not be added to the global {@link AnimationLoop}. Instead, the
 * `Timeline` will manage the animation's playback and progress. This means that individual animations will not be
 * updated unless the `Timeline` is playing.
 */
class Timeline(override var opts: AnimationOptions, internal val controller: MapController) : TimeAnimation(opts) {

    companion object {
        internal var clearParticles = false
        internal var totalDownloads = 0
        internal var isDownloading = false
        internal var pausedForMovement = false
        internal var pausedForDownload = false

        internal val threadDownload = false
        internal val movedOnTileLoaded = false
        internal var TAG = "TempStaticTimes"
        internal var currentPhaseA = 0
        internal var currentPhaseB = 1
        internal var totalPhase = 1
        internal var dataMeld: Float = 0f // Initial value
            set(value) {
                field = value.coerceIn(0.0f, 1.0f)
            }
        internal var frameRate = 60f
        private var isWaitingForEndDelay = false
        private var isWaitingForDelay = false
        private var timeWaitedForEndDelay = 0.0
        private var timeWaitedForDelay = 0.0

        internal var timeStrings: MutableList<String> = mutableListOf()
        internal var timeLongs: MutableList<Long> = mutableListOf()
        internal var timeDates: MutableList<Date> = mutableListOf()


        internal val validTimesList: HashMap<String, MutableList<String>> = hashMapOf()
        internal var sourceTimeHash: HashMap<String, LayerTimeline> = hashMapOf()
        internal var currentDLCount = 0
        var pendingPercent = 0f

        /**
         * Items incrementally added via [addPendingEncodedDownload] (for [effectiveEncodedDownloadDenominator]).
         */
        private val encodedDownloadScheduledTotal = AtomicInteger(0)

        /**
         * Sum of [TileLayer.preflightEncodedDownloadPairCount] across visible encoded layers for this wave
         * (set before any layer runs so % uses a fixed total when playing with multiple layers).
         */
        private val encodedSessionDownloadTarget = AtomicInteger(0)

        /** Increments in [removePendingEncodedDownload] when an item is actually removed. */
        private val encodedDownloadCompletedTotal = AtomicInteger(0)

        fun setEncodedSessionDownloadTarget(total: Int) {
            encodedSessionDownloadTarget.set(total.coerceAtLeast(0))
        }

        /** False while a session target from preflight is active; [resetEncodedDownloadProgressCounters] clears it. */
        internal fun isEncodedDownloadSessionTargetUnset(): Boolean =
            encodedSessionDownloadTarget.get() == 0

        private fun effectiveEncodedDownloadDenominator(): Int {
            val session = encodedSessionDownloadTarget.get()
            val scheduled = encodedDownloadScheduledTotal.get()
            return maxOf(session, scheduled).coerceAtLeast(1)
        }

        var intervalLength = 3600L

        private val _pendingVectorDownloadsLiveData = MutableLiveData(0) // Initial value 0
        val pendingVectorDownloadsLiveData: LiveData<Int> = _pendingVectorDownloadsLiveData

        /** Used when layerInfo doesn't have valid time strings yet
         *  phase: 0 = A, 1 = B
         *  timeString: Usually from LayerInfo
         * **/
        internal fun getTimeString(phase: Int, timeString: String): String {
            if (phase == 0) {
                return if (timeString.length < 4) timeStrings[currentPhaseA] else timeString
            } else {
                return if (timeString.length < 4) timeStrings[currentPhaseB] else timeString
            }
        }


        /**
         * @param pendingTileListCount entries still in [com.xweather.mapsgl.tiles.TileList.pendingList]
         *        (used only when no encoded downloads have been scheduled this session).
         */
        internal fun calcDLPercent(pendingTileListCount: Int) {
            if (encodedSessionDownloadTarget.get() > 0 || encodedDownloadScheduledTotal.get() > 0) {
                val denom = effectiveEncodedDownloadDenominator()
                val completed = encodedDownloadCompletedTotal.get().coerceAtMost(denom)
                pendingPercent = ((completed.toFloat() / denom.toFloat()) * 100f).coerceIn(0f, 100f)
            } else if (currentDLCount > 0) {
                pendingPercent =
                    (((currentDLCount - pendingTileListCount).toFloat() / currentDLCount.toFloat()) * 100f).coerceIn(
                        0f,
                        100f,
                    )
            } else {
                pendingPercent = 0f
            }
        }

        internal fun resetEncodedDownloadProgressCounters() {
            encodedDownloadScheduledTotal.set(0)
            encodedSessionDownloadTarget.set(0)
            encodedDownloadCompletedTotal.set(0)
        }

        // Function to update the value
        fun updatePendingVectorDownloads(newValue: Int) {
            _pendingVectorDownloadsLiveData.postValue(newValue.coerceAtLeast(0)) // Use postValue if updating from a background thread
            // or _pendingVectorDownloadsLiveData.value = newValue if on the main thread
        }

        fun incrementPendingVectorDownloads() {
            val finalVal = _pendingVectorDownloadsLiveData.value?.plus(1)
            _pendingVectorDownloadsLiveData.postValue(finalVal)
            // or _pendingVectorDownloadsLiveData.value = newValue if on the main thread
        }

        fun decrementPendingVectorDownloads() {
            val firstVal = _pendingVectorDownloadsLiveData.value?.minus(1)
            val finalVal = firstVal?.coerceAtLeast(0)
            _pendingVectorDownloadsLiveData.postValue(finalVal)
            // or _pendingVectorDownloadsLiveData.value = newValue if on the main thread
        }

        fun updateAllMelds() {
            for (item in sourceTimeHash) {
                item.value.calcRenderVarFromDownloadedTimes()
            }
        }


        private val hourLong = 3600000
        private val _pendingEncodedDownloadsLiveData =
            MutableLiveData<HashMap<String, MutableList<String>>>(hashMapOf())

        val pendingEncodedDownloadsLiveData: LiveData<HashMap<String, MutableList<String>>> =
            _pendingEncodedDownloadsLiveData

        fun addPendingEncodedDownload(id: String, item: String) {
            // Use postValue for thread safety, as updates can come from background threads.
            _pendingEncodedDownloadsLiveData.postValue( // <-- Corrected to use _pendingEncodedDownloadsLiveData
                _pendingEncodedDownloadsLiveData.value?.apply {
                    // 'this' refers to the non-null HashMap here. Use it directly.
                    val list = this.getOrPut(id) { mutableListOf() }
                    // Add the new item if it's not already in the list to avoid duplicates.
                    if (!list.contains(item)) {
                        list.add(item)
                        encodedDownloadScheduledTotal.incrementAndGet()
                        // Keep session denominator >= scheduled when preflight missed work (e.g. late metadata).
                        encodedSessionDownloadTarget.updateAndGet { maxOf(it, encodedDownloadScheduledTotal.get()) }
                    }
                })
        }

        /**
         * Removes a download item from the pending list for a given ID.
         * If the list becomes empty, the ID is removed from the map.
         * @param id The identifier for the group of downloads.
         * @param item The specific item to remove.
         */
        fun removePendingEncodedDownload(id: String, item: String) {
            // Use postValue for thread safety.
            _pendingEncodedDownloadsLiveData.postValue( // <-- Corrected to use _pendingEncodedDownloadsLiveData
                _pendingEncodedDownloadsLiveData.value?.apply {
                    // 'this' refers to the non-null HashMap.
                    // Check if the list for the given ID exists.
                    this[id]?.let { list ->
                        if (list.remove(item)) {
                            encodedDownloadCompletedTotal.incrementAndGet()
                        }
                        // If the list is now empty, remove the ID from the map to keep it clean.
                        if (list.isEmpty()) {
                            this.remove(id)
                        }
                    }
                })
        }

        fun countPendingEncodedAll(): Int {
            val map = _pendingEncodedDownloadsLiveData.value ?: return 0
            return map.values.sumOf { it.size }
        }

        internal fun generateHourlyIntervals(startDate: Date, endDate: Date): MutableList<String> {
            //println("Timeline - generateHourlyIntervals() start: $startDate  end: $endDate")

            val intervalList = mutableListOf<String>()
            val longIntervalList = mutableListOf<Long>()
            val dateIntervalList = mutableListOf<Date>()
            var currentInstant = startDate.toInstant().truncatedTo(ChronoUnit.HOURS)
            val endInstant = endDate.toInstant().truncatedTo(ChronoUnit.HOURS)
            val totalTimeHours = (endDate.time - startDate.time) / (3600 * 1000)

            if (totalTimeHours < 25) {
                intervalLength = 3600
            } else if (totalTimeHours < 49) {
                intervalLength = 3600 * 2
            } else if (totalTimeHours < 73) {
                intervalLength = 3600 * 3
            } else {
                val timeMult = totalTimeHours.toFloat() / 40f
                intervalLength = (3600.0 * timeMult).toLong()
            }


            // Define the desired timezone (UTC)
            val zoneOffset = ZoneOffset.UTC
            val formatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME.withZone(ZoneId.of(zoneOffset.id))

            while (currentInstant <= endInstant) {
                // Format the Instant to the required String format
                var formattedDate = formatter.format(currentInstant)
                formattedDate = "[\"${formattedDate.substring(0, 14)}00:00Z\"]" //fixed above
                intervalList.add(formattedDate)
                dateIntervalList.add(Date.from(currentInstant))
                longIntervalList.add(currentInstant.epochSecond)
                currentInstant = currentInstant.plusSeconds(intervalLength)
            }

            timeStrings = intervalList
            timeLongs = longIntervalList
            timeDates = dateIntervalList

            //TODO: for each source, get all valid times between start and end.


            if (pr.ON) pr.p(TAG, pr.interleave, "generateHourlyIntervals() times.size: ${timeStrings.size}")

            return timeStrings
        }


        /**
         * Converts a Date object to an ISO 8601 string in UTC.
         * @param date The Date object to format.
         * @return A string formatted as "yyyy-MM-dd'T'HH:mm:ss'Z'".
         */
        fun formatDateToUTCString(date: Date): String {
            // Define the specific date format pattern. The 'Z' at the end formats it as UTC.
            val utcFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            // Set the timezone to UTC to ensure the output is not affected by the device's local timezone.
            utcFormat.timeZone = TimeZone.getTimeZone("UTC")
            return utcFormat.format(date)
        }

        fun datesToStringsAndLongs(sourceId: String) {
            if (pr.ON) pr.p("Timeline", pr.layerTimes, "Timeline, datesToStringsAndLongs() entered")
            val layerTimeline = sourceTimeHash[sourceId]
            if (layerTimeline != null) {
                val stringList = mutableListOf<String>()
                val longList = mutableListOf<Long>()

                // Iterate through the source dates a single time.


                for (date in layerTimeline.timeDates) {
                    // Convert to a formatted string and add to the string list.
                    stringList.add("[\"${formatDateToUTCString(date)}\"]")
                    // Get the epoch time in seconds and add to the long list.
                    longList.add(date.time / 1000)
                }

                // Convert the lists to arrays and assign them to the LayerTimeline properties.
                layerTimeline.timeStrings = stringList
                layerTimeline.timeLongs = longList


                //println(">> Timeline, datesToStringsAndLongs()   .timeDates: ${layerTimeline.timeDates.size} ${layerTimeline.timeDates}")
                //println(">> Timeline, datesToStringsAndLongs() .timeStrings: ${layerTimeline.timeStrings.size} ${layerTimeline.timeStrings}")
                //println(">> Timeline, datesToStringsAndLongs()   .timeLongs: ${layerTimeline.timeLongs.size} ${layerTimeline.timeLongs}")


            }
        }


    } //end companion object

    internal var seekBarMoved = false
    private var realWorldTime: String? = null
    private var _times: MutableList<String>? = null

    internal var times: MutableList<String>
        get() = Timeline.timeStrings
        set(value) {
            //numPhases = times!!.size
            _times = value
            Timeline.timeStrings = value
        }

    private val _animations: MutableList<Animation> = mutableListOf()
    private var playJob: Job? = null

    /**
     * Monotonic clock for [updateDataMeld] so meld advances by **elapsed** time between calls (VSync / load jitter)
     * instead of assuming every call represents exactly `1 / frameRate` seconds. Keeps gridded GPU blends aligned
     * with wall-clock playback like iOS interval-style progress.
     */
    private var lastDataMeldAdvanceMonotonicNanos: Long = 0L

    private var clampMin = 0.0
    private var clampMax = 1.0


    /** Whether the animation should begin playing immediately. */
    var autoPlay = opts.autoPlay

    /** Whether the animation should restart after completing playback. */
    var repeat = opts.repeat

    /** Factor used to scale the time of the animation where a value of 1 is normal speed, 0.5 is half speed, and 2
     * is double speed, etc. Only positive values are allowed.
     */
    var timeScale = 1.0

    init {
        start = opts.start
        end = opts.end
        duration = opts.duration
        delay = opts.delay
        endDelay = opts.endDelay
        autoPlay = opts.autoPlay
        repeat = opts.repeat
        enabled = opts.enabled


        if (pr.ON) pr.p(TAG, pr.pastInterval, "init{}  start:$start, end:$end")
        //println(">> Timeline calling generateHourlyIntervals() from init{}")

        generateHourlyIntervals(start, end)
        massUpdate(Timeline.timeStrings)

        currentPhaseA = 0
        currentPhaseB = 1
    }

    /**
     * Restricts the animation to a specific date range relative to the overall start and end date. This is useful if you want to limit the animation to a subset of the overall time range without changing the overall start and end date values.
     * @param min: The minimum date for the range, which must be between the start and end date.
     * @param max: The maximum date for the range, which must be between the start and end date.
     */
    fun clampDateRange(min: Date, max: Date) {
        clampMin = (min.time - start.time).toDouble() / (end.time - start.time).toDouble()
        clampMax = (max.time - start.time).toDouble() / (end.time - start.time).toDouble()
        clampMin = clamp(clampMin, 0.0, 1.0)
        clampMax = clamp(clampMax, clampMin, 1.0)
    }

    /** @return true if the timeline wrapped and [setProgress] reset playback (no further meld carry). */
    private fun nextPhase(): Boolean {
        currentPhaseA++
        currentPhaseB++
        //println(">> Timeline nextPhase beforeEnd currentPhaseA to ${currentPhaseA}")
        if (currentPhaseB > totalPhase /*|| position > clampMax*/) {
            setProgress(clampMin)
            return true
        }
        //println(">> Timeline nextPhase set currentPhaseA to ${currentPhaseA}")
        return false
    }

    /** Seconds since the last playing [updateDataMeld] call; capped to avoid huge jumps after stalls. */
    private fun consumePlaybackDeltaSeconds(): Double {
        val now = System.nanoTime()
        val prev = lastDataMeldAdvanceMonotonicNanos
        lastDataMeldAdvanceMonotonicNanos = now
        if (prev == 0L) {
            return (1.0 / frameRate.toDouble().coerceAtLeast(1.0)).coerceAtMost(0.25)
        }
        val dt = (now - prev) / 1_000_000_000.0
        return dt.coerceIn(0.0, 0.25)
    }

    internal fun updateDataMeld(isNowPlaying: Boolean) {
        if (!isNowPlaying) {
            lastDataMeldAdvanceMonotonicNanos = 0L
            return
        }
        val deltaSec = consumePlaybackDeltaSeconds()
        if (isWaitingForEndDelay) {
            //pr.p("TEMPSTAT", pr.movePause, "frameTime: $frameTime")
            timeWaitedForEndDelay += deltaSec
            if (timeWaitedForEndDelay > endDelay) {
                timeWaitedForEndDelay = 0.0
                isWaitingForEndDelay = false
                clearParticles = true
                setProgress(clampMin)
            }
        } else if (isWaitingForDelay) {
            timeWaitedForDelay += deltaSec
            if (timeWaitedForDelay > delay) {
                timeWaitedForDelay = 0.0
                isWaitingForDelay = false
                //advance(clampMin)
                //setProgress(clampMin)
            }
        } else if (dataMeld < 1f) {
            val inc = (((totalPhase.toDouble() / duration) * deltaSec * timeScale)).toFloat()
            val next = dataMeld + inc
            if (next >= 1f) {
                if (currentPhaseB == totalPhase) {
                    // Final interval: hold at full meld; repeat/stop handled below (same as legacy increment).
                    dataMeld = 1f
                } else {
                    // Carry fractional progress across the phase step in one tick so we never expose a separate
                    // frame at meld==1.0 and then meld==0.0 (same boundary sampled twice).
                    var overshoot = next - 1f
                    var wrapped = nextPhase()
                    if (!wrapped) {
                        while (overshoot >= 1f) {
                            overshoot -= 1f
                            wrapped = nextPhase()
                            if (wrapped) break
                        }
                        if (!wrapped) {
                            dataMeld = overshoot.coerceIn(0f, 1f)
                        }
                    }
                }
            } else {
                dataMeld = next
            }

            if ((currentPhaseB == totalPhase && dataMeld >= 1f) || position > clampMax) {
                if (repeat) {
                    isWaitingForEndDelay = true
                } else {
                    //setProgress(clampMin)
                    stop()
                }
            }
            clearParticles = false
        } else {
            timeWaitedForEndDelay = 0.0
            if (pr.ON) pr.p("Timeline", pr.flicker2, " updateDataMeld: setting meld to 0")
            dataMeld = 0f
            nextPhase()
            //Timeline.updateAllMelds()
            clearParticles = false
        }
    }

    override var position: Double = 0.0
        get() = getSeekBarPosition() // Getter returns the value of the backing field

    /** The animations managed by the timeline.
     * @readonly
     */
    internal val animations: List<Animation>
        get() = _animations

    init {
        realWorldTime = formatDateToIsoString(Date())
        currentDate = Date()
    }

    /** Listen for the Play Button,  Listener set up in TileLayer.onAdd() */
    private val _playIsPressed = MutableLiveData<Boolean>() // Mutable version (internal)
    internal val playIsPressed: LiveData<Boolean> = _playIsPressed  // Read-only access

    private fun setPlayIsPressed(value: Boolean) {
        if (pr.ON) pr.p("Timeline", pr.playLock, "setPlayIsPressed() ${value}")
        _playIsPressed.postValue(value)
    }

    /** Returns the position the seekbar should be at, from 0.0 to 1.0 **/
    private fun getSeekBarPosition(): Double {

        var tempPosition = 0.0


        if (seekBarMoved || state == AnimationState.playing) {
            tempPosition = ((dataMeld + currentPhaseA) / totalPhase.toDouble())
            checkInterval()
        } else {
            tempPosition = calculateProgressBetweenDates(start, end, storedDate)
            checkInterval()
        }

        return tempPosition.coerceIn(0.0, 1.0)
    }

    internal fun getCurrentTimeStringA(): String {
        if (currentPhaseA > timeStrings.size - 1) {
            currentPhaseA = timeStrings.size - 1
        }
        return timeStrings[currentPhaseA]
    }

    internal fun getCurrentTimeStringB(): String {
        if (currentPhaseB > timeStrings.size - 1) {
            currentPhaseB = timeStrings.size - 1
        }

        if (pr.ON) pr.p(
            TAG,
            pr.pastInterval,
            "getCurrentTimeStringB() A: ${currentPhaseA}    B: ${currentPhaseB}   times.size: ${timeStrings.size}"
        )

        return timeStrings[currentPhaseB]
    }

    /** Updates the map to a point on the timeline from 0.0 to 1.0  **/
    private fun setProgress(progress: Double) {
        if (state != AnimationState.playing) {// moved from mainActivity seekbar listener
            seekBarMoved = true //todo: get rid of this // moved to goTo:
            controller.animatingTimeline = !controller.animatingTimeline
            controller.updateTiles()
        }

        val numPerPhase = (100.0 / totalPhase.toFloat())   // = 50
        val moveIncrement = 1.0 / numPerPhase //= .02

        val progressMult = progress * 100.0

        currentPhaseA = 0
        currentPhaseB = 1
        if (progressMult <= numPerPhase) { //first interval

            dataMeld = (progressMult * moveIncrement).toFloat()
            if (pr.ON) pr.p("Timeline", pr.flicker2, " setProgress(): setting meld variable  $dataMeld")
        } else if (progress == 1.0) {
            currentPhaseA = totalPhase - 1
            currentPhaseB = totalPhase
            dataMeld = 1f
        } else {
            for (i in 0..totalPhase) {
                if (progressMult > (i + 1) * numPerPhase) {
                    if (currentPhaseB < totalPhase) {
                        currentPhaseA++
                        currentPhaseB++
                        //println(">> Timeline setProgress before end... currentPhaseA to ${currentPhaseA}")
                        dataMeld =
                            ((progressMult - ((100.0 / totalPhase.toFloat()) * (i + 1))) * moveIncrement).toFloat()
                        if (dataMeld > 1f) {
                            dataMeld = 1f
                        }
                    }
                }
            }
        }
        //Timeline.updateAllMelds()
        position = progress
        //println(">> Timeline setProgress set currentPhaseA to ${currentPhaseA}")
        triggerAny(AnimationEvent.advance, progress)
    }

    /** Listen for the Downloading */
    //private val _isDownloading = MutableLiveData<Boolean>() // Mutable version (internal)

    internal fun setIsDownloading(value: Boolean) {
        //_isDownloading.postValue(value)// .value = value
        if (value) {
            controller.triggerLoadStart()
        } else {
            controller.triggerLoadComplete()
        }
    }

    // liveState is currently unused but may be used in the future if live tracking of "state" changes is desired.
    private val _liveState = MutableLiveData<AnimationState>() // Mutable version (internal)
    val liveState: LiveData<AnimationState> = _liveState  // Read-only access

    private fun setLiveState(value: AnimationState) {
        _liveState.postValue(value)// .value = value
    }

    override val info: TimelineInfo
        get() = TimelineInfo(
            isActive = this.isActive,
            currentDate = this.currentDate,
            startDate = this.start,
            endDate = this.end,
            deltaTime = this.deltaTime
        )

    /** Adds an animation to the timeline.
     * @param animation - The animation to add.
     */
    internal fun add(animation: Animation?) {
        if (pr.ON) pr.p("TimeLine", pr.timeLine, "add() entered, is animation null? ${animation == null}")
        if (animation == null) return
        animation.timeline = this
        if (animation !in animations) {
            animation.delay = this.delay
            animation.duration = this.duration
            animation.endDelay = this.endDelay

            if (animation is TimeAnimation) {
                animation.start = this.start
                animation.end = this.end
                animation.goTo(this.position)
            }

            opts.manualAdvance = this.config.value.manualAdvance // not sure if necessary
            animation.config.setState(opts)
            _animations.add(animation)

            animation.trigger(AnimationEvent.TIMELINE_CHANGE)

            // If the timeline is active (playing or paused) and manual advance is disabled, immediately start playing
            // the animation.
            if (this.isActive && !this.config.value.manualAdvance) {
                animation.play(startImmediately = false)
            }
        }
    }

    /** Removes an animation from the timeline.
     * @param animation - The animation to remove.
     */
    internal fun remove(animation: Animation?) {
        if (animation == null) return

        val index = _animations.indexOf(animation)
        if (index >= 0) {
            animation.timeline = null
            _animations.removeAt(index)
            animation.trigger(AnimationEvent.TIMELINE_CHANGE)
        }
    }

    /** Removes an animation from the timeline by its identifier if it exists.
     * @param id - The identifier of the animation to remove.
     */
    internal fun removeById(id: String) {
        val animation = animations.firstOrNull { it.id == id }
        animation?.let { remove(it) }
    }

    /** Stops and removes all animations from the timeline.
     */
    internal fun clear() {
        stop()
        _animations.clear()
    }

    private fun startPlayJob(fps: Float) {
        if (playJob != null) {
            playJob!!.cancel()
        }
        playJob = updateWhilePlaying(fps) {
            triggerAny(AnimationEvent.advance, position)
            storedDate = currentDate
        }
    }

    private fun cancelPlayJob() {
        if (playJob != null) {
            playJob!!.cancel()
        }
    }

    /**
     *  Begins playing the animation.
     *
     * If you want to start playing the animation from a specific position, pass a value from 0 to 1 to the play()
     * method where 0 is the beginning of the animation and 1 is the end. For example, use play(0.5) to start playback
     * halfway through the animation.
     *
     * @param positionInput An optional position to seek to before toggling play/stop.
     *                           If null, toggles playback from the current position.
     *
     **/
    fun play(positionInput: Double? = null) {
        play(positionInput, true)
    }


    override fun play(positionInput: Double?, startImmediately: Boolean) {
        if (!enabled) return

        if (startImmediately) {
            isWaitingForEndDelay = false
            timeWaitedForEndDelay = 99999999.0
        } else if (delay > 0.0) {
            isWaitingForDelay = true
            timeWaitedForDelay = 0.0

        }

        if (positionInput != null) {
            goTo(positionInput)
        } else {
            goTo(calculateProgressBetweenDates(start, end, storedDate))

        }
        //controller.readyToPlay = false // 260311, commenting out allows playback of empty map

        setPlayIsPressed(true)
        controller.startAnimatingTimeline(true)




        if (_state == AnimationState.playing) {
            _state = AnimationState.stopped
            setLiveState(AnimationState.stopped) // TODO: is this ever used?
        } else {
            _state = AnimationState.playing
            setLiveState(AnimationState.playing)
        }

        //println(">> TimeLine.play() _state: ${_state}")

        this.trigger(AnimationEvent.play)

        if (_state == AnimationState.playing) {
            startPlayJob(frameRate)
        } else {
            cancelPlayJob()
        }


    }

    /** Begins playing the animation from the specified date where date is within the time range between the timeline's startDate and endDate values. **/
    fun playFromDate(fromDate: Date) {
        goToDate(fromDate)
        play(startImmediately = true)
    }

    /** Toggles the current state of the animation between paused and playing if currently active. **/
    override fun toggle() {
        if (_state == AnimationState.playing) {
            _state = AnimationState.paused
            setLiveState(AnimationState.paused)
        } else {
            _state = AnimationState.playing
            setLiveState(AnimationState.playing)
        }
    }

    /** Pauses the animation at its current position. **/
    override fun pause() {
        if (state == AnimationState.playing) {
            //if(pr.ON) pr.p("TimeLine", pr.playPause, "pause() B")
            _state = AnimationState.paused
            setLiveState(AnimationState.paused)
            this.trigger(AnimationEvent.PAUSE)
            setPlayIsPressed(false) // fire off listener in TileLayer
            _animations.forEach { it.pause() }
            super.pause()
            cancelPlayJob()
            lastDataMeldAdvanceMonotonicNanos = 0L
        }
    }

    /**  Resumes playing the animation from its current position, such as after being paused. **/
    override fun resume() {
        //if(pr.ON) pr.p("TimeLine", pr.playPause, "resume()")
        _state = AnimationState.playing
        setLiveState(AnimationState.playing)
        //setPlayIsPressed(true) // fire off listener in TileLayer
        startPlayJob(frameRate)
        this.trigger(AnimationEvent.RESUME)
        _animations.forEach { it.resume() }
        super.resume()
    }

    /** Stops playing the animation. The timeline position will be updated to the time closest to the current time, which may be at the start or end of the time range or somewhere in between. **/
    override fun stop() {
        if (pr.ON) pr.p("TimeLine", pr.timeMove, "stop()")
        _state = AnimationState.stopped
        setLiveState(AnimationState.stopped)
        setPlayIsPressed(false) // fire off listener in TileLayer
        this.trigger(AnimationEvent.stop)
        _animations.forEach { it.stop() }
        super.stop()
        advanceToStopPosition()
        cancelPlayJob()
        lastDataMeldAdvanceMonotonicNanos = 0L
    }

    override fun restart() {
        if (pr.ON) pr.p("TimeLine", pr.playPause, "restart()")
        setPlayIsPressed(true) // fire off listener in TileLayer
        _state = AnimationState.playing
        setLiveState(AnimationState.playing)
        this.trigger(AnimationEvent.RESTART)
        _animations.forEach { it.restart() }
        super.restart()
    }

    /** Stops playing the animation if currently playing and updates the playhead back to its original starting position. **/
    override fun reset() {
        stop()
        goTo(0.0)
        this.trigger(AnimationEvent.RESET)

    }

    override fun advance(progress: Double, useTotalDuration: Boolean) { //boolean is set to true by default in JS
        if (pr.ON) pr.p("Timeline", pr.timeMove, "advance($progress, $useTotalDuration) calling super.advance()")
        _animations.forEach { it.advance(progress, useTotalDuration) }
        super.advance(progress, useTotalDuration)
        this.trigger(AnimationEvent.advance)

    }

    override fun goToDate(date: Date) {
        _animations.forEach { animation ->
            if (animation is TimeAnimation) {
                animation.goToDate(date)
            }
        }
        super.goToDate(date)
    }

    /** Update the map to reflect a position on the timeline from 0.0 to 1.0 **/
    override fun goTo(position: Double, useTotalDuration: Boolean) { //boolean is set to false by default in JS
        if (pr.ON) pr.p(TAG, pr.flicker2, "goto($position) calling setProgress()")

        setProgress(position)
        //_animations.forEach { it.goTo(position, useTotalDuration) }
        //super.goTo(position, useTotalDuration)
        storedDate = currentDate

    }

    /** Calls a function for each animation in the timeline.
     * @param fn - The function to call for each animation.
     * @param enabledOnly - Whether to only call the function for enabled animations. Default is `true`.
     */
    private fun _each(fn: (animator: Animation) -> Unit, enabledOnly: Boolean = true) {
        _animations.filter { !enabledOnly || (enabledOnly && it.enabled) }.forEach(fn)
    }

    override fun advanceToStopPosition() {
        if (pr.ON) pr.p(
            "Timeline",
            pr.timeMove,
            "AdvanceToStopPosition alwaysStopAtStart:${alwaysStopAtStart}   st:${start.time}   rt: ${referenceDate.time}    et: ${end.time}                               "
        )
        if (alwaysStopAtStart) {
            advance(0.0)
        } else if (start.time < referenceDate.time && end.time > referenceDate.time) {
            //goToDate(referenceDate)
            if (pr.ON) pr.p(
                "Timeline",
                pr.timeMove,
                "AdvanceToStopPosition() calculateProgressBetweenDates(start, end, referenceDate) = ${
                    calculateProgressBetweenDates(
                        start, end, referenceDate
                    )
                } "
            )
            if (pr.ON) pr.p(
                "Timeline",
                pr.timeMove,
                "AdvanceToStopPosition() calling   advance(calculateProgressBetweenDates($start, $end, $referenceDate) )}  "
            )
            advance(calculateProgressBetweenDates(start, end, referenceDate /* * 100.0 */).toDouble())
        } else if (isPast) {
            advance(100.0)
        } else {
            advance(0.0)
        }
    }

    internal fun nextInterval() {
        if (pr.ON) pr.p(TAG, pr.timeMove, "nextInterval------------------")
        pause()
        val sizeMinusOne = timeStrings!!.size - 1

        if (dataMeld >= .97) {
            currentPhaseA++
            //println(">> Timeline nextInterval beforeEnd currentPhaseA to ${currentPhaseA}")
            currentPhaseB++
            dataMeld -= 1
            //updateAllMelds()
        }

        if (currentPhaseB < sizeMinusOne) {
            goTo(((currentPhaseA + 1).toDouble() / sizeMinusOne.toDouble()) * 1.0) //was 100.0
        } else {
            goTo(1.0) // was 100.0
        }

        //println(">> Timeline nextInterval set currentPhaseA to ${currentPhaseA}")
        triggerAny(AnimationEvent.advance, position)
    }

    internal fun prevInterval() {
        pause()

        if (dataMeld > .05f) {
            currentPhaseA++
            currentPhaseB++
            if (pr.ON) pr.p("TimeLine", pr.flicker2, " prevInterval: setting meld to 0")
            dataMeld = 0f
            //updateAllMelds()
        }

        if (currentPhaseA > 0) {
            val sizeMinusOne = timeStrings!!.size - 1
            goTo(((currentPhaseA - 1).toDouble() / sizeMinusOne) * 1.0) // was 100.0
        } else {
            goTo(0.0)
        }

        triggerAny(AnimationEvent.advance, position)
    }

    private fun formatDateToIsoString(date: Date): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
        sdf.timeZone = TimeZone.getTimeZone("UTC")
        val tempDateString = "[\"${sdf.format(date)}"
        return "${tempDateString.substring(0, 16)}00:00+00:00\"]"
    }


    @OptIn(DelicateCoroutinesApi::class)
    internal fun updateWhilePlaying(fps: Float, block: suspend () -> Unit): Job {
        // Drive playback advances from VSync using Choreographer so timing stays aligned
        // with screen refresh even when work varies or the app is under load.
        val choreographer = Choreographer.getInstance()
        val playJob = Job()
        val scope = kotlinx.coroutines.CoroutineScope(playJob + Dispatchers.Default)

        val inFlight = java.util.concurrent.atomic.AtomicBoolean(false)

        val callback =
            object : Choreographer.FrameCallback {
                override fun doFrame(frameTimeNanos: Long) {
                    if (!playJob.isActive) return

                    // Ensure we don't pile up overlapping executions if `block` ever takes longer than a frame.
                    if (inFlight.compareAndSet(false, true)) {
                        scope.launch {
                            try {
                                block()
                            } finally {
                                inFlight.set(false)
                            }
                        }
                    }

                    choreographer.postFrameCallback(this)
                }
            }

        choreographer.postFrameCallback(callback)
        return playJob
    }
}

/** @suppress **/
class TimelineInfo(
    override val isActive: Boolean,
    override val currentDate: Date,
    override val startDate: Date,
    override val endDate: Date,
    override val deltaTime: Long // Or appropriate type for deltaTime
) : TimeAnimationInfo(isActive, currentDate, startDate, endDate, deltaTime) {}

class LayerTimeline(val id: String) {
    var currentA = 0
    var currentB = 0
    var meld = 0f
    var lastMeld = 0f
    var paused = false
    internal var timeDates: MutableList<Date> = mutableListOf()
    internal var timeStrings: MutableList<String> = mutableListOf()
    internal var timeLongs: MutableList<Long> = mutableListOf()

    //internal var reqDates: MutableList<Date> = mutableListOf()
    internal var reqStrings: MutableList<String> = mutableListOf()
    internal var reqLongs: MutableList<Long> = mutableListOf()

    internal var phaseAString: String = ""
    internal var phaseBString: String = ""

    fun MutableList<Long>.addUnique(element: Long): Boolean {
        if (!this.contains(element)) {
            this.add(element)
            return true
        }
        return false
    }

    fun MutableList<String>.addUnique(element: String): Boolean {
        if (!this.contains(element)) {
            this.add(element)
            return true
        }
        return false
    }

    fun calcRenderVarFromDownloadedTimes() {
        if (paused) {
            // When paused, freeze the meld at the last known good value.
            // We handle "only completed intervals" at RenderPass draw-time by checking
            // whether exact tiles exist for A/B textures.
            meld = lastMeld
            return
        }

        val tLlongA = Timeline.timeLongs[Timeline.currentPhaseA]
        val tLlongB = Timeline.timeLongs[Timeline.currentPhaseB]
        var targetLong = (tLlongA + (tLlongB - tLlongA) * Timeline.dataMeld).toLong()

        if (targetLong < Timeline.timeLongs[0]) {
            targetLong = Timeline.timeLongs[0]
        }

        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderPassLogging,
            " ==========================================================================================="
        )


        val interpolObject = findInterpolationValuesFromDownloaded(targetLong, reqLongs)
        if (interpolObject != null) {
            lastMeld = meld
            meld = interpolObject.fraction
            currentA = interpolObject.aInt
            currentB = interpolObject.bInt
            phaseAString = reqStrings[currentA]
            phaseBString = reqStrings[currentB]
        } else {
            if (pr.ON) pr.p(
                "LayerTimeline", pr.renderPassLogging, ">> Timeline calcRenderVar interpolObject = null!!! ", 2
            )
        }


        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderpass10,
            ">> Timeline calcRenderVar() meldInfo new Values: A: ${interpolObject?.lowerBound}     B: ${interpolObject?.upperBound}  fr:${interpolObject?.fraction}"
        )
    }

    private fun findInterpolationValuesFromDownloaded(
        targetValue: Long, requestedLongList: List<Long>
    ): InterpolationResult? {
        // We need at least two points to form a range.

        if (requestedLongList.size < 2) {
            if (pr.ON) pr.p(
                "LayerTimeline",
                pr.renderPassLogging,
                ">> Timeline findInterpolationVal() requestedLongList: ${requestedLongList}",
                2
            )
            if (pr.ON) pr.p(
                "LayerTimeline",
                pr.renderPassLogging,
                ">> Timeline findInterpolationVal() find.. (requestedLongList < 2), return null",
                2
            )

            if (requestedLongList.isNotEmpty()) {
                return InterpolationResult(requestedLongList.first(), requestedLongList.first(), 0.0f, 0, 0)
            }

            return null
        }

        // Use binarySearch to find the index or the insertion point.
        /*
        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderPassLogging,
            ">> Timeline calcRenderVar() target: $targetValue in list: ${requestedLongList}"
        )

        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderPassLogging,
            ">> Timeline calcRenderVar() target: $targetValue in list: ${reqDates}"
        )
        */

        val searchResult = requestedLongList.binarySearch(targetValue)
        if (pr.ON) pr.p(
            "LayerTimeline",
            pr.renderpass10,
            ">> Timeline calcRenderVar() find.. searchResult: $searchResult   list.size:${requestedLongList.size}"
        )
        if (searchResult >= 0) {
            // Exact match found. The value is exactly on a point, so the fraction is 0.
            val value = requestedLongList[searchResult]
            return InterpolationResult(value, value, 0.0f, searchResult, searchResult)
        }

        // The value was not found. Convert the negative searchResult to an insertion point.
        val insertionPoint = -(searchResult + 1)

        // Handle edge cases: target is outside the entire range of the list.
        if (insertionPoint == 0 || insertionPoint == requestedLongList.size) {
            if (pr.ON) pr.p(
                "LayerTimeline",
                pr.renderPassLogging,
                ">> Timeline calcRenderVar() find.. (insertionPont == 0) return null",
                2
            )
            return null // Target is before the first element or after the last one.
        }

        // The target is between two elements.
        val lowerIndex = insertionPoint - 1
        val upperIndex = insertionPoint
        val lowerBound = requestedLongList[lowerIndex]
        val upperBound = requestedLongList[upperIndex]

        // Prevent division by zero if the bounds are identical.
        val range = (upperBound - lowerBound).toFloat()
        if (range == 0f) {
            return InterpolationResult(lowerBound, upperBound, 0.0f, lowerIndex, upperIndex)
        }

        // Calculate the fractional position of the target within the range.
        val position = (targetValue - lowerBound).toFloat()
        val fraction = position / range

        return InterpolationResult(
            lowerBound, upperBound, fraction.coerceIn(0.0f, 1.0f), lowerIndex, upperIndex
        )
    }


    /**
     * Finds the two values in a sorted list that a target value falls between,
     * and calculates the fractional distance between them.
     *
     * @param targetValue The long value to locate within the list.
     * @param sortedList The sorted list of longs to search within.
     * @return An [InterpolationResult] containing the lower and upper bound values and the fraction (0.0f to 1.0f).
     *         Returns null if the list has fewer than two elements or the target is outside the list's range.
     */
    fun findInterpolationValuesFromAllValidTimes(targetValue: Long, sortedList: List<Long>): InterpolationResult? {
        // We need at least two points to form a range.
        if (sortedList.size < 2) {
            return null
        }

        // Use binarySearch to find the index or the insertion point.
        val searchResult = sortedList.binarySearch(targetValue)

        if (searchResult >= 0) {
            // Exact match found. The value is exactly on a point, so the fraction is 0.
            val value = sortedList[searchResult]
            return InterpolationResult(value, value, 0.0f, searchResult, searchResult)
        }

        // The value was not found. Convert the negative searchResult to an insertion point.
        val insertionPoint = -(searchResult + 1)

        // Handle edge cases: target is outside the entire range of the list.
        if (insertionPoint == 0 || insertionPoint == sortedList.size) {
            return null // Target is before the first element or after the last one.
        }

        // The target is between two elements.
        val lowerIndex = insertionPoint - 1
        val upperIndex = insertionPoint
        val lowerBound = sortedList[lowerIndex]
        val upperBound = sortedList[upperIndex]

        // Prevent division by zero if the bounds are identical.
        val range = (upperBound - lowerBound).toFloat()
        if (range == 0f) {
            return InterpolationResult(lowerBound, upperBound, 0.0f, lowerIndex, upperIndex)
        }

        // Calculate the fractional position of the target within the range.
        val position = (targetValue - lowerBound).toFloat()
        val fraction = position / range

        return InterpolationResult(
            lowerBound, upperBound, fraction.coerceIn(0.0f, 1.0f), lowerIndex, upperIndex
        )
    }


}