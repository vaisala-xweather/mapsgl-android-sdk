package com.xweather.mapsgl.anim

import com.xweather.mapsgl.AbortSignal
import com.xweather.mapsgl.AnyAuthenticator
import com.xweather.mapsgl.gl.extensions.pr
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Date

/**
 * Options for a tile request.
 *
 * @suppress
 */
data class TileRequestOptions(
    /** The HTTP method to use for the request.   */
    val method: String = "",

    /** The authenticator to use for the request, if any.   */
    val authenticator: AnyAuthenticator? = null,

    /** The request body to send, if any.    */
    val body: Any? = null,

    /** The request headers to send, if any.    */
    val headers: Any? = null,

    // Query parameters are composed in `TileSource.makeTileURL`, which every tile source goes
    // through, from `TileSource.params` (XMAPSGLSDK-317). Kept rather than removed because this is a
    // published data class: dropping a constructor parameter changes the generated constructor, its
    // default bridge, `copy` and `componentN`, and would be a `NoSuchMethodError` for an app linking
    // an older AAR. Deprecated at warning level for the same reason -- an app that sets it today
    // still compiles, and setting it was already a no-op.
    /**
     * Never read; setting it has no effect. Set `params` on the source descriptor instead:
     * [com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor.params],
     * [com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor.params] or
     * [com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor.params].
     */
    @Deprecated(
        "Never read; setting it has no effect. Set EncodedSourceDescriptor.params / " +
            "ImageSourceDescriptor.params / VectorSourceDescriptor.params instead.",
    )
    val params: Map<String, Any>? = null,

    /** The AbortSignal to use for the request.    */
    val signal: AbortSignal? = null,

    /** Whether to reload the tile if it has already been loaded.    */
    var reload: Boolean = true,

    /** Whether to check if the tile is already pending before loading.    */
    var checkPending: Boolean = true,

    /** The time intervals to load for the tile.    */
    val intervals: List<Date>? = null,

    /** Used for p-type radar    */
    var isRadar: Boolean = false


) {

    init {
        if (pr.ON) pr.p("TileRequestOptions", pr.radarFix2, "init{} isRadar:$isRadar")
    }

    fun formatDate(date: Date): String {
        val instant = date.toInstant()
        val zonedDateTime = ZonedDateTime.ofInstant(instant, ZoneId.systemDefault()) // detect timezone
        val formatter: DateTimeFormatter = DateTimeFormatter.ISO_OFFSET_DATE_TIME
        return "${zonedDateTime.format(formatter).substring(0, 19)}Z"
    }

}
