package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.style.SymbolRankDirection
import kotlin.math.floor

/**
 * Screen-space symbol collision + opacity fade (MapsGL JS `placeSymbols` / `updateLayerOpacities`).
 */
internal class VectorSymbolScreenPlacer {

    data class Candidate(
        val crossTileId: String,
        val rank: Float,
        val screenBox: FloatArray,
        /**
         * Tie-break key for equal ranks. Must be *intrinsic to the symbol* — what it is, not how it
         * was found.
         *
         * Defaults to [crossTileId], which is intrinsic when identity is positional (the
         * `z-x-y-u-v` form [symbolCrossTileId] builds). It is NOT intrinsic when identity comes
         * from [VectorSymbolCrossTileIndex], which mints ids from a counter as labels are
         * discovered: ordering on that describes where the map has been rather than what the symbol
         * is, so the same scene reached by two different routes breaks ties differently and picks
         * different winners. The JS SDK's placement sort records the same hazard and excludes its
         * cross-tile identifier from the comparison for this reason.
         */
        val sortKey: String? = null,
        /**
         * Zoom of the tile this instance came from, or -1 when unknown.
         *
         * Identifies *which copy* of a label this is. Once identity is resolved by proximity
         * ([VectorSymbolCrossTileIndex]), the same place arriving from a coarse and a fine tile is
         * one label with two candidate instances, and something has to choose between them — see
         * `VectorSymbolLayerRenderer.dedupeCandidates`.
         */
        val tileZ: Int = -1,
    ) {
        val orderKey: String get() = sortKey ?: crossTileId
    }

    private data class FadeState(
        var placed: Boolean,
        var opacity: Float,
    )

    private val lock = Any()
    private val opacityById = LinkedHashMap<String, FadeState>(256)
    private var lastUpdateMs: Long = 0L

    /**
     * Whether [crossTileId] was placed and actually showing after the last pass.
     *
     * Read by the renderer's dedupe when choosing which of a label's candidate instances should
     * represent it: an already-visible label should keep the instance it is being drawn from, so it
     * does not restart its fade.
     */
    fun wasVisible(crossTileId: String): Boolean =
        synchronized(lock) {
            val state = opacityById[crossTileId] ?: return false
            state.placed && state.opacity > 0f
        }

    fun clear() {
        synchronized(lock) {
            opacityById.clear()
            lastUpdateMs = 0L
        }
    }

    /**
     * Rule: placer-cross-thread-safe. [placeAndFade]/[clear] run on the Mapbox GL/render thread
     * while [needsContinuation] is polled from the main-looper keep-redrawing tick. Iterating
     * [opacityById] without a lock raced a concurrent mutation and crashed on pan/scroll with
     * ConcurrentModificationException (LinkedHashMap iterator).
     */
    fun needsContinuation(): Boolean =
        synchronized(lock) {
            opacityById.values.any { state ->
                val target = if (state.placed) 1f else 0f
                kotlin.math.abs(state.opacity - target) > 0.02f
            }
        }

    /**
     * Runs cross-tile collision, updates fade targets, and returns per-[crossTileId] draw opacity.
     *
     * @param snap when true, skip fade animation (used while the camera is moving to avoid redraw storms).
     * @param foreignBoxes screen boxes already claimed by *other* layers sharing this layer's
     * collision group ([VectorSymbolCollisionGroups]). Inserted into the collision index before any
     * candidate is considered, so they occupy space but never become candidates themselves and
     * never appear in the returned opacities.
     *
     * Passing sibling labels in as pre-occupied space, rather than sharing one placer across the
     * layers, is deliberate: this method treats any tracked id absent from [candidates] as having
     * left the screen and fades it out, so a shared placer called once per layer would fade out
     * every *other* layer's labels on every call.
     * @param placedBoxesOut when non-null, receives the boxes this call actually placed, for
     * publishing to later siblings in the same frame.
     */
    fun placeAndFade(
        candidates: List<Candidate>,
        rankDirection: SymbolRankDirection?,
        nowMs: Long,
        fadeDurationMs: Long = SYMBOL_FADE_DURATION_MS,
        snap: Boolean = false,
        foreignBoxes: List<FloatArray> = emptyList(),
        placedBoxesOut: MutableList<FloatArray>? = null,
    ): Map<String, Float> = synchronized(lock) {
        // Rule: no-visibility-feedback-in-the-sort. Nothing here reads the current opacity state.
        //
        // This replaces `placement-visibility-boost`, which gave anything placed last frame a
        // 1,000,000-unit rank bias, plus `skip-boost-on-growth`, which scoped that bias to a
        // newcomer's own screen space. The JS SDK removed the equivalent bias outright, and its
        // reasoning applies here unchanged: ordering on what is already visible feeds placement
        // back into itself — an on-screen symbol wins its collisions, which keeps it on screen,
        // which keeps it winning. Most layers configure no rank at all (of the four place layers
        // only place-city sets one), so every candidate ties and that feedback becomes the *whole*
        // sort: a label from a newly loaded tile can then never take a slot from the coarser-zoom
        // label standing in for it, and stays invisible for as long as tiles keep arriving.
        // `skip-boost-on-growth` was an attempt to bound exactly that failure.
        //
        // The stability the bias was reaching for now comes from elsewhere: placement resolving the
        // same tile set that gets drawn, and identity surviving a zoom change
        // ([VectorSymbolCrossTileIndex]). What remains of it is the bounded hysteresis below, which
        // damps threshold chatter without being able to dominate the ordering.
        // Order by rank, then by an intrinsic tie-break. Both describe the symbol itself, so the
        // same candidate set always yields the same winners — which is what makes placement agree
        // with itself across a zoom boundary.
        val sorted =
            when (rankDirection) {
                SymbolRankDirection.DESC ->
                    candidates.sortedWith(compareByDescending<Candidate> { it.rank }.thenBy { it.orderKey })
                else ->
                    candidates.sortedWith(compareBy<Candidate> { it.rank }.thenBy { it.orderKey })
            }
        val collision = ScreenCollisionIndex()
        // Sibling layers' claims go in first: they cannot be displaced by anything here, which is
        // what makes a composite's sub-layers stop overlapping each other. Draw order decides who
        // yields, and it is stable (layer add order), so the outcome is deterministic.
        for (box in foreignBoxes) collision.insert(box)
        val seenIds = HashSet<String>(sorted.size)
        for (candidate in sorted) {
            seenIds.add(candidate.crossTileId)
            val state = opacityById.getOrPut(candidate.crossTileId) { FadeState(placed = false, opacity = 0f) }
            // Rule: bounded-collision-hysteresis. Clearance required to KEEP a slot versus to WIN
            // one. A symbol whose overlap sits exactly on the threshold would otherwise alternate
            // pass to pass as the view moves under it, and because each decision reverses its fade
            // it flickers rather than settling. An incumbent is tested with a slightly inset box
            // and a newcomer with a slightly outset one, so the decision has somewhere stable to
            // rest.
            val wasPlaced = state.placed
            val testBox = hysteresisBox(candidate.screenBox, wasPlaced)
            val fits = !collision.collides(testBox)
            state.placed = fits
            if (fits) {
                collision.insert(candidate.screenBox)
                placedBoxesOut?.add(candidate.screenBox)
            }
        }
        for (id in opacityById.keys.toList()) {
            if (id !in seenIds) {
                opacityById[id]?.placed = false
            }
        }
        if (snap) {
            for (id in seenIds) {
                val state = opacityById[id] ?: continue
                state.opacity = if (state.placed) 1f else 0f
            }
            for (id in opacityById.keys.toList()) {
                if (id !in seenIds) {
                    opacityById[id]?.opacity = 0f
                }
            }
        } else {
            val delta = fadeDelta(nowMs, fadeDurationMs)
            for (id in seenIds) {
                opacityById[id]?.let { stepOpacity(it, delta) }
            }
            for (id in opacityById.keys.toList()) {
                if (id !in seenIds) {
                    opacityById[id]?.let { stepOpacity(it, delta) }
                }
            }
        }
        pruneStaleOpacity(seenIds)
        return buildOpacityResult(seenIds)
    }

    private fun buildOpacityResult(seenIds: Set<String>): Map<String, Float> {
        val out = HashMap<String, Float>(seenIds.size + 8)
        for (id in seenIds) {
            // [placeAndFade] getOrPut's a state for every candidate, so a seen id can only be
            // missing here because [pruneStaleOpacity] just evicted it — which now happens only at
            // the hard ceiling, taking the dimmest entries first. The old `?: 1f` drew such a label
            // at FULL opacity for one frame before it reappeared next frame as a newcomer at 0 and
            // faded up: a hard 1 -> 0 flash, repeating for as long as the layer stayed over the
            // entry cap. Report what it actually was: gone.
            out[id] = opacityById[id]?.opacity ?: 0f
        }
        for ((id, state) in opacityById) {
            if (id !in seenIds && state.opacity > 0.02f) {
                out[id] = state.opacity
            }
        }
        return out
    }

    private fun pruneStaleOpacity(seenIds: Set<String>) {
        val it = opacityById.entries.iterator()
        while (it.hasNext()) {
            val (id, state) = it.next()
            if (id in seenIds) continue
            if (!state.placed && state.opacity <= 0.02f) {
                it.remove()
            }
        }
        if (opacityById.size <= MAX_OPACITY_ENTRIES) return
        // Rule: never-evict-an-on-screen-candidate. [MAX_OPACITY_ENTRIES] is a SOFT cap, and it may
        // only ever reclaim entries that are no longer candidates at all. Presence in this map is
        // what [placeAndFade] uses to tell an incumbent's established rival from a genuine newcomer
        // (skip-boost-on-growth), so evicting an id that is still on screen does not just lose a
        // fade — it corrupts that decision on the very next frame.
        //
        // The old loop got this wrong twice over, and both cost a frame-by-frame blink on any layer
        // dense enough to sit over the cap (place-city at low zoom, place-neighborhood at any zoom;
        // note LayerCode.PLACES composites four such layers, each with its own placer):
        //
        //   - It fell back to `opacityById.keys.firstOrNull()` — insertion-order oldest, typically a
        //     long-standing *visible* label. That label flashed at full opacity for one frame (see
        //     [buildOpacityResult]) and then restarted its fade from 0. A square wave.
        //   - Its preferred victim, an unplaced faded entry, is usually a label that is still on
        //     screen and merely losing its collision. Dropping it made it a newcomer next frame,
        //     which stripped the incumbent's visibility boost and handed the slot to whichever side
        //     momentarily ranked better — so the protection against tie-boundary flicker switched
        //     itself off exactly on the layers that need it most.
        //
        // And because something was always mid-fade, needsContinuation() never went quiet, so
        // VectorSymbolLayerRenderer's ~30fps fade tick re-rendered an idle map forever.
        //
        // Entries left after the loop above are either still candidates (untouchable) or mid-fade
        // on their way out, so only the latter are available. Dimmest first: they are disappearing
        // anyway, and cutting a nearly-invisible one short is the least visible thing to do.
        // Exceeding the cap when the on-screen candidates alone fill it is the correct outcome —
        // that count is bounded by the data (the first loop reclaims everything that leaves and
        // finishes fading), and a FadeState plus a crossTileId key each is far cheaper than blinking.
        var over = opacityById.size - MAX_OPACITY_ENTRIES
        val fadingOut = opacityById.entries
            .filter { it.key !in seenIds }
            .sortedBy { it.value.opacity }
        for (entry in fadingOut) {
            if (over <= 0) break
            opacityById.remove(entry.key)
            over--
        }
        if (opacityById.size <= HARD_MAX_OPACITY_ENTRIES) return
        // Rule: forced-eviction-takes-the-dimmest. Backstop for a pathological id space (far more
        // distinct crossTileIds on screen than any real tile set produces). Only here may an
        // on-screen candidate be dropped, and again the dimmest go first.
        val dimmestFirst = opacityById.entries.sortedBy { it.value.opacity }
        var stillOver = opacityById.size - HARD_MAX_OPACITY_ENTRIES
        for (entry in dimmestFirst) {
            if (stillOver <= 0) break
            opacityById.remove(entry.key)
            stillOver--
        }
    }

    private fun fadeDelta(nowMs: Long, fadeDurationMs: Long): Float {
        val prev = lastUpdateMs
        lastUpdateMs = nowMs
        if (prev == 0L || fadeDurationMs <= 0L) return 1f
        val elapsed = (nowMs - prev).coerceIn(0L, 64L)
        return elapsed.toFloat() / fadeDurationMs.toFloat()
    }

    /**
     * Rule: bounded-collision-hysteresis. The box a candidate is *tested* against, versus the box it
     * claims once placed.
     *
     * An incumbent is tested slightly inset and a newcomer slightly outset, so keeping a slot needs
     * marginally less clearance than winning one. The gap is deliberately small: it damps chatter
     * for a symbol sitting exactly on the threshold without meaningfully changing which symbols are
     * chosen — unlike the 1,000,000-unit rank bias it replaces, which could dominate the sort
     * outright. The claimed box is always the real one, so hysteresis never leaks into the space a
     * placed symbol actually reserves.
     */
    private fun hysteresisBox(box: FloatArray, wasPlaced: Boolean): FloatArray {
        if (box.size < 4) return box
        val d = if (wasPlaced) COLLISION_HYSTERESIS_PX else -COLLISION_HYSTERESIS_PX
        // Never invert a box: a symbol smaller than twice the margin would otherwise test as a
        // negative-size rectangle, which overlaps nothing and would place through everything.
        val halfW = (box[2] - box[0]) * 0.5f
        val halfH = (box[3] - box[1]) * 0.5f
        val dx = d.coerceAtMost(halfW - 0.5f)
        val dy = d.coerceAtMost(halfH - 0.5f)
        return floatArrayOf(box[0] + dx, box[1] + dy, box[2] - dx, box[3] - dy)
    }

    private fun stepOpacity(state: FadeState, delta: Float) {
        val target = if (state.placed) 1f else 0f
        when {
            state.opacity < target -> state.opacity = minOf(target, state.opacity + delta)
            state.opacity > target -> state.opacity = maxOf(target, state.opacity - delta)
        }
    }

    private class ScreenCollisionIndex {
        private val grid = HashMap<Long, ArrayList<FloatArray>>(64)

        /**
         * Rule: indexable-box-or-drop. [forEachCellInBox] walks a box cell by cell with no bound of
         * its own, and [insert] allocates a bucket per cell, so a degenerate box is not a wrong
         * answer — it is an OOM. `floor(1e30f / 128).toInt()` saturates to Int.MAX_VALUE, making
         * the nested loop ~1e19 iterations of list allocation inside Mapbox's render() callback,
         * which aborts the process at the JNI boundary. Such boxes came from dividing by a
         * near-zero clip w (see VectorSymbolScreenProjection.MIN_PROJECTED_CLIP_W, which now
         * rejects them at the source); this guard is the second line of defense so the grid can
         * never be one bad caller away from taking down the app.
         */
        private fun FloatArray.isIndexable(): Boolean {
            if (size < 4) return false
            if (!this[0].isFinite() || !this[1].isFinite()) return false
            if (!this[2].isFinite() || !this[3].isFinite()) return false
            if (this[2] < this[0] || this[3] < this[1]) return false
            val cellsX = ((this[2] - this[0]) / CELL_SIZE_PX).toDouble() + 1.0
            val cellsY = ((this[3] - this[1]) / CELL_SIZE_PX).toDouble() + 1.0
            return cellsX * cellsY <= MAX_CELLS_PER_BOX
        }

        fun collides(box: FloatArray): Boolean {
            // A footprint we cannot index must not be allowed to claim screen space, so report it
            // as colliding: the symbol goes unplaced and is never inserted.
            if (!box.isIndexable()) return true
            var hit = false
            forEachCellInBox(box) { key ->
                if (hit) return@forEachCellInBox
                val cell = grid[key] ?: return@forEachCellInBox
                for (other in cell) {
                    if (overlaps(box, other)) {
                        hit = true
                        return@forEachCellInBox
                    }
                }
            }
            return hit
        }

        fun insert(box: FloatArray) {
            // [placeAndFade]'s newcomer index inserts without a preceding collides() call, so this
            // guard has to stand on its own rather than lean on that one.
            if (!box.isIndexable()) return
            forEachCellInBox(box) { key ->
                grid.getOrPut(key) { ArrayList(4) }.add(box)
            }
        }

        private inline fun forEachCellInBox(box: FloatArray, action: (Long) -> Unit) {
            val x0 = floor(box[0] / CELL_SIZE_PX).toInt()
            val y0 = floor(box[1] / CELL_SIZE_PX).toInt()
            val x1 = floor(box[2] / CELL_SIZE_PX).toInt()
            val y1 = floor(box[3] / CELL_SIZE_PX).toInt()
            for (cy in y0..y1) {
                for (cx in x0..x1) {
                    action(cellKey(cx, cy))
                }
            }
        }

        private fun cellKey(cx: Int, cy: Int): Long =
            (cx.toLong() shl 32) or (cy.toLong() and 0xffffffffL)

        private fun overlaps(a: FloatArray, b: FloatArray): Boolean =
            a[0] < b[2] && a[2] > b[0] && a[1] < b[3] && a[3] > b[1]
    }

    companion object {
        private const val SYMBOL_FADE_DURATION_MS = 200L

        /** Collision grid cell edge, in screen px. */
        private const val CELL_SIZE_PX = 128f

        /**
         * Rule: indexable-box-or-drop. Most grid cells a single collision box may occupy. A box
         * covering an entire 4K viewport is roughly 30x17 = 510 cells, so this leaves ~32x headroom
         * over anything real while keeping the worst case bounded.
         */
        private const val MAX_CELLS_PER_BOX = 16_384

        /**
         * Rule: never-evict-an-on-screen-candidate. Soft cap on tracked fade states — exceeded
         * rather than reclaiming an id that is still a placement candidate. Was 512, which a dense
         * place layer clears easily (MAX_SYMBOL_INSTANCES_PER_TILE alone is 4096, per tile, and
         * several tiles are on screen at once); at that size the eviction path ran on every frame
         * and blinked the map permanently. Sized instead to hold every label a realistic viewport
         * can show, so in practice only mid-fade leftovers are ever reclaimed for it.
         */
        private const val MAX_OPACITY_ENTRIES = 8_192

        /**
         * Rule: forced-eviction-takes-the-dimmest. Absolute ceiling, past which even an on-screen
         * candidate may be evicted (dimmest first). Only reachable if far more distinct
         * crossTileIds are on screen than any real tile set produces.
         */
        private const val HARD_MAX_OPACITY_ENTRIES = 32_768

        /**
         * Rule: bounded-collision-hysteresis. Screen pixels of extra clearance a newcomer must find,
         * and that an incumbent may go without. Matches the JS SDK's `COLLISION_HYSTERESIS_PX`.
         */
        private const val COLLISION_HYSTERESIS_PX = 2f
    }
}
