package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.weather.groups.DataQuery
import android.content.Context
import android.opengl.GLES31
import android.opengl.Matrix
import android.os.SystemClock
import android.util.Log
import androidx.compose.ui.graphics.Color
import com.mapbox.geojson.Feature
import com.mapbox.geojson.MultiPoint
import com.mapbox.geojson.Point
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.EmptyRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.ExpressionFilterFlatten
import com.xweather.mapsgl.map.mapbox.ExpressionReferencedKeys
import com.xweather.mapsgl.map.mapbox.GeoJsonWorldCopies
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.MapboxVectorFeature
import com.xweather.mapsgl.map.mapbox.TropicalDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorCircleRawStyleEval
import com.xweather.mapsgl.map.mapbox.VectorDrawTime
import com.xweather.mapsgl.map.mapbox.VectorFeatureDrawFilter
import com.xweather.mapsgl.map.mapbox.geoJsonVisibleFeatureSetKey
import com.xweather.mapsgl.map.mapbox.VectorMapTime
import com.xweather.mapsgl.map.mapbox.VectorFillStyleExpressionEval
import com.xweather.mapsgl.map.mapbox.VectorLayerDrawFilterDefaults
import com.xweather.mapsgl.map.mapbox.VectorPolygonFillTriangulator
import com.xweather.mapsgl.map.mapbox.featureLayerTag
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.nestedDictionary
import com.xweather.mapsgl.sources.resolveVectorTileData
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.SymbolLayerPaint
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.util.MapsGLDebug
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.floor
import com.xweather.mapsgl.mvt.MvtFeature
import com.xweather.mapsgl.mvt.MvtMultiPoint
import com.xweather.mapsgl.mvt.MvtPoint

private const val VECTOR_SYMBOL_TAG = "VectorSymbolLayerRenderer"
/** Bump when [SYMBOL_VERT]/[SYMBOL_FRAG] change so cached programs are re-linked. */
private const val SYMBOL_GL_PROGRAM_VERSION = 8
/** Bump when per-instance layout / raster UV convention changes (invalidates [instanceCache]). */
private const val SYMBOL_INSTANCE_CACHE_VERSION = 30
/**
 * Cap symbol instance batches retained per renderer (each tile ≈ hundreds of points). Rule:
 * shared-playback-gate. Raised from the original 96 to match
 * [VectorCircleLayerRenderer]'s triangulation cache cap (512) — during gate-hold warmup the old
 * on-demand path keeps running (see [putInstanceCache]) and, for age-colored layers whose
 * mapTimeKey ticks every second, was cycling through 96 entries fast enough to evict a
 * just-built gate-hold batch before schedulePlaybackFramePreparation's next tick could see it,
 * stalling the gate indefinitely.
 */
private const val MAX_SYMBOL_INSTANCE_CACHE_ENTRIES = 512
/** Throttle tile prefetch requests kicked off from the draw loop (ms). */
private const val SYMBOL_DRAW_PREFETCH_MIN_INTERVAL_MS = 400L
/** Throttle background instance-build redraw requests (ms). */
private const val SYMBOL_BUILD_REDRAW_MIN_INTERVAL_MS = 200L
/** Min ms between collision-fade continuation redraws while the map is moving. */
private const val SYMBOL_CONTINUATION_REDRAW_MIN_MS = 48L
/** Rule: fade-needs-fast-tick. [ensureKeepRedrawing]'s repost interval while a collision fade is
 * actually in progress — ~30fps is fast enough that a 200ms opacity ramp completes in roughly its
 * nominal duration instead of crawling at the much slower [SYMBOL_DRAW_PREFETCH_MIN_INTERVAL_MS]
 * pace meant for tile-fetch retries. (Spinning icons use a separate vsync [Choreographer] loop.) */
private const val SYMBOL_FADE_REDRAW_INTERVAL_MS = 33L
/** Fractional zoom delta treated as active map movement (collision snap during gestures). */
private const val SYMBOL_CAMERA_ZOOM_EPSILON = 0.001
/** Hold prior draw batches across integer zoom changes (ms). */
private const val SYMBOL_ZOOM_TRANSITION_HOLD_MS = 1_000L
/** Background threads building per-tile instance buffers (lightning tiles are dense). */
private const val SYMBOL_INSTANCE_BUILD_THREADS = 2
/**
 * Rule: shared-playback-gate. Mirrors [VectorLineLayerRenderer]'s
 * `GEOJSON_SYNC_TRIANGULATION_MAX_FEATURES`: below this feature count, build instances inline on
 * the draw call instead of kicking off a background job and returning with nothing drawn this
 * frame. Needed because age/track-scrubbed layers (e.g. tropical-cyclones' track/position icons)
 * bake `mapTimeKey` (whole seconds) into their GeoJSON cache key, so during fast playback the key
 * changes almost every frame — with only the async path, every such change produced a real,
 * visible one-or-more-frame disappear while the rebuild was in flight, since (unlike the
 * VectorTileSource playback path) this GeoJSON branch has no `lastSuccessfulBatches` fallback.
 * These layers have very few features (a handful of storm track points), so building synchronously
 * is cheap.
 */
private const val GEOJSON_SYNC_INSTANCE_BUILD_MAX_FEATURES = 200
/**
 * Rule: per-tile-instance-cap. Hard ceiling on how many point instances a single [buildInstances]
 * call may emit, checked in the same loop that appends to sdfOut/rasterOut/textOut. A tile's own
 * feature list is normally at most a few hundred points even for the densest real place-city tile,
 * but [SYMBOL_TILE_UV_OWNERSHIP_MARGIN]'s per-point ownership gate degenerates at very coarse zoom —
 * at z=0 the tile's own uv range legitimately spans the entire world, so the gate can't reject
 * anything, and if that z=0/z=1 tile (reached directly or via allowParentFallback's coarser-ancestor
 * walk while zooming) carries an unsimplified, effectively-global feature list, every one of
 * potentially hundreds of thousands of worldwide points would be "owned" and emitted. Each owned
 * point contributes up to paint.text.size text instances (17 floats each) plus an icon instance, so
 * this can balloon into tens of millions of floats — which crashed the app for real: a
 * ByteBuffer.allocateDirect() for the resulting instance buffer threw OutOfMemoryError requesting a
 * ~256MB direct buffer, and the pending exception then aborted the process via a JNI safety check
 * inside Mapbox's own render() call. Capping here bounds both that crash and the wasted CPU/memory
 * of processing a feature list many orders of magnitude larger than any real tile needs.
 */
private const val MAX_SYMBOL_INSTANCES_PER_TILE = 4096
/** Throttle repetitive draw/build logs (ms). */
private const val SYMBOL_DEBUG_LOG_INTERVAL_MS = 2_000L
private const val SYMBOL_SCREEN_PADDING_PX = 2f
/** Extra screen padding for text collision boxes (MapsGL JS default `textPadding` ≈ 6px). */
private const val TEXT_COLLISION_PADDING_PX = 6f
/**
 * Place-label collision box scale / padding. Larger than the generic text defaults so dense
 * city clusters cull more aggressively (fewer overlapping names at continental zooms).
 */
private const val PLACE_TEXT_COLLISION_SCALE = 0.9f
private const val PLACE_TEXT_COLLISION_PADDING_PX = 10f
/** Skip drawing faded symbol instances below this combined alpha (collision fade ghosts). */
private const val SYMBOL_MIN_DRAW_ALPHA = 0.06f
/**
 * Hide GLES text on MVT parent-tile fallbacks when the view is more than this many zoom levels
 * above the tile Z (upscaled parent labels cluster into unreadable smears).
 */
private const val TEXT_PARENT_TILE_MAX_ZOOM_GAP = 1.5
/** See emit()'s tile-uv-ownership-gate rule: a point outside its own tile by more than this
 * (in tile-widths) is someone else's tile's feature and must not be drawn from here. Must stay
 * far smaller than 1 tile-width: some sources (observed: admin.place_city at low zoom) pre-pad
 * point geometry with antimeridian wrap duplicates at lon±360°, which land at exactly ±1.0
 * tile-width in u/v. A point near either edge of its own tile sits within 1 tile-width of one of
 * these duplicates, so a margin anywhere close to 0.25 admits the duplicate too — same real-world
 * point, different tile x/local-u baked into its crossTileId, so cross-tile dedup never merges
 * them and the symbol placer fights itself over two "different" candidates for one label (this was
 * the actual mechanism behind the reported "stuck semi-faded / colliding text" bug at wide/low-zoom
 * views). Only float-rounding slop from the lon/lat->uv conversion needs covering here — a point
 * genuinely belongs to exactly one tile, no real edge-buffer is needed. */
private const val SYMBOL_TILE_UV_OWNERSHIP_MARGIN = 0.01f
internal const val SYMBOL_FLOATS_PER_INSTANCE = 17
private const val INSTANCE_STRIDE_BYTES = SYMBOL_FLOATS_PER_INSTANCE * 4
/** Full-unit UV rect used for icon-less custom-shader instances; see the `paint.icon.shader != null` branch below. */
private val SHADER_ONLY_UV_RECT = floatArrayOf(0f, 0f, 1f, 1f)

/** GLES custom-symbol path scales style pixel sizes; not exposed on the public style API. */
internal const val VECTOR_SYMBOL_GL_PIXEL_SCALE = 2.0f

/**
 * Origin for the shader `u_time` uniform, fixed once per process.
 *
 * Rule: shader-time-is-session-relative. `u_time` feeds trigonometry in two places — the built-in
 * spin in [SYMBOL_VERT] (`radians(a_rotation + u_spin * a_factor * u_time * u_spinDegPerSec)`) and any custom
 * [com.xweather.mapsgl.style.IconPaint.shader]. Uploading raw [SystemClock.elapsedRealtime] means the
 * argument scales with device uptime: on a phone up five days it reaches ~4.7e5, and at the default
 * -180 deg/sec the spin angle reaches ~1.5e6 radians, where a float32 ULP is ~0.125 rad (~7 deg). The
 * spatial terms a shader adds to that argument (a few radians at most) are then quantised away
 * entirely, so patterns collapse to a uniform, time-invariant value and spin advances in coarse steps.
 * Measuring from process start keeps the argument small for any realistic session, and matches the
 * elapsed-time semantics the JS SDK's shaders are written against.
 */
private val SYMBOL_TIME_ORIGIN_MS = SystemClock.elapsedRealtime()

private const val SYMBOL_VERT = """#version 310 es
precision highp float;
layout(location = 0) in vec2 a_quad;
layout(location = 1) in vec2 a_center;
layout(location = 2) in vec4 a_uv;
layout(location = 3) in vec4 a_color;
layout(location = 4) in vec2 a_half_size;
layout(location = 5) in vec2 a_center_off;
layout(location = 6) in float a_rotation;
layout(location = 7) in float a_factor;
layout(location = 8) in float a_random;
uniform mat4 u_mvp;
uniform float u_half_scale;
uniform int u_billboard;
uniform int u_rotateWithMap;
uniform float u_bearingRad;
uniform vec2 u_viewport;
uniform float u_time;
uniform float u_spin;
uniform float u_spinDegPerSec;
out vec2 v_tex;
out vec4 v_color;
out float v_factor;
out float v_random;
void main() {
    // Rule: pitch-rotate-independence (JS parity: paint.symbol.pitchWithMap/rotateWithMap are
    // independent axes). u_billboard already IS the pitch axis (billboard = !pitchWithMap): map-plane
    // mode naturally inherits map bearing via u_mvp, billboard mode naturally ignores it via
    // screen-pixel offsetting. A correction is only needed when u_rotateWithMap disagrees with what
    // that mode does for free.
    float bearingCorrection = 0.0;
    if (u_billboard != 0) {
        if (u_rotateWithMap != 0) bearingCorrection = u_bearingRad;
    } else {
        if (u_rotateWithMap == 0) bearingCorrection = -u_bearingRad;
    }
    // a_factor carries the cyclone spin direction (+1 northern, -1 southern, 0 = do not spin),
    // matching the JS `paint.icon.factor` the position-icon layers set. It defaults to 1.0, so a
    // spinning layer that does not set factor keeps its old single-direction behaviour.
    float rad = radians(a_rotation + u_spin * a_factor * u_time * u_spinDegPerSec) + bearingCorrection;
    float c = cos(rad);
    float s = sin(rad);
    mat2 rot = mat2(c, -s, s, c);
    vec2 corner = rot * (a_quad * a_half_size);
    vec2 rel = a_center_off + corner;
    if (u_billboard != 0) {
        vec4 anchor = u_mvp * vec4(a_center, 0.0, 1.0);
        vec2 pixel = a_center_off + corner;
        vec2 offsetNdc = vec2(pixel.x, -pixel.y) * vec2(2.0 / u_viewport.x, 2.0 / u_viewport.y) * anchor.w;
        gl_Position = vec4(anchor.xy + offsetNdc, anchor.z, anchor.w);
    } else {
        vec2 pos = a_center + rel * u_half_scale;
        gl_Position = u_mvp * vec4(pos, 0.0, 1.0);
    }
    vec2 t = a_quad * 0.5 + 0.5;
    v_tex = mix(a_uv.xy, a_uv.zw, t);
    v_color = a_color;
    v_factor = a_factor;
    v_random = a_random;
}
"""

private const val SYMBOL_FRAG = """#version 310 es
precision highp float;
uniform sampler2D u_sdfTex;
uniform sampler2D u_rasterTex;
uniform vec4 u_haloColor;
uniform float u_haloWidth;
uniform int u_raster_mode;
in vec2 v_tex;
in vec4 v_color;
out vec4 fragColor;
void main() {
    if (u_raster_mode != 0) {
        vec4 t = texture(u_rasterTex, v_tex);
        fragColor = vec4(t.rgb * v_color.rgb, t.a * v_color.a);
        if (fragColor.a < 0.05) discard;
        return;
    }
    float dist0 = texture(u_sdfTex, v_tex).r;
    const float INNER_EDGE = 0.8;
    float aa = max(fwidth(dist0), 0.001);
    float fillA = smoothstep(INNER_EDGE - aa, INNER_EDGE + aa, dist0);
    if (u_haloWidth > 0.0) {
        float strokeEdge = INNER_EDGE - u_haloWidth;
        float strokeA = smoothstep(strokeEdge - aa, strokeEdge + aa, dist0);
        float haloOnly = strokeA * (1.0 - fillA);
        vec3 rgb = mix(u_haloColor.rgb, v_color.rgb, fillA);
        // v_color.a carries the per-instance collision fade, so it must scale the halo as well as
        // the fill. This was `max(haloOnly * u_haloColor.a, fillA * v_color.a)`, taking the halo's
        // alpha from the uniform alone: a fading label kept a full-strength outline and lost only
        // its fill. With a dark fill under a white halo on a dark basemap the halo IS the visible
        // letterform, so labels popped in and out with no fade at all. The raster branch has always
        // faded the whole glyph (`t.a * v_color.a`); this matches it.
        float alpha = v_color.a * max(haloOnly * u_haloColor.a, fillA);
        fragColor = vec4(rgb, alpha);
    } else {
        fragColor = vec4(v_color.rgb, fillA * v_color.a);
    }
    if (fragColor.a < 0.05) discard;
}
"""

private data class SymbolInstanceMeta(
    val crossTileId: String,
    val rank: Float,
    /** Overrides the instance buffer's half-width/height for collision purposes only; NaN = none. */
    val collisionHalfWidthPx: Float = Float.NaN,
    val collisionHalfHeightPx: Float = Float.NaN,
    /**
     * Overrides the instance buffer's centre offset for collision purposes only; NaN = none. Set on
     * the one per-glyph SDF text instance that carries a label's collision box, so the box stays
     * centred on the label while the instance stays centred on its glyph — see the
     * collision-box-may-move-off-instance rule in [VectorSymbolScreenProjection].
     */
    val collisionCenterOffsetXPx: Float = Float.NaN,
    val collisionCenterOffsetYPx: Float = Float.NaN,
    /**
     * Intrinsic tie-break key for equal-ranked candidates; null falls back to [crossTileId].
     *
     * Required wherever identity comes from [VectorSymbolCrossTileIndex], whose ids are minted from
     * a discovery counter — see [VectorSymbolScreenPlacer.Candidate.sortKey].
     */
    val sortKey: String? = null,
    /** True for a stacked-text sibling line that must never become its own collision candidate. */
    val excludeFromCollision: Boolean = false,
    /**
     * Encoded map-time reveal (see [VectorMapTime]). [VectorMapTime.ALWAYS_VISIBLE] means the
     * instance is not gated by the playhead; otherwise hide when featureTime > mapTime.
     */
    val featureTime: Float = VectorMapTime.ALWAYS_VISIBLE,
)

private data class SymbolInstanceBatch(
    val sdf: FloatArray = FloatArray(0),
    val raster: FloatArray = FloatArray(0),
    val text: FloatArray = FloatArray(0),
    val sdfMeta: List<SymbolInstanceMeta> = emptyList(),
    val rasterMeta: List<SymbolInstanceMeta> = emptyList(),
    val textMeta: List<SymbolInstanceMeta> = emptyList(),
    /**
     * Per-glyph text instances for layers on the SDF text path
     * ([VectorSymbolPlacementDefaults.usesSdfText]). Separate from [text] because they sample a
     * different texture ([VectorTextSdfAtlas], bound to `u_sdfTex`) in a different shader mode, and
     * one label contributes many instances here where [text] gets exactly one.
     */
    val textSdf: FloatArray = FloatArray(0),
    val textSdfMeta: List<SymbolInstanceMeta> = emptyList(),
    /** Halo colour/width for [textSdf], resolved once per batch from the layer's text paint. */
    val textSdfHaloArgb: Int = 0,
    val textSdfHaloWidth: Float = 0f,
)

private data class CachedSymbolDrawBatch(
    val coord: TileCoord,
    val instances: SymbolInstanceBatch,
)

private data class SymbolDrawResult(
    val drawnCount: Int,
    val totalCount: Int,
    val batches: List<CachedSymbolDrawBatch>,
    /** Count of [batches] drawn from a coarser ancestor tile (via [allowParentFallback]) rather than
     * their own native-zoom tile. A coord counted in [drawnCount] this way still needs its real tile
     * to arrive — see the `needPrefetch` rule at this result's call site in `draw()`. */
    val fallbackCount: Int = 0,
)

/**
 * Rule: raw-vector-fast-path (Symbol port). Pure decision function (rule: testability), mirroring
 * [resolveRawCirclePathEligible]/[resolveRawFillPathEligible]. Unlike Circle's gate, this has no
 * `consumerCount == 1` restriction — follows Fill's generalized gate instead, since a Symbol source
 * commonly has 2 attached consumers (e.g. `fires-obs-icons` + `fires-obs-names` both reading
 * `climate.fire_obs`), and [VectorTileSource.rawPathEligibleForLayer] already requires every attached
 * consumer to agree before a shared source goes raw.
 *
 * `anchor`/`offset` have no raw evaluator — [com.xweather.mapsgl.types.Anchor] and
 * [com.xweather.mapsgl.types.AnchorOffset] are practically always [StyleValue.Constant] in real
 * configs, but a data-driven one must still fail closed rather than silently mis-render.
 *
 * Scoped to icon-only layers for now (`paint.text.isEmpty()`) — [buildInstancesRaw] has no text
 * counterpart to [VectorTextLayout.resolveStackedTextInstances] yet; both of this session's actual
 * memory-pressure layers (`fires-obs-icons`, `lightning-strikes-icons`) are icon-only, so this covers
 * the real-world case without the added risk of a from-scratch raw text-layout port. A layer with
 * text simply stays on the heavy [buildInstances] path, unaffected.
 */
internal fun resolveRawSymbolPathEligible(
    layerId: String,
    filter: Expression?,
    paint: SymbolLayerPaint,
): Boolean {
    if (paint.text.isNotEmpty()) return false
    if (TropicalDrawFilter.isTropicalTrackLineLayer(layerId)) return false
    val flatFilter = ExpressionFilterFlatten.flatten(filter)
    if (VectorLayerDrawFilterDefaults.effectiveFilter(layerId, flatFilter) != null) return false

    if (paint.icon.anchor is StyleValue.Expression || paint.icon.offset is StyleValue.Expression) return false

    val colorExprs = listOfNotNull(paint.fill?.color?.expressionValue, paint.stroke?.color?.expressionValue)
    val numberExprs = listOfNotNull(
        paint.icon.size?.expressionValue,
        paint.icon.factor?.expressionValue,
        paint.icon.rotationExpression.expressionValue,
        paint.fill?.opacity?.expressionValue,
        paint.stroke?.opacity?.expressionValue,
        paint.stroke?.thickness?.expressionValue,
    )
    val stringExprs = listOfNotNull(paint.icon.image?.expressionValue)
    return colorExprs.all { VectorCircleRawStyleEval.isSupportedColorExpression(it) } &&
        numberExprs.all { VectorCircleRawStyleEval.isSupportedNumberExpression(it) } &&
        stringExprs.all { VectorCircleRawStyleEval.isSupportedStringExpression(it) }
}

internal fun resolveSymbolIconHalfPx(
    paint: SymbolLayerPaint,
    feature: Feature,
    zoom: Double,
    densityMult: Float,
    layerId: String? = null,
): Float {
    val placement = VectorSymbolLayout.placement(paint, feature, zoom, densityMult, layerId)
    return VectorSymbolLayout.collisionHalfPx(placement)
}

internal fun hitTestSymbolIconLngLat(
    features: List<Feature>,
    coord: TileCoord,
    sourceLayer: String?,
    filter: Expression?,
    paint: SymbolLayerPaint,
    tapLon: Double,
    tapLat: Double,
    zoom: Double,
    densityMult: Float,
    tileOverscale: Float,
    minHitRadiusPx: Float = 12f,
    layerId: String? = null,
): List<Feature> {
    val z = coord.z
    val tx = coord.x
    val ty = coord.y
    val world = 1 shl z
    val (tu, tv) = VectorPolygonFillTriangulator.lonLatToTileUv(z, tx, ty, world, tapLon, tapLat)
    val overscale = tileOverscale.coerceAtLeast(1f)
    // Rule: nearest-symbol-first. Icon boxes are far wider than the gap between neighbouring
    // symbols — a tropical track's fixes sit closer together than one icon is wide — so a tap
    // routinely lands inside two or three boxes at once. Returning them in feature order handed the
    // caller whichever happened to come first in the source data, which along a storm track is
    // always the earlier fix: a tap plainly nearest advisory 4 reported advisory 3. Callers read
    // element 0, so order by how far the tap is from each icon's drawn centre and let the closest
    // win. Ties keep feature order, since sortedBy is stable.
    val hits = LinkedHashMap<Feature, Double>()
    for (f in features) {
        if (!VectorFeatureDrawFilter.shouldDraw(f, filter, layerId)) continue
        if (sourceLayer != null) {
            val tag = featureLayerTag(f)
            if (tag != null && tag != sourceLayer) continue
        }
        val placement = VectorSymbolLayout.placement(paint, f, zoom, densityMult, layerId)
        // Rule: tap-target-is-finger-sized. The drawn glyph is only ~40px across and neighbouring
        // fixes on a storm track sit closer together than that, so a tap a few pixels off an icon
        // matched nothing at all — and with no symbol to answer, the row fell through to the track
        // line beneath, which carries the *previous* fix's properties and so named the advisory
        // before the one being aimed at. [minHitRadiusPx] has been a parameter here from the start
        // and was never applied; honouring it makes the target forgiving enough to hit, and the
        // closest-first ordering below decides between the overlaps that creates.
        val hitHalfWidthPx = kotlin.math.max(placement.halfWidthPx, minHitRadiusPx)
        val hitHalfHeightPx = kotlin.math.max(placement.halfHeightPx, minHitRadiusPx)
        val scalePx = 512f * overscale
        /** Squared px distance from the tap to this icon's centre, or null when outside its box. */
        fun pointHitDistanceSq(lon: Double, lat: Double): Double? {
            val (cu, cv) = VectorPolygonFillTriangulator.lonLatToTileUv(z, tx, ty, world, lon, lat)
            val du = (tu - cu) * scalePx - placement.centerOffsetXPx / overscale
            val dv = (tv - cv) * scalePx - placement.centerOffsetYPx / overscale
            val rad = Math.toRadians(-placement.rotationDeg.toDouble())
            val cos = kotlin.math.cos(rad)
            val sin = kotlin.math.sin(rad)
            val lx = du * cos - dv * sin
            val ly = du * sin + dv * cos
            val inside = kotlin.math.abs(lx) <= hitHalfWidthPx && kotlin.math.abs(ly) <= hitHalfHeightPx
            // Rotation preserves distance, so measure before it.
            return if (inside) (du * du + dv * dv).toDouble() else null
        }
        fun record(distanceSq: Double) {
            val previous = hits[f]
            if (previous == null || distanceSq < previous) hits[f] = distanceSq
        }
        when (val g = f.geometry()) {
            is Point -> pointHitDistanceSq(g.longitude(), g.latitude())?.let { record(it) }
            is MultiPoint -> {
                // Nearest part of a multi-point represents the whole feature.
                for (p in g.coordinates()) {
                    pointHitDistanceSq(p.longitude(), p.latitude())?.let { record(it) }
                }
            }
            else -> {}
        }
    }
    return hits.entries.sortedBy { it.value }.map { it.key }
}

/**
 * Draws [SymbolLayerPaint] point icons as instanced SDF/raster quads and [TextPaint] labels as
 * rasterized glyphs in a Mapbox custom GL layer.
 */
class VectorSymbolLayerRenderer(
    override var id: String,
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {

    companion object {
        @Volatile
        private var sharedGlGeneration = 0

        fun onGlContextLost() {
            sharedGlGeneration++
            VectorRasterSpriteAtlas.onGlContextLost()
            VectorSpriteSdfAtlas.onGlContextLost()
            VectorTextAtlas.onGlContextLost()
        }
    }

    init {
        cachesTextures = false
    }

    override fun onAdd() {}
    override fun onAdd(tileLayer: TileLayer) {
        super.onAdd(tileLayer)
        MapsGLDebug.logI(
            VECTOR_SYMBOL_TAG,
            "onAdd layer=${tileLayer.id} source=${tileLayer.source.id} sourceLayer=${(tileLayer as? VectorTileLayer)?.sourceLayer}",
        )
        if (tileLayer is VectorTileLayer && tileLayer.glRenderingActive()) {
            tileLayer.externalScope.launch {
                MapsGLDebug.logD(VECTOR_SYMBOL_TAG, "prefetch start layer=${tileLayer.id}")
                tileLayer.prefetchVectorTilesForGlRendering()
                tileLayer.mapController?.redraw()
                MapsGLDebug.logD(VECTOR_SYMBOL_TAG, "prefetch done layer=${tileLayer.id}")
            }
        }
    }
    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {}

    /** Clears cached symbol instances after the timeline interval changes (scrub / phase advance). */
    internal fun invalidateTimelineInstanceCache() {
        instanceCache.clear()
        instanceInProgress.clear()
        lastSuccessfulBatches = emptyList()
        lastSuccessfulDrawIntervalMs = null
        pausedBatchCount = 0
        playbackFrozenBatches = emptyList()
        playbackFrozenIntervalMs = null
        screenPlacer.clear()
        gate.invalidate()
    }

    /** Rule: shared-playback-gate. Mirrors [VectorCircleLayerRenderer.beginPlaybackPrefetchGate]. */
    internal fun beginPlaybackPrefetchGate(layer: VectorTileLayer? = null) = gate.beginPlaybackPrefetchGate(layer)

    private var symbolGlProgram = 0
    private var symbolGlProgramVersion = 0
    private var boundGlGeneration = -1
    private var uMvp = -1
    private var uHalfScale = -1
    private var uBillboard = -1
    private var uRotateWithMap = -1
    private var uBearingRad = -1
    private var uViewport = -1
    private var uHaloColor = -1
    private var uHaloWidth = -1
    /** Halo state last applied from the layer paint, so the per-batch SDF-text override can be undone. */
    private var paintHaloWidth = 0f
    private val paintHaloColor = floatArrayOf(1f, 1f, 1f, 1f)
    private var uRasterMode = -1
    private var uTime = -1
    private var uDpr = -1
    private var uSpin = -1
    private var uSpinDegPerSec = -1
    /**
     * Whether a [ensureKeepRedrawing] tick chain is already running. Written `true` from the GL
     * thread (draw() -> ensureKeepRedrawing) and `false` from the main looper (the tick itself), so
     * it has to be @Volatile like [keepRedrawingNeeded] and [pendingBuildRedrawScheduled] — a stale
     * `false` read on the GL thread starts a SECOND chain, and since each chain reposts itself the
     * redraw posts multiply instead of staying at the intended one-tick-per-renderer (and
     * LayerCode.PLACES alone is four symbol renderers).
     */
    @Volatile
    private var keepRedrawingScheduled = false
    /** Set true whenever needPrefetch or requestCollisionContinuationRedraw() wants another frame;
     * read by [ensureKeepRedrawing]'s tick, which stops once this goes false. */
    @Volatile
    private var keepRedrawingNeeded = false
    /** Custom fragment shader source currently compiled into [symbolGlProgram]; null when using [SYMBOL_FRAG]. */
    private var compiledIconShaderSource: String? = null
    private var locTex = -1
    private var locRasterTex = -1
    private var sdfAtlasTex = 0
    private var rasterAtlasTex = 0
    private var vao = 0
    private var quadVbo = 0
    private var instanceVbo = 0
    private var instanceByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
    private val instanceDrawScratch = ArrayList<Float>(512)

    private val instanceCache = ConcurrentHashMap<String, SymbolInstanceBatch>()
    private val instanceInProgress: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val backgroundExecutor = Executors.newFixedThreadPool(SYMBOL_INSTANCE_BUILD_THREADS)
    private val screenPlacer = VectorSymbolScreenPlacer()
    private var lastDrawDebugLogMs = 0L
    private var lastBuildDebugLogMs = 0L
    private var lastWarnLogMs = 0L
    private var lastSuccessfulBatches: List<CachedSymbolDrawBatch> = emptyList()
    private val minPromotionCoverage = 0.55f
    private val zoomTransitionHoldMs = SYMBOL_ZOOM_TRANSITION_HOLD_MS
    private var lastZoomFloor: Int? = null
    private var holdLastBatchesUntilMs = 0L
    /**
     * Rule: incumbent-instance-represents-its-label. Tile zoom of the instance chosen to represent
     * each label last pass, so the next pass can recognise the incumbent and keep drawing the copy
     * already on screen. Rebuilt every pass by [dedupeCandidates], so it cannot outlive the labels.
     */
    private val chosenInstanceTileZById = HashMap<String, Int>(256)
    private var lastDrawPrefetchMs = 0L
    private var lastBuildRedrawMs = 0L
    @Volatile
    private var pendingBuildRedrawScheduled = false
    private var lastContinuationRedrawMs = 0L
    private var lastDrawMapZoom = Double.NaN
    private var cameraMapMoving = false
    /** Rule: shared-playback-gate. Generic gate-hold/warmup state machine; see [VectorPlaybackGateController]. */
    private val gate = VectorPlaybackGateController(id)
    private var lastSuccessfulDrawIntervalMs: Long? = null
    private var pausedBatchCount = 0
    private var playbackFrozenBatches: List<CachedSymbolDrawBatch> = emptyList()
    private var playbackFrozenIntervalMs: Long? = null
    // Grace period before a just-resumed playback session freezes lastSuccessfulBatches as a
    // fallback — avoids re-freezing on a debounced blip (e.g. a quick pause/resume). Mirrors circle's.
    private val playbackPlayEdgeDebounceMs = 400L
    private val playbackCoordsHoldMs = 750L
    private val gateHoldMvtRequestsPerWave = 16

    private fun symbolDebugLog(message: String, throttleMs: Long = SYMBOL_DEBUG_LOG_INTERVAL_MS) {
        if (!MapsGLDebug.enabled) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastDrawDebugLogMs < throttleMs) return
        lastDrawDebugLogMs = now
        MapsGLDebug.logD(VECTOR_SYMBOL_TAG, "[${tileLayer?.id ?: id}] $message")
    }

    private fun symbolBuildDebugLog(message: String) {
        if (!MapsGLDebug.enabled) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastBuildDebugLogMs < SYMBOL_DEBUG_LOG_INTERVAL_MS) return
        lastBuildDebugLogMs = now
        MapsGLDebug.logD(VECTOR_SYMBOL_TAG, "[${tileLayer?.id ?: id}] $message")
    }

    private fun symbolWarnLog(message: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastWarnLogMs < SYMBOL_DEBUG_LOG_INTERVAL_MS) return
        lastWarnLogMs = now
        Log.w(VECTOR_SYMBOL_TAG, "[${tileLayer?.id ?: id}] $message")
    }

    /**
     * Rule: pruning-to-referenced-keys. Mirrors Fill/Circle's [VectorTileSource.declareNeededPropertyKeys]
     * call so the shared tile parser only materializes attributes Symbol's paint/filter actually read,
     * instead of every MVT property on every feature. [SymbolRank.property] is a plain attribute-name
     * string (not an [Expression]), so it's added directly rather than via [ExpressionReferencedKeys].
     * Likewise, [VectorSymbolPlacementDefaults.additionalNeededPropertyKeys] covers the built-in
     * per-layer overrides (`fireObsIconSidePx`, `textFontSizePxOverride`) that read raw feature
     * properties directly rather than through any [StyleValue]/[Expression] this function can walk —
     * without this, those reads would see nothing once restriction actually takes effect.
     */
    private fun symbolNeededPropertyKeys(paint: SymbolLayerPaint, filter: Expression?, layerId: String?): Set<String> {
        val keys = ExpressionReferencedKeys.collect(
            filter,
            paint.icon.image?.expressionValue,
            paint.icon.size?.expressionValue,
            paint.icon.anchor.expressionValue,
            paint.icon.offset.expressionValue,
            paint.icon.factor?.expressionValue,
            paint.icon.rotationExpression.expressionValue,
            paint.fill?.color?.expressionValue,
            paint.fill?.opacity?.expressionValue,
            paint.stroke?.color?.expressionValue,
            paint.stroke?.opacity?.expressionValue,
            paint.stroke?.thickness?.expressionValue,
            *paint.text.flatMap {
                listOf(
                    it.value.expressionValue,
                    it.size?.expressionValue,
                    it.color.expressionValue,
                    it.outlineColor?.expressionValue,
                    it.weight?.expressionValue,
                    it.anchor.expressionValue,
                    it.offset.expressionValue,
                    it.rotation.expressionValue,
                )
            }.toTypedArray(),
        )
        val withRank = paint.rank?.property?.let { keys + it } ?: keys
        return withRank + VectorSymbolPlacementDefaults.additionalNeededPropertyKeys(layerId)
    }

    private fun syncGlContextGeneration() {
        if (boundGlGeneration == sharedGlGeneration) return
        boundGlGeneration = sharedGlGeneration
        if (symbolGlProgram != 0) {
            GLES31.glDeleteProgram(symbolGlProgram)
        }
        symbolGlProgram = 0
        sdfAtlasTex = 0
        rasterAtlasTex = 0
        instanceCache.clear()
        lastSuccessfulBatches = emptyList()
    }

    override fun setUpRenderPass(): RenderPass =
        EmptyRenderPass(tileLayer?.source?.id ?: id, tileLayer!!.paint)

    override fun prerender(context: LayerRenderContext<Any>) {}
    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {}
    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>, camera: Camera) {
        val layer = tileLayer as? VectorTileLayer ?: run {
            symbolDebugLog("draw exit: tileLayer is not VectorTileLayer", throttleMs = 0)
            return
        }
        val paint = layer.paint as? SymbolLayerPaint ?: run {
            symbolDebugLog("draw exit: paint is not SymbolLayerPaint", throttleMs = 0)
            return
        }
        val geo = layer.source as? GeoJSONSource
        val vts = layer.source as? VectorTileSource
        if (geo == null && vts == null) {
            symbolDebugLog("draw exit: source is neither GeoJSON nor VectorTile", throttleMs = 0)
            return
        }
        // Rule: shared-playback-gate. Mirrors VectorCircleLayerRenderer's per-frame interval
        // resolution AND its gate-hold/warmup-priming state machine (via the shared
        // VectorPlaybackGateController) so time-series symbol layers (e.g. lightning-strikes-icons)
        // both track the current timeline phase and get the same dedicated prefetch-ahead smoothing
        // circles have, instead of resolving/building each interval on demand as playback reaches it.
        val drawIntervalMs = vts?.let { vectorTileSourceDrawIntervalMs(tileLayer, it) }
        val exactInterval = vts != null && !Timeline.isGloballyPlaying && !vts.isTimeSeriesSource
        val nowMsEarly = SystemClock.elapsedRealtime()
        val playbackStable = Timeline.isGloballyPlaying
        if (!playbackStable) {
            gate.lastGloballyInactiveMs = nowMsEarly
        }
        if (gate.wasGloballyPlaying && !playbackStable) {
            gate.playbackWarmupComplete = true
            gate.initialPlaybackWarmupSatisfied = false
            playbackFrozenBatches = emptyList()
            playbackFrozenIntervalMs = null
            gate.warmupTilePrefetchJob?.cancel()
            gate.warmupTilePrefetchJob = null
        }
        val steadyStatePlaybackDraw =
            playbackStable &&
                vts != null &&
                vts.isTimeSeriesSource &&
                gate.playbackWarmupComplete &&
                gate.initialPlaybackWarmupSatisfied
        if (!steadyStatePlaybackDraw && !playbackStable) {
            gate.lastPlaybackViewportTileKeys = emptySet()
        }
        if (playbackStable && !gate.wasGloballyPlaying && vts?.isTimeSeriesSource == true && !gate.initialPlaybackWarmupSatisfied) {
            val playResumeGapMs = nowMsEarly - gate.lastGloballyInactiveMs
            if (playResumeGapMs >= playbackPlayEdgeDebounceMs) {
                pausedBatchCount = lastSuccessfulBatches.size
                playbackFrozenIntervalMs = drawIntervalMs
                playbackFrozenBatches = lastSuccessfulBatches
                gate.playbackWarmupComplete = false
                gate.warmupTilePrefetchJob?.cancel()
                gate.warmupTilePrefetchJob = null
            }
        }
        gate.wasGloballyPlaying = playbackStable

        val mapboxProj = CameraSync.mapboxProjectionMatrix
        val mapboxMv = CameraSync.mapboxModelViewMatrix
        val useMapboxNativeMv =
            mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
        val proj = if (useMapboxNativeMv) mapboxProj!! else projectionMatrixToFloatArray(camera.projectionMatrix)
        val mvCam = if (useMapboxNativeMv) mapboxMv!! else matrix4ToFloatArray(camera.viewMatrix)
        val mapZoomNow = CameraSync.zoomForCustomLayerInstancing()
        val zoom = mapZoomNow
        val densityMult = camera.dpiMult.coerceAtLeast(1e-3f)
        val opacity = paint.opacity.coerceIn(0f, 1f)
        val effectivePitchWithMap = VectorSymbolPlacementDefaults.pitchWithMapOverride(layer.id) ?: paint.pitchWithMap
        val effectiveRotateWithMap = VectorSymbolPlacementDefaults.rotateWithMapOverride(layer.id) ?: paint.rotateWithMap
        val screenBillboard = !effectivePitchWithMap
        val rotateWithMap = effectiveRotateWithMap
        val bearingDeg = (tileLayer?.mapController as? MapboxMapController)?.getBearing()?.toFloat() ?: 0f
        val viewportW = camera.resX.toFloat().coerceAtLeast(1f)
        val viewportH = camera.resY.toFloat().coerceAtLeast(1f)

        val ctx = tileLayer?.drawContext ?: run {
            symbolDebugLog("draw exit: drawContext is null", throttleMs = 0)
            return
        }
        VectorRasterSpriteAtlas.ensureLoading {
            instanceCache.clear()
            tileLayer?.mapController?.redraw()
        }
        syncGlContextGeneration()
        if (sdfAtlasTex != 0 && !GLES31.glIsTexture(sdfAtlasTex)) {
            onGlContextLost()
            syncGlContextGeneration()
        }
        ensureGlResources(ctx, paint.icon.shader)
        if (symbolGlProgram == 0) {
            symbolDebugLog("draw exit: symbolGlProgram=0 (shader init failed)")
            return
        }
        val textLayerZoomOpacity = VectorSymbolPlacementDefaults.textLayerZoomOpacity(id, mapZoomNow)
        val zoomDelta =
            if (lastDrawMapZoom.isFinite()) kotlin.math.abs(mapZoomNow - lastDrawMapZoom) else 0.0
        cameraMapMoving = zoomDelta > SYMBOL_CAMERA_ZOOM_EPSILON
        lastDrawMapZoom = mapZoomNow
        rasterAtlasTex = VectorRasterSpriteAtlas.ensureLoadedOnGlThread()
        if (rasterAtlasTex == 0) {
            // Rule: sdf-first-icon-lookup. Previously this bailed the *entire* draw call whenever
            // paint.icon.image was non-null and the raster atlas wasn't ready yet — but the SDF
            // atlas (local assets, synchronous) is checked first per feature (see lookupUvRect
            // below) and many layers (e.g. tropical cyclones, lightning) resolve every icon from it
            // and never touch the raster atlas at all. That blanket check starved pure-SDF layers of
            // any icons for as long as the raster atlas's CDN fetch was slow/blocked. Per-feature
            // resolution already degrades gracefully (skippedUv++, no crash) when an icon needs the
            // raster atlas and it isn't ready, so just register the ready-callback and keep drawing.
            VectorRasterSpriteAtlas.ensureLoading {
                instanceCache.clear()
                tileLayer?.mapController?.redraw()
            }
        }

        val styleKey = symbolStyleCacheKey(paint, zoom, layer.filter, layer.id)
        // Rule: pruning-to-referenced-keys. Recomputed every draw (cheap — walks a handful of small
        // expression trees, not per-feature), so a style/filter change takes effect on the next tile
        // fetch. Mirrors VectorCircleLayerRenderer/VectorFillLayerRenderer's identical calls.
        vts?.declareNeededPropertyKeys(layer.id, symbolNeededPropertyKeys(paint, layer.filter, layer.id))
        // Rule: raw-vector-fast-path (Symbol port). Recomputed every draw (cheap — no per-feature
        // cost), so a style/filter change takes effect on the next tile fetch, same as Fill/Circle.
        vts?.setRawPathEligible(
            layer.id,
            layer.sourceLayer,
            resolveRawSymbolPathEligible(layer.id, layer.filter, paint),
        )
        val tileLocal = FloatArray(16)
        val modelView = FloatArray(16)
        val mvp = FloatArray(16)

        GLES31.glUseProgram(symbolGlProgram)
        if (uRasterMode >= 0) GLES31.glUniform1i(uRasterMode, 0)
        GLES31.glEnable(GLES31.GL_BLEND)
        GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
        GLES31.glDisable(GLES31.GL_CULL_FACE)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, sdfAtlasTex)
        if (locTex >= 0) GLES31.glUniform1i(locTex, 0)
        GLES31.glActiveTexture(GLES31.GL_TEXTURE1)
        if (rasterAtlasTex != 0) {
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, rasterAtlasTex)
        }
        if (locRasterTex >= 0) GLES31.glUniform1i(locRasterTex, 1)
        applyHaloUniforms(paint, layer.id)
        if (uDpr >= 0) GLES31.glUniform1f(uDpr, ctx.resources.displayMetrics.density)

        val depthWas = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glBindVertexArray(vao)
        try {
            if (geo != null) {
                val rawFeatures = geo.data?.features()
                if (rawFeatures.isNullOrEmpty()) {
                    (tileLayer?.mapController as? MapboxMapController)?.ensureGeoJsonSourceDataLoaded(geo)
                    return
                }
                val dynamicMapTime = VectorFeatureDrawFilter.referencesMapTime(layer.id, layer.filter)
                val monotonicMapTime = VectorMapTime.usesMonotonicMapTimeReveal(layer.id, layer.filter)
                val features = rawFeatures.filter {
                    if (dynamicMapTime && monotonicMapTime) {
                        VectorFeatureDrawFilter.shouldDrawForGpuMapTimePrep(it, layer.filter, layer.id)
                    } else {
                        VectorFeatureDrawFilter.shouldDraw(it, layer.filter, layer.id)
                    }
                }
                if (features.isEmpty()) return
                val dataVersion = geo.geoJsonStencilSequence
                // Monotonic map-time keeps one resident batch; complex filters key by visible set.
                val mapTimeKey =
                    if (dynamicMapTime && !monotonicMapTime) geoJsonVisibleFeatureSetKey(features) else 0
                // `atlas...` is load-bearing, not decoration: instance FloatArrays bake glyph UVs at
                // build time, so a batch cached before an atlas reset or growth keeps pre-event UVs
                // and samples whatever glyph later landed at that texture location -- labels render
                // as fragments of other labels. The tiled key below already folds this in; the
                // GeoJSON key did not, so every GeoJSON-backed symbol layer (alerts, lightning, and
                // the data-query `*-text` layers, which publish to a private GeoJSON source) replayed
                // stale UVs after any atlas event. See VectorTextAtlas.atlasGeneration.
                val cacheKey =
                    "geojson|${geo.id}|$styleKey|$dataVersion|$mapTimeKey|symbol" +
                        "|v$SYMBOL_INSTANCE_CACHE_VERSION|atlas${VectorTextAtlas.currentGeneration()}"
                val worldCoord = TileCoord(0, 0, 0)
                var instances = instanceCache[cacheKey]
                if (instances == null) {
                    if (features.size <= GEOJSON_SYNC_INSTANCE_BUILD_MAX_FEATURES) {
                        instances = buildInstances(
                            features, worldCoord, null, layer.filter, paint, zoom, densityMult, opacity, layer.id,
                        )
                        putInstanceCache(cacheKey, instances)
                    } else if (instanceInProgress.add(cacheKey)) {
                        val bg = features
                        val captured = tileLayer
                        backgroundExecutor.submit {
                            try {
                                val built = buildInstances(
                                    bg, worldCoord, null, layer.filter, paint, zoom, densityMult, opacity, layer.id,
                                )
                                putInstanceCache(cacheKey, built)
                                if (!built.isEmpty()) requestRedrawAfterBuild(captured)
                            } finally {
                                instanceInProgress.remove(cacheKey)
                            }
                        }
                    }
                    if (instances == null) return
                }
                if (instances.isEmpty()) return
                val visible = filterBatchByMapTime(instances, layer.id, layer.filter)
                if (visible.isEmpty()) return
                val overscale = tileOverscaleForDraw(useMapboxNativeMv, mapZoomNow, worldCoord.z)
                // Rule: dateline-world-copy. Same GeoJSON instances, one draw per visible world copy.
                val geoWorldCoords = GeoJsonWorldCopies.visibleWorldCoords(tileLayer?.mapController)
                for (drawCoord in geoWorldCoords) {
                    val batchList = listOf(CachedSymbolDrawBatch(drawCoord, visible))
                    val drawOpacities = resolveDrawOpacities(
                        paint, batchList, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
                        proj, mvCam, tileLocal, modelView, mvp,
                        screenBillboard, viewportW, viewportH,
                    )
                    drawInstanceBatch(
                        visible, drawCoord, overscale, proj, mvCam, tileLocal, modelView, mvp,
                        screenBillboard, viewportW, viewportH, drawOpacities, mapZoomNow, textLayerZoomOpacity,
                        rotateWithMap, bearingDeg,
                    )
                }
                if (requestCollisionContinuationRedraw()) {
                    keepRedrawingNeeded = true
                    ensureKeepRedrawing()
                }
                return
            }

            val placeDataZoomCap = VectorSymbolPlacementDefaults.placeLabelMaxDataZoom(layer.id)
            val placeDataZoom =
                if (placeDataZoomCap != null) {
                    mapZoomNow.coerceAtMost(placeDataZoomCap)
                } else {
                    mapZoomNow
                }
            val visibleCoords =
                if (steadyStatePlaybackDraw) {
                    (tileLayer as TileLayer).visibleTileCoordsForGlVectorPlayback()
                } else if (placeDataZoomCap != null) {
                    (tileLayer as TileLayer).visibleTileCoordsForMapboxVectorCacheAtDataZoom(placeDataZoom)
                } else {
                    (tileLayer as TileLayer).visibleTileCoordsForMapboxVectorCache()
                }
            val fallbackCoords = if (visibleCoords.isEmpty()) {
                val zf = floor(placeDataZoom).toInt()
                    .coerceAtLeast(0)
                    .coerceAtMost(layer.source.maxZoom.toInt())
                val zCandidates = listOf(zf, zf - 1, zf + 1).distinct()
                var candidate: List<TileCoord> = emptyList()
                for (z in zCandidates) {
                    if (z < 0) continue
                    val cached = (tileLayer as TileLayer).cachedTileCoordsWithDataAtZInViewport(vts!!, z)
                    if (cached.isNotEmpty()) {
                        candidate = cached
                        break
                    }
                }
                if (candidate.isEmpty()) {
                    (tileLayer as TileLayer).viewportCenterTileCoordsForPrefetch()
                } else {
                    candidate
                }
            } else {
                emptyList()
            }
            val targetZoomFloor = floor(placeDataZoom).toInt()
                .coerceAtLeast(0)
                .coerceAtMost(layer.source.maxZoom.toInt())
            val nowMs = nowMsEarly
            if (lastZoomFloor == null || lastZoomFloor != targetZoomFloor) {
                holdLastBatchesUntilMs = nowMs + zoomTransitionHoldMs
                lastZoomFloor = targetZoomFloor
                // Rule: keep-fade-state-across-a-zoom-floor. Deliberately does NOT clear the placer.
                //
                // This used to call screenPlacer.clear() so that fade state from the previous zoom,
                // and any transient mega-boxes during the jump, could not permanently suppress
                // newly loaded in-tile majors via placement-visibility-boost. Every part of that
                // has since stopped applying: the visibility boost is gone, mega-boxes are clamped
                // at the projection and rejected by the collision grid, and label identity now
                // survives a zoom change instead of being derived from the tile it arrived in.
                //
                // Clearing had become the thing it was protecting against. Traced on a Pixel 9,
                // `places` at world zoom, double-tapping across a floor boundary: the drawn instance
                // count never dropped (1500-4000 throughout), but the camera stops moving within
                // ~230ms of the tap, so `snap` is false, and with every label's fade state wiped the
                // whole set animated up from zero. Text vanished and returned about a second later -
                // roughly 600ms of fade plus the tail of the 1000ms batch hold.
                //
                // Keeping the state means a label present at both zooms holds its opacity straight
                // through the boundary, which is the point of resolving identity by proximity.
            }
            val zoomTransitionHold = nowMs < holdLastBatchesUntilMs
            if (visibleCoords.isEmpty() && fallbackCoords.isEmpty() && lastSuccessfulBatches.isEmpty()) {
                symbolDebugLog(
                    "draw exit: no tile coords (visible=${visibleCoords.size} fallback=${fallbackCoords.size} zoom=$mapZoomNow)",
                )
                (tileLayer as? VectorTileLayer)?.let { vectorLayer ->
                    if (nowMs - lastDrawPrefetchMs >= SYMBOL_DRAW_PREFETCH_MIN_INTERVAL_MS) {
                        lastDrawPrefetchMs = nowMs
                        vectorLayer.externalScope.launch {
                            vectorLayer.prefetchVectorTilesForGlRendering()
                        }
                    }
                }
                return
            }

            // Rule: shared-playback-gate. Prefetch-ahead + gate-hold, mirroring
            // VectorCircleLayerRenderer.draw(). vts is non-null here (geo path already returned above).
            val gateCoords = gate.playbackGateCoords(layer, visibleCoords, fallbackCoords)
            if (playbackStable && vts!!.isTimeSeriesSource && gateCoords.isNotEmpty()) {
                gate.scheduleFullTimelineMvtPrefetch(layer, vts, gateCoords)
                gate.schedulePlaybackFramePreparation(
                    layer = layer,
                    vts = vts,
                    coords = gateCoords,
                    buildRefs = { coords, intervalMs ->
                        buildPlaybackSymbolRefsForInterval(
                            vts, layer, paint, zoom, densityMult, opacity, styleKey, coords, intervalMs,
                        )
                    },
                    isDrawable = { coord, snappedMs -> isSymbolPhaseDrawable(vts, layer, styleKey, coord, snappedMs) },
                    phaseStoreBlockers = { coords, snappedMs -> symbolPhaseStoreBlockers(vts, coords, snappedMs) },
                    gateBlockers = { coords -> summarizeSymbolGateBlockers(vts, coords) },
                    onRepaintNeeded = { tileLayer?.mapController?.redraw() },
                )
            }

            if (playbackStable && vts!!.isTimeSeriesSource && !gate.playbackWarmupComplete && !gate.initialPlaybackWarmupSatisfied) {
                Timeline.setGlVectorFillLayerPlaybackReady(layer.id, false)
                val warmupCoords = gateCoords
                if (warmupCoords.isEmpty()) {
                    return
                } else {
                    // Rule: shared-playback-gate. Unlike circle's equivalent synchronous check
                    // (VectorCircleLayerRenderer.draw(), same ambiguity noted in
                    // VectorPlaybackGateController's class doc), this must actually return here
                    // rather than fall through to the old on-demand drawSymbolCoords() path below —
                    // that path's cache key includes a map-time component that ticks every second
                    // for age-colored layers (e.g. lightning), and its churn was evicting gate-hold's
                    // freshly built refs from instanceCache before the next prep tick could see them,
                    // stalling the gate indefinitely (circle's on-demand key has no such component,
                    // so it never hit this).
                    val isDrawable = { coord: TileCoord, snappedMs: Long ->
                        isSymbolPhaseDrawable(vts, layer, styleKey, coord, snappedMs)
                    }
                    val gateOpened = gate.playbackGateAnchorPhaseA < 0 &&
                        gate.completePlaybackGateIfReady(layer, vts, warmupCoords, isDrawable)
                    if (!gateOpened) {
                        val frozen = playbackFrozenBatches.ifEmpty { lastSuccessfulBatches }
                        if (frozen.isNotEmpty()) {
                            val visibleFrozen = filterCachedBatchesByMapTime(frozen, layer.id, layer.filter)
                            if (visibleFrozen.isNotEmpty()) {
                                val drawOpacities = resolveDrawOpacities(
                                    paint, visibleFrozen, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
                                    proj, mvCam, tileLocal, modelView, mvp, screenBillboard, viewportW, viewportH,
                                )
                                drawCachedBatches(
                                    visibleFrozen, drawOpacities, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
                                    proj, mvCam, tileLocal, modelView, mvp, screenBillboard, viewportW, viewportH,
                                    rotateWithMap, bearingDeg,
                                )
                            }
                        }
                        return
                    }
                }
            }

            if (steadyStatePlaybackDraw && drawIntervalMs != null) {
                val snappedDraw = vts!!.snappedTimeSeriesIntervalMs(drawIntervalMs)
                val prebuilt = gate.refsForInterval(snappedDraw)
                val drewPlayback = prebuilt.isNotEmpty() && drawPlaybackSymbolRefs(
                    vts, prebuilt, paint, layer.id, layer.filter,
                    useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
                    proj, mvCam, tileLocal, modelView, mvp, screenBillboard, viewportW, viewportH,
                    rotateWithMap, bearingDeg,
                )
                if (!drewPlayback && lastSuccessfulBatches.isNotEmpty()) {
                    val visibleHold = filterCachedBatchesByMapTime(
                        lastSuccessfulBatches, layer.id, layer.filter,
                    )
                    if (visibleHold.isNotEmpty()) {
                        val drawOpacities = resolveDrawOpacities(
                            paint, visibleHold, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
                            proj, mvCam, tileLocal, modelView, mvp, screenBillboard, viewportW, viewportH,
                        )
                        drawCachedBatches(
                            visibleHold, drawOpacities, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
                            proj, mvCam, tileLocal, modelView, mvp, screenBillboard, viewportW, viewportH,
                            rotateWithMap, bearingDeg,
                        )
                    }
                } else if (drewPlayback) {
                    lastSuccessfulDrawIntervalMs = snappedDraw
                }
                return
            }

            fun drawSymbolCoords(
                coords: List<TileCoord>,
                allowParentFallback: Boolean,
                maxParentZoomGap: Int = 2,
            ): SymbolDrawResult {
                var drawnCount = 0
                var missingCache = 0
                var missingData = 0
                var emptyInstances = 0
                var pendingBuild = 0
                var fallbackCount = 0
                val resolveIntervalMs = drawIntervalMs?.let { phaseMs ->
                    if (vts!!.isTimeSeriesSource) vts.snappedTimeSeriesIntervalMs(phaseMs) else phaseMs
                }
                val captured = ArrayList<CachedSymbolDrawBatch>()
                val drawnTileKeys = HashSet<String>(coords.size.coerceAtLeast(4))
                for (coord in coords) {
                    val resolved = resolveCachedVectorTile(vts!!, coord, allowParentFallback, maxParentZoomGap)
                    if (resolved == null) {
                        missingCache++
                        continue
                    }
                    val cached = resolved.first
                    val drawCoord = resolved.second
                    val drawKey = "${drawCoord.z}/${drawCoord.x}/${drawCoord.y}/${drawCoord.offset}"
                    if (!drawnTileKeys.add(drawKey)) {
                        drawnCount++
                        continue
                    }
                    if (drawCoord.z != coord.z) fallbackCount++
                    // Rule: symbol-timeline-animation. cached.data holds a VectorTimeSeriesData
                    // container for time-series sources (e.g. lightning) rather than a plain
                    // VectorData — unwrap it to the interval currently being drawn, same as
                    // VectorCircleLayerRenderer.drawCoords().
                    val data = resolveVectorTileData(cached.data, resolveIntervalMs, exactInterval)
                    if (data == null) {
                        missingData++
                        continue
                    }
                    val (meshFp, modeTag) = symbolMeshFingerprint(data, layer.sourceLayer)
                    // Map-time layers keep one resident candidate batch per tile/interval;
                    // playhead gating happens in filterBatchByMapTime at draw.
                    val mapTimeKey = 0L
                    val triKey = symbolInstanceCacheKey(
                        drawCoord,
                        layer.sourceLayer,
                        styleKey,
                        meshFp,
                        mapTimeKey,
                        vts.validTime.time,
                        modeTag,
                    )
                    val instances = resolveSymbolInstances(vts, triKey)
                    if (instances == null) {
                        if (instanceInProgress.add(triKey)) {
                            val bgRawFeatures = data.rawFeatures
                            val bgFeatures = data.features
                            val bgCoord = drawCoord
                            val bgLayer = layer
                            val bgVts = vts
                            val capturedLayer = tileLayer
                            backgroundExecutor.submit {
                                try {
                                    // Rule: text-layers-never-use-raw-path. buildInstancesRaw is
                                    // icon-only (no VectorTextLayout port). Place points can sit in
                                    // rawFeatures (sibling OSM raw layers, or pre-gate cache) while
                                    // features lacks that sourceLayer — materialize Features first.
                                    val built = if (bgRawFeatures != null && paint.text.isEmpty()) {
                                        buildInstancesRaw(
                                            bgRawFeatures,
                                            bgCoord,
                                            bgLayer.sourceLayer,
                                            paint,
                                            zoom,
                                            densityMult,
                                            opacity,
                                            bgLayer.id,
                                        )
                                    } else {
                                        val textFeatures = featuresForSymbolTextBuild(
                                            bgFeatures,
                                            bgRawFeatures,
                                            bgCoord,
                                            bgLayer.sourceLayer,
                                        )
                                        buildInstances(
                                            textFeatures,
                                            bgCoord,
                                            bgLayer.sourceLayer,
                                            bgLayer.filter,
                                            paint,
                                            zoom,
                                            densityMult,
                                            opacity,
                                            bgLayer.id,
                                        )
                                    }
                                    putInstanceCache(triKey, built, bgVts)
                                    if (!built.isEmpty()) requestRedrawAfterBuild(capturedLayer)
                                } finally {
                                    instanceInProgress.remove(triKey)
                                }
                            }
                        }
                        val parentHeld = if (allowParentFallback && drawCoord == coord) {
                            lookupParentInstanceBatch(
                                vts!!, coord, layer, styleKey, resolveIntervalMs, exactInterval, maxParentZoomGap,
                            )
                        } else {
                            null
                        }
                        if (parentHeld != null) {
                            val (parentCoord, parentBatch) = parentHeld
                            drawnCount++
                            captured.add(CachedSymbolDrawBatch(parentCoord, parentBatch))
                            continue
                        }
                        pendingBuild++
                        continue
                    }
                    if (instances.isEmpty()) {
                        // Rule: cache-legitimately-empty-results. This coord genuinely resolved to "no
                        // symbols here" (see putInstanceCache) — that's a settled result, not a
                        // still-loading one, so it must count toward drawnCount like any other resolved
                        // coord. Nothing goes in captured since there's nothing to draw.
                        emptyInstances++
                        drawnCount++
                        continue
                    }
                    drawnCount++
                    captured.add(CachedSymbolDrawBatch(drawCoord, instances))
                }
                if (MapsGLDebug.enabled && (drawnCount == 0 && coords.isNotEmpty())) {
                    symbolDebugLog(
                        "drawSymbolCoords coords=${coords.size} missingCache=$missingCache missingData=$missingData " +
                            "pendingBuild=$pendingBuild emptyInstances=$emptyInstances zoom=$mapZoomNow parent=$allowParentFallback",
                    )
                }
                return SymbolDrawResult(drawnCount, coords.size, captured, fallbackCount)
            }

            // Parent fallback fills gaps while exact-z tiles load during a zoom-floor hold.
            // Place-capped layers must NOT fall back merely because holdover is empty (cold add):
            // that walked to cached z0/z1 world tiles and spent a long time rasterizing thousands
            // of place glyphs before real z4 tiles arrived. Uncapped layers may still use empty
            // holdover as a recovery signal. Parent walk itself is gap-limited in
            // [resolveCachedVectorTile] so we never promote a world tile under regional coords.
            val allowParentFallback =
                zoomTransitionHold || (placeDataZoomCap == null && lastSuccessfulBatches.isEmpty())
            val maxParentZoomGap = if (placeDataZoomCap != null) 1 else 2
            val primaryCoords = if (visibleCoords.isNotEmpty()) visibleCoords else fallbackCoords
            val primaryResult = drawSymbolCoords(primaryCoords, allowParentFallback, maxParentZoomGap)
            val primaryCoverage =
                if (primaryResult.totalCount > 0) {
                    primaryResult.drawnCount.toFloat() / primaryResult.totalCount.toFloat()
                } else {
                    0f
                }
            val primaryTextCount = symbolTextInstanceCount(primaryResult.batches)
            val heldTextCount = symbolTextInstanceCount(lastSuccessfulBatches)
            val placeCapFloor = placeDataZoomCap?.let { floor(it).toInt() }
            val primaryAtPlaceCap =
                placeCapFloor != null &&
                    primaryTextCount > 0 &&
                    primaryResult.batches.isNotEmpty() &&
                    primaryResult.batches.all { it.coord.z >= placeCapFloor }
            val heldCoarserThanPlaceCap =
                placeCapFloor != null &&
                    lastSuccessfulBatches.isNotEmpty() &&
                    lastSuccessfulBatches.any { it.coord.z < placeCapFloor }
            // Rule: below-cap-still-needs-refinement. primaryAtPlaceCap requires every batch's z to
            // already be AT the cap — structurally impossible while the camera's native zoom sits
            // BELOW placeCapFloor (e.g. a world-zoom jump to z=2 with placeCapFloor=4). At that
            // point there's no "coarse vs precise" distinction to protect: z<cap tiles already ARE
            // the finest detail available, exactly like an uncapped layer. Without this, once ANY
            // partial holdover (e.g. 5 of 6 concurrently-building world tiles) locks in and keeps
            // intersecting the (now-static) viewport, holdoverUsable stays true forever and NONE of
            // the other promotion clauses can fire — the 6th tile's already-built, already-cached
            // data sits ready-to-draw but permanently unpromoted. Observed live: place-city stuck
            // showing only part of the world's cities (e.g. missing the whole western hemisphere)
            // indefinitely at low zoom, confirmed unchanged after 20+ seconds.
            val belowPlaceCap =
                placeCapFloor != null &&
                    primaryResult.batches.isNotEmpty() &&
                    primaryResult.batches.all { it.coord.z < placeCapFloor }
            // Rule: place-cap-beats-coarse-holdover. Low-z OSM place tiles omit mid-tier cities
            // (Columbus) and a z2 USA holdover still carries hundreds of worldwide city/town
            // instances. Those compete in screen collision when overzoomed into Ohio, so Cleveland
            // (present in the z2 data!) loses and the state looks empty while Detroit/Toronto remain.
            // Also, the old ≥50% total-count gate never fired: coarse holdover instance counts dwarf
            // the regional z4 set. Once capped-z tiles have real text, take them immediately —
            // including during the brief zoom-floor hold.
            val promotePrimary = primaryResult.batches.isNotEmpty() && (
                // Don't lock in text-empty place batches after holdover was wiped — that left
                // place-city permanently blank (batches exist, zero glyphs) until another zoom.
                (lastSuccessfulBatches.isEmpty() && (placeCapFloor == null || primaryTextCount > 0)) ||
                    (primaryAtPlaceCap && (heldCoarserThanPlaceCap || !zoomTransitionHold)) ||
                    // Primary already has more concrete tiles than holdover (e.g. southern America
                    // finished building while northern holdover was exclusive) — take it even during
                    // the zoom-floor hold so whole tiles don't stay blank until the hold expires.
                    (
                        belowPlaceCap &&
                            primaryResult.fallbackCount == 0 &&
                            primaryResult.batches.size > lastSuccessfulBatches.size &&
                            primaryTextCount > heldTextCount
                        ) ||
                    (
                        (placeCapFloor == null || belowPlaceCap) &&
                            primaryResult.fallbackCount == 0 &&
                            !zoomTransitionHold &&
                            primaryCoverage >= minPromotionCoverage &&
                            primaryTextCount >= maxOf(1, (heldTextCount * 0.5f).toInt())
                        )
                )
            var batchesToDraw = emptyList<CachedSymbolDrawBatch>()
            // For place/text layers, "drew" means we actually have glyph instances — empty batches
            // must not satisfy the drewAny branches or we skip holdover/prefetch recovery.
            var drewAny = primaryResult.batches.isNotEmpty() &&
                (placeCapFloor == null || primaryTextCount > 0 || paint.text.isEmpty())
            // Rule: keep-holdover-across-zoom. Finer batches (zoom-out) and coarser batches
            // (zoom-in) both stay drawable while the new floor's tiles load. Positioning of finer
            // tiles is correct via [tileOverscaleForDraw] (underscale < 1). Reject only
            // geographically irrelevant or text-empty place holdover — wiping finer holdover left
            // place-city blank when parent fallback was also off.
            val holdoverUsable =
                lastSuccessfulBatches.isNotEmpty() &&
                    symbolBatchesIntersectViewport(lastSuccessfulBatches) &&
                    (placeCapFloor == null ||
                        paint.text.isEmpty() ||
                        symbolTextInstanceCount(lastSuccessfulBatches) > 0)
            fun takeMergedOrPrimary() {
                // Rule: merge-holdover-with-primary-extras. Exclusive holdover kept only the
                // previously successful tiles (e.g. North America after a USA-centered view) while
                // newly ready primary tiles for the rest of the viewport (southern South America)
                // sat unused — whole tiles looked blank even though logs reported drew/coverage from
                // the northern holdover alone. Merge by tile key (primary wins); drop holdover
                // ancestors of primary tiles so coarse USA z2 doesn't collide with Ohio z4.
                val merged = mergeSymbolBatches(primaryResult.batches, lastSuccessfulBatches)
                batchesToDraw = merged
                lastSuccessfulBatches = merged
                drewAny = merged.isNotEmpty()
            }
            if (zoomTransitionHold) {
                if (promotePrimary) {
                    if (placeCapFloor != null && heldCoarserThanPlaceCap) {
                        // Drop stale visibility-boost winners from the coarse USA holdover so
                        // regional place-cap labels can place into empty Ohio space.
                        screenPlacer.clear()
                    }
                    lastSuccessfulBatches = primaryResult.batches
                    batchesToDraw = primaryResult.batches
                } else if (holdoverUsable) {
                    takeMergedOrPrimary()
                } else if (drewAny) {
                    batchesToDraw = primaryResult.batches
                }
            } else {
                if (promotePrimary) {
                    if (placeCapFloor != null && heldCoarserThanPlaceCap) {
                        screenPlacer.clear()
                    }
                    lastSuccessfulBatches = primaryResult.batches
                    batchesToDraw = primaryResult.batches
                } else if (holdoverUsable) {
                    takeMergedOrPrimary()
                } else if (drewAny) {
                    lastSuccessfulBatches = primaryResult.batches
                    batchesToDraw = primaryResult.batches
                }
            }
            if (!holdoverUsable && lastSuccessfulBatches.isNotEmpty() && !promotePrimary) {
                // Drop geographically irrelevant holdover (e.g. western z2 tiles after jumping to Ohio)
                // so fallback/prefetch can populate the current viewport instead of drawing nothing
                // after overzoom UV cull strips every off-footprint label.
                lastSuccessfulBatches = emptyList()
            }
            // Safety net: never end a frame with nothing if we still have in-viewport holdover
            // (covers races where primary was non-empty but text-less and promote/hold branches
            // left batchesToDraw empty while lastSuccessful still has real labels).
            if (batchesToDraw.isEmpty() && holdoverUsable) {
                batchesToDraw = lastSuccessfulBatches
                drewAny = true
            }
            if (!drewAny && fallbackCoords.isNotEmpty() && fallbackCoords !== primaryCoords) {
                val fallbackResult = drawSymbolCoords(fallbackCoords, allowParentFallback, maxParentZoomGap)
                val fallbackCoverage =
                    if (fallbackResult.totalCount > 0) {
                        fallbackResult.drawnCount.toFloat() / fallbackResult.totalCount.toFloat()
                    } else {
                        0f
                    }
                val fallbackTextCount = symbolTextInstanceCount(fallbackResult.batches)
                val heldForFallback = symbolTextInstanceCount(lastSuccessfulBatches)
                val fallbackAtPlaceCap =
                    placeCapFloor != null &&
                        fallbackTextCount > 0 &&
                        fallbackResult.batches.isNotEmpty() &&
                        fallbackResult.batches.all { it.coord.z >= placeCapFloor }
                val promoteFallback = fallbackResult.batches.isNotEmpty() && (
                    (lastSuccessfulBatches.isEmpty() && (placeCapFloor == null || fallbackTextCount > 0)) ||
                        (fallbackAtPlaceCap && (heldCoarserThanPlaceCap || !zoomTransitionHold)) ||
                        (
                            placeCapFloor == null &&
                                fallbackResult.fallbackCount == 0 &&
                                !zoomTransitionHold &&
                                fallbackCoverage >= minPromotionCoverage &&
                                fallbackTextCount >= maxOf(1, (heldForFallback * 0.5f).toInt())
                            )
                    )
                val fallbackDrew = fallbackResult.batches.isNotEmpty()
                if (promoteFallback) {
                    lastSuccessfulBatches = fallbackResult.batches
                    batchesToDraw = fallbackResult.batches
                    drewAny = true
                } else if (lastSuccessfulBatches.isNotEmpty() &&
                    symbolBatchesIntersectViewport(lastSuccessfulBatches)
                ) {
                    batchesToDraw = lastSuccessfulBatches
                    drewAny = true
                } else if (fallbackDrew) {
                    lastSuccessfulBatches = fallbackResult.batches
                    batchesToDraw = fallbackResult.batches
                    drewAny = true
                }
            }
            if (batchesToDraw.isNotEmpty()) {
                val cullPlaceUv = placeDataZoomCap != null
                val visibleBatches = filterCachedBatchesByMapTime(batchesToDraw, layer.id, layer.filter)
                if (visibleBatches.isEmpty()) return
                val drawOpacities = resolveDrawOpacities(
                    paint, visibleBatches, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
                    proj, mvCam, tileLocal, modelView, mvp,
                    screenBillboard, viewportW, viewportH,
                    cullOverzoomedPlaceUv = cullPlaceUv,
                )
                drawCachedBatches(
                    visibleBatches, drawOpacities, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
                    proj, mvCam, tileLocal, modelView, mvp,
                    screenBillboard, viewportW, viewportH,
                    rotateWithMap, bearingDeg,
                    cullOverzoomedPlaceUv = cullPlaceUv,
                )
                if (requestCollisionContinuationRedraw()) {
                    keepRedrawingNeeded = true
                    ensureKeepRedrawing()
                }
            }
            // Rule: fallback-coverage-still-needs-prefetch. drawnCount alone can't tell a genuinely
            // native tile apart from one only resolved via allowParentFallback's coarser-ancestor
            // walk — a coord "drawn" that way still needs its own real tile. Without fallbackCount
            // here, drawnCount==totalCount goes true the instant every coord has *some* data (even
            // a placeholder), needPrefetch flips false, and the retry loop below stops nudging
            // draw() forward — stranding that coord on its coarse ancestor forever (see the
            // incomplete-coverage-keeps-redrawing rule below, which depends on this being correct).
            // Also keep prefetching when holdover/merge still leaves a primary viewport coord with
            // no drawn batch (blank southern-America tile while northern holdover reported coverage).
            fun coordCoveredByDrawn(coord: TileCoord): Boolean =
                batchesToDraw.any {
                    (it.coord.z == coord.z && it.coord.x == coord.x && it.coord.y == coord.y) ||
                        tileIsAncestorOf(it.coord, coord) ||
                        tileIsAncestorOf(coord, it.coord)
                }
            val primaryCoordsUncovered = primaryCoords.any { !coordCoveredByDrawn(it) }
            val needPrefetch = primaryResult.drawnCount < primaryResult.totalCount ||
                primaryResult.fallbackCount > 0 ||
                primaryCoordsUncovered
            symbolDebugLog(
                "draw MVT source=${vts!!.id} sourceLayer=${layer.sourceLayer} " +
                    "coords=${primaryCoords.size} drew=$drewAny hold=$zoomTransitionHold " +
                    "coverage=$primaryCoverage rasterTex=$rasterAtlasTex uvReady=${VectorRasterSpriteAtlas.isUvMapReady()} " +
                    "needPrefetch=$needPrefetch zoom=$mapZoomNow",
            )
            if (!drewAny) {
                symbolWarnLog(
                    "no symbols drawn coords=${primaryCoords.size} hold=$zoomTransitionHold rasterTex=$rasterAtlasTex",
                )
            }
            if (needPrefetch && nowMs - lastDrawPrefetchMs >= SYMBOL_DRAW_PREFETCH_MIN_INTERVAL_MS) {
                lastDrawPrefetchMs = nowMs
                val vectorLayer = tileLayer as? VectorTileLayer
                if (vectorLayer != null) {
                    vectorLayer.externalScope.launch {
                        vectorLayer.prefetchVectorTilesForGlRendering()
                    }
                }
            }
            // Rule: incomplete-coverage-keeps-redrawing. requestCollisionContinuationRedraw() above
            // only re-arms the render loop while the *placer's own fade* is mid-animation — once
            // whatever partial batch we DID get settles to its steady opacity, that check goes quiet.
            // But needPrefetch=true means some of this layer's tiles never arrived at all (e.g. one
            // native tile never made the earlier prefetch wave's cut), and draw() itself only runs
            // when Mapbox renders another frame. With nothing else re-arming it, the coarser
            // ancestor-fallback tiles those coords fall back to (see textTileFallbackOpacity) end up
            // rendered at a permanent partial opacity, colliding with the tiles that DID load — the
            // reported "stuck semi-faded / colliding text" bug. keepRedrawingNeeded + the coalesced
            // repaint tick (ensureKeepRedrawing) keep nudging Mapbox for another frame — reliably,
            // unlike a raw per-frame redraw() call — until every coord is actually covered.
            //
            // Both triggers have to be OR'd in here. A bare `keepRedrawingNeeded = needPrefetch`
            // silently stomped the `= true` that requestCollisionContinuationRedraw() set earlier in
            // this same draw() call: with coverage complete but a fade still in flight, this line
            // put the flag back to false, the tick saw it and stopped, and the fade froze part-way —
            // reintroducing exactly the stuck-semi-faded symptom described above.
            val keepRedrawingForFade = screenPlacer.needsContinuation()
            keepRedrawingNeeded = needPrefetch || keepRedrawingForFade
            if (keepRedrawingNeeded) {
                ensureKeepRedrawing()
            }
        } finally {
            GLES31.glBindVertexArray(0)
            GLES31.glUseProgram(0)
            if (depthWas) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }
    }

    private fun SymbolInstanceBatch.isEmpty(): Boolean =
        sdf.isEmpty() && raster.isEmpty() && text.isEmpty() && textSdf.isEmpty()

    private fun symbolTextInstanceCount(batches: List<CachedSymbolDrawBatch>): Int =
        batches.sumOf {
            // Both text paths count: this drives batch-promotion and holdover decisions ("did this
            // tile set actually bring labels?"), and an SDF-text layer has all of its labels in
            // textSdf and none in text, so counting only the latter would report zero and hold
            // stale batches forever.
            (it.instances.text.size + it.instances.textSdf.size) / SYMBOL_FLOATS_PER_INSTANCE
        }

    private fun symbolInstanceCacheKey(
        drawCoord: TileCoord,
        sourceLayer: String?,
        styleKey: Int,
        meshFp: Int,
        mapTimeKey: Long,
        sourceValidTimeKey: Long,
        modeTag: String = "feat",
    ): String =
        // Rule: atlas-grow-invalidates-baked-uv (see VectorTextAtlas.atlasGeneration's KDoc). A cached
        // batch bakes its glyphs' UV directly into its instance FloatArray at build time; folding the
        // current atlas generation into the key means a later atlas resize misses the old entry and
        // rebuilds against today's texture layout instead of replaying now-stale UV forever.
        "${drawCoord.z}/${drawCoord.x}/${drawCoord.y}|$sourceLayer|$styleKey|$meshFp|$mapTimeKey|$sourceValidTimeKey|symbol|$modeTag|v$SYMBOL_INSTANCE_CACHE_VERSION|atlas${VectorTextAtlas.currentGeneration()}"

    /**
     * Rule: raw-vector-fast-path (Symbol port). Fingerprint + mode-tag pair for [symbolInstanceCacheKey],
     * mirroring [VectorCircleLayerRenderer]'s `circleTriangulationKey` — the two fingerprint schemes are
     * computed completely differently, so the mode tag is cheap insurance against a collision.
     */
    private fun symbolMeshFingerprint(data: VectorData, sourceLayer: String?): Pair<Int, String> {
        val rawFeatures = data.rawFeatures
        return if (rawFeatures != null) {
            VectorPolygonFillTriangulator.meshCacheFingerprintRaw(rawFeatures, data.validTime.time) to "raw"
        } else {
            VectorPolygonFillTriangulator.meshCacheFingerprint(data.features, data.validTime.time, sourceLayer) to "feat"
        }
    }

    /** Rule: shared-playback-gate. Mirrors [VectorCircleLayerRenderer.protectedPlaybackTriKeys]. */
    private fun protectedSymbolInstanceTriKeys(): Set<String> {
        val keys = HashSet<String>()
        // Rule: playback-refs-thread-safety. See VectorPlaybackGateController.refsLock's KDoc.
        // Rule: pan-during-playback. See VectorFillLayerRenderer.protectedFillTriKeys's KDoc — only
        // protects entries tagged with the current generation, so a coords-restart's stale entries
        // become evictable immediately instead of staying pinned for the whole reprime.
        synchronized(gate.refsLock) {
            for ((intervalMs, refs) in gate.refsByIntervalMs) {
                if (gate.refsGeneration[intervalMs] != gate.playbackPrepGeneration) continue
                for (ref in refs) keys.add(ref.triKey)
            }
        }
        return keys
    }

    /** Serializes a [SymbolInstanceBatch] for the native symbol-mesh cache. Unlike Fill/Outline/
     * Circle/Heatmap's uniform float layout, each instance array pairs with a per-instance
     * crossTileId string (variable length) — DataOutputStream/DataInputStream keep the read/write
     * byte order trivially self-consistent since only this class ever interprets these bytes. */
    private fun serializeSymbolInstanceBatch(batch: SymbolInstanceBatch): ByteArray {
        val buf = java.io.ByteArrayOutputStream()
        java.io.DataOutputStream(buf).use { dos ->
            fun writeArray(floats: FloatArray, metas: List<SymbolInstanceMeta>) {
                dos.writeInt(floats.size)
                for (f in floats) dos.writeFloat(f)
                dos.writeInt(metas.size)
                for (m in metas) {
                    val idBytes = m.crossTileId.toByteArray(Charsets.UTF_8)
                    dos.writeInt(idBytes.size)
                    dos.write(idBytes)
                    dos.writeFloat(m.rank)
                    dos.writeFloat(m.collisionHalfWidthPx)
                    dos.writeFloat(m.collisionHalfHeightPx)
                    dos.writeBoolean(m.excludeFromCollision)
                    dos.writeFloat(m.featureTime)
                    dos.writeFloat(m.collisionCenterOffsetXPx)
                    dos.writeFloat(m.collisionCenterOffsetYPx)
                }
            }
            writeArray(batch.sdf, batch.sdfMeta)
            writeArray(batch.raster, batch.rasterMeta)
            writeArray(batch.text, batch.textMeta)
            // Appended, not versioned: bytes written before this field existed simply run out here,
            // and [deserializeSymbolInstanceBatch] already treats any read failure as a cache miss,
            // so a stale entry rebuilds instead of decoding into garbage.
            writeArray(batch.textSdf, batch.textSdfMeta)
            dos.writeInt(batch.textSdfHaloArgb)
            dos.writeFloat(batch.textSdfHaloWidth)
        }
        return buf.toByteArray()
    }

    private fun deserializeSymbolInstanceBatch(bytes: ByteArray): SymbolInstanceBatch? = try {
        java.io.DataInputStream(java.io.ByteArrayInputStream(bytes)).use { dis ->
            fun readArray(): Pair<FloatArray, List<SymbolInstanceMeta>> {
                val floats = FloatArray(dis.readInt()) { dis.readFloat() }
                val metaCount = dis.readInt()
                val metas = ArrayList<SymbolInstanceMeta>(metaCount)
                repeat(metaCount) {
                    val idBytes = ByteArray(dis.readInt())
                    dis.readFully(idBytes)
                    val rank = dis.readFloat()
                    val collisionHalfWidthPx = dis.readFloat()
                    val collisionHalfHeightPx = dis.readFloat()
                    val excludeFromCollision = dis.readBoolean()
                    val featureTime = dis.readFloat()
                    val collisionCenterOffsetXPx = dis.readFloat()
                    val collisionCenterOffsetYPx = dis.readFloat()
                    metas.add(
                        // Named rather than positional: this constructor has grown twice now, and
                        // silently mapping the wrong field onto the wrong parameter is exactly the
                        // failure a positional call invites.
                        SymbolInstanceMeta(
                            crossTileId = String(idBytes, Charsets.UTF_8),
                            rank = rank,
                            collisionHalfWidthPx = collisionHalfWidthPx,
                            collisionHalfHeightPx = collisionHalfHeightPx,
                            collisionCenterOffsetXPx = collisionCenterOffsetXPx,
                            collisionCenterOffsetYPx = collisionCenterOffsetYPx,
                            excludeFromCollision = excludeFromCollision,
                            featureTime = featureTime,
                        ),
                    )
                }
                return floats to metas
            }
            val (sdf, sdfMeta) = readArray()
            val (raster, rasterMeta) = readArray()
            val (text, textMeta) = readArray()
            val (textSdf, textSdfMeta) = readArray()
            val haloArgb = dis.readInt()
            val haloWidth = dis.readFloat()
            SymbolInstanceBatch(
                sdf, raster, text, sdfMeta, rasterMeta, textMeta,
                textSdf, textSdfMeta, haloArgb, haloWidth,
            )
        }
    } catch (t: Throwable) {
        Log.w(VECTOR_SYMBOL_TAG, "deserializeSymbolInstanceBatch failed, treating as cache miss", t)
        null
    }

    /** Mirrors [VectorCircleLayerRenderer.resolveCircleMesh] — JVM hot cache first, then the native
     * symbol-mesh cache (populated by a prior tile-based [putInstanceCache] call). Native caching
     * only applies to tile-based (time-series) sources; GeoJSON symbol sources have no [VectorTileSource]. */
    private fun resolveSymbolInstances(vts: VectorTileSource, triKey: String): SymbolInstanceBatch? {
        instanceCache[triKey]?.let { return it }
        val bytes = vts.getSymbolInstancesNative(triKey) ?: return null
        val batch = deserializeSymbolInstanceBatch(bytes) ?: return null
        instanceCache[triKey] = batch
        return batch
    }

    private fun putInstanceCache(key: String, batch: SymbolInstanceBatch, vts: VectorTileSource? = null) {
        // Rule: cache-legitimately-empty-results. A tile with zero city/town-class features (common —
        // most tiles at typical zoom have no matching place) used to be dropped here entirely, so
        // resolveSymbolInstances() kept returning null for it forever: instanceInProgress rebuilt it on
        // every redraw with no way to ever mark it resolved, permanently counting it under
        // pendingBuild/missingCache. Because that coord's *own* status never settled, draw()'s coverage
        // check (drawnCount == totalCount) never reached 100%, needPrefetch never went false, and the
        // coarser ancestor-fallback tile serving that screen area (see textTileFallbackOpacity) was
        // never retired — an empty native-labeled patch of ocean/countryside kept showing whatever
        // far-flung city names the fallback's much-bigger tile happened to carry. Skip only the costly
        // native serialization for an empty result, not the (cheap) fact that it resolved to "nothing".
        if (!batch.isEmpty()) {
            vts?.putSymbolInstancesNative(key, serializeSymbolInstanceBatch(batch))
        }
        // Rule: shared-playback-gate. The old on-demand path below keeps running during gate-hold
        // warmup (same ambiguity as VectorCircleLayerRenderer's synchronous gate check) and its
        // triKey includes a map-time component that changes every second for age-colored layers
        // (e.g. lightning). Without protection, its churn evicts gate-hold's freshly built refs from
        // this bounded cache before schedulePlaybackFramePreparation's next tick can see them,
        // stalling gate-hold indefinitely. Mirrors VectorCircleLayerRenderer.trimTriangulationCacheIfNeeded.
        val protected = if (Timeline.isGloballyPlaying) protectedSymbolInstanceTriKeys() else emptySet()
        val maxEntries = if (Timeline.isGloballyPlaying) {
            maxOf(MAX_SYMBOL_INSTANCE_CACHE_ENTRIES, protected.size + 32)
        } else {
            MAX_SYMBOL_INSTANCE_CACHE_ENTRIES
        }
        while (instanceCache.size >= maxEntries) {
            val oldest = instanceCache.keys.firstOrNull { it !in protected } ?: break
            instanceCache.remove(oldest)
        }
        instanceCache[key] = batch
    }

    /**
     * Resolves MVT data for [coord], walking up to parent tiles when the exact z/x/y is not cached yet.
     * Returns the cached tile and the coord to use for matrix/instance space (may be a parent tile).
     */
    private fun lookupParentInstanceBatch(
        vts: VectorTileSource,
        coord: TileCoord,
        layer: VectorTileLayer,
        styleKey: Int,
        resolveIntervalMs: Long?,
        exactInterval: Boolean,
        maxParentZoomGap: Int = 2,
    ): Pair<TileCoord, SymbolInstanceBatch>? {
        var z = coord.z
        var x = coord.x
        var y = coord.y
        var gap = 0
        while (z > 0 && gap < maxParentZoomGap) {
            z--
            x = x shr 1
            y = y shr 1
            gap++
            val cached = vts.findCachedVectorTileForNominalZxy(z, x, y, true) ?: continue
            val data = resolveVectorTileData(cached.data, resolveIntervalMs, exactInterval) ?: continue
            val (meshFp, modeTag) = symbolMeshFingerprint(data, layer.sourceLayer)
            val triKey = symbolInstanceCacheKey(
                TileCoord(x, y, z),
                layer.sourceLayer,
                styleKey,
                meshFp,
                mapTimeKey = 0L,
                sourceValidTimeKey = vts.validTime.time,
                modeTag = modeTag,
            )
            val batch = resolveSymbolInstances(vts, triKey)
            if (batch != null && !batch.isEmpty()) {
                return TileCoord(x, y, z) to batch
            }
        }
        return null
    }

    /**
     * Rule: shared-playback-gate. [VectorPlaybackGateController.schedulePlaybackFramePreparation]'s
     * `buildRefs` hook for symbols — the per-interval counterpart to
     * [VectorCircleLayerRenderer.buildPlaybackCircleRefsForInterval]. Builds (or reuses a cached)
     * [SymbolInstanceBatch] per coord for [intervalMs] and wraps it as a [VectorPlaybackMeshRef].
     * Runs on a background dispatcher already (called from the controller's coroutine), so
     * [buildInstances] is called synchronously here rather than submitted to [backgroundExecutor].
     */
    private suspend fun buildPlaybackSymbolRefsForInterval(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        paint: SymbolLayerPaint,
        zoom: Double,
        densityMult: Float,
        opacity: Float,
        styleKey: Int,
        coords: List<TileCoord>,
        intervalMs: Long,
    ): List<VectorPlaybackMeshRef> {
        if (coords.isEmpty()) return emptyList()
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        return coroutineScope {
            coords.map { coord ->
                async(Dispatchers.Default) {
                    if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) return@async null
                    gate.ensurePhaseDataParsed(vts, coord, snappedMs)
                    val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
                        ?: return@async null
                    val data = resolveVectorTileData(cached.data, snappedMs, exactInterval = true) as? VectorData
                        ?: return@async null
                    val rawFeatures = data.rawFeatures
                    val textFeatures = if (paint.text.isNotEmpty()) {
                        featuresForSymbolTextBuild(data.features, rawFeatures, coord, layer.sourceLayer)
                    } else {
                        data.features
                    }
                    val drawableFeatures = if (rawFeatures != null && paint.text.isEmpty()) {
                        emptyList()
                    } else {
                        val dynamicMapTime = VectorFeatureDrawFilter.referencesMapTime(layer.id, layer.filter)
                        textFeatures.filter {
                            if (dynamicMapTime) {
                                VectorFeatureDrawFilter.shouldDrawForGpuMapTimePrep(it, layer.filter, layer.id)
                            } else {
                                VectorFeatureDrawFilter.shouldDraw(it, layer.filter, layer.id, mapTimeMs = snappedMs)
                            }
                        }
                    }
                    if (rawFeatures != null && paint.text.isEmpty()) {
                        if (rawPhaseVacuouslyReady(rawFeatures)) return@async null
                    } else if (drawableFeatures.isEmpty()) {
                        return@async null
                    }
                    val (meshFp, modeTag) = symbolMeshFingerprint(data, layer.sourceLayer)
                    // Rule: shared-playback-gate. Use the resolved interval's own (stable)
                    // data.validTime, not the source's live vts.validTime (which advances every
                    // frame during playback) — otherwise a build cached under one snapshot's key
                    // never matches a later isDrawable check's key, and the phase never commits.
                    // Mirrors VectorCircleLayerRenderer.circleTriangulationKey's use of data.validTime.
                    val triKey =
                        symbolInstanceCacheKey(coord, layer.sourceLayer, styleKey, meshFp, 0L, data.validTime.time, modeTag)
                    val existing = resolveSymbolInstances(vts, triKey)
                    val built = existing ?: (
                        if (rawFeatures != null && paint.text.isEmpty()) {
                            buildInstancesRaw(rawFeatures, coord, layer.sourceLayer, paint, zoom, densityMult, opacity, layer.id)
                        } else {
                            buildInstances(
                                drawableFeatures, coord, layer.sourceLayer, layer.filter, paint, zoom, densityMult,
                                opacity, layer.id,
                            )
                        }
                        ).also { putInstanceCache(triKey, it, vts) }
                    if (built.isEmpty()) return@async null
                    VectorPlaybackMeshRef(coord, triKey, opacity)
                }
            }.awaitAll().filterNotNull()
        }
    }

    /**
     * Rule: shared-playback-gate. `isDrawable` hook — true when (coord, snappedMs) already has cached
     * instances, is vacuously empty (no drawable features, nothing to build), or has a build in
     * progress. Mirrors [VectorCircleLayerRenderer.isPlaybackPhaseDrawable]'s outer shape. Rule:
     * raw-vector-fast-path (Symbol port) — reuses [rawPhaseVacuouslyReady] for the raw-mode vacuous
     * check, same as circle.
     */
    private fun isSymbolPhaseDrawable(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        styleKey: Int,
        coord: TileCoord,
        snappedMs: Long,
    ): Boolean {
        if (vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs)) return false
        if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) return false
        val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: return false
        val data = resolveVectorTileData(cached.data, snappedMs, exactInterval = true) as? VectorData ?: return false
        val textLayer = (layer.paint as? SymbolLayerPaint)?.text?.isNotEmpty() == true
        val rawFeatures = data.rawFeatures
        if (rawFeatures != null && !textLayer) {
            if (rawPhaseVacuouslyReady(rawFeatures)) return true
        } else {
            val textFeatures = featuresForSymbolTextBuild(data.features, rawFeatures, coord, layer.sourceLayer)
            val drawableFeatures = textFeatures.filter {
                VectorFeatureDrawFilter.shouldDraw(it, layer.filter, layer.id, mapTimeMs = snappedMs)
            }
            if (drawableFeatures.isEmpty()) return true
        }
        val (meshFp, modeTag) = symbolMeshFingerprint(data, layer.sourceLayer)
        // Rule: shared-playback-gate. data.validTime (stable per interval), not vts.validTime — see
        // buildPlaybackSymbolRefsForInterval.
        val triKey = symbolInstanceCacheKey(coord, layer.sourceLayer, styleKey, meshFp, 0L, data.validTime.time, modeTag)
        if (resolveSymbolInstances(vts, triKey) != null) return true
        val prefix = "${coord.z}/${coord.x}/${coord.y}|${layer.sourceLayer ?: ""}|$styleKey|"
        return instanceInProgress.any { it.startsWith(prefix) }
    }

    /** Rule: shared-playback-gate. Lightweight diagnostic-string hooks (no DOWNLOADING/NO_DATA/NO_MESH
     * taxonomy like circle's — build failures here are much less common since there's no raw-mode split). */
    private fun symbolPhaseStoreBlockers(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        snappedMs: Long,
    ): List<String> = coords.mapNotNull { coord ->
        when {
            vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs) ->
                "${coord.z}/${coord.x}/${coord.y} downloading"
            !vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs) ->
                "${coord.z}/${coord.x}/${coord.y} no interval"
            !vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, snappedMs) ->
                "${coord.z}/${coord.x}/${coord.y} no data"
            else -> "${coord.z}/${coord.x}/${coord.y} no instances"
        }
    }

    private fun summarizeSymbolGateBlockers(vts: VectorTileSource, coords: List<TileCoord>): List<String> {
        val allPhases = gate.allTimelinePhaseEpochMs(vts)
        val blockers = ArrayList<String>(8)
        for (snappedMs in allPhases) {
            if (!gate.refsByIntervalMs.containsKey(snappedMs)) {
                val coordBlockers = symbolPhaseStoreBlockers(vts, coords, snappedMs)
                if (coordBlockers.isNotEmpty()) {
                    blockers.add("phase $snappedMs: ${coordBlockers.take(3).joinToString()}")
                } else {
                    blockers.add("phase $snappedMs missing refs")
                }
                if (blockers.size >= 8) break
            }
        }
        return blockers
    }

    /**
     * Rule: shared-playback-gate. Resolves prebuilt [VectorPlaybackMeshRef]s to [CachedSymbolDrawBatch]es
     * and draws them via the existing (unchanged) [resolveDrawOpacities]/[drawCachedBatches] — collision
     * and fade always run fresh, per-frame, on whichever interval is current. Pre-warming only
     * populates [instanceCache] ahead of the playhead; it never runs collision speculatively.
     */
    private fun drawPlaybackSymbolRefs(
        vts: VectorTileSource,
        refs: List<VectorPlaybackMeshRef>,
        paint: SymbolLayerPaint,
        layerId: String?,
        filter: Expression?,
        useMapboxNativeMv: Boolean,
        mapZoomNow: Double,
        textLayerZoomOpacity: Float,
        proj: FloatArray,
        mvCam: FloatArray,
        tileLocal: FloatArray,
        modelView: FloatArray,
        mvp: FloatArray,
        screenBillboard: Boolean,
        viewportW: Float,
        viewportH: Float,
        rotateWithMap: Boolean,
        bearingDeg: Float,
    ): Boolean {
        val batches = refs.mapNotNull { ref ->
            val instances = resolveSymbolInstances(vts, ref.triKey) ?: return@mapNotNull null
            if (instances.isEmpty()) return@mapNotNull null
            CachedSymbolDrawBatch(ref.coord, instances)
        }
        if (batches.isEmpty()) return false
        val visibleBatches = filterCachedBatchesByMapTime(batches, layerId, filter)
        if (visibleBatches.isEmpty()) return false
        val drawOpacities = resolveDrawOpacities(
            paint, visibleBatches, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
            proj, mvCam, tileLocal, modelView, mvp, screenBillboard, viewportW, viewportH,
        )
        val drew = drawCachedBatches(
            visibleBatches, drawOpacities, useMapboxNativeMv, mapZoomNow, textLayerZoomOpacity,
            proj, mvCam, tileLocal, modelView, mvp, screenBillboard, viewportW, viewportH,
            rotateWithMap, bearingDeg,
        )
        if (requestCollisionContinuationRedraw()) {
            keepRedrawingNeeded = true
            ensureKeepRedrawing()
        }
        lastSuccessfulBatches = batches
        return drew
    }

    private fun resolveCachedVectorTile(
        vts: VectorTileSource,
        coord: TileCoord,
        allowParentFallback: Boolean,
        maxParentZoomGap: Int = 2,
    ): Pair<Tile<VectorData>, TileCoord>? {
        vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)?.let { tile ->
            return tile to coord
        }
        if (!allowParentFallback) return null
        var z = coord.z
        var x = coord.x
        var y = coord.y
        var gap = 0
        while (z > 0 && gap < maxParentZoomGap) {
            z--
            x = x shr 1
            y = y shr 1
            gap++
            vts.findCachedVectorTileForNominalZxy(z, x, y, true)?.let { tile ->
                return tile to TileCoord(x, y, z, coord.offset)
            }
        }
        return null
    }

    /**
     * Viewport footprint in a parent tile's 0..1 UV space. Used to cull overzoomed place-label
     * holdovers so worldwide cities from a z2 tile don't enter screen collision for a regional view.
     */
    private fun visibleTileUvAabb(coord: TileCoord): FloatArray? {
        val b = (tileLayer as? TileLayer)?.bounds ?: return null
        val world = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
        var u0 = Float.POSITIVE_INFINITY
        var v0 = Float.POSITIVE_INFINITY
        var u1 = Float.NEGATIVE_INFINITY
        var v1 = Float.NEGATIVE_INFINITY
        val lons = doubleArrayOf(b.westExtent, b.westExtent, b.eastExtent, b.eastExtent)
        val lats = doubleArrayOf(b.southExtent, b.northExtent, b.southExtent, b.northExtent)
        for (i in 0 until 4) {
            val (u, v) = VectorPolygonFillTriangulator.lonLatToTileUv(
                coord.z, coord.x, coord.y, world, lons[i], lats[i],
            )
            u0 = minOf(u0, u)
            v0 = minOf(v0, v)
            u1 = maxOf(u1, u)
            v1 = maxOf(v1, v)
        }
        if (!u0.isFinite() || !v0.isFinite() || !u1.isFinite() || !v1.isFinite()) return null
        val margin = 0.03f
        return floatArrayOf(u0 - margin, v0 - margin, u1 + margin, v1 + margin)
    }

    /** True when any batch tile's geographic footprint overlaps the current layer viewport. */
    private fun symbolBatchesIntersectViewport(batches: List<CachedSymbolDrawBatch>): Boolean {
        if (batches.isEmpty()) return false
        val b = (tileLayer as? TileLayer)?.bounds ?: return true
        for (batch in batches) {
            val c = batch.coord
            val n = powerTableI.getOrElse(c.z) { 1 shl c.z }.toDouble()
            val west = c.x / n * 360.0 - 180.0
            val east = (c.x + 1) / n * 360.0 - 180.0
            val nLat = mercatorYToLat(c.y / n)
            val sLat = mercatorYToLat((c.y + 1) / n)
            val south = minOf(nLat, sLat)
            val north = maxOf(nLat, sLat)
            if (west <= b.eastExtent && east >= b.westExtent &&
                south <= b.northExtent && north >= b.southExtent
            ) {
                return true
            }
        }
        return false
    }

    private fun symbolBatchKey(coord: TileCoord): String =
        "${coord.z}/${coord.x}/${coord.y}/${coord.offset}"

    /** True when [ancestor] is a coarser pyramid parent of [child] (same column of the quadtree). */
    private fun tileIsAncestorOf(ancestor: TileCoord, child: TileCoord): Boolean {
        if (ancestor.z >= child.z) return false
        val dz = child.z - ancestor.z
        return (child.x shr dz) == ancestor.x && (child.y shr dz) == ancestor.y
    }

    /**
     * Rule: merge-holdover-with-primary-extras. Union holdover + primary by tile key (primary wins).
     * Drop holdover tiles that are ancestors of any primary tile so a coarse USA holdover doesn't
     * keep colliding with newly arrived regional place-cap tiles. Same-z neighbors (N vs S America)
     * both survive — that was the blank-southern-tiles bug while scrolling.
     */
    private fun mergeSymbolBatches(
        primary: List<CachedSymbolDrawBatch>,
        holdover: List<CachedSymbolDrawBatch>,
    ): List<CachedSymbolDrawBatch> {
        if (primary.isEmpty()) return holdover.filter { !it.instances.isEmpty() }
        if (holdover.isEmpty()) return primary.filter { !it.instances.isEmpty() }
        val primaryTiles = primary.map { it.coord }
        val byKey = LinkedHashMap<String, CachedSymbolDrawBatch>(primary.size + holdover.size)
        for (batch in holdover) {
            if (batch.instances.isEmpty()) continue
            if (primaryTiles.any { tileIsAncestorOf(batch.coord, it) }) continue
            byKey[symbolBatchKey(batch.coord)] = batch
        }
        for (batch in primary) {
            if (batch.instances.isEmpty()) continue
            byKey[symbolBatchKey(batch.coord)] = batch
        }
        return byKey.values.toList()
    }

    private fun mercatorYToLat(yNorm: Double): Double {
        val n = Math.PI - 2.0 * Math.PI * yNorm.coerceIn(0.0, 1.0)
        return Math.toDegrees(Math.atan(Math.sinh(n)))
    }

    /**
     * Rule: allow-underscale-on-zoom-out. [CameraSync.tileRasterOverscale] is `2^(mapZoom-tileZ)`.
     * Parent-tile fallback (tileZ < mapZoom) needs overscale > 1; zoom-out holdover/fallback that
     * still draws a finer tile (tileZ > mapZoom) needs overscale < 1 so [tileLocal] shrinks that
     * tile into the coarser camera frame. The old `.coerceAtLeast(1f)` made every finer tile draw
     * at full unit size while translating by its high-z (x,y) — place-city billboard anchors then
     * slid toward larger mercator X/Y (screen bottom-right) while pinching from z4 → z0. Match
     * [VectorFillLayerRenderer]'s matrix path: pass the raw overscale through (epsilon floor only
     * so `u_half_scale` never divides by zero).
     */
    private fun tileOverscaleForDraw(useMapboxNativeMv: Boolean, mapZoomNow: Double, tileZ: Int): Float {
        val raw = if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, tileZ) else 1f
        return raw.coerceAtLeast(1e-6f)
    }

    private fun resolveDrawOpacities(
        paint: SymbolLayerPaint,
        batches: List<CachedSymbolDrawBatch>,
        useMapboxNativeMv: Boolean,
        mapZoomNow: Double,
        textLayerZoomOpacity: Float,
        proj: FloatArray,
        mvCam: FloatArray,
        tileLocal: FloatArray,
        modelView: FloatArray,
        mvp: FloatArray,
        screenBillboard: Boolean,
        viewportW: Float,
        viewportH: Float,
        cullOverzoomedPlaceUv: Boolean = false,
    ): Map<String, Float>? {
        if (symbolAllowOverlapForPaint(paint)) return null
        if (textLayerZoomOpacity < SYMBOL_MIN_DRAW_ALPHA &&
            paint.text.isNotEmpty() &&
            paint.icon.image == null
        ) {
            return null
        }
        val candidates = ArrayList<VectorSymbolScreenPlacer.Candidate>(128)
        val placeCap = VectorSymbolPlacementDefaults.placeLabelMaxDataZoom(id)
        val dataZoomForCull =
            if (placeCap != null) mapZoomNow.coerceAtMost(placeCap) else mapZoomNow
        val nominalZ = floor(dataZoomForCull)
        for (batch in batches) {
            if (batch.instances.isEmpty()) continue
            val overscale = tileOverscaleForDraw(useMapboxNativeMv, mapZoomNow, batch.coord.z)
            val mvpTile = VectorSymbolScreenProjection.buildTileMvp(
                batch.coord, overscale, proj, mvCam, tileLocal, modelView, mvp,
            )
            val uvAabb =
                if (cullOverzoomedPlaceUv && nominalZ - batch.coord.z >= 1.0) {
                    visibleTileUvAabb(batch.coord)
                } else {
                    null
                }
            collectPlacementCandidates(
                batch.instances.sdf,
                batch.instances.sdfMeta,
                mvpTile,
                overscale,
                viewportW,
                viewportH,
                billboard = false,
                out = candidates,
                uvAabb = uvAabb,
                tileZ = batch.coord.z,
            )
            collectPlacementCandidates(
                batch.instances.raster,
                batch.instances.rasterMeta,
                mvpTile,
                overscale,
                viewportW,
                viewportH,
                billboard = screenBillboard,
                out = candidates,
                uvAabb = uvAabb,
                tileZ = batch.coord.z,
            )
            val tileTextOpacity = textTileFallbackOpacity(
                batch.coord,
                mapZoomNow,
                fadeUpscaledParentText = !screenBillboard,
            )
            val batchTextOpacity = (textLayerZoomOpacity * tileTextOpacity).coerceIn(0f, 1f)
            if (batchTextOpacity >= SYMBOL_MIN_DRAW_ALPHA) {
                // Must match drawInstanceBatch's text billboard flag (screenBillboard =
                // !pitchWithMap). Hardcoding true made collision boxes billboard-sized while
                // default pitchWithMap=true drew map-plane quads — at continental zooms those
                // quads are larger than the boxes, so overlapping place labels slipped through.
                collectPlacementCandidates(
                    batch.instances.text,
                    batch.instances.textMeta,
                    mvpTile,
                    overscale,
                    viewportW,
                    viewportH,
                    billboard = screenBillboard,
                    // Place labels use larger boxes than generic text so dense city clusters
                    // cull more aggressively (see PLACE_TEXT_COLLISION_*).
                    paddingPx = if (placeCap != null) PLACE_TEXT_COLLISION_PADDING_PX else TEXT_COLLISION_PADDING_PX,
                    collisionScale = when {
                        placeCap != null -> PLACE_TEXT_COLLISION_SCALE
                        // The 0.72 inset is an icon-era tuning: a *proportional* shrink, so the
                        // overlap it permits grows with the text. At the default 11/14px that is a
                        // few pixels and reads as tight spacing; at 24-30px it is tens of pixels and
                        // reads as collision simply not working. Data-query stacks now carry a box
                        // measured to contain the whole value+name pair, so take it at face value.
                        DataQuery.isValueTextLayerId(id) -> 1f
                        else -> VectorSymbolScreenProjection.SYMBOL_COLLISION_BOX_SCALE
                    },
                    out = candidates,
                    uvAabb = uvAabb,
                    tileZ = batch.coord.z,
                )
                // Per-glyph SDF text: same box tuning, but only the first glyph of each label is a
                // candidate (the rest are excludeFromCollision) and it carries the label's extents
                // and centre via the collision overrides.
                collectPlacementCandidates(
                    batch.instances.textSdf,
                    batch.instances.textSdfMeta,
                    mvpTile,
                    overscale,
                    viewportW,
                    viewportH,
                    billboard = screenBillboard,
                    paddingPx = if (placeCap != null) PLACE_TEXT_COLLISION_PADDING_PX else TEXT_COLLISION_PADDING_PX,
                    collisionScale = if (placeCap != null) {
                        PLACE_TEXT_COLLISION_SCALE
                    } else {
                        VectorSymbolScreenProjection.SYMBOL_COLLISION_BOX_SCALE
                    },
                    out = candidates,
                    uvAabb = uvAabb,
                    tileZ = batch.coord.z,
                )
            }
        }
        // Rule: cross-layer-collision. Sibling layers in the same group (a composite's sub-layers)
        // claim screen space from each other, so e.g. a city name no longer draws through its own
        // state name. See [VectorSymbolCollisionGroups] for why this is a publish/read of boxes
        // rather than a placer shared between the layers.
        val groupId = VectorSymbolPlacementDefaults.collisionGroupId(id)
        val foreign =
            if (groupId != null) VectorSymbolCollisionGroups.foreignBoxes(groupId, id) else emptyList()
        val placedBoxes = if (groupId != null) ArrayList<FloatArray>(candidates.size) else null
        val opacities = screenPlacer.placeAndFade(
            dedupeCandidates(candidates, paint.rank?.direction, mapZoomNow),
            paint.rank?.direction,
            SystemClock.elapsedRealtime(),
            // Rule: fade-while-the-camera-moves. Was `snap = cameraMapMoving`, which skipped the
            // fade for any frame where the zoom changed by more than SYMBOL_CAMERA_ZOOM_EPSILON —
            // that is, for the whole of a zoom gesture, which is exactly the window where labels
            // enter and leave as tile sets swap. Every one of those transitions was instant, so the
            // fade was doing nothing at the only time it was needed and labels visibly popped.
            //
            // Its stated purpose was avoiding redraw storms, but a moving camera is already
            // rendering every frame, so fades advance for free there. The storm risk belongs to
            // requestCollisionContinuationRedraw asking for EXTRA frames on an otherwise idle map,
            // and that keeps its own throttle (SYMBOL_CONTINUATION_REDRAW_MIN_MS, applied only
            // while moving). fadeDelta also caps its step at 64ms of elapsed time, so a fade still
            // spans several frames however fast the camera is moving.
            snap = false,
            foreignBoxes = foreign,
            placedBoxesOut = placedBoxes,
        )
        if (groupId != null && placedBoxes != null) {
            VectorSymbolCollisionGroups.publish(groupId, id, placedBoxes)
        }
        return opacities
    }

    /** Schedules collision-fade frames without flooding redraw during pinch-zoom. */
    private fun requestCollisionContinuationRedraw(): Boolean {
        if (!screenPlacer.needsContinuation()) return false
        val now = SystemClock.elapsedRealtime()
        if (cameraMapMoving && now - lastContinuationRedrawMs < SYMBOL_CONTINUATION_REDRAW_MIN_MS) {
            return false
        }
        lastContinuationRedrawMs = now
        return true
    }

    /**
     * Rule: coalesced-redraw-must-not-drop. This throttle exists to collapse a BURST of
     * same-window build completions (e.g. 6 concurrent tiles finishing within ~100-300ms at very
     * low zoom) into one redraw — but the old implementation simply dropped every request that
     * landed inside the throttle window. If the LAST tile in the burst finished inside that window,
     * its `redraw()` call was the one that got dropped, and nothing else was scheduled to ever ask
     * again — that tile's already-built, already-cached instances sat ready-to-draw forever with
     * no redraw to pick them up. Observed live: place-city stuck showing 0-5 of 6 real tiles at
     * world zoom, permanently (not just slow — confirmed unchanged after 20+ seconds of waiting),
     * because the redraw that would have revealed the 6th tile's data never fired. Any request that
     * arrives inside the window now schedules exactly one trailing redraw for when the window closes,
     * so the burst always ends with a final flush instead of silently going quiet mid-batch.
     */
    private fun requestRedrawAfterBuild(tileLayer: TileLayer?) {
        if (tileLayer == null) return
        val now = SystemClock.elapsedRealtime()
        val elapsed = now - lastBuildRedrawMs
        if (elapsed >= SYMBOL_BUILD_REDRAW_MIN_INTERVAL_MS) {
            lastBuildRedrawMs = now
            tileLayer.mapController?.redraw()
            return
        }
        if (pendingBuildRedrawScheduled) return
        pendingBuildRedrawScheduled = true
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(
            {
                pendingBuildRedrawScheduled = false
                lastBuildRedrawMs = SystemClock.elapsedRealtime()
                tileLayer.mapController?.redraw()
            },
            (SYMBOL_BUILD_REDRAW_MIN_INTERVAL_MS - elapsed).coerceAtLeast(0L),
        )
    }

    /**
     * Collapses a label's candidate instances down to the one that should represent it.
     *
     * Rule: incumbent-instance-represents-its-label. Since identity became proximity-based
     * ([VectorSymbolCrossTileIndex]), one place arriving from a coarse and a fine tile is a single
     * label with several candidate instances, and which one is chosen decides where the label draws
     * and whether it keeps its fade. Preference order, mirroring the JS SDK's dedupe:
     *
     * 1. **The instance already on screen**, so a visible label does not restart its fade. This is
     *    the one place visibility feedback is still wanted — unlike in the placement sort, where it
     *    let an on-screen symbol keep winning its own collisions (see
     *    `no-visibility-feedback-in-the-sort`). Choosing which copy of an *already decided* label to
     *    draw cannot change which labels win space.
     * 2. **The tile whose zoom is closest to the view**, so a coarse or fine stand-in yields as soon
     *    as the matching tile arrives.
     * 3. Rank, then first-seen, as before.
     *
     * Rank alone was the previous rule, and it barely discriminated: every instance of one label is
     * the same source feature, so their ranks are normally equal, leaving the choice to tile arrival
     * order. Three of the four place layers configure no rank at all, so every dedupe landed there.
     */
    private fun dedupeCandidates(
        candidates: List<VectorSymbolScreenPlacer.Candidate>,
        rankDirection: com.xweather.mapsgl.style.SymbolRankDirection?,
        nominalZoom: Double,
    ): List<VectorSymbolScreenPlacer.Candidate> {
        if (candidates.size <= 1) return candidates
        val preferLowerRank = rankDirection != com.xweather.mapsgl.style.SymbolRankDirection.DESC
        val best = LinkedHashMap<String, VectorSymbolScreenPlacer.Candidate>(candidates.size)
        for (candidate in candidates) {
            val id = candidate.crossTileId
            val existing = best[id]
            if (existing == null) {
                best[id] = candidate
                continue
            }
            // Rule: no-equal-rank-box-union. Same-id boxes are never unioned — that produced
            // mega-boxes blocking whole regions (dateline world copies, near-duplicate points).
            // Exactly one instance is chosen and the rest are dropped.
            val preferNew = preferNewSymbolInstance(
                existingTileZ = existing.tileZ,
                candidateTileZ = candidate.tileZ,
                existingRank = existing.rank,
                candidateRank = candidate.rank,
                incumbentTileZ = chosenInstanceTileZById[id],
                incumbentVisible = screenPlacer.wasVisible(id),
                nominalZoom = nominalZoom,
                preferLowerRank = preferLowerRank,
            )
            if (preferNew) best[id] = candidate
        }
        // Remember the winners so the next pass can recognise the incumbent instance. Rebuilt rather
        // than updated so ids that stopped being candidates drop out and cannot pin an instance
        // choice for a label that is no longer on screen.
        chosenInstanceTileZById.clear()
        for ((id, chosen) in best) chosenInstanceTileZById[id] = chosen.tileZ
        return best.values.toList()
    }

    /**
     * Fades out parent-tile fallback labels near the max zoom gap (avoids a hard pop).
     *
     * No `coord.z == 0` early-out: a z=0 tile is the correct *native* tile only when the camera
     * itself is near zoom 0 (gap≈0 below already yields ~full opacity). A z=0 tile reached via
     * [resolveCachedVectorTile]'s parent-tile fallback while the camera sits at a much higher zoom
     * is a different case — that single world-spanning tile's entire global feature list is legitimately
     * within its own 0..1 uv range, so [SYMBOL_TILE_UV_OWNERSHIP_MARGIN]'s gate can't filter it, and at
     * the current zoom's tiny visible uv slice, dozens of unrelated-but-nearby-in-uv global cities land
     * on top of each other on screen. A hard-coded full-opacity carve-out for z=0 defeated the whole
     * point of this fade for exactly that case (see the reported label-clutter regression).
     */
    private fun textTileFallbackOpacity(
        coord: TileCoord,
        mapZoomNow: Double,
        fadeUpscaledParentText: Boolean,
    ): Float {
        // Billboard place labels (!pitchWithMap) stay screen-sized when drawn from a coarser tile —
        // they do not smear with overzoom — so the parent-gap fade must not hide them. Without this,
        // holding denser low-z place batches while zoomed into Ohio/etc. drew them at opacity 0.
        if (!fadeUpscaledParentText) return 1f
        // Rule: fallback-gap-uses-nominal-zoom. Tiles are requested at
        // min(floor(mapZoom), source.maxZoom[, placeLabelMaxDataZoom]); a native tile's z equals that
        // clamped zoom. Comparing against unclamped floor(mapZoom) zeros labels when overzooming.
        val sourceMaxZ = (tileLayer?.source?.maxZoom ?: 21f).toDouble().coerceAtLeast(0.0)
        val placeCap = VectorSymbolPlacementDefaults.placeLabelMaxDataZoom(id)
        val capZ = (placeCap ?: sourceMaxZ).coerceAtMost(sourceMaxZ)
        val nominalZ = kotlin.math.floor(mapZoomNow).coerceIn(0.0, capZ)
        val gap = nominalZ - coord.z
        if (gap <= 0.0) return 1f
        if (gap >= TEXT_PARENT_TILE_MAX_ZOOM_GAP) return 0f
        val t = (1.0 - gap / TEXT_PARENT_TILE_MAX_ZOOM_GAP).toFloat().coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun drawCachedBatches(
        batches: List<CachedSymbolDrawBatch>,
        drawOpacities: Map<String, Float>?,
        useMapboxNativeMv: Boolean,
        mapZoomNow: Double,
        textLayerZoomOpacity: Float,
        proj: FloatArray,
        mvCam: FloatArray,
        tileLocal: FloatArray,
        modelView: FloatArray,
        mvp: FloatArray,
        screenBillboard: Boolean,
        viewportW: Float,
        viewportH: Float,
        rotateWithMap: Boolean,
        bearingDeg: Float,
        cullOverzoomedPlaceUv: Boolean = false,
    ): Boolean {
        var drewAny = false
        val placeCap = VectorSymbolPlacementDefaults.placeLabelMaxDataZoom(id)
        val dataZoomForCull =
            if (placeCap != null) mapZoomNow.coerceAtMost(placeCap) else mapZoomNow
        val nominalZ = floor(dataZoomForCull)
        for (batch in batches) {
            if (batch.instances.isEmpty()) continue
            val overscale = tileOverscaleForDraw(useMapboxNativeMv, mapZoomNow, batch.coord.z)
            val uvAabb =
                if (cullOverzoomedPlaceUv && nominalZ - batch.coord.z >= 1.0) {
                    visibleTileUvAabb(batch.coord)
                } else {
                    null
                }
            drawInstanceBatch(
                batch.instances, batch.coord, overscale, proj, mvCam, tileLocal, modelView, mvp,
                screenBillboard, viewportW, viewportH, drawOpacities, mapZoomNow, textLayerZoomOpacity,
                rotateWithMap, bearingDeg, uvAabb,
            )
            drewAny = true
        }
        return drewAny
    }

    private fun drawInstanceBatch(
        batch: SymbolInstanceBatch,
        coord: TileCoord,
        overscale: Float,
        proj: FloatArray,
        mvCam: FloatArray,
        tileLocal: FloatArray,
        modelView: FloatArray,
        mvp: FloatArray,
        screenBillboard: Boolean,
        viewportW: Float,
        viewportH: Float,
        drawOpacities: Map<String, Float>?,
        mapZoomNow: Double,
        textLayerZoomOpacity: Float,
        rotateWithMap: Boolean,
        bearingDeg: Float,
        uvAabb: FloatArray? = null,
    ) {
        // Rule: pitch-rotate-parity. All three batch categories (sdf/raster/text) now share the
        // SAME layer-driven billboard/rotateWithMap pair (SymbolLayerPaint.pitchWithMap/rotateWithMap,
        // JS parity) instead of the previous per-category hardcoding (sdf always map-plane, text
        // always billboard) — that hardcoding was what made text labels ignore pitch/rotation entirely.
        if (batch.sdf.isNotEmpty()) {
            if (uRasterMode >= 0) GLES31.glUniform1i(uRasterMode, 0)
            uploadAndDrawInstances(
                batch.sdf, batch.sdfMeta, drawOpacities, coord, overscale, proj, mvCam, tileLocal, modelView, mvp,
                billboard = screenBillboard, viewportW, viewportH, rotateWithMap = rotateWithMap, bearingDeg = bearingDeg,
                uvAabb = uvAabb,
            )
        }
        if (batch.raster.isNotEmpty()) {
            if (rasterAtlasTex == 0) {
                rasterAtlasTex = VectorRasterSpriteAtlas.ensureLoadedOnGlThread()
            }
            if (rasterAtlasTex == 0) {
                symbolDebugLog("raster draw skipped: rasterAtlasTex=0 uvReady=${VectorRasterSpriteAtlas.isUvMapReady()}")
            } else {
                if (uRasterMode >= 0) GLES31.glUniform1i(uRasterMode, 1)
                uploadAndDrawInstances(
                    batch.raster, batch.rasterMeta, drawOpacities, coord, overscale, proj, mvCam, tileLocal, modelView, mvp,
                    billboard = screenBillboard, viewportW, viewportH, rotateWithMap = rotateWithMap, bearingDeg = bearingDeg,
                    uvAabb = uvAabb,
                )
            }
        }
        if (batch.text.isNotEmpty()) {
            val tileTextOpacity = textTileFallbackOpacity(
                coord,
                mapZoomNow,
                fadeUpscaledParentText = !screenBillboard,
            )
            val textAlpha = (textLayerZoomOpacity * tileTextOpacity).coerceIn(0f, 1f)
            if (textAlpha >= SYMBOL_MIN_DRAW_ALPHA) {
                val textAtlasTex = VectorTextAtlas.ensureLoadedOnGlThread()
                if (textAtlasTex == 0) {
                    symbolDebugLog("text draw skipped: text atlas not ready")
                } else {
                    GLES31.glActiveTexture(GLES31.GL_TEXTURE1)
                    GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textAtlasTex)
                    if (locRasterTex >= 0) GLES31.glUniform1i(locRasterTex, 1)
                    if (uRasterMode >= 0) GLES31.glUniform1i(uRasterMode, 1)
                    uploadAndDrawInstances(
                        batch.text,
                        batch.textMeta,
                        drawOpacities,
                        coord,
                        overscale,
                        proj,
                        mvCam,
                        tileLocal,
                        modelView,
                        mvp,
                        billboard = screenBillboard,
                        viewportW,
                        viewportH,
                        extraAlphaMult = textAlpha,
                        rotateWithMap = rotateWithMap,
                        bearingDeg = bearingDeg,
                        uvAabb = uvAabb,
                    )
                }
            }
        }
        if (batch.textSdf.isNotEmpty()) {
            val tileTextOpacity = textTileFallbackOpacity(
                coord,
                mapZoomNow,
                fadeUpscaledParentText = !screenBillboard,
            )
            val textAlpha = (textLayerZoomOpacity * tileTextOpacity).coerceIn(0f, 1f)
            if (textAlpha >= SYMBOL_MIN_DRAW_ALPHA) {
                val glyphTex = VectorTextSdfAtlas.ensureLoadedOnGlThread()
                if (glyphTex == 0) {
                    symbolDebugLog("sdf text draw skipped: glyph atlas not ready")
                } else {
                    GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
                    GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, glyphTex)
                    if (locTex >= 0) GLES31.glUniform1i(locTex, 0)
                    if (uRasterMode >= 0) GLES31.glUniform1i(uRasterMode, 0)
                    // Halo comes from the field, not from baked pixels — the reason one glyph can
                    // serve every colour and outline style. Set per batch from the layer's text
                    // paint; applyPaintUniforms' icon-stroke values do not apply to text.
                    if (uHaloWidth >= 0) GLES31.glUniform1f(uHaloWidth, batch.textSdfHaloWidth)
                    if (uHaloColor >= 0) {
                        val argb = batch.textSdfHaloArgb
                        GLES31.glUniform4f(
                            uHaloColor,
                            ((argb shr 16) and 0xFF) / 255f,
                            ((argb shr 8) and 0xFF) / 255f,
                            (argb and 0xFF) / 255f,
                            ((argb ushr 24) and 0xFF) / 255f,
                        )
                    }
                    uploadAndDrawInstances(
                        batch.textSdf,
                        batch.textSdfMeta,
                        drawOpacities,
                        coord,
                        overscale,
                        proj,
                        mvCam,
                        tileLocal,
                        modelView,
                        mvp,
                        billboard = screenBillboard,
                        viewportW,
                        viewportH,
                        extraAlphaMult = textAlpha,
                        rotateWithMap = rotateWithMap,
                        bearingDeg = bearingDeg,
                        uvAabb = uvAabb,
                    )
                    // Restore the sprite SDF atlas and the paint's halo: both are set once per
                    // paint, not per batch, and every batch after this one in the same frame would
                    // otherwise draw its icons against the glyph atlas with a text halo.
                    if (sdfAtlasTex != 0) {
                        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
                        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, sdfAtlasTex)
                    }
                    if (uHaloWidth >= 0) GLES31.glUniform1f(uHaloWidth, paintHaloWidth)
                    if (uHaloColor >= 0) {
                        GLES31.glUniform4f(
                            uHaloColor,
                            paintHaloColor[0], paintHaloColor[1],
                            paintHaloColor[2], paintHaloColor[3],
                        )
                    }
                }
            }
        }
    }

    private fun collectPlacementCandidates(
        instances: FloatArray,
        meta: List<SymbolInstanceMeta>,
        mvp: FloatArray,
        overscale: Float,
        viewportW: Float,
        viewportH: Float,
        billboard: Boolean,
        out: MutableList<VectorSymbolScreenPlacer.Candidate>,
        paddingPx: Float = SYMBOL_SCREEN_PADDING_PX,
        collisionScale: Float = VectorSymbolScreenProjection.SYMBOL_COLLISION_BOX_SCALE,
        uvAabb: FloatArray? = null,
        tileZ: Int = -1,
    ) {
        if (instances.isEmpty() || meta.isEmpty()) return
        val count = instances.size / SYMBOL_FLOATS_PER_INSTANCE
        for (i in 0 until count) {
            val entry = meta.getOrNull(i) ?: continue
            // Rule: stacked-line-no-self-collision. A stacked-text sibling line (e.g. the "name"
            // line of a value+name block) shares its crossTileId with the block's first line, which
            // already contributed the block's real collision box — letting this line become its
            // OWN candidate too risks it overlapping (and thus "colliding" against) its own sibling's
            // just-inserted box, overwriting the shared placement decision depending on iteration
            // order. It still draws (via the shared crossTileId's resolved opacity), just never
            // competes for space itself.
            if (entry.excludeFromCollision) continue
            val base = i * SYMBOL_FLOATS_PER_INSTANCE
            if (uvAabb != null) {
                val u = instances[base]
                val v = instances[base + 1]
                if (u < uvAabb[0] || u > uvAabb[2] || v < uvAabb[1] || v > uvAabb[3]) continue
            }
            val box = VectorSymbolScreenProjection.screenBoundsForInstance(
                instances,
                i,
                mvp,
                overscale,
                viewportW,
                viewportH,
                paddingPx,
                billboard,
                collisionScale,
                halfWidthPxOverride = entry.collisionHalfWidthPx.takeUnless { it.isNaN() },
                halfHeightPxOverride = entry.collisionHalfHeightPx.takeUnless { it.isNaN() },
                centerOffsetXPxOverride = entry.collisionCenterOffsetXPx.takeUnless { it.isNaN() },
                centerOffsetYPxOverride = entry.collisionCenterOffsetYPx.takeUnless { it.isNaN() },
            )
            if (!isScreenBoxVisible(box, viewportW, viewportH)) continue
            out.add(
                VectorSymbolScreenPlacer.Candidate(
                    entry.crossTileId, entry.rank, box, entry.sortKey, tileZ,
                ),
            )
        }
    }

    private fun isScreenBoxVisible(box: FloatArray, viewportW: Float, viewportH: Float): Boolean {
        val margin = 64f
        return box[2] >= -margin && box[0] <= viewportW + margin &&
            box[3] >= -margin && box[1] <= viewportH + margin
    }

    private fun uploadAndDrawInstances(
        instances: FloatArray,
        meta: List<SymbolInstanceMeta>,
        drawOpacities: Map<String, Float>?,
        coord: TileCoord,
        overscale: Float,
        proj: FloatArray,
        mvCam: FloatArray,
        tileLocal: FloatArray,
        modelView: FloatArray,
        mvp: FloatArray,
        billboard: Boolean,
        viewportW: Float,
        viewportH: Float,
        extraAlphaMult: Float = 1f,
        rotateWithMap: Boolean = true,
        bearingDeg: Float = 0f,
        uvAabb: FloatArray? = null,
    ) {
        val count = instances.size / SYMBOL_FLOATS_PER_INSTANCE
        if (count <= 0) return
        val applyAlphaOverride = extraAlphaMult < 0.999f || !drawOpacities.isNullOrEmpty() || uvAabb != null
        if (!applyAlphaOverride) {
            uploadInstanceBuffer(
                instances, count, coord, overscale, proj, mvCam, tileLocal, modelView, mvp, billboard, viewportW, viewportH,
                rotateWithMap, bearingDeg,
            )
            return
        }
        val scratch = instanceDrawScratch
        scratch.clear()
        scratch.ensureCapacity(instances.size)
        for (i in 0 until count) {
            val base = i * SYMBOL_FLOATS_PER_INSTANCE
            if (uvAabb != null) {
                val u = instances[base]
                val v = instances[base + 1]
                if (u < uvAabb[0] || u > uvAabb[2] || v < uvAabb[1] || v > uvAabb[3]) continue
            }
            var alpha = instances[base + 9] * extraAlphaMult.coerceIn(0f, 1f)
            if (!drawOpacities.isNullOrEmpty()) {
                val fade = drawOpacities[meta.getOrNull(i)?.crossTileId] ?: 1f
                alpha *= fade.coerceIn(0f, 1f)
            }
            if (alpha < SYMBOL_MIN_DRAW_ALPHA) continue
            for (j in 0 until SYMBOL_FLOATS_PER_INSTANCE) {
                scratch.add(instances[base + j])
            }
            // Alpha lives at offset 9 within each instance record; write-back must be relative to
            // SYMBOL_FLOATS_PER_INSTANCE, not a hardcoded literal — a prior fixed "- 6" (correct only
            // for the old 15-float stride) silently corrupted a_half_size's second component when the
            // stride grew to 17, since it landed 2 floats late.
            scratch[scratch.size - (SYMBOL_FLOATS_PER_INSTANCE - 9)] = alpha
        }
        val drawCount = scratch.size / SYMBOL_FLOATS_PER_INSTANCE
        if (drawCount <= 0) return
        uploadInstanceBuffer(
            scratch.toFloatArray(), drawCount, coord, overscale, proj, mvCam, tileLocal, modelView, mvp, billboard, viewportW, viewportH,
            rotateWithMap, bearingDeg,
        )
    }

    private fun uploadInstanceBuffer(
        data: FloatArray,
        drawCount: Int,
        coord: TileCoord,
        overscale: Float,
        proj: FloatArray,
        mvCam: FloatArray,
        tileLocal: FloatArray,
        modelView: FloatArray,
        mvp: FloatArray,
        billboard: Boolean,
        viewportW: Float,
        viewportH: Float,
        rotateWithMap: Boolean = true,
        bearingDeg: Float = 0f,
    ) {
        val bytes = data.size * 4
        if (instanceByteBuffer.capacity() < bytes) {
            instanceByteBuffer = ByteBuffer.allocateDirect(bytes + bytes / 2).order(ByteOrder.nativeOrder())
        }
        instanceByteBuffer.position(0)
        instanceByteBuffer.limit(bytes)
        instanceByteBuffer.asFloatBuffer().put(data)
        instanceByteBuffer.position(0)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, instanceVbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, bytes, instanceByteBuffer, GLES31.GL_DYNAMIC_DRAW)
        if (uHalfScale >= 0) GLES31.glUniform1f(uHalfScale, 1f / (512f * overscale.coerceAtLeast(1e-6f)))
        if (uBillboard >= 0) GLES31.glUniform1i(uBillboard, if (billboard) 1 else 0)
        if (uRotateWithMap >= 0) GLES31.glUniform1i(uRotateWithMap, if (rotateWithMap) 1 else 0)
        if (uBearingRad >= 0) GLES31.glUniform1f(uBearingRad, Math.toRadians(bearingDeg.toDouble()).toFloat())
        if (uViewport >= 0) GLES31.glUniform2f(uViewport, viewportW, viewportH)
        Matrix.setIdentityM(tileLocal, 0)
        Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
        // Rule: dateline-world-copy. See VectorFillLayerRenderer.drawInterleavedForCoord's identical
        // fix — must include coord.offset or every world copy of a tile draws at the same screen
        // position, breaking rendering across the antimeridian at wide zoom.
        val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
        Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
        Matrix.multiplyMM(modelView, 0, mvCam, 0, tileLocal, 0)
        Matrix.multiplyMM(mvp, 0, proj, 0, modelView, 0)
        GLES31.glUniformMatrix4fv(uMvp, 1, false, mvp, 0)
        GLES31.glDrawArraysInstanced(GLES31.GL_TRIANGLES, 0, 6, drawCount)
    }

    private fun ensureGlResources(context: Context, customIconShader: String?) {
        val needsRebuild = symbolGlProgram == 0 ||
            symbolGlProgramVersion != SYMBOL_GL_PROGRAM_VERSION ||
            vao == 0 ||
            compiledIconShaderSource != customIconShader
        if (!needsRebuild) {
            if (sdfAtlasTex == 0 || !GLES31.glIsTexture(sdfAtlasTex)) {
                sdfAtlasTex = VectorSpriteSdfAtlas.ensureLoaded(context)
            }
            return
        }
        if (symbolGlProgram != 0) {
            GLES31.glDeleteProgram(symbolGlProgram)
            symbolGlProgram = 0
        }
        var linkedShaderSource = customIconShader
        var prog = linkSymbolProgram(
            customIconShader?.let { VectorSymbolShaderChunks.resolveIncludes(it) } ?: SYMBOL_FRAG,
        )
        if (prog == 0 && customIconShader != null) {
            // Rule: never-a-hard-failure. An authoring mistake in a custom icon.shader should degrade
            // to the default icon rendering, not blank the whole layer (matches this codebase's
            // established fallback convention, e.g. native-triangulation fallback).
            Log.e(VECTOR_SYMBOL_TAG, "custom icon.shader failed to compile/link; falling back to default icon shader")
            linkedShaderSource = null
            prog = linkSymbolProgram(SYMBOL_FRAG)
        }
        if (prog == 0) return
        symbolGlProgram = prog
        symbolGlProgramVersion = SYMBOL_GL_PROGRAM_VERSION
        compiledIconShaderSource = linkedShaderSource
        instanceCache.clear()
        uMvp = GLES31.glGetUniformLocation(prog, "u_mvp")
        uHalfScale = GLES31.glGetUniformLocation(prog, "u_half_scale")
        uBillboard = GLES31.glGetUniformLocation(prog, "u_billboard")
        uRotateWithMap = GLES31.glGetUniformLocation(prog, "u_rotateWithMap")
        uBearingRad = GLES31.glGetUniformLocation(prog, "u_bearingRad")
        uViewport = GLES31.glGetUniformLocation(prog, "u_viewport")
        uRasterMode = GLES31.glGetUniformLocation(prog, "u_raster_mode")
        uHaloColor = GLES31.glGetUniformLocation(prog, "u_haloColor")
        uHaloWidth = GLES31.glGetUniformLocation(prog, "u_haloWidth")
        uTime = GLES31.glGetUniformLocation(prog, "u_time")
        uDpr = GLES31.glGetUniformLocation(prog, "u_dpr")
        uSpin = GLES31.glGetUniformLocation(prog, "u_spin")
        uSpinDegPerSec = GLES31.glGetUniformLocation(prog, "u_spinDegPerSec")
        locTex = GLES31.glGetUniformLocation(prog, "u_sdfTex")
        locRasterTex = GLES31.glGetUniformLocation(prog, "u_rasterTex")
        sdfAtlasTex = VectorSpriteSdfAtlas.ensureLoaded(context)

        val vaos = IntArray(1)
        GLES31.glGenVertexArrays(1, vaos, 0)
        vao = vaos[0]
        GLES31.glBindVertexArray(vao)
        val quad = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val vbos = IntArray(2)
        GLES31.glGenBuffers(2, vbos, 0)
        quadVbo = vbos[0]
        instanceVbo = vbos[1]
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, quadVbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, quad.size * 4, quad.toFloatBuffer(), GLES31.GL_STATIC_DRAW)
        GLES31.glEnableVertexAttribArray(0)
        GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, 8, 0)
        GLES31.glVertexAttribDivisor(0, 0)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, instanceVbo)
        val stride = INSTANCE_STRIDE_BYTES
        GLES31.glEnableVertexAttribArray(1)
        GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, stride, 0)
        GLES31.glVertexAttribDivisor(1, 1)
        GLES31.glEnableVertexAttribArray(2)
        GLES31.glVertexAttribPointer(2, 4, GLES31.GL_FLOAT, false, stride, 8)
        GLES31.glVertexAttribDivisor(2, 1)
        GLES31.glEnableVertexAttribArray(3)
        GLES31.glVertexAttribPointer(3, 4, GLES31.GL_FLOAT, false, stride, 24)
        GLES31.glVertexAttribDivisor(3, 1)
        GLES31.glEnableVertexAttribArray(4)
        GLES31.glVertexAttribPointer(4, 2, GLES31.GL_FLOAT, false, stride, 40)
        GLES31.glVertexAttribDivisor(4, 1)
        GLES31.glEnableVertexAttribArray(5)
        GLES31.glVertexAttribPointer(5, 2, GLES31.GL_FLOAT, false, stride, 48)
        GLES31.glVertexAttribDivisor(5, 1)
        GLES31.glEnableVertexAttribArray(6)
        GLES31.glVertexAttribPointer(6, 1, GLES31.GL_FLOAT, false, stride, 56)
        GLES31.glVertexAttribDivisor(6, 1)
        GLES31.glEnableVertexAttribArray(7)
        GLES31.glVertexAttribPointer(7, 1, GLES31.GL_FLOAT, false, stride, 60)
        GLES31.glVertexAttribDivisor(7, 1)
        GLES31.glEnableVertexAttribArray(8)
        GLES31.glVertexAttribPointer(8, 1, GLES31.GL_FLOAT, false, stride, 64)
        GLES31.glVertexAttribDivisor(8, 1)
        GLES31.glBindVertexArray(0)
    }

    /** Compiles [SYMBOL_VERT] against [fragmentSource] and links a program; returns 0 on any failure. */
    private fun linkSymbolProgram(fragmentSource: String): Int {
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, SYMBOL_VERT) ?: return 0
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, fragmentSource) ?: return 0
        val prog = GLES31.glCreateProgram()
        GLES31.glAttachShader(prog, vs)
        GLES31.glAttachShader(prog, fs)
        GLES31.glBindAttribLocation(prog, 0, "a_quad")
        GLES31.glBindAttribLocation(prog, 1, "a_center")
        GLES31.glBindAttribLocation(prog, 2, "a_uv")
        GLES31.glBindAttribLocation(prog, 3, "a_color")
        GLES31.glBindAttribLocation(prog, 4, "a_half_size")
        GLES31.glBindAttribLocation(prog, 5, "a_center_off")
        GLES31.glBindAttribLocation(prog, 6, "a_rotation")
        GLES31.glBindAttribLocation(prog, 7, "a_factor")
        GLES31.glBindAttribLocation(prog, 8, "a_random")
        GLES31.glLinkProgram(prog)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val linkOk = IntArray(1)
        GLES31.glGetProgramiv(prog, GLES31.GL_LINK_STATUS, linkOk, 0)
        if (linkOk[0] == 0) {
            Log.e(VECTOR_SYMBOL_TAG, "link failed: ${GLES31.glGetProgramInfoLog(prog)}")
            GLES31.glDeleteProgram(prog)
            return 0
        }
        return prog
    }

    private fun applyHaloUniforms(paint: SymbolLayerPaint, layerId: String?) {
        val stroke = paint.stroke
        val widthPx = (stroke?.thickness?.constantValue ?: 0.0).toFloat()
        // Thin symbol outlines use the expensive SDF halo path for little visual gain (e.g. lightning),
        // so sub-1px strokes are skipped by default. Tropical cyclone icons rely on their configured
        // 0.5px outline for JS parity (the white ring around each storm category icon), so they're
        // exempted from this cutoff rather than lowering it globally and re-enabling halos elsewhere.
        val exemptFromCutoff = layerId?.startsWith("tropical.") == true
        val haloWidth = if (widthPx >= 1f) {
            (widthPx * 0.02f).coerceIn(0.05f, 0.45f)
        } else if (exemptFromCutoff && widthPx > 0f) {
            // Rule: tropical-icon-outline. The shared 0.02x-of-widthPx formula above is tuned for
            // >=1px strokes; tropical's configured 0.5px thickness always hit the 0.05 floor,
            // rendering thinner than JS's outline. Use a higher floor for this exemption specifically
            // so the ring is visibly thicker without changing the (still-thin) lightning-style cutoff.
            (widthPx * 0.02f).coerceIn(0.12f, 0.45f)
        } else {
            0f
        }
        if (uHaloWidth >= 0) GLES31.glUniform1f(uHaloWidth, haloWidth)
        paintHaloWidth = haloWidth
        if (uHaloColor >= 0 && haloWidth > 0f) {
            val c = stroke?.color?.constantValue ?: Color.White
            GLES31.glUniform4f(uHaloColor, c.red, c.green, c.blue, c.alpha)
            paintHaloColor[0] = c.red
            paintHaloColor[1] = c.green
            paintHaloColor[2] = c.blue
            paintHaloColor[3] = c.alpha
        }
        if (uTime >= 0) {
            GLES31.glUniform1f(uTime, (SystemClock.elapsedRealtime() - SYMBOL_TIME_ORIGIN_MS) / 1000f)
        }
        if (uSpin >= 0) GLES31.glUniform1f(uSpin, if (paint.icon.spin) 1f else 0f)
        if (uSpinDegPerSec >= 0) GLES31.glUniform1f(uSpinDegPerSec, paint.icon.spinDegreesPerSecond)
        // Continuous frames for spin are driven by MapController's vsync loop (same as particles),
        // not from inside this GL render — queueEvent/triggerRepaint from here still got dropped /
        // paced to a few FPS once the camera was idle.
    }

    /**
     * Rule: incomplete-coverage-keeps-redrawing (see draw()'s needPrefetch check) and its sibling use
     * for [requestCollisionContinuationRedraw] (an in-progress collision fade). A raw
     * [MapController.redraw]/[triggerRepaint] posted from draw()'s own GL-thread call once per frame
     * turned out unreliable once the camera is fully idle: Mapbox appears to drop/ignore a flood of
     * identical repaint requests when nothing else is changing, so the retry chain silently died —
     * either a coord stuck on its coarse ancestor fallback, or two colliding candidates (e.g. two
     * real, nearby cities whose labels overlap) stuck mid-fade with both partially visible — sometimes
     * for minutes, until some unrelated gesture forced one more frame.
     * [MapboxMapController.requestRepaintCoalesced] (the pattern every other renderer already uses for
     * "a background build finished, draw again") is throttled to at most one pending post, so it
     * survives being called repeatedly without being mistaken for redundant noise. Stops once
     * [keepRedrawingNeeded] (updated every draw() call, from either trigger) goes false instead of
     * running for as long as the layer exists.
     *
     * Rule: fade-needs-fast-tick. This tick's own repost interval used to be a flat
     * [SYMBOL_DRAW_PREFETCH_MIN_INTERVAL_MS] (400ms) regardless of *why* it was scheduled — fine for
     * "keep retrying a tile fetch," since a fetch takes far longer than that anyway, but far too slow
     * for [VectorSymbolScreenPlacer]'s 200ms opacity fade: while the map is otherwise idle (no pan/
     * zoom already driving frames), this tick is the ONLY thing calling draw() again, so a fade
     * only advanced once every 400ms instead of at anything close to display refresh rate. Each step
     * is still capped at a real elapsed-time fraction internally, so the fade didn't overshoot — it
     * just visibly crawled, taking several multiples of its nominal 200ms instead of a quick fade.
     * Re-checking [VectorSymbolScreenPlacer.needsContinuation] on every tick and switching to
     * [SYMBOL_FADE_REDRAW_INTERVAL_MS] (~30fps) whenever a fade is actually in flight fixes that
     * without hammering the slow path when only prefetch-retry needs this tick.
     */
    private fun keepRedrawingIntervalMs(): Long =
        if (screenPlacer.needsContinuation()) SYMBOL_FADE_REDRAW_INTERVAL_MS else SYMBOL_DRAW_PREFETCH_MIN_INTERVAL_MS

    private fun ensureKeepRedrawing() {
        if (keepRedrawingScheduled) return
        keepRedrawingScheduled = true
        val handler = android.os.Handler(android.os.Looper.getMainLooper())
        val tick = object : Runnable {
            override fun run() {
                val controller = tileLayer?.mapController as? MapboxMapController
                if (controller == null || !keepRedrawingNeeded) {
                    keepRedrawingScheduled = false
                    return
                }
                controller.requestRepaintCoalesced()
                handler.postDelayed(this, keepRedrawingIntervalMs())
            }
        }
        handler.postDelayed(tick, keepRedrawingIntervalMs())
    }

    /**
     * Rule: tile-uv-ownership-before-atlas. True when [feature] has at least one point that this
     * tile owns (same gate as the emit path).
     */
    private fun featureHasOwnedTilePoint(
        feature: Feature,
        z: Int,
        tx: Int,
        ty: Int,
        world: Int,
    ): Boolean {
        when (val g = feature.geometry()) {
            is Point -> {
                val (u, v) = VectorPolygonFillTriangulator.lonLatToTileUv(
                    z, tx, ty, world, g.longitude(), g.latitude(),
                )
                return u >= -SYMBOL_TILE_UV_OWNERSHIP_MARGIN && u <= 1f + SYMBOL_TILE_UV_OWNERSHIP_MARGIN &&
                    v >= -SYMBOL_TILE_UV_OWNERSHIP_MARGIN && v <= 1f + SYMBOL_TILE_UV_OWNERSHIP_MARGIN
            }
            is MultiPoint -> {
                for (p in g.coordinates()) {
                    val (u, v) = VectorPolygonFillTriangulator.lonLatToTileUv(
                        z, tx, ty, world, p.longitude(), p.latitude(),
                    )
                    if (u >= -SYMBOL_TILE_UV_OWNERSHIP_MARGIN && u <= 1f + SYMBOL_TILE_UV_OWNERSHIP_MARGIN &&
                        v >= -SYMBOL_TILE_UV_OWNERSHIP_MARGIN && v <= 1f + SYMBOL_TILE_UV_OWNERSHIP_MARGIN
                    ) {
                        return true
                    }
                }
                return false
            }
            else -> return false
        }
    }

    /**
     * Rule: text-layers-materialize-raw-place. [VectorData.rawFeatures] is a tile-wide flag — a
     * sibling OSM layer on the raw path sets it even when `place` itself used Features, and older
     * cache entries may still have diverted `place` into raw only. Text builds need GeoJSON
     * [Feature]s; convert matching raw points when [parsed] has no rows for [sourceLayer].
     */
    private fun featuresForSymbolTextBuild(
        parsed: List<Feature>,
        raw: List<MvtFeature>?,
        coord: TileCoord,
        sourceLayer: String?,
    ): List<Feature> {
        if (raw == null) return parsed
        if (sourceLayer != null && parsed.any { featureLayerTag(it) == sourceLayer }) return parsed
        if (sourceLayer == null && parsed.isNotEmpty()) return parsed
        @Suppress("UNCHECKED_CAST")
        return raw.mapNotNull { rf ->
            if (sourceLayer != null && rf.layerName != sourceLayer) return@mapNotNull null
            val props = nestedDictionary(rf.attributes as Map<String, Any>).toMutableMap()
            props["layer"] = rf.layerName ?: sourceLayer.orEmpty()
            MapboxVectorFeature.from(coord, rf, props)
        }
    }

    private fun symbolPassesPrepFilter(
        feature: Feature,
        filter: Expression?,
        layerId: String?,
        dynamicMapTime: Boolean,
        mapTimeMs: Long,
    ): Boolean {
        val monotonic = dynamicMapTime && VectorMapTime.usesMonotonicMapTimeReveal(layerId, filter)
        return if (monotonic) {
            VectorFeatureDrawFilter.shouldDrawForGpuMapTimePrep(feature, filter, layerId)
        } else {
            VectorFeatureDrawFilter.shouldDraw(feature, filter, layerId, mapTimeMs)
        }
    }

    /**
     * iOS-style CPU map-time reveal for symbols: keep the full static candidate batch resident,
     * then drop instances whose baked featureTime is still ahead of the playhead before collision
     * and draw (so hidden icons do not suppress neighbors).
     */
    private fun filterBatchByMapTime(
        batch: SymbolInstanceBatch,
        layerId: String?,
        filter: Expression?,
    ): SymbolInstanceBatch {
        // Range / multi-clause dynamic filters already applied via full shouldDraw at prep.
        if (!VectorMapTime.usesMonotonicMapTimeReveal(layerId, filter)) return batch
        val mapTime = VectorMapTime.currentMapTimeUniform(hasDynamicMapTime = true)
        fun filterPair(
            floats: FloatArray,
            metas: List<SymbolInstanceMeta>,
        ): Pair<FloatArray, List<SymbolInstanceMeta>> {
            if (floats.isEmpty() || metas.isEmpty()) return floats to metas
            val outFloats = ArrayList<Float>(floats.size)
            val outMeta = ArrayList<SymbolInstanceMeta>(metas.size)
            val n = minOf(metas.size, floats.size / SYMBOL_FLOATS_PER_INSTANCE)
            for (i in 0 until n) {
                val m = metas[i]
                if (!VectorMapTime.passesFeatureTime(m.featureTime, mapTime)) continue
                val base = i * SYMBOL_FLOATS_PER_INSTANCE
                for (j in 0 until SYMBOL_FLOATS_PER_INSTANCE) outFloats.add(floats[base + j])
                outMeta.add(m)
            }
            if (outMeta.size == n) return floats to metas
            return outFloats.toFloatArray() to outMeta
        }
        val (sdf, sdfMeta) = filterPair(batch.sdf, batch.sdfMeta)
        val (raster, rasterMeta) = filterPair(batch.raster, batch.rasterMeta)
        val (text, textMeta) = filterPair(batch.text, batch.textMeta)
        val (textSdf, textSdfMeta) = filterPair(batch.textSdf, batch.textSdfMeta)
        // Rebuild by copy, not by the 6-arg constructor: the SDF-text arrays and their halo
        // colour/width default to empty/0, so listing only the first six fields silently drops
        // every glyph on a layer that uses both SDF text and monotonic map-time reveal. No shipped
        // layer combines the two today ([VectorSymbolPlacementDefaults.usesSdfText] is places-only,
        // and places have no playhead clause), which is why this stayed invisible.
        return batch.copy(
            sdf = sdf,
            raster = raster,
            text = text,
            sdfMeta = sdfMeta,
            rasterMeta = rasterMeta,
            textMeta = textMeta,
            textSdf = textSdf,
            textSdfMeta = textSdfMeta,
        )
    }

    private fun filterCachedBatchesByMapTime(
        batches: List<CachedSymbolDrawBatch>,
        layerId: String?,
        filter: Expression?,
    ): List<CachedSymbolDrawBatch> {
        if (!VectorFeatureDrawFilter.referencesMapTime(layerId, filter)) return batches
        return batches.mapNotNull { b ->
            val visible = filterBatchByMapTime(b.instances, layerId, filter)
            if (visible.isEmpty()) null else CachedSymbolDrawBatch(b.coord, visible)
        }
    }

    private fun buildInstances(
        features: List<Feature>,
        coord: TileCoord,
        sourceLayer: String?,
        filter: Expression?,
        paint: SymbolLayerPaint,
        zoom: Double,
        densityMult: Float,
        opacity: Float,
        layerId: String?,
    ): SymbolInstanceBatch {
        val sdfOut = ArrayList<Float>(128)
        val rasterOut = ArrayList<Float>(128)
        val textOut = ArrayList<Float>(128)
        val textSdfOut = ArrayList<Float>(128)
        val textSdfMeta = ArrayList<SymbolInstanceMeta>(128)
        var textSdfHaloArgb = 0
        var textSdfHaloWidth = 0f
        val sdfMeta = ArrayList<SymbolInstanceMeta>(64)
        val rasterMeta = ArrayList<SymbolInstanceMeta>(64)
        val textMeta = ArrayList<SymbolInstanceMeta>(64)
        val hasText = paint.text.isNotEmpty()
        var total = 0
        var points = 0
        var skippedFilter = 0
        var skippedLayer = 0
        var skippedImage = 0
        var skippedUv = 0
        var skippedColor = 0
        var skippedGeometry = 0
        var skippedText = 0
        var sampleRejectImageId: String? = null
        var sampleRejectReason: String? = null
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val dynamicMapTime = VectorFeatureDrawFilter.referencesMapTime(layerId, filter)
        val mapTimeMs = VectorDrawTime.currentMapTimeMillis()
        val orderedFeatures = VectorSymbolRankSort.sorted(features, paint.rank)
        // Rule: atlas-uv-stable-after-grow. Pack every in-tile text glyph first so [VectorTextAtlas]
        // can grow and rescale its Glyph.uv map *before* we bake UVs into the instance FloatArray.
        // Without this warm pass, a mid-loop grow left earlier labels (e.g. Columbus) sampling stale
        // UVs while later labels looked fine.
        if (hasText) {
            var warmed = 0
            for (f in orderedFeatures) {
                if (!symbolPassesPrepFilter(f, filter, layerId, dynamicMapTime, mapTimeMs)) continue
                if (sourceLayer != null) {
                    val tag = featureLayerTag(f)
                    if (tag != null && tag != sourceLayer) continue
                }
                if (!featureHasOwnedTilePoint(f, z, tx, ty, world)) continue
                // Both atlases need the same treatment: [VectorTextSdfAtlas] also renormalizes its
                // UVs on growth (it repacks from the origin), so a mid-loop grow would strand UVs
                // already baked into textSdfOut exactly as it did for the raster atlas.
                if (paint.text.size == 1 && VectorSymbolPlacementDefaults.usesSdfText(layerId)) {
                    VectorTextLayout.resolveSdfTextInstance(
                        paint.text[0], f, zoom, densityMult, opacity, layerId = layerId,
                    )
                } else {
                    VectorTextLayout.resolveStackedTextInstances(
                        paint.text, f, zoom, densityMult, opacity, layerId,
                    )
                }
                // Rule: per-tile-instance-cap. See MAX_SYMBOL_INSTANCES_PER_TILE — bounds this warm
                // pass's glyph-rasterization work the same way the main loop below bounds emitted
                // instances, for the same degenerate-ownership-gate-at-low-zoom reason.
                warmed++
                if (warmed >= MAX_SYMBOL_INSTANCES_PER_TILE) break
            }
        }
        for (f in orderedFeatures) {
            total++
            if (points >= MAX_SYMBOL_INSTANCES_PER_TILE) break
            if (!symbolPassesPrepFilter(f, filter, layerId, dynamicMapTime, mapTimeMs)) {
                skippedFilter++
                continue
            }
            if (sourceLayer != null) {
                val tag = featureLayerTag(f)
                if (tag != null && tag != sourceLayer) {
                    skippedLayer++
                    if (sampleRejectReason == null) sampleRejectReason = "layerTag=$tag expected=$sourceLayer"
                    continue
                }
            }
            // Rule: tile-uv-ownership-before-atlas. OSM `place` (and similar) tiles often pad each
            // cell with cities that live far outside the tile. Resolving text *before* the ownership
            // gate packed those labels into [VectorTextAtlas] until the 4096px atlas filled and
            // dropped in-tile majors (observed: Columbus/Cincinnati NO_TEXT while Cleveland still
            // emitted — `atlas full; dropped label`). Collect owned lon/lats first; only then rasterize.
            val ownedLons = ArrayList<Double>(1)
            val ownedLats = ArrayList<Double>(1)
            when (val g = f.geometry()) {
                is Point -> {
                    val (u, v) = VectorPolygonFillTriangulator.lonLatToTileUv(
                        z, tx, ty, world, g.longitude(), g.latitude(),
                    )
                    if (u >= -SYMBOL_TILE_UV_OWNERSHIP_MARGIN && u <= 1f + SYMBOL_TILE_UV_OWNERSHIP_MARGIN &&
                        v >= -SYMBOL_TILE_UV_OWNERSHIP_MARGIN && v <= 1f + SYMBOL_TILE_UV_OWNERSHIP_MARGIN
                    ) {
                        ownedLons.add(g.longitude())
                        ownedLats.add(g.latitude())
                    }
                }
                is MultiPoint -> {
                    for (p in g.coordinates()) {
                        val (u, v) = VectorPolygonFillTriangulator.lonLatToTileUv(
                            z, tx, ty, world, p.longitude(), p.latitude(),
                        )
                        if (u >= -SYMBOL_TILE_UV_OWNERSHIP_MARGIN && u <= 1f + SYMBOL_TILE_UV_OWNERSHIP_MARGIN &&
                            v >= -SYMBOL_TILE_UV_OWNERSHIP_MARGIN && v <= 1f + SYMBOL_TILE_UV_OWNERSHIP_MARGIN
                        ) {
                            ownedLons.add(p.longitude())
                            ownedLats.add(p.latitude())
                        }
                    }
                }
                else -> {
                    skippedGeometry++
                    if (sampleRejectReason == null) sampleRejectReason = "geom=${g?.type()}"
                    continue
                }
            }
            if (ownedLons.isEmpty()) continue

            val rank = placementRankForFeature(f, paint)
            // Blank image id = tropical LO/I parity (JS Active All Icons never draws tropical-low “L”).
            val imageId = resolveImageId(paint, f)?.takeIf { it.isNotBlank() }
            val factorValue = resolveIconFactor(paint.icon.factor, f, zoom)
            var iconPlacement: VectorSymbolLayout.IconPlacement? = null
            var iconUv: FloatArray? = null
            var iconRgba: FloatArray? = null
            var iconIsRaster = false
            if (imageId != null) {
                val sdfUv = VectorSpriteSdfAtlas.lookupUvRect(imageId)
                val rasterUv = if (sdfUv == null) VectorRasterSpriteAtlas.lookupUvRect(imageId) else null
                val uv = sdfUv ?: rasterUv
                if (uv == null) {
                    skippedUv++
                    if (sampleRejectReason == null) {
                        sampleRejectImageId = imageId
                        sampleRejectReason = "no UV for imageId=$imageId"
                    }
                } else {
                    iconPlacement = VectorSymbolLayout.placement(paint, f, zoom, densityMult, layerId)
                    iconUv = uv
                    iconRgba = resolveIconColor(paint, f, opacity, zoom)
                    if (iconRgba == null) {
                        skippedColor++
                        iconPlacement = null
                        iconUv = null
                        if (sampleRejectReason == null) {
                            sampleRejectReason = "resolveIconColor=null imageId=$imageId"
                        }
                    } else {
                        iconIsRaster = sdfUv == null
                    }
                }
            } else if (paint.icon.shader != null) {
                // Rule: icon-less-shader-instance. A custom fragment shader (JS parity
                // `paint.icon.shader`) often draws procedurally with no atlas image at all (e.g.
                // JS's earthquakes-pulse/fires-fx layers set no `icon.image`). Placement/size still
                // resolve purely from paint.icon.size/iconSize (VectorSymbolLayout.placement has no
                // atlas dependency); a full-unit UV rect gives the custom shader a clean 0..1 quad
                // coordinate to work with, matching JS's `vUv` behavior when no atlas image is bound.
                iconRgba = resolveIconColor(paint, f, opacity, zoom)
                if (iconRgba == null) {
                    skippedColor++
                    if (sampleRejectReason == null) sampleRejectReason = "resolveIconColor=null (shader-only)"
                } else {
                    iconPlacement = VectorSymbolLayout.placement(paint, f, zoom, densityMult, layerId)
                    iconUv = SHADER_ONLY_UV_RECT
                    iconIsRaster = true
                }
            } else if (!hasText) {
                skippedImage++
                if (sampleRejectReason == null) sampleRejectReason = "resolveImageId=null"
                continue
            }
            // Rule: sdf-text-opt-in. Single-TextPaint labels on an opted-in layer resolve to
            // per-character glyph quads instead of one whole-label raster. Multi-paint stacks
            // (data-query value blocks) stay on the raster path for now — see
            // VectorTextLayout.resolveSdfTextInstance.
            val useSdfText = hasText && paint.text.size == 1 &&
                VectorSymbolPlacementDefaults.usesSdfText(layerId)
            val sdfTextInstance =
                if (useSdfText) {
                    VectorTextLayout.resolveSdfTextInstance(
                        paint.text[0],
                        f,
                        zoom,
                        densityMult,
                        opacity,
                        layerId = layerId,
                    ).also { if (it == null) skippedText++ }
                } else {
                    null
                }
            val textInstances =
                if (hasText && !useSdfText) {
                    VectorTextLayout.resolveStackedTextInstances(
                        paint.text,
                        f,
                        zoom,
                        densityMult,
                        opacity,
                        layerId,
                    ).also { resolved ->
                        skippedText += (paint.text.size - resolved.size).coerceAtLeast(0)
                    }
                } else {
                    emptyList()
                }
            if (iconPlacement == null && iconUv == null &&
                textInstances.isEmpty() && sdfTextInstance == null
            ) {
                continue
            }
            val featureTime = if (dynamicMapTime) {
                VectorMapTime.featureTimeForLayer(f, layerId, filter)
            } else {
                VectorMapTime.ALWAYS_VISIBLE
            }
            fun emitOwned(lon: Double, lat: Double) {
                val (u, v) = VectorPolygonFillTriangulator.lonLatToTileUv(z, tx, ty, world, lon, lat)
                if (iconPlacement != null && iconUv != null && iconRgba != null) {
                    val out = if (iconIsRaster) rasterOut else sdfOut
                    val metaOut = if (iconIsRaster) rasterMeta else sdfMeta
                    out.add(u); out.add(v)
                    out.add(iconUv[0]); out.add(iconUv[1]); out.add(iconUv[2]); out.add(iconUv[3])
                    out.add(iconRgba[0]); out.add(iconRgba[1]); out.add(iconRgba[2]); out.add(iconRgba[3])
                    out.add(iconPlacement.halfWidthPx)
                    out.add(iconPlacement.halfHeightPx)
                    out.add(iconPlacement.centerOffsetXPx)
                    out.add(iconPlacement.centerOffsetYPx)
                    out.add(iconPlacement.rotationDeg)
                    out.add(factorValue)
                    out.add(kotlin.random.Random.Default.nextFloat())
                    metaOut.add(
                        SymbolInstanceMeta(
                            crossTileId = symbolCrossTileId(z, tx, ty, u, v, imageId ?: "shader", coord.offset),
                            rank = rank,
                            featureTime = featureTime,
                        ),
                    )
                }
                for ((_, ti) in textInstances) {
                    val placement = ti.placement
                    val uv = ti.glyph.uv
                    textOut.add(u); textOut.add(v)
                    textOut.add(uv[0]); textOut.add(uv[1]); textOut.add(uv[2]); textOut.add(uv[3])
                    textOut.add(1f); textOut.add(1f); textOut.add(1f); textOut.add(ti.tintRgba[3])
                    textOut.add(placement.halfWidthPx)
                    textOut.add(placement.halfHeightPx)
                    textOut.add(placement.centerOffsetXPx)
                    textOut.add(placement.centerOffsetYPx)
                    textOut.add(placement.rotationDeg)
                    textOut.add(1f)
                    textOut.add(0f)
                    textMeta.add(
                        SymbolInstanceMeta(
                            crossTileId = symbolCrossTileId(z, tx, ty, u, v, "text", coord.offset),
                            rank = rank,
                            collisionHalfWidthPx = placement.collisionHalfWidthPx,
                            collisionHalfHeightPx = placement.collisionHalfHeightPx,
                            excludeFromCollision = placement.excludeFromCollision,
                            featureTime = featureTime,
                        ),
                    )
                }
                sdfTextInstance?.let { st ->
                    // Every glyph of one label shares the label's crossTileId, so they fade and
                    // place as a unit. Only the first carries the collision box, with the label's
                    // extents and — via the collision-centre override — the label's centre.
                    // Rule: zoom-stable-label-identity. NOT symbolCrossTileId: that bakes the tile's
                    // z/x/y into the id, so the same city has a different identity at z3 than z4
                    // and a different one again once a parent-fallback tile is replaced by its
                    // native tile. Since the placer keys fade state by identity, that re-admits
                    // every label at opacity 0 on every zoom step — the old identity fading out
                    // while the new one fades in, which is a cross-fade of the same label.
                    // Resolved by proximity instead; see [VectorSymbolCrossTileIndex].
                    val crossId =
                        VectorSymbolCrossTileIndex.identityFor(layerId, st.text, lon, lat, coord.offset)
                    // Intrinsic tie-break: what the label is and where it is, never the identity it
                    // was handed. Those ids come from a discovery counter, so ordering on them
                    // would make the same scene reached by two different routes pick different
                    // winners among equal-ranked labels.
                    val sortKey = "${st.text}|$lon|$lat"
                    textSdfHaloArgb = st.haloArgb ?: 0
                    textSdfHaloWidth = st.haloWidthField
                    for ((quadIndex, q) in st.quads.withIndex()) {
                        val uv = st.uvs[q.glyphIndex]
                        textSdfOut.add(u); textSdfOut.add(v)
                        textSdfOut.add(uv[0]); textSdfOut.add(uv[1])
                        textSdfOut.add(uv[2]); textSdfOut.add(uv[3])
                        textSdfOut.add(st.fillRgba[0]); textSdfOut.add(st.fillRgba[1])
                        textSdfOut.add(st.fillRgba[2]); textSdfOut.add(st.fillRgba[3])
                        textSdfOut.add(q.halfWidthPx)
                        textSdfOut.add(q.halfHeightPx)
                        textSdfOut.add(q.centerOffsetXPx)
                        textSdfOut.add(q.centerOffsetYPx)
                        textSdfOut.add(st.placement.rotationDeg)
                        textSdfOut.add(1f)
                        textSdfOut.add(0f)
                        val first = quadIndex == 0
                        textSdfMeta.add(
                            SymbolInstanceMeta(
                                crossTileId = crossId,
                                rank = rank,
                                collisionHalfWidthPx =
                                    if (first) st.placement.halfWidthPx else Float.NaN,
                                collisionHalfHeightPx =
                                    if (first) st.placement.halfHeightPx else Float.NaN,
                                collisionCenterOffsetXPx =
                                    if (first) st.placement.centerOffsetXPx else Float.NaN,
                                collisionCenterOffsetYPx =
                                    if (first) st.placement.centerOffsetYPx else Float.NaN,
                                excludeFromCollision = !first,
                                featureTime = featureTime,
                                sortKey = sortKey,
                            ),
                        )
                    }
                }
            }
            points += ownedLons.size
            for (i in ownedLons.indices) {
                emitOwned(ownedLons[i], ownedLats[i])
            }
        }
        val rasterCount = rasterOut.size / SYMBOL_FLOATS_PER_INSTANCE
        val sdfCount = sdfOut.size / SYMBOL_FLOATS_PER_INSTANCE
        val textCount = textOut.size / SYMBOL_FLOATS_PER_INSTANCE
        if (points >= MAX_SYMBOL_INSTANCES_PER_TILE) {
            Log.w(
                VECTOR_SYMBOL_TAG,
                "buildInstances tile=${coord.z}/${coord.x}/${coord.y} hit MAX_SYMBOL_INSTANCES_PER_TILE " +
                    "($MAX_SYMBOL_INSTANCES_PER_TILE) out of $total features — truncated, see per-tile-instance-cap",
            )
        }
        if (MapsGLDebug.enabled && (rasterCount + sdfCount + textCount == 0 && total > 0)) {
            symbolBuildDebugLog(
                "buildInstances tile=${coord.z}/${coord.x}/${coord.y} sourceLayer=$sourceLayer " +
                    "features=$total points=$points raster=$rasterCount sdf=$sdfCount text=$textCount " +
                    "skip(filter=$skippedFilter layer=$skippedLayer image=$skippedImage uv=$skippedUv " +
                    "color=$skippedColor geom=$skippedGeometry text=$skippedText) " +
                    "sampleReject=$sampleRejectReason sampleImageId=$sampleRejectImageId " +
                    "uvMapReady=${VectorRasterSpriteAtlas.isUvMapReady()}",
            )
        } else if (MapsGLDebug.enabled && rasterCount + sdfCount + textCount > 0) {
            symbolBuildDebugLog(
                "buildInstances OK tile=${coord.z}/${coord.x}/${coord.y} " +
                    "raster=$rasterCount sdf=$sdfCount text=$textCount",
            )
        }
        return SymbolInstanceBatch(
            sdf = sdfOut.toFloatArray(),
            raster = rasterOut.toFloatArray(),
            text = textOut.toFloatArray(),
            sdfMeta = sdfMeta,
            rasterMeta = rasterMeta,
            textMeta = textMeta,
            textSdf = textSdfOut.toFloatArray(),
            textSdfMeta = textSdfMeta,
            textSdfHaloArgb = textSdfHaloArgb,
            textSdfHaloWidth = textSdfHaloWidth,
        )
    }

    /**
     * Rule: raw-vector-fast-path (Symbol port). Raw-attrs counterpart to [buildInstances] — reads
     * [MvtFeature] (raw MVT: JTS tile-local-pixel geometry + a flat
     * attribute map) instead of the heavy, fully-parsed [Feature] list, skipping
     * Feature/JsonObject/geometry-object construction entirely (the dominant per-feature cost for
     * point-heavy tiles like `fires-obs-icons`/`lightning-strikes-icons`).
     *
     * Scoped to icon-only instances: [resolveRawSymbolPathEligible] does not gate on `paint.text`, but
     * this function only ever runs when [data].rawFeatures is non-null, and callers only route through
     * here when `paint.text.isEmpty()` — text raw-mode support is a separate follow-up, not yet
     * implemented; layers with text stay on the heavy [buildInstances] path unconditionally (see the
     * call sites in `drawSymbolCoords`/`buildPlaybackSymbolRefsForInterval`).
     */
    private fun buildInstancesRaw(
        rawFeatures: List<MvtFeature>,
        coord: TileCoord,
        sourceLayer: String?,
        paint: SymbolLayerPaint,
        zoom: Double,
        densityMult: Float,
        opacity: Float,
        layerId: String?,
    ): SymbolInstanceBatch {
        val sdfOut = ArrayList<Float>(128)
        val rasterOut = ArrayList<Float>(128)
        val sdfMeta = ArrayList<SymbolInstanceMeta>(64)
        val rasterMeta = ArrayList<SymbolInstanceMeta>(64)
        val z = coord.z
        val tx = coord.x
        val ty = coord.y
        val world = 1 shl z
        val orderedFeatures = VectorSymbolRankSort.sortedRaw(rawFeatures, paint.rank)
        var emitted = 0
        for (f in orderedFeatures) {
            // Rule: per-tile-instance-cap. See MAX_SYMBOL_INSTANCES_PER_TILE / buildInstances's fuller
            // rationale — the same degenerate-ownership-gate-at-low-zoom exposure applies here.
            if (emitted >= MAX_SYMBOL_INSTANCES_PER_TILE) break
            try {
                @Suppress("UNCHECKED_CAST")
                val attrs = nestedDictionary(f.attributes as Map<String, Any>)
                if (!VectorPolygonFillTriangulator.rawFeatureVisible(attrs)) continue
                if (sourceLayer != null && f.layerName != sourceLayer) continue
                val rank = placementRankForFeatureRaw(attrs, paint)
                val imageId = resolveImageIdRaw(paint, attrs)?.takeIf { it.isNotBlank() }
                val factorValue = resolveIconFactorRaw(paint.icon.factor, attrs)
                var iconPlacement: VectorSymbolLayout.IconPlacement? = null
                var iconUv: FloatArray? = null
                var iconRgba: FloatArray? = null
                var iconIsRaster = false
                if (imageId != null) {
                    val sdfUv = VectorSpriteSdfAtlas.lookupUvRect(imageId)
                    val rasterUv = if (sdfUv == null) VectorRasterSpriteAtlas.lookupUvRect(imageId) else null
                    val uv = sdfUv ?: rasterUv
                    if (uv != null) {
                        iconRgba = resolveIconColorRaw(paint, attrs, opacity)
                        if (iconRgba != null) {
                            iconPlacement = VectorSymbolLayout.placementRaw(paint, attrs, zoom, densityMult, layerId)
                            iconUv = uv
                            iconIsRaster = sdfUv == null
                        }
                    }
                } else if (paint.icon.shader != null) {
                    iconRgba = resolveIconColorRaw(paint, attrs, opacity)
                    if (iconRgba != null) {
                        iconPlacement = VectorSymbolLayout.placementRaw(paint, attrs, zoom, densityMult, layerId)
                        iconUv = SHADER_ONLY_UV_RECT
                        iconIsRaster = true
                    }
                } else {
                    continue
                }
                if (iconPlacement == null || iconUv == null || iconRgba == null) continue
                fun emit(x: Double, y: Double) {
                    val (u, v) = VectorPolygonFillTriangulator.tileLocalXYToTileUv(x, y, coord, z, tx, ty, world)
                    val out = if (iconIsRaster) rasterOut else sdfOut
                    val metaOut = if (iconIsRaster) rasterMeta else sdfMeta
                    out.add(u); out.add(v)
                    out.add(iconUv[0]); out.add(iconUv[1]); out.add(iconUv[2]); out.add(iconUv[3])
                    out.add(iconRgba[0]); out.add(iconRgba[1]); out.add(iconRgba[2]); out.add(iconRgba[3])
                    out.add(iconPlacement.halfWidthPx)
                    out.add(iconPlacement.halfHeightPx)
                    out.add(iconPlacement.centerOffsetXPx)
                    out.add(iconPlacement.centerOffsetYPx)
                    out.add(iconPlacement.rotationDeg)
                    out.add(factorValue)
                    out.add(kotlin.random.Random.Default.nextFloat())
                    metaOut.add(
                        SymbolInstanceMeta(
                            crossTileId = symbolCrossTileId(z, tx, ty, u, v, imageId ?: "shader", coord.offset),
                            rank = rank,
                        ),
                    )
                    emitted++
                }
                when (val geometry = f.geometry) {
                    is MvtPoint -> emit(geometry.x, geometry.y)
                    is MvtMultiPoint -> for (p in geometry.coordinates) emit(p.x, p.y)
                    else -> Unit
                }
            } catch (t: Throwable) {
                MapsGLDebug.logW(VECTOR_SYMBOL_TAG, "buildInstancesRaw(): skipping malformed feature", t)
            }
        }
        if (emitted >= MAX_SYMBOL_INSTANCES_PER_TILE) {
            Log.w(
                VECTOR_SYMBOL_TAG,
                "buildInstancesRaw tile=${coord.z}/${coord.x}/${coord.y} hit MAX_SYMBOL_INSTANCES_PER_TILE " +
                    "($MAX_SYMBOL_INSTANCES_PER_TILE) — truncated, see per-tile-instance-cap",
            )
        }
        return SymbolInstanceBatch(
            sdf = sdfOut.toFloatArray(),
            raster = rasterOut.toFloatArray(),
            text = FloatArray(0),
            sdfMeta = sdfMeta,
            rasterMeta = rasterMeta,
            textMeta = emptyList(),
        )
    }

    private fun placementRankForFeatureRaw(attrs: Map<String, Any?>, paint: SymbolLayerPaint): Float {
        paint.rank?.let { return VectorSymbolRankSort.rankValueRaw(attrs, it.property).toFloat() }
        val area = VectorSymbolRankSort.rankValueRaw(attrs, "report.areaAC")
        if (area > 0.0) return -kotlin.math.ln(area.coerceAtLeast(1.0)).toFloat()
        return 0f
    }

    private fun resolveImageIdRaw(paint: SymbolLayerPaint, attrs: Map<String, Any?>): String? {
        val image = paint.icon.image ?: return null
        return when (image) {
            is StyleValue.Constant -> image.constantValue
            is StyleValue.Expression -> VectorCircleRawStyleEval.evaluateString(image.expression, attrs)
        }
    }

    private fun resolveIconFactorRaw(factor: StyleValue<Double>?, attrs: Map<String, Any?>): Float =
        when (factor) {
            null -> 1f
            is StyleValue.Constant -> (factor.constantValue ?: 1.0).toFloat()
            is StyleValue.Expression -> VectorCircleRawStyleEval.evaluateNumber(factor.expression, attrs)?.toFloat() ?: 1f
        }

    private fun resolveIconColorRaw(paint: SymbolLayerPaint, attrs: Map<String, Any?>, opacity: Float): FloatArray? {
        val fill = paint.fill ?: return floatArrayOf(1f, 1f, 1f, opacity)
        val color = fill.color
        val const = color.constantValue
        if (const != null) {
            val fo = (fill.opacity.constantValue ?: 1.0).toFloat().coerceIn(0f, 1f)
            return floatArrayOf(const.red, const.green, const.blue, const.alpha * opacity * fo)
        }
        val expr = color.expressionValue ?: return floatArrayOf(1f, 1f, 1f, opacity)
        val rgba = VectorCircleRawStyleEval.evaluateFillRgba(expr, attrs) ?: return null
        return floatArrayOf(rgba[0], rgba[1], rgba[2], rgba[3] * opacity)
    }

    /** Placement priority: explicit [SymbolLayerPaint.rank], else larger `report.areaAC` first. */
    private fun placementRankForFeature(feature: Feature, paint: SymbolLayerPaint): Float {
        if (paint.rank != null) {
            return VectorSymbolRankSort.rankValue(feature, paint.rank)
        }
        val area = VectorSymbolRankSort.rankValue(feature, "report.areaAC")
        if (area > 0.0) {
            return -kotlin.math.ln(area.coerceAtLeast(1.0)).toFloat()
        }
        return 0f
    }

    /** Resolves [IconPaint.factor] (JS parity `paint.icon.factor`) to `v_factor`; defaults to 1.0. */
    private fun resolveIconFactor(factor: StyleValue<Double>?, feature: Feature, zoom: Double): Float =
        when (factor) {
            null -> 1f
            is StyleValue.Constant -> (factor.constantValue ?: 1.0).toFloat()
            is StyleValue.Expression ->
                VectorFillStyleExpressionEval.evaluateNumber(factor.expression, feature, zoom)?.toFloat() ?: 1f
        }

    private fun resolveImageId(paint: SymbolLayerPaint, feature: Feature): String? {
        val image = paint.icon.image ?: return null
        return when (image) {
            is StyleValue.Constant -> image.constantValue
            is StyleValue.Expression -> {
                VectorFillStyleExpressionEval.evaluateString(image.expression, feature)
                    ?: VectorFillStyleExpressionEval.evaluateMatchString(image.expression, feature)
            }
        }
    }

    private fun resolveIconColor(
        paint: SymbolLayerPaint,
        feature: Feature,
        opacity: Float,
        zoom: Double,
    ): FloatArray? {
        val fill = paint.fill ?: return floatArrayOf(1f, 1f, 1f, opacity)
        val color = fill.color
        val const = color.constantValue
        if (const != null) {
            val fo = (fill.opacity.constantValue ?: 1.0).toFloat().coerceIn(0f, 1f)
            return floatArrayOf(const.red, const.green, const.blue, const.alpha * opacity * fo)
        }
        val expr = color.expressionValue ?: return floatArrayOf(1f, 1f, 1f, opacity)
        val rgba = VectorFillStyleExpressionEval.evaluateFillRgba(expr, feature, zoom) ?: return null
        return floatArrayOf(rgba[0], rgba[1], rgba[2], rgba[3] * opacity)
    }

    private fun symbolStyleCacheKey(
        paint: SymbolLayerPaint,
        zoom: Double,
        filter: Expression?,
        layerId: String?,
    ): Int {
        val img = paint.icon.image?.hashCode() ?: 0
        val sz = paint.icon.size?.hashCode() ?: 0
        val fill = paint.fill?.color?.hashCode() ?: 0
        val stroke = paint.stroke?.hashCode() ?: 0
        val overlap = if (symbolAllowOverlapForPaint(paint)) 1 else 0
        val rank = paint.rank?.hashCode() ?: 0
        val anchor = paint.icon.anchor.hashCode()
        val offset = paint.icon.offset.hashCode()
        val rotation = paint.icon.rotation.hashCode() + (if (paint.icon.rotationUsesDataDirection) 1 else 0)
        val textHash = paint.text.fold(0) { acc, tp ->
            31 * acc + tp.value.hashCode() + (tp.size?.hashCode() ?: 0) +
                tp.color.hashCode() + tp.anchor.hashCode() + tp.offset.hashCode() +
                (tp.outlineColor?.hashCode() ?: 0) + tp.allowOverlap.hashCode()
        }
        var h = 31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * (31 * img + sz) + fill) + stroke) + overlap) + rank) + anchor) + offset) + rotation) + textHash
        if (symbolPaintDependsOnZoom(paint)) {
            h = 31 * h + floor(zoom).toInt()
        }
        if (VectorFeatureDrawFilter.referencesMapTime(layerId, filter)) {
            h = 31 * h + filter.hashCode()
        }
        return h
    }

    private fun symbolPaintDependsOnZoom(paint: SymbolLayerPaint): Boolean =
        styleValueReferencesZoom(paint.icon.size) ||
            styleValueReferencesZoom(paint.icon.image) ||
            styleValueReferencesZoom(paint.fill?.color) ||
            styleValueReferencesZoom(paint.icon.offset) ||
            styleValueReferencesZoom(paint.icon.anchor) ||
            paint.icon.rotationUsesDataDirection ||
            paint.text.any {
                styleValueReferencesZoom(it.size) ||
                    styleValueReferencesZoom(it.value) ||
                    styleValueReferencesZoom(it.offset) ||
                    styleValueReferencesZoom(it.anchor)
            }

    private fun styleValueReferencesZoom(value: StyleValue<*>?): Boolean = when (value) {
        is StyleValue.Expression -> rawExpressionReferencesZoom(value.expression.raw)
        else -> false
    }

    private fun rawExpressionReferencesZoom(raw: Any?): Boolean = when (raw) {
        is List<*> -> raw.isNotEmpty() && (raw[0] == "zoom" || raw.any { rawExpressionReferencesZoom(it) })
        is Expression -> rawExpressionReferencesZoom(raw.raw)
        else -> false
    }

    override suspend fun update() {}

    private fun compileShader(type: Int, src: String): Int? {
        val s = GLES31.glCreateShader(type)
        GLES31.glShaderSource(s, src)
        GLES31.glCompileShader(s)
        val ok = IntArray(1)
        GLES31.glGetShaderiv(s, GLES31.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(VECTOR_SYMBOL_TAG, "shader compile failed: ${GLES31.glGetShaderInfoLog(s)}")
            GLES31.glDeleteShader(s)
            return null
        }
        return s
    }

    private fun projectionMatrixToFloatArray(pm: ProjectionMatrix): FloatArray = pm.elements.toFloatArray()
    private fun matrix4ToFloatArray(m: com.xweather.mapsgl.gl.math.Matrix4): FloatArray = m.elements.toFloatArray()
    private fun FloatArray.toFloatBuffer(): java.nio.FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(this).apply {
            position(0)
        }
}
