package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.style.SymbolRank
import com.xweather.mapsgl.style.SymbolRankDirection
import com.mapbox.geojson.Feature
import kotlin.math.roundToInt
import com.xweather.mapsgl.mvt.MvtFeature

internal object VectorSymbolRankSort {

    private const val RANK_MISSING = -1.0

    fun sorted(features: List<Feature>, rank: SymbolRank?): List<Feature> {
        if (rank == null || features.size <= 1) return features
        return features
            .map { it to rankValue(it, rank.property) }
            .let { keyed ->
                when (rank.direction) {
                    SymbolRankDirection.ASC -> keyed.sortedBy { it.second }
                    SymbolRankDirection.DESC -> keyed.sortedByDescending { it.second }
                }
            }
            .map { it.first }
    }

    fun rankValue(feature: Feature, rank: SymbolRank?): Float {
        if (rank == null) return 0f
        return rankValue(feature, rank.property).toFloat()
    }

    fun rankValue(feature: Feature, property: String): Double {
        val props = feature.properties() ?: return RANK_MISSING
        val el = props.get(property) ?: return RANK_MISSING
        if (el.isJsonNull) return RANK_MISSING
        if (!el.isJsonPrimitive) return RANK_MISSING
        val p = el.asJsonPrimitive
        if (p.isNumber) return p.asDouble
        if (p.isString) return p.asString.toDoubleOrNull() ?: RANK_MISSING
        return RANK_MISSING
    }

    /**
     * Rule: raw-vector-fast-path (Symbol port). Raw-attrs counterpart to [sorted]/[rankValue] — reads
     * the same flat, dot-notation-keyed property directly off [MvtFeature.attributes].
     */
    fun sortedRaw(
        features: List<MvtFeature>,
        rank: SymbolRank?,
    ): List<MvtFeature> {
        if (rank == null || features.size <= 1) return features
        return features
            .map { it to rankValueRaw(it.attributes, rank.property) }
            .let { keyed ->
                when (rank.direction) {
                    SymbolRankDirection.ASC -> keyed.sortedBy { it.second }
                    SymbolRankDirection.DESC -> keyed.sortedByDescending { it.second }
                }
            }
            .map { it.first }
    }

    fun rankValueRaw(attributes: Map<String, Any?>, property: String): Double =
        when (val v = attributes[property]) {
            is Number -> v.toDouble()
            is String -> v.toDoubleOrNull() ?: RANK_MISSING
            else -> RANK_MISSING
        }
}

internal fun symbolCrossTileId(
    coordZ: Int,
    coordX: Int,
    coordY: Int,
    anchorU: Float,
    anchorV: Float,
    imageId: String,
    worldOffset: Int = 0,
): String {
    val ax = (anchorU * 10_000f).roundToInt()
    val ay = (anchorV * 10_000f).roundToInt()
    val imageKey = imageId.replace(' ', '_')
    return if (worldOffset == 0) {
        "$coordZ-$coordX-$coordY-$ax-$ay-$imageKey"
    } else {
        "$coordZ-$coordX-$coordY-o$worldOffset-$ax-$ay-$imageKey"
    }
}

/**
 * Rule: incumbent-instance-represents-its-label. Decides whether a newly seen instance should
 * replace the one currently chosen to represent a label.
 *
 * Kept a pure function so the preference order is testable: it decides where a label draws and
 * whether it keeps its fade, but it lives behind renderer state (the placer's visibility and the
 * previous pass's choice) that a unit test cannot reach.
 *
 * Mirrors the JS SDK's dedupe. Order:
 *  1. the instance already on screen, so a visible label does not restart its fade;
 *  2. the tile whose zoom is closest to the view, so a stand-in yields once the right tile arrives;
 *  3. rank, then first-seen.
 *
 * Visibility feedback belongs here and not in the placement sort: choosing which copy of an
 * already-decided label to draw cannot change which labels win space, whereas ordering on
 * visibility let an on-screen symbol keep winning its own collisions.
 *
 * @param incumbentTileZ tile zoom of the instance chosen last pass, or null if there was none.
 * @param incumbentVisible whether the label was placed and showing after the last pass.
 */
internal fun preferNewSymbolInstance(
    existingTileZ: Int,
    candidateTileZ: Int,
    existingRank: Float,
    candidateRank: Float,
    incumbentTileZ: Int?,
    incumbentVisible: Boolean,
    nominalZoom: Double,
    preferLowerRank: Boolean,
): Boolean {
    val candidateIsIncumbent = incumbentTileZ != null && candidateTileZ == incumbentTileZ
    val existingIsIncumbent = incumbentTileZ != null && existingTileZ == incumbentTileZ
    if (incumbentVisible && candidateIsIncumbent != existingIsIncumbent) {
        return candidateIsIncumbent
    }
    if (!candidateIsIncumbent && !existingIsIncumbent) {
        val candidateGap = kotlin.math.abs(candidateTileZ - nominalZoom)
        val existingGap = kotlin.math.abs(existingTileZ - nominalZoom)
        if (candidateGap != existingGap) return candidateGap < existingGap
    }
    if (candidateRank != existingRank) {
        return if (preferLowerRank) candidateRank < existingRank else candidateRank > existingRank
    }
    return false
}
