package com.xweather.mapsgl.renderers

import android.os.SystemClock
import android.opengl.GLES31
import android.opengl.Matrix
import android.util.Log
import com.xweather.mapsgl.util.MapsGLDebug
import androidx.compose.ui.graphics.Color
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.gl.EmptyRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.ExpressionFilterFlatten
import com.xweather.mapsgl.map.mapbox.GeoJsonWorldCopies
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.TropicalDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorCircleRawStyleEval
import com.xweather.mapsgl.map.mapbox.VectorDrawTime
import com.xweather.mapsgl.map.mapbox.VectorFeatureDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorFillSortDefaults
import com.xweather.mapsgl.map.mapbox.VectorLayerDrawFilterDefaults
import com.xweather.mapsgl.map.mapbox.VectorMapTime
import com.xweather.mapsgl.map.mapbox.VectorPolygonFillTriangulator
import com.xweather.mapsgl.map.mapbox.geoJsonVisibleFeatureSetKey
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.meshModeFingerprint
import com.xweather.mapsgl.sources.markLayerMeshReady
import com.xweather.mapsgl.sources.withGpuUpload
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.anim.playbackGateReadyPhaseEpochMillis
import com.xweather.mapsgl.sources.resolveVectorTileData
import com.xweather.mapsgl.sources.timelinePhaseEpochMillis
import com.xweather.mapsgl.sources.timelinePlaybackPrefetchEpochMillis
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.renderers.LayerRenderContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.floor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private const val VECTOR_FILL_TAG = "VectorFillLayerRenderer"
/**
 * Rule: zoom-transition-hold. Background threads triangulating fill/outline meshes. Was a single
 * thread, serializing every visible tile's triangulation on a zoom change — for layers with large
 * or complex polygons (e.g. severe.alerts, whose geometry can span many tiles and sometimes needs
 * line-ribbon extrusion), serialized triangulation of several tiles could take longer than
 * zoomTransitionHoldMs, so the hold expired and promoted a still-incomplete frame instead of
 * continuing to hold the old-zoom batch — a visible flicker/gap right after zooming. Matches
 * VectorSymbolLayerRenderer's SYMBOL_INSTANCE_BUILD_THREADS pool size; triangulation cache/
 * in-progress-set are already ConcurrentHashMap-backed (same pattern Circle/Symbol already rely on
 * with their own thread pools), so this is a pure throughput change — no hold/promotion/playback
 * logic changes.
 */
private const val FILL_TRIANGULATION_BUILD_THREADS = 2

/** Rule: warmup-submit-pacing. See [VectorFillLayerRenderer.ensureTimeSeriesWarmupTriangulation]'s
 * KDoc — max new fill (and separately, outline) background triangulation jobs started per warmup
 * scan tick (every 250ms), so a cold warmup's allocation output is spread across more ticks instead
 * of front-loaded into one GC-pressuring burst. */
private const val WARMUP_SUBMIT_BUDGET_PER_TICK = 3
/**
 * Rule: pan-during-playback. Settle window before restarting [VectorFillLayerRenderer]'s
 * playback-prep job on a detected viewport-coords change — without this, a continuous drag would
 * cancel+relaunch the job on every single frame, never letting it finish building a single interval
 * for the new area. Matches the debounce window already used elsewhere in this codebase for
 * pan-related work.
 */
private const val PLAYBACK_PREP_COORDS_SETTLE_MS = 400L
/**
 * Rule: playback-mesh-cache-bound. Java-heap FloatArray mesh cache budget during playback, in
 * bytes. Was an entry-count cap (`maxOf(512, protected.size + 64)`, then later a flat 512) — but a
 * single tile's outline mesh over a dense administrative-boundary area (many small polygons, each
 * contributing 6 vertices x 10 floats per boundary point) can be hundreds of KB to low MB on its
 * own, so even a "fixed" entry count doesn't bound total bytes. This bounds actual memory instead:
 * see [trimMeshCacheHard].
 *
 * Was 24MB — measured on-device (alerts fill+outline, 5 visible tiles x 25 timeline phases) the
 * actually-needed ("protected") working set alone was ~181 mesh entries, comfortably exceeding 24MB
 * for outline meshes in particular. Once the protected set itself exceeds the budget,
 * [trimMeshCacheHard]'s "evict protected too" fallback starts evicting meshes that are still needed
 * for the current playback window — they get rebuilt and immediately evicted again on every timeline
 * loop, which is exactly the sustained GC pressure (continuous `WaitForGcToComplete` stalls) this was
 * caught doing. 64MB is not a full fix for arbitrarily long timelines/viewports — it's sized to clear
 * this specific measured working set with headroom. The real fix is Phase 2: move the source of truth
 * to a properly-sized native cache (not sharing the JVM heap's much smaller ceiling), with this JVM
 * cache staying a thin, safely-evictable hot layer in front of it.
 */
private const val PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES = 64L * 1024L * 1024L

/** Temporary diagnostic — detects a loop-wrap (currentPhaseA jumping back down near 0 after being
 * near the max) and dumps a window of outline draw-call state around it. Remove after use. */
private object OutlineLoopWrapDiag {
    private var lastPhaseA = -1
    private var framesSinceWrap = -1
    fun note(phaseA: Int, snappedDraw: Long) {
        if (!MapsGLDebug.enabled) return
        if (lastPhaseA > phaseA + 2 && framesSinceWrap < 0) {
            framesSinceWrap = 0
            Log.w("OutlineLoopWrapDiag", "WRAP DETECTED lastPhaseA=$lastPhaseA newPhaseA=$phaseA snappedDraw=$snappedDraw")
        }
        lastPhaseA = phaseA
        if (framesSinceWrap in 0..30) {
            Log.w("OutlineLoopWrapDiag", "frame+$framesSinceWrap phaseA=$phaseA snappedDraw=$snappedDraw")
            framesSinceWrap++
        }
    }
    fun noteRebuild(prebuiltSize: Int, freshSize: Int, lastSuccessfulSize: Int) {
        if (!MapsGLDebug.enabled) return
        if (framesSinceWrap in 0..30) {
            Log.w(
                "OutlineLoopWrapDiag",
                "  rebuild prebuiltOutline=$prebuiltSize freshOutline=$freshSize lastSuccessfulOutline=$lastSuccessfulSize",
            )
        }
    }
}

/**
 * Rule: raw-vector-fast-path. Pure decision function (rule: testability), split out so it's testable
 * without instantiating the renderer, mirroring
 * [com.xweather.mapsgl.renderers.resolveRawCirclePathEligible]. True only when it's safe to declare
 * this fill layer eligible via [VectorTileSource.setRawPathEligible]: the layer's effective filter
 * must be null **or** a geometry-type-only allow of Polygon/MultiPolygon (raw fill already skips
 * non-polygon geometry in [VectorPolygonFillTriangulator.triangulateFeaturesRaw]; it does not run
 * [VectorFeatureDrawFilter.shouldDraw]'s full filter/stencil-mask/tropical pipeline), and the
 * resolved fill-color expression must use only ops [VectorCircleRawStyleEval] can evaluate off raw
 * MVT attributes. Unlike Circle's gate, this has no `consumerCount == 1` restriction —
 * [VectorTileSource.rawPathEligibleForLayer] already generalizes to "every attached consumer agrees,"
 * which is exactly what lets a shared source like severe.alerts (fill + outline consumers) take this
 * path. Fill's own stroke (outline) color/thickness are always constant here (see draw()'s
 * strokeRgba/strokeThicknessPx), never expressions, so they need no separate support check.
 */
internal fun resolveRawFillPathEligible(
    layerId: String,
    filter: Expression?,
    fillColorExpression: Expression?,
): Boolean {
    if (TropicalDrawFilter.isTropicalTrackLineLayer(layerId)) return false
    val flatFilter = ExpressionFilterFlatten.flatten(filter)
    val effective = VectorLayerDrawFilterDefaults.effectiveFilter(layerId, flatFilter)
    if (effective != null && !isPolygonGeometryTypeOnlyFilter(effective)) return false
    if (!VectorCircleRawStyleEval.isSupportedColorExpression(fillColorExpression)) return false
    return true
}

/**
 * Applies a fill layer's draw filter to CPU-path features, which is what
 * [com.xweather.mapsgl.renderers.VectorCircleLayerRenderer] and
 * [com.xweather.mapsgl.renderers.VectorLineLayerRenderer] already do for their MVT paths, and what
 * the MVT fill path did not do at all — a [com.xweather.mapsgl.layers.spec.FillLayerDescriptor]'s
 * filter reached the GL renderer and was then only ever read for raw-path eligibility and hit
 * testing, never to decide what to draw.
 *
 * A null filter short-circuits rather than falling through to [VectorFeatureDrawFilter.shouldDraw],
 * so an unfiltered layer keeps exactly the feature set it had before — including features carrying
 * `visible = 0`, which shouldDraw would otherwise start dropping. Every built-in MVT fill filter is
 * geometry-type-only (hail and lightning threat polygons, stormcell cones) and
 * [VectorPolygonFillTriangulator.triangulateFeatures] already ignores non-polygon geometry, so this
 * changes nothing for any shipped configuration.
 */
internal fun fillFeaturesPassingDrawFilter(
    features: List<Feature>,
    drawFilter: Expression?,
    layerId: String?,
): List<Feature> {
    if (drawFilter == null) return features
    return features.filter { VectorFeatureDrawFilter.shouldDraw(it, drawFilter, layerId) }
}

/**
 * True when [filter] only restricts `geometry-type` to Polygon and/or MultiPolygon.
 * [VectorPolygonFillTriangulator.triangulateFeaturesRaw] already no-ops other geometry, so this
 * matches the heavy fill path without building GeoJSON Features (stormcells-cones).
 */
internal fun isPolygonGeometryTypeOnlyFilter(filter: Expression?): Boolean {
    if (filter == null) return false
    val node = ExpressionFilterFlatten.flattenNode(filter.raw) ?: return false
    return nodeIsPolygonGeometryTypeOnly(node)
}

private fun isGeometryTypeInput(node: Any?): Boolean {
    val list = when (node) {
        is Expression -> ExpressionFilterFlatten.flattenNode(node.raw) as? List<*>
        is List<*> -> node
        else -> null
    } ?: return false
    return list.size == 1 && list[0] == "geometry-type"
}

private fun isPolygonGeometryTypeName(value: Any?): Boolean =
    value == "Polygon" || value == "MultiPolygon"

private fun nodeIsPolygonGeometryTypeOnly(node: Any?): Boolean {
    val list = node as? List<*> ?: return false
    if (list.isEmpty()) return false
    return when (list[0]) {
        "==" -> list.size == 3 && isGeometryTypeInput(list[1]) && isPolygonGeometryTypeName(list[2])
        "match" -> {
            if (list.size < 4 || !isGeometryTypeInput(list[1])) return false
            var i = 2
            var allowsPolygon = false
            while (i + 1 < list.size - 1) {
                val label = list[i]
                val output = list[i + 1]
                val labels: List<Any?> = if (label is List<*>) label else listOf(label)
                if (labels.any { it !is String }) return false
                val isPolyLabel = labels.any { isPolygonGeometryTypeName(it) }
                if (isPolyLabel && output != true) return false
                if (isPolyLabel && output == true) allowsPolygon = true
                i += 2
            }
            allowsPolygon
        }
        "all" -> {
            if (list.size == 2) nodeIsPolygonGeometryTypeOnly(list[1])
            else list.size > 1 && list.drop(1).all { nodeIsPolygonGeometryTypeOnly(it) }
        }
        else -> false
    }
}

/**
 * Rule: native-fill-triangulation. Phase 4 of the heap-pressure plan: moves the earcut+clip+emit
 * computation for raw-path fill triangulation off the JVM heap into native code (see
 * VectorPolygonFillTriangulator.nativeTriHandle's KDoc). Enabled by default as of the re-benchmark
 * after this session's other playback/cache fixes: 90s active-playback heap sampling showed Dalvik
 * heap peak ~317MB (off) vs ~150MB (on), total PSS peak ~668MB (off) vs ~491MB (on), native heap
 * flat either way — a clearer win than the original "inconclusive at light test scale" verdict.
 * Visually verified correct (alerts fill+outline rendering intact) over both Europe and the USA
 * while actively playing. A single global toggle, not per-layer, since — unlike raw-path
 * eligibility — this doesn't depend on style/filter support, only on whether raw-path
 * triangulation is already happening at all (native only ever runs on top of the already-cheap
 * JTS ring data raw mode provides). Flip back to `false` if a regression surfaces.
 */
internal const val NATIVE_FILL_TRIANGULATION_ENABLED = true

/**
 * Rule: native-outline-triangulation. Moves the per-segment stroke-ribbon quad emission for
 * raw-path outline triangulation off the JVM heap into native code (see
 * VectorPolygonFillTriangulator.nativeTriHandle's KDoc, [VectorPolygonFillTriangulator.triangulateOutlinesRaw]).
 * Targets a confirmed live GC-churn/freeze during long-timeline steady-state playback: JVM
 * triangulation caches can't hold a full multi-day timeline's mesh data at once, so looping back
 * through already-evicted phases forces repeated outline rebuilds — and outline meshes are the
 * heavier of the two mesh types (per the debug panel's own numbers, e.g. ~86MB outline vs ~12MB
 * fill for the same viewport). Host-side correctness verified (8 cases including the exact
 * packColorFloat byte-layout match against the Kotlin reference, closed-ring wraparound vs. open
 * polyline behavior, and polygon-with-hole ring independence) before enabling. Flip back to `false`
 * if a regression surfaces.
 */
internal const val NATIVE_OUTLINE_TRIANGULATION_ENABLED = true

/**
 * Rule: playback-mesh-cache-bound. Evicts down to [maxBytes] of FloatArray payload regardless of
 * how large [protected] is — unlike a pure "never evict protected" trim, this guarantees the cache
 * cannot grow past a fixed memory bound even when the full timeline's protected set exceeds it.
 * Safe to evict protected (currently-needed-for-playback) entries too: every mesh here was already
 * persisted to the native triangulation cache when first computed (putFillTriangulationNative/
 * putOutlineTriangulationNative), so an evicted entry is restored on next access via a cheap
 * native fetch, never by re-triangulating.
 */
private fun trimMeshCacheHard(cache: ConcurrentHashMap<String, FloatArray>, protected: Set<String>, maxBytes: Long) {
    var totalBytes = cache.values.sumOf { it.size.toLong() * 4L }
    if (totalBytes <= maxBytes) return
    val nonProtected = cache.entries.iterator()
    while (totalBytes > maxBytes && nonProtected.hasNext()) {
        val entry = nonProtected.next()
        if (entry.key !in protected) {
            totalBytes -= entry.value.size.toLong() * 4L
            nonProtected.remove()
        }
    }
    if (totalBytes > maxBytes) {
        val anyEntry = cache.entries.iterator()
        while (totalBytes > maxBytes && anyEntry.hasNext()) {
            val entry = anyEntry.next()
            totalBytes -= entry.value.size.toLong() * 4L
            anyEntry.remove()
        }
    }
}

private fun vectorFillDrawIntervalMs(tileLayer: TileLayer?, vts: VectorTileSource): Long? {
    if (!vts.isTimeSeriesSource) return null
    // Global timeline phase is authoritative during scrub/playback (epoch ms, not timeLongs seconds).
    timelinePhaseEpochMillis(Timeline.currentPhaseA)?.let { return it }
    return tileLayer?.animator?.currentInterval?.interval?.takeIf { it > 0L }
}

/**
 * Draws [FillLayerPaint] polygon fills by triangulating [VectorTileSource] features in tile UV space (same basis as
 * encoded rasters / stencil masks) inside Mapbox [com.mapbox.maps.CustomLayerHost].
 *
 * Mapbox style `fill` layers are omitted when this renderer is active; use an invisible Mapbox fill hook so
 * [com.mapbox.maps.extension.style.sources.CustomGeometrySource] still receives tile requests.
 */
class VectorFillLayerRenderer(
    override var id: String,
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {
    private companion object {
        // Bump when fill-color triangulation semantics change so cached vertex colors are recomputed.
        private const val TRIANGULATION_COLOR_CACHE_VERSION = 5 // +hail/lightning lead-time fill sort

        /** See [requestCpuGeometryReparse]. Two is enough for a re-parse that is going to work. */
        private const val MAX_CPU_REPARSE_ATTEMPTS = 2

        /** Bounds the attempt ledger; a filter the user keeps switching must not grow it forever. */
        private const val MAX_CPU_REPARSE_KEYS = 4096

        /** Same threshold as [VectorLineLayerRenderer]: sync GeoJSON meshes under this size. */
        private const val GEOJSON_SYNC_TRIANGULATION_MAX_FEATURES = 2000

        private const val OUTLINE_VERTEX_STRIDE_BYTES =
            VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX * 4
    }

    private data class CachedDrawBatch(val coord: TileCoord, val interleaved: FloatArray)
    private data class DrawResult(
        val drawnCount: Int,
        val resolvedCount: Int,
        val batches: List<CachedDrawBatch>,
        val allExact: Boolean = true,
        /** Tiles that resolved to a built mesh holding no geometry. */
        val emptyMeshCount: Int = 0,
    ) {
        val fullCoverage: Boolean get() = resolvedCount > 0 && drawnCount == resolvedCount

        /**
         * Every tile in view resolved, and every one of them was built and had nothing to draw.
         *
         * This is a **complete** frame, not a failed one, and telling the two apart is what lets a
         * filter that matches nothing actually clear the map. A filter change alone can empty every
         * tile in view, and without this the zero-draw result read as "tiles not ready" and the
         * renderer held the previous filter's geometry on screen indefinitely.
         */
        val resolvedButEmpty: Boolean
            get() = drawnCount == 0 && resolvedCount > 0 && emptyMeshCount >= resolvedCount
    }

    init {
        cachesTextures = false
    }

    override fun onAdd() {}

    override fun onAdd(
        context: RenderContext<Any>,
        tileLayer: TileLayer,
        controller: MapboxMapController,
    ) {
    }

    private var glProgram: Int = 0
    private var uMvpLocation: Int = -1
    private var uMapTimeLocation: Int = -1
    private var outlineGlProgram: Int = 0
    private var uOutlineMvpLocation: Int = -1
    private var uOutlineMapTimeLocation: Int = -1
    private var uClipToTileLocation: Int = -1
    private var uOutlineClipToTileLocation: Int = -1
    private var uInvOverscaleLocation: Int = -1
    private var vbo: Int = 0
    private var fillByteBuffer: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
    private var outlineByteBuffer: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
    private val triangulationCache = ConcurrentHashMap<String, FloatArray>()
    private val triangulationInProgress: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private var lastSuccessfulBatches: List<CachedDrawBatch> = emptyList()
    private var lastSuccessfulDrawIntervalMs: Long? = null
    private val outlineTriangulationCache = ConcurrentHashMap<String, FloatArray>()
    private val outlineTriangulationInProgress: MutableSet<String> = ConcurrentHashMap.newKeySet()
    /**
     * Rule: paused-mesh-cache-protection. While paused, [trimTriangulationCachesIfNeeded] used to pass
     * an empty protected set (see its KDoc) — safe against the "protect the whole timeline forever"
     * OOM mistake, but it went too far the other way: a genuinely static paused view (same handful of
     * visible tiles, same single resolved interval, nothing changing frame to frame) had NOTHING
     * protecting even the tiles on screen right now, so once the combined working set nudged past the
     * halved paused budget, an unrelated tile's insert could evict a currently-displayed tile's mesh —
     * which [drawCoords]/[drawOutlineCoords] then immediately recomputes and re-inserts next frame,
     * evicting some other currently-displayed tile in turn. Live-measured: ~100MB/sec sustained GC
     * churn with the app fully paused and stationary. [drawCoords]/[drawOutlineCoords] repopulate these
     * every frame with exactly the tri-keys needed for what's on screen *this* frame — bounded by
     * visible-tile-count (never the whole timeline), so it can't reintroduce the earlier OOM failure
     * mode; [trimMeshCacheHard]'s unconditional evict-protected-too fallback pass is untouched.
     */
    // Concurrent, not HashSet: these are mutated on the draw thread (cleared each frame, added as
    // meshes are triangulated) but read via addAll from trimTriangulationCachesIfNeeded, which also
    // runs on a background coroutine via schedulePlaybackFramePreparation. A plain HashSet threw
    // ConcurrentModificationException there (the sibling protectedFillTriKeys() path is already
    // guarded by playbackRefsLock; this non-playing branch was not).
    private val visibleFillTriKeysThisFrame: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val visibleOutlineTriKeysThisFrame: MutableSet<String> = ConcurrentHashMap.newKeySet()
    /** GeoJSON CPU map-time meshes (convective, etc.) — keep current keys out of playback trim. */
    private var pinnedGeoJsonFillTriKey: String? = null
    private var pinnedGeoJsonOutlineTriKey: String? = null
    private var lastGeoJsonFillMesh: FloatArray? = null
    private var lastSuccessfulOutlineBatches: List<CachedDrawBatch> = emptyList()
    private var lastSuccessfulOutlineDrawIntervalMs: Long? = null
    /**
     * Rule: steady-state-redundant-rebuild. A ~30-phase timeline animating over ~1-2 seconds
     * advances phases every ~30-60ms, but the GL render loop runs at ~60fps (~16.6ms/frame) — so
     * each phase stays on screen across 2-4 rendered frames before the interval actually changes.
     * The steady-state draw branch previously called [drawPlaybackFillRefs]/[drawPlaybackOutlineRefs]
     * unconditionally every frame regardless of whether [snappedDraw] had changed since the last
     * frame — rebuilding a fresh [ArrayList] and a [CachedDrawBatch] wrapper per visible tile via a
     * hashmap [resolveFillMesh]/[resolveOutlineMesh] lookup, then discarding the previous
     * [lastSuccessfulBatches]/[lastSuccessfulOutlineBatches] list, every single one of those 2-4
     * redundant frames. Live-measured: the JVM triangulation-cache/native-cache layers were already
     * confirmed allocation-free (100% hits/zero-copy) by this point, yet ~85MB/sec of *small*-object
     * (non-LOS) GC churn persisted — this per-frame rebuild-of-unchanged-content is that source.
     * Tracked separately from [lastSuccessfulDrawIntervalMs]/[lastSuccessfulOutlineDrawIntervalMs]
     * (which serve the legacy on-demand branch's own, differently-scoped promotion logic) to avoid
     * any cross-branch interference.
     */
    private var lastSteadyStateFillIntervalMs: Long? = null
    private var lastSteadyStateOutlineIntervalMs: Long? = null
    /** Rule: warmup-scan-throttle. [ensureTimeSeriesWarmupTriangulation]'s O(coords × prefetchPhases)
     * scan was being re-run on every single draw() call (60fps) for the entire duration of the
     * loading burst, even though `submitted` (new triangulation jobs actually launched) plateaus
     * within the first second or two — an atrace capture measured ~9860 scan iterations in ~5s
     * while only ~122 were ever new work, the other ~98.8% just re-doing the same
     * hasTimeSeriesDataLoadedAt/findCachedVectorTileForNominalZxy/triKey-string-build lookups for
     * already-resolved combos and immediately discarding the result. That redundant allocation
     * churn is a real contributor to the GC-for-alloc stalls seen blocking the main/UI thread during
     * interval loading (see project_ui_jank_interval_loading_profiling memory). Throttling the scan
     * itself (not the cheap isPlaybackTimelineFullyPrimed completion check, which still runs every
     * frame so warmup-complete detection stays prompt) cuts this ~6x with zero correctness risk —
     * it only affects how often already-submitted-or-cached work gets re-noticed, not whether it
     * eventually gets noticed. */
    private var lastWarmupTriangulationScanMs: Long = 0L
    private val warmupTriangulationScanIntervalMs = 250L
    private var backgroundExecutor = Executors.newFixedThreadPool(FILL_TRIANGULATION_BUILD_THREADS)
    private val minPromotionCoverage = 0.55f
    private val zoomTransitionHoldMs = 700L

    /**
     * Rule: zoom-settle-hold. [zoomTransitionHoldMs] is a wall-clock deadline, and both of the
     * protections that keep a zoom change from flickering are keyed to it: the coarse-ancestor
     * fallback (`allowParentFallback = zoomTransitionHold`) and the partial-frame promotion guard
     * (`|| !zoomTransitionHold`). They therefore switch **off together** the instant it lapses, so a
     * zoom whose triangulation runs longer than 700ms lands on exactly one bad frame — partial
     * coverage, no coarse stand-in, promoted anyway. Measured live as a fully blank frame plus a
     * ~290ms dropout at ~72% coverage on a plain double-tap zoom over Iberia.
     *
     * The pre-existing mitigation was throughput (see [FILL_TRIANGULATION_BUILD_THREADS], 1 -> 2
     * threads) — it made exceeding 700ms *less likely* without removing the coupling, so the
     * flicker returns whenever the tiles are heavy enough. These fields instead let the hold last
     * until the new zoom floor has actually **settled**, i.e. every visible tile is drawn and no
     * mesh build is still in flight.
     *
     * [zoomSettleCeilingMs] is the anti-freeze backstop: the extension only applies while
     * triangulation is genuinely still running, but a leaked in-progress key would otherwise hold
     * the old zoom's batches on screen forever, so the extension is abandoned unconditionally past
     * this ceiling and behaviour reverts to the original deadline semantics.
     */
    private val zoomSettleCeilingMs = 8_000L
    private var zoomFloorSettled: Boolean = false
    private var zoomSettleDeadlineMs: Long = 0L
    private val playbackCoordsHoldMs = 750L
    private var lastZoomFloor: Int? = null
    private var holdLastBatchesUntilMs: Long = 0L
    private var playbackStableCoords: List<TileCoord> = emptyList()
    private var playbackStableCoordsUntilMs: Long = 0L
    private val playbackFillRefsByIntervalMs = LinkedHashMap<Long, List<VectorPlaybackMeshRef>>()
    private val playbackOutlineRefsByIntervalMs = LinkedHashMap<Long, List<VectorPlaybackMeshRef>>()
    /**
     * Rule: playback-refs-thread-safety. [playbackFillRefsByIntervalMs]/[playbackOutlineRefsByIntervalMs]
     * are written from [schedulePlaybackFramePreparation]'s background prep job (Dispatchers.Default)
     * while [draw] iterates them synchronously on the Mapbox GL render thread — confirmed live via a
     * full crash stack trace (`java.util.ConcurrentModificationException` at
     * `LinkedHashMap$LinkedValueIterator.next` inside [protectedOutlineTriKeys], called from
     * [trimTriangulationCachesIfNeeded] → [resolveOutlineMesh] → [ensureTimeSeriesWarmupTriangulation] →
     * [draw], fatal-aborting the whole app via a JNI CheckJNI abort once the exception state corrupted
     * a subsequent native call). This is the same "zero app-code frames" crash flagged as unreproduced
     * in an earlier session — now root-caused. `LinkedHashMap` can't be swapped for
     * `ConcurrentHashMap` here: [trimPlaybackMeshRefCache] relies on insertion-order iteration
     * (`keys.firstOrNull()`) for LRU eviction, which `ConcurrentHashMap` doesn't guarantee. Instead,
     * every iteration and every structural mutation (put/remove/clear) of these two maps must hold
     * this lock — plain get()/containsKey() single-key lookups elsewhere are left unsynchronized
     * (can't throw CME on their own; the confirmed failure mode is iteration racing a mutation).
     */
    private val playbackRefsLock = Any()
    /**
     * Rule: pan-during-playback. Tags which [playbackPrepGeneration] each committed interval entry
     * was built against — see [schedulePlaybackFramePreparation]'s coords-restart handling for why
     * this exists instead of clearing [playbackFillRefsByIntervalMs]/[playbackOutlineRefsByIntervalMs]
     * outright on a viewport change.
     */
    private val playbackFillRefsGeneration = HashMap<Long, Long>()
    private val playbackOutlineRefsGeneration = HashMap<Long, Long>()
    /** Rule: parsed-heap-bound. Throttle for the periodic parsed-feature trim during playback. */
    private var lastParsedHeapTrimMs: Long = 0L
    private val parsedHeapTrimIntervalMs = 750L
    /** Rule: native-cache-budget. Throttle for re-deriving native mesh pins from the JVM-side
     * protected set — cheap in isolation, but resolveFillMesh/resolveOutlineMesh call the trim path
     * once per visible tile per draw() frame, and a full unpin-all-then-repin is real JNI call volume
     * (~100s of pins) we don't need to pay every frame just to keep pins in lockstep. */
    private var lastNativePinSyncMs: Long = 0L
    private val nativePinSyncIntervalMs = 500L
    /** Rule: native-cache-budget. This renderer's own previously-pinned keys, so pin syncing can
     * unpin only the ones that left the working set — never the shared namespace's other entries
     * (see trimTriangulationCachesIfNeeded's KDoc for why a namespace-wide unpin-all is unsafe here). */
    private var previouslyPinnedFillKeys: Set<String> = emptySet()
    private var previouslyPinnedOutlineKeys: Set<String> = emptySet()
    /**
     * Rule: playback-mesh-cache-bound. A phase's tiles aren't added to [protectedFillTriKeys] /
     * [protectedOutlineTriKeys] until the *entire* phase's ref list is committed to
     * [playbackFillRefsByIntervalMs] / [playbackOutlineRefsByIntervalMs] — but building one phase
     * across several tiles takes several trim-triggering inserts in a row. Without this, once the
     * resident committed working set sits near the cache budget, a new phase's own earlier tiles get
     * evicted by the trim calls its own later tiles trigger, before the phase ever finishes — so it
     * retries forever without ever completing (confirmed live: a phase's built-tile count oscillated
     * 0→2→3→0 across retries, never reaching all coords, while GC churned continuously and playback
     * stayed frozen on the last phase that ever did complete). These sets mark a tile's key as
     * protected for the duration of its own build call, closing that gap.
     */
    private val inFlightFillTriKeys: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val inFlightOutlineTriKeys: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private fun maxPlaybackIntervalBatchCacheSize(): Int {
        val phaseCount = Timeline.timeStrings.size.coerceAtLeast(1)
        // Hold one ref list per timeline phase so loop playback never evicts wrapped intervals.
        return maxOf(phaseCount + 8, timelinePlaybackPrefetchEpochMillis().size * 4)
    }

    /**
     * Rule: pan-during-playback. Only protects entries tagged with the *current*
     * [playbackPrepGeneration] — a coords-restart (pan/zoom during playback) bumps that generation
     * but deliberately never clears [playbackFillRefsByIntervalMs] (see the coords-restart KDoc), so
     * without this filter every stale entry from the OLD viewport stays "protected" (and native-pinned
     * via [trimTriangulationCachesIfNeeded]) right alongside the NEW viewport's growing set until the
     * slow background prep job happens to overwrite each one — i.e. two full viewports' worth of
     * mesh data resident and exempt from eviction at once. Confirmed live: zooming in one level during
     * active 3-day playback over a wide viewport (France/W. Europe) drove the native heap to ~822MB
     * and the JVM mesh caches into an evict/refetch thrash severe enough to freeze playback for 4+
     * minutes. Filtering here means a stale-generation entry becomes evictable the instant the
     * restart begins, not only once naturally overwritten.
     */
    private fun protectedFillTriKeys(): Set<String> {
        val keys = HashSet<String>()
        synchronized(playbackRefsLock) {
            for ((intervalMs, refs) in playbackFillRefsByIntervalMs) {
                if (playbackFillRefsGeneration[intervalMs] != playbackPrepGeneration) continue
                for (ref in refs) keys.add(ref.triKey)
            }
        }
        keys.addAll(inFlightFillTriKeys)
        pinnedGeoJsonFillTriKey?.let { keys.add(it) }
        return keys
    }

    private fun protectedOutlineTriKeys(): Set<String> {
        val keys = HashSet<String>()
        synchronized(playbackRefsLock) {
            for ((intervalMs, refs) in playbackOutlineRefsByIntervalMs) {
                if (playbackOutlineRefsGeneration[intervalMs] != playbackPrepGeneration) continue
                for (ref in refs) keys.add(ref.triKey)
            }
        }
        keys.addAll(inFlightOutlineTriKeys)
        pinnedGeoJsonOutlineTriKey?.let { keys.add(it) }
        return keys
    }
    // Tile count from the paused frame — promotion during playback requires at least this many
    // drawn tiles so partial triangulation never replaces the complete paused display.
    private var pausedBatchCount = 0
    private var pausedOutlineBatchCount = 0
    private var wasGloballyPlaying = false
    /** While false during playback, the layer holds [playbackFrozenBatches] until the prefetch window is ready. */
    private var playbackWarmupComplete = true
    private var playbackFrozenBatches: List<CachedDrawBatch> = emptyList()
    private var playbackFrozenOutlineBatches: List<CachedDrawBatch> = emptyList()
    private var playbackFrozenIntervalMs: Long? = null
    private var warmupTilePrefetchJob: Job? = null
    /** Builds per-interval draw batches off the GL thread for 60fps playback (rule 9). */
    private var playbackFramePrepJob: Job? = null
    /**
     * Rule: pan-during-playback. Coord-set key the currently-running [playbackFramePrepJob] was
     * actually launched with (its `coords` argument freezes into a closure at launch and is never
     * re-read). [pendingPlaybackPrepCoordsKey]/[pendingPlaybackPrepCoordsKeyStableSinceMs] debounce a
     * settle window before restarting the job on a genuine viewport change, so a continuous drag
     * doesn't cancel+relaunch every frame. [playbackPrepGeneration] is bumped on every such restart;
     * see the generation-tag comment on [playbackFillRefsGeneration] for why a restart never clears
     * the committed ref maps outright.
     */
    private var playbackFramePrepCoordsKey: Set<String> = emptySet()
    private var pendingPlaybackPrepCoordsKey: Set<String> = emptySet()
    private var pendingPlaybackPrepCoordsKeyStableSinceMs: Long = 0L
    private var playbackPrepGeneration: Long = 0L
    /**
     * Rule: pan-during-playback. True from the moment a coords-restart begins until its full
     * reprime completes — drives the loading spinner for a pan-triggered reload the same way
     * `!playbackWarmupComplete && !initialPlaybackWarmupSatisfied` drives it for the initial
     * play-press warmup. The spinner flag (`Timeline.glVectorFillPrefetchLoadUiActive`) and the
     * per-layer-ready map (`Timeline.glVectorFillLayerPlaybackReady`) are both structurally
     * independent of `playbackWarmupComplete`/`initialPlaybackWarmupSatisfied` — confirmed by
     * reading every call site — so toggling them here can't reintroduce the confirmed clock-freeze
     * regression from resetting those two booleans mid-playback.
     */
    private var panReprimeInProgress: Boolean = false
    private var lastPlaybackFramePrepPhaseA: Int = -1
    /** Last time global playback was inactive; used to ignore sub-second play flicker during camera moves. */
    private var lastGloballyInactiveMs: Long = 0L
    private val playbackPlayEdgeDebounceMs = 400L
    private var lastPlaybackViewportTileKeys: Set<String> = emptySet()
    /** True after the first play-session warmup succeeds; viewport changes must not re-block playback. */
    private var initialPlaybackWarmupSatisfied = false
    private var viewportTilePrefetchPending = false
    private var lastViewportPrefetchSignalMs = 0L
    private val viewportPrefetchSignalDebounceMs = 500L
    /** While true, [drawIntervalMs] is frozen at [viewportHoldIntervalMs] until the live target loads. */
    private var viewportSpatialHoldActive = false
    private var viewportHoldIntervalMs: Long? = null
    /** Phase index when the playback batch cache was last validated at gate-open. */
    private var playbackBatchCacheAnchorPhaseA: Int = -1
    /** Fixed phase pair for gate prefetch while the layer holds (timeline may advance). */
    private var playbackGateAnchorPhaseA: Int = -1
    private var playbackGateAnchorPhaseB: Int = -1
    /** When the gate last opened; used to prioritize tail phases right after animation starts. */
    private var playbackGateOpenedAtMs: Long = 0L
    /** True once every timeline phase has prebuilt refs for the current viewport. */
    private var playbackTimelineFullyPrimed = false
    private var fullTimelineMvtPrefetchJob: Job? = null
    private val fullTimelineTailPhasesPerPrepTick = 3
    /**
     * Rule: parsed-heap-bound. Was 96, then 16 — confirmed via an actual post-GC heap dump
     * (`am dumpheap` + a from-scratch HPROF histogram parse) that there is no retained-object leak
     * here at all: live heap after a forced GC was ~20MB. The OOM is purely a GC-outpacing
     * allocation-rate problem — each `requestTile` call parses eagerly (not deferred) into a full
     * Feature list, gated only by a process-wide 12-concurrent-decode semaphore with no rate limit,
     * and both this renderer's and VectorLineLayerRenderer's independent copy of this loop hammer
     * the same source concurrently. Trimming what's resident doesn't help against a burst that
     * hasn't become garbage yet. Smaller waves + a longer pause between them (see delay below) give
     * the concurrent GC actual wall-clock time to run between bursts instead of racing it.
     */
    private val fullTimelineMvtRequestsPerWave = 6

    internal fun beginPlaybackPrefetchGate(layer: VectorTileLayer? = null) {
        val priorViewportTileKeys = lastPlaybackViewportTileKeys
        var refreshedViewportTileKeys = priorViewportTileKeys
        layer?.let { vectorLayer ->
            val tileLayerRef = vectorLayer as? TileLayer ?: return@let
            tileLayerRef.refreshVisibleTileCoordsForVectorGl()
            val coords = tileLayerRef.visibleTileCoordsForGlVectorPlayback()
            if (coords.isNotEmpty()) {
                refreshedViewportTileKeys =
                    coords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
            }
            (vectorLayer.source as? VectorTileSource)?.cancelAllInFlightTimeSeriesTiles()
        }
        val viewportChanged =
            priorViewportTileKeys.isEmpty() ||
                refreshedViewportTileKeys.isEmpty() ||
                refreshedViewportTileKeys != priorViewportTileKeys
        lastPlaybackViewportTileKeys = refreshedViewportTileKeys
        playbackGateAnchorPhaseA = Timeline.currentPhaseA
        playbackGateAnchorPhaseB = Timeline.currentPhaseB
        playbackGateOpenedAtMs = 0L
        playbackWarmupComplete = false
        initialPlaybackWarmupSatisfied = false
        playbackTimelineFullyPrimed = false
        fullTimelineMvtPrefetchJob?.cancel()
        fullTimelineMvtPrefetchJob = null
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        lastPlaybackFramePrepPhaseA = -1
        if (viewportChanged) {
            playbackFramePrepJob?.cancel()
            playbackFramePrepJob = null
            synchronized(playbackRefsLock) {
                playbackFillRefsByIntervalMs.clear()
                playbackOutlineRefsByIntervalMs.clear()
            }
            playbackBatchCacheAnchorPhaseA = -1
        }
    }

    private fun armViewportSpatialHold(holdIntervalMs: Long?) {
        if (holdIntervalMs == null) return
        viewportSpatialHoldActive = true
        viewportHoldIntervalMs = holdIntervalMs
        if (lastSuccessfulBatches.isNotEmpty()) {
            playbackFrozenBatches = lastSuccessfulBatches
            playbackFrozenOutlineBatches = lastSuccessfulOutlineBatches
            playbackFrozenIntervalMs = holdIntervalMs
        }
    }

    private fun signalPlaybackViewportPrefetch(layer: VectorTileLayer) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastViewportPrefetchSignalMs < viewportPrefetchSignalDebounceMs) return
        lastViewportPrefetchSignalMs = now
        viewportTilePrefetchPending = true
        val phaseMs = timelinePhaseEpochMillis(Timeline.currentPhaseA)
        layer.schedulePlaybackViewportRefresh(priorityIntervalMs = phaseMs)
    }

    /**
     * Rule: pan-during-playback. Cancels stale in-flight MVT requests for tiles outside
     * [visibleTileKeys] and trims retained parsed data for the old viewport, then re-signals a
     * priority prefetch for the new one. Previously only reachable from the warmup/pre-steady-state
     * branch — a mid-playback pan (the exact reported bug scenario) never called this because the
     * steady-state branch's gate (`viewportTilePrefetchPending && viewportTileSetChanged`) is
     * effectively dead: nothing sets `viewportTilePrefetchPending` on an ordinary steady-state pan.
     * Without this, stale in-flight requests for the old viewport could saturate
     * [VectorTileSource]'s fixed in-flight budget and starve the new area's own requests.
     */
    private fun handleViewportTileSetChangedDuringPlayback(
        layer: VectorTileLayer,
        visibleTileKeys: Set<String>,
        signalPrefetch: Boolean,
    ) {
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        layer.cancelPlaybackViewportPrefetch()
        val vtsForCancel = layer.source as? VectorTileSource
        if (vtsForCancel != null && vtsForCancel.retainNativeMvtBytes) {
            val keepSpatial = visibleTileKeys.mapNotNull { key ->
                val parts = key.split('/')
                if (parts.size != 3) return@mapNotNull null
                TileCoord(parts[1].toInt(), parts[2].toInt(), parts[0].toInt()).hash()
            }.toSet()
            vtsForCancel.cancelInFlightTilesOutside(keepSpatial)
            vtsForCancel.trimParsedHeapForTimeline(keepSpatialHashes = keepSpatial)
        }
        lastPlaybackViewportTileKeys = visibleTileKeys
        if (signalPrefetch) {
            signalPlaybackViewportPrefetch(layer)
        }
    }

    /**
     * Rule: native-cache-budget. [vts] is optional only because a couple of call sites (the
     * GeoJSON-source path) have no [VectorTileSource] to sync against — every VectorTileSource-path
     * call site should pass it so the native fill/outline mesh caches' pins stay in lockstep with
     * the JVM-side protected set, not just the JVM caches.
     *
     * Pin sync is diff-based against [previouslyPinnedFillKeys]/[previouslyPinnedOutlineKeys], never
     * a namespace-wide unpin-all: the native outline-mesh namespace is shared with
     * [com.xweather.mapsgl.renderers.VectorLineLayerRenderer] (severe.alerts has both a Fill and a
     * Line consumer on the same [VectorTileSource]), so an unpin-all here would race the other
     * renderer's own pin sync and could wipe its currently-needed pins mid-playback — confirmed as
     * the actual cause of a "meshes evicted, alerts intermittently missing, playback never settles"
     * bug in an earlier version of this fix.
     */
    private fun trimTriangulationCachesIfNeeded(vts: VectorTileSource? = null) {
        val fillProtected = HashSet<String>()
        if (Timeline.isGloballyPlaying) fillProtected.addAll(protectedFillTriKeys())
        else fillProtected.addAll(visibleFillTriKeysThisFrame)
        pinnedGeoJsonFillTriKey?.let { fillProtected.add(it) }
        val outlineProtected = HashSet<String>()
        if (Timeline.isGloballyPlaying) outlineProtected.addAll(protectedOutlineTriKeys())
        else outlineProtected.addAll(visibleOutlineTriKeysThisFrame)
        pinnedGeoJsonOutlineTriKey?.let { outlineProtected.add(it) }
        val maxBytes = if (Timeline.isGloballyPlaying) {
            PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES
        } else {
            PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES / 2
        }
        trimMeshCacheHard(triangulationCache, fillProtected, maxBytes)
        trimMeshCacheHard(outlineTriangulationCache, outlineProtected, maxBytes)
        if (vts != null && SystemClock.elapsedRealtime() - lastNativePinSyncMs > nativePinSyncIntervalMs) {
            lastNativePinSyncMs = SystemClock.elapsedRealtime()
            for (key in previouslyPinnedFillKeys) if (key !in fillProtected) vts.unpinFillTriangulationNative(key)
            for (key in fillProtected) vts.pinFillTriangulationNative(key)
            previouslyPinnedFillKeys = fillProtected
            for (key in previouslyPinnedOutlineKeys) if (key !in outlineProtected) vts.unpinOutlineTriangulationNative(key)
            for (key in outlineProtected) vts.pinOutlineTriangulationNative(key)
            previouslyPinnedOutlineKeys = outlineProtected
        }
    }

    override fun setUpRenderPass(): RenderPass =
        EmptyRenderPass(tileLayer?.source?.id ?: id, tileLayer!!.paint)

    override fun prerender(context: LayerRenderContext<Any>) {
        // Vector fills read directly from VectorTileSource tile cache in draw(); skip quad mesh pipeline.
    }

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {}

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>, camera: Camera) {
        val layer = tileLayer as? VectorTileLayer ?: return
        val geoJsonSource = layer.source as? GeoJSONSource
        val mapboxProj = CameraSync.mapboxProjectionMatrix
        val mapboxMv = CameraSync.mapboxModelViewMatrix
        val useMapboxNativeMv =
            mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
        val proj = if (useMapboxNativeMv) mapboxProj!! else projectionMatrixToFloatArray(camera.projectionMatrix)
        val mvCam = if (useMapboxNativeMv) mapboxMv!! else matrix4ToFloatArray(camera.viewMatrix)
        val mapZoomNow = CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom

        ensureProgram()
        if (glProgram == 0 || uMvpLocation < 0) return

        // ── GeoJSON source path ───────────────────────────────────────────────
        if (geoJsonSource != null) {
            val rawFeatures = geoJsonSource.data?.features()
            if (rawFeatures.isNullOrEmpty()) {
                (tileLayer?.mapController as? MapboxMapController)?.ensureGeoJsonSourceDataLoaded(geoJsonSource)
                return
            }
            val gpuMapTime = VectorMapTime.usesGpuMapTimeReveal(layer.id, layer.filter)
            val mapTimeRevealKey = if (gpuMapTime) VectorMapTime.mapTimeRevealKey(layer.id, layer.filter) else null
            val features = rawFeatures.filter {
                if (gpuMapTime) {
                    VectorFeatureDrawFilter.shouldDrawForGpuMapTimePrep(it, layer.filter, layer.id)
                } else {
                    VectorFeatureDrawFilter.shouldDraw(it, layer.filter, layer.id)
                }
            }
            if (features.isEmpty()) {
                pinnedGeoJsonFillTriKey = null
                pinnedGeoJsonOutlineTriKey = null
                lastGeoJsonFillMesh = null
                return
            }
            val paint = layer.paint as? FillLayerPaint ?: return
            val fillFallbackRgba = fillFallbackRgbaFromLayerPaint(paint)
            val fillFallbackKey = fillFallbackRgba?.contentHashCode() ?: 0
            val fillColorExpression = (paint.fill.color as? StyleValue.Expression)?.expression
            val exprKey = fillColorExpression?.raw?.hashCode() ?: 0
            val styleKey = 31 * fillFallbackKey + exprKey
            val allowLineRibbonFallback = layer.id.startsWith("severe.alerts.")
            // A host app that assigned fill.color expects it to win over the feature's own COLOR
            // property; built-in configurations set theirs in the constructor and are unaffected.
            // See FillPaint.isColorCustomized.
            val expressionColorExclusive =
                layer.id == "severe.stormcells.cone.line" || paint.fill.isColorCustomized
            val opacity = effectiveFillOpacity(paint)
            val strokePaint = paint.stroke
            val strokeConstColor: Color? = strokePaint?.color?.constantValue
            val strokeThicknessPx = (strokePaint?.thickness?.constantValue ?: 0.0).toFloat()
            val strokeOpacity = (strokePaint?.opacity?.constantValue ?: 1.0).toFloat()
            val strokeRgba: FloatArray? = if (strokeConstColor != null && strokeThicknessPx > 0f) {
                floatArrayOf(
                    strokeConstColor.red,
                    strokeConstColor.green,
                    strokeConstColor.blue,
                    strokeConstColor.alpha * strokeOpacity,
                )
            } else null

            val dataVersion = geoJsonSource.geoJsonStencilSequence
            val filterKey = (
                if (gpuMapTime) VectorMapTime.staticPrepFilter(layer.id, layer.filter)
                else VectorLayerDrawFilterDefaults.effectiveFilter(layer.id, layer.filter)
            )?.hashCode() ?: 0
            // GPU map-time: one mesh for all playheads. CPU map-time (range filters): key by the
            // visible feature set — not wall-clock seconds — so playhead motion inside a stable
            // outlook window reuses the mesh and survives playback cache trim.
            val mapTimeKey =
                if (gpuMapTime) {
                    0
                } else if (VectorFeatureDrawFilter.referencesMapTime(layer.id, layer.filter)) {
                    geoJsonVisibleFeatureSetKey(features)
                } else {
                    0
                }
            val geoTriKey =
                "geojson|${geoJsonSource.id}|$styleKey|$dataVersion|fill|$filterKey|$mapTimeKey|ft$TRIANGULATION_COLOR_CACHE_VERSION|${layer.id}"
            val worldCoord = TileCoord(0, 0, 0)
            var rawFill = triangulationCache[geoTriKey]
            if (rawFill == null) {
                // Match line GeoJSON: sync for modest feature counts. Per-second mapTime cache keys
                // (convective range filters) otherwise race the async triangulator and stay empty.
                if (features.size <= GEOJSON_SYNC_TRIANGULATION_MAX_FEATURES) {
                    val sorted = VectorFillSortDefaults.sortedFeaturesForFill(layer.id, features, paint)
                    rawFill = VectorPolygonFillTriangulator.triangulateFeatures(
                        sorted,
                        worldCoord,
                        null,
                        fillFallbackRgba,
                        fillColorExpression,
                        allowLineRibbonFallback,
                        expressionColorExclusive,
                        mapTimeRevealKey,
                    )
                    triangulationCache[geoTriKey] = rawFill
                    pinnedGeoJsonFillTriKey = geoTriKey
                    trimTriangulationCachesIfNeeded()
                } else if (triangulationInProgress.add(geoTriKey)) {
                    val bgFeatures = VectorFillSortDefaults.sortedFeaturesForFill(layer.id, features, paint)
                    val bgFallback = fillFallbackRgba
                    val bgExpr = fillColorExpression
                    val capturedTileLayer = tileLayer
                    backgroundExecutor.submit {
                        try {
                            val computed = VectorPolygonFillTriangulator.triangulateFeatures(
                                bgFeatures,
                                worldCoord,
                                null,
                                bgFallback,
                                bgExpr,
                                allowLineRibbonFallback,
                                expressionColorExclusive,
                                mapTimeRevealKey,
                            )
                            triangulationCache[geoTriKey] = computed
                            pinnedGeoJsonFillTriKey = geoTriKey
                            trimTriangulationCachesIfNeeded()
                            if (computed.isNotEmpty()) {
                                capturedTileLayer?.mapController?.redraw()
                            }
                        } finally {
                            triangulationInProgress.remove(geoTriKey)
                        }
                    }
                }
                // Prefer the mesh we just built; do not re-read after trim (can briefly miss).
                if (rawFill == null) {
                    rawFill = triangulationCache[geoTriKey]
                }
            } else {
                pinnedGeoJsonFillTriKey = geoTriKey
            }
            if (rawFill != null && rawFill.isNotEmpty()) {
                lastGeoJsonFillMesh = rawFill
            } else {
                rawFill = lastGeoJsonFillMesh
            }
            if (rawFill == null || rawFill.isEmpty()) return

            val projectionMatrix = FloatArray(16)
            val cameraArray = FloatArray(16)
            System.arraycopy(proj, 0, projectionMatrix, 0, 16)
            System.arraycopy(mvCam, 0, cameraArray, 0, 16)
            val tileLocal = FloatArray(16)
            val modelViewMatrixArray = FloatArray(16)
            val mvp = FloatArray(16)
            val stride = VectorPolygonFillTriangulator.FILL_FLOATS_PER_VERTEX * 4

            GLES31.glUseProgram(glProgram)
            setTileClip(uClipToTileLocation, false)
            GLES31.glEnable(GLES31.GL_BLEND)
            GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glColorMask(true, true, true, true)
            if (vbo == 0) {
                val h = IntArray(1)
                GLES31.glGenBuffers(1, h, 0)
                vbo = h[0]
            }
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(0)
            GLES31.glEnableVertexAttribArray(1)
            GLES31.glEnableVertexAttribArray(2)
            val depthWasEnabled = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
            val stencilWasEnabled = GLES31.glIsEnabled(GLES31.GL_STENCIL_TEST)
            val scissorWasEnabled = GLES31.glIsEnabled(GLES31.GL_SCISSOR_TEST)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            if (stencilWasEnabled) GLES31.glDisable(GLES31.GL_STENCIL_TEST)
            if (scissorWasEnabled) GLES31.glDisable(GLES31.GL_SCISSOR_TEST)
            try {
                val interleaved = if (opacity < 1f) {
                    val v = rawFill.copyOf()
                    var i = 5
                    while (i < v.size) {
                        v[i] *= opacity
                        i += VectorPolygonFillTriangulator.FILL_FLOATS_PER_VERTEX
                    }
                    v
                } else {
                    rawFill
                }
                val requiredBytes = interleaved.size * 4
                if (fillByteBuffer.capacity() < requiredBytes) {
                    fillByteBuffer =
                        ByteBuffer.allocateDirect(requiredBytes + requiredBytes / 2).order(ByteOrder.nativeOrder())
                }
                fillByteBuffer.position(0)
                fillByteBuffer.limit(requiredBytes)
                fillByteBuffer.asFloatBuffer().put(interleaved)
                fillByteBuffer.position(0)
                GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, requiredBytes, fillByteBuffer, GLES31.GL_DYNAMIC_DRAW)
                GLES31.glEnableVertexAttribArray(2)
                GLES31.glEnableVertexAttribArray(2)
                GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, stride, 0)
                GLES31.glVertexAttribPointer(1, 4, GLES31.GL_FLOAT, false, stride, 8)
                GLES31.glVertexAttribPointer(2, 1, GLES31.GL_FLOAT, false, stride, 24)
                GLES31.glVertexAttribPointer(2, 1, GLES31.GL_FLOAT, false, stride, 24)
                val overscale =
                    (if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, worldCoord.z) else 1f)
                        .coerceAtLeast(1f)
                if (uMapTimeLocation >= 0) {
                    GLES31.glUniform1f(
                        uMapTimeLocation,
                        VectorMapTime.currentMapTimeUniform(gpuMapTime),
                    )
                }
                val geoWorldCoords = GeoJsonWorldCopies.visibleWorldCoords(tileLayer?.mapController)
                // Rule: dateline-world-copy. Redraw z=0 GeoJSON fill for each visible world copy.
                for (drawCoord in geoWorldCoords) {
                    Matrix.setIdentityM(tileLocal, 0)
                    Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                    val worldCopyN = powerTableI.getOrElse(drawCoord.z) { 1 shl drawCoord.z }
                    Matrix.translateM(
                        tileLocal,
                        0,
                        drawCoord.x.toFloat() + drawCoord.offset * worldCopyN,
                        drawCoord.y.toFloat(),
                        0f,
                    )
                    Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
                    Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
                    GLES31.glUniformMatrix4fv(uMvpLocation, 1, false, mvp, 0)
                    GLES31.glDrawArrays(
                        GLES31.GL_TRIANGLES,
                        0,
                        interleaved.size / VectorPolygonFillTriangulator.FILL_FLOATS_PER_VERTEX,
                    )
                }

                if (strokeRgba != null) {
                    ensureOutlineProgram()
                    if (outlineGlProgram != 0 && uOutlineMvpLocation >= 0 && uInvOverscaleLocation >= 0) {
                        val outlineKey =
                            "geojson|${geoJsonSource.id}|outline|$styleKey|$dataVersion|fill|$filterKey|$mapTimeKey|${strokeRgba.contentHashCode()}"
                        var rawOutline = outlineTriangulationCache[outlineKey]
                        if (rawOutline == null) {
                            if (features.size <= GEOJSON_SYNC_TRIANGULATION_MAX_FEATURES) {
                                rawOutline = VectorPolygonFillTriangulator.triangulateOutlines(
                                    features,
                                    worldCoord,
                                    null,
                                    strokeRgba,
                                    layerFallbackThicknessPx = strokeThicknessPx,
                                    mapTimeRevealKey = mapTimeRevealKey,
                                )
                                outlineTriangulationCache[outlineKey] = rawOutline
                                pinnedGeoJsonOutlineTriKey = outlineKey
                                trimTriangulationCachesIfNeeded()
                            } else if (outlineTriangulationInProgress.add(outlineKey)) {
                                val bgFeatures = features
                                val bgStrokeRgba = strokeRgba.copyOf()
                                val bgStrokeThicknessPx = strokeThicknessPx
                                val capturedTileLayer = tileLayer
                                backgroundExecutor.submit {
                                    try {
                                        val computed = VectorPolygonFillTriangulator.triangulateOutlines(
                                            bgFeatures,
                                            worldCoord,
                                            null,
                                            bgStrokeRgba,
                                            layerFallbackThicknessPx = bgStrokeThicknessPx,
                                            mapTimeRevealKey = mapTimeRevealKey,
                                        )
                                        outlineTriangulationCache[outlineKey] = computed
                                        pinnedGeoJsonOutlineTriKey = outlineKey
                                        trimTriangulationCachesIfNeeded()
                                        if (computed.isNotEmpty()) {
                                            capturedTileLayer?.mapController?.redraw()
                                        }
                                    } finally {
                                        outlineTriangulationInProgress.remove(outlineKey)
                                    }
                                }
                            }
                            if (rawOutline == null) {
                                rawOutline = outlineTriangulationCache[outlineKey]
                            }
                        } else {
                            pinnedGeoJsonOutlineTriKey = outlineKey
                        }
                        if (rawOutline != null && rawOutline.isNotEmpty()) {
                            GLES31.glUseProgram(outlineGlProgram)
                            setTileClip(uOutlineClipToTileLocation, false)
                            GLES31.glEnableVertexAttribArray(2)
                            GLES31.glEnableVertexAttribArray(3)
                            GLES31.glEnableVertexAttribArray(4)
                            val outlineInterleaved = applyOutlineOpacity(rawOutline, opacity)
                            uploadOutlineInterleaved(outlineInterleaved)
                            GLES31.glUniform1f(uInvOverscaleLocation, 1f / overscale)
                            if (uOutlineMapTimeLocation >= 0) {
                                GLES31.glUniform1f(
                                    uOutlineMapTimeLocation,
                                    VectorMapTime.currentMapTimeUniform(gpuMapTime),
                                )
                            }
                            for (drawCoord in geoWorldCoords) {
                                Matrix.setIdentityM(tileLocal, 0)
                                Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                                val worldCopyN = powerTableI.getOrElse(drawCoord.z) { 1 shl drawCoord.z }
                                Matrix.translateM(
                                    tileLocal,
                                    0,
                                    drawCoord.x.toFloat() + drawCoord.offset * worldCopyN,
                                    drawCoord.y.toFloat(),
                                    0f,
                                )
                                Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
                                Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
                                GLES31.glUniformMatrix4fv(uOutlineMvpLocation, 1, false, mvp, 0)
                                GLES31.glDrawArrays(
                                    GLES31.GL_TRIANGLES,
                                    0,
                                    outlineInterleaved.size / VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX,
                                )
                            }
                        }
                    }
                }
            } finally {
                if (scissorWasEnabled) GLES31.glEnable(GLES31.GL_SCISSOR_TEST)
                if (stencilWasEnabled) GLES31.glEnable(GLES31.GL_STENCIL_TEST)
                if (depthWasEnabled) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            }
            GLES31.glDisableVertexAttribArray(0)
            GLES31.glDisableVertexAttribArray(1)
            GLES31.glDisableVertexAttribArray(2)
            GLES31.glDisableVertexAttribArray(3)
            GLES31.glDisableVertexAttribArray(4)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
            GLES31.glUseProgram(0)
            return
        }
        // ── VectorTileSource path ─────────────────────────────────────────────
        val vts = layer.source as? VectorTileSource ?: return
        // Rule: paused-mesh-cache-protection. Reset once per frame; drawCoords/drawOutlineCoords
        // repopulate with exactly this frame's visible tri-keys below.
        visibleFillTriKeysThisFrame.clear()
        visibleOutlineTriKeysThisFrame.clear()
        val liveDrawIntervalMs = vectorFillDrawIntervalMs(tileLayer as? TileLayer, vts)
        val tileLayerRef = tileLayer as TileLayer
        val timeSeriesPlayback = vts.isTimeSeriesSource && Timeline.isGloballyPlaying
        val visibleCoords =
            if (timeSeriesPlayback) tileLayerRef.visibleTileCoordsForGlVectorPlayback()
            else tileLayerRef.visibleTileCoordsForMapboxVectorCache()
        val fallbackCoords = if (visibleCoords.isEmpty()) {
            // During zoom transitions Mapbox can briefly report no visible coords at the target Z while
            // custom-geometry tiles are still loading; reuse nearest cached zoom to avoid one-frame blanks.
            val mapZoom = (mapZoomNow ?: 0f).toDouble()
            val zCandidates = tileLayerRef.glVectorPlaybackFallbackZoomCandidates(mapZoom)
            var candidate: List<TileCoord> = emptyList()
            for (z in zCandidates) {
                val cached = tileLayerRef.cachedTileCoordsWithDataAtZInViewport(vts, z)
                if (cached.isNotEmpty()) {
                    candidate = cached
                    break
                }
            }
            candidate
        } else {
            emptyList()
        }
        val targetZoomFloor = floor((mapZoomNow ?: 0f).toDouble()).toInt()
            .coerceAtLeast(0)
            .coerceAtMost(layer.source.maxZoom.toInt())
        val nowMs = SystemClock.elapsedRealtime()
        val zoomFloorChanged = lastZoomFloor != null && lastZoomFloor != targetZoomFloor
        if (lastZoomFloor == null || zoomFloorChanged) {
            holdLastBatchesUntilMs = nowMs + zoomTransitionHoldMs
            // Rule: zoom-settle-hold. The new zoom floor is unsettled until a draw proves otherwise.
            zoomFloorSettled = false
            zoomSettleDeadlineMs = nowMs + zoomSettleCeilingMs
            lastZoomFloor = targetZoomFloor
        }
        // Timeline animation coupling removed — always allow stale-time fallback and promote
        // partial frames immediately (no blink-hold on timeline scrub).
        val playbackStable = Timeline.isGloballyPlaying
        // Rule: zoom-settle-hold. Extend the hold past zoomTransitionHoldMs while mesh builds for
        // the new zoom are still running, so the ancestor fallback and the promotion guard stay up
        // until there is genuinely nothing left to wait for. Scoped to the paused case: during
        // playback the warmup/prefetch pipeline keeps these sets non-empty for unrelated reasons,
        // and its own gating (initialPlaybackWarmupSatisfied / viewportSpatialHoldActive) already
        // owns promotion there.
        val zoomBuildPending =
            triangulationInProgress.isNotEmpty() || outlineTriangulationInProgress.isNotEmpty()
        val zoomTransitionHold = nowMs < holdLastBatchesUntilMs ||
            (!playbackStable && !zoomFloorSettled && zoomBuildPending && nowMs < zoomSettleDeadlineMs)
        val allowStaleTimeFallback = true
        if (!playbackStable) {
            lastGloballyInactiveMs = nowMs
        }
        if (wasGloballyPlaying && !playbackStable) {
            playbackWarmupComplete = true
            initialPlaybackWarmupSatisfied = false
            viewportSpatialHoldActive = false
            viewportHoldIntervalMs = null
            playbackFrozenBatches = emptyList()
            playbackFrozenOutlineBatches = emptyList()
            playbackFrozenIntervalMs = null
            warmupTilePrefetchJob?.cancel()
            warmupTilePrefetchJob = null
        }
        if (zoomFloorChanged && playbackStable && playbackWarmupComplete) {
            playbackStableCoords = emptyList()
            playbackStableCoordsUntilMs = 0L
            if (initialPlaybackWarmupSatisfied) {
                armViewportSpatialHold(liveDrawIntervalMs)
            }
            signalPlaybackViewportPrefetch(layer)
        }
        val visibleTileKeys = visibleCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
        val viewportTileSetChanged =
            visibleTileKeys.isNotEmpty() && visibleTileKeys != lastPlaybackViewportTileKeys
        val steadyStatePlaybackDraw =
            playbackStable &&
                vts.isTimeSeriesSource &&
                playbackWarmupComplete &&
                initialPlaybackWarmupSatisfied
        // Spatial hold / cancel only during warmup or explicit pan prefetch — not per-frame
        // viewport coord jitter while the timeline is playing (scrub never hits this path).
        if (!steadyStatePlaybackDraw) {
            if (playbackStable &&
                playbackWarmupComplete &&
                initialPlaybackWarmupSatisfied &&
                viewportTileSetChanged
            ) {
                armViewportSpatialHold(liveDrawIntervalMs)
            }
            if (playbackStable &&
                playbackWarmupComplete &&
                viewportTileSetChanged
            ) {
                handleViewportTileSetChangedDuringPlayback(
                    layer, visibleTileKeys, signalPrefetch = !zoomFloorChanged,
                )
            } else if (!playbackStable) {
                lastPlaybackViewportTileKeys = emptySet()
                viewportSpatialHoldActive = false
                viewportHoldIntervalMs = null
            }
        } else if (viewportTileSetChanged) {
            // Rule: pan-during-playback. The main fix for "pan to a new area during playback never
            // loads" — this branch used to require viewportTilePrefetchPending (a flag nothing sets
            // during ordinary steady-state panning), so it was effectively dead here. Runs the exact
            // same in-flight-cancel/heap-trim/re-signal handling as the warmup-phase branch above;
            // doesn't touch playbackWarmupComplete/initialPlaybackWarmupSatisfied/the spinner latch, so
            // it can't regress the separately-confirmed clock-freeze bug from resetting those.
            handleViewportTileSetChangedDuringPlayback(layer, visibleTileKeys, signalPrefetch = true)
        }
        val canAttemptDraw =
            visibleCoords.isNotEmpty() ||
                fallbackCoords.isNotEmpty() ||
                lastSuccessfulBatches.isNotEmpty() ||
                (playbackStable && playbackStableCoords.isNotEmpty() && nowMs < playbackStableCoordsUntilMs)
        if (!canAttemptDraw) return

        val paint = layer.paint as? FillLayerPaint ?: return
        val fillFallbackRgba = fillFallbackRgbaFromLayerPaint(paint)
        val fillFallbackKey = fillFallbackRgba?.contentHashCode() ?: 0
        val fillColorExpression = (paint.fill.color as? StyleValue.Expression)?.expression
        val exprKey = fillColorExpression?.raw?.hashCode() ?: 0
        val styleKey = 31 * fillFallbackKey + exprKey
        // Rule: raw-vector-fast-path. Recomputed every draw (cheap — no per-feature cost), so a style
        // or filter change takes effect on the next tile fetch, same as Circle's equivalent call.
        vts.setRawPathEligible(
            layer.id,
            layer.sourceLayer,
            resolveRawFillPathEligible(layer.id, layer.filter, fillColorExpression),
        )
        val allowLineRibbonFallback = layer.id.startsWith("severe.alerts.")
        // A host app that assigned fill.color expects it to win over the feature's own COLOR
        // property; built-in configurations set theirs in the constructor and are unaffected.
        // See FillPaint.isColorCustomized.
        val expressionColorExclusive =
            layer.id == "severe.stormcells.cone.line" || paint.fill.isColorCustomized
        val opacity = effectiveFillOpacity(paint)
        val strokePaint = paint.stroke
        val strokeConstColor: Color? = strokePaint?.color?.constantValue
        val strokeThicknessPx = (strokePaint?.thickness?.constantValue ?: 0.0).toFloat()
        val strokeOpacity = (strokePaint?.opacity?.constantValue ?: 1.0).toFloat()
        val strokeRgba: FloatArray? = if (strokeConstColor != null && strokeThicknessPx > 0f) {
            floatArrayOf(
                strokeConstColor.red,
                strokeConstColor.green,
                strokeConstColor.blue,
                strokeConstColor.alpha * strokeOpacity,
            )
        } else null

        if (viewportSpatialHoldActive &&
            liveDrawIntervalMs != null &&
            visibleCoords.isNotEmpty() &&
            isViewportIntervalReady(vts, visibleCoords, liveDrawIntervalMs, styleKey, layer.sourceLayer)
        ) {
            viewportSpatialHoldActive = false
            viewportHoldIntervalMs = null
        }
        val drawIntervalMs = if (viewportSpatialHoldActive && viewportHoldIntervalMs != null) {
            viewportHoldIntervalMs
        } else {
            liveDrawIntervalMs
        }

        if (drawIntervalMs != null &&
            lastSuccessfulDrawIntervalMs != null &&
            drawIntervalMs != lastSuccessfulDrawIntervalMs
        ) {
            val snappedStep = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
            if (playbackFillRefsByIntervalMs.containsKey(snappedStep)) {
                lastSuccessfulDrawIntervalMs = snappedStep
            }
            if (strokeRgba != null && playbackOutlineRefsByIntervalMs.containsKey(snappedStep)) {
                lastSuccessfulOutlineDrawIntervalMs = snappedStep
            }
        }
        val holdSameInterval =
            drawIntervalMs != null &&
                lastSuccessfulDrawIntervalMs != null &&
                drawIntervalMs == lastSuccessfulDrawIntervalMs
        // JS resolveVectorTileData: exact snap when paused/scrubbing; closest-loaded hold while playing.
        // Time-series vector sources store data under the snapped valid-time key (not the phase
        // epoch-ms), so exact lookup always returns null — always use closest-interval fallback.
        val exactInterval =
            (!Timeline.isGloballyPlaying && !vts.isTimeSeriesSource) ||
                (viewportSpatialHoldActive && drawIntervalMs == viewportHoldIntervalMs)
        // outlineStrokeKey reserved for future outline warmup parity

        if (playbackStable && !wasGloballyPlaying && vts.isTimeSeriesSource && !initialPlaybackWarmupSatisfied) {
            val playResumeGapMs = nowMs - lastGloballyInactiveMs
            if (playResumeGapMs >= playbackPlayEdgeDebounceMs) {
                pausedBatchCount = lastSuccessfulBatches.size
                pausedOutlineBatchCount = lastSuccessfulOutlineBatches.size
                playbackFrozenIntervalMs = liveDrawIntervalMs
                playbackFrozenBatches = lastSuccessfulBatches
                playbackFrozenOutlineBatches = lastSuccessfulOutlineBatches
                playbackWarmupComplete = false
                warmupTilePrefetchJob?.cancel()
                warmupTilePrefetchJob = null
            }
        }
        wasGloballyPlaying = playbackStable

        val projectionMatrix = FloatArray(16)
        val cameraArray = FloatArray(16)
        System.arraycopy(proj, 0, projectionMatrix, 0, 16)
        System.arraycopy(mvCam, 0, cameraArray, 0, 16)

        val tileLocal = FloatArray(16)
        val modelViewMatrixArray = FloatArray(16)
        val mvp = FloatArray(16)

        GLES31.glUseProgram(glProgram)
        setTileClip(uClipToTileLocation, true)
        GLES31.glEnable(GLES31.GL_BLEND)
        GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
        GLES31.glDisable(GLES31.GL_CULL_FACE)
        GLES31.glColorMask(true, true, true, true)

        if (vbo == 0) {
            val h = IntArray(1)
            GLES31.glGenBuffers(1, h, 0)
            vbo = h[0]
        }
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)

        val stride = VectorPolygonFillTriangulator.FILL_FLOATS_PER_VERTEX * 4
        GLES31.glEnableVertexAttribArray(0)
        GLES31.glEnableVertexAttribArray(1)
        GLES31.glEnableVertexAttribArray(2)

        val depthWasEnabled = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        val stencilWasEnabled = GLES31.glIsEnabled(GLES31.GL_STENCIL_TEST)
        val scissorWasEnabled = GLES31.glIsEnabled(GLES31.GL_SCISSOR_TEST)
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        if (stencilWasEnabled) GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        if (scissorWasEnabled) GLES31.glDisable(GLES31.GL_SCISSOR_TEST)
        try {
            // Rule: zero-copy-gpu-upload (Phase 5). Shared MVP/uniform/draw-call tail for both the
            // FloatArray-backed upload path (drawInterleavedForCoord) and the native-cache-direct
            // path (drawDirectBufferForCoord) — the only difference between the two is what's already
            // bound as GL_ARRAY_BUFFER by the time this runs.
            fun applyCoordTransformAndDraw(coord: TileCoord, vertexCount: Int) {
                Matrix.setIdentityM(tileLocal, 0)
                val overscale =
                    if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, coord.z) else 1f
                Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                // Rule: dateline-world-copy. Must add coord.offset * n (n = tile-grid width at this
                // zoom) to the translate X, matching VectorGeometryRenderer.meshInfoForCoord's
                // worldX formula — otherwise every world copy of the same tile draws at the identical
                // screen position instead of its own shifted location, so at wide zoomed-out views
                // spanning the antimeridian only one copy is ever visibly correct (the other draws
                // on top of / in place of it rather than on the far side of the visible seam).
                val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
                Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
                Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
                Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
                GLES31.glUniformMatrix4fv(uMvpLocation, 1, false, mvp, 0)
                if (uMapTimeLocation >= 0) {
                    GLES31.glUniform1f(uMapTimeLocation, VectorMapTime.NEVER_HIDE_UNIFORM)
                }
                GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, vertexCount)
            }

            fun drawInterleavedForCoord(coord: TileCoord, interleaved: FloatArray) {
                val requiredBytes = interleaved.size * 4
                if (fillByteBuffer.capacity() < requiredBytes) {
                    fillByteBuffer = ByteBuffer.allocateDirect(requiredBytes + requiredBytes / 2).order(ByteOrder.nativeOrder())
                }
                fillByteBuffer.position(0)
                fillByteBuffer.limit(requiredBytes)
                fillByteBuffer.asFloatBuffer().put(interleaved)
                fillByteBuffer.position(0)

                GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, requiredBytes, fillByteBuffer, GLES31.GL_DYNAMIC_DRAW)
                GLES31.glEnableVertexAttribArray(2)
                GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, stride, 0)
                GLES31.glVertexAttribPointer(1, 4, GLES31.GL_FLOAT, false, stride, 8)
                GLES31.glVertexAttribPointer(2, 1, GLES31.GL_FLOAT, false, stride, 24)
                applyCoordTransformAndDraw(coord, interleaved.size / VectorPolygonFillTriangulator.FILL_FLOATS_PER_VERTEX)
            }

            /**
             * Rule: zero-copy-gpu-upload (Phase 5). Uploads straight from a native-cache-backed
             * direct [java.nio.ByteBuffer] — no FloatArray materialization, no scratch-buffer copy,
             * zero JVM heap allocation on this path. [byteCount] must be a multiple of 24 (6 floats *
             * 4 bytes/vertex, matching the interleaved [u,v,r,g,b,a] layout native triangulation and
             * [drawInterleavedForCoord] both use). Caller owns the checkout/release lifecycle — this
             * function only reads the buffer, synchronously, before returning.
             */
            fun drawDirectBufferForCoord(coord: TileCoord, buffer: ByteBuffer, byteCount: Int) {
                buffer.order(ByteOrder.nativeOrder())
                buffer.position(0)
                buffer.limit(byteCount)
                GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, byteCount, buffer, GLES31.GL_DYNAMIC_DRAW)
                GLES31.glEnableVertexAttribArray(2)
                GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, stride, 0)
                GLES31.glVertexAttribPointer(1, 4, GLES31.GL_FLOAT, false, stride, 8)
                GLES31.glVertexAttribPointer(2, 1, GLES31.GL_FLOAT, false, stride, 24)
                applyCoordTransformAndDraw(coord, byteCount / 4 / 6)
            }

            // Rule: zoom-transition-hold. Mirrors VectorSymbolLayerRenderer.resolveCachedVectorTile —
            // on a zoom-floor change, the exact-zoom tile's MVT bytes often aren't cached yet, but the
            // previous zoom's tile almost always still is (it was just on screen). Walking up to the
            // nearest cached ancestor and drawing its already-triangulated mesh (scaled via the
            // existing tileRasterOverscale/tileLocal matrix math, same as any other tile) gives an
            // instant, correctly-positioned — if coarser — fill/outline instead of a gap, without
            // waiting on zoomTransitionHoldMs or re-triangulating anything.
            fun resolveCachedVectorTile(
                coord: TileCoord,
                allowParentFallback: Boolean,
            ): Pair<Tile<VectorData>, TileCoord>? {
                vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, allowStaleTimeFallback)
                    ?.let { return it to coord }
                if (!allowParentFallback) return null
                var z = coord.z
                var x = coord.x
                var y = coord.y
                while (z > 0) {
                    z--
                    x = x shr 1
                    y = y shr 1
                    vts.findCachedVectorTileForNominalZxy(z, x, y, allowStaleTimeFallback)?.let { tile ->
                        // Rule: dateline-world-copy. Preserve the original coord's world-copy offset —
                        // it's independent of which zoom level the ancestor fallback resolves to.
                        return tile to TileCoord(x, y, z, coord.offset)
                    }
                }
                return null
            }

            fun drawCoords(
                coords: List<TileCoord>,
                emitGeometry: Boolean = true,
                intervalForDraw: Long? = drawIntervalMs,
                allowParentFallback: Boolean = false,
            ): DrawResult {
                var drawnCount = 0
                var resolvedCount = 0
                var emptyMeshCount = 0
                var allExact = true
                val captured = ArrayList<CachedDrawBatch>()
                val drawnTileKeys = HashSet<String>(coords.size.coerceAtLeast(4))
                val resolveIntervalMs = intervalForDraw?.let { phaseMs ->
                    if (vts.isTimeSeriesSource) vts.snappedTimeSeriesIntervalMs(phaseMs) else phaseMs
                }
                for (coord in coords) {
                    val resolved = resolveCachedVectorTile(coord, allowParentFallback) ?: continue
                    val cached = resolved.first
                    val drawCoord = resolved.second
                    // Rule: zoom-transition-hold. Several visible child coords can all resolve to the
                    // same cached ancestor tile during a zoom-in — draw/count it once, not once per
                    // child, so ancestor fallback never multiplies draw calls beyond the visible set.
                    // Rule: dateline-world-copy. Must include offset — the same real tile can be
                    // needed twice (once per world copy) at wide zoomed-out antimeridian views, and
                    // each occurrence must still be drawn (at its own screen position), not deduped
                    // away as if it were the same "child resolved to the same ancestor" case.
                    if (!drawnTileKeys.add("${drawCoord.z}/${drawCoord.x}/${drawCoord.y}/${drawCoord.offset}")) {
                        resolvedCount++
                        drawnCount++
                        continue
                    }
                    val data = resolveVectorTileData(cached.data, resolveIntervalMs, exactInterval = exactInterval)
                        ?: continue
                    if (resolveIntervalMs != null && data.validTime.time != resolveIntervalMs) {
                        allExact = false
                    }
                    resolvedCount++
                    val triKey = fillTriangulationKey(drawCoord, data, layer.sourceLayer, styleKey)
                    visibleFillTriKeysThisFrame.add(triKey)
                    var raw = triangulationCache[triKey]
                    if (raw == null) {
                        raw = vts.getFillTriangulationNative(triKey)?.also { triangulationCache[triKey] = it }
                    }
                    if (raw == null) {
                        if (!data.hasCpuGeometry()) {
                                if (data.cpuGeometryReleased) {
                                requestCpuGeometryReparse(vts, layer, drawCoord, data, resolveIntervalMs, triKey)
                            } else if (vectorDataHasNoFeatures(data)) {
                                // Parsed and held nothing — an ocean tile, or one the source has no
                                // features for. Counts as drawn-and-empty, not as unresolved: a
                                // viewport is normally mostly these, and treating them as pending
                                // meant a frame could never satisfy DrawResult.resolvedButEmpty.
                                emptyMeshCount++
                            }
                            continue
                        }
                        if (!backgroundExecutor.isShutdown && triangulationInProgress.add(triKey)) {
                            val bgData = data
                            val bgCoord = drawCoord
                            val bgSourceLayer = layer.sourceLayer
                            val bgFillFallback = fillFallbackRgba
                            val bgFillExpr = fillColorExpression
                            val bgDrawFilter = layer.filter
                            backgroundExecutor.submit {
                                try {
                                    val computed = bgData.withGpuUpload {
                                        triangulateFillFeatures(
                                            bgData,
                                            bgCoord,
                                            bgSourceLayer,
                                            bgFillFallback,
                                            bgFillExpr,
                                            allowLineRibbonFallback,
                                            expressionColorExclusive,
                                            vts,
                                            triKey,
                                            layer.id,
                                            bgDrawFilter,
                                        )
                                    }
                                    // Cached even when empty. "This tile has nothing the current
                                    // filter keeps" is a finished answer, not a missing one; leaving
                                    // it out made the tile look unbuilt forever, and the draw then
                                    // held the previous filter's geometry on screen.
                                    triangulationCache[triKey] = computed
                                    trimTriangulationCachesIfNeeded(vts)
                                    if (strokeRgba == null) bgData.markLayerMeshReady(vts, layer.id)
                                    (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                                } finally {
                                    triangulationInProgress.remove(triKey)
                                }
                            }
                        }
                        continue
                    }
                    if (raw.isEmpty()) {
                        emptyMeshCount++
                        if (strokeRgba == null) data.markLayerMeshReady(vts, layer.id)
                        continue
                    }
                    if (strokeRgba == null) data.markLayerMeshReady(vts, layer.id)

                    val interleaved = if (opacity < 1f) {
                        val v = raw.copyOf(raw.size)
                        var i = 5
                        while (i < v.size) {
                            v[i] *= opacity
                            i += VectorPolygonFillTriangulator.FILL_FLOATS_PER_VERTEX
                        }
                        v
                    } else {
                        raw
                    }

                    if (emitGeometry) {
                        drawInterleavedForCoord(drawCoord, interleaved)
                    }
                    drawnCount++
                    captured.add(CachedDrawBatch(drawCoord, interleaved))
                }
                return DrawResult(drawnCount, resolvedCount, captured, allExact, emptyMeshCount)
            }

            // Rule: playback-mesh-cache-bound. Used to take a glHotCacheOnly flag meaning "Java-heap
            // hit or skip this tile this frame" — safe only while the hot cache never evicted a
            // currently-needed entry. Now that trimMeshCacheHard can evict protected keys too (to
            // guarantee a hard memory bound), always resolve through the native-fallback path
            // (resolveFillMesh checks the hot cache first, so this is free in the common case);
            // otherwise an evicted-but-still-visible tile flashes empty until some other path
            // happens to rebuild it.
            // Rule: playback-stale-fallback. Returns the batches it successfully drew (not just a
            // boolean) so the steady-state caller can refresh lastSuccessfulBatches with this
            // frame's genuinely fresh content — see that call site's KDoc for why. Legacy-branch
            // callers that only need "did we draw anything" use `.isNotEmpty()`, an exact match for
            // the old boolean return.
            fun drawPlaybackFillRefs(refs: List<VectorPlaybackMeshRef>): List<CachedDrawBatch> {
                val drawn = ArrayList<CachedDrawBatch>(refs.size)
                for (ref in refs) {
                    // Rule: zero-copy-gpu-upload (Phase 5). Only take the native-direct path when
                    // the JVM hot cache doesn't already have this mesh — a hot-cache hit is already
                    // a free FloatArray reference with no new allocation, so there's nothing to save
                    // by routing it through a native round-trip instead. Also requires full opacity:
                    // sub-1 opacity needs a per-vertex alpha scale, which the FloatArray path already
                    // does cheaply but the direct buffer can't do without a copy (that copy would
                    // defeat the entire point of this path). On a miss, this deliberately does NOT
                    // fall through to populating triangulationCache — the mesh is drawn straight from
                    // native memory and released immediately, so it never becomes a JVM object at all,
                    // for the lifetime of this cache entry. Not added to [drawn]/lastSuccessfulBatches
                    // since there's no FloatArray snapshot to retain; the narrow window where that
                    // matters (a stale-frame fallback needing exactly this tile) just redraws it fresh
                    // next frame via this same path — see resolveFillMesh's KDoc for why a miss is
                    // always "cheap to recompute," never "permanently failed."
                    if (ref.vertexOpacity >= 1f && !triangulationCache.containsKey(ref.triKey)) {
                        val direct = vts.getFillTriangulationNativeDirect(ref.triKey)
                        if (direct != null) {
                            try {
                                if (direct.capacity() > 0) {
                                    drawDirectBufferForCoord(ref.coord, direct, direct.capacity())
                                }
                            } finally {
                                vts.releaseFillTriangulationNativeDirect(ref.triKey)
                            }
                            continue
                        }
                    }
                    val raw = resolveFillMesh(vts, ref.triKey) ?: continue
                    if (raw.isEmpty()) continue
                    val interleaved =
                        if (ref.vertexOpacity < 1f) applyOpacityToInterleaved(raw, ref.vertexOpacity) else raw
                    drawInterleavedForCoord(ref.coord, interleaved)
                    drawn.add(CachedDrawBatch(ref.coord, interleaved))
                }
                return drawn
            }

            fun drawCachedBatches(batches: List<CachedDrawBatch>): Boolean {
                var drewAny = false
                for (batch in batches) {
                    if (batch.interleaved.isEmpty()) continue
                    drawInterleavedForCoord(batch.coord, batch.interleaved)
                    drewAny = true
                }
                return drewAny
            }

            // Rule: zero-copy-gpu-upload (Phase 5). Shared MVP/uniform/draw-call tail — see
            // applyCoordTransformAndDraw's Fill equivalent for why this is split out.
            fun applyOutlineCoordTransformAndDraw(coord: TileCoord, vertexCount: Int) {
                Matrix.setIdentityM(tileLocal, 0)
                val overscale = if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, coord.z) else 1f
                Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                // Rule: dateline-world-copy. See drawInterleavedForCoord's identical fix.
                val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
                Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
                Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
                Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
                GLES31.glUniformMatrix4fv(uOutlineMvpLocation, 1, false, mvp, 0)
                                GLES31.glUniform1f(uInvOverscaleLocation, 1f / overscale.coerceAtLeast(1f))
                if (uOutlineMapTimeLocation >= 0) {
                    GLES31.glUniform1f(uOutlineMapTimeLocation, VectorMapTime.NEVER_HIDE_UNIFORM)
                }
                GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, vertexCount)
            }

            fun drawOutlineInterleavedForCoord(coord: TileCoord, interleaved: FloatArray) {
                uploadOutlineInterleaved(interleaved)
                applyOutlineCoordTransformAndDraw(
                    coord,
                    interleaved.size / VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX,
                )
            }

            /** Rule: zero-copy-gpu-upload (Phase 5). See drawDirectBufferForCoord's KDoc — same
             * contract, outline vertex layout ([OUTLINE_VERTEX_STRIDE_BYTES] bytes per vertex). */
            fun drawOutlineDirectBufferForCoord(coord: TileCoord, buffer: ByteBuffer, byteCount: Int) {
                buffer.order(ByteOrder.nativeOrder())
                buffer.position(0)
                buffer.limit(byteCount)
                GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, byteCount, buffer, GLES31.GL_DYNAMIC_DRAW)
                GLES31.glEnableVertexAttribArray(5)
                GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 0)
                GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 8)
                GLES31.glVertexAttribPointer(2, 4, GLES31.GL_UNSIGNED_BYTE, true, OUTLINE_VERTEX_STRIDE_BYTES, 16)
                GLES31.glVertexAttribPointer(3, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 20)
                GLES31.glVertexAttribPointer(4, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 24)
                GLES31.glVertexAttribPointer(5, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 28)
                applyOutlineCoordTransformAndDraw(coord, byteCount / OUTLINE_VERTEX_STRIDE_BYTES)
            }

            // Rule: playback-mesh-cache-bound. See drawPlaybackFillRefs's comment — same fix.
            // Rule: playback-stale-fallback. See drawPlaybackFillRefs's KDoc — same return-type
            // change, same reason.
            fun drawPlaybackOutlineRefs(refs: List<VectorPlaybackMeshRef>): List<CachedDrawBatch> {
                val drawn = ArrayList<CachedDrawBatch>(refs.size)
                for (ref in refs) {
                    // Rule: zero-copy-gpu-upload (Phase 5). See drawPlaybackFillRefs's identical branch.
                    if (ref.vertexOpacity >= 1f && !outlineTriangulationCache.containsKey(ref.triKey)) {
                        val direct = vts.getOutlineTriangulationNativeDirect(ref.triKey)
                        if (direct != null) {
                            try {
                                if (direct.capacity() > 0) {
                                    drawOutlineDirectBufferForCoord(ref.coord, direct, direct.capacity())
                                }
                            } finally {
                                vts.releaseOutlineTriangulationNativeDirect(ref.triKey)
                            }
                            continue
                        }
                    }
                    val raw = resolveOutlineMesh(vts, ref.triKey) ?: continue
                    if (raw.isEmpty()) continue
                    val interleaved =
                        if (ref.vertexOpacity < 1f) applyOutlineOpacity(raw, ref.vertexOpacity) else raw
                    drawOutlineInterleavedForCoord(ref.coord, interleaved)
                    drawn.add(CachedDrawBatch(ref.coord, interleaved))
                }
                return drawn
            }

            fun drawOutlineCachedBatches(batches: List<CachedDrawBatch>): Boolean {
                var drewAny = false
                for (batch in batches) {
                    if (batch.interleaved.isEmpty()) continue
                    drawOutlineInterleavedForCoord(batch.coord, batch.interleaved)
                    drewAny = true
                }
                return drewAny
            }

            fun drawOutlineCoords(
                coords: List<TileCoord>,
                emitGeometry: Boolean = true,
                allowParentFallback: Boolean = false,
            ): DrawResult {
                var drawnCount = 0
                var resolvedCount = 0
                var emptyMeshCount = 0
                var allExact = true
                val captured = ArrayList<CachedDrawBatch>()
                val drawnTileKeys = HashSet<String>(coords.size.coerceAtLeast(4))
                for (coord in coords) {
                    val resolved = resolveCachedVectorTile(coord, allowParentFallback) ?: continue
                    val cached = resolved.first
                    val drawCoord = resolved.second
                    // Rule: dateline-world-copy. Must include offset — see drawCoords's identical fix.
                    if (!drawnTileKeys.add("${drawCoord.z}/${drawCoord.x}/${drawCoord.y}/${drawCoord.offset}")) {
                        resolvedCount++
                        drawnCount++
                        continue
                    }
                    val resolveIntervalMs = drawIntervalMs?.let { phaseMs ->
                        if (vts.isTimeSeriesSource) vts.snappedTimeSeriesIntervalMs(phaseMs) else phaseMs
                    }
                    val data = resolveVectorTileData(cached.data, resolveIntervalMs, exactInterval = exactInterval) ?: continue
                    if (resolveIntervalMs != null && data.validTime.time != resolveIntervalMs) allExact = false
                    resolvedCount++
                    val outlineKey = outlineTriangulationKey(drawCoord, data, layer.sourceLayer, strokeRgba!!)
                    visibleOutlineTriKeysThisFrame.add(outlineKey)
                    var raw = resolveOutlineMesh(vts, outlineKey)
                    if (raw == null) {
                        if (!data.hasCpuGeometry()) {
                            if (data.cpuGeometryReleased) {
                                requestCpuGeometryReparse(vts, layer, drawCoord, data, resolveIntervalMs, outlineKey)
                            } else if (vectorDataHasNoFeatures(data)) {
                                emptyMeshCount++
                            }
                            continue
                        }
                        if (!backgroundExecutor.isShutdown && outlineTriangulationInProgress.add(outlineKey)) {
                            val bgData = data
                            val bgCoord = drawCoord
                            val bgSourceLayer = layer.sourceLayer
                            val bgStrokeRgba = strokeRgba.copyOf()
                            val bgStrokeThicknessPx = strokeThicknessPx
                            val bgDrawFilter = layer.filter
                            backgroundExecutor.submit {
                                try {
                                    val computed = bgData.withGpuUpload {
                                        triangulateFillOutlines(
                                            bgData,
                                            bgCoord,
                                            bgSourceLayer,
                                            bgStrokeRgba,
                                            bgStrokeThicknessPx,
                                            vts,
                                            outlineKey,
                                            layer.id,
                                            bgDrawFilter,
                                        )
                                    }
                                    // Rule: playback-mesh-cache-bound. Was a stale entry-count cap
                                    // (`size < 64`) predating the byte-budget design — for large
                                    // outline meshes (dense alert boundaries) 64 entries alone can
                                    // be tens of MB over budget before trimTriangulationCachesIfNeeded
                                    // ever runs. Insert unconditionally; the byte-budget trim below
                                    // is the sole size cap now. Empty counts too — see the fill block.
                                    outlineTriangulationCache[outlineKey] = computed
                                    trimTriangulationCachesIfNeeded(vts)
                                    bgData.markLayerMeshReady(vts, layer.id)
                                    (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                                } finally {
                                    outlineTriangulationInProgress.remove(outlineKey)
                                }
                            }
                        }
                        continue
                    }
                    if (raw.isEmpty()) {
                        emptyMeshCount++
                        data.markLayerMeshReady(vts, layer.id)
                        continue
                    }
                    data.markLayerMeshReady(vts, layer.id)
                    val interleaved = applyOutlineOpacity(raw, opacity)
                    if (emitGeometry) {
                        drawOutlineInterleavedForCoord(drawCoord, interleaved)
                    }
                    drawnCount++
                    captured.add(CachedDrawBatch(drawCoord, interleaved))
                }
                return DrawResult(drawnCount, resolvedCount, captured, allExact, emptyMeshCount)
            }

            fun rememberPlaybackFillRefs(intervalMs: Long?, fill: List<VectorPlaybackMeshRef>) {
                if (intervalMs == null) return
                synchronized(playbackRefsLock) {
                    playbackFillRefsByIntervalMs[intervalMs] = fill
                    trimPlaybackMeshRefCache(playbackFillRefsByIntervalMs, maxPlaybackIntervalBatchCacheSize())
                }
            }

            fun rememberPlaybackOutlineRefs(intervalMs: Long?, outline: List<VectorPlaybackMeshRef>) {
                if (intervalMs == null) return
                synchronized(playbackRefsLock) {
                    playbackOutlineRefsByIntervalMs[intervalMs] = outline
                    trimPlaybackMeshRefCache(playbackOutlineRefsByIntervalMs, maxPlaybackIntervalBatchCacheSize())
                }
            }

            fun fillRefsForPlayback(intervalMs: Long?): List<VectorPlaybackMeshRef> {
                if (intervalMs == null) return emptyList()
                return playbackFillRefsByIntervalMs[intervalMs].orEmpty()
            }

            fun outlineRefsForPlayback(intervalMs: Long?): List<VectorPlaybackMeshRef> {
                if (intervalMs == null) return emptyList()
                return playbackOutlineRefsByIntervalMs[intervalMs].orEmpty()
            }

            val primaryCoords = run {
                if (steadyStatePlaybackDraw) {
                    visibleCoords.ifEmpty { fallbackCoords }
                } else if (playbackStable) {
                    if (visibleCoords.isNotEmpty()) {
                        val visibleKeys = visibleCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
                        val stableKeys = playbackStableCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
                        val viewportShifted =
                            playbackStableCoords.isEmpty() || visibleKeys != stableKeys
                        val shouldRefreshStable =
                            playbackStableCoords.isEmpty() ||
                                nowMs >= playbackStableCoordsUntilMs ||
                                visibleCoords.size > playbackStableCoords.size ||
                                viewportShifted
                        if (shouldRefreshStable) {
                            playbackStableCoords = visibleCoords
                            playbackStableCoordsUntilMs = nowMs + playbackCoordsHoldMs
                        }
                        if (!viewportShifted &&
                            playbackStableCoords.isNotEmpty() &&
                            visibleCoords.size < playbackStableCoords.size &&
                            nowMs < playbackStableCoordsUntilMs
                        ) {
                            playbackStableCoords
                        } else {
                            visibleCoords
                        }
                    } else if (playbackStableCoords.isNotEmpty() && nowMs < playbackStableCoordsUntilMs) {
                        playbackStableCoords
                    } else if (fallbackCoords.isNotEmpty()) {
                        fallbackCoords
                    } else {
                        emptyList()
                    }
                } else if (visibleCoords.isNotEmpty()) {
                    visibleCoords
                } else if (fallbackCoords.isNotEmpty()) {
                    fallbackCoords
                } else {
                    emptyList()
                }
            }

            val prepCoords = playbackPrepCoords(layer, primaryCoords.ifEmpty { fallbackCoords })
            if (playbackStable && vts.isTimeSeriesSource && prepCoords.isNotEmpty()) {
                scheduleFullTimelineMvtPrefetch(layer, vts, prepCoords)
                schedulePlaybackFramePreparation(
                    layer = layer,
                    vts = vts,
                    coords = prepCoords,
                    styleKey = styleKey,
                    fillFallbackRgba = fillFallbackRgba,
                    fillColorExpression = fillColorExpression,
                    allowLineRibbonFallback = allowLineRibbonFallback,
                    expressionColorExclusive = expressionColorExclusive,
                    opacity = opacity,
                    strokeRgba = strokeRgba,
                    strokeThicknessPx = strokeThicknessPx,
                )
            }

            if (playbackStable && vts.isTimeSeriesSource && !playbackWarmupComplete && !initialPlaybackWarmupSatisfied) {
                Timeline.setGlVectorFillLayerPlaybackReady(layer.id, false)
                val warmupCoords = if (primaryCoords.isNotEmpty()) primaryCoords else fallbackCoords
                if (warmupCoords.isEmpty()) {
                    // Viewport tiles are not known yet — keep this layer awaiting so the play-press
                    // indicator stays up. Claiming ready here dismissed the spinner on the first
                    // frames, then intervals streamed in with no load UI.
                    return
                }
                    val nowMsForWarmupScan = SystemClock.elapsedRealtime()
                    if (nowMsForWarmupScan - lastWarmupTriangulationScanMs >= warmupTriangulationScanIntervalMs) {
                        lastWarmupTriangulationScanMs = nowMsForWarmupScan
                        val gatePhases = playbackGateReadyPhaseEpochMs(vts)
                        ensureTimeSeriesWarmupTriangulation(
                            vts = vts,
                            layer = layer,
                            coords = warmupCoords,
                            styleKey = styleKey,
                            prefetchPhases = gatePhases,
                            requestMissingTiles = true,
                            fillFallbackRgba = fillFallbackRgba,
                            fillColorExpression = fillColorExpression,
                            allowLineRibbonFallback = allowLineRibbonFallback,
                            expressionColorExclusive = expressionColorExclusive,
                            strokeRgba = strokeRgba,
                            strokeThicknessPx = strokeThicknessPx,
                        )
                    }
                    if (isPlaybackGateReady(vts, warmupCoords, strokeRgba, playbackPrepGeneration)) {
                        playbackWarmupComplete = true
                        initialPlaybackWarmupSatisfied = true
                        playbackBatchCacheAnchorPhaseA = Timeline.currentPhaseA
                        playbackGateAnchorPhaseA = -1
                        playbackGateAnchorPhaseB = -1
                        playbackGateOpenedAtMs = SystemClock.elapsedRealtime()
                        warmupTilePrefetchJob?.cancel()
                        warmupTilePrefetchJob = null
                        Timeline.setGlVectorFillLayerPlaybackReady(layer.id, true)
                        if (!Timeline.isAnyGlVectorFillLayerAwaitingPlayback()) {
                            Timeline.endGlVectorFillPrefetchLoadUi()
                            (tileLayer?.mapController as? MapController)?.scheduleVectorFillPrefetchLoadComplete()
                        }
                    } else {
                        val frozenFill = playbackFrozenBatches.ifEmpty { lastSuccessfulBatches }
                        if (frozenFill.isNotEmpty()) {
                            drawCachedBatches(frozenFill)
                        }
                        if (strokeRgba != null) {
                            val frozenOutline =
                                playbackFrozenOutlineBatches.ifEmpty { lastSuccessfulOutlineBatches }
                            if (!drawOutlineCachedBatchesGl(
                                    frozenOutline,
                                    projectionMatrix,
                                    cameraArray,
                                    useMapboxNativeMv,
                                    mapZoomNow,
                                ) && playbackFrozenIntervalMs != null
                            ) {
                                val holdCoords = frozenFill.map { it.coord }
                                drawOutlineHoldFromTriangulationCache(
                                    coords = holdCoords,
                                    holdIntervalMs = playbackFrozenIntervalMs!!,
                                    vts = vts,
                                    layer = layer,
                                    strokeRgba = strokeRgba,
                                    opacity = opacity,
                                    projectionMatrix = projectionMatrix,
                                    cameraArray = cameraArray,
                                    useMapboxNativeMv = useMapboxNativeMv,
                                    mapZoomNow = mapZoomNow,
                                )
                            }
                        }
                        return
                    }
            }

            if (playbackStable && vts.isTimeSeriesSource && playbackWarmupComplete && !steadyStatePlaybackDraw) {
                val prefetchCoords = primaryCoords.ifEmpty { fallbackCoords }
                if (prefetchCoords.isNotEmpty() && viewportTilePrefetchPending) {
                    val triangulationPhases =
                        if (viewportSpatialHoldActive && drawIntervalMs != null) {
                            listOf(vts.snappedTimeSeriesIntervalMs(drawIntervalMs))
                        } else {
                            playbackPrefetchPhaseEpochMs(vts)
                        }
                    ensureTimeSeriesWarmupTriangulation(
                        vts = vts,
                        layer = layer,
                        coords = prefetchCoords,
                        styleKey = styleKey,
                        prefetchPhases = triangulationPhases,
                        requestMissingTiles = true,
                        fillFallbackRgba = fillFallbackRgba,
                        fillColorExpression = fillColorExpression,
                        allowLineRibbonFallback = allowLineRibbonFallback,
                        expressionColorExclusive = expressionColorExclusive,
                        strokeRgba = strokeRgba,
                        strokeThicknessPx = strokeThicknessPx,
                    )
                    viewportTilePrefetchPending = false
                }
            }

            if (steadyStatePlaybackDraw && drawIntervalMs != null) {
                val snappedDraw = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                // Rule: steady-state-redundant-rebuild. The interval hasn't changed since the last
                // rendered frame (common — phases outlive individual frames at 60fps) and we already
                // have a successfully-drawn batch list for it: just re-issue the GL draw calls from
                // that existing list (drawCachedBatches allocates nothing — it only reads already-
                // built FloatArrays) instead of rebuilding via drawPlaybackFillRefs.
                if (snappedDraw == lastSteadyStateFillIntervalMs && lastSuccessfulBatches.isNotEmpty()) {
                    drawCachedBatches(lastSuccessfulBatches)
                } else {
                    val prebuiltFill = fillRefsForPlayback(snappedDraw)
                    // Rule: playback-stale-fallback. lastSuccessfulBatches was previously only ever
                    // written by the legacy on-demand draw branch below, which never runs once steady
                    // state begins — so it was a single snapshot frozen at whenever steady state was
                    // last (re-)entered, never refreshed again. After a pan-triggered coords-restart, any
                    // stretch of frames where the live phase's refs aren't ready yet (prep hasn't caught
                    // up) fell back to redrawing that same, ever-more-stale pre-pan snapshot forever —
                    // the reported "timeline animates but layer doesn't" bug. Refreshing it here on every
                    // successful steady-state draw makes it a rolling "most recently drawn" snapshot
                    // instead, so the fallback self-heals the instant prep succeeds for any phase.
                    val freshFillBatches = if (prebuiltFill.isNotEmpty()) drawPlaybackFillRefs(prebuiltFill) else emptyList()
                    if (freshFillBatches.isNotEmpty()) {
                        lastSuccessfulBatches = freshFillBatches
                        // Rule: steady-state-partial-resolve. See VectorLineLayerRenderer's identical
                        // fix/KDoc — only lock in the skip-rebuild fast path when every ref resolved;
                        // a partial resolve must keep retrying next frame instead of freezing the gap
                        // for the rest of this interval's phase duration.
                        if (freshFillBatches.size >= prebuiltFill.size) {
                            lastSteadyStateFillIntervalMs = snappedDraw
                        }
                    } else if (lastSuccessfulBatches.isNotEmpty()) {
                        drawCachedBatches(lastSuccessfulBatches)
                    }
                }
                if (strokeRgba != null) {
                    ensureOutlineProgram()
                    if (outlineGlProgram != 0 && uOutlineMvpLocation >= 0 && uInvOverscaleLocation >= 0) {
                        OutlineLoopWrapDiag.note(Timeline.currentPhaseA, snappedDraw)
                        GLES31.glUseProgram(outlineGlProgram)
                        setTileClip(uOutlineClipToTileLocation, true)
                        GLES31.glEnableVertexAttribArray(2)
                        GLES31.glEnableVertexAttribArray(3)
                        GLES31.glEnableVertexAttribArray(4)
                        if (snappedDraw == lastSteadyStateOutlineIntervalMs && lastSuccessfulOutlineBatches.isNotEmpty()) {
                            drawOutlineCachedBatches(lastSuccessfulOutlineBatches)
                        } else {
                            val prebuiltOutline = outlineRefsForPlayback(snappedDraw)
                            val freshOutlineBatches =
                                if (prebuiltOutline.isNotEmpty()) drawPlaybackOutlineRefs(prebuiltOutline) else emptyList()
                            OutlineLoopWrapDiag.noteRebuild(
                                prebuiltOutline.size,
                                freshOutlineBatches.size,
                                lastSuccessfulOutlineBatches.size,
                            )
                            if (freshOutlineBatches.isNotEmpty()) {
                                lastSuccessfulOutlineBatches = freshOutlineBatches
                                // Rule: steady-state-partial-resolve. See VectorLineLayerRenderer's
                                // identical fix/KDoc — only lock in skip-rebuild when every ref resolved.
                                if (freshOutlineBatches.size >= prebuiltOutline.size) {
                                    lastSteadyStateOutlineIntervalMs = snappedDraw
                                }
                            } else if (lastSuccessfulOutlineBatches.isNotEmpty()) {
                                drawOutlineCachedBatches(lastSuccessfulOutlineBatches)
                            }
                        }
                        GLES31.glDisableVertexAttribArray(2)
                        GLES31.glDisableVertexAttribArray(3)
                        GLES31.glDisableVertexAttribArray(4)
                    }
                }
            } else {

            var drew = false
            val timeSeriesPlaying = playbackStable && vts.isTimeSeriesSource
            if (timeSeriesPlaying && playbackWarmupComplete && drawIntervalMs != null) {
                val snappedDraw = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                val holdCoords = primaryCoords.ifEmpty { fallbackCoords }
                if (isIntervalReadyForPlaybackDisplay(
                        vts,
                        holdCoords,
                        drawIntervalMs,
                        styleKey,
                        layer.sourceLayer,
                        strokeRgba,
                    )
                ) {
                    val prebuiltFill = fillRefsForPlayback(snappedDraw)
                    if (prebuiltFill.isNotEmpty()) {
                        drew = drawPlaybackFillRefs(prebuiltFill).isNotEmpty()
                        if (drew) {
                            lastSuccessfulDrawIntervalMs = snappedDraw
                        }
                    }
                }
            }
            if (!drew && !(timeSeriesPlaying && initialPlaybackWarmupSatisfied)) {
            // Rule: zoom-hold-complete-frame. Across a zoom-floor change the held frame stays up until
            // every visible tile at the new zoom is built (drawn, or known empty), then the new frame
            // replaces it in one step. Drawing and promoting whatever subset was ready blanked the rest
            // of the view - whole tile-shaped areas of alerts - for a frame or two after each zoom.
            val holdForCompleteFrame = zoomTransitionHold && !playbackStable && lastSuccessfulBatches.isNotEmpty()
            val primaryResult = drawCoords(
                primaryCoords,
                emitGeometry = !holdForCompleteFrame,
                allowParentFallback = zoomTransitionHold,
            )
            val deferPartialFrame = holdForCompleteFrame &&
                primaryResult.drawnCount + primaryResult.emptyMeshCount < primaryCoords.size
            if (holdForCompleteFrame && !deferPartialFrame) drawCachedBatches(primaryResult.batches)
            val primaryFullCoverage = primaryResult.fullCoverage
            val primaryCoverage =
                if (primaryResult.resolvedCount > 0) {
                    primaryResult.drawnCount.toFloat() / primaryResult.resolvedCount.toFloat()
                } else {
                    0f
                }
            // Rule: zoom-settle-hold. The new zoom floor counts as settled only once every visible
            // coord resolved to a tile, all of them drew, and no mesh build is still queued —
            // fullCoverage alone is not enough, because resolvedCount excludes coords that have no
            // cached tile yet, so it can read "complete" while half the viewport is still empty.
            if (!zoomFloorSettled &&
                primaryResult.fullCoverage &&
                primaryResult.resolvedCount >= primaryCoords.size &&
                triangulationInProgress.isEmpty() &&
                outlineTriangulationInProgress.isEmpty()
            ) {
                zoomFloorSettled = true
            }
            val minFillPromotionCount = maxOf(lastSuccessfulBatches.size, pausedBatchCount).coerceAtLeast(1)
            val promotePrimary = !deferPartialFrame && primaryResult.drawnCount > 0 && (
                (!playbackStable && (lastSuccessfulBatches.isEmpty() || primaryFullCoverage || primaryCoverage >= minPromotionCoverage || !zoomTransitionHold)) ||
                    (timeSeriesPlaying && initialPlaybackWarmupSatisfied && !viewportSpatialHoldActive && primaryFullCoverage) ||
                    (timeSeriesPlaying && !initialPlaybackWarmupSatisfied && primaryFullCoverage) ||
                    (viewportSpatialHoldActive && primaryFullCoverage) ||
                    (playbackStable && !vts.isTimeSeriesSource && primaryResult.drawnCount >= minFillPromotionCount)
                )
            drew = !deferPartialFrame && primaryResult.drawnCount > 0
            if (promotePrimary && primaryResult.batches.isNotEmpty()) {
                lastSuccessfulBatches = primaryResult.batches
                // Only commit this interval as "done" when the resolved data was an exact match.
                // When drawing closest-interval fallback (data.validTime != drawIntervalMs), keep
                // lastSuccessfulDrawIntervalMs null so subsequent frames keep calling drawCoords and
                // can replace the stale display as soon as the exact-interval tile arrives.
                if (primaryResult.allExact) {
                    lastSuccessfulDrawIntervalMs = drawIntervalMs
                } else {
                    lastSuccessfulDrawIntervalMs = null
                }
            } else if (!deferPartialFrame && primaryResult.resolvedButEmpty) {
                // Every visible tile built a mesh and every mesh was empty — the filter keeps
                // nothing in view. That is a finished frame, so it promotes like any other and the
                // held batches are dropped. Falling through to the hold branches below instead is
                // what left the previous filter's polygons on screen: with nothing drawn there was
                // never a "successful" frame to replace them.
                lastSuccessfulBatches = emptyList()
                lastSuccessfulDrawIntervalMs = if (primaryResult.allExact) drawIntervalMs else null
                drew = true
            } else if (playbackStable && lastSuccessfulBatches.isNotEmpty() &&
                !(timeSeriesPlaying && initialPlaybackWarmupSatisfied && !viewportSpatialHoldActive && drew) &&
                !(timeSeriesPlaying && drawIntervalMs != null &&
                    vts.snappedTimeSeriesIntervalMs(drawIntervalMs) != lastSuccessfulDrawIntervalMs)
            ) {
                // Promotion failed during playback (partial or zero draw). Overdraw the
                // partial tiles with the last complete cached frame so no incomplete frame
                // is ever visible — the layer holds its last good state until a full draw
                // succeeds and promotes.
                drew = drawCachedBatches(lastSuccessfulBatches)
            } else if (!drew && holdSameInterval && lastSuccessfulBatches.isNotEmpty()) {
                drew = drawCachedBatches(lastSuccessfulBatches)
            } else if (playbackStable && !drew && drawIntervalMs != null) {
                val holdCoords = primaryCoords.ifEmpty { fallbackCoords }
                if (isIntervalReadyForPlaybackDisplay(
                        vts,
                        holdCoords,
                        drawIntervalMs,
                        styleKey,
                        layer.sourceLayer,
                        strokeRgba,
                    )
                ) {
                    val snappedHold = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                    val held = fillRefsForPlayback(snappedHold)
                    if (held.isNotEmpty()) {
                        drew = drawPlaybackFillRefs(held).isNotEmpty()
                        lastSuccessfulDrawIntervalMs = snappedHold
                    }
                }
            } else if (timeSeriesPlaying && initialPlaybackWarmupSatisfied && lastSuccessfulBatches.isNotEmpty()) {
                drew = drawCachedBatches(lastSuccessfulBatches)
            }
            if (!drew && fallbackCoords.isNotEmpty() && fallbackCoords !== primaryCoords &&
                !(timeSeriesPlaying && initialPlaybackWarmupSatisfied)
            ) {
                val fallbackResult = drawCoords(fallbackCoords, emitGeometry = true, allowParentFallback = zoomTransitionHold)
                val fallbackFullCoverage = fallbackResult.fullCoverage
                val fallbackCoverage =
                    if (fallbackResult.resolvedCount > 0) {
                        fallbackResult.drawnCount.toFloat() / fallbackResult.resolvedCount.toFloat()
                    } else {
                        0f
                    }
                val promoteFallback = fallbackResult.drawnCount > 0 && (
                    (!playbackStable && (lastSuccessfulBatches.isEmpty() || fallbackFullCoverage || fallbackCoverage >= minPromotionCoverage || !zoomTransitionHold)) ||
                        (timeSeriesPlaying && initialPlaybackWarmupSatisfied && !viewportSpatialHoldActive && fallbackFullCoverage) ||
                        (timeSeriesPlaying && !initialPlaybackWarmupSatisfied && fallbackFullCoverage) ||
                        (viewportSpatialHoldActive && fallbackFullCoverage) ||
                        (playbackStable && !vts.isTimeSeriesSource && fallbackResult.drawnCount >= minFillPromotionCount)
                    )
                val fallbackDrew = fallbackResult.drawnCount > 0
                if (promoteFallback && fallbackResult.batches.isNotEmpty()) {
                    lastSuccessfulBatches = fallbackResult.batches
                    if (fallbackResult.allExact) {
                        lastSuccessfulDrawIntervalMs = drawIntervalMs
                        lastSuccessfulDrawIntervalMs = drawIntervalMs
                    } else {
                        lastSuccessfulDrawIntervalMs = null
                    }
                    drew = true
                } else if (!fallbackDrew && holdSameInterval && lastSuccessfulBatches.isNotEmpty()) {
                    drew = drawCachedBatches(lastSuccessfulBatches)
                } else {
                    drew = fallbackDrew
                }
            }
            // Safety net: if every draw path failed and we're not playing, show the last
            // known-good frame so the layer never goes blank mid-scrub or on zoom transitions.
            if (!drew && lastSuccessfulBatches.isNotEmpty()) {
                drawCachedBatches(lastSuccessfulBatches)
            }

            if (strokeRgba != null) {
                ensureOutlineProgram()
                if (outlineGlProgram != 0 && uOutlineMvpLocation >= 0 && uInvOverscaleLocation >= 0) {
                    GLES31.glUseProgram(outlineGlProgram)
                    setTileClip(uOutlineClipToTileLocation, true)
                    GLES31.glEnableVertexAttribArray(2)
                    GLES31.glEnableVertexAttribArray(3)
                    GLES31.glEnableVertexAttribArray(4)

                    val outlinePrimaryCoords = primaryCoords
                    var outlineDrew = false
                    val minOutlinePromotionCount =
                        maxOf(lastSuccessfulOutlineBatches.size, pausedOutlineBatchCount).coerceAtLeast(1)
                    if (timeSeriesPlaying && playbackWarmupComplete && drawIntervalMs != null) {
                        val snappedOutlineDraw = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                        val outlineHoldCoords = outlinePrimaryCoords.ifEmpty { fallbackCoords }
                        if (isIntervalReadyForPlaybackDisplay(
                                vts,
                                outlineHoldCoords,
                                drawIntervalMs,
                                styleKey,
                                layer.sourceLayer,
                                strokeRgba,
                            )
                        ) {
                            val prebuiltOutline = outlineRefsForPlayback(snappedOutlineDraw)
                            if (prebuiltOutline.isNotEmpty()) {
                                outlineDrew = drawPlaybackOutlineRefs(prebuiltOutline).isNotEmpty()
                                if (outlineDrew) {
                                    lastSuccessfulOutlineDrawIntervalMs = snappedOutlineDraw
                                }
                            }
                        }
                    }
                    if (!outlineDrew && !(timeSeriesPlaying && initialPlaybackWarmupSatisfied)) {
                    val outlinePrimaryResult = drawOutlineCoords(
                        outlinePrimaryCoords, emitGeometry = true, allowParentFallback = zoomTransitionHold,
                    )
                    val outlinePrimaryFull = outlinePrimaryResult.fullCoverage
                    val outlinePrimaryCoverage =
                        if (outlinePrimaryResult.resolvedCount > 0) {
                            outlinePrimaryResult.drawnCount.toFloat() / outlinePrimaryResult.resolvedCount.toFloat()
                        } else {
                            0f
                        }
                    val promoteOutlinePrimary = outlinePrimaryResult.drawnCount > 0 && (
                        (!playbackStable && (lastSuccessfulOutlineBatches.isEmpty() || outlinePrimaryFull || outlinePrimaryCoverage >= minPromotionCoverage || !zoomTransitionHold)) ||
                            (timeSeriesPlaying && initialPlaybackWarmupSatisfied && !viewportSpatialHoldActive && outlinePrimaryFull) ||
                            (timeSeriesPlaying && !initialPlaybackWarmupSatisfied && outlinePrimaryFull) ||
                            (viewportSpatialHoldActive && outlinePrimaryFull) ||
                            (playbackStable && !vts.isTimeSeriesSource && outlinePrimaryResult.drawnCount >= minOutlinePromotionCount)
                        )
                    outlineDrew = outlinePrimaryResult.drawnCount > 0
                    if (promoteOutlinePrimary && outlinePrimaryResult.batches.isNotEmpty()) {
                        lastSuccessfulOutlineBatches = outlinePrimaryResult.batches
                        if (outlinePrimaryResult.allExact) {
                            lastSuccessfulOutlineDrawIntervalMs = drawIntervalMs
                            lastSuccessfulOutlineDrawIntervalMs = drawIntervalMs
                        } else {
                            lastSuccessfulOutlineDrawIntervalMs = null
                        }
                    } else if (outlinePrimaryResult.resolvedButEmpty) {
                        // See DrawResult.resolvedButEmpty — a complete frame with nothing in it.
                        lastSuccessfulOutlineBatches = emptyList()
                        lastSuccessfulOutlineDrawIntervalMs =
                            if (outlinePrimaryResult.allExact) drawIntervalMs else null
                        outlineDrew = true
                    } else if (playbackStable && lastSuccessfulOutlineBatches.isNotEmpty()) {
                        outlineDrew = drawOutlineCachedBatches(lastSuccessfulOutlineBatches)
                    } else if (!outlineDrew && holdSameInterval && lastSuccessfulOutlineBatches.isNotEmpty()) {
                        outlineDrew = drawOutlineCachedBatches(lastSuccessfulOutlineBatches)
                    } else if (playbackStable && !outlineDrew && drawIntervalMs != null) {
                        val outlineHoldCoords = outlinePrimaryCoords.ifEmpty { fallbackCoords }
                        if (isIntervalReadyForPlaybackDisplay(
                                vts,
                                outlineHoldCoords,
                                drawIntervalMs,
                                styleKey,
                                layer.sourceLayer,
                                strokeRgba,
                            )
                        ) {
                            val snappedOutlineHold = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                            val held = outlineRefsForPlayback(snappedOutlineHold)
                            if (held.isNotEmpty()) {
                                outlineDrew = drawPlaybackOutlineRefs(held).isNotEmpty()
                                lastSuccessfulOutlineDrawIntervalMs = snappedOutlineHold
                            }
                        }
                    }
                    } else if (timeSeriesPlaying && initialPlaybackWarmupSatisfied &&
                        lastSuccessfulOutlineBatches.isNotEmpty()
                    ) {
                        outlineDrew = drawOutlineCachedBatches(lastSuccessfulOutlineBatches)
                    }
                    if (!outlineDrew && fallbackCoords.isNotEmpty() && fallbackCoords !== outlinePrimaryCoords &&
                        !(timeSeriesPlaying && initialPlaybackWarmupSatisfied)
                    ) {
                        val outlineFallbackResult = drawOutlineCoords(
                            fallbackCoords, emitGeometry = true, allowParentFallback = zoomTransitionHold,
                        )
                        val outlineFallbackFull = outlineFallbackResult.fullCoverage
                        val outlineFallbackCoverage =
                            if (outlineFallbackResult.resolvedCount > 0) {
                                outlineFallbackResult.drawnCount.toFloat() / outlineFallbackResult.resolvedCount.toFloat()
                            } else {
                                0f
                            }
                        val promoteOutlineFallback = outlineFallbackResult.drawnCount > 0 && (
                            (!playbackStable && (lastSuccessfulOutlineBatches.isEmpty() || outlineFallbackFull || outlineFallbackCoverage >= minPromotionCoverage || !zoomTransitionHold)) ||
                                (timeSeriesPlaying && initialPlaybackWarmupSatisfied && !viewportSpatialHoldActive && outlineFallbackFull) ||
                                (timeSeriesPlaying && !initialPlaybackWarmupSatisfied && outlineFallbackFull) ||
                                (viewportSpatialHoldActive && outlineFallbackFull) ||
                                (playbackStable && !vts.isTimeSeriesSource && outlineFallbackResult.drawnCount >= minOutlinePromotionCount)
                            )
                        val outlineFallbackDrew = outlineFallbackResult.drawnCount > 0
                        if (promoteOutlineFallback && outlineFallbackResult.batches.isNotEmpty()) {
                            lastSuccessfulOutlineBatches = outlineFallbackResult.batches
                            if (outlineFallbackResult.allExact) {
                                lastSuccessfulOutlineDrawIntervalMs = drawIntervalMs
                                lastSuccessfulOutlineDrawIntervalMs = drawIntervalMs
                            } else {
                                lastSuccessfulOutlineDrawIntervalMs = null
                            }
                            outlineDrew = true
                        } else if (!outlineFallbackDrew && holdSameInterval && lastSuccessfulOutlineBatches.isNotEmpty()) {
                            outlineDrew = drawOutlineCachedBatches(lastSuccessfulOutlineBatches)
                        } else {
                            outlineDrew = outlineFallbackDrew
                        }
                    }

                    GLES31.glDisableVertexAttribArray(2)
                    GLES31.glDisableVertexAttribArray(3)
                    GLES31.glDisableVertexAttribArray(4)
                }
            }
            }
            }

        } finally {
            if (scissorWasEnabled) GLES31.glEnable(GLES31.GL_SCISSOR_TEST)
            if (stencilWasEnabled) GLES31.glEnable(GLES31.GL_STENCIL_TEST)
            if (depthWasEnabled) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }

        GLES31.glDisableVertexAttribArray(0)
        GLES31.glDisableVertexAttribArray(1)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        GLES31.glUseProgram(0)
    }

    private fun projectionMatrixToFloatArray(pm: ProjectionMatrix): FloatArray =
        FloatArray(16) { i -> pm.elements[i] }

    private fun matrix4ToFloatArray(m: Matrix4): FloatArray =
        FloatArray(16) { i -> m.elements[i] }

    /** RGBA for vertices when MVT features have no `COLOR` property (matches Mapbox `fill-color` + `fill-opacity`). */
    private fun fillFallbackRgbaFromLayerPaint(paint: FillLayerPaint): FloatArray? {
        val c = paint.fill.color.constantValue ?: return null
        val fillOp = (paint.fill.opacity.constantValue ?: 1.0).toFloat().coerceIn(0f, 1f)
        return floatArrayOf(
            c.red,
            c.green,
            c.blue,
            (c.alpha * fillOp).coerceIn(0f, 1f),
        )
    }

    private fun uploadOutlineInterleaved(interleaved: FloatArray) {
        val requiredBytes = interleaved.size * 4
        if (outlineByteBuffer.capacity() < requiredBytes) {
            outlineByteBuffer =
                ByteBuffer.allocateDirect(requiredBytes + requiredBytes / 2).order(ByteOrder.nativeOrder())
        }
        outlineByteBuffer.position(0)
        outlineByteBuffer.limit(requiredBytes)
        outlineByteBuffer.asFloatBuffer().put(interleaved)
        outlineByteBuffer.position(0)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, requiredBytes, outlineByteBuffer, GLES31.GL_DYNAMIC_DRAW)
        GLES31.glEnableVertexAttribArray(5)
        GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 0)
        GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 8)
        GLES31.glVertexAttribPointer(2, 4, GLES31.GL_UNSIGNED_BYTE, true, OUTLINE_VERTEX_STRIDE_BYTES, 16)
        GLES31.glVertexAttribPointer(3, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 20)
        GLES31.glVertexAttribPointer(4, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 24)
        GLES31.glVertexAttribPointer(5, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 28)
    }

    private fun applyOutlineOpacity(interleaved: FloatArray, opacity: Float): FloatArray {
        if (opacity >= 1f) return interleaved
        val v = interleaved.copyOf(interleaved.size)
        var i = 4
        while (i < v.size) {
            v[i] = VectorPolygonFillTriangulator.repackColorAlpha(v[i], opacity)
            i += VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX
        }
        return v
    }

    /** Tiles whose CPU geometry is being brought back, and how often each has been asked for. */
    private val cpuReparseInFlight: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private val cpuReparseAttempts = ConcurrentHashMap<String, Int>()

    /**
     * Brings back the CPU features of a tile that released them once its mesh reached the GPU, so a
     * mesh that now has to be rebuilt under a **different** cache key has something to build from.
     *
     * A filter change is the case that needs this. Every other thing that moves a fill mesh's cache
     * key — style, stroke, map time — also changes the tile data or arrives before upload, so the
     * draw loop's plain `continue` was survivable: something else would rebuild the tile shortly.
     * A filter change moves the key on its own, with the tile data untouched, and the skip is then
     * permanent: the layer goes on drawing the geometry it built under the old filter for as long
     * as those tiles stay cached.
     *
     * [VectorTileSource.ensureTimeSeriesParsedAt] is the same recovery the playback path already
     * performs inline; the live path could not call it because it suspends. Nothing is refetched —
     * the MVT bytes stay in native memory ([VectorTileSource.retainNativeMvtBytes]).
     */
    private fun requestCpuGeometryReparse(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        coord: TileCoord,
        data: VectorData,
        intervalMs: Long?,
        meshKey: String,
    ) {
        // A tile that parsed empty never had geometry to give up; re-parsing finds nothing again.
        if (!data.cpuGeometryReleased) return
        if (!vts.isTimeSeriesSource || !vts.retainNativeMvtBytes) return
        val phaseMs = intervalMs ?: data.validTime.time
        // Keyed by filter as well as tile, so each filter the app selects gets its own budget and a
        // tile that went quiet under one filter is still retried under the next.
        val reparseKey = "${coord.z}/${coord.x}/${coord.y}|$phaseMs|f$drawFilterKey"
        // Bounded, because a re-parse does not guarantee a mesh: a tile holding no feature the
        // current filter keeps triangulates to nothing, caches nothing, and asks again next frame.
        // Without a cap that is an unbounded re-parse loop on every tile outside the filter.
        if ((cpuReparseAttempts[reparseKey] ?: 0) >= MAX_CPU_REPARSE_ATTEMPTS) return
        if (!cpuReparseInFlight.add(reparseKey)) return
        cpuReparseAttempts.merge(reparseKey, 1, Int::plus)
        if (cpuReparseAttempts.size > MAX_CPU_REPARSE_KEYS) cpuReparseAttempts.clear()
        layer.externalScope.launch(Dispatchers.Default) {
            try {
                val restored = vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, phaseMs)
                if (restored != null) {
                    triangulationCache.remove(meshKey)
                    (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                }
            } catch (t: Throwable) {
                MapsGLDebug.logE("VectorFillLayerRenderer", "CPU geometry re-parse failed for $reparseKey", t)
            } finally {
                cpuReparseInFlight.remove(reparseKey)
            }
        }
    }

    private fun outlineTriangulationKey(
        coord: TileCoord,
        data: VectorData,
        sourceLayer: String?,
        strokeRgba: FloatArray,
    ): String {
        val (outlineMeshFp, modeTag) = data.meshModeFingerprint(sourceLayer)
        return "${coord.z}/${coord.x}/${coord.y}|$sourceLayer|$outlineMeshFp|outline|$modeTag|" +
            "${strokeRgba.contentHashCode()}|f$drawFilterKey"
    }

    /**
     * Rule: raw-vector-fast-path. Routes to [VectorPolygonFillTriangulator.triangulateFeaturesRaw]
     * when [data] was parsed via the raw MVT path (non-null [VectorData.rawFeatures]), else the
     * heavy [VectorPolygonFillTriangulator.triangulateFeatures] path. See
     * [resolveRawFillPathEligible] for how eligibility is proven before [data] can ever carry raw
     * features for a fill consumer.
     */
    private fun triangulateFillFeatures(
        data: VectorData,
        coord: TileCoord,
        sourceLayer: String?,
        fillFallbackRgba: FloatArray?,
        fillColorExpression: Expression?,
        allowLineRibbonFallback: Boolean,
        expressionColorExclusive: Boolean,
        // Rule: native-triangulation-zero-copy-write. Optional — when both are supplied, the mesh is
        // written to vts's native fill-mesh cache internally (bytes-direct when every polygon in this
        // tile triangulated natively, else the existing FloatArray-encode path), so the caller does
        // NOT also need its own vts.putFillTriangulationNative(triKey, computed) call afterward.
        vts: VectorTileSource? = null,
        triKey: String? = null,
        layerId: String? = null,
        // Snapshotted by the caller alongside triKey rather than read off tileLayer here: this runs
        // on a background executor, and a filter changing mid-flight would otherwise store the new
        // filter's mesh under the old filter's cache key.
        drawFilter: Expression? = null,
    ): FloatArray {
        val rawFeatures = data.rawFeatures
        val sortPaint = tileLayer?.paint as? FillLayerPaint
        return if (rawFeatures != null) {
            val sortedRaw = VectorFillSortDefaults.sortedRawFeaturesForFill(layerId, rawFeatures, sortPaint)
            VectorPolygonFillTriangulator.triangulateFeaturesRaw(
                sortedRaw,
                coord,
                fillFallbackRgba,
                fillColorExpression,
                allowLineRibbonFallback,
                expressionColorExclusive,
                useNativeTriangulation = NATIVE_FILL_TRIANGULATION_ENABLED,
                vts = vts,
                nativeCacheKey = triKey,
            )
        } else {
            val drawable = fillFeaturesPassingDrawFilter(data.features, drawFilter, layerId)
            val sorted = VectorFillSortDefaults.sortedFeaturesForFill(layerId, drawable, sortPaint)
            VectorPolygonFillTriangulator.triangulateFeatures(
                sorted,
                coord,
                sourceLayer,
                fillFallbackRgba,
                fillColorExpression,
                allowLineRibbonFallback,
                expressionColorExclusive,
            ).also { floats ->
                if (vts != null && triKey != null && floats.isNotEmpty()) {
                    vts.putFillTriangulationNative(triKey, floats)
                }
            }
        }
    }

    /** [triangulateFillFeatures]'s outline counterpart. Fill's stroke is always constant here (see draw()). */
    private fun triangulateFillOutlines(
        data: VectorData,
        coord: TileCoord,
        sourceLayer: String?,
        strokeRgba: FloatArray,
        layerFallbackThicknessPx: Float?,
        // Rule: native-triangulation-zero-copy-write. See triangulateFillFeatures's identical params.
        vts: VectorTileSource? = null,
        triKey: String? = null,
        layerId: String? = null,
        drawFilter: Expression? = null,
    ): FloatArray {
        val rawFeatures = data.rawFeatures
        return if (rawFeatures != null) {
            VectorPolygonFillTriangulator.triangulateOutlinesRaw(
                rawFeatures,
                coord,
                strokeRgba,
                null,
                null,
                false,
                layerFallbackThicknessPx,
                null,
                1f,
                useNativeTriangulation = NATIVE_OUTLINE_TRIANGULATION_ENABLED,
                vts = vts,
                nativeCacheKey = triKey,
            )
        } else {
            VectorPolygonFillTriangulator.triangulateOutlines(
                fillFeaturesPassingDrawFilter(data.features, drawFilter, layerId),
                coord,
                sourceLayer,
                strokeRgba,
                layerFallbackThicknessPx = layerFallbackThicknessPx,
                // Rule: outline-tile-clip-edge-skip. MVT branch (raw fast path unavailable) — the
                // GeoJSON outline call sites above deliberately leave this off.
                skipTileClipEdges = true,
            ).also { floats ->
                if (vts != null && triKey != null && floats.isNotEmpty()) {
                    vts.putOutlineTriangulationNative(triKey, floats)
                }
            }
        }
    }

    /** True when [data] parsed empty — not when CPU geometry was consumed after GPU upload. */
    private fun vectorDataHasNoFeatures(data: VectorData): Boolean = data.isVacuousParse()

    private fun drawOutlineCachedBatchesGl(
        batches: List<CachedDrawBatch>,
        projectionMatrix: FloatArray,
        cameraArray: FloatArray,
        useMapboxNativeMv: Boolean,
        mapZoomNow: Double,
    ): Boolean {
        if (batches.isEmpty()) return false
        ensureOutlineProgram()
        if (outlineGlProgram == 0 || uOutlineMvpLocation < 0 || uInvOverscaleLocation < 0) return false
        GLES31.glUseProgram(outlineGlProgram)
        setTileClip(uOutlineClipToTileLocation, true)
        GLES31.glEnableVertexAttribArray(2)
        GLES31.glEnableVertexAttribArray(3)
        GLES31.glEnableVertexAttribArray(4)
        val tileLocal = FloatArray(16)
        val modelViewMatrixArray = FloatArray(16)
        val mvp = FloatArray(16)
        var drewAny = false
        for (batch in batches) {
            if (batch.interleaved.isEmpty()) continue
            uploadOutlineInterleaved(batch.interleaved)
            Matrix.setIdentityM(tileLocal, 0)
            val overscale =
                if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, batch.coord.z) else 1f
            Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
            // Rule: dateline-world-copy. See drawInterleavedForCoord's identical fix.
            val worldCopyN = powerTableI.getOrElse(batch.coord.z) { 1 shl batch.coord.z }
            Matrix.translateM(
                tileLocal, 0,
                batch.coord.x.toFloat() + batch.coord.offset * worldCopyN,
                batch.coord.y.toFloat(), 0f,
            )
            Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
            Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
            GLES31.glUniformMatrix4fv(uOutlineMvpLocation, 1, false, mvp, 0)
                        GLES31.glUniform1f(uInvOverscaleLocation, 1f / overscale.coerceAtLeast(1f))
            if (uOutlineMapTimeLocation >= 0) {
                GLES31.glUniform1f(uOutlineMapTimeLocation, VectorMapTime.NEVER_HIDE_UNIFORM)
            }
            GLES31.glDrawArrays(
                GLES31.GL_TRIANGLES,
                0,
                batch.interleaved.size / VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX,
            )
            drewAny = true
        }
        GLES31.glDisableVertexAttribArray(2)
        GLES31.glDisableVertexAttribArray(3)
        GLES31.glDisableVertexAttribArray(4)
        return drewAny
    }

    private fun drawOutlineHoldFromTriangulationCache(
        coords: List<TileCoord>,
        holdIntervalMs: Long,
        vts: VectorTileSource,
        layer: VectorTileLayer,
        strokeRgba: FloatArray,
        opacity: Float,
        projectionMatrix: FloatArray,
        cameraArray: FloatArray,
        useMapboxNativeMv: Boolean,
        mapZoomNow: Double,
    ): Boolean {
        if (coords.isEmpty()) return false
        ensureOutlineProgram()
        if (outlineGlProgram == 0 || uOutlineMvpLocation < 0 || uInvOverscaleLocation < 0) return false
        GLES31.glUseProgram(outlineGlProgram)
        setTileClip(uOutlineClipToTileLocation, true)
        GLES31.glEnableVertexAttribArray(2)
        GLES31.glEnableVertexAttribArray(3)
        GLES31.glEnableVertexAttribArray(4)
        val snappedMs = vts.snappedTimeSeriesIntervalMs(holdIntervalMs)
        val tileLocal = FloatArray(16)
        val modelViewMatrixArray = FloatArray(16)
        val mvp = FloatArray(16)
        var drewAny = false
        for (coord in coords) {
            val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: continue
            val data = resolveVectorTileData(cached.data, snappedMs, exactInterval = true) ?: continue
            val outlineKey = outlineTriangulationKey(coord, data, layer.sourceLayer, strokeRgba)
            val raw = outlineTriangulationCache[outlineKey] ?: continue
            if (raw.isEmpty()) continue
            val interleaved = applyOutlineOpacity(raw, opacity)
            uploadOutlineInterleaved(interleaved)
            Matrix.setIdentityM(tileLocal, 0)
            val overscale =
                if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, coord.z) else 1f
            Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
            // Rule: dateline-world-copy. See drawInterleavedForCoord's identical fix.
            val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
            Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
            Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
            Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
            GLES31.glUniformMatrix4fv(uOutlineMvpLocation, 1, false, mvp, 0)
                        GLES31.glUniform1f(uInvOverscaleLocation, 1f / overscale.coerceAtLeast(1f))
            if (uOutlineMapTimeLocation >= 0) {
                GLES31.glUniform1f(uOutlineMapTimeLocation, VectorMapTime.NEVER_HIDE_UNIFORM)
            }
            GLES31.glDrawArrays(
                GLES31.GL_TRIANGLES,
                0,
                interleaved.size / VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX,
            )
            drewAny = true
        }
        GLES31.glDisableVertexAttribArray(2)
        GLES31.glDisableVertexAttribArray(3)
        GLES31.glDisableVertexAttribArray(4)
        return drewAny
    }

    /**
     * Rule: tile-clip. A vector tile draws only inside its own square, as MapsGL JS and Mapbox do.
     * Some sources (storm cells) put every feature in every tile, with coordinates far outside
     * the extent; unclipped, each visible tile drew them again and 50% fills stacked to opaque.
     * GeoJSON draws are not tiled and keep it off.
     */
    private fun setTileClip(location: Int, on: Boolean) {
        if (location >= 0) GLES31.glUniform1f(location, if (on) 1f else 0f)
    }

    private fun ensureProgram() {
        if (glProgram != 0) return
        if (tryLinkProgramEs310()) return
        Log.w(VECTOR_FILL_TAG, "GLES 3.1 program failed; trying GLES 3.0 fallback")
        tryLinkProgramEs300()
    }

    private fun tryLinkProgramEs310(): Boolean {
        val vtx = """
            #version 300 es
            layout(location = 0) in vec2 a_pos;
            layout(location = 1) in vec4 a_color;
            layout(location = 2) in float a_feature_time;
            uniform mat4 u_mvp;
            out vec4 v_color;
            out float v_feature_time;
            out vec2 v_tile;
            void main() {
                v_color = a_color;
                v_feature_time = a_feature_time;
                v_tile = a_pos;
                gl_Position = u_mvp * vec4(a_pos, 0.0, 1.0);
            }
        """.trimIndent()
        val frag = """
            #version 300 es
            precision mediump float;
            in vec4 v_color;
            in float v_feature_time;
            uniform float u_mapTime;
            uniform float u_clip_to_tile;
            in vec2 v_tile;
            out vec4 o_frag;
            void main() {
                if (v_feature_time > u_mapTime) discard;
                if (u_clip_to_tile > 0.5 && (any(lessThan(v_tile, vec2(0.0))) || any(greaterThan(v_tile, vec2(1.0))))) discard;
                o_frag = v_color;
            }
        """.trimIndent()
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vtx, "vertex310")
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, frag, "frag310")
        if (vs == 0 || fs == 0) return false
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, vs)
        GLES31.glAttachShader(p, fs)
        GLES31.glLinkProgram(p)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val link = IntArray(1)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) {
            logProgramLinkFailure("310", p)
            GLES31.glDeleteProgram(p)
            return false
        }
        glProgram = p
        uMvpLocation = GLES31.glGetUniformLocation(glProgram, "u_mvp")
        uMapTimeLocation = GLES31.glGetUniformLocation(glProgram, "u_mapTime")
        uClipToTileLocation = GLES31.glGetUniformLocation(glProgram, "u_clip_to_tile")
        if (uMvpLocation < 0) {
            Log.e(VECTOR_FILL_TAG, "u_mvp missing after GLES 3.1 link")
            GLES31.glDeleteProgram(glProgram)
            glProgram = 0
            uMapTimeLocation = -1
            return false
        }
        return true
    }

    private fun tryLinkProgramEs300() {
        val vtx = """
            #version 300 es
            uniform mat4 u_mvp;
            in vec2 a_pos;
            in vec4 a_color;
            in float a_feature_time;
            out vec4 v_color;
            out float v_feature_time;
            out vec2 v_tile;
            void main() {
                v_color = a_color;
                v_feature_time = a_feature_time;
                v_tile = a_pos;
                gl_Position = u_mvp * vec4(a_pos, 0.0, 1.0);
            }
        """.trimIndent()
        val frag = """
            #version 300 es
            precision mediump float;
            in vec4 v_color;
            in float v_feature_time;
            uniform float u_mapTime;
            uniform float u_clip_to_tile;
            in vec2 v_tile;
            out vec4 fragColor;
            void main() {
                if (v_feature_time > u_mapTime) discard;
                if (u_clip_to_tile > 0.5 && (any(lessThan(v_tile, vec2(0.0))) || any(greaterThan(v_tile, vec2(1.0))))) discard;
                fragColor = v_color;
            }
        """.trimIndent()
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vtx, "vertex300")
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, frag, "frag300")
        if (vs == 0 || fs == 0) return
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, vs)
        GLES31.glAttachShader(p, fs)
        GLES31.glBindAttribLocation(p, 0, "a_pos")
        GLES31.glBindAttribLocation(p, 1, "a_color")
        GLES31.glBindAttribLocation(p, 2, "a_feature_time")
        GLES31.glLinkProgram(p)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val link = IntArray(1)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) {
            logProgramLinkFailure("300", p)
            GLES31.glDeleteProgram(p)
            glProgram = 0
            uMvpLocation = -1
            uMapTimeLocation = -1
            return
        }
        glProgram = p
        uMvpLocation = GLES31.glGetUniformLocation(glProgram, "u_mvp")
        uMapTimeLocation = GLES31.glGetUniformLocation(glProgram, "u_mapTime")
        uClipToTileLocation = GLES31.glGetUniformLocation(glProgram, "u_clip_to_tile")
        if (uMvpLocation < 0) {
            Log.e(VECTOR_FILL_TAG, "u_mvp missing after GLES 3.0 link")
            GLES31.glDeleteProgram(glProgram)
            glProgram = 0
            uMapTimeLocation = -1
        }
    }

    private fun ensureOutlineProgram() {
        if (outlineGlProgram != 0) return
        if (tryLinkOutlineProgramEs310()) return
        Log.w(VECTOR_FILL_TAG, "GLES 3.1 outline program failed; trying GLES 3.0 fallback")
        tryLinkOutlineProgramEs300()
    }

    private fun tryLinkOutlineProgramEs310(): Boolean {
        val vtx = """
            #version 300 es
            layout(location = 0) in vec2 a_pos;
            layout(location = 1) in vec2 a_normal;
            layout(location = 2) in vec4 a_color;
            layout(location = 3) in float a_edge_dist;
            layout(location = 4) in float a_half_width_uv;
            layout(location = 5) in float a_feature_time;
            uniform mat4 u_mvp;
            uniform float u_inv_overscale;
            out vec4 v_color;
            out float v_edge_dist;
            out float v_feature_time;
            out vec2 v_tile;
            void main() {
                v_color = a_color;
                v_edge_dist = a_edge_dist;
                v_feature_time = a_feature_time;
                vec2 pos = a_pos + a_normal * (a_half_width_uv * u_inv_overscale * 1.2);
                v_tile = pos;
                gl_Position = u_mvp * vec4(pos, 0.0, 1.0);
            }
        """.trimIndent()
        val frag = """
            #version 300 es
            precision mediump float;
            in vec4 v_color;
            in float v_edge_dist;
            in float v_feature_time;
            uniform float u_mapTime;
            uniform float u_clip_to_tile;
            in vec2 v_tile;
            out vec4 o_frag;
            void main() {
                if (v_feature_time > u_mapTime) discard;
                if (u_clip_to_tile > 0.5 && (any(lessThan(v_tile, vec2(0.0))) || any(greaterThan(v_tile, vec2(1.0))))) discard;
                float d = abs(v_edge_dist);
                float fw = fwidth(d);
                float aa = 1.0 - smoothstep(0.833 - fw, 0.833 + fw, d);
                o_frag = vec4(v_color.rgb, v_color.a * aa);
            }
        """.trimIndent()
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vtx, "outline-vertex310")
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, frag, "outline-frag310")
        if (vs == 0 || fs == 0) return false
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, vs)
        GLES31.glAttachShader(p, fs)
        GLES31.glLinkProgram(p)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val link = IntArray(1)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) {
            logProgramLinkFailure("outline-310", p)
            GLES31.glDeleteProgram(p)
            return false
        }
        outlineGlProgram = p
        uOutlineMvpLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_mvp")
        uInvOverscaleLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_inv_overscale")
        uOutlineMapTimeLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_mapTime")
        uOutlineClipToTileLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_clip_to_tile")
        if (uOutlineMvpLocation < 0 || uInvOverscaleLocation < 0) {
            Log.e(VECTOR_FILL_TAG, "outline uniforms missing after GLES 3.1 link")
            GLES31.glDeleteProgram(outlineGlProgram)
            outlineGlProgram = 0
            uOutlineMapTimeLocation = -1
            return false
        }
        return true
    }

    private fun tryLinkOutlineProgramEs300() {
        val vtx = """
            #version 300 es
            uniform mat4 u_mvp;
            uniform float u_inv_overscale;
            in vec2 a_pos;
            in vec2 a_normal;
            in vec4 a_color;
            in float a_edge_dist;
            in float a_half_width_uv;
            in float a_feature_time;
            out vec4 v_color;
            out float v_edge_dist;
            out float v_feature_time;
            out vec2 v_tile;
            void main() {
                v_color = a_color;
                v_edge_dist = a_edge_dist;
                v_feature_time = a_feature_time;
                vec2 pos = a_pos + a_normal * (a_half_width_uv * u_inv_overscale * 1.2);
                v_tile = pos;
                gl_Position = u_mvp * vec4(pos, 0.0, 1.0);
            }
        """.trimIndent()
        val frag = """
            #version 300 es
            precision mediump float;
            in vec4 v_color;
            in float v_edge_dist;
            in float v_feature_time;
            uniform float u_mapTime;
            uniform float u_clip_to_tile;
            in vec2 v_tile;
            out vec4 fragColor;
            void main() {
                if (v_feature_time > u_mapTime) discard;
                if (u_clip_to_tile > 0.5 && (any(lessThan(v_tile, vec2(0.0))) || any(greaterThan(v_tile, vec2(1.0))))) discard;
                float d = abs(v_edge_dist);
                float fw = fwidth(d);
                float aa = 1.0 - smoothstep(0.833 - fw, 0.833 + fw, d);
                fragColor = vec4(v_color.rgb, v_color.a * aa);
            }
        """.trimIndent()
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vtx, "outline-vertex300")
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, frag, "outline-frag300")
        if (vs == 0 || fs == 0) return
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, vs)
        GLES31.glAttachShader(p, fs)
        GLES31.glBindAttribLocation(p, 0, "a_pos")
        GLES31.glBindAttribLocation(p, 1, "a_normal")
        GLES31.glBindAttribLocation(p, 2, "a_color")
        GLES31.glBindAttribLocation(p, 3, "a_edge_dist")
        GLES31.glBindAttribLocation(p, 4, "a_half_width_uv")
        GLES31.glBindAttribLocation(p, 5, "a_feature_time")
        GLES31.glLinkProgram(p)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val link = IntArray(1)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) {
            logProgramLinkFailure("outline-300", p)
            GLES31.glDeleteProgram(p)
            outlineGlProgram = 0
            uOutlineMvpLocation = -1
            uInvOverscaleLocation = -1
            return
        }
        outlineGlProgram = p
        uOutlineMvpLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_mvp")
        uInvOverscaleLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_inv_overscale")
        uOutlineMapTimeLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_mapTime")
        uOutlineClipToTileLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_clip_to_tile")
        if (uOutlineMvpLocation < 0 || uInvOverscaleLocation < 0) {
            Log.e(VECTOR_FILL_TAG, "outline uniforms missing after GLES 3.0 link")
            GLES31.glDeleteProgram(outlineGlProgram)
            outlineGlProgram = 0
            uOutlineMvpLocation = -1
            uOutlineMapTimeLocation = -1
            uInvOverscaleLocation = -1
        }
    }

    private fun logProgramLinkFailure(label: String, program: Int) {
        val log = GLES31.glGetProgramInfoLog(program)
        if (log.isNotBlank()) {
            Log.e(VECTOR_FILL_TAG, "Program link failed ($label): $log")
        }
    }

    /** Sliding window for rolling prefetch after the per-layer gate opens (rule 1). */
    private fun playbackPrefetchPhaseEpochMs(vts: VectorTileSource): List<Long> =
        timelinePlaybackPrefetchEpochMillis(lookBehind = 2, lookAhead = 10)
            .map { vts.snappedTimeSeriesIntervalMs(it) }
            .distinct()

    /** Fixed prefetch window at play-press; used while the gate holds so a moving playhead does not shift the target. */
    private fun playbackGatePrefetchPhaseEpochMs(vts: VectorTileSource): List<Long> {
        val count = Timeline.timeStrings.size
        if (count == 0) return emptyList()
        val phaseA = playbackGateAnchorPhaseA.coerceIn(0, count - 1)
        val phaseB = playbackGateAnchorPhaseB.coerceIn(0, count - 1)
        val start = (minOf(phaseA, phaseB) - 2).coerceAtLeast(0)
        val end = (maxOf(phaseA, phaseB) + 10).coerceAtMost(count - 1)
        return (start..end).mapNotNull { timelinePhaseEpochMillis(it) }
            .map { vts.snappedTimeSeriesIntervalMs(it) }
            .distinct()
    }

    /** Union of play-press anchor window and live playhead window while the gate holds. */
    private fun playbackGateHoldPrefetchPhaseEpochMs(vts: VectorTileSource): List<Long> =
        (playbackGatePrefetchPhaseEpochMs(vts) + playbackPrefetchPhaseEpochMs(vts)).distinct()

    /** Active timeline phase drawable before the per-layer gate opens (rule 1). */
    private fun playbackGatePhaseEpochMs(vts: VectorTileSource): List<Long> {
        val phaseMs = timelinePhaseEpochMillis(Timeline.currentPhaseA) ?: return emptyList()
        return listOf(vts.snappedTimeSeriesIntervalMs(phaseMs))
    }

    private fun resolveFillMesh(vts: VectorTileSource, triKey: String): FloatArray? {
        triangulationCache[triKey]?.let { return it }
        vts.getFillTriangulationNative(triKey)?.let { native ->
            triangulationCache[triKey] = native
            // Rule: playback-mesh-cache-bound. This runs once per visible tile per draw() frame during
            // steady-state playback — the only insert path that previously had no trim call at all,
            // letting the cache grow unbounded across an entire playback session as evicted entries
            // got silently re-populated from native every frame without ever being re-capped.
            trimTriangulationCachesIfNeeded(vts)
            return native
        }
        return null
    }

    private fun resolveOutlineMesh(vts: VectorTileSource, triKey: String): FloatArray? {
        outlineTriangulationCache[triKey]?.let { return it }
        vts.getOutlineTriangulationNative(triKey)?.let { native ->
            outlineTriangulationCache[triKey] = native
            trimTriangulationCachesIfNeeded(vts)
            return native
        }
        return null
    }

    private fun triangulateOutlineMeshForPlayback(
        vts: VectorTileSource,
        triKey: String,
        data: VectorData,
        coord: TileCoord,
        sourceLayer: String?,
        strokeRgba: FloatArray,
        strokeThicknessPx: Float,
        layerId: String? = null,
        drawFilter: Expression? = null,
    ): FloatArray {
        resolveOutlineMesh(vts, triKey)?.let {
            data.markLayerMeshReady(vts, layerId)
            return it
        }
        return data.withGpuUpload {
            val computed = triangulateFillOutlines(
                data,
                coord,
                sourceLayer,
                strokeRgba,
                strokeThicknessPx,
                vts,
                triKey,
                layerId,
                drawFilter,
            )
            // Empty is cached too — a filter that keeps nothing in this tile has a finished
            // answer, and omitting it leaves the tile looking unbuilt.
            outlineTriangulationCache[triKey] = computed
            // Rule: playback-mesh-cache-bound. This builds every phase's ref during initial warmup
            // (potentially 100+ inserts in a tight loop) — was previously uncapped and untrimmed here,
            // letting the cache balloon far past its budget before any other code path happened to trim it.
            trimTriangulationCachesIfNeeded(vts)
            computed
        }.also { data.markLayerMeshReady(vts, layerId) }
    }

    private fun allTimelinePhaseEpochMs(vts: VectorTileSource): List<Long> =
        Timeline.timeStrings.indices
            .mapNotNull { timelinePhaseEpochMillis(it) }
            .mapNotNull { vts.resolvedIntervalOrNull(it) }
            .distinct()

    private fun playbackGateReadyPhaseEpochMs(vts: VectorTileSource): List<Long> {
        val count = Timeline.timeStrings.size
        if (count == 0) return emptyList()
        val phaseA = if (playbackGateAnchorPhaseA >= 0) playbackGateAnchorPhaseA else Timeline.currentPhaseA
        val phaseB = if (playbackGateAnchorPhaseB >= 0) playbackGateAnchorPhaseB else Timeline.currentPhaseB
        return playbackGateReadyPhaseEpochMillis(
            phaseA = phaseA,
            phaseB = phaseB,
            phaseCount = count,
            epochMillisAt = { timelinePhaseEpochMillis(it) },
            resolvedIntervalOrNull = { vts.resolvedIntervalOrNull(it) },
        )
    }

    private fun isPlaybackGateReady(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        strokeRgba: FloatArray?,
        generation: Long,
    ): Boolean {
        val gatePhases = playbackGateReadyPhaseEpochMs(vts)
        if (gatePhases.isEmpty() || coords.isEmpty()) return true
        return gatePhases.all { snappedMs ->
            playbackFillRefsByIntervalMs.containsKey(snappedMs) &&
                playbackFillRefsGeneration[snappedMs] == generation &&
                (strokeRgba == null ||
                    (playbackOutlineRefsByIntervalMs.containsKey(snappedMs) &&
                        playbackOutlineRefsGeneration[snappedMs] == generation))
        }
    }

    private fun timelinePhaseIndexForSnappedMs(vts: VectorTileSource, snappedMs: Long): Int =
        Timeline.timeStrings.indices.firstOrNull { idx ->
            timelinePhaseEpochMillis(idx)?.let { vts.snappedTimeSeriesIntervalMs(it) } == snappedMs
        } ?: -1

    private fun isPlaybackTimelineFullyPrimed(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        @Suppress("UNUSED_PARAMETER") styleKey: Int,
        @Suppress("UNUSED_PARAMETER") sourceLayer: String?,
        strokeRgba: FloatArray?,
        generation: Long,
    ): Boolean {
        val allPhases = allTimelinePhaseEpochMs(vts)
        if (allPhases.isEmpty() || coords.isEmpty()) return true
        // Rule: parsed-heap-bound. Used to also re-verify coords.all { isPlaybackPhaseDrawable(...) }
        // here — but that check independently re-derives drawability from the JVM-heap-trimmable
        // parsed Feature data, which trimParsedHeapForTimeline() can evict again well after a phase
        // was already successfully committed to the ref map below. Once committed, this phase's
        // meshes are pinned in the native cache (see trimTriangulationCachesIfNeeded's pin sync) and
        // recoverable via resolveFillMesh's native fallback regardless of parsed-data state — so
        // ref-map membership alone is the correct, stable proof of "ready," and re-deriving it via a
        // fragile re-check only produced false negatives (confirmed live: readyFill/readyOutlined
        // reached 25/25 while this re-check kept this gate open forever).
        //
        // Rule: pan-during-playback. Also requires the entry's generation tag to match [generation] —
        // otherwise a coords-restart (new viewport) would leave this "fully primed" even though every
        // entry still only covers the OLD viewport's tiles, since containsKey alone can't tell stale
        // apart from fresh once a restart bumps the generation.
        return allPhases.all { snappedMs ->
            playbackFillRefsByIntervalMs.containsKey(snappedMs) &&
                playbackFillRefsGeneration[snappedMs] == generation &&
                (strokeRgba == null ||
                    (playbackOutlineRefsByIntervalMs.containsKey(snappedMs) &&
                        playbackOutlineRefsGeneration[snappedMs] == generation))
        }
    }

    private fun phasesForPlaybackFramePrep(
        vts: VectorTileSource,
        gateHoldActive: Boolean,
        fullTimelinePrimeActive: Boolean,
        generation: Long,
    ): List<Long> {
        // Rule: pan-during-playback. "Missing" also includes entries whose generation tag is stale
        // (built for a since-superseded coords set) — without this, a coords-restart's tail-catchup
        // mechanism never revisits phases outside the rolling window (their containsKey is already
        // true from the OLD generation, since a restart never clears these maps), so
        // isPlaybackTimelineFullyPrimed — which requires ALL phases at the current generation —
        // can never resolve after a pan, leaving the loading spinner stuck forever. Confirmed live:
        // spinner never cleared after panning to a new area, only the rolling-window phases ever
        // refreshed. Checks both fill and outline maps regardless of whether this layer draws an
        // outline — harmless for fill-only layers (just a few wasted re-checks in the bounded tail
        // slots), and keeps this function's signature simple.
        fun isMissing(snappedMs: Long): Boolean =
            playbackFillRefsByIntervalMs[snappedMs] == null ||
                playbackFillRefsGeneration[snappedMs] != generation ||
                playbackOutlineRefsByIntervalMs[snappedMs] == null ||
                playbackOutlineRefsGeneration[snappedMs] != generation
        when {
            gateHoldActive -> return playbackGateReadyPhaseEpochMs(vts).filter(::isMissing)
            fullTimelinePrimeActive -> {
                val rolling = playbackPrefetchPhaseEpochMs(vts)
                val missingTailFirst = allTimelinePhaseEpochMs(vts)
                    .filter(::isMissing)
                    .sortedByDescending { timelinePhaseIndexForSnappedMs(vts, it) }
                    .take(fullTimelineTailPhasesPerPrepTick)
                return (rolling + missingTailFirst).distinct()
            }
            else -> {
                val currentPhaseMs = timelinePhaseEpochMillis(Timeline.currentPhaseA)
                val rollingPhases = playbackPrefetchPhaseEpochMs(vts)
                return buildList {
                    currentPhaseMs?.let { add(it) }
                    for (phaseMs in rollingPhases) {
                        if (phaseMs != currentPhaseMs) add(phaseMs)
                    }
                }
            }
        }
    }

    private fun scheduleFullTimelineMvtPrefetch(
        layer: VectorTileLayer,
        vts: VectorTileSource,
        coords: List<TileCoord>,
    ) {
        if (!Timeline.isGloballyPlaying || coords.isEmpty()) return
        if (!playbackWarmupComplete) return
        if (playbackTimelineFullyPrimed && playbackWarmupComplete) return
        if (fullTimelineMvtPrefetchJob?.isActive == true) return
        val prepCoords = coords.toList()
        fullTimelineMvtPrefetchJob = layer.externalScope.launch(Dispatchers.Default) {
            val phasesTailFirst = allTimelinePhaseEpochMs(vts)
                .sortedByDescending { timelinePhaseIndexForSnappedMs(vts, it) }
            while (isActive && Timeline.isGloballyPlaying && !playbackTimelineFullyPrimed) {
                var requested = 0
                for (intervalMs in phasesTailFirst) {
                    for (coord in prepCoords) {
                        if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, intervalMs)) {
                            vts.requestTile(
                                coord.x,
                                coord.y,
                                coord.z,
                                intervalTime = java.util.Date(intervalMs),
                            )
                            requested++
                            if (requested >= fullTimelineMvtRequestsPerWave) break
                        }
                    }
                    if (requested >= fullTimelineMvtRequestsPerWave) break
                }
                if (requested == 0) break
                // Rule: parsed-heap-bound. Trim right after every wave, not just on the separate
                // frame-prep loop's own timer — each requestTile call above just eagerly parsed and
                // stored a full Feature list, so letting several waves run before the next trim
                // would let the resident parsed-feature set balloon well past the rolling window.
                vts.trimParsedHeapForTimeline()
                // Rule: parsed-heap-bound. Was 80ms — confirmed via heap dump this is a GC-outpacing
                // allocation-rate problem, not retention, so the fix is giving the concurrent GC real
                // wall-clock time between bursts rather than firing the next wave as soon as possible.
                delay(250)
            }
        }
    }

    private fun fillTriangulationKey(
        coord: TileCoord,
        data: com.xweather.mapsgl.sources.VectorData,
        sourceLayer: String?,
        styleKey: Int,
    ): String {
        val (meshFp, modeTag) = data.meshModeFingerprint(sourceLayer)
        return "${coord.z}/${coord.x}/${coord.y}|$sourceLayer|$styleKey|$TRIANGULATION_COLOR_CACHE_VERSION|" +
            "$modeTag|$meshFp|f$drawFilterKey"
    }

    /**
     * Identity of the layer's current draw filter, mixed into every mesh cache key.
     *
     * Fill meshes live in [VectorTileSource]'s native cache, which is keyed by **source** id — so
     * without this two fill layers over one source (or one layer whose filter changed) resolve to
     * the same entry and the first one's geometry is handed to the second. Hashing
     * [Expression.raw] rather than the [Expression] keeps the key stable across draws: `raw` is the
     * underlying list/map, so structurally equal filters agree and an unchanged filter never
     * thrashes the cache. Unfiltered layers hash to `0`.
     */
    private val drawFilterKey: Int
        get() = (tileLayer as? VectorTileLayer)?.filter?.raw?.hashCode() ?: 0


    /**
     * The opacity the fill is actually drawn at: the layer-level [FillLayerPaint.opacity] composed
     * with [FillPaint.opacity].
     *
     * Both exist and both mean something. Until XMAPSGLSDK-323 this path read only the layer-level
     * one, so `fill.opacity` -- the field MapsGL JS has, and the one anyone porting a layer spec
     * sets -- was silently dropped, and `climate.fire_obs.perimeter` and `tropical.cone.fill` drew
     * fully opaque instead of at the 0.6 and 0.5 they declare. [VectorCircleLayerRenderer] already
     * composed the two; this brings Fill in line with it.
     *
     * An expression-valued opacity is per-feature and cannot be folded into one layer-wide scalar,
     * so it falls back to 1.0 here and is left to the colour path, matching how stroke opacity is
     * already read.
     */
    private fun effectiveFillOpacity(paint: FillLayerPaint): Float {
        val fillOpacity = (paint.fill.opacity.constantValue ?: 1.0).toFloat()
        return (paint.opacity * fillOpacity).coerceIn(0f, 1f)
    }

    private fun applyOpacityToInterleaved(raw: FloatArray, opacity: Float): FloatArray {
        if (opacity >= 1f) return raw
        val v = raw.copyOf(raw.size)
        var i = 5
        while (i < v.size) {
            v[i] *= opacity
            i += VectorPolygonFillTriangulator.FILL_FLOATS_PER_VERTEX
        }
        return v
    }

    private fun triangulateFillMeshForPlayback(
        vts: VectorTileSource,
        triKey: String,
        data: VectorData,
        coord: TileCoord,
        sourceLayer: String?,
        fillFallbackRgba: FloatArray?,
        fillColorExpression: Expression?,
        allowLineRibbonFallback: Boolean,
        expressionColorExclusive: Boolean,
        layerId: String? = null,
        markLayerReady: Boolean = true,
        drawFilter: Expression? = null,
    ): FloatArray {
        triangulationCache[triKey]?.let {
            if (markLayerReady) data.markLayerMeshReady(vts, layerId)
            return it
        }
        vts.getFillTriangulationNative(triKey)?.let { native ->
            triangulationCache[triKey] = native
            if (markLayerReady) data.markLayerMeshReady(vts, layerId)
            return native
        }
        return data.withGpuUpload {
            val computed = triangulateFillFeatures(
                data,
                coord,
                sourceLayer,
                fillFallbackRgba,
                fillColorExpression,
                allowLineRibbonFallback,
                expressionColorExclusive,
                vts,
                triKey,
                layerId,
                drawFilter,
            )
            triangulationCache[triKey] = computed
            // Rule: playback-mesh-cache-bound. Same fix as triangulateOutlineMeshForPlayback — this
            // warmup path inserted every phase's fill mesh with no trim call at all.
            trimTriangulationCachesIfNeeded(vts)
            computed
        }.also { if (markLayerReady) data.markLayerMeshReady(vts, layerId) }
    }

    private fun playbackPrepCoords(layer: VectorTileLayer, fallback: List<TileCoord>): List<TileCoord> {
        layer.refreshVisibleTileCoordsForVectorGl()
        val visible = layer.visibleTileCoordsForGlVectorPlayback()
        return when {
            visible.isNotEmpty() -> visible
            playbackStableCoords.isNotEmpty() -> playbackStableCoords
            fallback.isNotEmpty() -> fallback
            else -> emptyList()
        }
    }

    private suspend fun buildPlaybackFillRefsForInterval(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        coords: List<TileCoord>,
        intervalMs: Long,
        styleKey: Int,
        fillFallbackRgba: FloatArray?,
        fillColorExpression: com.xweather.mapsgl.style.Expression?,
        allowLineRibbonFallback: Boolean,
        expressionColorExclusive: Boolean,
        opacity: Float,
        markLayerReady: Boolean = true,
    ): List<VectorPlaybackMeshRef> {
        if (coords.isEmpty()) return emptyList()
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        val refs = ArrayList<VectorPlaybackMeshRef>(coords.size)
        val addedInFlight = ArrayList<String>(coords.size)
        try {
            for (coord in coords) {
                if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) continue
                val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: continue
                // Re-parse from native MVT when Features were consumed after GPU upload, or trimmed.
                var data = vectorDataForSnappedPhase(vts, cached.data, snappedMs)
                    ?: vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs)
                    ?: continue
                if (vectorDataHasNoFeatures(data)) {
                    if (markLayerReady) data.markLayerMeshReady(vts, layer.id)
                    continue
                }
                val triKey = fillTriangulationKey(coord, data, layer.sourceLayer, styleKey)
                if (!data.hasCpuGeometry() && data.cpuGeometryReleased && resolveFillMesh(vts, triKey) == null) {
                    data = vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs) ?: continue
                    if (vectorDataHasNoFeatures(data)) {
                        if (markLayerReady) data.markLayerMeshReady(vts, layer.id)
                        continue
                    }
                }
                inFlightFillTriKeys.add(triKey)
                addedInFlight.add(triKey)
                val raw = triangulateFillMeshForPlayback(
                    vts = vts,
                    triKey = triKey,
                    data = data,
                    coord = coord,
                    sourceLayer = layer.sourceLayer,
                    fillFallbackRgba = fillFallbackRgba,
                    fillColorExpression = fillColorExpression,
                    allowLineRibbonFallback = allowLineRibbonFallback,
                    expressionColorExclusive = expressionColorExclusive,
                    layerId = layer.id,
                    markLayerReady = markLayerReady,
                    drawFilter = layer.filter,
                )
                if (raw.isEmpty()) continue
                refs.add(VectorPlaybackMeshRef(coord, triKey, opacity))
            }
            return refs
        } finally {
            inFlightFillTriKeys.removeAll(addedInFlight.toSet())
        }
    }

    private suspend fun buildPlaybackOutlineRefsForInterval(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        coords: List<TileCoord>,
        intervalMs: Long,
        strokeRgba: FloatArray,
        strokeThicknessPx: Float,
        opacity: Float,
    ): List<VectorPlaybackMeshRef> {
        if (coords.isEmpty()) return emptyList()
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        val refs = ArrayList<VectorPlaybackMeshRef>(coords.size)
        val addedInFlight = ArrayList<String>(coords.size)
        try {
            for (coord in coords) {
                if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) continue
                val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: continue
                var data = vectorDataForSnappedPhase(vts, cached.data, snappedMs)
                    ?: vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs)
                    ?: continue
                if (vectorDataHasNoFeatures(data)) {
                    data.markLayerMeshReady(vts, layer.id)
                    continue
                }
                val outlineKey = outlineTriangulationKey(coord, data, layer.sourceLayer, strokeRgba)
                if (!data.hasCpuGeometry() && data.cpuGeometryReleased && resolveOutlineMesh(vts, outlineKey) == null) {
                    data = vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs) ?: continue
                    if (vectorDataHasNoFeatures(data)) {
                        data.markLayerMeshReady(vts, layer.id)
                        continue
                    }
                }
                inFlightOutlineTriKeys.add(outlineKey)
                addedInFlight.add(outlineKey)
                val raw = triangulateOutlineMeshForPlayback(
                    vts = vts,
                    triKey = outlineKey,
                    data = data,
                    coord = coord,
                    sourceLayer = layer.sourceLayer,
                    strokeRgba = strokeRgba,
                    strokeThicknessPx = strokeThicknessPx,
                    layerId = layer.id,
                    drawFilter = layer.filter,
                )
                if (raw.isEmpty()) continue
                refs.add(VectorPlaybackMeshRef(coord, outlineKey, opacity))
            }
            return refs
        } finally {
            inFlightOutlineTriKeys.removeAll(addedInFlight.toSet())
        }
    }

    private fun schedulePlaybackFramePreparation(
        layer: VectorTileLayer,
        vts: VectorTileSource,
        coords: List<TileCoord>,
        styleKey: Int,
        fillFallbackRgba: FloatArray?,
        fillColorExpression: com.xweather.mapsgl.style.Expression?,
        allowLineRibbonFallback: Boolean,
        expressionColorExclusive: Boolean,
        opacity: Float,
        strokeRgba: FloatArray?,
        strokeThicknessPx: Float,
    ) {
        if (!Timeline.isGloballyPlaying || coords.isEmpty()) return
        // Rule: dateline-world-copy. Must include offset, not just z/x/y — at wide zoomed-out views
        // spanning the antimeridian, the same real tile can appear twice in [coords] (once per world
        // copy, distinguished only by TileCoord.offset). A z/x/y-only key collapses "1 copy visible"
        // and "2 copies visible of the same tile" to the identical key, so gaining/losing a world copy
        // was never detected as a coords change — the prep job (captured once at launch) kept building
        // refs for whichever single copy was visible when it first started, silently leaving the other
        // side of the date line permanently undrawn even as the timeline kept animating fine on the
        // one side it did know about. This key is purely internal (compared only against
        // playbackFramePrepCoordsKey/pendingPlaybackPrepCoordsKey below), so including offset here is
        // safe — nothing re-parses it expecting exactly 3 segments.
        val coordsKey = coords.mapTo(HashSet(coords.size)) { "${it.z}/${it.x}/${it.y}/${it.offset}" }
        if (playbackFramePrepJob?.isActive == true) {
            if (coordsKey == playbackFramePrepCoordsKey) {
                pendingPlaybackPrepCoordsKey = coordsKey
                return
            }
            val now = SystemClock.elapsedRealtime()
            if (coordsKey != pendingPlaybackPrepCoordsKey) {
                pendingPlaybackPrepCoordsKey = coordsKey
                pendingPlaybackPrepCoordsKeyStableSinceMs = now
                return
            }
            if (now - pendingPlaybackPrepCoordsKeyStableSinceMs < PLAYBACK_PREP_COORDS_SETTLE_MS) return
            // Rule: pan-during-playback. coords genuinely changed and settled (debounced above so a
            // continuous drag doesn't retrigger this every frame) — restart the prep job with the
            // fresh coords. Deliberately does NOT clear playbackFillRefsByIntervalMs/
            // playbackOutlineRefsByIntervalMs (an earlier, abandoned attempt at this fix did, and is
            // suspected to be why it "broke timeline animations profoundly" — steady-state drawing
            // reads *exclusively* from those maps, so wiping them blanks the ENTIRE timeline's
            // content, not just the new area, until the job rebuilds everything from scratch).
            // Instead, bump playbackPrepGeneration; the per-interval "already built?" checks below now
            // also compare generation, so each interval's entry is overwritten in place as the job's
            // normal iteration naturally reaches it — nothing currently drawn ever goes empty.
            // Deliberately does NOT touch playbackWarmupComplete/initialPlaybackWarmupSatisfied —
            // resetting those mid-playback is separately confirmed to freeze the displayed timeline
            // clock for 30+ seconds. The load-indicator flags below ARE safe to touch here: they're
            // structurally independent of those two booleans (see panReprimeInProgress's KDoc).
            playbackFramePrepJob?.cancel()
            playbackFramePrepJob = null
            playbackPrepGeneration++
            playbackTimelineFullyPrimed = false
            panReprimeInProgress = true
            Timeline.setGlVectorFillLayerPlaybackReady(layer.id, false)
            Timeline.beginGlVectorFillPrefetchLoadUi()
        }
        playbackFramePrepCoordsKey = coordsKey
        pendingPlaybackPrepCoordsKey = coordsKey
        val prepCoords = coords.toList()
        val prepGeneration = playbackPrepGeneration
        playbackFramePrepJob = layer.externalScope.launch(Dispatchers.Default) {
            while (isActive && Timeline.isGloballyPlaying) {
                val gateHoldActive = !playbackWarmupComplete && playbackGateAnchorPhaseA >= 0
                val fullTimelinePrimeActive = playbackWarmupComplete && !playbackTimelineFullyPrimed
                val phases = phasesForPlaybackFramePrep(vts, gateHoldActive, fullTimelinePrimeActive, prepGeneration)
                val panLoadUiPhases =
                    if (panReprimeInProgress) playbackGateReadyPhaseEpochMs(vts).toHashSet() else emptySet()
                var builtAny = false
                for (phaseMs in phases) {
                    if (!isActive) break
                    val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
                    if (playbackFillRefsByIntervalMs[snappedMs] == null ||
                        playbackFillRefsGeneration[snappedMs] != prepGeneration
                    ) {
                        for (coord in prepCoords) {
                            if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) {
                                vts.requestTile(
                                    coord.x,
                                    coord.y,
                                    coord.z,
                                    intervalTime = java.util.Date(snappedMs),
                                    countsForGlFillLoadIndicator = gateHoldActive ||
                                        snappedMs in panLoadUiPhases,
                                )
                            }
                        }
                        val fillRefs = buildPlaybackFillRefsForInterval(
                            vts = vts,
                            layer = layer,
                            coords = prepCoords,
                            intervalMs = phaseMs,
                            styleKey = styleKey,
                            fillFallbackRgba = fillFallbackRgba,
                            fillColorExpression = fillColorExpression,
                            allowLineRibbonFallback = allowLineRibbonFallback,
                            expressionColorExclusive = expressionColorExclusive,
                            opacity = opacity,
                            markLayerReady = strokeRgba == null,
                        )
                        if (prepCoords.all { coord ->
                                isPlaybackPhaseDrawable(vts, coord, snappedMs, styleKey, layer.sourceLayer)
                            }
                        ) {
                            synchronized(playbackRefsLock) {
                                playbackFillRefsByIntervalMs[snappedMs] = fillRefs
                                playbackFillRefsGeneration[snappedMs] = prepGeneration
                                trimPlaybackMeshRefCache(playbackFillRefsByIntervalMs, maxPlaybackIntervalBatchCacheSize())
                            }
                            builtAny = true
                        }
                    }
                    if (strokeRgba != null &&
                        (playbackOutlineRefsByIntervalMs[snappedMs] == null ||
                            playbackOutlineRefsGeneration[snappedMs] != prepGeneration)
                    ) {
                        val outlineRefs = buildPlaybackOutlineRefsForInterval(
                            vts = vts,
                            layer = layer,
                            coords = prepCoords,
                            intervalMs = phaseMs,
                            strokeRgba = strokeRgba,
                            strokeThicknessPx = strokeThicknessPx,
                            opacity = opacity,
                        )
                        if (prepCoords.all { coord ->
                                isPlaybackPhaseDrawable(
                                    vts,
                                    coord,
                                    snappedMs,
                                    styleKey,
                                    layer.sourceLayer,
                                )
                            }
                        ) {
                            synchronized(playbackRefsLock) {
                                playbackOutlineRefsByIntervalMs[snappedMs] = outlineRefs
                                playbackOutlineRefsGeneration[snappedMs] = prepGeneration
                                trimPlaybackMeshRefCache(playbackOutlineRefsByIntervalMs, maxPlaybackIntervalBatchCacheSize())
                            }
                            builtAny = true
                        }
                    }
                }
                if (builtAny) {
                    (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                }
                // Rule: parsed-heap-bound. This loop runs continuously for the whole steady-state
                // playback session, but the only other call site for trimParsedHeapForTimeline() is
                // gated behind a viewport-change check that never fires for a fixed viewport — so
                // without this, the parsed Feature-list heap (much heavier per interval than the
                // triangulated mesh) grows unbounded for the life of the playback session. Throttled
                // since it walks every cached tile in this source.
                val nowForTrim = SystemClock.elapsedRealtime()
                if (nowForTrim - lastParsedHeapTrimMs >= parsedHeapTrimIntervalMs) {
                    lastParsedHeapTrimMs = nowForTrim
                    vts.trimParsedHeapForTimeline()
                }
                if (panReprimeInProgress &&
                    isPlaybackGateReady(vts, prepCoords, strokeRgba, prepGeneration)
                ) {
                    panReprimeInProgress = false
                    Timeline.setGlVectorFillLayerPlaybackReady(layer.id, true)
                    if (!Timeline.isAnyGlVectorFillLayerAwaitingPlayback()) {
                        Timeline.endGlVectorFillPrefetchLoadUi()
                        (tileLayer?.mapController as? MapController)?.scheduleVectorFillPrefetchLoadComplete()
                    }
                }
                if (fullTimelinePrimeActive &&
                    isPlaybackTimelineFullyPrimed(
                        vts,
                        prepCoords,
                        styleKey,
                        layer.sourceLayer,
                        strokeRgba,
                        prepGeneration,
                    )
                ) {
                    playbackTimelineFullyPrimed = true
                    fullTimelineMvtPrefetchJob?.cancel()
                    fullTimelineMvtPrefetchJob = null
                    Timeline.markPlaybackFullTimelinePrimed(layer.id)
                }
                delay(
                    when {
                        !playbackWarmupComplete -> if (builtAny) 4L else 12L
                        fullTimelinePrimeActive -> if (builtAny) 2L else 8L
                        builtAny -> 8L
                        // Rule: prep-loop-idle-backoff. Once the whole timeline is fully primed and
                        // this iteration built nothing, there's no urgency to re-check every 16ms
                        // forever — a static viewport can sit in this state for the entire rest of
                        // the playback session. This loop previously spun at ~60Hz indefinitely even
                        // fully idle, reconstructing phasesForPlaybackFramePrep's phase list (fresh
                        // allocations) every single iteration for no benefit — a real, continuous
                        // small-object GC contributor on top of the render-path fixes. A genuine
                        // viewport change is caught independently by schedulePlaybackFramePreparation
                        // (called from draw(), cancels this job and starts a fresh one), so backing
                        // off here can't cause a pan/zoom to go unnoticed.
                        playbackTimelineFullyPrimed -> 500L
                        else -> 16L
                    },
                )
            }
        }
    }

    private fun vectorDataForSnappedPhase(
        vts: VectorTileSource,
        tilePayload: Any?,
        phaseMs: Long,
    ): VectorData? {
        val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
        return resolveVectorTileData(tilePayload, snappedMs, exactInterval = true)
    }

    private fun isViewportIntervalReady(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        intervalMs: Long,
        styleKey: Int,
        sourceLayer: String?,
    ): Boolean {
        if (coords.isEmpty()) return true
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        // Rule: viewport-spatial-hold-deadlock. Steady-state playback populates
        // playbackFillRefsByIntervalMs in the background (schedulePlaybackFramePreparation), not the
        // legacy on-demand triangulationCache checked below — checking only the legacy cache meant
        // this readiness check could never observe "ready" during steady-state playback, so a
        // zoom-floor change's spatial hold (armed in draw()'s zoomFloorChanged branch) never released,
        // permanently freezing the layer at whatever interval was live when the zoom happened even
        // though the timeline kept advancing. "Ready" mirrors phasesForPlaybackFramePrep's own
        // isMissing check (generation-tagged, not per-coord ref coverage) — a per-coord coverage check
        // was tried first and never released either, because a tile with zero alert features in it
        // legitimately produces no ref for that coord (nothing to draw), which is indistinguishable
        // from "not built yet" if you only look at which coords have refs. Sparse-coverage areas
        // (confirmed: Europe has little/no alert data much of the time) would then never satisfy
        // "every coord has a ref" and the hold would never release. Checking the interval's own
        // generation tag instead correctly treats "this interval was rebuilt against the current
        // viewport" as ready regardless of how many of its tiles had anything to draw.
        if (playbackFillRefsByIntervalMs[snappedMs] != null &&
            playbackFillRefsGeneration[snappedMs] == playbackPrepGeneration
        ) {
            return true
        }
        for (coord in coords) {
            if (!vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, snappedMs)) return false
            val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: return false
            val data = vectorDataForSnappedPhase(vts, cached.data, snappedMs) ?: return false
            val triKey = fillTriangulationKey(coord, data, sourceLayer, styleKey)
            if (!triangulationCache.containsKey(triKey) && !vts.hasFillTriangulationNative(triKey)) return false
        }
        return true
    }

    private fun isIntervalReadyForPlaybackDisplay(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        intervalMs: Long,
        styleKey: Int,
        sourceLayer: String?,
        strokeRgba: FloatArray?,
    ): Boolean {
        if (coords.isEmpty()) return true
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        if (!coords.all { coord ->
                isPlaybackPhaseDrawable(vts, coord, snappedMs, styleKey, sourceLayer)
            }
        ) {
            return false
        }
        if (!playbackFillRefsByIntervalMs.containsKey(snappedMs)) return false
        if (strokeRgba != null && !playbackOutlineRefsByIntervalMs.containsKey(snappedMs)) return false
        return true
    }

    /** Every interval in the rolling prefetch window must be prebuilt before the layer animates. */
    private fun isPlaybackPrefetchWindowDisplayReady(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        styleKey: Int,
        sourceLayer: String?,
        strokeRgba: FloatArray?,
    ): Boolean = isPlaybackPrefetchWindowDisplayReadyForPhases(
        vts,
        coords,
        playbackPrefetchPhaseEpochMs(vts),
        styleKey,
        sourceLayer,
        strokeRgba,
    )

    private fun isPlaybackPrefetchWindowDisplayReadyForPhases(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        phases: List<Long>,
        styleKey: Int,
        sourceLayer: String?,
        strokeRgba: FloatArray?,
    ): Boolean {
        if (phases.isEmpty()) return true
        if (coords.isEmpty()) return false
        return phases.all { phaseMs ->
            isIntervalReadyForPlaybackDisplay(
                vts,
                coords,
                phaseMs,
                styleKey,
                sourceLayer,
                strokeRgba,
            )
        }
    }

    // Rule: playback-phase-drawable-deadlock. Previously required triangulationCache.containsKey(triKey)
    // (or the native-flag/prefix-scan fallback) once a tile's vector data was loaded — the same legacy
    // on-demand cache that isPlaybackTimelineFullyPrimed's own KDoc already documents as unreliable
    // here: the ref-based playback pipeline (buildPlaybackFillRefsForInterval/
    // buildPlaybackOutlineRefsForInterval, called by this function's only two callers, both gating a
    // commit into playbackFillRefsByIntervalMs/playbackOutlineRefsByIntervalMs) does its own
    // triangulation and never writes into triangulationCache — so for any tile with real alert
    // features, this function could never observe "drawable," permanently blocking the commit (and
    // therefore isPlaybackTimelineFullyPrimed, which reads generation tags written only on commit) no
    // matter how long you waited. Confirmed live: thousands of consecutive NOT_DRAWABLE hits all
    // failed this exact check while the ref-based pipeline was successfully building and drawing
    // fine — the layer animated correctly the whole time, only the "fully primed" spinner never
    // cleared. Once the tile's vector data is loaded, trust the caller's own build function to
    // triangulate it rather than re-deriving readiness from a cache the pipeline doesn't populate.
    private fun isPlaybackPhaseDrawable(
        vts: VectorTileSource,
        coord: TileCoord,
        phaseMs: Long,
        styleKey: Int,
        sourceLayer: String?,
    ): Boolean {
        if (vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, phaseMs)) return false
        if (vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, phaseMs)) {
            val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
            val loadedData = cached?.let { vectorDataForSnappedPhase(vts, it.data, phaseMs) }
            if (loadedData != null) return true
        }
        return false
    }

    private fun ensureTimeSeriesWarmupTriangulation(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        coords: List<TileCoord>,
        styleKey: Int,
        prefetchPhases: List<Long>,
        requestMissingTiles: Boolean,
        fillFallbackRgba: FloatArray?,
        fillColorExpression: com.xweather.mapsgl.style.Expression?,
        allowLineRibbonFallback: Boolean,
        expressionColorExclusive: Boolean,
        strokeRgba: FloatArray?,
        strokeThicknessPx: Float,
    ) {
        if (requestMissingTiles && playbackGateAnchorPhaseA < 0 && warmupTilePrefetchJob?.isActive != true) {
            val prefetchCoords = coords.toList()
            val phasesForPrefetch = prefetchPhases
            warmupTilePrefetchJob = layer.externalScope.launch(Dispatchers.Default) {
                while (isActive) {
                    var requested = 0
                    // Rule: warmup-prefetch-starvation. MUST iterate phase-major (outer) /
                    // coord-minor (inner), not the reverse. With coord as the outer loop, a single
                    // tile needing all ~1000 timeline phases consumes the entire per-tick budget by
                    // itself — later tiles in `prefetchCoords` never get a single request queued
                    // until every earlier tile is 100% done, which at 24 requests/150ms can take
                    // minutes per tile. Confirmed live at zoom 5 (30 visible tiles): 12 tiles
                    // progressively gained data while the other 18 sat at zero bytes, unchanged, for
                    // 20+ seconds — exactly this starvation pattern, not a network/cap failure.
                    // Phase-major spreads each tick's budget across every visible tile for the
                    // nearest not-yet-loaded phases first, so all tiles gain some coverage together
                    // instead of being fully resolved one at a time in list order.
                    outer@ for (phaseMs in phasesForPrefetch) {
                        for (coord in prefetchCoords) {
                            if (vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, phaseMs)) continue
                            vts.requestTile(
                                coord.x,
                                coord.y,
                                coord.z,
                                intervalTime = java.util.Date(phaseMs),
                                countsForGlFillLoadIndicator = true,
                            )
                            requested++
                            if (requested >= 24) break@outer
                        }
                    }
                    if (requested == 0) break
                    delay(150)
                }
            }
        }
        // Rule: warmup-submit-pacing. Caps how many *new* background triangulation jobs this single
        // scan tick may start (the caller re-invokes this function every 250ms until fully primed, so
        // anything deferred here is simply picked up on the next tick — never dropped). Without this,
        // a cold warmup scan can discover and submit dozens of not-yet-cached tile x phase
        // combinations in one pass; since each job's real triangulation output (tens of KB to a few
        // MB) only gets allocated once it actually runs, back-to-back completions from even a small
        // 2-thread pool sustain a high enough allocation rate to force the main thread into a
        // GC-for-alloc stall (confirmed via atrace: `GC: Wait For Completion Alloc` on the main
        // thread during the loading burst — see project_ui_jank_interval_loading_profiling.md), which
        // blocks the Choreographer callback driving the seekbar's smooth position update, producing
        // exactly the reported "seekbar stutters while loading" symptom. Spreading new submissions
        // across more 250ms ticks trades a slightly longer time-to-fully-primed for a smoother main
        // thread throughout — same explicit tradeoff already made for playback (see
        // project_seekbar_smoothness_vs_gc_throttle_tradeoff.md).
        var fillSubmitBudget = WARMUP_SUBMIT_BUDGET_PER_TICK
        var outlineSubmitBudget = WARMUP_SUBMIT_BUDGET_PER_TICK
        // This scan runs on the Mapbox render thread, so its per-candidate cost is paid by the
        // thread that also has to produce frames. Two things keep it cheap:
        //
        // 1. The cache lookup is hoisted out of the phase loop. It is keyed only on the coord, but
        //    used to sit inside the inner loop and so repeated once per phase -- and
        //    findCachedVectorTileForNominalZxy falls back to a *linear* scan of both tile caches
        //    when the preferred key misses. At a six-day extend (tens of phases x ~18 coords) that
        //    turned one lookup per tile into tens of full cache walks per tick.
        // 2. Budget exhaustion breaks out of both loops rather than just the inner one, so once
        //    this tick can submit nothing more it stops scanning instead of walking the remaining
        //    coords. Anything skipped is picked up on the next tick (the caller re-invokes every
        //    250ms until fully primed), so this defers work and never drops it.
        scan@ for (coord in coords) {
            if (fillSubmitBudget <= 0 && (strokeRgba == null || outlineSubmitBudget <= 0)) break@scan
            val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: continue@scan
            for (phaseMs in prefetchPhases) {
                if (fillSubmitBudget <= 0 && (strokeRgba == null || outlineSubmitBudget <= 0)) break@scan
                if (!vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, phaseMs)) continue
                val data = vectorDataForSnappedPhase(vts, cached.data, phaseMs) ?: continue
                val triKey = fillTriangulationKey(coord, data, layer.sourceLayer, styleKey)
                if (fillSubmitBudget > 0 &&
                    data.hasCpuGeometry() &&
                    resolveFillMesh(vts, triKey) == null &&
                    triangulationInProgress.add(triKey)
                ) {
                    fillSubmitBudget--
                    val bgData = data
                    val bgCoord = coord
                    val bgSourceLayer = layer.sourceLayer
                    val bgFillFallback = fillFallbackRgba
                    val bgFillExpr = fillColorExpression
                    val bgDrawFilter = layer.filter
                    backgroundExecutor.submit {
                        try {
                            val computed = bgData.withGpuUpload {
                                triangulateFillFeatures(
                                    bgData,
                                    bgCoord,
                                    bgSourceLayer,
                                    bgFillFallback,
                                    bgFillExpr,
                                    allowLineRibbonFallback,
                                    expressionColorExclusive,
                                    vts,
                                    triKey,
                                    layer.id,
                                    bgDrawFilter,
                                )
                            }
                            triangulationCache[triKey] = computed
                            trimTriangulationCachesIfNeeded(vts)
                            if (strokeRgba == null) bgData.markLayerMeshReady(vts, layer.id)
                            (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                        } finally {
                            triangulationInProgress.remove(triKey)
                        }
                    }
                }
                if (strokeRgba != null) {
                    val outlineKey = outlineTriangulationKey(coord, data, layer.sourceLayer, strokeRgba)
                    if (outlineSubmitBudget > 0 &&
                        data.hasCpuGeometry() &&
                        resolveOutlineMesh(vts, outlineKey) == null &&
                        outlineTriangulationInProgress.add(outlineKey)
                    ) {
                        outlineSubmitBudget--
                        val bgData = data
                        val bgCoord = coord
                        val bgSourceLayer = layer.sourceLayer
                        val bgStrokeRgba = strokeRgba.copyOf()
                        val bgStrokeThicknessPx = strokeThicknessPx
                        val bgDrawFilter = layer.filter
                        backgroundExecutor.submit {
                            try {
                                val computed = bgData.withGpuUpload {
                                    triangulateFillOutlines(
                                        bgData,
                                        bgCoord,
                                        bgSourceLayer,
                                        bgStrokeRgba,
                                        bgStrokeThicknessPx,
                                        vts,
                                        outlineKey,
                                        layer.id,
                                        bgDrawFilter,
                                    )
                                }
                                // Rule: playback-mesh-cache-bound. See the drawOutlineCoords
                                // background block's identical fix — stale entry-count cap removed,
                                // byte-budget trim below is the sole size cap now.
                                outlineTriangulationCache[outlineKey] = computed
                                trimTriangulationCachesIfNeeded(vts)
                                bgData.markLayerMeshReady(vts, layer.id)
                                (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                            } finally {
                                outlineTriangulationInProgress.remove(outlineKey)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun compileShader(type: Int, src: String, label: String): Int {
        val s = GLES31.glCreateShader(type)
        GLES31.glShaderSource(s, src)
        GLES31.glCompileShader(s)
        val ok = IntArray(1)
        GLES31.glGetShaderiv(s, GLES31.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES31.glGetShaderInfoLog(s)
            if (log.isNotBlank()) {
                Log.e(VECTOR_FILL_TAG, "Shader compile failed ($label): $log")
            }
            GLES31.glDeleteShader(s)
            return 0
        }
        return s
    }

    internal fun invalidateTimelineMeshCache() {
        triangulationCache.clear()
        triangulationInProgress.clear()
        lastSuccessfulBatches = emptyList()
        lastSuccessfulDrawIntervalMs = null
        playbackStableCoords = emptyList()
        playbackStableCoordsUntilMs = 0L
        pausedBatchCount = 0
        pausedOutlineBatchCount = 0
        wasGloballyPlaying = false
        lastPlaybackViewportTileKeys = emptySet()
        lastGloballyInactiveMs = 0L
        initialPlaybackWarmupSatisfied = false
        viewportTilePrefetchPending = false
        lastViewportPrefetchSignalMs = 0L
        viewportSpatialHoldActive = false
        viewportHoldIntervalMs = null
        playbackWarmupComplete = true
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        playbackFramePrepJob?.cancel()
        playbackFramePrepJob = null
        lastPlaybackFramePrepPhaseA = -1
        playbackFrozenBatches = emptyList()
        playbackFrozenOutlineBatches = emptyList()
        playbackFrozenIntervalMs = null
        previouslyPinnedFillKeys = emptySet()
        previouslyPinnedOutlineKeys = emptySet()
        playbackGateOpenedAtMs = 0L
        playbackGateAnchorPhaseA = -1
        playbackGateAnchorPhaseB = -1
        playbackBatchCacheAnchorPhaseA = -1
        playbackTimelineFullyPrimed = false
        fullTimelineMvtPrefetchJob?.cancel()
        fullTimelineMvtPrefetchJob = null
        synchronized(playbackRefsLock) {
            playbackFillRefsByIntervalMs.clear()
            playbackOutlineRefsByIntervalMs.clear()
        }
        outlineTriangulationCache.clear()
        outlineTriangulationInProgress.clear()
        lastSuccessfulOutlineBatches = emptyList()
        lastSuccessfulOutlineDrawIntervalMs = null
    }

    fun releaseGl() {
        invalidateTimelineMeshCache()
        backgroundExecutor.shutdownNow()
        backgroundExecutor = Executors.newFixedThreadPool(FILL_TRIANGULATION_BUILD_THREADS)
        if (vbo != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(vbo), 0)
            vbo = 0
        }
        if (glProgram != 0) {
            GLES31.glDeleteProgram(glProgram)
            glProgram = 0
        }
        if (outlineGlProgram != 0) {
            GLES31.glDeleteProgram(outlineGlProgram)
            outlineGlProgram = 0
            uOutlineMvpLocation = -1
            uInvOverscaleLocation = -1
        }
    }

    override suspend fun update() {}
}
