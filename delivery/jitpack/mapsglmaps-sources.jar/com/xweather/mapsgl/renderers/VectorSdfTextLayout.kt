package com.xweather.mapsgl.renderers

/**
 * Lays a run of per-character SDF glyphs out into quads, for the glyph-atlas text path
 * ([VectorTextSdfAtlas]).
 *
 * Pure geometry over glyph metrics — no atlas, no Bitmap, no GL — so the positioning math is
 * unit-testable. Worth isolating: whole-label rasterization needed no layout at all (one bitmap, one
 * quad), so every advance, bearing and baseline term here is new code on the path that draws every
 * label, and the characteristic failures are subtle rather than absent. Letters spaced slightly too
 * far apart, or a label sitting a few pixels off its anchor, are easy to miss on a device and
 * trivial to pin here.
 */
internal object VectorSdfTextLayout {

    /**
     * One glyph's quad, in screen pixels relative to the feature's anchor point, y-down — the space
     * [VectorSymbolLayerRenderer]'s `a_center_off` instance attribute expects.
     */
    data class GlyphQuad(
        /** Index into the metrics list this quad came from, so callers can pair it with its UV. */
        val glyphIndex: Int,
        val halfWidthPx: Float,
        val halfHeightPx: Float,
        val centerOffsetXPx: Float,
        val centerOffsetYPx: Float,
    )

    data class Line(
        val quads: List<GlyphQuad>,
        /** Advance width of the whole run, scaled. Drives the collision box. */
        val widthPx: Float,
        /** Ascent-to-descent height of the run, scaled. Drives the collision box. */
        val heightPx: Float,
    )

    /**
     * @param metrics per-character metrics as returned by [VectorTextSdfAtlas.ensureGlyph], in
     * raster pixels at [VectorTextSdfAtlas.GLYPH_RASTER_PX]. Blank glyphs (whitespace) contribute
     * their advance and no quad.
     * @param scale `targetFontSizePx / GLYPH_RASTER_PX`.
     * @param ascentPx font ascent at raster size (negative, up).
     * @param descentPx font descent at raster size (positive, down).
     * @param anchorFracX horizontal anchor fraction, as [VectorSymbolLayout.anchorFraction].
     * @param anchorFracY vertical anchor fraction.
     * @param offsetXPx extra screen-pixel offset applied to the whole run.
     * @param offsetYPx extra screen-pixel offset applied to the whole run.
     * @param letterSpacingPx extra advance added per character, in raster pixels. The paint
     * expresses this as a fraction of the em (`text-letter-spacing`), so the caller multiplies by
     * the raster size. Matches the JS SDK's `TextLayout`, which does
     * `advance += letterSpacing * fontSize` before adding the glyph's own advance.
     */
    fun layOutLine(
        metrics: List<VectorTextSdfAtlas.GlyphMetrics>,
        scale: Float,
        ascentPx: Float,
        descentPx: Float,
        anchorFracX: Float,
        anchorFracY: Float,
        offsetXPx: Float,
        offsetYPx: Float,
        letterSpacingPx: Float = 0f,
    ): Line {
        var advance = 0f
        for (m in metrics) advance += m.advancePx + letterSpacingPx
        val widthPx = advance * scale
        val heightPx = (descentPx - ascentPx) * scale

        // Matches the whole-label path's anchoring: the run's centre sits at the feature anchor plus
        // the paint offset plus a fraction of the run's own size.
        val centreX = offsetXPx + widthPx * anchorFracX
        val centreY = offsetYPx + heightPx * anchorFracY
        // Top-left of the run's box, and the baseline within it. bearingY is measured from the
        // baseline (negative up), so the baseline must be located before glyphs can be placed.
        val boxLeft = centreX - widthPx * 0.5f
        val boxTop = centreY - heightPx * 0.5f
        val baselineY = boxTop + (-ascentPx) * scale

        val quads = ArrayList<GlyphQuad>(metrics.size)
        var penX = 0f
        for ((index, m) in metrics.withIndex()) {
            if (m.widthPx > 0 && m.heightPx > 0) {
                val w = m.widthPx * scale
                val h = m.heightPx * scale
                val left = boxLeft + penX + m.bearingXPx * scale
                val top = baselineY + m.bearingYPx * scale
                quads.add(
                    GlyphQuad(
                        glyphIndex = index,
                        halfWidthPx = w * 0.5f,
                        halfHeightPx = h * 0.5f,
                        centerOffsetXPx = left + w * 0.5f,
                        centerOffsetYPx = top + h * 0.5f,
                    ),
                )
            }
            penX += (m.advancePx + letterSpacingPx) * scale
        }
        return Line(quads, widthPx, heightPx)
    }
}
