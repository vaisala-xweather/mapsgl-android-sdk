package com.xweather.mapsgl.renderers

import android.content.Context
import android.opengl.GLES31
import android.util.Log
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.style.GridLayerPaint
import com.xweather.mapsgl.style.IconSize
import kotlin.concurrent.withLock
import kotlin.math.max

/**
 * Renders wind-barb sampling as **instanced quads** in the Mapbox custom layer GL pass, using
 * per-frame projection/model-view from [com.mapbox.maps.CustomLayerRenderParameters] when available
 * so icons stay **pitch-correct** with the map (same framing as Mapbox symbols).
 *
 * Glyphs are sampled from a **wind-barb-only** `GL_TEXTURE_2D_ARRAY` built from [sprite-sdf@2x.png] by cropping each
 * `wind-barb-{kt}-sdf` rect from JSON. Hurricane / tropical sprites in the same PNG are **not** in that array, so this
 * layer cannot draw them. Atlas layer `i` matches JS: **floor(speedMs / (5×0.5144444))** clamped to 0…20 (5‑knot steps in m/s, same as [GridLayerPaint] `interval`).
 *
 * Placement and sampling reuse [EncodedGridVectorTileSource] (no Mapbox vector symbol layer).
 *
 * **Timeline meld** is applied on the GPU ([Timeline.dataMeld] uniform), like encoded raster layers
 * blending two phases each frame without rebuilding instance data every tick.
 */
class WindBarbInstancedRenderer(
    override var id: String,
) : GridLayerRenderer(id) {

    override val logTag: String = "WindBarbInstancedRenderer"

    private var windBarbShaderProgram = 0

    /** `GL_TEXTURE_2D_ARRAY` of 21 wind-barb SDF slices (no hurricane/tropical tiles). */
    private var sdfAtlasTextureId = 0
    private var locSdfTex = -1
    private var haloColorUniformLocation = -1
    private var haloWidthUniformLocation = -1

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>, camera: Camera) {
        val tl = tileLayer ?: return
        scheduleInstancedCpuGatherBeforeDraw(tl)
        consumePendingInstanceUploadAndDraw(camera)
        val mc = tl.mapController as? MapboxMapController
        val gs = gridSource
        if (mc != null && gs != null && gpuInstanceCount > 0) {
            maybeSchedulePrefetchNextPhase(tl, mc, gs, 0.0)
        }
    }

    override suspend fun runGridGatherOnce(
        tl: TileLayer,
        gs: EncodedGridVectorTileSource,
        mc: MapboxMapController,
    ): Boolean {
        if (adoptPrefetched()) return true
        val zoom = CameraSync.zoomForCustomLayerInstancing()
        val gatherKeyAtStart = computeGatherKey(tl)
        val bounds = resolveVisibleGeoBoundsForGather(tl, mc, zoom)
        val coords = tl.visibleTileCoordsForSidecarSampling()
        if (coords.isEmpty()) return false
        val (floats, n) = gs.buildInstancedWindBufferDualPhase(coords, zoom, bounds, 12_000)
        bufferLock.withLock {
            pendingInstanceData = floats
            pendingInstanceCount = n
            pendingGatherZoom = zoom
            pendingAppliedGatherKey = gatherKeyAtStart
            pendingBufferPhaseA = Timeline.currentPhaseA
            pendingBufferPhaseB = Timeline.currentPhaseB
        }
        return true
    }

    /**
     * [u_haloWidth] in the barb shader lowers the ink threshold below [INNER_EDGE] (0.8), in atlas SDF units.
     * Thin barb lines need a large inset; proportional to stroke px with a visible floor.
     */
    override fun resolveStrokeHaloSdfWidth(): Float {
        val gridPaint = tileLayer?.paint as? GridLayerPaint ?: return 0f
        val widthPx = strokeThicknessPx(gridPaint) ?: return 0f
        if (widthPx <= 0f) return 0f
        val density = griddedIconDisplayDensity()
        val scale = GRIDDED_ICON_GL_PIXEL_SCALE
        val iconSize = gridPaint.icon.iconSize
        val iconRefPx =
            minOf(
                (iconSize?.width ?: IconSize.JS_REFERENCE_WIDTH_PX) * density * scale,
                (iconSize?.height ?: IconSize.JS_REFERENCE_WIDTH_PX) * density * scale,
            ).coerceAtLeast(1f)
        val frac = widthPx / iconRefPx
        return (frac * BARB_STROKE_INSET_SCALE).coerceIn(BARB_STROKE_INSET_MIN, BARB_STROKE_INSET_MAX)
    }

    /** Square barb quad: JS uses `icon.size` 40×40px; shader uses one half-extent — max of anisotropic halves. */
    private fun resolveBarbIconHalfWorld(baseHalfWorld: Float): Float {
        val p = tileLayer?.paint as? GridLayerPaint ?: return baseHalfWorld
        val icon = p.icon
        icon.iconSize?.let { sz ->
            val (hx, hy) = mercatorHalfExtentsFromJsIconPixels(sz.width, sz.height, baseHalfWorld)
            return max(hx, hy)
        }
        val s = icon.size?.constantValue ?: return baseHalfWorld
        val d = griddedIconDisplayDensity()
        return (baseHalfWorld * s.toFloat().coerceIn(0.05f, 8f) * d * GRIDDED_ICON_GL_PIXEL_SCALE).coerceIn(2f, 192f)
    }

    override fun ensureGlResources() {
        if (glReady) return
        val ctx: Context = tileLayer?.drawContext ?: return

        val vs = compileShaderOrNull(GLES31.GL_VERTEX_SHADER, VERT_SHADER, "wind barb VS")
        val fs = compileShaderOrNull(GLES31.GL_FRAGMENT_SHADER, FRAG_SHADER, "wind barb FS")
        if (vs == null || fs == null) {
            if (vs != null) GLES31.glDeleteShader(vs)
            if (fs != null) GLES31.glDeleteShader(fs)
            return
        }
        val prog = GLES31.glCreateProgram()
        GLES31.glAttachShader(prog, vs)
        GLES31.glAttachShader(prog, fs)
        GLES31.glLinkProgram(prog)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)

        val linkOk = IntArray(1)
        GLES31.glGetProgramiv(prog, GLES31.GL_LINK_STATUS, linkOk, 0)
        if (linkOk[0] == 0) {
            Log.e(logTag, "Wind barb program link failed: ${GLES31.glGetProgramInfoLog(prog)}")
            GLES31.glDeleteProgram(prog)
            return
        }

        sdfAtlasTextureId = WindBarbSdfAtlas.uploadWindBarbTexture2DArray(ctx)

        windBarbShaderProgram = prog
        locSdfTex = GLES31.glGetUniformLocation(windBarbShaderProgram, "u_sdfTex")
        haloColorUniformLocation = GLES31.glGetUniformLocation(windBarbShaderProgram, "u_haloColor")
        haloWidthUniformLocation = GLES31.glGetUniformLocation(windBarbShaderProgram, "u_haloWidth")

        val vaos = IntArray(1)
        GLES31.glGenVertexArrays(1, vaos, 0)
        vao = vaos[0]
        GLES31.glBindVertexArray(vao)

        val quad = floatArrayOf(
            -1f, -1f, 1f, -1f, -1f, 1f,
            1f, -1f, -1f, 1f, 1f, 1f,
        )
        val vbos = IntArray(2)
        GLES31.glGenBuffers(2, vbos, 0)
        quadVbo = vbos[0]
        instanceVbo = vbos[1]

        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, quadVbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, quad.size * 4, quad.toFloatBuffer(), GLES31.GL_STATIC_DRAW)
        GLES31.glEnableVertexAttribArray(0)
        GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, 2 * 4, 0)
        GLES31.glVertexAttribDivisor(0, 0)

        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, instanceVbo)
        val stride = GridLayerRenderer.FLOATS_PER_INSTANCE * 4
        GLES31.glEnableVertexAttribArray(1)
        GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, stride, 0)
        GLES31.glVertexAttribDivisor(1, 1)
        GLES31.glEnableVertexAttribArray(2)
        GLES31.glVertexAttribPointer(2, 4, GLES31.GL_FLOAT, false, stride, 8)
        GLES31.glVertexAttribDivisor(2, 1)
        GLES31.glEnableVertexAttribArray(3)
        GLES31.glVertexAttribPointer(3, 4, GLES31.GL_FLOAT, false, stride, 24)
        GLES31.glVertexAttribDivisor(3, 1)
        GLES31.glEnableVertexAttribArray(4)
        GLES31.glVertexAttribPointer(4, 4, GLES31.GL_FLOAT, false, stride, 40)
        GLES31.glVertexAttribDivisor(4, 1)

        GLES31.glBindVertexArray(0)
        glReady = true
    }

    override fun drawInstanced(camera: Camera, instanceCount: Int, dataMeld: Float) {
        if (windBarbShaderProgram == 0) return
        val proj = CameraSync.mapboxProjectionMatrix ?: projectionMatrixToFloatArray(camera.projectionMatrix)
        val mv = CameraSync.mapboxModelViewMatrix ?: matrix4ToFloatArray(camera.viewMatrix)

        GLES31.glUseProgram(windBarbShaderProgram)
        GLES31.glUniformMatrix4fv(
            GLES31.glGetUniformLocation(windBarbShaderProgram, "u_projection"),
            1,
            false,
            proj,
            0,
        )
        GLES31.glUniformMatrix4fv(
            GLES31.glGetUniformLocation(windBarbShaderProgram, "u_modelView"),
            1,
            false,
            mv,
            0,
        )
        GLES31.glUniform1f(
            GLES31.glGetUniformLocation(windBarbShaderProgram, "u_mercatorZoomFix"),
            CameraSync.mercatorWorldPixelZoomFix(gpuGatherZoom),
        )
        val baseHalfWorld = baseHalfWorldMercatorForInstancedIcon()
        val iconHalfWorld = resolveBarbIconHalfWorld(baseHalfWorld)
        GLES31.glUniform1f(GLES31.glGetUniformLocation(windBarbShaderProgram, "u_iconHalfExtent"), iconHalfWorld)
        GLES31.glUniform1f(GLES31.glGetUniformLocation(windBarbShaderProgram, "u_dataMeld"), dataMeld)

        GLES31.glActiveTexture(GLES31.GL_TEXTURE0)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D_ARRAY, sdfAtlasTextureId)
        if (locSdfTex >= 0) {
            GLES31.glUniform1i(locSdfTex, 0)
        }
        applyStrokeHaloUniforms(haloWidthUniformLocation, haloColorUniformLocation)

        GLES31.glBindVertexArray(vao)
        val depthWasEnabled = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        GLES31.glEnable(GLES31.GL_BLEND)
        GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
        GLES31.glDrawArraysInstanced(GLES31.GL_TRIANGLES, 0, 6, instanceCount)
        GLES31.glDisable(GLES31.GL_BLEND)
        if (depthWasEnabled) {
            GLES31.glEnable(GLES31.GL_DEPTH_TEST)
        }
        GLES31.glBindVertexArray(0)
        GLES31.glUseProgram(0)
    }

    private fun compileShaderOrNull(type: Int, src: String, tag: String): Int? {
        val s = GLES31.glCreateShader(type)
        GLES31.glShaderSource(s, src)
        GLES31.glCompileShader(s)
        val ok = IntArray(1)
        GLES31.glGetShaderiv(s, GLES31.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            Log.e(logTag, "$tag compile failed: ${GLES31.glGetShaderInfoLog(s)}")
            GLES31.glDeleteShader(s)
            return null
        }
        return s
    }

    override fun onRemove() {
        super.onRemove()
        if (sdfAtlasTextureId != 0) {
            GLES31.glDeleteTextures(1, intArrayOf(sdfAtlasTextureId), 0)
            sdfAtlasTextureId = 0
        }
        if (windBarbShaderProgram != 0) {
            GLES31.glDeleteProgram(windBarbShaderProgram)
            windBarbShaderProgram = 0
        }
        if (vao != 0) {
            GLES31.glDeleteVertexArrays(1, intArrayOf(vao), 0)
            vao = 0
        }
        if (quadVbo != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(quadVbo), 0)
            quadVbo = 0
        }
        if (instanceVbo != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(instanceVbo), 0)
            instanceVbo = 0
        }
        glReady = false
        locSdfTex = -1
        haloColorUniformLocation = -1
        haloWidthUniformLocation = -1
    }

    companion object {
        /** Must match [FRAG_SHADER] `INNER_EDGE`. */
        private const val BARB_SDF_INNER_EDGE = 0.8f

        /** Maps stroke px → lowered SDF edge (see [resolveStrokeHaloSdfWidth]). */
        private const val BARB_STROKE_INSET_SCALE = 2.5f
        private const val BARB_STROKE_INSET_MIN = 0.12f
        private const val BARB_STROKE_INSET_MAX = 0.55f

        private const val VERT_SHADER = """#version 300 es
precision highp float;
uniform mat4 u_projection;
uniform mat4 u_modelView;
uniform float u_mercatorZoomFix;
uniform float u_iconHalfExtent;
uniform float u_dataMeld;
layout(location = 0) in vec2 a_quad;
layout(location = 1) in vec2 a_tileXY;
layout(location = 2) in vec4 a_phase;
layout(location = 3) in vec4 a_colorA;
layout(location = 4) in vec4 a_colorB;
out vec4 v_color;
out vec2 v_tex;
flat out int v_barbLayer;
/** 5 knots in m/s — same as web `interval: 5 * 0.5144444` for `floor(v / atlasInterval)`. */
const float WIND_BARB_ATLAS_INTERVAL_MS = 5.0 * 0.5144444;
void main() {
    float t = clamp(u_dataMeld, 0.0, 1.0);
    float dirA = a_phase.x;
    float speedA = a_phase.y;
    float dirB = a_phase.z;
    float speedB = a_phase.w;
    // Shortest-path direction blend (see WindArrowInstancedRenderer) — avoids opposite-vector mix singularity.
    float dDeg = mod(dirB - dirA + 540.0, 360.0) - 180.0;
    float dirM = mod(dirA + t * dDeg + 360.0, 360.0);
    float radM = radians(dirM - 90.0);
    vec2 vm = vec2(cos(radM), sin(radM));
    float rotDeg = degrees(atan(vm.y, vm.x));
    float rad = radians(rotDeg);
    float c = cos(rad);
    float s = sin(rad);
    mat2 R = mat2(c, -s, s, c);
    /** Pivot at texture bottom-center: with [v_tex] = (v0, 1−u0), (0.5,0) maps to a_quad = (1,0), not quad bottom. */
    vec2 pivot = vec2(u_iconHalfExtent, 0.0);
    vec2 rel = a_quad * u_iconHalfExtent - pivot;
    vec2 offset = R * vec2(rel.x, -rel.y);
    vec4 world = vec4((a_tileXY + offset) * u_mercatorZoomFix, 0.0, 1.0);
    gl_Position = u_projection * u_modelView * world;
    v_color = vec4(mix(a_colorA.rgb, a_colorB.rgb, t), 1.0);
    float speedMs = mix(speedA, speedB, t);
    int vi = int(floor(speedMs / WIND_BARB_ATLAS_INTERVAL_MS));
    v_barbLayer = clamp(vi, 0, 20);
    /** 90° CCW then 180° about sprite center → (u,v) → (v, 1−u). */
    float u0 = a_quad.x * 0.5 + 0.5;
    float v0 = a_quad.y * 0.5 + 0.5;
    v_tex = vec2(v0, 1.0 - u0);
}
"""

        /** Samples wind-barb-only [sampler2DArray] slice [v_barbLayer]. */
        private const val FRAG_SHADER = """#version 300 es
precision highp float;
precision highp sampler2DArray;
uniform sampler2DArray u_sdfTex;
/** [GridLayerPaint.stroke]; [u_haloWidth] = atlas SDF inset below [INNER_EDGE] (see [resolveStrokeHaloSdfWidth]). */
uniform vec4 u_haloColor;
uniform float u_haloWidth;
in vec4 v_color;
in vec2 v_tex;
flat in int v_barbLayer;
out vec4 fragColor;

float barbSdfDist(vec2 uv) {
    return texture(u_sdfTex, vec3(uv, float(v_barbLayer))).r;
}

void main() {
    float dist0 = barbSdfDist(v_tex);
    /** Parity with JS barb shader: high threshold = thin strokes & more negative space. */
    const float INNER_EDGE = 0.8;
    float aa = max(fwidth(dist0), 0.001);
    float fillA = smoothstep(INNER_EDGE - aa, INNER_EDGE + aa, dist0);

    if (u_haloWidth > 0.0) {
        float strokeEdge = INNER_EDGE - u_haloWidth;
        float dilate = u_haloWidth * 0.35;
        vec2 r = vec2(dilate, dilate);
        float distWide = dist0;
        distWide = max(distWide, barbSdfDist(v_tex + vec2(r.x, 0.0)));
        distWide = max(distWide, barbSdfDist(v_tex - vec2(r.x, 0.0)));
        distWide = max(distWide, barbSdfDist(v_tex + vec2(0.0, r.y)));
        distWide = max(distWide, barbSdfDist(v_tex - vec2(0.0, r.y)));
        distWide = max(distWide, barbSdfDist(v_tex + vec2(r.x, r.y)));
        distWide = max(distWide, barbSdfDist(v_tex + vec2(-r.x, r.y)));
        distWide = max(distWide, barbSdfDist(v_tex + vec2(r.x, -r.y)));
        distWide = max(distWide, barbSdfDist(v_tex + vec2(-r.x, -r.y)));
        float strokeA = smoothstep(strokeEdge - aa, strokeEdge + aa, distWide);
        float haloOnly = strokeA * (1.0 - fillA);
        vec3 rgb = mix(u_haloColor.rgb, v_color.rgb, fillA);
        float alpha = max(haloOnly * u_haloColor.a, fillA * v_color.a);
        fragColor = vec4(rgb, alpha);
    } else {
        fragColor = vec4(v_color.rgb, fillA * v_color.a);
    }
}
"""
    }
}
