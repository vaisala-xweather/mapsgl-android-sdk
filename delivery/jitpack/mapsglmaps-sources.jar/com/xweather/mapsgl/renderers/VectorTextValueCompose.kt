package com.xweather.mapsgl.renderers

/**
 * Splits data-query value strings into reusable atlas segments (digits + unit suffix).
 *
 * Whole-string packing of every playback value (`12mph`, `13mph`, …) filled [VectorTextAtlas]
 * during timeline play. Composing from shared digit/unit glyphs keeps the working set near the
 * size of the alphabet instead of unique formatted values.
 */
internal object VectorTextValueCompose {

    /**
     * Known unit suffixes from [com.xweather.mapsgl.layers.tile.DataQueryCoordinator] formatters.
     * Longest-first so `km/h` wins over `km` / `h`, `inHg` over `in`, etc.
     */
    private val UNIT_SUFFIXES =
        listOf(
            "°F",
            "°C",
            "inHg",
            "km/h",
            "mph",
            "kts",
            "m/s",
            "hPa",
            "mb",
            "km",
            "mi",
            "mm",
            "cm",
            "in",
            "%",
            "K",
        ).sortedByDescending { it.length }

    /**
     * @return segment list such as `["1","2","mph"]` / `["-","5","°C"]`, or null when [display]
     * is not a composable numeric value (caller should pack the whole string).
     */
    fun splitValueSegments(display: String): List<String>? {
        if (display.isEmpty()) return null
        var i = 0
        val parts = ArrayList<String>(8)
        val first = display[0]
        if (first == '+' || first == '-') {
            parts.add(first.toString())
            i = 1
        }
        var sawDigit = false
        while (i < display.length) {
            val c = display[i]
            if (c.isDigit() || c == '.') {
                parts.add(c.toString())
                if (c.isDigit()) sawDigit = true
                i++
            } else {
                break
            }
        }
        if (!sawDigit) return null
        if (i < display.length) {
            val rest = display.substring(i)
            val known = UNIT_SUFFIXES.any { it == rest }
            val letterish = rest.isNotEmpty() && rest.all { it.isLetter() || it == '/' || it == '°' }
            if (!known && !letterish) return null
            parts.add(rest)
        }
        return parts
    }

    data class Quad(
        val glyph: VectorTextAtlas.Glyph,
        /** Glyph center X from the left edge of the composed line box (1x CSS px). */
        val centerFromLineLeftPx: Float,
    )

    data class Line(
        val quads: List<Quad>,
        val widthPx: Float,
        val heightPx: Float,
    )

    /**
     * Packs [display] as digit/unit segment glyphs and lays them out with [Paint]-accurate advances.
     * @return null when [display] is not composable or any segment fails to pack.
     */
    fun composeValueLine(
        display: String,
        fontSizePx: Int,
        colorArgb: Int,
        outlineArgb: Int?,
        bold: Boolean,
        outlineWidthScale: Float = 1f,
    ): Line? {
        val parts = splitValueSegments(display) ?: return null
        val lineW = VectorTextAtlas.measureTextAdvancePx(display, fontSizePx, bold).coerceAtLeast(1f)
        var maxH = 1f
        val quads = ArrayList<Quad>(parts.size)
        var prefix = ""
        for (part in parts) {
            val key =
                VectorTextAtlas.Key(
                    part,
                    fontSizePx,
                    colorArgb,
                    outlineArgb,
                    bold,
                    outlineWidthScale,
                    tightHorizontalPad = true,
                )
            val glyph = VectorTextAtlas.ensureComposableGlyph(key) ?: return null
            val xLeft = VectorTextAtlas.measureTextAdvancePx(prefix, fontSizePx, bold)
            val segAdvance = VectorTextAtlas.measureTextAdvancePx(part, fontSizePx, bold)
            // Align glyph center to the Paint advance mid of this segment (pads are symmetrical).
            val center = xLeft + segAdvance * 0.5f
            quads.add(Quad(glyph, center))
            maxH = maxOf(maxH, glyph.heightPx.toFloat())
            prefix += part
        }
        if (quads.isEmpty()) return null
        return Line(quads, lineW, maxH)
    }
}
