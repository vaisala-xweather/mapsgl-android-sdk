package com.xweather.mapsgl.renderers


import com.xweather.mapsgl.gl.ParticleRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.programs.TriangleProgram
import com.xweather.mapsgl.style.ColorLookupTable
import com.xweather.mapsgl.style.ColorScaleOptions
import com.xweather.mapsgl.style.ColorStop
import com.xweather.mapsgl.types.math_type.resolveDrawRange
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.colorScaleRangeForMagnitudeLookup
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.math_type.ValueRange
import kotlin.math.pow

interface ParticleRendererOptions : EncodedDataRendererOptions {
    val totalParticles: Int
    val particleSize: Int
    val enableTrails: Boolean
    val speedFactor: Double
    val dropRate: Double
    val dropRateBump: Double
    val fade: Double
}

class ParticleRenderer(override var id: String) : EncodedDataRenderer<TileData, LayerRenderContext<Any>>(id) {

    private lateinit var paintStyle: ParticleLayerPaint
    private var _particleCount = 256.0.pow(2).toInt()
    private var _renderTrails = false

    init {
        // If a custom particle count is set, automatically set `density` to `count`.
        val count = _particleCount
        this._particleCount = 0;
        this._renderTrails = false
    }

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {
        TODO("Not yet implemented")
    }

    //override fun draw(texUnit: HashMap<String, HashMap<String, Int>>) {
    //    TODO("Not yet implemented")
    //}

    override fun onAdd() {
        TODO("Not yet implemented")
    }

    //override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer) {
    //    super.onAdd(tileLayer)
    //}

    override fun setUpRenderPass(): RenderPass {
        if (pr.ON) pr.p("ParticleRenderer", pr.waaveRenderpath, ">> setupRenderpass")
        if (this.tileLayer?.source?.id != null) {
            return ParticleRenderPass(tileLayer!!.source.id, tileLayer!!.paint)
        } else {
            return ParticleRenderPass("particle", tileLayer!!.paint)
        }
    }

    override suspend fun update() {
        TODO("Not yet implemented")
    }

    /*
    private fun makeMeshForRenderable(renderable: TileRenderable<DataType>?): Mesh {
        return try {
            if (program == null) {
                createProgram()
                mesh = Mesh(0, quadGeometry, program!!, createFrameBufferProgram())
                mesh.textureProgram = createTextureProgram()
                //tileLayer!!.paint is ParticleLayerPaint
            } else if (resetPaint) {
                resetProgram()
                resetPaint = false
            }
            return mesh

        } catch (e: Exception) {
            throw e
        }
    } */

    override fun prerender(context: LayerRenderContext<Any>) {
        super.prerender(context)
    }

    /**
     * The sampled band's no-data byte. The draw shader hides particles over it and the compute
     * pass respawns them, instead of advecting them with the sentinel decoded as a full-strength vector.
     */
    private fun applyBandNoData(tProgram: TriangleProgram) {
        val channel = paintStyle.sample.channel.firstOrNull()?.rawValue
        val noData = channel?.let { ch ->
            tileLayer?.source?.datasets?.firstOrNull { (it.band?.rawValue ?: -1) == ch }?.noData
        }
        if (noData != null) {
            tProgram.updateNoData((noData / 255.0).toFloat())
            tProgram.noDataC = (noData / 255.0).toFloat()
        } else {
            tProgram.noDataC = -1f
        }
    }

    override fun setup(paint: LayerPaint) {
        paintStyle = (paint as ParticleLayerPaint)
        val colorScale = paintStyle.sample.colorScale
        val expression = paintStyle.sample.expression
        _outputRange = ValueRange(0.0, 255.0, "")

        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        val tProgram = (program as TriangleProgram)
        applyBandNoData(tProgram)

        applyColorAndDrawRange(tProgram, colorScale, expression)

        //Fixme: colorRange is applied in createColorLookupBitmap(), it should be applied earlier in createColorLookupTables()
        colorBandBitmap = arrayOf(colorLookupTable.createColorLookupBitmap(256, 1))

        tProgram.uniforms["colorBitmap"] = colorBandBitmap
        colorBandTexHandles[0] =
            ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.let { it.interpolate && it.interval == 0.0 })
        tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]

        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1
        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }
        tProgram.updateChannels(channel1, channel2) //normal

    }

    /**
     * Rebuilds the colour lookup tables when a caller has raised
     * [TileLayerRenderer.resetPaint].
     *
     * Sample and contour layers act on that flag in `makeMeshForRenderable` by calling
     * `resetProgram()`. Particles cannot: `resetProgram()` assigns a new program to
     * [TileLayerRenderer.program], but [TileLayerRenderer.mesh] captured its program in a `val` at
     * construction and the render pass draws with the mesh's. The rebuilt tables would land on a
     * program nothing draws, and the replaced one would leak. So `makeMeshForRenderable` leaves the
     * flag alone for particle paint, and it is consumed here instead.
     *
     * The colour lookup tables are rebuilt by [setup] and [setupFrameBufferProgram], which reuse
     * the existing programs, and a density or count change is picked up by
     * [ParticleRenderPass.refreshParticleCount]. Removing and re-adding the layer is *not* an
     * equivalent: that builds a new program and a new `ParticleTileBufferPool` each time.
     *
     * Both programs need it. [setup] uploads the LUT to the compute/particle program and
     * [setupFrameBufferProgram] to the screen program; doing only the first leaves the visible
     * pass on the previous colours.
     *
     * If the program does not exist yet the flag is left raised so a later frame can apply it,
     * rather than being consumed against nothing.
     */
    override fun applyPendingPaintReset() {
        if (!resetPaint) return
        val particlePaint = tileLayer?.paint as? ParticleLayerPaint ?: return
        if (program == null) return
        resetPaint = false

        setup(particlePaint)
        (screenProgramOrNull as? RasterTileProgram)?.let {
            setupFrameBufferProgram(particlePaint, it)
        }

        // A density or count change resizes the simulation rather than the colour tables, so it is
        // handled on the pass. No-op when the count is unchanged.
        if (renderpassInitialized) {
            (renderPass as? ParticleRenderPass)?.refreshParticleCount()
        }
    }

    override fun setNeedsUpdate() {}

    /**
     * Builds the color lookup table and sets the data, draw and discard ranges on [tProgram].
     * Shared by the particle program and the framebuffer program so the two cannot disagree.
     */
    private fun applyColorAndDrawRange(
        tProgram: TriangleProgram,
        colorScale: ColorScaleOptions,
        expression: SampleExpression,
    ) {
        // The lookup table spans the color scale's own range, never the draw range. Spanning the
        // draw range stretched the whole scale across it, so narrowing the range recolored every
        // particle instead of hiding the ones outside it. MapsGL JS keeps the scale where it is and
        // discards (particles-draw.frag.glsl).
        val lutRange =
            colorScaleRangeForMagnitudeLookup(
                expression,
                colorScale.range
                    ?: run {
                        val stops = colorScale.stops.filterIsInstance<ColorStop>()
                        val first = stops.firstOrNull()?.value ?: 0.0
                        val last = stops.lastOrNull()?.value ?: (first + 1.0)
                        first..last
                    },
            )

        val channelIndex = paintStyle.sample.channel.firstOrNull()?.rawValue
        val datasetRange =
            channelIndex?.let { tileLayer?.source?.datasets?.get(it)?.dataRange } ?: lutRange

        createColorLookupTables(options = colorScale, drawRange = lutRange)
        tProgram.updateDataRange(datasetRange.start.toFloat(), datasetRange.endInclusive.toFloat())
        // tilePartFrag: drawValue = (magnitude/dataRangeMax - drawRangeMin) / (drawRangeMax - drawRangeMin)
        tProgram.updateDrawRange(0f, 1f)
        // drawRange is a discard window on wind speed, in the data's units. An end left open
        // (BoundedRange.atLeast / atMost) is filled from the speed range the data can reach, which
        // for a vector field starts at 0 even though its components go negative.
        val discardRange = resolveDrawRange(
            paintStyle.sample.drawRange,
            colorScaleRangeForMagnitudeLookup(expression, datasetRange),
        )
        if (discardRange != null && discardRange.start < discardRange.endInclusive) {
            tProgram.updateDiscardRange(discardRange.start.toFloat(), discardRange.endInclusive.toFloat())
        } else if (discardRange != null) {
            // Inverted or empty - a min written above the max, or an open end that resolves past
            // the data. MapsGL JS draws nothing then. max <= min is the shader's "no draw range"
            // sentinel, so send a window no wind speed can fall in instead of the range itself.
            tProgram.updateDiscardRange(EMPTY_WINDOW_MIN, Float.MAX_VALUE)
        } else {
            tProgram.updateDiscardRange(-1f, -1f)
        }
    }

    fun setupFrameBufferProgram(paint: LayerPaint, rasterTileProgram: RasterTileProgram) {
        paintStyle = (paint as ParticleLayerPaint)
        val colorScale = paintStyle.sample.colorScale
        val expression = paintStyle.sample.expression
        _outputRange = ValueRange(0.0, 255.0, "")

        val md = (this.tileLayer?.source)?.metadata
        if (md != null) {
            if (md.noData != null) _outputRange.min = md.noData!!.toDouble()
        }

        val tProgram = (rasterTileProgram as TriangleProgram)

        applyColorAndDrawRange(tProgram, colorScale, expression)

        //Fixme: colorRange is applied in createColorLookupBitmap(), it should be applied earlier in createColorLookupTables()
        colorBandBitmap = arrayOf(colorLookupTable.createColorLookupBitmap(256, 1))

        tProgram.uniforms["colorBitmap"] = colorBandBitmap[0]
        colorBandTexHandles[0] =
            ColorLookupTable.bitmapToTextureHandle(colorBandBitmap[0], paintStyle.sample.colorScale.let { it.interpolate && it.interval == 0.0 })
        tProgram.uniforms["colorBandTexHandle"] = colorBandTexHandles[0]
        val channel1 = paintStyle.sample.channel[0].rawValue
        var channel2 = -1
        if (paintStyle.sample.channel.size > 1) {
            channel2 = paintStyle.sample.channel[1].rawValue
        }
        tProgram.updateChannels(channel1, channel2) //normal

    }

    fun updateParticleDrawPasses(enableTrails: Boolean) {
        this._renderTrails = enableTrails
    }

    private companion object {
        /** Floor of a discard window above any real wind speed, so it hides every particle. */
        const val EMPTY_WINDOW_MIN = Float.MAX_VALUE / 2f
    }
}