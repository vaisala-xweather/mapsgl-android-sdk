package com.xweather.mapsgl.renderers

import android.os.SystemClock
import android.opengl.GLES31
import android.opengl.Matrix
import android.util.Log
import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.EmptyRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.GeoJsonWorldCopies
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.VectorDrawTime
import com.xweather.mapsgl.map.mapbox.VectorFeatureDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorGlPlaybackDiagnostics
import com.xweather.mapsgl.map.mapbox.VectorMapTime
import com.xweather.mapsgl.map.mapbox.VectorPolygonFillTriangulator
import com.xweather.mapsgl.map.mapbox.geoJsonVisibleFeatureSetKey
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.meshModeFingerprint
import com.xweather.mapsgl.sources.markLayerMeshReady
import com.xweather.mapsgl.sources.withGpuUpload
import com.xweather.mapsgl.map.mapbox.ExpressionFilterFlatten
import com.xweather.mapsgl.map.mapbox.ExpressionReferencedKeys
import com.xweather.mapsgl.map.mapbox.TropicalDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorCircleRawStyleEval
import com.xweather.mapsgl.map.mapbox.VectorLayerDrawFilterDefaults
import com.xweather.mapsgl.sources.nestedDictionary
import com.xweather.mapsgl.sources.resolveVectorTileData
import com.xweather.mapsgl.sources.timelinePhaseEpochMillis
import com.xweather.mapsgl.style.CircleLayerPaint
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import com.xweather.mapsgl.mvt.MvtFeature

private const val VECTOR_CIRCLE_TAG = "VectorCircleLayerRenderer"
/** Rule: playback-mesh-cache-bound. See VectorFillLayerRenderer.PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES. */
private const val PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES = 24L * 1024L * 1024L

/** Rule: playback-mesh-cache-bound. See VectorFillLayerRenderer.trimMeshCacheHard. */
private fun trimMeshCacheHard(cache: ConcurrentHashMap<String, FloatArray>, protected: Set<String>, maxBytes: Long) {
    var totalBytes = cache.values.sumOf { it.size.toLong() * 4L }
    if (totalBytes <= maxBytes) return
    val nonProtected = cache.entries.iterator()
    while (totalBytes > maxBytes && nonProtected.hasNext()) {
        val entry = nonProtected.next()
        if (entry.key !in protected) {
            totalBytes -= entry.value.size.toLong() * 4L
            nonProtected.remove()
        }
    }
    if (totalBytes > maxBytes) {
        val anyEntry = cache.entries.iterator()
        while (totalBytes > maxBytes && anyEntry.hasNext()) {
            val entry = anyEntry.next()
            totalBytes -= entry.value.size.toLong() * 4L
            anyEntry.remove()
        }
    }
}

/** Shared by [VectorCircleLayerRenderer] and [VectorSymbolLayerRenderer] draw loops. */
internal fun vectorTileSourceDrawIntervalMs(tileLayer: TileLayer?, vts: VectorTileSource): Long? {
    if (!vts.isTimeSeriesSource) return null
    timelinePhaseEpochMillis(Timeline.currentPhaseA)?.let { return it }
    return tileLayer?.animator?.currentInterval?.interval?.takeIf { it > 0L }
}

/**
 * Pure decision function behind [VectorCircleLayerRenderer.rawCirclePathEligible] (rule:
 * raw-circle-fast-path), split out so it's testable without instantiating the renderer (its GL calls
 * require an Android GLES context unavailable in plain JVM unit tests). See that function's KDoc for
 * the reasoning behind each condition.
 */
internal fun resolveRawCirclePathEligible(
    consumerCount: Int,
    layerId: String,
    filter: Expression?,
    circleColorExpression: Expression?,
    circleRadiusExpression: Expression?,
): Boolean {
    if (consumerCount != 1) return false
    if (TropicalDrawFilter.isTropicalTrackLineLayer(layerId)) return false
    val flatFilter = ExpressionFilterFlatten.flatten(filter)
    if (VectorLayerDrawFilterDefaults.effectiveFilter(layerId, flatFilter) != null) return false
    if (!VectorCircleRawStyleEval.isSupportedColorExpression(circleColorExpression)) return false
    if (!VectorCircleRawStyleEval.isSupportedNumberExpression(circleRadiusExpression)) return false
    return true
}

/**
 * Rule: raw-circle-fast-path. The gate-hold state machine's raw-mode counterpart to "data.features is
 * empty" — true when a raw-mode [VectorData] genuinely has nothing to draw (either no raw features at
 * all, or none pass the MVT `visible` check raw mode replicates), so the caller may vacuously treat
 * this phase/tile as ready. Split out as a pure function (rule: testability) so the two prior
 * gate-hold hangs' failure mode — a check like this silently disagreeing with what actually got
 * triangulated — has a single, independently-tested source of truth instead of being reimplemented
 * ad hoc at each call site.
 */
internal fun rawPhaseVacuouslyReady(rawFeatures: List<MvtFeature>): Boolean {
    if (rawFeatures.isEmpty()) return true
    return rawFeatures.none { feature ->
        @Suppress("UNCHECKED_CAST")
        VectorPolygonFillTriangulator.rawFeatureVisible(nestedDictionary(feature.attributes as Map<String, Any>))
    }
}

/**
 * GLES custom-circle path scales style pixel radii/strokes; not exposed on the public style API.
 *
 * Radii/strokes reach the shader in tile UV (`px / 512 / overscale`) and the tile matrix scales that
 * by the device pixel ratio on the way to the framebuffer, so the round trip is already
 * `style px * SCALE * density = device px`. At 1.0 a style radius of 3 draws a 3 dp radius -- the
 * same as `circle-radius: 3` in JS / Apple, at any density.
 *
 * Do **not** reintroduce a density multiplier here. This path used to fold in
 * `Camera.dpiMult` (= density / 2) on top of the matrix, which squares density: correct only at
 * xhdpi, where `dpiMult * ratio` happens to equal `density`. Measured on-device at density 2.625,
 * that drew every circle 1.31x oversized. Verified against earthquakes' expression radii too --
 * the "strong" stop (12) draws a 12 dp radius with the ring inset from it.
 */
internal const val VECTOR_CIRCLE_GL_PIXEL_SCALE = 1.0f

/**
 * Trims [CircleLayerPaint.stroke] thickness on the circle path only.
 *
 * The ring is inset from the outer radius (see the class KDoc), so thickness competes with fill for
 * the same disc: lightning's radius 3 / thickness 2 leaves just 1 style px of colour. Shaving the
 * ring keeps the outer size at JS parity while letting more of the fill colour -- which is what
 * carries the data -- through. Deliberately mild; if a layer wants a hairline, set its own
 * thickness rather than pushing this lower.
 */
internal const val VECTOR_CIRCLE_GL_STROKE_SCALE = 0.75f

/**
 * Nested inspector keys that circle paint expressions often never reference. Storm-cell
 * presentation requires `ob.movement.dirTo` while color only reads `traits.type`; without `ob`
 * the callout is empty even when the tap hits.
 */
internal val CIRCLE_INSPECTOR_PROPERTY_KEYS = setOf("ob", "traits")

/**
 * Draws [CircleLayerPaint] point features by tessellating [VectorTileSource] Point/MultiPoint
 * geometry in tile UV space inside a Mapbox [com.mapbox.maps.CustomLayerHost].
 *
 * Each MVT point becomes a 2-triangle bounding quad; the fragment shader clips to a smooth disc
 * using `length(v_corner) <= 1.0` with `fwidth`-based AA.
 *
 * Vertex layout: `[cx, cy, nx, ny, r, g, b, a, radius_scale]` — 9 floats, 36-byte stride.
 * Circle colour is read from [CircleLayerPaint.fill]; radius from [CircleLayerPaint.circle]
 * is the **total outer** radius (JS / Apple parity). When [CircleLayerPaint.stroke] is set, the
 * ring is drawn *inset* from that outer radius so overall size stays `2 * radius`.
 */
class VectorCircleLayerRenderer(
    override var id: String,
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {

    private companion object {
        // Bumped: cached meshes switched from 9-floats x 6-vertices/point to the 7-floats/point
        // instance layout below (rule: circle-gpu-instancing) — old cached FloatArrays must never be
        // misread under the new layout.
        private const val TRIANGULATION_COLOR_CACHE_VERSION = 8
        private const val CIRCLE_GL_PROGRAM_VERSION = 6

        /** Per-point instance data `[cx,cy,r,g,b,a,radius_scale]` — divisor 1, one record per point. */
        private val FLOATS_PER_INSTANCE = VectorPolygonFillTriangulator.CIRCLE_FLOATS_PER_INSTANCE
        private val CIRCLE_INSTANCE_STRIDE_BYTES = FLOATS_PER_INSTANCE * 4

        /** Static per-vertex quad corner `[nx,ny]` — divisor 0, the same 6 vertices for every draw. */
        private const val CIRCLE_QUAD_FLOATS_PER_VERTEX = 2
        private const val CIRCLE_QUAD_STRIDE_BYTES = CIRCLE_QUAD_FLOATS_PER_VERTEX * 4
        private const val CIRCLE_QUAD_VERTEX_COUNT = 6
        private val CIRCLE_QUAD_CORNERS = floatArrayOf(
            -1f, -1f,
            1f, -1f,
            1f, 1f,
            -1f, -1f,
            1f, 1f,
            -1f, 1f,
        )
    }

    private data class CachedDrawBatch(val coord: TileCoord, val interleaved: FloatArray)
    private data class DrawResult(val drawnCount: Int, val totalCount: Int, val batches: List<CachedDrawBatch>)

    init {
        cachesTextures = false
    }

    override fun onAdd() {}

    override fun onAdd(tileLayer: TileLayer) {
        super.onAdd(tileLayer)
        if (tileLayer is VectorTileLayer && tileLayer.glRenderingActive()) {
            tileLayer.externalScope.launch {
                tileLayer.prefetchVectorTilesForGlRendering()
                tileLayer.mapController?.redraw()
            }
        }
    }

    override fun onAdd(
        context: RenderContext<Any>,
        tileLayer: TileLayer,
        controller: MapboxMapController,
    ) {
    }

    private var circleGlProgram: Int = 0
    private var circleGlProgramVersion: Int = -1
    private var uCircleMvpLocation: Int = -1
    private var uRadiusUvLocation: Int = -1
    private var uStrokeColorLocation: Int = -1
    private var uStrokeUvLocation: Int = -1
    private var vbo: Int = 0
    /** Static per-vertex quad corner buffer (rule: circle-gpu-instancing) — created once, never re-uploaded. */
    private var circleQuadVbo: Int = 0
    private var circleByteBuffer: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
    private val triangulationCache = ConcurrentHashMap<String, FloatArray>()
    private val circleFeatureTimeCache = ConcurrentHashMap<String, FloatArray>()
    private val triangulationInProgress: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private var lastSuccessfulBatches: List<CachedDrawBatch> = emptyList()
    private var lastSuccessfulDrawIntervalMs: Long? = null
    /** Rule: steady-state-redundant-rebuild. See VectorFillLayerRenderer's identical field/KDoc —
     * lets the steady-state draw branch skip rebuilding via drawPlaybackCircleRefs when the interval
     * hasn't changed since the last rendered frame. Rule: steady-state-partial-resolve — only ever
     * set when a resolve was fully complete (every ref for the interval resolved), never on a partial. */
    private var lastSteadyStateIntervalMs: Long? = null
    /** Rule: shared-playback-gate. Generic gate-hold/warmup state machine; see [VectorPlaybackGateController]. */
    private val gate = VectorPlaybackGateController(id)

    private fun protectedPlaybackTriKeys(): Set<String> {
        val keys = HashSet<String>()
        // Rule: playback-refs-thread-safety. See VectorPlaybackGateController.refsLock's KDoc —
        // gate.refsByIntervalMs is written from the gate's background prep job while this iterates
        // it on the GL render thread; must hold the same lock the write side uses.
        // Rule: pan-during-playback. See VectorFillLayerRenderer.protectedFillTriKeys's KDoc — only
        // protects entries tagged with the current generation, so a coords-restart's stale entries
        // become evictable immediately instead of staying pinned for the whole reprime.
        synchronized(gate.refsLock) {
            for ((intervalMs, refs) in gate.refsByIntervalMs) {
                if (gate.refsGeneration[intervalMs] != gate.playbackPrepGeneration) continue
                for (ref in refs) keys.add(ref.triKey)
            }
        }
        return keys
    }

    private fun trimTriangulationCacheIfNeeded() {
        val protected = if (Timeline.isGloballyPlaying) protectedPlaybackTriKeys() else emptySet()
        val maxBytes = if (Timeline.isGloballyPlaying) {
            PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES
        } else {
            PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES / 2
        }
        trimMeshCacheHard(triangulationCache, protected, maxBytes)
    }
    private var pausedBatchCount = 0
    private var playbackFrozenBatches: List<CachedDrawBatch> = emptyList()
    private var playbackFrozenIntervalMs: Long? = null
    private val circleTriangulationThreads = 8
    private var backgroundExecutor = Executors.newFixedThreadPool(circleTriangulationThreads)
    private val minPromotionCoverage = 0.55f
    private val zoomTransitionHoldMs = 700L
    private var lastZoomFloor: Int? = null
    private var holdLastBatchesUntilMs: Long = 0L
    private val playbackCoordsHoldMs = 750L
    private val gateHoldMvtRequestsPerWave = 16
    // Grace period before a just-resumed playback session freezes lastSuccessfulBatches as a
    // fallback — avoids re-freezing on a debounced blip (e.g. a quick pause/resume).
    private val playbackPlayEdgeDebounceMs = 400L

    internal fun beginPlaybackPrefetchGate(layer: VectorTileLayer? = null) = gate.beginPlaybackPrefetchGate(layer)

    override fun setUpRenderPass(): RenderPass =
        EmptyRenderPass(tileLayer?.source?.id ?: id, tileLayer!!.paint)

    override fun prerender(context: LayerRenderContext<Any>) {}

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {}

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>, camera: Camera) {
        val layer = tileLayer as? VectorTileLayer ?: return
        val source = layer.source
        val geoJsonSource = source as? GeoJSONSource
        val vtsOrNull = source as? VectorTileSource
        if (geoJsonSource == null && vtsOrNull == null) return
        val mapboxProj = CameraSync.mapboxProjectionMatrix
        val mapboxMv = CameraSync.mapboxModelViewMatrix
        val useMapboxNativeMv =
            mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
        val proj = if (useMapboxNativeMv) mapboxProj!! else projectionMatrixToFloatArray(camera.projectionMatrix)
        val mvCam = if (useMapboxNativeMv) mapboxMv!! else matrix4ToFloatArray(camera.viewMatrix)
        val mapZoomNow = CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom

        ensureCircleProgram()
        if (circleGlProgram == 0 ||
            uCircleMvpLocation < 0 ||
            uRadiusUvLocation < 0 ||
            uStrokeUvLocation < 0
        ) {
            return
        }

        fun strokeWidthPxForPaint(paint: CircleLayerPaint): Float =
            (
                (paint.stroke.thickness.constantValue ?: 0.0).toFloat() *
                    VECTOR_CIRCLE_GL_STROKE_SCALE * VECTOR_CIRCLE_GL_PIXEL_SCALE
            ).coerceAtLeast(0f)

        fun circleRadiusStylePxForPaint(paint: CircleLayerPaint): Float =
            (paint.circle.radius.constantValue ?: 6.0).toFloat().coerceAtLeast(0.5f)

        fun circleRadiusExpressionForPaint(paint: CircleLayerPaint) =
            (paint.circle.radius as? StyleValue.Expression)?.expression

        fun circleRadiusPxForPaint(paint: CircleLayerPaint): Float =
            ((paint.circle.radius.constantValue ?: 6.0).toFloat() * VECTOR_CIRCLE_GL_PIXEL_SCALE)
                .coerceAtLeast(0.5f)

        fun strokeRgbaForPaint(paint: CircleLayerPaint, layerOpacity: Float): FloatArray? {
            val strokeColor = paint.stroke.color.constantValue ?: return null
            val strokeOpacity = (paint.stroke.opacity.constantValue ?: 1.0).toFloat().coerceIn(0f, 1f)
            if (strokeWidthPxForPaint(paint) <= 0f) return null
            val fillOpacity = (paint.fill.opacity.constantValue ?: 1.0).toFloat().coerceIn(0f, 1f)
            val combined = layerOpacity * fillOpacity * strokeOpacity
            if (combined <= 0f) return null
            return floatArrayOf(strokeColor.red, strokeColor.green, strokeColor.blue, strokeColor.alpha * combined)
        }

        // ── GeoJSON source path ───────────────────────────────────────────────
        // Global point datasets (earthquakes, tropical points): one z=0 mesh per data/style
        // revision. Per-visible-tile triangulation reprocessed every feature on every zoom
        // floor change and blocked the GL thread (~2s with 1000 features).
        if (geoJsonSource != null) {
            val rawFeatures = geoJsonSource.data?.features()
            if (rawFeatures.isNullOrEmpty()) {
                (tileLayer?.mapController as? MapboxMapController)?.ensureGeoJsonSourceDataLoaded(geoJsonSource)
                return
            }
            val dynamicMapTime = VectorFeatureDrawFilter.referencesMapTime(layer.id, layer.filter)
            val monotonicMapTime = VectorMapTime.usesMonotonicMapTimeReveal(layer.id, layer.filter)
            val features = rawFeatures.filter {
                if (dynamicMapTime && monotonicMapTime) {
                    VectorFeatureDrawFilter.shouldDrawForGpuMapTimePrep(it, layer.filter, layer.id)
                } else {
                    VectorFeatureDrawFilter.shouldDraw(it, layer.filter, layer.id)
                }
            }
            if (features.isEmpty()) return
            val paint = layer.paint as? CircleLayerPaint ?: return
            val radiusStylePx = circleRadiusStylePxForPaint(paint)
            val radiusExpression = circleRadiusExpressionForPaint(paint)
            val radiusPx = circleRadiusPxForPaint(paint)
            val opacity = paint.opacity.coerceIn(0f, 1f)
            val fillOpacity = (paint.fill.opacity.constantValue ?: 1.0).toFloat().coerceIn(0f, 1f)
            val combinedOpacity = opacity * fillOpacity
            val circleConstColor: Color? = paint.fill.color.constantValue
            val fallbackRgba: FloatArray? = circleConstColor?.let {
                floatArrayOf(it.red, it.green, it.blue, it.alpha * combinedOpacity)
            }
            val colorExpression = (paint.fill.color as? StyleValue.Expression)?.expression
            val fallbackKey = fallbackRgba?.contentHashCode() ?: 0
            val exprKey = colorExpression?.raw?.hashCode() ?: 0
            val radiusExprKey = radiusExpression?.raw?.hashCode() ?: 0
            val radiusKey = radiusPx.toBits()
            val styleKey = 31 * (31 * (31 * fallbackKey + exprKey) + radiusKey) + radiusExprKey
            val dataVersion = geoJsonSource.geoJsonStencilSequence
            // Monotonic map-time keeps one resident mesh; range / complex filters key by visible set.
            val mapTimeKey =
                if (dynamicMapTime && !monotonicMapTime) geoJsonVisibleFeatureSetKey(features) else 0
            val geoTriKey =
                "geojson|${geoJsonSource.id}|$styleKey|$dataVersion|$mapTimeKey|$TRIANGULATION_COLOR_CACHE_VERSION|circle"
            val worldCoord = TileCoord(0, 0, 0)
            val revealKey =
                if (dynamicMapTime && monotonicMapTime) VectorMapTime.mapTimeRevealKey(layer.id, layer.filter) else null
            var raw = triangulationCache[geoTriKey]
            if (raw == null) {
                if (!backgroundExecutor.isShutdown && triangulationInProgress.add(geoTriKey)) {
                    val bgFeatures = features
                    val bgFallback = fallbackRgba
                    val bgExpr = colorExpression
                    val bgRadiusStylePx = radiusStylePx
                    val bgRadiusExpr = radiusExpression
                    val bgRevealKey = revealKey
                    val capturedTileLayer = tileLayer
                    val capturedGeoTriKey = geoTriKey
                    backgroundExecutor.submit {
                        try {
                            val computed = VectorPolygonFillTriangulator.triangulateCirclePointsDetailed(
                                bgFeatures,
                                worldCoord,
                                null,
                                layerFallbackCircleRgba = bgFallback,
                                circleColorExpression = bgExpr,
                                circleRadiusPx = bgRadiusStylePx,
                                circleRadiusExpression = bgRadiusExpr,
                                mapTimeRevealKey = bgRevealKey,
                            )
                            cacheCircleTriangulationWithTimes(capturedGeoTriKey, computed)
                            if (computed.interleaved.isNotEmpty()) {
                                capturedTileLayer?.mapController?.redraw()
                            }
                        } finally {
                            triangulationInProgress.remove(capturedGeoTriKey)
                        }
                    }
                }
                val detailed = VectorPolygonFillTriangulator.triangulateCirclePointsDetailed(
                    features,
                    worldCoord,
                    null,
                    layerFallbackCircleRgba = fallbackRgba,
                    circleColorExpression = colorExpression,
                    circleRadiusPx = radiusStylePx,
                    circleRadiusExpression = radiusExpression,
                    mapTimeRevealKey = revealKey,
                )
                cacheCircleTriangulationWithTimes(geoTriKey, detailed)
                raw = detailed.interleaved
            }
            if (raw.isEmpty()) return
            raw = compactCircleInstancesByMapTime(
                raw,
                circleFeatureTimeCache[geoTriKey],
                dynamicMapTime && monotonicMapTime,
            )
            if (raw.isEmpty()) return
            val interleaved = if (combinedOpacity < 1f) {
                val v = raw.copyOf()
                var i = 5 // alpha is index 5 of [cx,cy,r,g,b,a,radius_scale]
                while (i < v.size) {
                    v[i] *= combinedOpacity
                    i += FLOATS_PER_INSTANCE
                }
                v
            } else {
                raw
            }
            val overscale =
                (if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, worldCoord.z) else 1f)
                    .coerceAtLeast(1f)
            val tileRadiusUv = radiusPx / 512f / overscale
            val strokeRgba = strokeRgbaForPaint(paint, opacity)
            val strokeWidthPx = strokeWidthPxForPaint(paint)
            if (vbo == 0) {
                val h = IntArray(1)
                GLES31.glGenBuffers(1, h, 0)
                vbo = h[0]
            }
            ensureCircleQuadVbo()
            GLES31.glUseProgram(circleGlProgram)
            GLES31.glEnable(GLES31.GL_BLEND)
            GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glColorMask(true, true, true, true)
            // Static per-vertex quad corner (attribute 1, divisor 0) — same buffer for every draw.
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, circleQuadVbo)
            GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, CIRCLE_QUAD_STRIDE_BYTES, 0)
            GLES31.glVertexAttribDivisor(1, 0)
            GLES31.glEnableVertexAttribArray(0)
            GLES31.glEnableVertexAttribArray(1)
            GLES31.glEnableVertexAttribArray(2)
            GLES31.glEnableVertexAttribArray(3)
            val depthWasEnabled = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
            val stencilWasEnabled = GLES31.glIsEnabled(GLES31.GL_STENCIL_TEST)
            val scissorWasEnabled = GLES31.glIsEnabled(GLES31.GL_SCISSOR_TEST)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            if (stencilWasEnabled) GLES31.glDisable(GLES31.GL_STENCIL_TEST)
            if (scissorWasEnabled) GLES31.glDisable(GLES31.GL_SCISSOR_TEST)
            try {
                val requiredBytes = interleaved.size * 4
                if (circleByteBuffer.capacity() < requiredBytes) {
                    circleByteBuffer =
                        ByteBuffer.allocateDirect(requiredBytes + requiredBytes / 2).order(ByteOrder.nativeOrder())
                }
                circleByteBuffer.position(0)
                circleByteBuffer.limit(requiredBytes)
                circleByteBuffer.asFloatBuffer().put(interleaved)
                circleByteBuffer.position(0)
                // Per-point instance data (attributes 0/2/3, divisor 1) — one record per point.
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
                GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, requiredBytes, circleByteBuffer, GLES31.GL_DYNAMIC_DRAW)
                GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 0)
                GLES31.glVertexAttribDivisor(0, 1)
                GLES31.glVertexAttribPointer(2, 4, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 8)
                GLES31.glVertexAttribDivisor(2, 1)
                GLES31.glVertexAttribPointer(3, 1, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 24)
                GLES31.glVertexAttribDivisor(3, 1)
                val tileLocal = FloatArray(16)
                val modelViewMatrixArray = FloatArray(16)
                val mvp = FloatArray(16)
                // Rule: dateline-world-copy. Redraw z=0 GeoJSON mesh for each visible world copy.
                for (drawCoord in GeoJsonWorldCopies.visibleWorldCoords(tileLayer?.mapController)) {
                    Matrix.setIdentityM(tileLocal, 0)
                    Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                    val worldCopyN = powerTableI.getOrElse(drawCoord.z) { 1 shl drawCoord.z }
                    Matrix.translateM(
                        tileLocal,
                        0,
                        drawCoord.x.toFloat() + drawCoord.offset * worldCopyN,
                        drawCoord.y.toFloat(),
                        0f,
                    )
                    Matrix.multiplyMM(modelViewMatrixArray, 0, mvCam, 0, tileLocal, 0)
                    Matrix.multiplyMM(mvp, 0, proj, 0, modelViewMatrixArray, 0)
                    GLES31.glUniformMatrix4fv(uCircleMvpLocation, 1, false, mvp, 0)
                    drawCircleBatch(
                        tileRadiusUv,
                        overscale,
                        strokeWidthPx,
                        strokeRgba,
                        interleaved.size / FLOATS_PER_INSTANCE,
                    )
                }
            } finally {
                if (scissorWasEnabled) GLES31.glEnable(GLES31.GL_SCISSOR_TEST)
                if (stencilWasEnabled) GLES31.glEnable(GLES31.GL_STENCIL_TEST)
                if (depthWasEnabled) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            }
            GLES31.glDisableVertexAttribArray(0)
            GLES31.glDisableVertexAttribArray(1)
            GLES31.glDisableVertexAttribArray(2)
            GLES31.glDisableVertexAttribArray(3)
            // Divisors set above (0/2/3) are shared, non-VAO'd context state — restore the
            // default (per-vertex) rate so other renderers' non-instanced glDrawArrays calls on
            // these same attribute indices aren't silently starved to a single vertex record.
            GLES31.glVertexAttribDivisor(0, 0)
            GLES31.glVertexAttribDivisor(2, 0)
            GLES31.glVertexAttribDivisor(3, 0)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
            GLES31.glUseProgram(0)
            return
        }
        // ── VectorTileSource path ─────────────────────────────────────────────
        // geoJsonSource == null here, so vtsOrNull is guaranteed non-null by the guard above
        val vts = vtsOrNull ?: return
        val tileLayerRef = tileLayer as TileLayer
        val timeSeriesPlayback = vts.isTimeSeriesSource && Timeline.isGloballyPlaying
        val visibleCoords =
            if (timeSeriesPlayback) tileLayerRef.visibleTileCoordsForGlVectorPlayback()
            else tileLayerRef.visibleTileCoordsForMapboxVectorCache()
        val fallbackCoords = if (visibleCoords.isEmpty()) {
            val mapZoom = (mapZoomNow ?: 0f).toDouble()
            val zCandidates = tileLayerRef.glVectorPlaybackFallbackZoomCandidates(mapZoom)
            var candidate: List<TileCoord> = emptyList()
            for (z in zCandidates) {
                val cached = tileLayerRef.cachedTileCoordsWithDataAtZInViewport(vts, z)
                if (cached.isNotEmpty()) {
                    candidate = cached
                    break
                }
            }
            candidate
        } else {
            emptyList()
        }
        val targetZoomFloor = floor((mapZoomNow ?: 0f).toDouble()).toInt()
            .coerceAtLeast(0)
            .coerceAtMost(layer.source.maxZoom.toInt())
        val nowMs = SystemClock.elapsedRealtime()
        val zoomFloorChanged = lastZoomFloor != null && lastZoomFloor != targetZoomFloor
        if (lastZoomFloor == null || zoomFloorChanged) {
            holdLastBatchesUntilMs = nowMs + zoomTransitionHoldMs
            lastZoomFloor = targetZoomFloor
        }
        val zoomTransitionHold = nowMs < holdLastBatchesUntilMs
        val allowStaleTimeFallback = true
        val playbackStable = Timeline.isGloballyPlaying
        if (!playbackStable) {
            gate.lastGloballyInactiveMs = nowMs
        }
        if (gate.wasGloballyPlaying && !playbackStable) {
            gate.playbackWarmupComplete = true
            gate.initialPlaybackWarmupSatisfied = false
            playbackFrozenBatches = emptyList()
            playbackFrozenIntervalMs = null
            gate.warmupTilePrefetchJob?.cancel()
            gate.warmupTilePrefetchJob = null
        }
        val steadyStatePlaybackDraw =
            playbackStable &&
                vts.isTimeSeriesSource &&
                gate.playbackWarmupComplete &&
                gate.initialPlaybackWarmupSatisfied
        if (!steadyStatePlaybackDraw && !playbackStable) {
            gate.lastPlaybackViewportTileKeys = emptySet()
        }
        val canAttemptDraw =
            visibleCoords.isNotEmpty() ||
                fallbackCoords.isNotEmpty() ||
                lastSuccessfulBatches.isNotEmpty() ||
                (playbackStable && gate.playbackStableCoords.isNotEmpty() && nowMs < gate.playbackStableCoordsUntilMs)
        if (!canAttemptDraw) return

        val paint = layer.paint as? CircleLayerPaint ?: return
        val circleStyle = circleTriangulationStyle(paint) ?: return
        // Rule: pruning-to-referenced-keys. Tells the shared tile parser which attribute keys this
        // layer's filter/paint actually read, so it can skip materializing the rest per feature.
        // Cheap (walks a handful of small expression nodes, not per-feature) — fine to redo per draw.
        (layer.source as? VectorTileSource)?.declareNeededPropertyKeys(
            layer.id,
            ExpressionReferencedKeys.collect(layer.filter, circleStyle.circleColorExpression, circleStyle.circleRadiusExpression) +
                CIRCLE_INSPECTOR_PROPERTY_KEYS,
        )
        // Rule: raw-vector-fast-path. Recomputed every draw (cheap — no per-feature cost), so a style
        // or consumer change takes effect on the next tile fetch, same as declareNeededPropertyKeys.
        vts.setRawPathEligible(layer.id, layer.sourceLayer, rawCirclePathEligible(vts, layer, circleStyle))
        val radiusStylePx = circleStyle.circleRadiusStylePx
        val radiusExpression = circleStyle.circleRadiusExpression
        val radiusPx = circleRadiusPxForPaint(paint)
        val opacity = paint.opacity.coerceIn(0f, 1f)
        val fillOpacity = (paint.fill.opacity.constantValue ?: 1.0).toFloat().coerceIn(0f, 1f)
        val combinedOpacity = opacity * fillOpacity
        val fallbackRgba = circleStyle.layerFallbackCircleRgba
        val colorExpression = circleStyle.circleColorExpression
        val styleKey = circleStyle.styleKey

        val liveDrawIntervalMs = vectorTileSourceDrawIntervalMs(tileLayer, vts)
        val drawIntervalMs = liveDrawIntervalMs

        if (playbackStable && !gate.wasGloballyPlaying && vts.isTimeSeriesSource && !gate.initialPlaybackWarmupSatisfied) {
            val playResumeGapMs = nowMs - gate.lastGloballyInactiveMs
            if (playResumeGapMs >= playbackPlayEdgeDebounceMs) {
                pausedBatchCount = lastSuccessfulBatches.size
                playbackFrozenIntervalMs = liveDrawIntervalMs
                playbackFrozenBatches = lastSuccessfulBatches
                gate.playbackWarmupComplete = false
                gate.warmupTilePrefetchJob?.cancel()
                gate.warmupTilePrefetchJob = null
            }
        }
        gate.wasGloballyPlaying = playbackStable

        val strokeRgba = strokeRgbaForPaint(paint, opacity)
        val strokeWidthPx = strokeWidthPxForPaint(paint)

        val projectionMatrix = FloatArray(16)
        val cameraArray = FloatArray(16)
        System.arraycopy(proj, 0, projectionMatrix, 0, 16)
        System.arraycopy(mvCam, 0, cameraArray, 0, 16)

        val tileLocal = FloatArray(16)
        val modelViewMatrixArray = FloatArray(16)
        val mvp = FloatArray(16)

        GLES31.glUseProgram(circleGlProgram)
        GLES31.glEnable(GLES31.GL_BLEND)
        GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
        GLES31.glDisable(GLES31.GL_CULL_FACE)
        GLES31.glColorMask(true, true, true, true)

        if (vbo == 0) {
            val h = IntArray(1)
            GLES31.glGenBuffers(1, h, 0)
            vbo = h[0]
        }
        ensureCircleQuadVbo()
        // Static per-vertex quad corner (attribute 1, divisor 0) — same buffer for every draw.
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, circleQuadVbo)
        GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, CIRCLE_QUAD_STRIDE_BYTES, 0)
        GLES31.glVertexAttribDivisor(1, 0)
        GLES31.glEnableVertexAttribArray(0)
        GLES31.glEnableVertexAttribArray(1)
        GLES31.glEnableVertexAttribArray(2)
        GLES31.glEnableVertexAttribArray(3)

        val depthWasEnabled = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        val stencilWasEnabled = GLES31.glIsEnabled(GLES31.GL_STENCIL_TEST)
        val scissorWasEnabled = GLES31.glIsEnabled(GLES31.GL_SCISSOR_TEST)
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        if (stencilWasEnabled) GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        if (scissorWasEnabled) GLES31.glDisable(GLES31.GL_SCISSOR_TEST)
        try {
            fun drawCirclesForCoord(
                coord: TileCoord,
                interleaved: FloatArray,
                fillRadiusUv: Float,
                overscale: Float,
            ) {
                val requiredBytes = interleaved.size * 4
                if (circleByteBuffer.capacity() < requiredBytes) {
                    circleByteBuffer = ByteBuffer.allocateDirect(requiredBytes + requiredBytes / 2)
                        .order(ByteOrder.nativeOrder())
                }
                circleByteBuffer.position(0)
                circleByteBuffer.limit(requiredBytes)
                circleByteBuffer.asFloatBuffer().put(interleaved)
                circleByteBuffer.position(0)
                // Per-point instance data (attributes 0/2/3, divisor 1) — one record per point.
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
                GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, requiredBytes, circleByteBuffer, GLES31.GL_DYNAMIC_DRAW)
                GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 0)
                GLES31.glVertexAttribDivisor(0, 1)
                GLES31.glVertexAttribPointer(2, 4, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 8)
                GLES31.glVertexAttribDivisor(2, 1)
                GLES31.glVertexAttribPointer(3, 1, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 24)
                GLES31.glVertexAttribDivisor(3, 1)
                Matrix.setIdentityM(tileLocal, 0)
                val overscale = if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, coord.z) else 1f
                Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                // Rule: dateline-world-copy. See VectorFillLayerRenderer.drawInterleavedForCoord's
                // identical fix — must include coord.offset or every world copy of a tile draws at
                // the same screen position, breaking rendering across the antimeridian at wide zoom.
                val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
                Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
                Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
                Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
                GLES31.glUniformMatrix4fv(uCircleMvpLocation, 1, false, mvp, 0)
                drawCircleBatch(
                    fillRadiusUv,
                    overscale.coerceAtLeast(1f),
                    strokeWidthPx,
                    strokeRgba,
                    interleaved.size / FLOATS_PER_INSTANCE,
                )
            }

            /** Rule: zero-copy-gpu-upload (Phase 5). See VectorFillLayerRenderer.drawDirectBufferForCoord's
             * KDoc — same contract, instanced circle-point vertex layout ([CIRCLE_INSTANCE_STRIDE_BYTES]
             * bytes per point). */
            fun drawCirclesDirectBufferForCoord(
                coord: TileCoord,
                buffer: ByteBuffer,
                byteCount: Int,
                fillRadiusUv: Float,
            ) {
                buffer.order(ByteOrder.nativeOrder())
                buffer.position(0)
                buffer.limit(byteCount)
                GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
                GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, byteCount, buffer, GLES31.GL_DYNAMIC_DRAW)
                GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 0)
                GLES31.glVertexAttribDivisor(0, 1)
                GLES31.glVertexAttribPointer(2, 4, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 8)
                GLES31.glVertexAttribDivisor(2, 1)
                GLES31.glVertexAttribPointer(3, 1, GLES31.GL_FLOAT, false, CIRCLE_INSTANCE_STRIDE_BYTES, 24)
                GLES31.glVertexAttribDivisor(3, 1)
                Matrix.setIdentityM(tileLocal, 0)
                val overscale = if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, coord.z) else 1f
                Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                // Rule: dateline-world-copy. See drawCirclesForCoord's identical fix.
                val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
                Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
                Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
                Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
                GLES31.glUniformMatrix4fv(uCircleMvpLocation, 1, false, mvp, 0)
                drawCircleBatch(
                    fillRadiusUv,
                    overscale.coerceAtLeast(1f),
                    strokeWidthPx,
                    strokeRgba,
                    byteCount / CIRCLE_INSTANCE_STRIDE_BYTES,
                )
            }

            fun drawCachedBatches(batches: List<CachedDrawBatch>): Boolean {
                var drewAny = false
                for (batch in batches) {
                    if (batch.interleaved.isEmpty()) continue
                    val batchOverscale =
                        (if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, batch.coord.z) else 1f)
                            .coerceAtLeast(1f)
                    drawCirclesForCoord(
                        batch.coord,
                        batch.interleaved,
                        radiusPx / 512f / batchOverscale,
                        batchOverscale,
                    )
                    drewAny = true
                }
                return drewAny
            }

            // Rule: playback-stale-fallback. See VectorFillLayerRenderer.drawPlaybackFillRefs's KDoc —
            // returns the batches actually drawn (not just a boolean) so the steady-state caller can
            // refresh lastSuccessfulBatches with this frame's fresh content. Legacy-branch callers use
            // `.isNotEmpty()`, an exact match for the old boolean.
            fun drawPlaybackCircleRefs(refs: List<VectorPlaybackMeshRef>): List<CachedDrawBatch> {
                val drawn = ArrayList<CachedDrawBatch>(refs.size)
                for (ref in refs) {
                    // Rule: zero-copy-gpu-upload (Phase 5). See VectorFillLayerRenderer.drawPlaybackFillRefs's
                    // identical branch.
                    if (ref.vertexOpacity >= 1f && !triangulationCache.containsKey(ref.triKey)) {
                        val direct = vts.getCircleTriangulationNativeDirect(ref.triKey)
                        if (direct != null) {
                            try {
                                if (direct.capacity() > 0) {
                                    val batchOverscale =
                                        (if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, ref.coord.z) else 1f)
                                            .coerceAtLeast(1f)
                                    drawCirclesDirectBufferForCoord(
                                        ref.coord,
                                        direct,
                                        direct.capacity(),
                                        radiusPx / 512f / batchOverscale,
                                    )
                                }
                            } finally {
                                vts.releaseCircleTriangulationNativeDirect(ref.triKey)
                            }
                            continue
                        }
                    }
                    val raw = resolveCircleMesh(vts, ref.triKey) ?: continue
                    if (raw.isEmpty()) continue
                    val interleaved =
                        if (ref.vertexOpacity < 1f) applyCircleOpacity(raw, ref.vertexOpacity) else raw
                    val batchOverscale =
                        (if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, ref.coord.z) else 1f)
                            .coerceAtLeast(1f)
                    drawCirclesForCoord(
                        ref.coord,
                        interleaved,
                        radiusPx / 512f / batchOverscale,
                        batchOverscale,
                    )
                    drawn.add(CachedDrawBatch(ref.coord, interleaved))
                }
                return drawn
            }

            fun circleRefsForPlayback(intervalMs: Long?): List<VectorPlaybackMeshRef> = gate.refsForInterval(intervalMs)

            fun drawCoords(
                coords: List<TileCoord>,
                emitGeometry: Boolean = true,
                intervalForDraw: Long? = drawIntervalMs,
            ): DrawResult {
                var drawnCount = 0
                var resolvedCount = 0
                val captured = ArrayList<CachedDrawBatch>()
                val resolveIntervalMs = intervalForDraw?.let { phaseMs ->
                    if (vts.isTimeSeriesSource) vts.snappedTimeSeriesIntervalMs(phaseMs) else phaseMs
                }
                val exactInterval = !Timeline.isGloballyPlaying && !vts.isTimeSeriesSource
                for (coord in coords) {
                    val cached = vts.findCachedVectorTileForNominalZxy(
                        coord.z, coord.x, coord.y, allowStaleTimeFallback,
                    ) ?: continue
                    val data = resolveVectorTileData(cached.data, resolveIntervalMs, exactInterval = exactInterval)
                        as? VectorData ?: continue
                    resolvedCount++
                    val layerFilter = (tileLayer as? VectorTileLayer)?.filter
                    // Rule: raw-circle-fast-path. data.rawFeatures != null means parseVectorTile
                    // produced this VectorData in raw mode (data.features stays empty in that case) —
                    // this is the one flag every branch below reads, never a second bookkeeping map.
                    val rawFeatures = data.rawFeatures
                    val isRawMode = rawFeatures != null
                    val drawableFeatures = if (isRawMode) emptyList() else data.features.filter {
                        VectorFeatureDrawFilter.shouldDraw(it, layerFilter, layer.id)
                    }
                    val rawDrawableFeatures = if (isRawMode) {
                        rawFeatures!!.filter {
                            @Suppress("UNCHECKED_CAST")
                            VectorPolygonFillTriangulator.rawFeatureVisible(nestedDictionary(it.attributes as Map<String, Any>))
                        }
                    } else {
                        emptyList()
                    }
                    val triKey = circleTriangulationKey(coord, data, layer.sourceLayer, styleKey)
                    var raw = resolveCircleMesh(vts, triKey)
                    if (raw == null) {
                        if (!data.hasCpuGeometry()) {
                            if (data.isVacuousParse()) data.markLayerMeshReady(vts, layer.id)
                            continue
                        }
                        if (isRawMode) {
                            if (rawDrawableFeatures.isEmpty()) {
                                data.markLayerMeshReady(vts, layer.id)
                                continue
                            }
                        } else if (drawableFeatures.isEmpty()) {
                            data.markLayerMeshReady(vts, layer.id)
                            continue
                        }
                        if (!backgroundExecutor.isShutdown && triangulationInProgress.add(triKey)) {
                            val bgCoord = coord
                            val bgSourceLayer = layer.sourceLayer
                            val bgStyle = circleStyle
                            if (isRawMode) {
                                val bgRawFeatures = rawFeatures!!
                                backgroundExecutor.submit {
                                    try {
                                        val computed = data.withGpuUpload {
                                            VectorPolygonFillTriangulator.triangulateCirclePointsRaw(
                                                bgRawFeatures,
                                                bgCoord,
                                                layerFallbackCircleRgba = bgStyle.layerFallbackCircleRgba,
                                                circleColorExpression = bgStyle.circleColorExpression,
                                                circleRadiusPx = bgStyle.circleRadiusStylePx,
                                                circleRadiusExpression = bgStyle.circleRadiusExpression,
                                            )
                                        }
                                        cacheCircleTriangulation(vts, triKey, computed)
                                        data.markLayerMeshReady(vts, layer.id)
                                        (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                                    } finally {
                                        triangulationInProgress.remove(triKey)
                                    }
                                }
                            } else {
                                val bgFeatures = drawableFeatures
                                backgroundExecutor.submit {
                                    try {
                                        val computed = data.withGpuUpload {
                                            VectorPolygonFillTriangulator.triangulateCirclePoints(
                                                bgFeatures,
                                                bgCoord,
                                                bgSourceLayer,
                                                layerFallbackCircleRgba = bgStyle.layerFallbackCircleRgba,
                                                circleColorExpression = bgStyle.circleColorExpression,
                                                circleRadiusPx = bgStyle.circleRadiusStylePx,
                                                circleRadiusExpression = bgStyle.circleRadiusExpression,
                                            )
                                        }
                                        cacheCircleTriangulation(vts, triKey, computed)
                                        data.markLayerMeshReady(vts, layer.id)
                                        (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                                    } finally {
                                        triangulationInProgress.remove(triKey)
                                    }
                                }
                            }
                        }
                        if (!playbackStable || !vts.isTimeSeriesSource) {
                            raw = if (isRawMode) {
                                VectorPolygonFillTriangulator.triangulateCirclePointsRaw(
                                    rawFeatures!!,
                                    coord,
                                    layerFallbackCircleRgba = fallbackRgba,
                                    circleColorExpression = colorExpression,
                                    circleRadiusPx = radiusStylePx,
                                    circleRadiusExpression = radiusExpression,
                                )
                            } else {
                                VectorPolygonFillTriangulator.triangulateCirclePoints(
                                    drawableFeatures,
                                    coord,
                                    layer.sourceLayer,
                                    layerFallbackCircleRgba = fallbackRgba,
                                    circleColorExpression = colorExpression,
                                    circleRadiusPx = radiusStylePx,
                                    circleRadiusExpression = radiusExpression,
                                )
                            }
                            cacheCircleTriangulation(vts, triKey, raw)
                        } else {
                            continue
                        }
                    }
                    if (raw.isEmpty()) {
                        data.markLayerMeshReady(vts, layer.id)
                        continue
                    }
                    data.markLayerMeshReady(vts, layer.id)
                    val tileOverscale =
                        (if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, coord.z) else 1f)
                            .coerceAtLeast(1f)
                    val tileRadiusUv = radiusPx / 512f / tileOverscale
                    val interleaved = if (combinedOpacity < 1f) applyCircleOpacity(raw, combinedOpacity) else raw
                    if (emitGeometry) {
                        drawCirclesForCoord(coord, interleaved, tileRadiusUv, tileOverscale)
                    }
                    drawnCount++
                    captured.add(CachedDrawBatch(coord, interleaved))
                }
                return DrawResult(drawnCount, resolvedCount, captured)
            }

            val primaryCoords = run {
                if (steadyStatePlaybackDraw) {
                    visibleCoords.ifEmpty { fallbackCoords }
                } else if (playbackStable) {
                    if (visibleCoords.isNotEmpty()) {
                        val visibleKeys = visibleCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
                        val stableKeys = gate.playbackStableCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
                        val viewportShifted =
                            gate.playbackStableCoords.isEmpty() || visibleKeys != stableKeys
                        val shouldRefreshStable =
                            gate.playbackStableCoords.isEmpty() ||
                                nowMs >= gate.playbackStableCoordsUntilMs ||
                                visibleCoords.size > gate.playbackStableCoords.size ||
                                viewportShifted
                        if (shouldRefreshStable) {
                            gate.playbackStableCoords = visibleCoords
                            gate.playbackStableCoordsUntilMs = nowMs + playbackCoordsHoldMs
                        }
                        if (!viewportShifted &&
                            gate.playbackStableCoords.isNotEmpty() &&
                            visibleCoords.size < gate.playbackStableCoords.size &&
                            nowMs < gate.playbackStableCoordsUntilMs
                        ) {
                            gate.playbackStableCoords
                        } else {
                            visibleCoords
                        }
                    } else if (gate.playbackStableCoords.isNotEmpty() && nowMs < gate.playbackStableCoordsUntilMs) {
                        gate.playbackStableCoords
                    } else if (fallbackCoords.isNotEmpty()) {
                        fallbackCoords
                    } else {
                        emptyList()
                    }
                } else if (visibleCoords.isNotEmpty()) {
                    visibleCoords
                } else {
                    fallbackCoords
                }
            }

            val gateCoords = gate.playbackGateCoords(layer, primaryCoords, fallbackCoords)
            if (playbackStable && vts.isTimeSeriesSource && gateCoords.isNotEmpty()) {
                gate.scheduleFullTimelineMvtPrefetch(layer, vts, gateCoords)
                gate.schedulePlaybackFramePreparation(
                    layer = layer,
                    vts = vts,
                    coords = gateCoords,
                    buildRefs = { coords, intervalMs ->
                        buildPlaybackCircleRefsForInterval(
                            vts = vts,
                            layer = layer,
                            coords = coords,
                            intervalMs = intervalMs,
                            circleStyle = circleStyle,
                            opacity = combinedOpacity,
                        )
                    },
                    isDrawable = { coord, snappedMs ->
                        isPlaybackPhaseDrawable(vts, coord, snappedMs, circleStyle.styleKey, layer.sourceLayer, layer)
                    },
                    phaseStoreBlockers = { coords, snappedMs ->
                        phaseStoreBlockers(vts, coords, snappedMs, circleStyle.styleKey, layer.sourceLayer, layer)
                    },
                    gateBlockers = { coords ->
                        summarizePlaybackGateBlockers(vts, coords, circleStyle.styleKey, layer.sourceLayer, layer)
                    },
                    onRepaintNeeded = {
                        (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                    },
                )
            }

            if (playbackStable && vts.isTimeSeriesSource && !gate.playbackWarmupComplete && !gate.initialPlaybackWarmupSatisfied) {
                Timeline.setGlVectorFillLayerPlaybackReady(layer.id, false)
                val warmupCoords = gateCoords
                if (warmupCoords.isEmpty()) {
                    // Viewport tiles are not known yet — keep this layer awaiting so the play-press
                    // indicator stays up. Claiming ready here dismissed the spinner on the first
                    // frames, then intervals streamed in with no load UI.
                    return
                } else if (gate.playbackGateAnchorPhaseA < 0) {
                    val allPhases = gate.playbackGateReadyPhaseEpochMs(vts)
                    ensureTimeSeriesWarmupTriangulation(
                        vts = vts,
                        layer = layer,
                        coords = warmupCoords,
                        circleStyle = circleStyle,
                        prefetchPhases = allPhases,
                        requestMissingTiles = true,
                    )
                    val isDrawable = { coord: TileCoord, snappedMs: Long ->
                        isPlaybackPhaseDrawable(vts, coord, snappedMs, circleStyle.styleKey, layer.sourceLayer, layer)
                    }
                    if (gate.completePlaybackGateIfReady(layer, vts, warmupCoords, isDrawable)) {
                        // gate opened
                    } else {
                        val frozen = playbackFrozenBatches.ifEmpty { lastSuccessfulBatches }
                        if (frozen.isNotEmpty()) {
                            drawCachedBatches(frozen)
                        }
                        return
                    }
                }
            }

            if (steadyStatePlaybackDraw && drawIntervalMs != null) {
                val snappedDraw = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                // Rule: steady-state-redundant-rebuild + playback-stale-fallback. See
                // VectorFillLayerRenderer's identical fix/KDoc — skip rebuilding when the interval
                // hasn't changed, and refresh lastSuccessfulBatches on every successful steady-state
                // draw so the empty-lookup fallback self-heals instead of freezing at whenever
                // steady-state was first entered (the "layer doesn't animate after a pan" bug class).
                if (snappedDraw == lastSteadyStateIntervalMs && lastSuccessfulBatches.isNotEmpty()) {
                    drawCachedBatches(lastSuccessfulBatches)
                } else {
                    val prebuilt = circleRefsForPlayback(snappedDraw)
                    val freshBatches = if (prebuilt.isNotEmpty()) drawPlaybackCircleRefs(prebuilt) else emptyList()
                    if (freshBatches.isNotEmpty()) {
                        lastSuccessfulBatches = freshBatches
                        // Rule: steady-state-partial-resolve. Only lock in the skip-rebuild fast path
                        // when every ref resolved — a partial resolve must keep retrying next frame
                        // instead of freezing the gap for the rest of this interval's phase duration.
                        if (freshBatches.size >= prebuilt.size) {
                            lastSteadyStateIntervalMs = snappedDraw
                        }
                    } else if (lastSuccessfulBatches.isNotEmpty()) {
                        drawCachedBatches(lastSuccessfulBatches)
                    }
                }
            } else {
            var drew = false
            val timeSeriesPlaying = playbackStable && vts.isTimeSeriesSource
            if (timeSeriesPlaying && gate.playbackWarmupComplete && drawIntervalMs != null) {
                val snappedDraw = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                val holdCoords = primaryCoords.ifEmpty { fallbackCoords }
                if (gate.isIntervalReadyForPlaybackDisplay(
                        vts,
                        holdCoords,
                        drawIntervalMs,
                        isDrawable = { coord, snappedMs ->
                            isPlaybackPhaseDrawable(vts, coord, snappedMs, styleKey, layer.sourceLayer, layer)
                        },
                    )
                ) {
                    val prebuilt = circleRefsForPlayback(snappedDraw)
                    if (prebuilt.isNotEmpty()) {
                        drew = drawPlaybackCircleRefs(prebuilt).isNotEmpty()
                        if (drew) {
                            lastSuccessfulDrawIntervalMs = snappedDraw
                        }
                    }
                }
            }
            if (!drew && !(timeSeriesPlaying && gate.initialPlaybackWarmupSatisfied)) {
            // Rule: single-interval-draw. drawCoords() below only resolves/caches batches now
            // (emitGeometry = false) — the actual GL draw call happens exactly once, for whichever
            // one batch set (new partial/full result, stale cached batch, or held playback refs) is
            // chosen below. Previously drawCoords() emitted geometry eagerly while iterating, so a
            // partially-resolved new interval was already drawn to the GPU before the coverage check
            // decided to *also* fall back to redrawing the stale cached batch — showing two different
            // time intervals' circles in the same frame during a phase transition.
            val primaryResult = drawCoords(primaryCoords, emitGeometry = false)
            val primaryFullCoverage =
                primaryResult.totalCount > 0 && primaryResult.drawnCount == primaryResult.totalCount
            val primaryCoverage =
                if (primaryResult.totalCount > 0) primaryResult.drawnCount.toFloat() / primaryResult.totalCount.toFloat() else 0f
            val minPromotionCount = maxOf(lastSuccessfulBatches.size, pausedBatchCount).coerceAtLeast(1)
            val promotePrimary = primaryResult.drawnCount > 0 && (
                (!playbackStable && (lastSuccessfulBatches.isEmpty() || primaryFullCoverage || primaryCoverage >= minPromotionCoverage || !zoomTransitionHold)) ||
                    (timeSeriesPlaying && gate.initialPlaybackWarmupSatisfied && primaryFullCoverage) ||
                    (timeSeriesPlaying && !gate.initialPlaybackWarmupSatisfied && primaryFullCoverage) ||
                    (playbackStable && !vts.isTimeSeriesSource && primaryResult.drawnCount >= minPromotionCount)
                )
            val hasPrimaryResult = primaryResult.drawnCount > 0
            drew = false
            if (promotePrimary && primaryResult.batches.isNotEmpty()) {
                lastSuccessfulBatches = primaryResult.batches
                lastSuccessfulDrawIntervalMs = drawIntervalMs?.let { vts.snappedTimeSeriesIntervalMs(it) }
                drew = drawCachedBatches(primaryResult.batches)
            } else if (playbackStable && lastSuccessfulBatches.isNotEmpty() &&
                !(timeSeriesPlaying && gate.initialPlaybackWarmupSatisfied && hasPrimaryResult)
            ) {
                drew = drawCachedBatches(lastSuccessfulBatches)
            } else if (!hasPrimaryResult && lastSuccessfulBatches.isNotEmpty()) {
                drew = drawCachedBatches(lastSuccessfulBatches)
            } else if (playbackStable && !hasPrimaryResult && drawIntervalMs != null) {
                val snappedHold = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                val held = circleRefsForPlayback(snappedHold)
                if (held.isNotEmpty()) {
                    drew = drawPlaybackCircleRefs(held).isNotEmpty()
                    lastSuccessfulDrawIntervalMs = snappedHold
                }
            } else if (timeSeriesPlaying && gate.initialPlaybackWarmupSatisfied && lastSuccessfulBatches.isNotEmpty()) {
                drew = drawCachedBatches(lastSuccessfulBatches)
            } else if (hasPrimaryResult) {
                // Partial new-interval coverage with nothing better (no stale batch, no held refs) to
                // show instead — draw what resolved rather than nothing.
                drew = drawCachedBatches(primaryResult.batches)
            }
            if (!drew && fallbackCoords.isNotEmpty() && fallbackCoords !== primaryCoords &&
                !(timeSeriesPlaying && gate.initialPlaybackWarmupSatisfied)
            ) {
                val fallbackResult = drawCoords(fallbackCoords, emitGeometry = false)
                val fallbackFullCoverage =
                    fallbackResult.totalCount > 0 && fallbackResult.drawnCount == fallbackResult.totalCount
                val fallbackCoverage =
                    if (fallbackResult.totalCount > 0) fallbackResult.drawnCount.toFloat() / fallbackResult.totalCount.toFloat() else 0f
                val promoteFallback = fallbackResult.drawnCount > 0 && (
                    (!playbackStable && (lastSuccessfulBatches.isEmpty() || fallbackFullCoverage || fallbackCoverage >= minPromotionCoverage || !zoomTransitionHold)) ||
                        (timeSeriesPlaying && gate.initialPlaybackWarmupSatisfied && fallbackFullCoverage) ||
                        (timeSeriesPlaying && !gate.initialPlaybackWarmupSatisfied && fallbackFullCoverage) ||
                        (playbackStable && !vts.isTimeSeriesSource && fallbackResult.drawnCount >= minPromotionCount)
                    )
                val fallbackHasResult = fallbackResult.drawnCount > 0
                drew = if (promoteFallback && fallbackResult.batches.isNotEmpty()) {
                    lastSuccessfulBatches = fallbackResult.batches
                    lastSuccessfulDrawIntervalMs = drawIntervalMs?.let { vts.snappedTimeSeriesIntervalMs(it) }
                    drawCachedBatches(fallbackResult.batches)
                } else if (!fallbackHasResult && lastSuccessfulBatches.isNotEmpty()) {
                    drawCachedBatches(lastSuccessfulBatches)
                } else if (fallbackHasResult) {
                    drawCachedBatches(fallbackResult.batches)
                } else {
                    false
                }
            }
            if (!drew && lastSuccessfulBatches.isNotEmpty()) {
                drawCachedBatches(lastSuccessfulBatches)
            }
            }
            }
        } finally {
            if (scissorWasEnabled) GLES31.glEnable(GLES31.GL_SCISSOR_TEST)
            if (stencilWasEnabled) GLES31.glEnable(GLES31.GL_STENCIL_TEST)
            if (depthWasEnabled) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            // Must live in this finally, not after it: an early `return` from inside the try block
            // (e.g. the playback-gate-not-ready branch above) would otherwise skip this cleanup on
            // that frame, leaving attributes 0/2/3's divisor stuck at 1 — corrupting any other
            // renderer's non-instanced glDrawArrays on those shared (non-VAO'd) attribute indices
            // until a later frame happens to take the non-early-return path. That intermittent,
            // frame-dependent corruption is what caused fill/outline flicker during timeline playback.
            GLES31.glDisableVertexAttribArray(0)
            GLES31.glDisableVertexAttribArray(1)
            GLES31.glDisableVertexAttribArray(2)
            GLES31.glDisableVertexAttribArray(3)
            GLES31.glVertexAttribDivisor(0, 0)
            GLES31.glVertexAttribDivisor(2, 0)
            GLES31.glVertexAttribDivisor(3, 0)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
            GLES31.glUseProgram(0)
        }
    }

    private data class CircleTriangulationStyle(
        val layerFallbackCircleRgba: FloatArray?,
        val circleColorExpression: Expression?,
        val circleRadiusStylePx: Float,
        val circleRadiusExpression: Expression?,
        val styleKey: Int,
    )

    private fun circleTriangulationStyle(paint: CircleLayerPaint): CircleTriangulationStyle? {
        val opacity = paint.opacity.coerceIn(0f, 1f)
        val fillOpacity = (paint.fill.opacity.constantValue ?: 1.0).toFloat().coerceIn(0f, 1f)
        val combinedOpacity = opacity * fillOpacity
        val circleConstColor: Color? = paint.fill.color.constantValue
        val fallbackRgba: FloatArray? = circleConstColor?.let {
            floatArrayOf(it.red, it.green, it.blue, it.alpha * combinedOpacity)
        }
        val colorExpression = (paint.fill.color as? StyleValue.Expression)?.expression
        val radiusStylePx = (paint.circle.radius.constantValue ?: 6.0).toFloat().coerceAtLeast(0.5f)
        val radiusExpression = (paint.circle.radius as? StyleValue.Expression)?.expression
        val radiusPx =
            ((paint.circle.radius.constantValue ?: 6.0).toFloat() * VECTOR_CIRCLE_GL_PIXEL_SCALE)
                .coerceAtLeast(0.5f)
        val fallbackKey = fallbackRgba?.contentHashCode() ?: 0
        val exprKey = colorExpression?.raw?.hashCode() ?: 0
        val radiusExprKey = radiusExpression?.raw?.hashCode() ?: 0
        val radiusKey = radiusPx.toBits()
        val styleKey = 31 * (31 * (31 * fallbackKey + exprKey) + radiusKey) + radiusExprKey
        return CircleTriangulationStyle(
            layerFallbackCircleRgba = fallbackRgba,
            circleColorExpression = colorExpression,
            circleRadiusStylePx = radiusStylePx,
            circleRadiusExpression = radiusExpression,
            styleKey = styleKey,
        )
    }

    /**
     * Rule: raw-vector-fast-path. True only when it's safe to declare this circle layer eligible via
     * [VectorTileSource.setRawPathEligible]: kept deliberately conservative (still requires this
     * circle layer to be the source's sole consumer, `consumerCount == 1`) even though
     * [VectorTileSource.rawPathEligibleForLayer] now generalizes to "every attached consumer agrees"
     * for shared sources (e.g. alerts fill+outline) — Circle's own gate is unchanged from before that
     * generalization, so this stays a strict subset of what's now possible rather than a behavior
     * change. Its resolved paint must also use only expression ops [VectorCircleRawStyleEval] can
     * evaluate off raw MVT attributes. The layer's *effective* filter must also be null, since raw
     * mode only replicates the MVT `visible` check (see
     * [VectorPolygonFillTriangulator.rawFeatureVisible]), not the full
     * [VectorFeatureDrawFilter.shouldDraw] pipeline (filter flatten -> layer-id defaults -> stencil
     * mask -> tropical special-case).
     */
    private fun rawCirclePathEligible(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        circleStyle: CircleTriangulationStyle,
    ): Boolean = resolveRawCirclePathEligible(
        consumerCount = vts.consumers.size,
        layerId = layer.id,
        filter = layer.filter,
        circleColorExpression = circleStyle.circleColorExpression,
        circleRadiusExpression = circleStyle.circleRadiusExpression,
    )



    private fun applyCircleOpacity(interleaved: FloatArray, opacity: Float): FloatArray {
        if (opacity >= 1f) return interleaved
        val v = interleaved.copyOf(interleaved.size)
        var i = 5 // alpha is index 5 of [cx,cy,r,g,b,a,radius_scale]
        while (i < v.size) {
            v[i] *= opacity
            i += FLOATS_PER_INSTANCE
        }
        return v
    }

    private fun circleTriangulationKey(
        coord: TileCoord,
        data: VectorData,
        sourceLayer: String?,
        styleKey: Int,
    ): String {
        val (meshFp, modeTag) = data.meshModeFingerprint(sourceLayer)
        return "${coord.z}/${coord.x}/${coord.y}|$sourceLayer|$styleKey|$TRIANGULATION_COLOR_CACHE_VERSION|$modeTag|$meshFp|circle"
    }

    private fun resolveCircleMesh(vts: VectorTileSource, triKey: String): FloatArray? {
        if (triangulationCache.containsKey(triKey)) return triangulationCache[triKey]
        vts.getCircleTriangulationNative(triKey)?.let { native ->
            triangulationCache[triKey] = native
            return native
        }
        return null
    }


    // allTimelinePhaseEpochMs, phasesForPlaybackFramePrep, scheduleFullTimelineMvtPrefetch,
    // playbackGateCoords, completePlaybackGateIfReady, isPlaybackTimelineFullyPrimed: moved to
    // VectorPlaybackGateController (rule: shared-playback-gate) — called via `gate.*` from draw().

    // prefetchPlaybackTilesWave, prefetchPlaybackNativeParseWave, countUnparsedNativeMvt,
    // ensurePlaybackPhaseDataReady, allViewportPhasesDataResolved, playbackPrefetchPhaseEpochMs:
    // moved to VectorPlaybackGateController (rule: shared-playback-gate).
    // ensureCirclePhaseDataParsed: moved as the generic gate.ensurePhaseDataParsed.

    private fun phaseStoreBlockers(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        snappedMs: Long,
        styleKey: Int,
        sourceLayer: String?,
        layer: VectorTileLayer,
    ): List<String> =
        coords.mapNotNull { coord ->
            when (
                playbackPhaseDrawableBlockReason(
                    vts,
                    coord,
                    snappedMs,
                    styleKey,
                    sourceLayer,
                    layer,
                )
            ) {
                PlaybackDrawableBlockReason.READY -> null
                PlaybackDrawableBlockReason.DOWNLOADING ->
                    "${coord.z}/${coord.x}/${coord.y} downloading"
                PlaybackDrawableBlockReason.NO_INTERVAL ->
                    "${coord.z}/${coord.x}/${coord.y} no interval"
                PlaybackDrawableBlockReason.NO_DATA ->
                    "${coord.z}/${coord.x}/${coord.y} no data"
                PlaybackDrawableBlockReason.NO_MESH ->
                    "${coord.z}/${coord.x}/${coord.y} no mesh"
            }
        }

    private fun vectorDataForSnappedPhase(
        vts: VectorTileSource,
        tilePayload: Any?,
        phaseMs: Long,
    ): VectorData? {
        val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
        return resolveVectorTileData(tilePayload, snappedMs, exactInterval = true) as? VectorData
    }

    private fun cacheCircleTriangulation(vts: VectorTileSource, triKey: String, computed: FloatArray) {
        triangulationCache[triKey] = computed
        if (computed.isNotEmpty()) {
            vts.putCircleTriangulationNative(triKey, computed)
            trimTriangulationCacheIfNeeded()
        }
    }

    private fun triangulateCircleMeshForPlayback(
        vts: VectorTileSource,
        triKey: String,
        data: VectorData,
        features: List<com.mapbox.geojson.Feature>,
        coord: TileCoord,
        sourceLayer: String?,
        circleStyle: CircleTriangulationStyle,
        layerId: String? = null,
    ): FloatArray {
        resolveCircleMesh(vts, triKey)?.let {
            data.markLayerMeshReady(vts, layerId)
            return it
        }
        return data.withGpuUpload {
            val computed = VectorPolygonFillTriangulator.triangulateCirclePoints(
                features,
                coord,
                sourceLayer,
                layerFallbackCircleRgba = circleStyle.layerFallbackCircleRgba,
                circleColorExpression = circleStyle.circleColorExpression,
                circleRadiusPx = circleStyle.circleRadiusStylePx,
                circleRadiusExpression = circleStyle.circleRadiusExpression,
            )
            cacheCircleTriangulation(vts, triKey, computed)
            computed
        }.also { data.markLayerMeshReady(vts, layerId) }
    }

    /** [triangulateCircleMeshForPlayback]'s raw-circle-fast-path counterpart (rule: raw-circle-fast-path). */
    private fun triangulateCircleMeshForPlaybackRaw(
        vts: VectorTileSource,
        triKey: String,
        data: VectorData,
        rawFeatures: List<MvtFeature>,
        coord: TileCoord,
        circleStyle: CircleTriangulationStyle,
        layerId: String? = null,
    ): FloatArray {
        resolveCircleMesh(vts, triKey)?.let {
            data.markLayerMeshReady(vts, layerId)
            return it
        }
        return data.withGpuUpload {
            val computed = VectorPolygonFillTriangulator.triangulateCirclePointsRaw(
                rawFeatures,
                coord,
                layerFallbackCircleRgba = circleStyle.layerFallbackCircleRgba,
                circleColorExpression = circleStyle.circleColorExpression,
                circleRadiusPx = circleStyle.circleRadiusStylePx,
                circleRadiusExpression = circleStyle.circleRadiusExpression,
            )
            cacheCircleTriangulation(vts, triKey, computed)
            computed
        }.also { data.markLayerMeshReady(vts, layerId) }
    }

    private suspend fun buildPlaybackCircleRefsForInterval(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        coords: List<TileCoord>,
        intervalMs: Long,
        circleStyle: CircleTriangulationStyle,
        opacity: Float,
    ): List<VectorPlaybackMeshRef> {
        if (coords.isEmpty()) return emptyList()
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        return coroutineScope {
            coords.map { coord ->
                async(Dispatchers.Default) {
                    if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) return@async null
                    gate.ensurePhaseDataParsed(vts, coord, snappedMs)
                    val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
                        ?: return@async null
                    var data = vectorDataForSnappedPhase(vts, cached.data, snappedMs)
                        ?: vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs)
                        ?: return@async null
                    if (data.isVacuousParse()) {
                        data.markLayerMeshReady(vts, layer.id)
                        return@async null
                    }
                    var triKey = circleTriangulationKey(coord, data, layer.sourceLayer, circleStyle.styleKey)
                    if (!data.hasCpuGeometry() && data.cpuGeometryReleased && resolveCircleMesh(vts, triKey) == null) {
                        data = vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs) ?: return@async null
                        if (data.isVacuousParse()) {
                            data.markLayerMeshReady(vts, layer.id)
                            return@async null
                        }
                        triKey = circleTriangulationKey(coord, data, layer.sourceLayer, circleStyle.styleKey)
                    }
                    val rawFeatures = data.rawFeatures
                    val raw = if (rawFeatures != null) {
                        if (rawPhaseVacuouslyReady(rawFeatures)) {
                            data.markLayerMeshReady(vts, layer.id)
                            return@async null
                        }
                        triangulateCircleMeshForPlaybackRaw(
                            vts = vts,
                            triKey = triKey,
                            data = data,
                            rawFeatures = rawFeatures,
                            coord = coord,
                            circleStyle = circleStyle,
                            layerId = layer.id,
                        )
                    } else {
                        if (!data.hasCpuGeometry() && resolveCircleMesh(vts, triKey) != null) {
                            data.markLayerMeshReady(vts, layer.id)
                            resolveCircleMesh(vts, triKey)!!
                        } else {
                            val drawableFeatures =
                                data.features.filter {
                                    VectorFeatureDrawFilter.shouldDraw(
                                        it,
                                        layer.filter,
                                        layer.id,
                                        mapTimeMs = snappedMs,
                                    )
                                }
                            if (drawableFeatures.isEmpty()) {
                                data.markLayerMeshReady(vts, layer.id)
                                return@async null
                            }
                            triangulateCircleMeshForPlayback(
                                vts = vts,
                                triKey = triKey,
                                data = data,
                                features = drawableFeatures,
                                coord = coord,
                                sourceLayer = layer.sourceLayer,
                                circleStyle = circleStyle,
                                layerId = layer.id,
                            )
                        }
                    }
                    if (raw.isEmpty()) return@async null
                    VectorPlaybackMeshRef(coord, triKey, opacity)
                }
            }.awaitAll().filterNotNull()
        }
    }

    private fun isPlaybackPhaseDrawable(
        vts: VectorTileSource,
        coord: TileCoord,
        phaseMs: Long,
        styleKey: Int,
        sourceLayer: String?,
        layer: VectorTileLayer? = null,
    ): Boolean {
        val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
        if (vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs)) return false
        if (vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, snappedMs)) {
            val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
            val loadedData = cached?.let { vectorDataForSnappedPhase(vts, it.data, snappedMs) }
            val loadedRawFeatures = loadedData?.rawFeatures
            if (loadedRawFeatures != null) {
                if (rawPhaseVacuouslyReady(loadedRawFeatures)) return true
            } else if (loadedData != null && loadedData.isVacuousParse()) {
                return true
            }
        }
        if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) return false
        val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
        val data = cached?.let { vectorDataForSnappedPhase(vts, it.data, snappedMs) }
        if (data != null) {
            // Rule: raw-circle-fast-path. data.rawFeatures != null is the single flag this whole
            // gate-hold state machine branches on — same object, same playbackCircleRefsByIntervalMs
            // map as the Feature path, just a different "is there anything to draw" / triangulate call.
            val rawFeatures = data.rawFeatures
            if (rawFeatures != null) {
                if (rawPhaseVacuouslyReady(rawFeatures)) return true
            } else if (data.isVacuousParse()) {
                return true
            } else if (layer != null && data.hasCpuGeometry()) {
                val anyDrawable =
                    data.features.any { feature ->
                        VectorFeatureDrawFilter.shouldDraw(
                            feature,
                            layer.filter,
                            layer.id,
                            mapTimeMs = snappedMs,
                        )
                    }
                if (!anyDrawable) return true
            }
            val triKey = circleTriangulationKey(coord, data, sourceLayer, styleKey)
            if (resolveCircleMesh(vts, triKey) != null) return true
            if (triangulationCache.containsKey(triKey) || vts.hasCircleTriangulationNative(triKey)) return true
        }
        val prefix = "${coord.z}/${coord.x}/${coord.y}|${sourceLayer ?: ""}|$styleKey|"
        return triangulationInProgress.any { it.startsWith(prefix) }
    }

    private enum class PlaybackDrawableBlockReason {
        READY,
        DOWNLOADING,
        NO_INTERVAL,
        NO_DATA,
        NO_MESH,
    }

    private fun playbackPhaseDrawableBlockReason(
        vts: VectorTileSource,
        coord: TileCoord,
        phaseMs: Long,
        styleKey: Int,
        sourceLayer: String?,
        layer: VectorTileLayer?,
    ): PlaybackDrawableBlockReason {
        if (isPlaybackPhaseDrawable(vts, coord, phaseMs, styleKey, sourceLayer, layer)) {
            return PlaybackDrawableBlockReason.READY
        }
        val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
        if (vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, snappedMs)) {
            return PlaybackDrawableBlockReason.DOWNLOADING
        }
        if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) {
            return PlaybackDrawableBlockReason.NO_INTERVAL
        }
        val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
        val data = cached?.let { vectorDataForSnappedPhase(vts, it.data, snappedMs) }
            ?: return PlaybackDrawableBlockReason.NO_DATA
        val rawFeatures = data.rawFeatures
        val vacuouslyReady = if (rawFeatures != null) rawPhaseVacuouslyReady(rawFeatures) else data.features.isEmpty()
        if (vacuouslyReady) return PlaybackDrawableBlockReason.READY
        return PlaybackDrawableBlockReason.NO_MESH
    }

    private fun summarizePlaybackGateBlockers(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        styleKey: Int,
        sourceLayer: String?,
        layer: VectorTileLayer,
    ): List<String> {
        val allPhases = gate.allTimelinePhaseEpochMs(vts)
        val blockers = ArrayList<String>(8)
        for (snappedMs in allPhases) {
            if (!gate.refsByIntervalMs.containsKey(snappedMs)) {
                val coordBlockers = phaseStoreBlockers(
                    vts,
                    coords,
                    snappedMs,
                    styleKey,
                    sourceLayer,
                    layer,
                )
                if (coordBlockers.isNotEmpty()) {
                    blockers.add("phase $snappedMs: ${coordBlockers.take(3).joinToString()}")
                } else {
                    blockers.add("phase $snappedMs missing refs")
                }
                if (blockers.size >= 8) break
                continue
            }
            for (coord in coords) {
                when (
                    playbackPhaseDrawableBlockReason(
                        vts,
                        coord,
                        snappedMs,
                        styleKey,
                        sourceLayer,
                        layer,
                    )
                ) {
                    PlaybackDrawableBlockReason.READY -> Unit
                    PlaybackDrawableBlockReason.DOWNLOADING ->
                        blockers.add("${coord.z}/${coord.x}/${coord.y}@$snappedMs downloading")
                    PlaybackDrawableBlockReason.NO_INTERVAL ->
                        blockers.add("${coord.z}/${coord.x}/${coord.y}@$snappedMs no interval")
                    PlaybackDrawableBlockReason.NO_DATA ->
                        blockers.add("${coord.z}/${coord.x}/${coord.y}@$snappedMs no parsed data")
                    PlaybackDrawableBlockReason.NO_MESH ->
                        blockers.add("${coord.z}/${coord.x}/${coord.y}@$snappedMs no mesh")
                }
                if (blockers.size >= 8) return blockers
            }
        }
        return blockers
    }

    // isIntervalReadyForPlaybackDisplay, schedulePlaybackFramePreparation: moved to
    // VectorPlaybackGateController (rule: shared-playback-gate) — called via `gate.*` from draw().

    private fun ensureTimeSeriesWarmupTriangulation(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        coords: List<TileCoord>,
        circleStyle: CircleTriangulationStyle,
        prefetchPhases: List<Long>,
        requestMissingTiles: Boolean,
    ) {
        // Gate-hold prep runs exclusively in [VectorPlaybackGateController.schedulePlaybackFramePreparation];
        // avoid per-frame work here.
        if (gate.playbackGateAnchorPhaseA >= 0) return
        if (requestMissingTiles && gate.warmupTilePrefetchJob?.isActive != true) {
            val prefetchCoords = coords.toList()
            val phasesForPrefetch = prefetchPhases
            gate.warmupTilePrefetchJob = layer.externalScope.launch(Dispatchers.Default) {
                while (isActive && !gate.playbackWarmupComplete) {
                    val waveStartMs = SystemClock.elapsedRealtime()
                    val requested = gate.prefetchPlaybackTilesWave(
                        layer = layer,
                        vts = vts,
                        coords = prefetchCoords,
                        phases = phasesForPrefetch,
                        waveBudget = gateHoldMvtRequestsPerWave,
                        awaitCompletion = false,
                    )
                    val parsed = gate.prefetchPlaybackNativeParseWave(
                        vts,
                        prefetchCoords,
                        phasesForPrefetch,
                        waveBudget = 64,
                    )
                    VectorGlPlaybackDiagnostics.logPrefetchWave(
                        "warmup",
                        requested,
                        SystemClock.elapsedRealtime() - waveStartMs,
                        parsed,
                    )
                    if (requested == 0 && parsed == 0 &&
                        gate.allViewportPhasesDataResolved(vts, prefetchCoords, phasesForPrefetch)
                    ) {
                        break
                    }
                    delay(40)
                }
            }
        }
        for (coord in coords) {
            for (phaseMs in prefetchPhases) {
                if (!vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, phaseMs)) continue
                val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: continue
                val data = vectorDataForSnappedPhase(vts, cached.data, phaseMs) ?: continue
                val rawFeatures = data.rawFeatures
                val drawableFeatures = if (rawFeatures != null) {
                    emptyList()
                } else {
                    data.features.filter {
                        val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
                        VectorFeatureDrawFilter.shouldDraw(
                            it,
                            layer.filter,
                            layer.id,
                            mapTimeMs = snappedMs,
                        )
                    }
                }
                if (rawFeatures != null) {
                    if (rawPhaseVacuouslyReady(rawFeatures)) {
                        data.markLayerMeshReady(vts, layer.id)
                        continue
                    }
                } else if (!data.hasCpuGeometry()) {
                    val triKeyEarly = circleTriangulationKey(coord, data, layer.sourceLayer, circleStyle.styleKey)
                    if (resolveCircleMesh(vts, triKeyEarly) != null) {
                        data.markLayerMeshReady(vts, layer.id)
                        continue
                    }
                    if (data.isVacuousParse()) data.markLayerMeshReady(vts, layer.id)
                    continue
                } else if (drawableFeatures.isEmpty()) {
                    data.markLayerMeshReady(vts, layer.id)
                    continue
                }
                val triKey = circleTriangulationKey(coord, data, layer.sourceLayer, circleStyle.styleKey)
                if (resolveCircleMesh(vts, triKey) == null && data.hasCpuGeometry() && triangulationInProgress.add(triKey)) {
                    val bgCoord = coord
                    val bgSourceLayer = layer.sourceLayer
                    val bgStyle = circleStyle
                    if (rawFeatures != null) {
                        val bgRawFeatures = rawFeatures
                        backgroundExecutor.submit {
                            try {
                                val computed = data.withGpuUpload {
                                    VectorPolygonFillTriangulator.triangulateCirclePointsRaw(
                                        bgRawFeatures,
                                        bgCoord,
                                        layerFallbackCircleRgba = bgStyle.layerFallbackCircleRgba,
                                        circleColorExpression = bgStyle.circleColorExpression,
                                        circleRadiusPx = bgStyle.circleRadiusStylePx,
                                        circleRadiusExpression = bgStyle.circleRadiusExpression,
                                    )
                                }
                                cacheCircleTriangulation(vts, triKey, computed)
                                data.markLayerMeshReady(vts, layer.id)
                                (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                            } finally {
                                triangulationInProgress.remove(triKey)
                            }
                        }
                    } else {
                        val bgFeatures = drawableFeatures
                        backgroundExecutor.submit {
                            try {
                                val computed = data.withGpuUpload {
                                    VectorPolygonFillTriangulator.triangulateCirclePoints(
                                        bgFeatures,
                                        bgCoord,
                                        bgSourceLayer,
                                        layerFallbackCircleRgba = bgStyle.layerFallbackCircleRgba,
                                        circleColorExpression = bgStyle.circleColorExpression,
                                        circleRadiusPx = bgStyle.circleRadiusStylePx,
                                        circleRadiusExpression = bgStyle.circleRadiusExpression,
                                    )
                                }
                                cacheCircleTriangulation(vts, triKey, computed)
                                data.markLayerMeshReady(vts, layer.id)
                                (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                            } finally {
                                triangulationInProgress.remove(triKey)
                            }
                        }
                    }
                } else if (resolveCircleMesh(vts, triKey) != null) {
                    data.markLayerMeshReady(vts, layer.id)
                }
            }
        }
    }

    private fun projectionMatrixToFloatArray(pm: ProjectionMatrix): FloatArray =
        FloatArray(16) { i -> pm.elements[i] }

    private fun matrix4ToFloatArray(m: Matrix4): FloatArray =
        FloatArray(16) { i -> m.elements[i] }

    private fun cacheTriangulationIfNonEmpty(key: String, data: FloatArray) {
        if (data.isNotEmpty()) triangulationCache[key] = data
    }

    private fun cacheCircleTriangulationWithTimes(
        key: String,
        result: VectorPolygonFillTriangulator.CircleTriangulationResult,
    ) {
        if (result.interleaved.isEmpty()) return
        triangulationCache[key] = result.interleaved
        val times = result.featureTimes
        if (times != null && times.isNotEmpty()) {
            circleFeatureTimeCache[key] = times
        } else {
            circleFeatureTimeCache.remove(key)
        }
    }

    /** CPU map-time reveal for circles: drop instances whose featureTime is ahead of the playhead. */
    private fun compactCircleInstancesByMapTime(
        interleaved: FloatArray,
        featureTimes: FloatArray?,
        dynamicMapTime: Boolean,
    ): FloatArray {
        if (!dynamicMapTime || featureTimes == null || featureTimes.isEmpty()) return interleaved
        val mapTime = VectorMapTime.currentMapTimeUniform(hasDynamicMapTime = true)
        val count = minOf(featureTimes.size, interleaved.size / FLOATS_PER_INSTANCE)
        var keep = 0
        for (i in 0 until count) {
            if (VectorMapTime.passesFeatureTime(featureTimes[i], mapTime)) keep++
        }
        if (keep == count) return interleaved
        if (keep == 0) return FloatArray(0)
        val out = FloatArray(keep * FLOATS_PER_INSTANCE)
        var o = 0
        for (i in 0 until count) {
            if (!VectorMapTime.passesFeatureTime(featureTimes[i], mapTime)) continue
            val base = i * FLOATS_PER_INSTANCE
            System.arraycopy(interleaved, base, out, o, FLOATS_PER_INSTANCE)
            o += FLOATS_PER_INSTANCE
        }
        return out
    }

    /**
     * Rule: circle-single-pass-stroke. Fill and stroke are resolved per-pixel in one draw call
     * (matching the JS SDK's `point.frag.glsl`), not as two global passes over every instance. Two
     * passes previously meant every point's stroke ring was drawn strictly after every point's fill —
     * painter's-algorithm blending then stacked every ring on top of every fill map-wide, so densely
     * overlapping points (e.g. lightning strikes) rendered as mostly grey outlines. A single mixed
     * draw keeps each point's fill/stroke resolution local to that point.
     *
     * [fillRadiusUv] is the paint outer radius in tile UV (`CirclePaint.radius`); the stroke is inset
     * inside that radius in the vertex shader (JS / Apple parity).
     */
    private fun drawCircleBatch(
        fillRadiusUv: Float,
        overscale: Float,
        strokeWidthPx: Float,
        strokeRgba: FloatArray?,
        instanceCount: Int,
    ) {
        val strokeUv =
            if (strokeWidthPx > 0f) strokeWidthPx / 512f / overscale.coerceAtLeast(1f) else 0f
        GLES31.glUniform1f(uRadiusUvLocation, fillRadiusUv)
        GLES31.glUniform1f(uStrokeUvLocation, strokeUv)
        if (strokeRgba != null && strokeUv > 0f) {
            GLES31.glUniform4f(
                uStrokeColorLocation,
                strokeRgba[0],
                strokeRgba[1],
                strokeRgba[2],
                strokeRgba[3],
            )
        } else {
            GLES31.glUniform4f(uStrokeColorLocation, 0f, 0f, 0f, 0f)
        }
        GLES31.glDrawArraysInstanced(GLES31.GL_TRIANGLES, 0, CIRCLE_QUAD_VERTEX_COUNT, instanceCount)
    }

    /** Creates the static per-vertex quad corner buffer once (rule: circle-gpu-instancing). */
    private fun ensureCircleQuadVbo() {
        if (circleQuadVbo != 0) return
        val h = IntArray(1)
        GLES31.glGenBuffers(1, h, 0)
        circleQuadVbo = h[0]
        val bytes = CIRCLE_QUAD_CORNERS.size * 4
        val bb = ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder())
        bb.asFloatBuffer().put(CIRCLE_QUAD_CORNERS)
        bb.position(0)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, circleQuadVbo)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, bytes, bb, GLES31.GL_STATIC_DRAW)
    }

    private fun ensureCircleProgram() {
        if (circleGlProgram != 0 &&
            circleGlProgramVersion == CIRCLE_GL_PROGRAM_VERSION &&
            uCircleMvpLocation >= 0 &&
            uRadiusUvLocation >= 0 &&
            uStrokeColorLocation >= 0 &&
            uStrokeUvLocation >= 0
        ) {
            return
        }
        if (circleGlProgram != 0) {
            GLES31.glDeleteProgram(circleGlProgram)
            circleGlProgram = 0
            uCircleMvpLocation = -1
            uRadiusUvLocation = -1
            uStrokeColorLocation = -1
            uStrokeUvLocation = -1
        }
        if (tryLinkCircleProgramExplicitLocations()) {
            circleGlProgramVersion = CIRCLE_GL_PROGRAM_VERSION
            return
        }
        // Both variants are ES 3.0; they differ only in whether attribute locations are declared
        // explicitly. Explicit locations are core in GLSL ES 3.00, so this fallback exists only for
        // drivers that mishandle them, not for any version requirement.
        Log.w(VECTOR_CIRCLE_TAG, "circle program with explicit attribute locations failed; trying plain-attribute fallback")
        tryLinkCircleProgramPlainAttribs()
        if (circleGlProgram != 0) {
            circleGlProgramVersion = CIRCLE_GL_PROGRAM_VERSION
        }
    }

    private fun tryLinkCircleProgramExplicitLocations(): Boolean {
        val vtx = """
            #version 300 es
            layout(location = 0) in vec2 a_center;
            layout(location = 1) in vec2 a_corner;
            layout(location = 2) in vec4 a_color;
            layout(location = 3) in float a_radius_scale;
            uniform mat4 u_mvp;
            uniform float u_radius_uv;
            uniform float u_stroke_uv;
            out vec4 v_color;
            out vec2 v_corner;
            out float v_stroke_inner_ratio_out;
            void main() {
                v_color = a_color;
                v_corner = a_corner;
                // [CirclePaint.radius] is outer size; stroke is inset (JS / Apple parity).
                float outerR = u_radius_uv * a_radius_scale;
                float fillR = max(0.0, outerR - u_stroke_uv);
                v_stroke_inner_ratio_out = fillR / max(outerR, 1e-6);
                gl_Position = u_mvp * vec4(a_center + a_corner * outerR, 0.0, 1.0);
            }
        """.trimIndent()
        val frag = """
            #version 300 es
            precision mediump float;
            in vec4 v_color;
            in vec2 v_corner;
            in float v_stroke_inner_ratio_out;
            uniform vec4 u_stroke_color;
            out vec4 o_frag;
            void main() {
                float dist = length(v_corner);
                float fw = fwidth(dist);
                float strokeT = smoothstep(v_stroke_inner_ratio_out - fw, v_stroke_inner_ratio_out + fw, dist);
                vec4 mixed = mix(v_color, u_stroke_color, strokeT);
                float outerAa = 1.0 - smoothstep(1.0 - fw, 1.0 + fw, dist);
                o_frag = vec4(mixed.rgb, mixed.a * outerAa);
            }
        """.trimIndent()
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vtx, "circle-vertex-explicit-loc")
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, frag, "circle-frag-explicit-loc")
        if (vs == 0 || fs == 0) return false
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, vs)
        GLES31.glAttachShader(p, fs)
        GLES31.glLinkProgram(p)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val link = IntArray(1)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) {
            logProgramLinkFailure("circle-310", p)
            GLES31.glDeleteProgram(p)
            return false
        }
        circleGlProgram = p
        uCircleMvpLocation = GLES31.glGetUniformLocation(circleGlProgram, "u_mvp")
        uRadiusUvLocation = GLES31.glGetUniformLocation(circleGlProgram, "u_radius_uv")
        uStrokeColorLocation = GLES31.glGetUniformLocation(circleGlProgram, "u_stroke_color")
        uStrokeUvLocation = GLES31.glGetUniformLocation(circleGlProgram, "u_stroke_uv")
        if (uCircleMvpLocation < 0 || uRadiusUvLocation < 0 ||
            uStrokeColorLocation < 0 || uStrokeUvLocation < 0
        ) {
            Log.e(VECTOR_CIRCLE_TAG, "circle uniforms missing after GLES 3.1 link")
            GLES31.glDeleteProgram(circleGlProgram)
            circleGlProgram = 0
            uCircleMvpLocation = -1
            uRadiusUvLocation = -1
            uStrokeColorLocation = -1
            uStrokeUvLocation = -1
            return false
        }
        return true
    }

    private fun tryLinkCircleProgramPlainAttribs() {
        val vtx = """
            #version 300 es
            uniform mat4 u_mvp;
            uniform float u_radius_uv;
            uniform float u_stroke_uv;
            in vec2 a_center;
            in vec2 a_corner;
            in vec4 a_color;
            in float a_radius_scale;
            out vec4 v_color;
            out vec2 v_corner;
            out float v_stroke_inner_ratio_out;
            void main() {
                v_color = a_color;
                v_corner = a_corner;
                // [CirclePaint.radius] is outer size; stroke is inset (JS / Apple parity).
                float outerR = u_radius_uv * a_radius_scale;
                float fillR = max(0.0, outerR - u_stroke_uv);
                v_stroke_inner_ratio_out = fillR / max(outerR, 1e-6);
                gl_Position = u_mvp * vec4(a_center + a_corner * outerR, 0.0, 1.0);
            }
        """.trimIndent()
        val frag = """
            #version 300 es
            precision mediump float;
            in vec4 v_color;
            in vec2 v_corner;
            in float v_stroke_inner_ratio_out;
            uniform vec4 u_stroke_color;
            out vec4 fragColor;
            void main() {
                float dist = length(v_corner);
                float fw = fwidth(dist);
                float strokeT = smoothstep(v_stroke_inner_ratio_out - fw, v_stroke_inner_ratio_out + fw, dist);
                vec4 mixed = mix(v_color, u_stroke_color, strokeT);
                float outerAa = 1.0 - smoothstep(1.0 - fw, 1.0 + fw, dist);
                fragColor = vec4(mixed.rgb, mixed.a * outerAa);
            }
        """.trimIndent()
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vtx, "circle-vertex300")
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, frag, "circle-frag300")
        if (vs == 0 || fs == 0) return
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, vs)
        GLES31.glAttachShader(p, fs)
        GLES31.glBindAttribLocation(p, 0, "a_center")
        GLES31.glBindAttribLocation(p, 1, "a_corner")
        GLES31.glBindAttribLocation(p, 2, "a_color")
        GLES31.glBindAttribLocation(p, 3, "a_radius_scale")
        GLES31.glLinkProgram(p)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val link = IntArray(1)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) {
            logProgramLinkFailure("circle-300", p)
            GLES31.glDeleteProgram(p)
            circleGlProgram = 0
            uCircleMvpLocation = -1
            uRadiusUvLocation = -1
            uStrokeColorLocation = -1
            uStrokeUvLocation = -1
            return
        }
        circleGlProgram = p
        uCircleMvpLocation = GLES31.glGetUniformLocation(circleGlProgram, "u_mvp")
        uRadiusUvLocation = GLES31.glGetUniformLocation(circleGlProgram, "u_radius_uv")
        uStrokeColorLocation = GLES31.glGetUniformLocation(circleGlProgram, "u_stroke_color")
        uStrokeUvLocation = GLES31.glGetUniformLocation(circleGlProgram, "u_stroke_uv")
        if (uCircleMvpLocation < 0 || uRadiusUvLocation < 0 ||
            uStrokeColorLocation < 0 || uStrokeUvLocation < 0
        ) {
            Log.e(VECTOR_CIRCLE_TAG, "circle uniforms missing after GLES 3.0 link")
            GLES31.glDeleteProgram(circleGlProgram)
            circleGlProgram = 0
            uCircleMvpLocation = -1
            uRadiusUvLocation = -1
            uStrokeColorLocation = -1
            uStrokeUvLocation = -1
        }
    }

    private fun logProgramLinkFailure(label: String, program: Int) {
        val log = GLES31.glGetProgramInfoLog(program)
        if (log.isNotBlank()) {
            Log.e(VECTOR_CIRCLE_TAG, "Program link failed ($label): $log")
        }
    }

    private fun compileShader(type: Int, src: String, label: String): Int {
        val s = GLES31.glCreateShader(type)
        GLES31.glShaderSource(s, src)
        GLES31.glCompileShader(s)
        val ok = IntArray(1)
        GLES31.glGetShaderiv(s, GLES31.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES31.glGetShaderInfoLog(s)
            if (log.isNotBlank()) {
                Log.e(VECTOR_CIRCLE_TAG, "Shader compile failed ($label): $log")
            }
            GLES31.glDeleteShader(s)
            return 0
        }
        return s
    }

    internal fun invalidateTimelineMeshCache() {
        triangulationCache.clear()
        circleFeatureTimeCache.clear()
        triangulationInProgress.clear()
        lastSuccessfulBatches = emptyList()
        lastSuccessfulDrawIntervalMs = null
        pausedBatchCount = 0
        playbackFrozenBatches = emptyList()
        playbackFrozenIntervalMs = null
        gate.invalidate()
    }

    fun releaseGl() {
        invalidateTimelineMeshCache()
        backgroundExecutor.shutdownNow()
        backgroundExecutor = Executors.newFixedThreadPool(circleTriangulationThreads)
        if (vbo != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(vbo), 0)
            vbo = 0
        }
        if (circleQuadVbo != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(circleQuadVbo), 0)
            circleQuadVbo = 0
        }
        if (circleGlProgram != 0) {
            GLES31.glDeleteProgram(circleGlProgram)
            circleGlProgram = 0
            uCircleMvpLocation = -1
            uRadiusUvLocation = -1
            uStrokeColorLocation = -1
            uStrokeUvLocation = -1
            circleGlProgramVersion = -1
        }
    }

    override suspend fun update() {}
}
