package com.xweather.mapsgl.renderers

/**
 * Small `#include <name>` resolver for custom Symbol fragment shaders ([com.xweather.mapsgl.style.IconPaint.shader]),
 * mirroring the JS SDK's shader-chunk registry so effects like the JS `fires-fx` example (which uses
 * `#include <fbm>`) can be ported without re-typing noise functions by hand. Non-recursive (chunks
 * don't themselves reference other chunks) — sufficient for the single seeded chunk below.
 */
internal object VectorSymbolShaderChunks {

    /** Ported verbatim from the JS SDK's `chunks/fbm.glsl` (value-noise fractal Brownian motion). */
    private const val FBM = """
vec2 hash(vec2 p) {
    p = vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)));
    return -1.0 + 2.0 * fract(sin(p) * 43758.5453123);
}

float noise(in vec2 p) {
    const float K1 = 0.366025404;
    const float K2 = 0.211324865;
    vec2 i = floor(p + (p.x + p.y) * K1);
    vec2 a = p - i + (i.x + i.y) * K2;
    vec2 o = (a.x > a.y) ? vec2(1.0, 0.0) : vec2(0.0, 1.0);
    vec2 b = a - o + K2;
    vec2 c = a - 1.0 + 2.0 * K2;
    vec3 h = max(0.5 - vec3(dot(a, a), dot(b, b), dot(c, c)), 0.0);
    vec3 n = h * h * h * h * vec3(dot(a, hash(i + 0.0)), dot(b, hash(i + o)), dot(c, hash(i + 1.0)));
    return dot(n, vec3(70.0));
}

float fbm(vec2 uv) {
    float f;
    mat2 m = mat2(1.6, 1.2, -1.2, 1.6);
    f  = 0.5000 * noise(uv); uv = m * uv;
    f += 0.2500 * noise(uv); uv = m * uv;
    f += 0.1250 * noise(uv); uv = m * uv;
    f += 0.0625 * noise(uv); uv = m * uv;
    f = 0.5 + 0.5 * f;
    return f;
}
"""

    private val chunks: Map<String, String> = mapOf("fbm" to FBM)

    private val includePattern = Regex("""^[\t ]*#include\s*<(\w+)>[\t ]*$""", RegexOption.MULTILINE)

    /**
     * Replaces every `#include <name>` line in [source] with the matching registered chunk's source.
     * An unresolvable name is left as a GLSL comment (causing a clear compile error at the reference
     * site) rather than silently dropped, so authoring mistakes are visible in the shader compile log.
     */
    fun resolveIncludes(source: String): String =
        includePattern.replace(source) { match ->
            val name = match.groupValues[1]
            chunks[name] ?: "// unresolved #include <$name>"
        }
}
