package com.xweather.mapsgl.renderers

import android.opengl.GLES31
import android.util.Log
import com.mapbox.maps.toCameraOptions
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.EmptyRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.sources.EncodedGridVectorTileSource
import com.xweather.mapsgl.sources.VisibleGeoBounds
import com.xweather.mapsgl.sources.XweatherEncodedTileSource
import com.xweather.mapsgl.style.IconSize
import com.xweather.mapsgl.tiles.TileData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.min
import kotlin.math.pow

/**
 * Shared instanced grid pipeline for layers that sample [EncodedGridVectorTileSource] into a dual-phase
 * instance buffer ([buildInstancedWindBufferDualPhase]), upload on the render thread, and apply [Timeline.dataMeld] in the shader.
 *
 * Subclasses supply GL setup ([ensureGlResources]), draw ([drawInstanced]), and CPU gather ([runGridGatherOnce]).
 */
abstract class GridLayerRenderer(
    override var id: String,
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {

    protected abstract val logTag: String

    protected var gridSource: EncodedGridVectorTileSource? = null
    protected var gatherJob: Job? = null

    @Volatile
    protected var gatherKickPending = false

    protected val bufferLock = Any()
    protected var pendingInstanceData: FloatArray? = null
    protected var pendingInstanceCount: Int = 0
    protected var pendingGatherZoom: Double = 0.0
    protected var pendingAppliedGatherKey: String? = null
    protected var pendingBufferPhaseA: Int = -1
    protected var pendingBufferPhaseB: Int = -1

    protected var gpuInstanceCount = 0
    protected var gpuGatherZoom: Double = 5.0
    protected var appliedGatherKey: String? = null

    /** Phase indices baked into the current GPU instance buffer (see [effectiveGridMeld]). */
    protected var bufferPhaseA: Int = -1
    protected var bufferPhaseB: Int = -1

    protected var glReady = false
    protected var vao = 0
    protected var quadVbo = 0
    protected var instanceVbo = 0

    fun attachGridSource(source: EncodedGridVectorTileSource) {
        gridSource = source
        appliedGatherKey = null
        bufferPhaseA = -1
        bufferPhaseB = -1
        scheduleGather()
    }

    /**
     * Resolves geographic bounds for CPU instanced gather. Prefer live Mapbox camera corners; if that fails
     * (e.g. camera not ready on first frame at zoom 0), fall back to the tile layer’s [TileLayer.bounds] or
     * [MapController.getBounds] so [EncodedGridVectorTileSource.buildViewportGridPoints] is not empty.
     */
    protected suspend fun resolveVisibleGeoBoundsForGather(
        tl: TileLayer,
        mc: MapboxMapController,
        zoom: Double,
    ): VisibleGeoBounds? {
        val map = mc.mapboxMap ?: return null
        val fromCamera = withContext(Dispatchers.Main) {
            val centerLon = map.cameraState.center.longitude()
            runCatching {
                VisibleGeoBounds.fromMapboxUnwrappedCamera(
                    map.coordinateBoundsForCameraUnwrapped(map.cameraState.toCameraOptions()),
                    centerLon,
                    zoom,
                )
            }.getOrNull()
        }
        if (fromCamera != null) return fromCamera
        return withContext(Dispatchers.Main) {
            val lb = tl.bounds ?: runCatching { mc.getBounds() }.getOrNull() ?: return@withContext null
            VisibleGeoBounds.fromLatLonExtents(
                lb.westExtent,
                lb.southExtent,
                lb.eastExtent,
                lb.northExtent,
            )
        }
    }

    override fun setNeedsUpdate() {
        scheduleGather()
    }

    override fun setNeedsUpdate(force: Boolean) {
        scheduleGather()
    }

    override fun onAdd() {}

    override fun onAdd(context: RenderContext<Any>, tileLayer: TileLayer, controller: MapboxMapController) {}

    override suspend fun update() {}

    override fun setUpRenderPass(): RenderPass =
        EmptyRenderPass(tileLayer?.source?.id ?: id, tileLayer!!.paint)

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {}

    /**
     * [draw] runs on the Mapbox render thread; do not read live camera zoom from the main thread.
     * @see CameraSync.zoomForCustomLayerInstancing
     */
    protected fun zoomForInstancedGatherKey(): Double = CameraSync.zoomForCustomLayerInstancing()

    protected fun computeGatherKey(tl: TileLayer): String {
        val z = zoomForInstancedGatherKey()
        val dKey = EncodedGridVectorTileSource.instancingGatherPlacementKey(z)
        val vKey = instancedGatherViewportKey(tl)
        return "${Timeline.currentPhaseA}|${Timeline.currentPhaseB}|$dKey|$vKey"
    }

    /**
     * Quantized visible bounds (same scheme as [EncodedGridVectorTileSource.viewportKeyForVisibleBounds]),
     * not an enumerated tile list — near the antimeridian tile columns can reorder every frame while the
     * geographic viewport is stable, which was spuriously invalidating the gather key.
     */
    protected fun instancedGatherViewportKey(tl: TileLayer): String {
        val b = tl.bounds
        if (b == null) {
            val coords = tl.visibleTileCoordsForSidecarSampling()
            return coords.joinToString(",") { "${it.z}/${it.x}/${it.y}" }
        }
        fun q(x: Double) = (x * 80.0).toInt()
        val eastUnwrapped = if (b.eastExtent < b.westExtent) b.eastExtent + 360.0 else b.eastExtent
        return "vp${q(b.westExtent)}_${q(b.southExtent)}_${q(eastUnwrapped)}_${q(b.northExtent)}"
    }

    /**
     * When [logGriddedTimelineMeldWhileAnimating] is true and the map timeline is [AnimationState.playing],
     * emits one [Log.d] per draw frame with [Timeline.dataMeld], effective meld, and [Timeline.intervalLength].
     */
    private fun maybeLogGriddedMeldWhileAnimating(effectiveMeld: Float) {
        if (!logGriddedTimelineMeldWhileAnimating) return
        val mc = tileLayer?.mapController as? MapboxMapController ?: return
        if (mc.timeline.state != AnimationState.playing) return

        val dataMeld = Timeline.dataMeld
        val intervalSec = Timeline.intervalLength
        val ta = Timeline.currentPhaseA
        val tb = Timeline.currentPhaseB
        val timeA = Timeline.timeStrings.getOrNull(ta).orEmpty()
        val timeB = Timeline.timeStrings.getOrNull(tb).orEmpty()
        Log.d(
            LOG_TAG_GRIDDED_MELD,
            "layer=$id dataMeld=$dataMeld effectiveMeld=$effectiveMeld " +
                "intervalSec=$intervalSec phases=($ta->$timeA | $tb->$timeB) bufferPhases=($bufferPhaseA,$bufferPhaseB)",
        )
    }

    /**
     * Meld passed to the shader. Matches [Timeline.dataMeld] when the uploaded instance buffer was built for the
     * same phase indices as the timeline.
     *
     * When the buffer is **behind** the timeline, the shader must not blend with a small [Timeline.dataMeld] —
     * slots A/B in the VBO still refer to the *previous* pair; weighting toward A (low meld) shows the wrong wind
     * direction for a frame. Hold at **1** (full buffer B, i.e. end of the prior step) until gather refills; this
     * usually lines up with the new interval’s first timestep. [scheduleGather] runs when behind.
     *
     * When the buffer is **ahead**, use **0** (full buffer A) until the timeline catches up.
     */
    protected fun effectiveGridMeld(): Float {
        val ta = Timeline.currentPhaseA
        val tb = Timeline.currentPhaseB
        val ba = bufferPhaseA
        val bb = bufferPhaseB
        val m = Timeline.dataMeld.coerceIn(0f, 1f)
        if (ba < 0 || bb < 0) return m
        if (ba == ta && bb == tb) return m
        return when {
            ba < ta || bb < tb -> {
                scheduleGather()
                1f
            }
            ba > ta || bb > tb -> 0f
            else -> m
        }
    }

    protected fun FloatArray.toFloatBuffer(): FloatBuffer =
        ByteBuffer.allocateDirect(size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().also {
            it.put(this)
            it.position(0)
        }

    protected fun scheduleGather() {
        val tl = tileLayer ?: return
        val gs = gridSource ?: return
        val mc = tl.mapController as? MapboxMapController ?: return

        if (gatherJob?.isActive == true) {
            gatherKickPending = true
            return
        }
        gatherKickPending = false
        gatherJob = tl.externalScope.launch {
            do {
                gatherKickPending = false
                runGridGatherOnce(tl, gs, mc)
            } while (gatherKickPending)
        }
    }

    protected abstract suspend fun runGridGatherOnce(
        tl: TileLayer,
        gs: EncodedGridVectorTileSource,
        mc: MapboxMapController,
    )

    protected fun worldSizePx(mapZoom: Double): Double = 512.0 * 2.0.pow(mapZoom)

    protected fun iconSizingZoomClampedToDataMax(baseZoom: Double = gpuGatherZoom): Double {
        val tl = tileLayer ?: return baseZoom
        val maxData = tl.source.maxZoom.toDouble().coerceIn(0.0, 24.0)
        if (maxData <= 1e-6) return baseZoom
        return min(baseZoom, maxData)
    }

    /**
     * Mercator half-extent baseline for [u_iconHalfExtent]. Plateau [3,4]: see
     * [ICON_HALF_EXTENT_PLATEAU_LO] / [ICON_HALF_EXTENT_PLATEAU_HI].
     */
    protected fun baseHalfWorldMercatorForInstancedIcon(): Float {
        val zR = CameraSync.zoomForCustomLayerInstancing()
        val zG = gpuGatherZoom
        val inPlateau34 =
            zR >= ICON_HALF_EXTENT_PLATEAU_LO && zR <= ICON_HALF_EXTENT_PLATEAU_HI
        val raw = if (inPlateau34) {
            val zLock = iconSizingZoomClampedToDataMax(ICON_HALF_EXTENT_PLATEAU_LO)
            val wszLock = worldSizePx(zLock)
            val wszR = worldSizePx(zR)
            val wszG = worldSizePx(zG)
            wszLock.toFloat() * 0.0012f * (wszG / wszR).toFloat()
        } else {
            worldSizePx(iconSizingZoomClampedToDataMax(zG)).toFloat() * 0.0012f
        }
        val overPlateauHi =
            if (zR > ICON_HALF_EXTENT_PLATEAU_HI) ICON_HALF_EXTENT_ZOOM_GT_PLATEAU_HI_SCALE else 1f
        return (raw * overPlateauHi).coerceIn(6f, 96f)
    }

    /**
     * `Resources.displayMetrics.density` for scaling JS-style **logical** icon `width`/`height` (dp-like authoring)
     * to physical pixels before Mercator conversion. Uses the map view context when attached, else [TileLayer.drawContext].
     */
    protected fun griddedIconDisplayDensity(): Float {
        val ctx =
            tileLayer?.mapController?.mapView?.context
                ?: tileLayer?.drawContext
        val d = ctx?.resources?.displayMetrics?.density ?: return 1f
        return if (d > 0f) d else 1f
    }

    /**
     * Converts JS-style `icon.size` pixel dimensions (web [SymbolStore.layoutIcon] `w`/`h`) to Mercator half-extents.
     * [baseHalfWorldMercatorForInstancedIcon] is tuned so a **40px-wide** icon matches the web default scale; other
     * widths/heights scale linearly (arrow 40×20 → half extents in 2:1 ratio).
     *
     * Width and height are multiplied by [griddedIconDisplayDensity] so authored sizes track device density whenever
     * paint is read during gather/draw (no separate "icon size changed" hook).
     */
    protected fun mercatorHalfExtentsFromJsIconPixels(
        widthPx: Float,
        heightPx: Float,
        baseHalfWorld: Float,
        jsReferenceWidthPx: Float = IconSize.JS_REFERENCE_WIDTH_PX,
    ): Pair<Float, Float> {
        val density = griddedIconDisplayDensity()
        val wPx = widthPx * density
        val hPx = heightPx * density
        val ref = jsReferenceWidthPx.coerceAtLeast(1e-3f)
        val hx = (baseHalfWorld * (wPx / ref)).coerceIn(2f, 192f)
        val hy = (baseHalfWorld * (hPx / ref)).coerceIn(2f, 192f)
        return hx to hy
    }

    /**
     * Upload pending instance CPU data to the instance VBO and invoke [drawInstanced] when instances are ready.
     * Call from the Mapbox render thread after optional [scheduleGather] when the gather key is stale.
     */
    protected fun consumePendingInstanceUploadAndDraw(camera: Camera) {
        synchronized(bufferLock) {
            val data = pendingInstanceData
            val count = pendingInstanceCount
            if (data != null) {
                ensureGlResources()
                if (count > 0) {
                    GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, instanceVbo)
                    GLES31.glBufferData(
                        GLES31.GL_ARRAY_BUFFER,
                        data.size * 4,
                        data.toFloatBuffer(),
                        GLES31.GL_DYNAMIC_DRAW,
                    )
                }
                gpuInstanceCount = count
                gpuGatherZoom = pendingGatherZoom
                pendingAppliedGatherKey?.let { appliedGatherKey = it }
                pendingAppliedGatherKey = null
                if (count > 0 && pendingBufferPhaseA >= 0 && pendingBufferPhaseB >= 0) {
                    bufferPhaseA = pendingBufferPhaseA
                    bufferPhaseB = pendingBufferPhaseB
                } else if (count == 0) {
                    bufferPhaseA = -1
                    bufferPhaseB = -1
                }
                pendingBufferPhaseA = -1
                pendingBufferPhaseB = -1
                pendingInstanceData = null
                pendingInstanceCount = 0
            }
            if (gpuInstanceCount > 0 && glReady) {
                val meld = effectiveGridMeld()
                maybeLogGriddedMeldWhileAnimating(meld)
                drawInstanced(camera, gpuInstanceCount, meld)
            }
        }
    }

    protected abstract fun ensureGlResources()

    protected abstract fun drawInstanced(camera: Camera, instanceCount: Int, meld: Float)

    protected fun projectionMatrixToFloatArray(pm: ProjectionMatrix): FloatArray =
        pm.elements.toFloatArray()

    protected fun matrix4ToFloatArray(m: com.xweather.mapsgl.gl.math.Matrix4): FloatArray =
        m.elements.toFloatArray()

    override fun onAdd(tileLayer: TileLayer) {
        super.onAdd(tileLayer)
        val enc = tileLayer.source as? XweatherEncodedTileSource
        enc?.addOnEncodedTileReadyListener {
            appliedGatherKey = null
            bufferPhaseA = -1
            bufferPhaseB = -1
            scheduleGather()
        }
        appliedGatherKey = null
        bufferPhaseA = -1
        bufferPhaseB = -1
        scheduleGather()
    }

    companion object {
        /** Logcat tag for [maybeLogGriddedMeldWhileAnimating] (`adb logcat -s MapsGLGriddedMeld:D`). */
        const val LOG_TAG_GRIDDED_MELD = "MapsGLGriddedMeld"

        /**
         * When true, gridded instanced layers log [Timeline.dataMeld], effective shader meld, and
         * [Timeline.intervalLength] (seconds) on every draw frame while the timeline is playing (very verbose).
         */
        @JvmField
        var logGriddedTimelineMeldWhileAnimating: Boolean = false

        /** tileXY(2) + dirA,speedA,dirB,speedB(4) + rgbaA(4) + rgbaB(4) — meld in shader */
        const val FLOATS_PER_INSTANCE = 14

        const val ICON_HALF_EXTENT_PLATEAU_LO = 3.0
        const val ICON_HALF_EXTENT_PLATEAU_HI = 4.0

        /** Multiply Mercator half-extent when [CameraSync.zoomForCustomLayerInstancing] > [ICON_HALF_EXTENT_PLATEAU_HI]. */
        const val ICON_HALF_EXTENT_ZOOM_GT_PLATEAU_HI_SCALE = 0.5f
    }
}
