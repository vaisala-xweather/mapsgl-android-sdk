package com.xweather.mapsgl.renderers

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Converts an 8-bit alpha coverage bitmap into a signed distance field, byte-encoded for
 * [VectorSymbolLayerRenderer]'s SDF fragment path.
 *
 * Ported from the Apple SDK's `IconAtlas.writeSDF` / `chamferEDT` (release/1.7.0) so Android bakes
 * text glyphs the same way iOS does. Kept as a pure function over plain arrays — no Bitmap, no GL —
 * because it is the part of the glyph pipeline most easily got subtly wrong (see the chamfer-unit
 * conversion below) and this module's JVM unit tests cannot construct an android.graphics.Bitmap.
 */
internal object VectorSdfEncoder {

    /**
     * Distance, in source pixels, over which the field ramps from the glyph edge to fully outside.
     * Matches the Apple SDK's `IconAtlas.sdfRadius`. The glyph bitmap must carry at least this much
     * transparent padding around its ink or the ramp is clipped and the halo has nowhere to draw.
     */
    const val SDF_RADIUS_PX = 8f

    /**
     * Normalized field value at the glyph edge; everything inside is greater.
     *
     * The Apple SDK bakes the edge at 192/255 (~0.753) to match its own shader constant. Android's
     * [VectorSymbolLayerRenderer] SDF path hardcodes `INNER_EDGE = 0.8`, and its pre-baked
     * `sprite-sdf@2x.png` asset is authored to that, so text bakes to 0.8 as well rather than
     * introducing a second convention the one shader would have to distinguish between.
     */
    const val SDF_EDGE = 0.8f

    /**
     * Normalized field units per source pixel of distance. The shader's halo width is expressed in
     * these units: a halo of N source pixels is `N * FIELD_UNITS_PER_PX` (see
     * [haloWidthForOutlinePx]).
     */
    const val FIELD_UNITS_PER_PX = SDF_EDGE / SDF_RADIUS_PX

    /** Chamfer-3-4 encodes one orthogonal step as 3 and one diagonal as 4. */
    private const val CHAMFER_ORTHOGONAL = 3f
    private const val CHAMFER_DIAGONAL = 4f

    /** Coverage above this counts as inside the glyph. */
    private const val INK_THRESHOLD = 127

    private const val INF = 1e9f

    /**
     * Converts the shader's halo width from source pixels to the normalized field units
     * `u_haloWidth` expects.
     *
     * Mirrors the Apple SDK's `chamferPerPixel` correction, whose comment records what happens
     * without it: the byte ramp came out 3x steeper than the shader's interpretation, so every halo
     * rendered at roughly a third of its configured width and was invisible at small sizes. Here the
     * conversion lives in [encode] (distances are divided back to pixels before quantizing), so this
     * only has to scale pixels to field units.
     */
    fun haloWidthForOutlinePx(outlinePx: Float): Float =
        (outlinePx * FIELD_UNITS_PER_PX).coerceIn(0f, SDF_EDGE)

    /**
     * @param alpha row-major 8-bit coverage, [width] * [height] entries. Values are read as
     * unsigned, so callers may pass raw `ByteArray` from a bitmap.
     * @return one byte per pixel, row-major: [SDF_EDGE] * 255 at the glyph edge, rising to 255 well
     * inside the ink and falling to 0 at [SDF_RADIUS_PX] outside it.
     */
    fun encode(
        alpha: ByteArray,
        width: Int,
        height: Int,
        radiusPx: Float = SDF_RADIUS_PX,
        edge: Float = SDF_EDGE,
    ): ByteArray {
        require(width > 0 && height > 0) { "empty glyph bitmap ${width}x$height" }
        require(alpha.size >= width * height) {
            "alpha buffer ${alpha.size} too small for ${width}x$height"
        }
        val n = width * height
        val inside = FloatArray(n) { INF }
        val outside = FloatArray(n) { INF }
        for (i in 0 until n) {
            if ((alpha[i].toInt() and 0xFF) > INK_THRESHOLD) inside[i] = 0f else outside[i] = 0f
        }
        chamferEdt(inside, width, height)
        chamferEdt(outside, width, height)

        val edgeByte = edge * 255f
        val out = ByteArray(n)
        for (i in 0 until n) {
            // Signed: negative inside the ink, positive outside it.
            val chamferDistance = if (inside[i] == 0f) -outside[i] else inside[i]
            val distancePx = chamferDistance / CHAMFER_ORTHOGONAL
            val clamped = max(-radiusPx, min(radiusPx, distancePx))
            val v = edgeByte - clamped * (edgeByte / radiusPx)
            out[i] = v.roundToInt().coerceIn(0, 255).toByte()
        }
        return out
    }

    /** Chamfer-3-4 EDT, two passes over [d] in place. */
    private fun chamferEdt(d: FloatArray, width: Int, height: Int) {
        for (y in 0 until height) {
            for (x in 0 until width) {
                val i = y * width + x
                if (x > 0) d[i] = min(d[i], d[i - 1] + CHAMFER_ORTHOGONAL)
                if (y > 0) {
                    d[i] = min(d[i], d[i - width] + CHAMFER_ORTHOGONAL)
                    if (x > 0) d[i] = min(d[i], d[i - width - 1] + CHAMFER_DIAGONAL)
                    if (x < width - 1) d[i] = min(d[i], d[i - width + 1] + CHAMFER_DIAGONAL)
                }
            }
        }
        for (y in height - 1 downTo 0) {
            for (x in width - 1 downTo 0) {
                val i = y * width + x
                if (x < width - 1) d[i] = min(d[i], d[i + 1] + CHAMFER_ORTHOGONAL)
                if (y < height - 1) {
                    d[i] = min(d[i], d[i + width] + CHAMFER_ORTHOGONAL)
                    if (x > 0) d[i] = min(d[i], d[i + width - 1] + CHAMFER_DIAGONAL)
                    if (x < width - 1) d[i] = min(d[i], d[i + width + 1] + CHAMFER_DIAGONAL)
                }
            }
        }
    }
}
