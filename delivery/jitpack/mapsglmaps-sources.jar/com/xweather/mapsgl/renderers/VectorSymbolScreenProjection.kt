package com.xweather.mapsgl.renderers

import android.opengl.Matrix
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.tiles.TileCoord
import kotlin.math.cos
import kotlin.math.sin

/** Projects GLES symbol instances to screen-space bounds (MapsGL JS collision boxes). */
internal object VectorSymbolScreenProjection {

    /** Collision footprint vs drawn icon (inset from full quad bounds). */
    const val SYMBOL_COLLISION_BOX_SCALE = 0.72f

    /**
     * Rule: reject-unprojectable-corner. Smallest clip-space w a corner may divide by. The guards
     * below used to test `w == 0f` exactly, which is almost never the value that actually occurs:
     * under a pitched camera a symbol at or beyond the horizon lands on a w of ~1e-8, not 0, and
     * dividing by it yields screen coordinates around ±1e30. Such a box passes
     * [VectorSymbolLayerRenderer]'s viewport test (it "covers" the screen), and
     * VectorSymbolScreenPlacer's collision grid then tried to walk it cell by cell — with
     * `floor(±1e30 / 128).toInt()` saturating to Int.MIN_VALUE/Int.MAX_VALUE, that is a ~1e19
     * iteration loop allocating a bucket per cell, i.e. an OOM inside Mapbox's own render()
     * callback, which aborts the process at the JNI boundary (same failure mode documented on
     * VectorSymbolLayerRenderer.MAX_SYMBOL_INSTANCES_PER_TILE).
     *
     * A corner behind or on the camera plane has no meaningful screen position, so it is reported
     * as NaN and the whole symbol is dropped from placement, rather than being clamped to a
     * fabricated coordinate.
     */
    private const val MIN_PROJECTED_CLIP_W = 1e-6f

    /**
     * Rule: bounded-collision-box. How far outside the viewport a collision box may extend before
     * its edges are clamped. Every box that survives VectorSymbolLayerRenderer's visibility test
     * intersects the viewport, so clamping at a margin this much larger than that test's own 64px
     * cannot change which boxes overlap *on screen* — it only stops a legitimately huge box (a very
     * large label at low zoom, an extreme overscale) from spanning an unbounded number of grid
     * cells. Kept well above any real label size so ordinary placement is untouched.
     */
    private const val SCREEN_BOX_CLAMP_MARGIN_PX = 4096f

    fun buildTileMvp(
        coord: TileCoord,
        overscale: Float,
        proj: FloatArray,
        mvCam: FloatArray,
        tileLocal: FloatArray,
        modelView: FloatArray,
        mvp: FloatArray,
    ): FloatArray {
        Matrix.setIdentityM(tileLocal, 0)
        Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
        // Rule: dateline-world-copy. See VectorFillLayerRenderer.drawInterleavedForCoord's identical
        // fix — must match VectorSymbolLayerRenderer.uploadInstanceBuffer's draw-matrix offset or
        // collision boxes are computed at the wrong screen position for a world-copied tile.
        val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
        Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
        Matrix.multiplyMM(modelView, 0, mvCam, 0, tileLocal, 0)
        Matrix.multiplyMM(mvp, 0, proj, 0, modelView, 0)
        return mvp
    }

    fun screenBoundsForInstance(
        instances: FloatArray,
        instanceIndex: Int,
        mvp: FloatArray,
        overscale: Float,
        viewportW: Float,
        viewportH: Float,
        paddingPx: Float,
        billboard: Boolean,
        collisionScale: Float = SYMBOL_COLLISION_BOX_SCALE,
        halfWidthPxOverride: Float? = null,
        halfHeightPxOverride: Float? = null,
        centerOffsetXPxOverride: Float? = null,
        centerOffsetYPxOverride: Float? = null,
    ): FloatArray {
        val base = instanceIndex * SYMBOL_FLOATS_PER_INSTANCE
        val cu = instances[base]
        val cv = instances[base + 1]
        val hw = (halfWidthPxOverride ?: instances[base + 10]) * collisionScale
        val hh = (halfHeightPxOverride ?: instances[base + 11]) * collisionScale
        // Rule: collision-box-may-move-off-instance. Per-glyph SDF text emits one instance per
        // character, so the instance carrying the label's collision box is the *first glyph* and
        // sits at that glyph's centre, not the label's. Overriding the half extents alone would
        // centre a label-sized box on the first letter — off by roughly half the label width, so
        // long names would collide against space they do not occupy and leave their own tail
        // unprotected. The override lets the box keep the label's centre while the instance keeps
        // the glyph's.
        val offX = centerOffsetXPxOverride ?: instances[base + 12]
        val offY = centerOffsetYPxOverride ?: instances[base + 13]
        val rotRad = Math.toRadians(instances[base + 14].toDouble())
        val cosR = cos(rotRad).toFloat()
        val sinR = sin(rotRad).toFloat()
        val halfScale = 1f / (512f * overscale.coerceAtLeast(1e-6f))
        var minX = Float.POSITIVE_INFINITY
        var minY = Float.POSITIVE_INFINITY
        var maxX = Float.NEGATIVE_INFINITY
        var maxY = Float.NEGATIVE_INFINITY
        val corners = arrayOf(-1f to -1f, 1f to -1f, -1f to 1f, 1f to 1f)
        for ((qx, qy) in corners) {
            val rx = qx * hw
            val ry = qy * hh
            val cx = rx * cosR - ry * sinR + offX
            val cy = rx * sinR + ry * cosR + offY
            val (sx, sy) =
                if (billboard) {
                    projectBillboardCorner(cu, cv, cx, cy, mvp, viewportW, viewportH)
                } else {
                    val tu = cu + cx * halfScale
                    val tv = cv + cy * halfScale
                    projectTileUvToScreen(tu, tv, mvp, viewportW, viewportH)
                }
            // Rule: reject-unprojectable-corner. One bad corner invalidates the whole quad — a
            // partially projected box would claim a screen footprint the symbol does not have.
            // NaN propagates to the caller's viewport test, which rejects it (every comparison
            // against NaN is false), so the symbol simply never becomes a placement candidate.
            if (!sx.isFinite() || !sy.isFinite()) return UNPROJECTABLE_BOX.copyOf()
            minX = minOf(minX, sx)
            minY = minOf(minY, sy)
            maxX = maxOf(maxX, sx)
            maxY = maxOf(maxY, sy)
        }
        // Rule: bounded-collision-box.
        val loX = -SCREEN_BOX_CLAMP_MARGIN_PX
        val loY = -SCREEN_BOX_CLAMP_MARGIN_PX
        val hiX = viewportW + SCREEN_BOX_CLAMP_MARGIN_PX
        val hiY = viewportH + SCREEN_BOX_CLAMP_MARGIN_PX
        return floatArrayOf(
            (minX - paddingPx).coerceIn(loX, hiX),
            (minY - paddingPx).coerceIn(loY, hiY),
            (maxX + paddingPx).coerceIn(loX, hiX),
            (maxY + paddingPx).coerceIn(loY, hiY),
        )
    }

    /** See [MIN_PROJECTED_CLIP_W]. Copied per call so callers can never alias a shared array. */
    private val UNPROJECTABLE_BOX =
        floatArrayOf(Float.NaN, Float.NaN, Float.NaN, Float.NaN)

    private fun projectBillboardCorner(
        anchorU: Float,
        anchorV: Float,
        cornerPxX: Float,
        cornerPxY: Float,
        mvp: FloatArray,
        viewportW: Float,
        viewportH: Float,
    ): Pair<Float, Float> {
        val clipX = mvp[0] * anchorU + mvp[4] * anchorV + mvp[12]
        val clipY = mvp[1] * anchorU + mvp[5] * anchorV + mvp[13]
        val clipW = mvp[3] * anchorU + mvp[7] * anchorV + mvp[15]
        // Rule: reject-unprojectable-corner. Behind, on, or within rounding distance of the camera
        // plane — no screen position exists. Was `clipW == 0f`, which let ~1e-8 through.
        if (!(clipW > MIN_PROJECTED_CLIP_W)) return Float.NaN to Float.NaN
        // Match SYMBOL_VERT billboard branch: offset in clip space, then perspective divide.
        val offClipX = cornerPxX * (2f / viewportW) * clipW
        val offClipY = -cornerPxY * (2f / viewportH) * clipW
        val ndcX = (clipX + offClipX) / clipW
        val ndcY = (clipY + offClipY) / clipW
        return (ndcX + 1f) * 0.5f * viewportW to (1f - ndcY) * 0.5f * viewportH
    }

    private fun projectTileUvToScreen(
        tileU: Float,
        tileV: Float,
        mvp: FloatArray,
        viewportW: Float,
        viewportH: Float,
    ): Pair<Float, Float> {
        val ndcX = mvp[0] * tileU + mvp[4] * tileV + mvp[12]
        val ndcY = mvp[1] * tileU + mvp[5] * tileV + mvp[13]
        val ndcW = mvp[3] * tileU + mvp[7] * tileV + mvp[15]
        // Rule: reject-unprojectable-corner. See [projectBillboardCorner].
        if (!(ndcW > MIN_PROJECTED_CLIP_W)) return Float.NaN to Float.NaN
        val x = ndcX / ndcW
        val y = ndcY / ndcW
        return (x + 1f) * 0.5f * viewportW to (1f - y) * 0.5f * viewportH
    }
}
