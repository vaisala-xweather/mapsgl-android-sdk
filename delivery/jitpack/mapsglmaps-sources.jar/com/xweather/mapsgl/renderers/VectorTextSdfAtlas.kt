package com.xweather.mapsgl.renderers

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.opengl.GLES31
import com.xweather.mapsgl.util.MapsGLDebug
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

/**
 * Per-glyph signed-distance-field atlas for GLES symbol text.
 *
 * Ported from the Apple SDK's `GlyphManager` (release/1.7.0), which its own header notes mirrors the
 * JS SDK. The point of the port is the cache key: **one entry per character**, rasterized once at a
 * single size, with colour and halo applied by the shader at draw time.
 *
 * [VectorTextAtlas] instead keys on the whole rendered label —
 * `Key(text, fontSizePx, colorArgb, outlineArgb, bold, ...)` — so every label, at every size, in
 * every colour, is its own bitmap. Measured on a Pixel 9 with LayerCode.PLACES, those average
 * 437x125px, a 4096px atlas holds only ~220 of them, and `places` needs more: the atlas saturates
 * permanently and the working set grows with the number of labels on screen. Here the working set is
 * the *alphabet* — a few hundred glyphs for the life of the process, no matter how many labels are
 * drawn — which is why iOS never hits this at all.
 *
 * Glyphs are rasterized to alpha coverage, converted to a distance field by [VectorSdfEncoder], and
 * sampled by [VectorSymbolLayerRenderer]'s existing SDF fragment path (`u_raster_mode == 0`), which
 * already derives both the fill edge and the halo from the field. So text gets its outline computed
 * in-shader from the distance field rather than baked per label — the other half of why the Apple
 * implementation can share one glyph across every colour and outline style.
 */
internal object VectorTextSdfAtlas {

    private const val TAG = "VectorTextSdfAtlas"

    /**
     * Every glyph is rasterized at this size regardless of the paint's text size; callers scale
     * metrics by `targetPx / GLYPH_RASTER_PX` at draw time.
     *
     * 48px matches the Apple SDK's `GlyphManager.rasterPointSize`, whose comment explains the
     * choice: it gives the chamfer EDT enough source pixels to keep edge stair-stepping (inherent to
     * integer-pixel EDT input) well under 1% of cap height, compensating for an on-the-fly Core
     * Text / Paint path that cannot match Fontnik's pre-rendered sub-pixel edge estimation.
     *
     * This is also what removes [VectorTextAtlas.TEXT_SUPERSAMPLE]'s cost: supersampling existed
     * because a 14px whole-label raster has 1-2px letter strokes and cannot be made crisp. A
     * distance field is resolution-independent, so one 48px raster serves every display size.
     */
    const val GLYPH_RASTER_PX = 48

    /** Transparent margin around each glyph's ink, giving the EDT room to ramp outside the edge. */
    private val SDF_PAD_PX = VectorSdfEncoder.SDF_RADIUS_PX.toInt()

    private const val INITIAL_ATLAS_PX = 1024

    /**
     * Growth ceiling. Far above real demand: at 48px raster a Latin glyph cell is roughly 60x80px,
     * so 1024px already holds ~200 and 2048px ~800. Retained only so a CJK-heavy label set degrades
     * by dropping glyphs rather than by corrupting the atlas.
     */
    private const val MAX_ATLAS_PX = 4096

    /** Gutter between packed glyphs so linear filtering cannot sample a neighbour's field. */
    private const val PAD_PX = 2

    /** Bump when raster metrics or the field encoding change, to invalidate cached instance UVs. */
    private const val GLYPH_SDF_VERSION = 1

    /**
     * One character in one weight. Deliberately excludes size, colour, outline and outline width —
     * that exclusion is the whole point of the port. Mirrors the Apple SDK's `FontKey`, which drops
     * `pointSize` from its own `hash`/`==` with the note that it is "advisory metadata, not a cache
     * distinguisher".
     */
    data class GlyphKey(
        val codePoint: Int,
        val bold: Boolean,
        val version: Int = GLYPH_SDF_VERSION,
    )

    /**
     * Glyph placement metrics, in raster pixels at [GLYPH_RASTER_PX]. Scale by
     * `targetPx / GLYPH_RASTER_PX` for a given text size.
     *
     * [bearingXPx]/[bearingYPx] locate the atlas quad's top-left corner relative to the pen position
     * on the baseline, and both already include [SDF_PAD_PX]. That inclusion matters: the Apple port
     * documents that letting the pad fall outside the recorded metrics grows the atlas region past
     * the quad built from them, so the ink samples a region larger than the quad — glyphs shrink
     * inside their cells (reading as letters spaced too far apart) and the field slope rescales, so
     * the halo draws at the wrong width.
     */
    data class GlyphMetrics(
        val advancePx: Float,
        val bearingXPx: Float,
        val bearingYPx: Float,
        val widthPx: Int,
        val heightPx: Int,
    )

    /** [uv] is (u0, v0, u1, v1); empty for a whitespace glyph that advances but draws nothing. */
    data class SdfGlyph(
        val uv: FloatArray,
        val metrics: GlyphMetrics,
    ) {
        val isBlank: Boolean get() = metrics.widthPx <= 0 || metrics.heightPx <= 0
    }

    private val lock = Any()
    private val glyphs = ConcurrentHashMap<GlyphKey, SdfGlyph>()

    @Volatile
    private var textureId: Int = 0
    private var atlasSizePx: Int = INITIAL_ATLAS_PX
    private var cpuRgba: ByteBuffer? = null
    private var packX = PAD_PX
    private var packY = PAD_PX
    private var rowHeight = 0
    private var glUploadDirty = false
    private var atlasGeneration: Int = 0
    private var didWarnFull = false

    /** Reused staging buffer for the vertical flip in [uploadFullAtlas]. */
    private var uploadScratch: ByteBuffer? = null

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = GLYPH_RASTER_PX.toFloat()
        color = -0x1 // opaque white; only coverage is kept
    }

    fun currentGeneration(): Int = atlasGeneration

    /** Advance of [text] in raster pixels, without packing anything. */
    fun measureAdvancePx(text: String, bold: Boolean): Float {
        synchronized(lock) {
            fillPaint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            return fillPaint.measureText(text)
        }
    }

    /** Font ascent/descent in raster pixels, for vertical centring of a whole line. */
    fun lineMetricsPx(bold: Boolean): Pair<Float, Float> {
        synchronized(lock) {
            fillPaint.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            val fm = fillPaint.fontMetrics
            return fm.ascent to fm.descent
        }
    }

    /**
     * Returns the glyph for [key], rasterizing and packing it on first request.
     *
     * @return null only when the atlas is full and cannot grow, or the codepoint has no glyph.
     */
    fun ensureGlyph(key: GlyphKey): SdfGlyph? {
        glyphs[key]?.let { return it }
        synchronized(lock) {
            glyphs[key]?.let { return it }
            val glyph = rasterizeAndPack(key) ?: return null
            glyphs[key] = glyph
            return glyph
        }
    }

    fun onGlContextLost() {
        synchronized(lock) {
            textureId = 0
            glUploadDirty = true
        }
    }

    /** Drops every glyph and the backing surface; the next request re-rasterizes on demand. */
    fun reset() {
        synchronized(lock) {
            glyphs.clear()
            packX = PAD_PX
            packY = PAD_PX
            rowHeight = 0
            atlasSizePx = INITIAL_ATLAS_PX
            cpuRgba = null
            didWarnFull = false
            glUploadDirty = true
            atlasGeneration++
        }
    }

    /** Must run on the GL thread. @return the atlas texture, or 0 if it could not be created. */
    fun ensureLoadedOnGlThread(): Int {
        synchronized(lock) {
            val existing = textureId
            if (existing != 0 && GLES31.glIsTexture(existing)) {
                if (glUploadDirty) {
                    GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, existing)
                    uploadFullAtlas(existing)
                    GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0)
                    glUploadDirty = false
                }
                return existing
            }
            ensureCpuBuffer()
            val ids = IntArray(1)
            GLES31.glGenTextures(1, ids, 0)
            val tid = ids[0]
            if (tid == 0) return 0
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, tid)
            // Linear, no mipmaps: a distance field must be interpolated, not pre-averaged. Minified
            // mip levels blur the field across the edge, which shifts where the shader's fill and
            // halo thresholds land and makes small text bleed. Resolution independence is what the
            // field itself provides, so mips buy nothing here (unlike VectorTextAtlas's raster
            // glyphs, which need them).
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
            uploadFullAtlas(tid)
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0)
            textureId = tid
            glUploadDirty = false
            return tid
        }
    }

    /**
     * Uploads the CPU surface bottom-row-first.
     *
     * GL's first texture row is the texture's bottom, while the pack cursor and [blitField] are
     * top-origin. [VectorTextAtlas.uploadFullAtlasToGl] resolves that the same way, which is what
     * makes the shared `1 - y/size` UV formula in [rasterizeAndPack] correct. Uploading straight
     * instead put every glyph's UV rect at the opposite end of the texture, sampling blank atlas —
     * labels resolved, packed, and drew nothing at all.
     */
    private fun uploadFullAtlas(tid: Int) {
        val src = cpuRgba ?: return
        val size = atlasSizePx
        val rowBytes = size * 4
        var scratch = uploadScratch
        if (scratch == null || scratch.capacity() < size * rowBytes) {
            scratch = ByteBuffer.allocateDirect(size * rowBytes).order(ByteOrder.nativeOrder())
            uploadScratch = scratch
        }
        val row = ByteArray(rowBytes)
        scratch.clear()
        for (y in size - 1 downTo 0) {
            src.get(y * rowBytes, row, 0, rowBytes)
            scratch.put(row, 0, rowBytes)
        }
        scratch.flip()
        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D, 0, GLES31.GL_RGBA,
            size, size, 0,
            GLES31.GL_RGBA, GLES31.GL_UNSIGNED_BYTE, scratch,
        )
        scratch.clear()
    }

    private fun ensureCpuBuffer() {
        if (cpuRgba == null || cpuRgba!!.capacity() != atlasSizePx * atlasSizePx * 4) {
            cpuRgba = ByteBuffer.allocateDirect(atlasSizePx * atlasSizePx * 4)
                .order(ByteOrder.nativeOrder())
        }
    }

    /** Caller must hold [lock]. */
    private fun rasterizeAndPack(key: GlyphKey): SdfGlyph? {
        ensureCpuBuffer()
        fillPaint.typeface = if (key.bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        val text = String(Character.toChars(key.codePoint))
        val advance = fillPaint.measureText(text)
        val ink = Rect()
        fillPaint.getTextBounds(text, 0, text.length, ink)
        if (ink.width() <= 0 || ink.height() <= 0) {
            // Whitespace and zero-width codepoints: advance only, nothing to pack.
            return SdfGlyph(
                uv = floatArrayOf(0f, 0f, 0f, 0f),
                metrics = GlyphMetrics(advance, 0f, 0f, 0, 0),
            )
        }
        val w = ink.width() + SDF_PAD_PX * 2
        val h = ink.height() + SDF_PAD_PX * 2
        val alpha = rasterizeAlpha(text, ink, w, h) ?: return null
        val field = VectorSdfEncoder.encode(alpha, w, h)
        if (!ensurePackRoom(w, h)) {
            if (!didWarnFull) {
                didWarnFull = true
                MapsGLDebug.logW(
                    TAG,
                    "glyph atlas full at ${atlasSizePx}px; dropping U+${key.codePoint.toString(16)} " +
                        "and further new glyphs (this should not happen for Latin text)",
                )
            }
            return null
        }
        val x = packX
        val y = packY
        blitField(field, x, y, w, h)
        packX += w + PAD_PX
        rowHeight = max(rowHeight, h)
        glUploadDirty = true
        val a = atlasSizePx.toFloat()
        return SdfGlyph(
            // Same V convention as [VectorTextAtlas.uvRectForPackRect]: pack coordinates are y-down
            // while the quad's V runs the other way, so V is flipped and the glyph's top row is
            // emitted first. Diverging here renders text upside down.
            uv = floatArrayOf(x / a, 1f - y / a, (x + w) / a, 1f - (y + h) / a),
            metrics = GlyphMetrics(
                advancePx = advance,
                bearingXPx = (ink.left - SDF_PAD_PX).toFloat(),
                bearingYPx = (ink.top - SDF_PAD_PX).toFloat(),
                widthPx = w,
                heightPx = h,
            ),
        )
    }

    /**
     * @return row-major coverage, or null if the glyph could not be rasterized.
     *
     * Rasterizes into ARGB_8888 and keeps the alpha channel, rather than drawing straight into an
     * ALPHA_8 bitmap: [Canvas] rejects ALPHA_8 as a drawing target ("Unsupported Bitmap.Config"),
     * and because glyph packing runs on the instance-build worker the resulting exception was
     * swallowed by the executor — every label silently produced no glyphs, with nothing in the log
     * to say so.
     */
    private fun rasterizeAlpha(text: String, ink: Rect, w: Int, h: Int): ByteArray? {
        val bmp =
            try {
                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            } catch (e: OutOfMemoryError) {
                MapsGLDebug.logW(TAG, "glyph raster allocation failed (${w}x$h): ${e.message}")
                return null
            }
        try {
            val canvas = Canvas(bmp)
            // Shift so the ink's top-left lands at (SDF_PAD_PX, SDF_PAD_PX).
            canvas.drawText(
                text,
                (SDF_PAD_PX - ink.left).toFloat(),
                (SDF_PAD_PX - ink.top).toFloat(),
                fillPaint,
            )
            val pixels = IntArray(w * h)
            bmp.getPixels(pixels, 0, w, 0, 0, w, h)
            val out = ByteArray(w * h)
            for (i in pixels.indices) out[i] = (pixels[i] ushr 24).toByte()
            return out
        } catch (t: Throwable) {
            MapsGLDebug.logW(TAG, "glyph rasterization failed for '$text': $t")
            return null
        } finally {
            bmp.recycle()
        }
    }

    private fun ensurePackRoom(w: Int, h: Int): Boolean {
        if (packX + w + PAD_PX > atlasSizePx) {
            packX = PAD_PX
            packY += rowHeight + PAD_PX
            rowHeight = 0
        }
        if (packY + h + PAD_PX > atlasSizePx) {
            if (!growAtlas()) return false
            if (packY + h + PAD_PX > atlasSizePx) return false
        }
        return true
    }

    /**
     * Doubles the atlas and repacks from the origin.
     *
     * Deliberately does NOT preserve the old pixels: UVs are normalized by [atlasSizePx], so
     * doubling invalidates every UV already handed out, which means the glyph map has to be cleared
     * and every live glyph re-rasterized regardless. Copying the old surface would therefore be
     * wasted work whose only lasting effect is stale ink sitting in regions the repack has not
     * reached yet, where the gutter can sample it. Growth is a reset at a larger size.
     *
     * Cheap because it happens at most twice per process, and only for a glyph repertoire far
     * larger than Latin — the whole reason for the per-character key is that the working set is the
     * alphabet, not the label count. Callers see it as an [atlasGeneration] bump, which instance
     * caches already fold into their keys.
     */
    private fun growAtlas(): Boolean {
        val newSize = (atlasSizePx * 2).coerceAtMost(MAX_ATLAS_PX)
        if (newSize <= atlasSizePx) return false
        val grown =
            try {
                ByteBuffer.allocateDirect(newSize * newSize * 4).order(ByteOrder.nativeOrder())
            } catch (e: OutOfMemoryError) {
                MapsGLDebug.logW(TAG, "glyph atlas growth to ${newSize}px failed: ${e.message}")
                return false
            }
        grown.position(0)
        cpuRgba = grown
        atlasSizePx = newSize
        glyphs.clear()
        packX = PAD_PX
        packY = PAD_PX
        rowHeight = 0
        atlasGeneration++
        glUploadDirty = true
        return true
    }

    /** Writes the field into all four channels, matching the sprite SDF atlas the shader samples. */
    private fun blitField(field: ByteArray, dstX: Int, dstY: Int, w: Int, h: Int) {
        val buf = cpuRgba ?: return
        for (y in 0 until h) {
            var dst = ((dstY + y) * atlasSizePx + dstX) * 4
            var src = y * w
            for (x in 0 until w) {
                val v = field[src]
                buf.put(dst, v)
                buf.put(dst + 1, v)
                buf.put(dst + 2, v)
                buf.put(dst + 3, v)
                dst += 4
                src++
            }
        }
    }
}
