package com.xweather.mapsgl.renderers

import java.util.concurrent.ConcurrentHashMap

/**
 * Cross-layer label collision: lets sibling symbol layers see each other's claimed screen space.
 *
 * Each [VectorSymbolLayerRenderer] owns its own [VectorSymbolScreenPlacer], which is correct for
 * fade state (one layer's labels appearing and disappearing is that layer's business) but means a
 * composite's sub-layers place independently. `LayerCode.PLACES` is four such layers — country,
 * state, city, neighbourhood — so at world zoom their labels sat on top of each other. That was
 * previously masked: the whole-label atlas could only hold ~220 labels, so most never drew.
 *
 * Layers in the same group publish the boxes they placed, and read their siblings' as space that is
 * already taken.
 *
 * **Staleness is deliberate.** A layer's entry is replaced on each publish and never expires, so a
 * reader may see boxes from the previous frame rather than the current one. That was the choice over
 * a frame token or a time window: there is no shared per-frame signal across renderers, and an
 * expiry window makes siblings periodically stop colliding, which reintroduces exactly the flicker
 * this work removed. Label positions change slowly relative to the frame rate, so a frame of lag
 * costs nothing visible and adds useful hysteresis.
 */
internal object VectorSymbolCollisionGroups {

    /**
     * Cap on boxes retained per layer. A layer publishing more than this has more labels on screen
     * than collision could meaningfully arbitrate anyway, and the cap keeps a pathological tile set
     * from pinning memory. Comfortably above any real viewport's placed-label count.
     */
    private const val MAX_BOXES_PER_LAYER = 4_096

    private val boxesByGroup = ConcurrentHashMap<String, ConcurrentHashMap<String, List<FloatArray>>>()

    /** Replaces [layerId]'s claimed boxes within [groupId]. */
    fun publish(groupId: String, layerId: String, boxes: List<FloatArray>) {
        val group = boxesByGroup.getOrPut(groupId) { ConcurrentHashMap() }
        group[layerId] = if (boxes.size <= MAX_BOXES_PER_LAYER) {
            boxes
        } else {
            boxes.subList(0, MAX_BOXES_PER_LAYER).toList()
        }
    }

    /** Boxes claimed by every layer in [groupId] except [layerId] itself. */
    fun foreignBoxes(groupId: String, layerId: String): List<FloatArray> {
        val group = boxesByGroup[groupId] ?: return emptyList()
        if (group.isEmpty()) return emptyList()
        var out: ArrayList<FloatArray>? = null
        for ((otherLayerId, boxes) in group) {
            if (otherLayerId == layerId || boxes.isEmpty()) continue
            val list = out ?: ArrayList<FloatArray>(boxes.size).also { out = it }
            list.addAll(boxes)
        }
        return out ?: emptyList()
    }

    /** Drops [layerId]'s claims — call when the layer is removed or its renderer is released. */
    fun remove(groupId: String, layerId: String) {
        val group = boxesByGroup[groupId] ?: return
        group.remove(layerId)
        if (group.isEmpty()) boxesByGroup.remove(groupId)
    }

    fun clear() = boxesByGroup.clear()
}
