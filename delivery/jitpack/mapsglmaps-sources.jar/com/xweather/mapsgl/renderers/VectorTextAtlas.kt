package com.xweather.mapsgl.renderers

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.opengl.GLES31
import android.os.SystemClock
import com.xweather.mapsgl.util.MapsGLDebug
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.ceil
import kotlin.math.max

/**
 * Dynamic CPU-rasterized label atlas for GLES symbol text ([VectorSymbolLayerRenderer]).
 * Labels are drawn with Android [Paint] on a background thread, packed into a single
 * [GL_TEXTURE_2D], and sampled in raster mode (premultiplied-style RGBA quads).
 */
internal object VectorTextAtlas {

    private const val TAG = "VectorTextAtlas"
    private const val INITIAL_ATLAS_PX = 1024
    /**
     * Hard cap at 4096px (64MB RGBA). 8192px is 256MB alone, and [growAtlas] briefly keeps the
     * old 64MB buffer alive while allocating the new one — confirmed live crash on
     * DataQueryTextActivity / wind_speeds_text: `ByteBuffer.allocateDirect(268435475)` threw
     * OutOfMemoryError on MapboxRenderThr and aborted via pending JNI exception in Map.render().
     * When full at this cap, [packGlyph] drops the new label instead of growing further.
     */
    private const val MAX_ATLAS_PX = 4096
    /**
     * Gutter between packed glyphs (linear filtering needs margin past UV inset). Wider than a
     * bare minimum since mipmapping ([ensureLoadedOnGlThread]) blends a progressively larger
     * neighborhood at lower mip levels — too little gutter would let adjacent glyphs bleed into
     * each other once minified.
     */
    private const val PAD_PX = 10
    /**
     * Rule: place-label-text-scale-tuning. Glyphs are rasterized at [TEXT_SUPERSAMPLE]x the final
     * on-screen size, then reported back to callers (and thus placed/sized on-screen) at the
     * original 1x dimensions — the GPU minifies the higher-res texture back down when sampling,
     * giving anti-aliasing far more source detail to work with. At small font sizes (the ~14px
     * place-city floor) a 1x rasterization has letter strokes only 1-2 raw pixels wide, so no
     * amount of color/outline tuning can produce a crisp fill; supersampling is what actually fixes
     * that. Paired with mipmapping ([ensureLoadedOnGlThread]) so minification blends properly
     * instead of aliasing.
     *
     * Kept at 2 (was 3): 3× with a 14px floor produced ~140px-tall atlas slots and filled the
     * 4096 atlas during multi-tile place-city builds, dropping in-tile majors after UV ownership
     * was already correct (Columbus emitted then vanished / collided with stale UVs).
     */
    private const val TEXT_SUPERSAMPLE = 2
    /** Bump when glyph padding / metrics change (invalidates cached atlas keys). */
    private const val GLYPH_RASTER_VERSION = 6

    data class Key(
        val text: String,
        val fontSizePx: Int,
        val colorArgb: Int,
        val outlineArgb: Int?,
        val bold: Boolean,
        /** Per-layer outline-thickness multiplier (see [com.xweather.mapsgl.renderers.VectorSymbolPlacementDefaults.textOutlineWidthScale]). */
        val outlineWidthScale: Float = 1f,
        /**
         * When true, rasterize with reduced horizontal edge pad for side-by-side digit/unit
         * composition ([VectorTextValueCompose]). Must participate in equality so composable and
         * whole-string packs of the same character do not share a UV rect.
         */
        val tightHorizontalPad: Boolean = false,
        val rasterVersion: Int = GLYPH_RASTER_VERSION,
    )

    /** One line in a stacked label (JS `format` / newline layout). */
    data class StackedLineKey(
        val text: String,
        val fontSizePx: Int,
        val colorArgb: Int,
        val outlineArgb: Int?,
        val bold: Boolean,
    )

    data class MultiLineKey(
        val lines: List<StackedLineKey>,
        val lineGapPx: Float,
        val rasterVersion: Int = GLYPH_RASTER_VERSION,
    )

    data class Glyph(
        val widthPx: Int,
        val heightPx: Int,
        val uv: FloatArray,
    )

    @Volatile
    private var textureId: Int = 0

    @Volatile
    private var atlasSizePx: Int = INITIAL_ATLAS_PX

    /**
     * Rule: atlas-grow-invalidates-baked-uv. [growAtlas] rescales the UV rects held in [glyphs] /
     * [multiLineGlyphs] so *future* [ensureGlyph] calls stay correct — but a [VectorSymbolLayerRenderer]
     * bakes a glyph's UV directly into its per-tile instance FloatArray at build time, then caches that
     * whole buffer (JVM + native) keyed by tile/style/mesh/time, with no atlas dependency at all. A
     * batch built and cached *before* a later growth event keeps its now-stale, pre-growth UV forever —
     * sampling whatever unrelated glyph ended up at that texture location after the resize. Bumped
     * inside [growAtlas]; callers fold this into their own instance-cache key so a growth event misses
     * (and rebuilds against the current, correctly-scaled glyph) instead of replaying stale pixels.
     */
    @Volatile
    private var atlasGeneration: Int = 0

    fun currentGeneration(): Int = atlasGeneration

    private val glyphs = java.util.concurrent.ConcurrentHashMap<Key, Glyph>()
    private val multiLineGlyphs = java.util.concurrent.ConcurrentHashMap<MultiLineKey, Glyph>()
    private val lock = Any()

    private var packX = PAD_PX
    private var packY = PAD_PX
    private var rowHeight = 0

    // Rule: cpu-atlas-off-heap. At MAX_ATLAS_PX this buffer is 64MB RGBA, and growAtlas() briefly
    // needs the old AND new buffer alive at once (e.g. 16MB + 64MB growing 2048->4096). Confirmed
    // live: a plain on-heap ByteArray here crashed the process with OutOfMemoryError while panning
    // a fully-loaded Europe view to the USA with a sampled value layer active (place-city shares this
    // atlas). A direct ByteBuffer keeps pixels in native memory, same as [uploadScratch] for GL
    // upload staging — but allocateDirect can still throw under process pressure, so growAtlas
    // must catch OOM and refuse growth rather than aborting the render thread.
    @Volatile
    private var cpuRgba: ByteBuffer? = null

    @Volatile
    private var glUploadDirty = false

    /** CPU atlas regions touched since the last GL upload (incremental [glTexSubImage2D]). */
    private val dirtyRects = ArrayList<IntArray>(16)

    @Volatile
    private var needsFullGlUpload = false

    private var uploadScratch: ByteBuffer? = null

    fun lookupUv(key: Key): FloatArray? = glyphs[key]?.uv

    fun glyphSize(key: Key): Pair<Int, Int>? =
        glyphs[key]?.let { it.widthPx to it.heightPx }

    fun ensureGlyph(key: Key): Glyph? {
        if (key.text.isEmpty()) return null
        glyphs[key]?.let { return it }
        synchronized(lock) {
            glyphs[key]?.let { return it }
            val glyph = packGlyph(rasterize(key)) ?: return null
            glyphs[key] = glyph
            return glyph
        }
    }

    /**
     * Like [ensureGlyph], but with reduced horizontal edge pad so side-by-side digit/unit
     * composition ([VectorTextValueCompose]) does not leave large transparent gaps between segments.
     * Vertical pad is unchanged so outline strokes still clear the atlas gutter.
     */
    fun ensureComposableGlyph(key: Key): Glyph? {
        val composeKey = if (key.tightHorizontalPad) key else key.copy(tightHorizontalPad = true)
        if (composeKey.text.isEmpty()) return null
        glyphs[composeKey]?.let { return it }
        synchronized(lock) {
            glyphs[composeKey]?.let { return it }
            val glyph = packGlyph(rasterize(composeKey)) ?: return null
            glyphs[composeKey] = glyph
            return glyph
        }
    }

    /** 1x CSS-px advance of [text] for [fontSizePx]/[bold] (matches reported [Glyph.widthPx] scale). */
    fun measureTextAdvancePx(text: String, fontSizePx: Int, bold: Boolean): Float {
        if (text.isEmpty()) return 0f
        val paint = createFillPaint(fontSizePx.coerceAtLeast(1), uncheckedColorBlack, bold)
        return paint.measureText(text).coerceAtLeast(0f)
    }

    fun ensureMultiLineGlyph(lines: List<StackedLineKey>, lineGapPx: Float): Glyph? {
        if (lines.isEmpty() || lines.all { it.text.isEmpty() }) return null
        val key = MultiLineKey(lines, lineGapPx)
        multiLineGlyphs[key]?.let { return it }
        synchronized(lock) {
            multiLineGlyphs[key]?.let { return it }
            return packMultiLineGlyph(key)
        }
    }

    /**
     * Measures what [ensureMultiLineGlyph] would pack for these lines, without rasterizing or
     * touching the atlas — lets callers size a stable COLLISION box (e.g. a placeholder value
     * string) independently of the glyph actually drawn. Mirrors [rasterizeStacked]'s sizing math
     * and reports 1x dimensions, same convention as [Glyph.widthPx]/[Glyph.heightPx].
     */
    fun measureMultiLineSizePx(lines: List<StackedLineKey>, lineGapPx: Float): Pair<Int, Int>? {
        val active = lines.filter { it.text.isNotEmpty() }
        if (active.isEmpty()) return null
        val gap = lineGapPx.coerceAtLeast(0f)
        var maxFontPx = 1
        var contentH = 0f
        var maxW = 0f
        for ((index, line) in active.withIndex()) {
            val fontSizePx = line.fontSizePx * TEXT_SUPERSAMPLE
            maxFontPx = max(maxFontPx, fontSizePx)
            val paint = createFillPaint(fontSizePx, line.colorArgb, line.bold)
            val fm = paint.fontMetrics
            val lineW = paint.measureText(line.text).coerceAtLeast(1f)
            maxW = max(maxW, lineW)
            if (index > 0) contentH += gap
            contentH += fm.descent - fm.ascent
        }
        val pad = edgePadPx(maxFontPx).toFloat()
        val w = ceil(maxW + pad * 2f).toInt().coerceAtLeast(1)
        val h = ceil(contentH + pad * 2f).toInt().coerceAtLeast(1)
        return (w / TEXT_SUPERSAMPLE).coerceAtLeast(1) to (h / TEXT_SUPERSAMPLE).coerceAtLeast(1)
    }

    fun ensureLoadedOnGlThread(): Int {
        if (textureId != 0 && GLES31.glIsTexture(textureId)) {
            flushPendingGlUpload(textureId)
            return textureId
        }
        synchronized(lock) {
            if (textureId != 0 && GLES31.glIsTexture(textureId)) {
                flushPendingGlUpload(textureId)
                return textureId
            }
            textureId = 0
            ensureCpuBuffer()
            val texIds = IntArray(1)
            GLES31.glGenTextures(1, texIds, 0)
            val tid = texIds[0]
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, tid)
            // Rule: place-label-text-scale-tuning. Glyphs are rasterized at TEXT_SUPERSAMPLE-times
            // the on-screen size (see that constant's KDoc) — mipmapping lets the GPU properly blend
            // that extra detail down to the actual displayed size instead of point-sampling a coarse
            // 2x2 neighborhood (which would alias rather than smooth).
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR_MIPMAP_LINEAR)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_S, GLES31.GL_CLAMP_TO_EDGE)
            GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_WRAP_T, GLES31.GL_CLAMP_TO_EDGE)
            uploadFullAtlasToGl(tid)
            GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0)
            textureId = tid
            glUploadDirty = false
            needsFullGlUpload = false
            dirtyRects.clear()
            return textureId
        }
    }

    fun onGlContextLost() {
        synchronized(lock) {
            textureId = 0
            glUploadDirty = true
            needsFullGlUpload = true
            dirtyRects.clear()
        }
    }

    fun reset() = resetInternal(preserveCapacity = false)

    /**
     * @param preserveCapacity keeps the current [atlasSizePx] instead of shrinking back to
     * [INITIAL_ATLAS_PX]. Used by compaction, where re-growing is pure loss: [ensurePackRoom] resumes
     * at `packY = oldAtlasSizePx` after a doubling (it must, or it would pack over glyphs still being
     * referenced), so climbing 1024 -> 2048 -> 4096 again leaves the right-hand strip of every
     * earlier square unusable. Compacting in place gives one clean, fully packable surface, which is
     * the difference between compacting once and compacting repeatedly as the same labels fail to fit.
     */
    private fun resetInternal(preserveCapacity: Boolean) {
        synchronized(lock) {
            glyphs.clear()
            multiLineGlyphs.clear()
            packX = PAD_PX
            packY = PAD_PX
            rowHeight = 0
            val targetSizePx = if (preserveCapacity) atlasSizePx else INITIAL_ATLAS_PX
            val existing = cpuRgba
            if (!preserveCapacity || existing == null ||
                existing.capacity() != targetSizePx * targetSizePx * 4
            ) {
                atlasSizePx = targetSizePx
                cpuRgba = ByteBuffer.allocateDirect(atlasSizePx * atlasSizePx * 4)
                    .order(ByteOrder.nativeOrder())
            } else {
                // Same surface, just logically empty — zeroing keeps stale pixels from bleeding
                // through the padding gutters of newly packed glyphs.
                existing.clear()
                while (existing.remaining() >= 8) existing.putLong(0L)
                while (existing.hasRemaining()) existing.put(0)
                existing.clear()
            }
            glUploadDirty = true
            needsFullGlUpload = true
            dirtyRects.clear()
            atlasGeneration++
            if (!preserveCapacity) {
                // Rule: saturated-atlas-holds-still. A real invalidation (GL context loss, layer
                // removed, a runtime text-size change) makes the previous demand estimate
                // meaningless, so re-arm compaction instead of serving out a stale hold.
                consecutiveCompactions = 0
                saturatedUntilMs = 0L
                packsSinceCompaction = 0
            }
        }
    }

    /**
     * Glyphs successfully packed since the last compaction. Compaction re-arms on real progress
     * rather than on [atlasGeneration]: compaction preserves capacity and so no longer grows, which
     * means the generation stops changing and a generation-based guard would allow exactly one
     * compaction for the lifetime of the atlas — after which every further label is dropped forever.
     */
    private var packsSinceCompaction: Int = 0

    /** Rule: saturated-atlas-holds-still. Compactions since the last one that actually relieved pressure. */
    private var consecutiveCompactions: Int = 0

    /**
     * Rule: saturated-atlas-holds-still. [SystemClock.elapsedRealtime] until which compaction is
     * suspended because the live set does not fit. Zero when not saturated.
     */
    private var saturatedUntilMs: Long = 0L

    /** Throttles the dropped-label warning, which would otherwise fire per label per frame once saturated. */
    private var lastDropLogMs: Long = 0L

    /**
     * How much new packing must have happened before compacting again. Guards the degenerate case
     * where the live set genuinely does not fit: there, compacting repeatedly would rasterize the
     * same labels over and over for nothing. Above this, churn is real (panning, a size change) and
     * reclaiming is worthwhile.
     */
    private const val MIN_PACKS_BEFORE_RECOMPACT = 32

    /**
     * Rule: saturated-atlas-holds-still. Consecutive compactions allowed before the atlas concludes
     * that the live set simply does not fit and stops compacting.
     *
     * [MIN_PACKS_BEFORE_RECOMPACT] only catches the case where *nothing* was packed since the last
     * compaction, which never happens when demand merely exceeds capacity: measured on a Pixel 9
     * with LayerCode.PLACES at the default world view, ~220 labels pack, the 4096px atlas exhausts,
     * everything is dropped, all ~220 re-rasterize, and it exhausts again — every ~2.3 seconds,
     * indefinitely. Since each compaction wipes every glyph, labels vanish and reappear as they are
     * re-rasterized: that cycle IS the reported "place labels blink on and off forever", and it held
     * the process at ~143% of one CPU core with a stationary camera.
     *
     * Two compactions is enough to tell real churn (panning, a text-size change, where reclaiming
     * dead entries genuinely helps) from saturation (where it buys nothing).
     */
    private const val MAX_CONSECUTIVE_COMPACTIONS = 2

    /**
     * Rule: saturated-atlas-holds-still. How long to keep the atlas untouched once saturated.
     *
     * While held, [packGlyph] drops labels that do not fit instead of wiping the ones that do. That
     * is a real trade — some labels are missing at extreme density — but it is strictly better than
     * the alternative: the glyphs that did fit keep their UVs, so instance caches (which fold
     * [atlasGeneration] into their keys) stay valid, nothing re-rasterizes, and the map holds a
     * steady image instead of flashing. Long enough that a recovery attempt is invisible rather
     * than a visible pulse; short enough that panning to a sparser area restores full labels on its
     * own. A real invalidation ([reset], GL context loss, a text-size change) re-arms immediately.
     */
    private const val SATURATED_HOLD_MS = 30_000L

    /** Rule: saturated-atlas-holds-still. Minimum gap between dropped-label warnings. */
    private const val DROP_LOG_INTERVAL_MS = 5_000L

    /**
     * Reclaims the atlas when it is genuinely out of room, so exhaustion is recoverable instead of
     * permanent.
     *
     * Packing is append-only with no per-entry eviction, so everything ever rasterized stays resident:
     * labels for areas long since scrolled away, and every prior size of every label after a runtime
     * text-size change. Height scales with font size (and again by `VECTOR_SYMBOL_GL_PIXEL_SCALE`),
     * so raising place-label size roughly quadruples the area each label costs -- a few hundred names
     * at a larger size exhaust the 4096px cap. Once that happened, `ensurePackRoom` refused forever
     * and [com.xweather.mapsgl.renderers.VectorTextLayout] silently skipped those lines, so place
     * names never returned even after panning somewhere new.
     *
     * Dropping everything and re-packing on demand is the cheap fix: only glyphs still being drawn
     * get rasterized again, which is exactly the live set. Safe because [reset] bumps
     * [atlasGeneration] and instance caches fold that into their keys, so batches holding pre-reset
     * UVs miss and rebuild.
     *
     * Caller must hold [lock].
     *
     * @return true when the atlas was reclaimed and the pack is worth retrying.
     */
    private fun compactForRetryLocked(): Boolean {
        // Still room to grow — not actually exhausted, let ensurePackRoom take the normal path.
        if (atlasSizePx < MAX_ATLAS_PX) return false
        // Nothing meaningful packed since the last compaction: the live set does not fit, so
        // compacting again would just re-rasterize the same labels and drop them anyway.
        if (packsSinceCompaction < MIN_PACKS_BEFORE_RECOMPACT) return false
        // Rule: saturated-atlas-holds-still. Already concluded the live set does not fit; keep the
        // packed glyphs and their UVs exactly as they are so the image stays steady.
        val nowMs = SystemClock.elapsedRealtime()
        if (nowMs < saturatedUntilMs) return false
        consecutiveCompactions++
        if (consecutiveCompactions > MAX_CONSECUTIVE_COMPACTIONS) {
            saturatedUntilMs = nowMs + SATURATED_HOLD_MS
            consecutiveCompactions = 0
            MapsGLDebug.logW(
                TAG,
                "atlas saturated at ${atlasSizePx}px ($packsSinceCompaction packs fit); the live " +
                    "label set does not fit, so holding it steady for ${SATURATED_HOLD_MS}ms and " +
                    "dropping labels that do not fit rather than wiping the ones that do",
            )
            return false
        }
        MapsGLDebug.logW(
            TAG,
            "atlas exhausted at ${atlasSizePx}px after $packsSinceCompaction packs; compacting",
        )
        resetInternal(preserveCapacity = true)
        packsSinceCompaction = 0
        return true
    }

    private fun packGlyph(bmp: Bitmap): Glyph? {
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0) {
            bmp.recycle()
            return null
        }
        if (!ensurePackRoom(w, h) && !(compactForRetryLocked() && ensurePackRoom(w, h))) {
            bmp.recycle()
            // Rule: saturated-atlas-holds-still. Throttled: once saturated this is the normal path
            // for every label past capacity, on every build, so logging each one buries the log.
            val nowMs = SystemClock.elapsedRealtime()
            if (nowMs - lastDropLogMs >= DROP_LOG_INTERVAL_MS) {
                lastDropLogMs = nowMs
                MapsGLDebug.logW(TAG, "atlas full; dropped label ${w}x$h (throttled)")
            }
            return null
        }
        packsSinceCompaction++
        val x = packX
        val y = packY
        blitBitmapToCpuAtlas(bmp, x, y)
        bmp.recycle()
        packX += w + PAD_PX
        rowHeight = max(rowHeight, h)
        markDirtyRect(x, y, w, h)
        val uv = uvRectForPackRect(x, y, w, h)
        // Rule: place-label-text-scale-tuning. The atlas region (UV rect) reflects the full
        // supersampled pixel footprint, but callers place/size the glyph on-screen using
        // widthPx/heightPx — report those at 1x so the on-screen quad stays the originally-intended
        // size while the underlying texture data has TEXT_SUPERSAMPLE-times more detail.
        return Glyph(
            (w / TEXT_SUPERSAMPLE).coerceAtLeast(1),
            (h / TEXT_SUPERSAMPLE).coerceAtLeast(1),
            uv,
        )
    }

    private fun packMultiLineGlyph(key: MultiLineKey): Glyph? {
        val bmp = rasterizeStacked(key.lines, key.lineGapPx)
        val glyph = packGlyph(bmp) ?: return null
        multiLineGlyphs[key] = glyph
        return glyph
    }

    /** Half-texel inset when the glyph span is wide enough; avoids linear-filter bleed. */
    private fun uvRectForPackRect(x: Int, y: Int, w: Int, h: Int): FloatArray {
        val aw = atlasSizePx.toFloat()
        val u0 = x / aw
        val u1 = (x + w) / aw
        val vBottom = 1f - (y + h) / aw
        val vTop = 1f - y / aw
        val inset = 0.5f / aw
        val u0i = if (u1 - u0 > inset * 3f) u0 + inset else u0
        val u1i = if (u1 - u0 > inset * 3f) u1 - inset else u1
        val vTopi = if (vTop - vBottom > inset * 3f) vTop - inset else vTop
        val vBottomi = if (vTop - vBottom > inset * 3f) vBottom + inset else vBottom
        // Match [VectorRasterSpriteAtlas]: billboard quad swaps V corners (PNG y-down pack coords).
        return floatArrayOf(u0i, vTopi, u1i, vBottomi)
    }

    private fun ensurePackRoom(w: Int, h: Int): Boolean {
        if (packX + w + PAD_PX > atlasSizePx) {
            packX = PAD_PX
            packY += rowHeight + PAD_PX
            rowHeight = 0
        }
        if (packY + h + PAD_PX > atlasSizePx) {
            if (atlasSizePx >= MAX_ATLAS_PX) return false
            // growAtlas() preserves all already-packed glyph pixels at their existing (x, y)
            // coordinates in the new, larger buffer — resuming the cursor at PAD_PX would pack the
            // next glyph right on top of that still-referenced region. Resume below the fully-used
            // old square instead.
            val oldAtlasSizePx = atlasSizePx
            if (!growAtlas()) return false
            packX = PAD_PX
            packY = oldAtlasSizePx
            rowHeight = 0
            if (packY + h + PAD_PX > atlasSizePx) return false
        }
        return true
    }

    /** @return false if growth was refused (at cap or OOM); caller must drop the glyph. */
    private fun growAtlas(): Boolean {
        val newSize = (atlasSizePx * 2).coerceAtMost(MAX_ATLAS_PX)
        if (newSize <= atlasSizePx) return false
        val oldSize = atlasSizePx
        val old = cpuRgba
        val grown = try {
            ByteBuffer.allocateDirect(newSize * newSize * 4).order(ByteOrder.nativeOrder())
        } catch (oom: OutOfMemoryError) {
            MapsGLDebug.logW(TAG, "growAtlas OOM to ${newSize}px; keeping ${atlasSizePx}px")
            return false
        }
        if (old != null) {
            // Absolute-indexed get/put (not position-based) — old/grown are both direct buffers,
            // copied through a small per-row scratch array so the two full-size buffers are never
            // additionally duplicated on the JVM heap just to move bytes between them.
            val rowBytes = oldSize * 4
            val rowScratch = ByteArray(rowBytes)
            for (y in 0 until oldSize) {
                old.get(y * rowBytes, rowScratch, 0, rowBytes)
                grown.put(y * newSize * 4, rowScratch, 0, rowBytes)
            }
        }
        cpuRgba = grown
        atlasSizePx = newSize
        val scale = oldSize.toFloat() / newSize
        // Rule: atlas-grow-uv-rescale. uv is [u0, vTop, u1, vBottom] (see uvRectForPackRect). U maps
        // linearly from the left edge (u = x/atlasSizePx), so multiplying by `scale` correctly turns
        // x/oldSize into x/newSize. V is flipped from the *top* edge (v = 1 - y/atlasSizePx) — the "1 -"
        // means the same `* scale` is wrong for any real growth (scale != 1): it was silently
        // corrupting every already-cached glyph's vertical texture lookup after each atlas doubling,
        // making it sample whatever unrelated glyph row ended up there instead of its own pixels.
        // Solving old_v = 1 - y/oldSize for y and substituting into new_v = 1 - y/newSize gives
        // new_v = 1 - scale * (1 - old_v).
        fun rescaleV(v: Float) = 1f - scale * (1f - v)
        fun rescaleUv(g: Glyph): Glyph {
            val uv = g.uv
            return g.copy(
                uv = floatArrayOf(uv[0] * scale, rescaleV(uv[1]), uv[2] * scale, rescaleV(uv[3])),
            )
        }
        // Rescaling the maps above keeps *future* ensureGlyph lookups correct, but every
        // SymbolInstanceBatch already built and cached before this resize baked its glyph's old UV
        // directly into its instance FloatArray (see atlasGeneration's doc) — bump so those caches miss.
        atlasGeneration++
        val updated = glyphs.mapValues { (_, g) -> rescaleUv(g) }
        val updatedMulti = multiLineGlyphs.mapValues { (_, g) -> rescaleUv(g) }
        glyphs.clear()
        glyphs.putAll(updated)
        multiLineGlyphs.clear()
        multiLineGlyphs.putAll(updatedMulti)
        needsFullGlUpload = true
        dirtyRects.clear()
        glUploadDirty = true
        MapsGLDebug.logD(TAG, "grew atlas to ${newSize}px")
        return true
    }

    private const val uncheckedColorBlack = 0xFF000000.toInt()

    private fun rasterize(key: Key): Bitmap {
        val fontSizePx = key.fontSizePx * TEXT_SUPERSAMPLE
        val fillPaint = createFillPaint(fontSizePx, key.colorArgb, key.bold)
        val outlineWidth = outlineWidthFor(key.outlineArgb, fontSizePx) * key.outlineWidthScale
        val strokePaint = key.outlineArgb?.let { createStrokePaint(fontSizePx, it, key.bold, outlineWidth) }
        return rasterizeLine(
            key.text,
            fillPaint,
            strokePaint,
            outlineWidth,
            tightHorizontalPad = key.tightHorizontalPad,
        )
    }

    private fun rasterizeStacked(lines: List<StackedLineKey>, lineGapPx: Float): Bitmap {
        val draws = ArrayList<Triple<String, Paint, Paint?>>(lines.size)
        var maxFontPx = 1
        for (line in lines) {
            if (line.text.isEmpty()) continue
            val fontSizePx = line.fontSizePx * TEXT_SUPERSAMPLE
            maxFontPx = max(maxFontPx, fontSizePx)
            val fillPaint = createFillPaint(fontSizePx, line.colorArgb, line.bold)
            val outlineWidth = outlineWidthFor(line.outlineArgb, fontSizePx)
            val strokePaint =
                line.outlineArgb?.let { createStrokePaint(fontSizePx, it, line.bold, outlineWidth) }
            draws.add(Triple(line.text, fillPaint, strokePaint))
        }
        if (draws.isEmpty()) {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
        }
        val gap = lineGapPx.coerceAtLeast(0f)
        val pad = edgePadPx(maxFontPx).toFloat()
        var contentH = 0f
        var maxW = 0f
        val metrics = ArrayList<Pair<Paint.FontMetrics, Float>>(draws.size)
        for ((index, triple) in draws.withIndex()) {
            val (text, fillPaint, _) = triple
            val fm = fillPaint.fontMetrics
            val lineW = fillPaint.measureText(text).coerceAtLeast(1f)
            metrics.add(fm to lineW)
            maxW = max(maxW, lineW)
            if (index > 0) contentH += gap
            contentH += fm.descent - fm.ascent
        }
        val w = ceil(maxW + pad * 2f).toInt().coerceAtLeast(1)
        val h = ceil(contentH + pad * 2f).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        var baselineY = pad - metrics[0].first.ascent
        for ((index, triple) in draws.withIndex()) {
            if (index > 0) {
                val prevFm = metrics[index - 1].first
                val curFm = metrics[index].first
                baselineY += (prevFm.descent - curFm.ascent) + gap
            }
            val (text, fillPaint, strokePaint) = triple
            val x = pad
            strokePaint?.let { canvas.drawText(text, x, baselineY, it) }
            canvas.drawText(text, x, baselineY, fillPaint)
        }
        return bmp
    }

    private fun rasterizeLine(
        text: String,
        fillPaint: Paint,
        strokePaint: Paint?,
        outlineWidth: Float,
        tightHorizontalPad: Boolean = false,
    ): Bitmap {
        val metrics = fillPaint.fontMetrics
        val textWidth = fillPaint.measureText(text).coerceAtLeast(1f)
        val textHeight = (metrics.descent - metrics.ascent).coerceAtLeast(1f)
        val strokePad = if (outlineWidth > 0f) outlineWidth * 0.55f + 2f else 2f
        val edgePad = edgePadPx(fillPaint.textSize.toInt())
        val padX = if (tightHorizontalPad) 0 else edgePad
        val padY = edgePad
        val w = ceil(textWidth + padX * 2f + strokePad * 2f).toInt().coerceAtLeast(1)
        val h = ceil(textHeight + padY * 2f + strokePad * 2f).toInt().coerceAtLeast(1)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val x = padX + strokePad
        val y = padY + strokePad - metrics.ascent
        strokePaint?.let { canvas.drawText(text, x, y, it) }
        canvas.drawText(text, x, y, fillPaint)
        return bmp
    }

    private fun edgePadPx(maxFontSizePx: Int): Int =
        max(8, (maxFontSizePx * 0.12f + 4f).toInt())

    private fun outlineWidthFor(outlineArgb: Int?, fontSizePx: Int): Float =
        if (outlineArgb != null) {
            // Rule: place-label-text-scale-tuning. A flat 2px floor is a ~20% stroke-to-em ratio at
            // the 10px place-label minimum (vs the intended 12%) — thick enough to eat into thin
            // letter strokes and read as a blurry white blob around the fill. 1px keeps a visible
            // halo at tiny sizes without dominating them.
            max(1f, fontSizePx * 0.12f)
        } else {
            0f
        }

    private fun createFillPaint(fontSizePx: Int, colorArgb: Int, bold: Boolean): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = fontSizePx.toFloat()
            color = colorArgb
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun createStrokePaint(fontSizePx: Int, outlineArgb: Int, bold: Boolean, outlineWidth: Float): Paint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = fontSizePx.toFloat()
            color = outlineArgb
            style = Paint.Style.STROKE
            strokeWidth = outlineWidth
            strokeJoin = Paint.Join.ROUND
            typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        }

    private fun ensureCpuBuffer() {
        if (cpuRgba == null || cpuRgba!!.capacity() != atlasSizePx * atlasSizePx * 4) {
            cpuRgba = ByteBuffer.allocateDirect(atlasSizePx * atlasSizePx * 4).order(ByteOrder.nativeOrder())
        }
    }

    private fun blitBitmapToCpuAtlas(bmp: Bitmap, destX: Int, destY: Int) {
        ensureCpuBuffer()
        val atlas = cpuRgba!!
        val aw = atlasSizePx
        val w = bmp.width
        val h = bmp.height
        val row = IntArray(w)
        val rowBytes = ByteArray(w * 4)
        for (rowY in 0 until h) {
            bmp.getPixels(row, 0, w, 0, rowY, w, 1)
            var di = 0
            for (col in 0 until w) {
                val p = row[col]
                rowBytes[di++] = ((p shr 16) and 0xFF).toByte()
                rowBytes[di++] = ((p shr 8) and 0xFF).toByte()
                rowBytes[di++] = (p and 0xFF).toByte()
                rowBytes[di++] = ((p shr 24) and 0xFF).toByte()
            }
            val destRow = destY + rowY
            atlas.put((destRow * aw + destX) * 4, rowBytes, 0, w * 4)
        }
    }

    private fun markDirtyRect(x: Int, y: Int, w: Int, h: Int) {
        dirtyRects.add(intArrayOf(x, y, w, h))
        glUploadDirty = true
    }

    private fun flushPendingGlUpload(tid: Int) {
        if (!glUploadDirty) return
        synchronized(lock) {
            if (!glUploadDirty) return
            if (needsFullGlUpload || dirtyRects.isEmpty()) {
                uploadFullAtlasToGl(tid)
                needsFullGlUpload = false
                dirtyRects.clear()
            } else {
                uploadDirtyRectsToGl(tid)
            }
            glUploadDirty = false
        }
    }

    private fun uploadDirtyRectsToGl(tid: Int) {
        val atlas = cpuRgba ?: return
        val size = atlasSizePx
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, tid)
        for (rect in dirtyRects) {
            val x = rect[0]
            val y = rect[1]
            val w = rect[2]
            val h = rect[3]
            val rowBytes = w * 4
            val needed = h * rowBytes
            var buf = uploadScratch
            if (buf == null || buf.capacity() < needed) {
                buf = ByteBuffer.allocateDirect(needed.coerceAtLeast(4096)).order(ByteOrder.nativeOrder())
                uploadScratch = buf
            }
            buf.clear()
            val rowScratch = ByteArray(rowBytes)
            for (rowY in h - 1 downTo 0) {
                val srcRow = y + rowY
                atlas.get((srcRow * size + x) * 4, rowScratch, 0, rowBytes)
                buf.put(rowScratch, 0, rowBytes)
            }
            buf.flip()
            val glY = size - (y + h)
            GLES31.glTexSubImage2D(
                GLES31.GL_TEXTURE_2D,
                0,
                x,
                glY,
                w,
                h,
                GLES31.GL_RGBA,
                GLES31.GL_UNSIGNED_BYTE,
                buf,
            )
        }
        GLES31.glGenerateMipmap(GLES31.GL_TEXTURE_2D)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0)
        dirtyRects.clear()
    }

    /**
     * Rule: full-atlas-upload-chunked. A full re-upload must not allocate a second full-size
     * direct buffer on top of [cpuRgba] (historically 256MB at an 8192px cap — that peak OOM'd
     * and aborted via Mapbox Map.render()). Allocate empty GPU storage via
     * `glTexImage2D(..., null)` and stream content in bounded row-bands via `glTexSubImage2D`
     * (reusing [uploadScratch]) so the transient buffer stays at [FULL_UPLOAD_BAND_BYTES].
     */
    private const val FULL_UPLOAD_BAND_BYTES = 4 * 1024 * 1024

    private fun uploadFullAtlasToGl(tid: Int = textureId) {
        val atlas = cpuRgba ?: return
        val size = atlasSizePx
        val rowBytes = size * 4
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, tid)
        GLES31.glTexImage2D(
            GLES31.GL_TEXTURE_2D,
            0,
            GLES31.GL_RGBA8,
            size,
            size,
            0,
            GLES31.GL_RGBA,
            GLES31.GL_UNSIGNED_BYTE,
            null,
        )
        val bandRows = (FULL_UPLOAD_BAND_BYTES / rowBytes).coerceAtLeast(1)
        val neededBandBytes = bandRows * rowBytes
        var buf = uploadScratch
        if (buf == null || buf.capacity() < neededBandBytes) {
            buf = ByteBuffer.allocateDirect(neededBandBytes).order(ByteOrder.nativeOrder())
            uploadScratch = buf
        }
        val rowScratch = ByteArray(rowBytes)
        var rowsDone = 0
        while (rowsDone < size) {
            val rows = minOf(bandRows, size - rowsDone)
            buf.clear()
            // GL first row = texture bottom; CPU atlas is top-origin — same flip as before, just
            // banded: buffer row j within this band lands at GL row (rowsDone + j).
            for (j in 0 until rows) {
                val atlasRow = size - 1 - rowsDone - j
                atlas.get(atlasRow * rowBytes, rowScratch, 0, rowBytes)
                buf.put(rowScratch, 0, rowBytes)
            }
            buf.flip()
            GLES31.glTexSubImage2D(
                GLES31.GL_TEXTURE_2D,
                0,
                0,
                rowsDone,
                size,
                rows,
                GLES31.GL_RGBA,
                GLES31.GL_UNSIGNED_BYTE,
                buf,
            )
            rowsDone += rows
        }
        GLES31.glGenerateMipmap(GLES31.GL_TEXTURE_2D)
        GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, 0)
        glUploadDirty = false
    }
}
