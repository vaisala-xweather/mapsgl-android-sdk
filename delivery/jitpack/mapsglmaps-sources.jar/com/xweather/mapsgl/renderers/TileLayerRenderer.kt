package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.UnitQuad2DGeometry
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.gl.geometries.QuadGeometry
import com.xweather.mapsgl.gl.programs.Program
import com.xweather.mapsgl.gl.programs.RasterTileProgram
import com.xweather.mapsgl.gl.worldObjects.Mesh
import com.xweather.mapsgl.gl.worldObjects.MeshInfo
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.style.ParticleStyle
import com.xweather.mapsgl.layers.style.SampleStyle
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.style.ContourLayerPaint
import com.xweather.mapsgl.style.ParticleLayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileRenderable
import com.xweather.mapsgl.types.SampleExpression

/**
 *   TileLayerRenderer.kt
 *
 *   Adapted from IOS version TileLayerRenderer.swift, TileRenderer in TS
 *   @author Jason Suto 12/20/23
 */

abstract class TileLayerRenderer<DataType : TileData, Context : LayerRenderContext<Any>> : LayerRenderer<Context> {

    private val TAG = "TileLayerRenderer"
    var tileLayer: TileLayer? = null
    internal lateinit var context: RenderContext<Any>
    private val helpers: MutableList<MeshInfo> = mutableListOf()
    private lateinit var _geometry: UnitQuad2DGeometry
    private lateinit var _renderPass: RenderPass //fixme: fix this, _renderpass should be initialized in onAdd()
    private var _renderablesAndMeshes: MutableMap<TileRenderable<DataType>, Mesh> = mutableMapOf()
    var cachesTextures = true;
    lateinit var mesh: Mesh
    private lateinit var FRAGMENT_SHADER_PATH: String
    private lateinit var VERTEX_SHADER_PATH: String
    private lateinit var RADAR_FRAGMENT_SHADER_PATH: String
    private lateinit var COMPUTE_SHADER_PATH: String
    private lateinit var TOUCH_SHADER_PATH: String
    lateinit var renderPass: RenderPass
    var renderpassInitialized = false
    val quadGeometry = QuadGeometry()
    var program: Program? = null
    var touchProgram: Program? = null
    var resetPaint = false

    init {
        quadGeometry.setVertices(UnitQuad2DGeometry.genQuad1x1())
    }

    override fun initialize(context: RenderContext<Any>) {
        this.context = context //This is also in makeMesh for renderable
    }

    /** empty so far */
    override fun setNeedsUpdate() {}

    /** empty so far */
    override fun setNeedsUpdate(force: Boolean) {}

    /** Called from TileLayer.render(), calls _renderPass.render() to do actual draw calls */
    override fun draw(context: Context, texUnit: HashMap<String, Int>, camera: Camera) {
        if (Timeline.timeStrings != null) {
            _renderPass.render(texUnit, camera)


        }
    }

    override fun onAdd(tileLayer: TileLayer) {
        this.tileLayer = tileLayer
        _renderPass = setUpRenderPass()
        renderPass = _renderPass
        renderpassInitialized = true
    }

    /**  Puts a list of meshes to be drawn into _renderPass.meshes   */
    override fun prerender(context: Context) {
        val renderables = context.renderables as? List<TileRenderable<DataType>> ?: return

        // 1. Synchronized cleanup of old meshes
        val currentKeys = _renderablesAndMeshes.keys.toSet()
        val toRemove = currentKeys.filter { it !in renderables }
        toRemove.forEach { _renderablesAndMeshes.remove(it) }
        helpers.clear()

        for (renderable in renderables) {
            // Get existing mesh or create a unique one for this tile
            val mesh = _renderablesAndMeshes.getOrPut(renderable) {
                makeMeshForRenderable(renderable)
            }

            // 3. ALWAYS update positions so tiles move when the map pans
            mesh.position.x = renderable.coord.x.toFloat()
            mesh.position.y = renderable.coord.y.toFloat()
            mesh.position.z = renderable.coord.z.toFloat()

            helpers.add(
                MeshInfo(
                    mesh.position.x, mesh.position.y, mesh.position.z,
                    renderable.tile.coordHash
                )
            )
        }
        _renderPass.meshInfoList = helpers.toList()
        _renderPass.meshes = _renderablesAndMeshes.values.toList()
    }

    private fun makeMeshForRenderable(renderable: TileRenderable<DataType>?): Mesh/*<TileMaterial>*/ {
        return try {
            if (program == null) {
                createProgram()
                if (tileLayer!!.paint is ParticleLayerPaint) {
                    mesh = Mesh(0, quadGeometry, program!!, createFrameBufferProgram())
                    mesh.textureProgram = createTextureProgram()

                } else {
                    //println("$TAG makeMeshForRenderable() paint is NOT ParticleStyle")
                    mesh = Mesh(0, quadGeometry, program!!, touchProgram = touchProgram)
                }
                //tileLayer!!.paint is ParticleLayerPaint
            } else if (resetPaint) {
                resetProgram()
                resetPaint = false
            }
            return mesh

        } catch (e: Exception) {
            throw e
        }
    }

    private fun createProgram(): RasterTileProgram {

        if (pr.ON) pr.p(TAG, pr.radarFix, "createProgram() Entered for ${tileLayer!!.id} ")

        if (tileLayer!!.paint is SampleLayerPaint) {

            val expression: String
            val encodedPaint = tileLayer!!.paint as SampleLayerPaint
            val expressionEnum = encodedPaint.sample.expression
            if (expressionEnum == SampleExpression.VECTOR) {
                expression = "EXPRESSION_VECTOR"
            } else if (expressionEnum == SampleExpression.DIFFERENCE) {
                expression = "EXPRESSION_DIFF"
            } else if (tileLayer!!.source.datasets.any { it.noData != null }) { // If any noData set, define in shader
                expression = "NO_DATA"
            } else {
                expression = "sample"
            }

            if (tileLayer!!.id != "conditions.radar.fill") {

                VERTEX_SHADER_PATH = "shaders/vertexShader.vert"
                FRAGMENT_SHADER_PATH = "shaders/sample.frag.combined.glsl" //correct shader

                //TOUCH_SHADER_PATH = "shaders/rawImage.glsl" //correct shader
                //FRAGMENT_SHADER_PATH="shaders/test/green.glsl" //single channel test
                //FRAGMENT_SHADER_PATH="shaders/fragmentShaderRawImage.glsl" // for testing raw image from server
                //FRAGMENT_SHADER_PATH="shaders/test/fragmentShaderColorBand.glsl" // for testing colorBand
                //FRAGMENT_SHADER_PATH="shaders/test/boarder.glsl" // for testing raw image with black boarder
                // FRAGMENT_SHADER_PATH="shaders/test/partTestShader.frag" // for testing particle generation
                program = RasterTileProgram(
                    tileLayer?.drawContext,
                    VERTEX_SHADER_PATH,
                    FRAGMENT_SHADER_PATH,
                    expression,
                    ProgramType.SAMPLE,
                )

                (this as EncodedDataRenderer<*, *>).setup(encodedPaint)

            } else { // Special shader for radar

                if (pr.ON) pr.p(TAG, pr.radarFix2, "createProgram() USING THE RADAR SHADER")
                tileLayer!!.isRadar = true
                VERTEX_SHADER_PATH = "shaders/vertexShader.vert"
                RADAR_FRAGMENT_SHADER_PATH = "shaders/sample-multiband.frag.glsl"

                program = RasterTileProgram(
                    tileLayer?.drawContext,
                    VERTEX_SHADER_PATH,
                    RADAR_FRAGMENT_SHADER_PATH,
                    expression,
                    ProgramType.SAMPLE,
                )
                (this as EncodedDataRenderer<*, *>).setup(encodedPaint)
                return program as RasterTileProgram
            }

        } else if (tileLayer!!.paint is ParticleLayerPaint) {
            COMPUTE_SHADER_PATH = "shaders/particles/tilePartComp31.glsl"
            FRAGMENT_SHADER_PATH = "shaders/particles/tilePartFrag31.glsl"
            VERTEX_SHADER_PATH = "shaders/particles/tilePartVert31.glsl"
            //VERTEX_SHADER_STRING=  "shaders/vertexShader.vert"
            //FRAGMENT_SHADER_PATH="shaders/fragmentShaderRawImage.glsl"

            val encodedPaint = tileLayer!!.paint as ParticleLayerPaint
            val expressionEnum = encodedPaint.sample.expression
            var expression: String
            if (expressionEnum == SampleExpression.VECTOR) {
                expression = "EXPRESSION_VECTOR"
            } else {
                expression = "EXPRESSION_ANGLE"
            }

            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                expression,
                ProgramType.PARTICLE,
                COMPUTE_SHADER_PATH
            )
            (this as ParticleRenderer).setup(tileLayer!!.paint as ParticleLayerPaint)
        } else if (tileLayer!!.paint is ContourLayerPaint) {

            val expression: String
            val contourPaint = tileLayer!!.paint as ContourLayerPaint
            val expressionEnum = contourPaint.sample.expression
            if (expressionEnum == SampleExpression.VECTOR) {
                expression = "EXPRESSION_VECTOR"
            } else if (expressionEnum == SampleExpression.DIFFERENCE) {
                expression = "EXPRESSION_DIFF"
            } else if (tileLayer!!.source.datasets.any { it.noData != null }) { // If any noData set, define in shader
                expression = "NO_DATA"
            } else {
                expression = "sample"
            }

            VERTEX_SHADER_PATH = "shaders/vertexContour.vert"
            FRAGMENT_SHADER_PATH = "shaders/fragmentContour.glsl"

            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                expression,
                ProgramType.SAMPLE,
            )

            (this as EncodedDataRenderer<*, *>).setup(contourPaint)
            if (pr.ON) pr.p("TileLayerRenderer", pr.contour, "createProgram() Contour detected")


        } else { //Raster Image Tile
            if (pr.ON) pr.p(TAG, pr.autoGenerated, "createProgram() 800 ")
            VERTEX_SHADER_PATH = "shaders/vertexShader.vert"
            FRAGMENT_SHADER_PATH =
                "shaders/fragmentShaderRawImage.glsl" // Correct, for displaying raster image from server
            //FRAGMENT_SHADER_PATH= "shaders/test/fragmentShaderTexture.frag" // Just show the raw texture
            //if(pr.ON)pr.p(TAG,pr.particles,"createProgram(), raster detected")
            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                "raster",
                ProgramType.RASTER
            )
        }

        return program as RasterTileProgram
    }

    /** Dynamically set colorstops **/
    private fun resetProgram(): RasterTileProgram {
        if (tileLayer!!.paint is SampleLayerPaint) {
            val expression = ((tileLayer!!.paint as SampleStyle).expression).toString()

            if (!tileLayer!!.isRadar) {
                program = RasterTileProgram(
                    tileLayer?.drawContext,
                    VERTEX_SHADER_PATH,
                    FRAGMENT_SHADER_PATH,
                    expression,
                    ProgramType.SAMPLE
                )
                (this as EncodedDataRenderer<*, *>).setup(tileLayer!!.paint as SampleLayerPaint)
            } else {
                program = RasterTileProgram(
                    tileLayer?.drawContext,
                    VERTEX_SHADER_PATH,
                    FRAGMENT_SHADER_PATH,
                    expression,
                    ProgramType.SAMPLE
                )
                (this as EncodedDataRenderer<*, *>).setup(tileLayer!!.paint as SampleLayerPaint)
                return program as RasterTileProgram
            }


        } else if (tileLayer!!.paint is ParticleLayerPaint) {

            if (pr.ON) pr.p(TAG, pr.customColor, "resetProgram(), particles detected")
            val expression = ((tileLayer!!.paint as ParticleStyle).expression).toString()
            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                expression,
                ProgramType.PARTICLE
            )
            (this as ParticleRenderer).setup(tileLayer!!.paint as ParticleLayerPaint)
        } else { //Image Tile
            program = RasterTileProgram(
                tileLayer?.drawContext,
                VERTEX_SHADER_PATH,
                FRAGMENT_SHADER_PATH,
                "raster",
                ProgramType.RASTER
            )
        }
        if (pr.ON) pr.p(TAG, pr.customColor, "resetProgram(), returning")
        return program as RasterTileProgram
    }

    fun createFrameBufferProgram(): RasterTileProgram {
        val VERTEX_PATH = "shaders/particles/fb-trail-vert.glsl"
        val FRAGMENT_PATH = "shaders/particles/fb-trail-frag.glsl"
        //val FRAGMENT_PATH="shaders/fragmentShaderRawImage.glsl" // for testing raw image from server
        val rasterTileProgram =
            RasterTileProgram(tileLayer?.drawContext, VERTEX_PATH, FRAGMENT_PATH, "frameBuffer", ProgramType.PARTICLE)
        (this as ParticleRenderer).setupFrameBufferProgram(tileLayer!!.paint, rasterTileProgram)
        return rasterTileProgram
    }

    fun createTextureProgram(): RasterTileProgram {
        val VERTEX_PATH = "shaders/particles/mega-texture-vert.glsl"
        //val VERTEX_PATH =  "shaders/vertexShader.vert"
        val FRAGMENT_PATH = "shaders/particles/mega-texture-frag.glsl"
        //val FRAGMENT_PATH="shaders/fragmentShaderRawImage.glsl"
        return RasterTileProgram(
            tileLayer?.drawContext,
            VERTEX_PATH,
            FRAGMENT_PATH,
            "frameBuffer",
            ProgramType.PARTICLE
        )
    }

    @Throws(Exception::class)
    abstract fun setUpRenderPass(): RenderPass

    override fun onRemove() {
        if (pr.ON) pr.p(TAG, pr.i13, "TileLayerRenderer onRemove() Entered ")

    }

    override suspend fun onMove() {}

    override fun onMoveStart() {}

    override suspend fun onMoveEnd() {}

    override fun onResize() {}

    override fun onClick() {}

    override fun onVisible() {}

    override fun onHidden() {}
}

class ProgramType {
    companion object {
        const val RASTER = 1
        const val SAMPLE = 2
        const val PARTICLE = 3
    }
}