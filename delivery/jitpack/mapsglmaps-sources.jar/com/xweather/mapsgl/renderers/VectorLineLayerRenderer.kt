package com.xweather.mapsgl.renderers

import android.os.SystemClock
import android.opengl.GLES31
import android.opengl.Matrix
import android.util.Log
import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.gl.EmptyRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.math.Matrix4
import com.xweather.mapsgl.gl.math.PowerTable.Companion.powerTableI
import com.xweather.mapsgl.gl.math.ProjectionMatrix
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.mapbox.CameraSync
import com.xweather.mapsgl.map.mapbox.ExpressionFilterFlatten
import com.xweather.mapsgl.map.mapbox.ExpressionReferencedKeys
import com.xweather.mapsgl.map.mapbox.GeoJsonWorldCopies
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.map.mapbox.StencilMaskFilter
import com.xweather.mapsgl.map.mapbox.TropicalDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorCircleRawStyleEval
import com.xweather.mapsgl.map.mapbox.VectorDrawTime
import com.xweather.mapsgl.map.mapbox.VectorFeatureDrawFilter
import com.xweather.mapsgl.map.mapbox.VectorLayerDrawFilterDefaults
import com.xweather.mapsgl.map.mapbox.VectorMapTime
import com.xweather.mapsgl.map.mapbox.VectorPolygonFillTriangulator
import com.xweather.mapsgl.map.mapbox.geoJsonVisibleFeatureSetKey
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.anim.playbackGateReadyPhaseEpochMillis
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.sources.resolveVectorTileData
import com.xweather.mapsgl.sources.timelinePhaseEpochMillis
import com.xweather.mapsgl.sources.timelinePlaybackPrefetchEpochMillis
import com.xweather.mapsgl.sources.GeoJSONSource
import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.sources.meshModeFingerprint
import com.xweather.mapsgl.sources.markLayerMeshReady
import com.xweather.mapsgl.sources.withGpuUpload
import com.xweather.mapsgl.style.LineLayerPaint
import com.xweather.mapsgl.style.StyleValue
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.LinkedHashMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private const val VECTOR_LINE_TAG = "VectorLineLayerRenderer"
/** Rule: zoom-transition-hold. See VectorFillLayerRenderer.FILL_TRIANGULATION_BUILD_THREADS. */
private const val LINE_TRIANGULATION_BUILD_THREADS = 2
/** Rule: warmup-submit-pacing. See VectorFillLayerRenderer.WARMUP_SUBMIT_BUDGET_PER_TICK. */
private const val WARMUP_SUBMIT_BUDGET_PER_TICK = 3
/** Rule: playback-mesh-cache-bound. See VectorFillLayerRenderer.PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES. */
private const val PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES = 64L * 1024L * 1024L


/** Rule: pan-during-playback. See VectorFillLayerRenderer.PLAYBACK_PREP_COORDS_SETTLE_MS. */
private const val PLAYBACK_PREP_COORDS_SETTLE_MS = 400L

/** Rule: playback-mesh-cache-bound. See VectorFillLayerRenderer.trimMeshCacheHard. */
private fun trimMeshCacheHard(cache: ConcurrentHashMap<String, FloatArray>, protected: Set<String>, maxBytes: Long) {
    var totalBytes = cache.values.sumOf { it.size.toLong() * 4L }
    if (totalBytes <= maxBytes) return
    val nonProtected = cache.entries.iterator()
    while (totalBytes > maxBytes && nonProtected.hasNext()) {
        val entry = nonProtected.next()
        if (entry.key !in protected) {
            totalBytes -= entry.value.size.toLong() * 4L
            nonProtected.remove()
        }
    }
    if (totalBytes > maxBytes) {
        val anyEntry = cache.entries.iterator()
        while (totalBytes > maxBytes && anyEntry.hasNext()) {
            val entry = anyEntry.next()
            totalBytes -= entry.value.size.toLong() * 4L
            anyEntry.remove()
        }
    }
}

/**
 * Rule: raw-vector-fast-path. Pure decision function (rule: testability), mirroring
 * [com.xweather.mapsgl.renderers.resolveRawCirclePathEligible] /
 * [com.xweather.mapsgl.renderers.resolveRawFillPathEligible]. True only when it's safe to declare
 * this line layer eligible via [VectorTileSource.setRawPathEligible]: the layer's effective filter
 * must be null (raw mode only replicates the MVT `visible` check via
 * [VectorPolygonFillTriangulator.rawFeatureVisible], not [VectorFeatureDrawFilter.shouldDraw]'s full
 * filter/stencil-mask/tropical-special-case pipeline — this specifically excludes tropical track-line
 * layers, whose visibility depends on a `timestamp` vs. map-time comparison raw mode cannot
 * replicate), and the resolved stroke color/thickness expressions must use only ops
 * [VectorCircleRawStyleEval] can evaluate off raw MVT attributes. No `consumerCount == 1`
 * restriction — [VectorTileSource.rawPathEligibleForLayer] already generalizes to "every attached
 * consumer agrees," which is what lets a shared source like severe.alerts (fill + outline
 * consumers) take this path.
 */
internal fun resolveRawLinePathEligible(
    layerId: String,
    filter: Expression?,
    strokeColorExpression: Expression?,
    strokeThicknessExpression: Expression?,
): Boolean {
    if (TropicalDrawFilter.isTropicalTrackLineLayer(layerId)) return false
    val flatFilter = ExpressionFilterFlatten.flatten(filter)
    if (VectorLayerDrawFilterDefaults.effectiveFilter(layerId, flatFilter) != null) return false
    if (!VectorCircleRawStyleEval.isSupportedColorExpression(strokeColorExpression)) return false
    if (!VectorCircleRawStyleEval.isSupportedNumberExpression(strokeThicknessExpression)) return false
    return true
}

private fun vectorLineDrawIntervalMs(tileLayer: TileLayer?, vts: VectorTileSource): Long? {
    if (!vts.isTimeSeriesSource) return null
    timelinePhaseEpochMillis(Timeline.currentPhaseA)?.let { return it }
    return tileLayer?.animator?.currentInterval?.interval?.takeIf { it > 0L }
}

/**
 * Draws [LineLayerPaint] strokes by tessellating [VectorTileSource] features in tile UV space inside Mapbox
 * [com.mapbox.maps.CustomLayerHost]. Mapbox native `line` style layers are omitted when this renderer is active.
 */
class VectorLineLayerRenderer(
    override var id: String,
) : TileLayerRenderer<TileData, LayerRenderContext<Any>>() {
    private companion object {
        private const val TRIANGULATION_COLOR_CACHE_VERSION = 4 // +featureTime GPU map-time reveal

        /**
         * Custom GL line ribbons read wider than Mapbox/JS at the same nominal `line-width`.
         * Applied only here — [LineLayerPaint] and style spec values stay unchanged.
         */
        private const val CUSTOM_WEBGL_LINE_THICKNESS_SCALE = 0.5f

        /** GeoJSON tropical / alert lines are small; triangulate on the GL thread to avoid a blank first pass. */
        private const val GEOJSON_SYNC_TRIANGULATION_MAX_FEATURES = 2000

        private const val OUTLINE_VERTEX_STRIDE_BYTES =
            VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX * 4

        /** Bump when outline vertex layout / map-time packing changes. */
        private const val LINE_MESH_CACHE_VERSION = 5
    }

    private data class CachedDrawBatch(val coord: TileCoord, val interleaved: FloatArray)
    private data class DrawResult(val drawnCount: Int, val totalCount: Int, val batches: List<CachedDrawBatch>)

    init {
        cachesTextures = false
    }

    override fun onAdd() {}

    override fun onAdd(
        context: RenderContext<Any>,
        tileLayer: TileLayer,
        controller: MapboxMapController,
    ) {
    }

    private var outlineGlProgram: Int = 0
    private var uOutlineMvpLocation: Int = -1
    private var uOutlineMapTimeLocation: Int = -1
    private var uInvOverscaleLocation: Int = -1
    private var vbo: Int = 0
    private var outlineByteBuffer: ByteBuffer = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder())
    private val triangulationCache = ConcurrentHashMap<String, FloatArray>()
    private val triangulationInProgress: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private var lastSuccessfulBatches: List<CachedDrawBatch> = emptyList()
    private var lastSuccessfulDrawIntervalMs: Long? = null
    /** Rule: steady-state-redundant-rebuild. See VectorFillLayerRenderer's identical field/KDoc —
     * tracked separately from [lastSuccessfulDrawIntervalMs] (the legacy branch's own promotion
     * logic) to avoid cross-branch interference. */
    private var lastSteadyStateIntervalMs: Long? = null
    /** Rule: warmup-scan-throttle. See VectorFillLayerRenderer's identical field/KDoc — throttles
     * ensureTimeSeriesWarmupTriangulation's O(coords × prefetchPhases) scan, which was re-running
     * every draw() call (60fps) for the whole interval-loading burst even after all real work
     * plateaued. */
    private var lastWarmupTriangulationScanMs: Long = 0L
    private val warmupTriangulationScanIntervalMs = 250L
    /** Rule: paused-mesh-cache-protection. See VectorFillLayerRenderer's identical field/KDoc — while
     * paused, [trimTriangulationCacheIfNeeded] previously protected nothing, so a static paused view's
     * own on-screen tiles could be evicted (by an unrelated tile's insert) and immediately
     * recomputed/re-inserted next frame, evicting some other on-screen tile in turn — sustained GC
     * churn with nothing animating. Repopulated every frame by [drawCoords] with exactly this frame's
     * visible tri-keys — bounded by visible-tile-count, never the whole timeline. */
    private val visibleTriKeysThisFrame: MutableSet<String> = HashSet()
    /** GeoJSON CPU map-time meshes — keep current key out of playback trim (convective outline). */
    private var pinnedGeoJsonTriKey: String? = null
    private var lastGeoJsonLineMesh: FloatArray? = null
    private val playbackLineRefsByIntervalMs = LinkedHashMap<Long, List<VectorPlaybackMeshRef>>()
    /** Rule: playback-refs-thread-safety. See VectorFillLayerRenderer's identical field/KDoc — this
     * map is written from the background prep job while [draw] iterates it on the GL render thread;
     * confirmed live via a crash in Fill's copy of this exact pattern (ConcurrentModificationException
     * fatal-aborting the app from inside Mapbox's native render() call). Every iteration and
     * structural mutation (put/remove/clear) of [playbackLineRefsByIntervalMs] must hold this lock. */
    private val playbackRefsLock = Any()
    /** Rule: pan-during-playback. See VectorFillLayerRenderer.playbackFillRefsGeneration's KDoc —
     * tags which [playbackPrepGeneration] each committed interval entry was built against, so a
     * viewport-change restart can overwrite entries in place instead of clearing the map outright. */
    private val playbackLineRefsGeneration = HashMap<Long, Long>()
    /** Rule: parsed-heap-bound. See VectorFillLayerRenderer's equivalent — throttle for the
     * periodic parsed-feature trim during playback. */
    private var lastParsedHeapTrimMs: Long = 0L
    private val parsedHeapTrimIntervalMs = 750L
    /** Rule: native-cache-budget. See VectorFillLayerRenderer's identical throttle — resolveLineMesh
     * calls the trim path once per visible tile per draw() frame; a full unpin-all-then-repin native
     * sync doesn't need to run that often. */
    private var lastNativePinSyncMs: Long = 0L
    private val nativePinSyncIntervalMs = 500L
    /** Rule: native-cache-budget. This renderer's own previously-pinned keys — see
     * VectorFillLayerRenderer.trimTriangulationCachesIfNeeded's KDoc for why diffing against this
     * (instead of a namespace-wide unpin-all) is required: the native outline-mesh namespace is
     * shared with VectorFillLayerRenderer (severe.alerts has both a Fill and a Line consumer on the
     * same VectorTileSource), and an unpin-all here previously raced Fill's own pin sync, evicting
     * meshes Fill still needed and vice versa. */
    private var previouslyPinnedOutlineKeys: Set<String> = emptySet()
    /** Rule: playback-mesh-cache-bound. See VectorFillLayerRenderer's identical fields/KDoc — a
     * phase's tiles aren't protected until its whole ref list is committed, so without this a
     * multi-tile phase's own earlier tiles can get evicted by its own later tiles' trim calls before
     * it ever finishes, retrying forever. */
    private val inFlightOutlineTriKeys: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private fun maxPlaybackIntervalRefCacheSize(): Int {
        val phaseCount = Timeline.timeStrings.size.coerceAtLeast(1)
        return maxOf(phaseCount + 8, timelinePlaybackPrefetchEpochMillis().size * 4)
    }

    /** Rule: pan-during-playback. See VectorFillLayerRenderer.protectedFillTriKeys's KDoc — only
     * protects entries tagged with the current [playbackPrepGeneration], so a coords-restart's stale
     * OLD-viewport entries become evictable immediately instead of staying pinned alongside the NEW
     * viewport's growing set for the whole reprime. */
    private fun protectedPlaybackTriKeys(): Set<String> {
        val keys = HashSet<String>()
        synchronized(playbackRefsLock) {
            for ((intervalMs, refs) in playbackLineRefsByIntervalMs) {
                if (playbackLineRefsGeneration[intervalMs] != playbackPrepGeneration) continue
                for (ref in refs) keys.add(ref.triKey)
            }
        }
        keys.addAll(inFlightOutlineTriKeys)
        pinnedGeoJsonTriKey?.let { keys.add(it) }
        return keys
    }

    /** [vts] is optional only for the GeoJSON-source call site, which has no [VectorTileSource] to
     * sync native pins against — see VectorFillLayerRenderer.trimTriangulationCachesIfNeeded. */
    private fun trimTriangulationCacheIfNeeded(vts: VectorTileSource? = null) {
        val protected = HashSet<String>()
        if (Timeline.isGloballyPlaying) protected.addAll(protectedPlaybackTriKeys())
        else protected.addAll(visibleTriKeysThisFrame)
        pinnedGeoJsonTriKey?.let { protected.add(it) }
        val maxBytes = if (Timeline.isGloballyPlaying) {
            PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES
        } else {
            PLAYBACK_TRIANGULATION_CACHE_MAX_BYTES / 2
        }
        trimMeshCacheHard(triangulationCache, protected, maxBytes)
        if (vts != null && SystemClock.elapsedRealtime() - lastNativePinSyncMs > nativePinSyncIntervalMs) {
            lastNativePinSyncMs = SystemClock.elapsedRealtime()
            for (key in previouslyPinnedOutlineKeys) if (key !in protected) vts.unpinOutlineTriangulationNative(key)
            for (key in protected) vts.pinOutlineTriangulationNative(key)
            previouslyPinnedOutlineKeys = protected
        }
    }
    private var pausedBatchCount = 0
    private var wasGloballyPlaying = false
    private var playbackWarmupComplete = true
    private var playbackFrozenBatches: List<CachedDrawBatch> = emptyList()
    private var playbackFrozenIntervalMs: Long? = null
    private var warmupTilePrefetchJob: Job? = null
    private var playbackFramePrepJob: Job? = null
    /** Rule: pan-during-playback. See VectorFillLayerRenderer's identical fields/KDoc — debounced
     * coords-restart tracking for [playbackFramePrepJob]. */
    private var playbackFramePrepCoordsKey: Set<String> = emptySet()
    private var pendingPlaybackPrepCoordsKey: Set<String> = emptySet()
    private var pendingPlaybackPrepCoordsKeyStableSinceMs: Long = 0L
    private var playbackPrepGeneration: Long = 0L
    /** Rule: pan-during-playback. See VectorFillLayerRenderer's identical field/KDoc — drives the
     * loading spinner for a pan-triggered reload the same way the initial-warmup booleans drive it
     * for play-press, without touching those booleans (structurally independent flags). */
    private var panReprimeInProgress: Boolean = false
    private var lastPlaybackFramePrepPhaseA: Int = -1
    private var lastGloballyInactiveMs: Long = 0L
    private val playbackPlayEdgeDebounceMs = 400L
    private var lastPlaybackViewportTileKeys: Set<String> = emptySet()
    private var initialPlaybackWarmupSatisfied = false
    private var viewportTilePrefetchPending = false
    private var lastViewportPrefetchSignalMs = 0L
    private val viewportPrefetchSignalDebounceMs = 500L
    private var playbackStableCoords: List<TileCoord> = emptyList()
    private var playbackStableCoordsUntilMs: Long = 0L
    private val playbackCoordsHoldMs = 750L
    private var playbackGateAnchorPhaseA: Int = -1
    private var playbackGateAnchorPhaseB: Int = -1
    private var playbackGateOpenedAtMs: Long = 0L
    private var playbackTimelineFullyPrimed = false
    private var fullTimelineMvtPrefetchJob: Job? = null
    private val fullTimelineTailPhasesPerPrepTick = 3
    /**
     * Rule: parsed-heap-bound. See VectorFillLayerRenderer's equivalent comment — was 96, then 16.
     * Confirmed via heap dump this is a GC-outpacing allocation-rate problem, not retention.
     */
    private val fullTimelineMvtRequestsPerWave = 6
    private var backgroundExecutor = Executors.newFixedThreadPool(LINE_TRIANGULATION_BUILD_THREADS)
    private val minPromotionCoverage = 0.55f
    private val zoomTransitionHoldMs = 700L

    /** Rule: zoom-settle-hold. See [VectorFillLayerRenderer]'s identical fields/KDoc — the same
     * deadline coupling (ancestor fallback and partial-frame promotion guard both keyed to
     * zoomTransitionHoldMs, so both lapse together) exists verbatim here. */
    private val zoomSettleCeilingMs = 8_000L
    private var zoomFloorSettled: Boolean = false
    private var zoomSettleDeadlineMs: Long = 0L
    private var lastZoomFloor: Int? = null
    private var holdLastBatchesUntilMs: Long = 0L

    internal fun beginPlaybackPrefetchGate(layer: VectorTileLayer? = null) {
        val priorViewportTileKeys = lastPlaybackViewportTileKeys
        var refreshedViewportTileKeys = priorViewportTileKeys
        layer?.let { vectorLayer ->
            val tileLayerRef = vectorLayer as? TileLayer ?: return@let
            tileLayerRef.refreshVisibleTileCoordsForVectorGl()
            val coords = tileLayerRef.visibleTileCoordsForGlVectorPlayback()
            if (coords.isNotEmpty()) {
                refreshedViewportTileKeys =
                    coords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
            }
            (vectorLayer.source as? VectorTileSource)?.cancelAllInFlightTimeSeriesTiles()
        }
        val viewportChanged =
            priorViewportTileKeys.isEmpty() ||
                refreshedViewportTileKeys.isEmpty() ||
                refreshedViewportTileKeys != priorViewportTileKeys
        lastPlaybackViewportTileKeys = refreshedViewportTileKeys
        playbackGateAnchorPhaseA = Timeline.currentPhaseA
        playbackGateAnchorPhaseB = Timeline.currentPhaseB
        playbackGateOpenedAtMs = 0L
        playbackWarmupComplete = false
        initialPlaybackWarmupSatisfied = false
        playbackTimelineFullyPrimed = false
        fullTimelineMvtPrefetchJob?.cancel()
        fullTimelineMvtPrefetchJob = null
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        lastPlaybackFramePrepPhaseA = -1
        if (viewportChanged) {
            playbackFramePrepJob?.cancel()
            playbackFramePrepJob = null
            synchronized(playbackRefsLock) { playbackLineRefsByIntervalMs.clear() }
            playbackTimelineFullyPrimed = false
        }
    }

    /**
     * Rule: pan-during-playback. This renderer previously had no live pan-during-playback handling
     * at all (unlike VectorFillLayerRenderer, which had a partial — dead-gated — version); a mid-
     * playback pan to a genuinely new area never cancelled stale in-flight MVT requests for the old
     * viewport or re-signalled a priority prefetch for the new one, letting stale requests saturate
     * VectorTileSource's fixed in-flight budget and starve the new area's own requests. Mirrors
     * VectorFillLayerRenderer.handleViewportTileSetChangedDuringPlayback exactly.
     */
    private fun handleViewportTileSetChangedDuringPlayback(
        layer: VectorTileLayer,
        visibleTileKeys: Set<String>,
        signalPrefetch: Boolean,
    ) {
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        layer.cancelPlaybackViewportPrefetch()
        val vtsForCancel = layer.source as? VectorTileSource
        if (vtsForCancel != null && vtsForCancel.retainNativeMvtBytes) {
            val keepSpatial = visibleTileKeys.mapNotNull { key ->
                val parts = key.split('/')
                if (parts.size != 3) return@mapNotNull null
                TileCoord(parts[1].toInt(), parts[2].toInt(), parts[0].toInt()).hash()
            }.toSet()
            vtsForCancel.cancelInFlightTilesOutside(keepSpatial)
            vtsForCancel.trimParsedHeapForTimeline(keepSpatialHashes = keepSpatial)
        }
        lastPlaybackViewportTileKeys = visibleTileKeys
        if (signalPrefetch) {
            signalPlaybackViewportPrefetch(layer)
        }
    }

    private fun signalPlaybackViewportPrefetch(layer: VectorTileLayer) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastViewportPrefetchSignalMs < viewportPrefetchSignalDebounceMs) return
        lastViewportPrefetchSignalMs = now
        viewportTilePrefetchPending = true
        val phaseMs = timelinePhaseEpochMillis(Timeline.currentPhaseA)
        layer.schedulePlaybackViewportRefresh(priorityIntervalMs = phaseMs)
    }

    override fun setUpRenderPass(): RenderPass =
        EmptyRenderPass(tileLayer?.source?.id ?: id, tileLayer!!.paint)

    override fun prerender(context: LayerRenderContext<Any>) {}

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>) {}

    override fun draw(context: LayerRenderContext<Any>, texUnit: HashMap<String, Int>, camera: Camera) {
        val layer = tileLayer as? VectorTileLayer ?: return
        val geoJsonSource = layer.source as? GeoJSONSource
        val mapboxProj = CameraSync.mapboxProjectionMatrix
        val mapboxMv = CameraSync.mapboxModelViewMatrix
        val useMapboxNativeMv =
            mapboxProj != null && mapboxMv != null && mapboxProj.size >= 16 && mapboxMv.size >= 16
        val proj = if (useMapboxNativeMv) mapboxProj!! else projectionMatrixToFloatArray(camera.projectionMatrix)
        val mvCam = if (useMapboxNativeMv) mapboxMv!! else matrix4ToFloatArray(camera.viewMatrix)
        val mapZoomNow = CameraSync.customLayerRenderZoom ?: CameraSync.mapZoom

        ensureOutlineProgram()
        if (outlineGlProgram == 0 || uOutlineMvpLocation < 0 || uInvOverscaleLocation < 0) return

        // ── GeoJSON source path ───────────────────────────────────────────────
        if (geoJsonSource != null) {
            val rawFeatures = geoJsonSource.data?.features()
            if (rawFeatures.isNullOrEmpty()) {
                (tileLayer?.mapController as? MapboxMapController)?.ensureGeoJsonSourceDataLoaded(geoJsonSource)
                return
            }
            val gpuMapTime = VectorMapTime.usesGpuMapTimeReveal(layer.id, layer.filter)
            val mapTimeRevealKey = if (gpuMapTime) VectorMapTime.mapTimeRevealKey(layer.id, layer.filter) else null
            val features = rawFeatures.filter {
                if (gpuMapTime) {
                    VectorFeatureDrawFilter.shouldDrawForGpuMapTimePrep(it, layer.filter, layer.id)
                } else {
                    VectorFeatureDrawFilter.shouldDraw(it, layer.filter, layer.id)
                }
            }
            if (features.isEmpty()) {
                val trackLineRaw = rawFeatures.count { it.getStringProperty("featureType") == "trackLine" }
                if (trackLineRaw > 0) {
                    val sample = rawFeatures.firstOrNull { it.getStringProperty("featureType") == "trackLine" }
                    val mapTimeSec = VectorDrawTime.currentMapTimeSeconds()
                    val detail =
                        sample?.let { f ->
                            val ts = f.getNumberProperty("timestamp") ?: f.getStringProperty("timestamp")
                            val vis = f.getNumberProperty("visible") ?: f.getBooleanProperty("visible")
                            val passesType = VectorFeatureDrawFilter.shouldDraw(
                                f,
                                layer.filter,
                                layer.id,
                                VectorDrawTime.currentMapTimeMillis(),
                            )
                            val passesAll = passesType
                            "sample id=${f.id()} ts=$ts visible=$vis baseFilter=$passesType effective=$passesAll"
                        } ?: ""
                    Log.d(
                        VECTOR_LINE_TAG,
                        "${layer.id}: draw filter removed all $trackLineRaw trackLine features " +
                            "(mapTime=${mapTimeSec}s) $detail",
                    )
                }
                pinnedGeoJsonTriKey = null
                lastGeoJsonLineMesh = null
                return
            }
            val paint = layer.paint as? LineLayerPaint ?: return
            val strokeStyle = lineStrokeTriangulationStyle(paint) ?: return
            val opacity = paint.opacity.coerceIn(0f, 1f)
            val dataVersion = geoJsonSource.geoJsonStencilSequence
            val filterKey = (
                if (gpuMapTime) VectorMapTime.staticPrepFilter(layer.id, layer.filter)
                else VectorLayerDrawFilterDefaults.effectiveFilter(layer.id, layer.filter)
            )?.hashCode() ?: 0
            val mapTimeKey =
                if (gpuMapTime) {
                    0
                } else if (VectorFeatureDrawFilter.referencesMapTime(layer.id, layer.filter)) {
                    geoJsonVisibleFeatureSetKey(features)
                } else {
                    0
                }
            val meshVer = LINE_MESH_CACHE_VERSION
            val geoTriKey =
                "geojson|${geoJsonSource.id}|${strokeStyle.styleKey}|$dataVersion|line|$filterKey|$mapTimeKey|ft$meshVer|${layer.id}"
            val worldCoord = TileCoord(0, 0, 0)
            var raw = triangulationCache[geoTriKey]
            if (raw == null) {
                if (features.size <= GEOJSON_SYNC_TRIANGULATION_MAX_FEATURES) {
                    raw = triangulateGeoJsonOutlines(features, worldCoord, strokeStyle, mapTimeRevealKey)
                    triangulationCache[geoTriKey] = raw
                    pinnedGeoJsonTriKey = geoTriKey
                    trimTriangulationCacheIfNeeded()
                } else if (triangulationInProgress.add(geoTriKey)) {
                    val bgFeatures = features
                    val bgStyle = strokeStyle
                    val capturedTileLayer = tileLayer
                    backgroundExecutor.submit {
                        try {
                            val computed = triangulateGeoJsonOutlines(bgFeatures, worldCoord, bgStyle, mapTimeRevealKey)
                            triangulationCache[geoTriKey] = computed
                            pinnedGeoJsonTriKey = geoTriKey
                            trimTriangulationCacheIfNeeded()
                            if (computed.isNotEmpty()) {
                                capturedTileLayer?.mapController?.redraw()
                            }
                        } finally {
                            triangulationInProgress.remove(geoTriKey)
                        }
                    }
                }
                if (raw == null) {
                    raw = triangulationCache[geoTriKey]
                }
            } else {
                pinnedGeoJsonTriKey = geoTriKey
            }
            if (raw != null && raw.isNotEmpty()) {
                lastGeoJsonLineMesh = raw
            } else {
                raw = lastGeoJsonLineMesh
            }
            if (raw == null || raw.isEmpty()) {
                if (raw != null) {
                    Log.w(
                        VECTOR_LINE_TAG,
                        "${layer.id}: outline triangulation produced 0 vertices for ${features.size} features",
                    )
                }
                return
            }

            val projectionMatrix = FloatArray(16)
            val cameraArray = FloatArray(16)
            System.arraycopy(proj, 0, projectionMatrix, 0, 16)
            System.arraycopy(mvCam, 0, cameraArray, 0, 16)
            val tileLocal = FloatArray(16)
            val modelViewMatrixArray = FloatArray(16)
            val mvp = FloatArray(16)

            GLES31.glUseProgram(outlineGlProgram)
            GLES31.glEnable(GLES31.GL_BLEND)
            GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
            GLES31.glDisable(GLES31.GL_CULL_FACE)
            GLES31.glColorMask(true, true, true, true)
            if (vbo == 0) {
                val h = IntArray(1)
                GLES31.glGenBuffers(1, h, 0)
                vbo = h[0]
            }
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
            GLES31.glEnableVertexAttribArray(0)
            GLES31.glEnableVertexAttribArray(1)
            GLES31.glEnableVertexAttribArray(2)
            GLES31.glEnableVertexAttribArray(3)
            GLES31.glEnableVertexAttribArray(4)
            GLES31.glEnableVertexAttribArray(5)
            val depthWasEnabled = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
            val stencilWasEnabled = GLES31.glIsEnabled(GLES31.GL_STENCIL_TEST)
            val scissorWasEnabled = GLES31.glIsEnabled(GLES31.GL_SCISSOR_TEST)
            GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            if (stencilWasEnabled) GLES31.glDisable(GLES31.GL_STENCIL_TEST)
            if (scissorWasEnabled) GLES31.glDisable(GLES31.GL_SCISSOR_TEST)
            try {
                val interleaved = applyOutlineOpacity(raw, opacity)
                uploadOutlineInterleaved(interleaved)
                val overscale =
                    (if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, worldCoord.z) else 1f)
                        .coerceAtLeast(1f)
                if (uOutlineMapTimeLocation >= 0) {
                    GLES31.glUniform1f(
                        uOutlineMapTimeLocation,
                        VectorMapTime.currentMapTimeUniform(
                            VectorMapTime.usesGpuMapTimeReveal(layer.id, layer.filter),
                        ),
                    )
                }
                GLES31.glUniform1f(uInvOverscaleLocation, 1f / overscale)
                // Rule: dateline-world-copy. GeoJSON meshes are z=0 UV; redraw for each visible
                // Mapbox world copy so antimeridian-split tropical tracks stay continuous.
                for (drawCoord in GeoJsonWorldCopies.visibleWorldCoords(tileLayer?.mapController)) {
                    Matrix.setIdentityM(tileLocal, 0)
                    Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                    val worldCopyN = powerTableI.getOrElse(drawCoord.z) { 1 shl drawCoord.z }
                    Matrix.translateM(
                        tileLocal,
                        0,
                        drawCoord.x.toFloat() + drawCoord.offset * worldCopyN,
                        drawCoord.y.toFloat(),
                        0f,
                    )
                    Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
                    Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
                    GLES31.glUniformMatrix4fv(uOutlineMvpLocation, 1, false, mvp, 0)
                    GLES31.glDrawArrays(
                        GLES31.GL_TRIANGLES,
                        0,
                        interleaved.size / VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX,
                    )
                }
            } finally {
                if (scissorWasEnabled) GLES31.glEnable(GLES31.GL_SCISSOR_TEST)
                if (stencilWasEnabled) GLES31.glEnable(GLES31.GL_STENCIL_TEST)
                if (depthWasEnabled) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
            }
            GLES31.glDisableVertexAttribArray(0)
            GLES31.glDisableVertexAttribArray(1)
            GLES31.glDisableVertexAttribArray(2)
            GLES31.glDisableVertexAttribArray(3)
            GLES31.glDisableVertexAttribArray(4)
            GLES31.glDisableVertexAttribArray(5)
            GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
            GLES31.glUseProgram(0)
            return
        }
        // ── VectorTileSource path ─────────────────────────────────────────────
        val vts = layer.source as? VectorTileSource ?: return
        // Rule: paused-mesh-cache-protection. Reset once per frame; drawCoords repopulates with
        // exactly this frame's visible tri-keys below.
        visibleTriKeysThisFrame.clear()
        val liveDrawIntervalMs = vectorLineDrawIntervalMs(tileLayer as? TileLayer, vts)
        val tileLayerRef = tileLayer as TileLayer
        val timeSeriesPlayback = vts.isTimeSeriesSource && Timeline.isGloballyPlaying
        val visibleCoords =
            if (timeSeriesPlayback) tileLayerRef.visibleTileCoordsForGlVectorPlayback()
            else tileLayerRef.visibleTileCoordsForMapboxVectorCache()
        val fallbackCoords = if (visibleCoords.isEmpty()) {
            val mapZoom = (mapZoomNow ?: 0f).toDouble()
            val zCandidates = tileLayerRef.glVectorPlaybackFallbackZoomCandidates(mapZoom)
            var candidate: List<TileCoord> = emptyList()
            for (z in zCandidates) {
                val cached = tileLayerRef.cachedTileCoordsWithDataAtZInViewport(vts, z)
                if (cached.isNotEmpty()) {
                    candidate = cached
                    break
                }
            }
            candidate
        } else {
            emptyList()
        }
        val targetZoomFloor = floor((mapZoomNow ?: 0f).toDouble()).toInt()
            .coerceAtLeast(0)
            .coerceAtMost(layer.source.maxZoom.toInt())
        val nowMs = SystemClock.elapsedRealtime()
        val zoomFloorChanged = lastZoomFloor != null && lastZoomFloor != targetZoomFloor
        if (lastZoomFloor == null || zoomFloorChanged) {
            holdLastBatchesUntilMs = nowMs + zoomTransitionHoldMs
            // Rule: zoom-settle-hold.
            zoomFloorSettled = false
            zoomSettleDeadlineMs = nowMs + zoomSettleCeilingMs
            lastZoomFloor = targetZoomFloor
        }
        val playbackStable = Timeline.isGloballyPlaying
        // Rule: zoom-settle-hold. See VectorFillLayerRenderer's identical block/KDoc.
        val zoomBuildPending = triangulationInProgress.isNotEmpty()
        val zoomTransitionHold = nowMs < holdLastBatchesUntilMs ||
            (!playbackStable && !zoomFloorSettled && zoomBuildPending && nowMs < zoomSettleDeadlineMs)
        val allowStaleTimeFallback = true
        if (!playbackStable) {
            lastGloballyInactiveMs = nowMs
        }
        if (wasGloballyPlaying && !playbackStable) {
            playbackWarmupComplete = true
            initialPlaybackWarmupSatisfied = false
            playbackFrozenBatches = emptyList()
            playbackFrozenIntervalMs = null
            warmupTilePrefetchJob?.cancel()
            warmupTilePrefetchJob = null
        }
        val visibleTileKeys = visibleCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
        val viewportTileSetChanged =
            visibleTileKeys.isNotEmpty() && visibleTileKeys != lastPlaybackViewportTileKeys
        val steadyStatePlaybackDraw =
            playbackStable &&
                vts.isTimeSeriesSource &&
                playbackWarmupComplete &&
                initialPlaybackWarmupSatisfied
        if (!steadyStatePlaybackDraw && !playbackStable) {
            lastPlaybackViewportTileKeys = emptySet()
        } else if (playbackStable && playbackWarmupComplete && viewportTileSetChanged) {
            // Rule: pan-during-playback. Covers both the warmup-phase and steady-state pan cases —
            // see handleViewportTileSetChangedDuringPlayback's KDoc.
            handleViewportTileSetChangedDuringPlayback(layer, visibleTileKeys, signalPrefetch = true)
        }
        val canAttemptDraw =
            visibleCoords.isNotEmpty() ||
                fallbackCoords.isNotEmpty() ||
                lastSuccessfulBatches.isNotEmpty() ||
                (playbackStable && playbackStableCoords.isNotEmpty() && nowMs < playbackStableCoordsUntilMs)
        if (!canAttemptDraw) return

        val paint = layer.paint as? LineLayerPaint ?: return
        val strokeStyle = lineStrokeTriangulationStyle(paint) ?: return
        // Rule: pruning-to-referenced-keys. Mirrors Circle/Fill/Symbol's identical call — without it
        // this consumer counts as "needs every attribute", which (because restrictedPropertyKeysFor
        // unions across *all* consumers) also disabled pruning for every other layer sharing the
        // source. Undeclared Line consumers were why a filtered line layer such as
        // severe.stormcells.track.line materialized every MVT property of every feature across the
        // whole timeline and exhausted the heap.
        //
        // Collected off the *effective* filter, not layer.filter: VectorLayerDrawFilterDefaults
        // injects the `timestamp <= map-time` track scrub here, and it must be visible to the key
        // walk. `timestamp`/`featureType`/`visible` are additionally pinned by
        // VectorTileSource.ALWAYS_NEEDED_PROPERTY_KEYS (`visible`/`timestamp`/`featureType` for the
        // scrub, plus `ADVISORY` for the alerts legend/inspector), since those are read off raw
        // attributes where no Expression walk can see them.
        (layer.source as? VectorTileSource)?.declareNeededPropertyKeys(
            layer.id,
            ExpressionReferencedKeys.collect(
                VectorLayerDrawFilterDefaults.effectiveFilter(
                    layer.id,
                    ExpressionFilterFlatten.flatten(layer.filter),
                ),
                strokeStyle.strokeColorExpression,
                strokeStyle.strokeThicknessExpression,
            ) + setOf("featureType", "timestamp", "visible"),
        )
        // Rule: raw-vector-fast-path. Recomputed every draw (cheap — no per-feature cost), so a style
        // or filter change takes effect on the next tile fetch, same as Circle's/Fill's equivalent call.
        vts.setRawPathEligible(
            layer.id,
            layer.sourceLayer,
            resolveRawLinePathEligible(
                layer.id,
                layer.filter,
                strokeStyle.strokeColorExpression,
                strokeStyle.strokeThicknessExpression,
            ),
        )
        val opacity = paint.opacity.coerceIn(0f, 1f)
        val drawIntervalMs = liveDrawIntervalMs

        if (playbackStable && !wasGloballyPlaying && vts.isTimeSeriesSource && !initialPlaybackWarmupSatisfied) {
            val playResumeGapMs = nowMs - lastGloballyInactiveMs
            if (playResumeGapMs >= playbackPlayEdgeDebounceMs) {
                pausedBatchCount = lastSuccessfulBatches.size
                playbackFrozenIntervalMs = liveDrawIntervalMs
                playbackFrozenBatches = lastSuccessfulBatches
                playbackWarmupComplete = false
                warmupTilePrefetchJob?.cancel()
                warmupTilePrefetchJob = null
            }
        }
        wasGloballyPlaying = playbackStable

        val projectionMatrix = FloatArray(16)
        val cameraArray = FloatArray(16)
        System.arraycopy(proj, 0, projectionMatrix, 0, 16)
        System.arraycopy(mvCam, 0, cameraArray, 0, 16)

        val tileLocal = FloatArray(16)
        val modelViewMatrixArray = FloatArray(16)
        val mvp = FloatArray(16)

        GLES31.glUseProgram(outlineGlProgram)
        GLES31.glEnable(GLES31.GL_BLEND)
        GLES31.glBlendFunc(GLES31.GL_SRC_ALPHA, GLES31.GL_ONE_MINUS_SRC_ALPHA)
        GLES31.glDisable(GLES31.GL_CULL_FACE)
        GLES31.glColorMask(true, true, true, true)

        if (vbo == 0) {
            val h = IntArray(1)
            GLES31.glGenBuffers(1, h, 0)
            vbo = h[0]
        }
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, vbo)
        GLES31.glEnableVertexAttribArray(0)
        GLES31.glEnableVertexAttribArray(1)
        GLES31.glEnableVertexAttribArray(2)
        GLES31.glEnableVertexAttribArray(3)
        GLES31.glEnableVertexAttribArray(4)

        val depthWasEnabled = GLES31.glIsEnabled(GLES31.GL_DEPTH_TEST)
        val stencilWasEnabled = GLES31.glIsEnabled(GLES31.GL_STENCIL_TEST)
        val scissorWasEnabled = GLES31.glIsEnabled(GLES31.GL_SCISSOR_TEST)
        GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        if (stencilWasEnabled) GLES31.glDisable(GLES31.GL_STENCIL_TEST)
        if (scissorWasEnabled) GLES31.glDisable(GLES31.GL_SCISSOR_TEST)
        try {
            // Rule: zero-copy-gpu-upload (Phase 5). Shared MVP/uniform/draw-call tail — split out so
            // the native-direct-buffer path (drawOutlineDirectBufferForCoord) can reuse it without a
            // FloatArray, mirroring VectorFillLayerRenderer.applyOutlineCoordTransformAndDraw.
            fun applyOutlineCoordTransformAndDraw(coord: TileCoord, vertexCount: Int) {
                Matrix.setIdentityM(tileLocal, 0)
                val overscale = if (useMapboxNativeMv) CameraSync.tileRasterOverscale(mapZoomNow, coord.z) else 1f
                Matrix.scaleM(tileLocal, 0, 512f * overscale, 512f * overscale, 1f)
                // Rule: dateline-world-copy. Must add coord.offset * n (n = tile-grid width at this
                // zoom), matching VectorGeometryRenderer.meshInfoForCoord's worldX formula — otherwise
                // every world copy of the same tile draws at the identical screen position instead of
                // its own shifted location (see VectorFillLayerRenderer's identical fix).
                val worldCopyN = powerTableI.getOrElse(coord.z) { 1 shl coord.z }
                Matrix.translateM(tileLocal, 0, coord.x.toFloat() + coord.offset * worldCopyN, coord.y.toFloat(), 0f)
                Matrix.multiplyMM(modelViewMatrixArray, 0, cameraArray, 0, tileLocal, 0)
                Matrix.multiplyMM(mvp, 0, projectionMatrix, 0, modelViewMatrixArray, 0)
                GLES31.glUniformMatrix4fv(uOutlineMvpLocation, 1, false, mvp, 0)
                GLES31.glUniform1f(uInvOverscaleLocation, 1f / overscale.coerceAtLeast(1f))
                if (uOutlineMapTimeLocation >= 0) {
                    GLES31.glUniform1f(
                        uOutlineMapTimeLocation,
                        VectorMapTime.currentMapTimeUniform(
                            VectorMapTime.usesGpuMapTimeReveal(layer.id, layer.filter),
                        ),
                    )
                }
                GLES31.glDrawArrays(GLES31.GL_TRIANGLES, 0, vertexCount)
            }

            fun drawOutlineInterleavedForCoord(coord: TileCoord, interleaved: FloatArray) {
                uploadOutlineInterleaved(interleaved)
                applyOutlineCoordTransformAndDraw(
                    coord,
                    interleaved.size / VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX,
                )
            }

            /** Rule: zero-copy-gpu-upload (Phase 5). See VectorFillLayerRenderer.drawOutlineDirectBufferForCoord's
             * KDoc — same contract. Line reuses Outline's native mesh cache/namespace (both produce
             * the identical stroke-ribbon vertex layout, see resolveLineMesh), so the same
             * getOutlineTriangulationNativeDirect accessor works unchanged here. */
            fun drawOutlineDirectBufferForCoord(coord: TileCoord, buffer: ByteBuffer, byteCount: Int) {
                buffer.order(ByteOrder.nativeOrder())
                buffer.position(0)
                buffer.limit(byteCount)
                GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, byteCount, buffer, GLES31.GL_DYNAMIC_DRAW)
                GLES31.glEnableVertexAttribArray(5)
                GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 0)
                GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 8)
                GLES31.glVertexAttribPointer(2, 4, GLES31.GL_UNSIGNED_BYTE, true, OUTLINE_VERTEX_STRIDE_BYTES, 16)
                GLES31.glVertexAttribPointer(3, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 20)
                GLES31.glVertexAttribPointer(4, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 24)
                GLES31.glVertexAttribPointer(5, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 28)
                applyOutlineCoordTransformAndDraw(coord, byteCount / OUTLINE_VERTEX_STRIDE_BYTES)
            }

            fun drawCachedBatches(batches: List<CachedDrawBatch>): Boolean {
                var drewAny = false
                for (batch in batches) {
                    if (batch.interleaved.isEmpty()) continue
                    drawOutlineInterleavedForCoord(batch.coord, batch.interleaved)
                    drewAny = true
                }
                return drewAny
            }

            // Rule: playback-mesh-cache-bound. See VectorFillLayerRenderer.drawPlaybackFillRefs's
            // comment — used to take a glHotCacheOnly flag meaning "Java-heap hit or skip this tile
            // this frame," which is only safe while the hot cache never evicts a currently-needed
            // entry. Now that trimMeshCacheHard can evict protected keys too, always resolve through
            // the native-fallback path (free in the common case) so an evicted-but-still-visible
            // tile doesn't flash empty until some other path happens to rebuild it.
            // Rule: playback-stale-fallback. See VectorFillLayerRenderer.drawPlaybackFillRefs's KDoc
            // — returns the batches actually drawn (not just a boolean) so the steady-state caller
            // can refresh lastSuccessfulBatches with this frame's fresh content. Legacy-branch
            // callers use `.isNotEmpty()`, an exact match for the old boolean.
            fun drawPlaybackLineRefs(refs: List<VectorPlaybackMeshRef>): List<CachedDrawBatch> {
                val drawn = ArrayList<CachedDrawBatch>(refs.size)
                for (ref in refs) {
                    // Rule: zero-copy-gpu-upload (Phase 5). See VectorFillLayerRenderer.drawPlaybackFillRefs's
                    // identical branch — Line shares Outline's native mesh cache/namespace (resolveLineMesh
                    // already reads it), so the same direct-buffer accessor works unchanged here.
                    if (ref.vertexOpacity >= 1f && !triangulationCache.containsKey(ref.triKey)) {
                        val direct = vts.getOutlineTriangulationNativeDirect(ref.triKey)
                        if (direct != null) {
                            try {
                                if (direct.capacity() > 0) {
                                    drawOutlineDirectBufferForCoord(ref.coord, direct, direct.capacity())
                                }
                            } finally {
                                vts.releaseOutlineTriangulationNativeDirect(ref.triKey)
                            }
                            continue
                        }
                    }
                    val raw = resolveLineMesh(vts, ref.triKey) ?: continue
                    if (raw.isEmpty()) continue
                    val interleaved =
                        if (ref.vertexOpacity < 1f) applyOutlineOpacity(raw, ref.vertexOpacity) else raw
                    drawOutlineInterleavedForCoord(ref.coord, interleaved)
                    drawn.add(CachedDrawBatch(ref.coord, interleaved))
                }
                return drawn
            }

            fun lineRefsForPlayback(intervalMs: Long?): List<VectorPlaybackMeshRef> {
                if (intervalMs == null) return emptyList()
                return playbackLineRefsByIntervalMs[intervalMs].orEmpty()
            }

            // Rule: zoom-transition-hold. See VectorFillLayerRenderer's resolveCachedVectorTile —
            // same ancestor-tile walk, ported for the line/outline mesh.
            fun resolveCachedVectorTile(
                coord: TileCoord,
                allowParentFallback: Boolean,
            ): Pair<Tile<VectorData>, TileCoord>? {
                vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, allowStaleTimeFallback)
                    ?.let { return it to coord }
                if (!allowParentFallback) return null
                var z = coord.z
                var x = coord.x
                var y = coord.y
                while (z > 0) {
                    z--
                    x = x shr 1
                    y = y shr 1
                    vts.findCachedVectorTileForNominalZxy(z, x, y, allowStaleTimeFallback)?.let { tile ->
                        // Rule: dateline-world-copy. Preserve the original coord's world-copy offset.
                        return tile to TileCoord(x, y, z, coord.offset)
                    }
                }
                return null
            }

            fun drawCoords(
                coords: List<TileCoord>,
                emitGeometry: Boolean = true,
                intervalForDraw: Long? = drawIntervalMs,
                allowParentFallback: Boolean = false,
            ): DrawResult {
                var drawnCount = 0
                var resolvedCount = 0
                val captured = ArrayList<CachedDrawBatch>()
                val drawnTileKeys = HashSet<String>(coords.size.coerceAtLeast(4))
                val resolveIntervalMs = intervalForDraw?.let { phaseMs ->
                    if (vts.isTimeSeriesSource) vts.snappedTimeSeriesIntervalMs(phaseMs) else phaseMs
                }
                val exactInterval = !Timeline.isGloballyPlaying && !vts.isTimeSeriesSource
                for (coord in coords) {
                    val resolved = resolveCachedVectorTile(coord, allowParentFallback) ?: continue
                    val cached = resolved.first
                    val drawCoord = resolved.second
                    // Rule: dateline-world-copy. Must include offset — see VectorFillLayerRenderer's
                    // identical fix.
                    if (!drawnTileKeys.add("${drawCoord.z}/${drawCoord.x}/${drawCoord.y}/${drawCoord.offset}")) {
                        resolvedCount++
                        drawnCount++
                        continue
                    }
                    val data = resolveVectorTileData(cached.data, resolveIntervalMs, exactInterval = exactInterval)
                        as? VectorData ?: continue
                    resolvedCount++
                    val triKey = lineTriangulationKey(drawCoord, data, layer.sourceLayer, strokeStyle.styleKey)
                    visibleTriKeysThisFrame.add(triKey)
                    var raw = resolveLineMesh(vts, triKey)
                    if (raw == null) {
                        if (!data.hasCpuGeometry()) continue
                        if (!backgroundExecutor.isShutdown && triangulationInProgress.add(triKey)) {
                            val bgData = data
                            val bgCoord = drawCoord
                            val bgSourceLayer = layer.sourceLayer
                            val bgStyle = strokeStyle
                            backgroundExecutor.submit {
                                try {
                                    val computed = bgData.withGpuUpload {
                                        triangulateLineOutlines(bgData, bgCoord, bgSourceLayer, bgStyle, vts, triKey)
                                    }
                                    if (computed.isNotEmpty()) {
                                        triangulationCache[triKey] = computed
                                        trimTriangulationCacheIfNeeded(vts)
                                    }
                                    bgData.markLayerMeshReady(vts, layer.id)
                                    (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                                } finally {
                                    triangulationInProgress.remove(triKey)
                                }
                            }
                        }
                        continue
                    }
                    if (raw.isEmpty()) continue
                    data.markLayerMeshReady(vts, layer.id)
                    val interleaved = applyOutlineOpacity(raw, opacity)
                    if (emitGeometry) {
                        drawOutlineInterleavedForCoord(drawCoord, interleaved)
                    }
                    drawnCount++
                    captured.add(CachedDrawBatch(drawCoord, interleaved))
                }
                return DrawResult(drawnCount, resolvedCount, captured)
            }

            val primaryCoords = run {
                if (steadyStatePlaybackDraw) {
                    visibleCoords.ifEmpty { fallbackCoords }
                } else if (playbackStable) {
                    if (visibleCoords.isNotEmpty()) {
                        val visibleKeys = visibleCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
                        val stableKeys = playbackStableCoords.map { "${it.z}/${it.x}/${it.y}" }.toSet()
                        val viewportShifted =
                            playbackStableCoords.isEmpty() || visibleKeys != stableKeys
                        val shouldRefreshStable =
                            playbackStableCoords.isEmpty() ||
                                nowMs >= playbackStableCoordsUntilMs ||
                                visibleCoords.size > playbackStableCoords.size ||
                                viewportShifted
                        if (shouldRefreshStable) {
                            playbackStableCoords = visibleCoords
                            playbackStableCoordsUntilMs = nowMs + playbackCoordsHoldMs
                        }
                        if (!viewportShifted &&
                            playbackStableCoords.isNotEmpty() &&
                            visibleCoords.size < playbackStableCoords.size &&
                            nowMs < playbackStableCoordsUntilMs
                        ) {
                            playbackStableCoords
                        } else {
                            visibleCoords
                        }
                    } else if (playbackStableCoords.isNotEmpty() && nowMs < playbackStableCoordsUntilMs) {
                        playbackStableCoords
                    } else if (fallbackCoords.isNotEmpty()) {
                        fallbackCoords
                    } else {
                        emptyList()
                    }
                } else if (visibleCoords.isNotEmpty()) {
                    visibleCoords
                } else {
                    fallbackCoords
                }
            }

            val prepCoords = playbackPrepCoords(layer, primaryCoords.ifEmpty { fallbackCoords })
            if (playbackStable && vts.isTimeSeriesSource && prepCoords.isNotEmpty()) {
                scheduleFullTimelineMvtPrefetch(layer, vts, prepCoords)
                schedulePlaybackFramePreparation(
                    layer = layer,
                    vts = vts,
                    coords = prepCoords,
                    strokeStyle = strokeStyle,
                    opacity = opacity,
                )
            }

            if (playbackStable && vts.isTimeSeriesSource && !playbackWarmupComplete && !initialPlaybackWarmupSatisfied) {
                Timeline.setGlVectorFillLayerPlaybackReady(layer.id, false)
                val warmupCoords = if (primaryCoords.isNotEmpty()) primaryCoords else fallbackCoords
                if (warmupCoords.isEmpty()) {
                    // Viewport tiles are not known yet — keep this layer awaiting so the play-press
                    // indicator stays up. Claiming ready here dismissed the spinner on the first
                    // frames, then intervals streamed in with no load UI.
                    return
                }
                    val nowMsForWarmupScan = SystemClock.elapsedRealtime()
                    if (nowMsForWarmupScan - lastWarmupTriangulationScanMs >= warmupTriangulationScanIntervalMs) {
                        lastWarmupTriangulationScanMs = nowMsForWarmupScan
                        val gatePhases = playbackGateReadyPhaseEpochMs(vts)
                        ensureTimeSeriesWarmupTriangulation(
                            vts = vts,
                            layer = layer,
                            coords = warmupCoords,
                            strokeStyle = strokeStyle,
                            prefetchPhases = gatePhases,
                            requestMissingTiles = true,
                        )
                    }
                    if (isPlaybackGateReady(vts, warmupCoords, playbackPrepGeneration)) {
                        playbackWarmupComplete = true
                        initialPlaybackWarmupSatisfied = true
                        playbackGateAnchorPhaseA = -1
                        playbackGateAnchorPhaseB = -1
                        playbackGateOpenedAtMs = SystemClock.elapsedRealtime()
                        warmupTilePrefetchJob?.cancel()
                        warmupTilePrefetchJob = null
                        Timeline.setGlVectorFillLayerPlaybackReady(layer.id, true)
                        if (!Timeline.isAnyGlVectorFillLayerAwaitingPlayback()) {
                            Timeline.endGlVectorFillPrefetchLoadUi()
                            (tileLayer?.mapController as? MapController)?.scheduleVectorFillPrefetchLoadComplete()
                        }
                    } else {
                        val frozen = playbackFrozenBatches.ifEmpty { lastSuccessfulBatches }
                        if (frozen.isNotEmpty()) {
                            drawCachedBatches(frozen)
                        }
                        return
                    }
            }

            if (steadyStatePlaybackDraw && drawIntervalMs != null) {
                val snappedDraw = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                // Rule: steady-state-redundant-rebuild. See VectorFillLayerRenderer's identical
                // fix/KDoc — skip rebuilding via drawPlaybackLineRefs when the interval hasn't
                // changed since the last rendered frame; just re-issue the GL draw calls from the
                // already-built batch list (drawCachedBatches allocates nothing).
                if (snappedDraw == lastSteadyStateIntervalMs && lastSuccessfulBatches.isNotEmpty()) {
                    drawCachedBatches(lastSuccessfulBatches)
                } else {
                    val prebuilt = lineRefsForPlayback(snappedDraw)
                    // Rule: playback-stale-fallback. See VectorFillLayerRenderer's identical fix/KDoc —
                    // refreshes lastSuccessfulBatches on every successful steady-state draw so the
                    // empty-lookup fallback is a rolling "most recently drawn" snapshot instead of a
                    // permanently-frozen pre-pan one.
                    val freshBatches = if (prebuilt.isNotEmpty()) drawPlaybackLineRefs(prebuilt) else emptyList()
                    if (freshBatches.isNotEmpty()) {
                        lastSuccessfulBatches = freshBatches
                        // Rule: steady-state-partial-resolve. Only lock in the skip-rebuild fast path
                        // (above) when every ref for this interval actually resolved. A partial resolve
                        // (some tile's mesh not yet in cache — normal for a moment after eviction/prep
                        // catching up) still draws what it has this frame via drawPlaybackLineRefs's own
                        // GL calls, but must NOT freeze that gap in place: leaving lastSteadyStateIntervalMs
                        // unset means the next frame retries drawPlaybackLineRefs fresh instead of
                        // re-issuing the same incomplete batch for this interval's entire ~30-60ms phase
                        // duration. Without this, a tile missing on one frame stayed missing (or a
                        // different tile went missing on the next loop pass) for the whole phase every
                        // time — the reported "flickers/tiles missing during playback" bug.
                        if (freshBatches.size >= prebuilt.size) {
                            lastSteadyStateIntervalMs = snappedDraw
                        }
                    } else if (lastSuccessfulBatches.isNotEmpty()) {
                        drawCachedBatches(lastSuccessfulBatches)
                    }
                }
            } else {
            var drew = false
            val timeSeriesPlaying = playbackStable && vts.isTimeSeriesSource
            if (timeSeriesPlaying && playbackWarmupComplete && drawIntervalMs != null) {
                val snappedDraw = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                val holdCoords = primaryCoords.ifEmpty { fallbackCoords }
                if (isIntervalReadyForPlaybackDisplay(
                        vts,
                        holdCoords,
                        drawIntervalMs,
                        strokeStyle.styleKey,
                        layer.sourceLayer,
                    )
                ) {
                    val prebuilt = lineRefsForPlayback(snappedDraw)
                    if (prebuilt.isNotEmpty()) {
                        drew = drawPlaybackLineRefs(prebuilt).isNotEmpty()
                        if (drew) {
                            lastSuccessfulDrawIntervalMs = snappedDraw
                        }
                    }
                }
            }
            if (!drew && !(timeSeriesPlaying && initialPlaybackWarmupSatisfied)) {
            val primaryResult = drawCoords(primaryCoords, emitGeometry = true, allowParentFallback = zoomTransitionHold)
            val primaryFullCoverage =
                primaryResult.totalCount > 0 && primaryResult.drawnCount == primaryResult.totalCount
            val primaryCoverage =
                if (primaryResult.totalCount > 0) primaryResult.drawnCount.toFloat() / primaryResult.totalCount.toFloat() else 0f
            // Rule: zoom-settle-hold. See VectorFillLayerRenderer's identical block/KDoc — totalCount
            // is populated from resolvedCount, so it excludes coords with no cached tile yet and
            // primaryFullCoverage alone can read "complete" over a half-empty viewport.
            if (!zoomFloorSettled &&
                primaryFullCoverage &&
                primaryResult.totalCount >= primaryCoords.size &&
                triangulationInProgress.isEmpty()
            ) {
                zoomFloorSettled = true
            }
            val minPromotionCount = maxOf(lastSuccessfulBatches.size, pausedBatchCount).coerceAtLeast(1)
            val promotePrimary = primaryResult.drawnCount > 0 && (
                (!playbackStable && (lastSuccessfulBatches.isEmpty() || primaryFullCoverage || primaryCoverage >= minPromotionCoverage || !zoomTransitionHold)) ||
                    (timeSeriesPlaying && initialPlaybackWarmupSatisfied && primaryFullCoverage) ||
                    (timeSeriesPlaying && !initialPlaybackWarmupSatisfied && primaryFullCoverage) ||
                    (playbackStable && !vts.isTimeSeriesSource && primaryResult.drawnCount >= minPromotionCount)
                )
            drew = primaryResult.drawnCount > 0
            if (promotePrimary && primaryResult.batches.isNotEmpty()) {
                lastSuccessfulBatches = primaryResult.batches
            } else if (playbackStable && lastSuccessfulBatches.isNotEmpty() &&
                !(timeSeriesPlaying && initialPlaybackWarmupSatisfied && drew)
            ) {
                drew = drawCachedBatches(lastSuccessfulBatches)
            } else if (!drew && lastSuccessfulBatches.isNotEmpty()) {
                drew = drawCachedBatches(lastSuccessfulBatches)
            } else if (playbackStable && !drew && drawIntervalMs != null) {
                val snappedHold = vts.snappedTimeSeriesIntervalMs(drawIntervalMs)
                val held = lineRefsForPlayback(snappedHold)
                if (held.isNotEmpty()) {
                    drew = drawPlaybackLineRefs(held).isNotEmpty()
                    lastSuccessfulDrawIntervalMs = snappedHold
                }
            } else if (timeSeriesPlaying && initialPlaybackWarmupSatisfied && lastSuccessfulBatches.isNotEmpty()) {
                drew = drawCachedBatches(lastSuccessfulBatches)
            }
            if (!drew && fallbackCoords.isNotEmpty() && fallbackCoords !== primaryCoords &&
                !(timeSeriesPlaying && initialPlaybackWarmupSatisfied)
            ) {
                val fallbackResult = drawCoords(fallbackCoords, emitGeometry = true, allowParentFallback = zoomTransitionHold)
                val fallbackFullCoverage =
                    fallbackResult.totalCount > 0 && fallbackResult.drawnCount == fallbackResult.totalCount
                val fallbackCoverage =
                    if (fallbackResult.totalCount > 0) fallbackResult.drawnCount.toFloat() / fallbackResult.totalCount.toFloat() else 0f
                val promoteFallback = fallbackResult.drawnCount > 0 && (
                    (!playbackStable && (lastSuccessfulBatches.isEmpty() || fallbackFullCoverage || fallbackCoverage >= minPromotionCoverage || !zoomTransitionHold)) ||
                        (timeSeriesPlaying && initialPlaybackWarmupSatisfied && fallbackFullCoverage) ||
                        (timeSeriesPlaying && !initialPlaybackWarmupSatisfied && fallbackFullCoverage) ||
                        (playbackStable && !vts.isTimeSeriesSource && fallbackResult.drawnCount >= minPromotionCount)
                    )
                val fallbackDrew = fallbackResult.drawnCount > 0
                if (promoteFallback && fallbackResult.batches.isNotEmpty()) {
                    lastSuccessfulBatches = fallbackResult.batches
                    drew = true
                } else if (!fallbackDrew && lastSuccessfulBatches.isNotEmpty()) {
                    drew = drawCachedBatches(lastSuccessfulBatches)
                } else {
                    drew = fallbackDrew
                }
            }
            if (!drew && lastSuccessfulBatches.isNotEmpty()) {
                drawCachedBatches(lastSuccessfulBatches)
            }
            }
            }
        } finally {
            if (scissorWasEnabled) GLES31.glEnable(GLES31.GL_SCISSOR_TEST)
            if (stencilWasEnabled) GLES31.glEnable(GLES31.GL_STENCIL_TEST)
            if (depthWasEnabled) GLES31.glEnable(GLES31.GL_DEPTH_TEST) else GLES31.glDisable(GLES31.GL_DEPTH_TEST)
        }

        GLES31.glDisableVertexAttribArray(0)
        GLES31.glDisableVertexAttribArray(1)
        GLES31.glDisableVertexAttribArray(2)
        GLES31.glDisableVertexAttribArray(3)
        GLES31.glDisableVertexAttribArray(4)
        GLES31.glBindBuffer(GLES31.GL_ARRAY_BUFFER, 0)
        GLES31.glUseProgram(0)
    }

    private data class LineStrokeTriangulationStyle(
        val layerFallbackThicknessPx: Float?,
        val strokeThicknessExpression: Expression?,
        val strokeFallbackRgba: FloatArray?,
        val strokeColorExpression: Expression?,
        val styleKey: Int,
    )

    private fun triangulateGeoJsonOutlines(
        features: List<com.mapbox.geojson.Feature>,
        worldCoord: TileCoord,
        strokeStyle: LineStrokeTriangulationStyle,
        mapTimeRevealKey: String? = null,
    ): FloatArray =
        VectorPolygonFillTriangulator.triangulateOutlines(
            features,
            worldCoord,
            null,
            strokeRgba = null,
            layerFallbackStrokeRgba = strokeStyle.strokeFallbackRgba,
            strokeColorExpression = strokeStyle.strokeColorExpression,
            layerFallbackThicknessPx = strokeStyle.layerFallbackThicknessPx,
            strokeThicknessExpression = strokeStyle.strokeThicknessExpression,
            lineThicknessScale = CUSTOM_WEBGL_LINE_THICKNESS_SCALE,
            mapTimeRevealKey = mapTimeRevealKey,
        )

    private fun lineStrokeTriangulationStyle(paint: LineLayerPaint): LineStrokeTriangulationStyle? {
        val constantThicknessPx = paint.stroke.thickness.constantValue?.toFloat() ?: 0f
        val thicknessExpression = (paint.stroke.thickness as? StyleValue.Expression)?.expression
        if (constantThicknessPx <= 0f && thicknessExpression == null) return null
        val strokeOpacity = (paint.stroke.opacity.constantValue ?: 1.0).toFloat()
        val strokeConstColor: Color? = paint.stroke.color.constantValue
        val strokeFallbackRgba: FloatArray? = strokeConstColor?.let {
            floatArrayOf(it.red, it.green, it.blue, it.alpha * strokeOpacity)
        }
        val strokeColorExpression = (paint.stroke.color as? StyleValue.Expression)?.expression
        val fallbackKey = strokeFallbackRgba?.contentHashCode() ?: 0
        val colorExprKey = strokeColorExpression?.raw?.hashCode() ?: 0
        val thicknessExprKey = thicknessExpression?.raw?.hashCode() ?: 0
        val thicknessConstKey = constantThicknessPx.toBits()
        val styleKey = 31 * (31 * (31 * fallbackKey + colorExprKey) + thicknessExprKey) + thicknessConstKey
        return LineStrokeTriangulationStyle(
            layerFallbackThicknessPx = constantThicknessPx.takeIf { it > 0f },
            strokeThicknessExpression = thicknessExpression,
            strokeFallbackRgba = strokeFallbackRgba,
            strokeColorExpression = strokeColorExpression,
            styleKey = styleKey,
        )
    }

    private fun uploadOutlineInterleaved(interleaved: FloatArray) {
        val requiredBytes = interleaved.size * 4
        if (outlineByteBuffer.capacity() < requiredBytes) {
            outlineByteBuffer =
                ByteBuffer.allocateDirect(requiredBytes + requiredBytes / 2).order(ByteOrder.nativeOrder())
        }
        outlineByteBuffer.position(0)
        outlineByteBuffer.limit(requiredBytes)
        outlineByteBuffer.asFloatBuffer().put(interleaved)
        outlineByteBuffer.position(0)
        GLES31.glBufferData(GLES31.GL_ARRAY_BUFFER, requiredBytes, outlineByteBuffer, GLES31.GL_DYNAMIC_DRAW)
        GLES31.glEnableVertexAttribArray(5)
        GLES31.glVertexAttribPointer(0, 2, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 0)
        GLES31.glVertexAttribPointer(1, 2, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 8)
        GLES31.glVertexAttribPointer(2, 4, GLES31.GL_UNSIGNED_BYTE, true, OUTLINE_VERTEX_STRIDE_BYTES, 16)
        GLES31.glVertexAttribPointer(3, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 20)
        GLES31.glVertexAttribPointer(4, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 24)
        GLES31.glVertexAttribPointer(5, 1, GLES31.GL_FLOAT, false, OUTLINE_VERTEX_STRIDE_BYTES, 28)
    }

    private fun applyOutlineOpacity(interleaved: FloatArray, opacity: Float): FloatArray {
        if (opacity >= 1f) return interleaved
        val v = interleaved.copyOf(interleaved.size)
        var i = 4
        while (i < v.size) {
            v[i] = VectorPolygonFillTriangulator.repackColorAlpha(v[i], opacity)
            i += VectorPolygonFillTriangulator.OUTLINE_FLOATS_PER_VERTEX
        }
        return v
    }

    private fun projectionMatrixToFloatArray(pm: ProjectionMatrix): FloatArray =
        FloatArray(16) { i -> pm.elements[i] }

    private fun matrix4ToFloatArray(m: Matrix4): FloatArray =
        FloatArray(16) { i -> m.elements[i] }

    private fun ensureOutlineProgram() {
        if (outlineGlProgram != 0) return
        if (tryLinkOutlineProgramEs310()) return
        Log.w(VECTOR_LINE_TAG, "GLES 3.1 outline program failed; trying GLES 3.0 fallback")
        tryLinkOutlineProgramEs300()
    }

    private fun tryLinkOutlineProgramEs310(): Boolean {
        val vtx = """
            #version 300 es
            layout(location = 0) in vec2 a_pos;
            layout(location = 1) in vec2 a_normal;
            layout(location = 2) in vec4 a_color;
            layout(location = 3) in float a_edge_dist;
            layout(location = 4) in float a_half_width_uv;
            layout(location = 5) in float a_feature_time;
            uniform mat4 u_mvp;
            uniform float u_inv_overscale;
            out vec4 v_color;
            out float v_edge_dist;
            out float v_feature_time;
            void main() {
                v_color = a_color;
                v_edge_dist = a_edge_dist;
                v_feature_time = a_feature_time;
                gl_Position = u_mvp * vec4(a_pos + a_normal * (a_half_width_uv * u_inv_overscale * 1.2), 0.0, 1.0);
            }
        """.trimIndent()
        val frag = """
            #version 300 es
            precision highp float;
            in vec4 v_color;
            in float v_edge_dist;
            in float v_feature_time;
            uniform float u_mapTime;
            out vec4 o_frag;
            void main() {
                if (v_feature_time > u_mapTime) discard;
                float d = abs(v_edge_dist);
                float fw = fwidth(d);
                float aa = 1.0 - smoothstep(0.833 - fw, 0.833 + fw, d);
                o_frag = vec4(v_color.rgb, v_color.a * aa);
            }
        """.trimIndent()
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vtx, "outline-vertex310")
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, frag, "outline-frag310")
        if (vs == 0 || fs == 0) return false
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, vs)
        GLES31.glAttachShader(p, fs)
        GLES31.glLinkProgram(p)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val link = IntArray(1)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) {
            logProgramLinkFailure("outline-310", p)
            GLES31.glDeleteProgram(p)
            return false
        }
        outlineGlProgram = p
        uOutlineMvpLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_mvp")
        uInvOverscaleLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_inv_overscale")
        uOutlineMapTimeLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_mapTime")
        if (uOutlineMvpLocation < 0 || uInvOverscaleLocation < 0) {
            Log.e(VECTOR_LINE_TAG, "outline uniforms missing after GLES 3.1 link")
            GLES31.glDeleteProgram(outlineGlProgram)
            outlineGlProgram = 0
            uOutlineMapTimeLocation = -1
            return false
        }
        return true
    }

    private fun tryLinkOutlineProgramEs300() {
        val vtx = """
            #version 300 es
            uniform mat4 u_mvp;
            uniform float u_inv_overscale;
            in vec2 a_pos;
            in vec2 a_normal;
            in vec4 a_color;
            in float a_edge_dist;
            in float a_half_width_uv;
            in float a_feature_time;
            out vec4 v_color;
            out float v_edge_dist;
            out float v_feature_time;
            void main() {
                v_color = a_color;
                v_edge_dist = a_edge_dist;
                v_feature_time = a_feature_time;
                gl_Position = u_mvp * vec4(a_pos + a_normal * (a_half_width_uv * u_inv_overscale * 1.2), 0.0, 1.0);
            }
        """.trimIndent()
        val frag = """
            #version 300 es
            precision mediump float;
            in vec4 v_color;
            in float v_edge_dist;
            in float v_feature_time;
            uniform float u_mapTime;
            out vec4 fragColor;
            void main() {
                if (v_feature_time > u_mapTime) discard;
                float d = abs(v_edge_dist);
                float fw = fwidth(d);
                float aa = 1.0 - smoothstep(0.833 - fw, 0.833 + fw, d);
                fragColor = vec4(v_color.rgb, v_color.a * aa);
            }
        """.trimIndent()
        val vs = compileShader(GLES31.GL_VERTEX_SHADER, vtx, "outline-vertex300")
        val fs = compileShader(GLES31.GL_FRAGMENT_SHADER, frag, "outline-frag300")
        if (vs == 0 || fs == 0) return
        val p = GLES31.glCreateProgram()
        GLES31.glAttachShader(p, vs)
        GLES31.glAttachShader(p, fs)
        GLES31.glBindAttribLocation(p, 0, "a_pos")
        GLES31.glBindAttribLocation(p, 1, "a_normal")
        GLES31.glBindAttribLocation(p, 2, "a_color")
        GLES31.glBindAttribLocation(p, 3, "a_edge_dist")
        GLES31.glBindAttribLocation(p, 4, "a_half_width_uv")
        GLES31.glBindAttribLocation(p, 5, "a_feature_time")
        GLES31.glLinkProgram(p)
        GLES31.glDeleteShader(vs)
        GLES31.glDeleteShader(fs)
        val link = IntArray(1)
        GLES31.glGetProgramiv(p, GLES31.GL_LINK_STATUS, link, 0)
        if (link[0] == 0) {
            logProgramLinkFailure("outline-300", p)
            GLES31.glDeleteProgram(p)
            outlineGlProgram = 0
            uOutlineMvpLocation = -1
            uInvOverscaleLocation = -1
            return
        }
        outlineGlProgram = p
        uOutlineMvpLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_mvp")
        uInvOverscaleLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_inv_overscale")
        uOutlineMapTimeLocation = GLES31.glGetUniformLocation(outlineGlProgram, "u_mapTime")
        if (uOutlineMvpLocation < 0 || uInvOverscaleLocation < 0) {
            Log.e(VECTOR_LINE_TAG, "outline uniforms missing after GLES 3.0 link")
            GLES31.glDeleteProgram(outlineGlProgram)
            outlineGlProgram = 0
            uOutlineMvpLocation = -1
            uInvOverscaleLocation = -1
        }
    }

    private fun logProgramLinkFailure(label: String, program: Int) {
        val log = GLES31.glGetProgramInfoLog(program)
        if (log.isNotBlank()) {
            Log.e(VECTOR_LINE_TAG, "Program link failed ($label): $log")
        }
    }

    private fun lineTriangulationKey(
        coord: TileCoord,
        data: VectorData,
        sourceLayer: String?,
        styleKey: Int,
    ): String {
        val (meshFp, modeTag) = data.meshModeFingerprint(sourceLayer)
        return "${coord.z}/${coord.x}/${coord.y}|$sourceLayer|$styleKey|$TRIANGULATION_COLOR_CACHE_VERSION|$modeTag|$meshFp|line"
    }

    private fun resolveLineMesh(vts: VectorTileSource, triKey: String): FloatArray? {
        triangulationCache[triKey]?.let { return it }
        vts.getOutlineTriangulationNative(triKey)?.let { native ->
            triangulationCache[triKey] = native
            // Rule: playback-mesh-cache-bound. See VectorFillLayerRenderer.resolveFillMesh's identical
            // fix — this per-frame native-repopulate path previously had no trim call at all.
            trimTriangulationCacheIfNeeded(vts)
            return native
        }
        return null
    }

    /**
     * Rule: raw-vector-fast-path. Routes to [VectorPolygonFillTriangulator.triangulateOutlinesRaw]
     * when [data] was parsed via the raw MVT path (non-null [VectorData.rawFeatures]), else the heavy
     * [VectorPolygonFillTriangulator.triangulateOutlines] path. See [resolveRawLinePathEligible] for
     * how eligibility is proven before [data] can ever carry raw features for a line consumer.
     */
    private fun triangulateLineOutlines(
        data: VectorData,
        coord: TileCoord,
        sourceLayer: String?,
        strokeStyle: LineStrokeTriangulationStyle,
        // Rule: native-triangulation-zero-copy-write. See VectorFillLayerRenderer.triangulateFillFeatures's
        // identical params — keeps the native-cache-put call centralized here rather than duplicated
        // at every call site.
        vts: VectorTileSource? = null,
        triKey: String? = null,
    ): FloatArray {
        val rawFeatures = data.rawFeatures
        return if (rawFeatures != null) {
            VectorPolygonFillTriangulator.triangulateOutlinesRaw(
                rawFeatures,
                coord,
                null,
                strokeStyle.strokeFallbackRgba,
                strokeStyle.strokeColorExpression,
                false,
                strokeStyle.layerFallbackThicknessPx,
                strokeStyle.strokeThicknessExpression,
                CUSTOM_WEBGL_LINE_THICKNESS_SCALE,
                // Rule: native-outline-triangulation. This is the exact same triangulateOutlinesRaw /
                // tryNativeOutlineTriangulation code path VectorFillLayerRenderer's own outline
                // rendering already uses with this flag on — no new native code, just routing Line's
                // own outline consumer through it too.
                useNativeTriangulation = NATIVE_OUTLINE_TRIANGULATION_ENABLED,
                vts = vts,
                nativeCacheKey = triKey,
            )
        } else {
            VectorPolygonFillTriangulator.triangulateOutlines(
                data.features,
                coord,
                sourceLayer,
                strokeRgba = null,
                layerFallbackStrokeRgba = strokeStyle.strokeFallbackRgba,
                strokeColorExpression = strokeStyle.strokeColorExpression,
                layerFallbackThicknessPx = strokeStyle.layerFallbackThicknessPx,
                strokeThicknessExpression = strokeStyle.strokeThicknessExpression,
                lineThicknessScale = CUSTOM_WEBGL_LINE_THICKNESS_SCALE,
                // Rule: outline-tile-clip-edge-skip. MVT branch (raw fast path unavailable);
                // triangulateGeoJsonOutlines() deliberately leaves this off.
                skipTileClipEdges = true,
            ).also { floats ->
                if (vts != null && triKey != null && floats.isNotEmpty()) {
                    vts.putOutlineTriangulationNative(triKey, floats)
                }
            }
        }
    }

    /** True when [data] parsed empty — not when CPU geometry was consumed after GPU upload. */
    private fun vectorDataHasNoFeatures(data: VectorData): Boolean = data.isVacuousParse()

    private fun triangulateLineMeshForPlayback(
        vts: VectorTileSource,
        triKey: String,
        data: VectorData,
        coord: TileCoord,
        sourceLayer: String?,
        strokeStyle: LineStrokeTriangulationStyle,
        layerId: String? = null,
    ): FloatArray {
        resolveLineMesh(vts, triKey)?.let {
            data.markLayerMeshReady(vts, layerId)
            return it
        }
        return data.withGpuUpload {
            val computed = triangulateLineOutlines(data, coord, sourceLayer, strokeStyle, vts, triKey)
            if (computed.isNotEmpty()) {
                triangulationCache[triKey] = computed
                trimTriangulationCacheIfNeeded(vts)
            }
            computed
        }.also { data.markLayerMeshReady(vts, layerId) }
    }

    private fun allTimelinePhaseEpochMs(vts: VectorTileSource): List<Long> =
        Timeline.timeStrings.indices
            .mapNotNull { timelinePhaseEpochMillis(it) }
            .mapNotNull { vts.resolvedIntervalOrNull(it) }
            .distinct()

    private fun playbackGateReadyPhaseEpochMs(vts: VectorTileSource): List<Long> {
        val count = Timeline.timeStrings.size
        if (count == 0) return emptyList()
        val phaseA = if (playbackGateAnchorPhaseA >= 0) playbackGateAnchorPhaseA else Timeline.currentPhaseA
        val phaseB = if (playbackGateAnchorPhaseB >= 0) playbackGateAnchorPhaseB else Timeline.currentPhaseB
        return playbackGateReadyPhaseEpochMillis(
            phaseA = phaseA,
            phaseB = phaseB,
            phaseCount = count,
            epochMillisAt = { timelinePhaseEpochMillis(it) },
            resolvedIntervalOrNull = { vts.resolvedIntervalOrNull(it) },
        )
    }

    private fun isPlaybackGateReady(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        generation: Long,
    ): Boolean {
        val gatePhases = playbackGateReadyPhaseEpochMs(vts)
        if (gatePhases.isEmpty() || coords.isEmpty()) return true
        return gatePhases.all { snappedMs ->
            playbackLineRefsByIntervalMs.containsKey(snappedMs) &&
                playbackLineRefsGeneration[snappedMs] == generation
        }
    }

    private fun timelinePhaseIndexForSnappedMs(vts: VectorTileSource, snappedMs: Long): Int =
        Timeline.timeStrings.indices.firstOrNull { idx ->
            timelinePhaseEpochMillis(idx)?.let { vts.snappedTimeSeriesIntervalMs(it) } == snappedMs
        } ?: -1

    private fun isPlaybackTimelineFullyPrimed(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        @Suppress("UNUSED_PARAMETER") styleKey: Int,
        @Suppress("UNUSED_PARAMETER") sourceLayer: String?,
        generation: Long,
    ): Boolean {
        val allPhases = allTimelinePhaseEpochMs(vts)
        if (allPhases.isEmpty() || coords.isEmpty()) return true
        // Rule: parsed-heap-bound. See VectorFillLayerRenderer.isPlaybackTimelineFullyPrimed's KDoc —
        // removed the redundant coords.all { isPlaybackPhaseDrawable(...) } re-check, which
        // independently re-derives drawability from JVM-heap-trimmable parsed data and produced false
        // negatives long after a phase was already successfully committed and pinned in native.
        //
        // Rule: pan-during-playback. Also requires the entry's generation tag to match [generation] —
        // see VectorFillLayerRenderer's identical check for why containsKey alone can't tell a
        // stale (old-viewport) entry apart from a fresh one after a coords-restart.
        return allPhases.all { snappedMs ->
            playbackLineRefsByIntervalMs.containsKey(snappedMs) &&
                playbackLineRefsGeneration[snappedMs] == generation
        }
    }

    private fun phasesForPlaybackFramePrep(
        vts: VectorTileSource,
        gateHoldActive: Boolean,
        fullTimelinePrimeActive: Boolean,
        generation: Long,
    ): List<Long> {
        // Rule: pan-during-playback. See VectorFillLayerRenderer's identical fix/KDoc — "missing"
        // also includes entries whose generation tag is stale, otherwise the tail-catchup mechanism
        // never revisits phases outside the rolling window after a coords-restart, so
        // isPlaybackTimelineFullyPrimed can never resolve and the loading spinner sticks forever.
        fun isMissing(snappedMs: Long): Boolean =
            playbackLineRefsByIntervalMs[snappedMs] == null ||
                playbackLineRefsGeneration[snappedMs] != generation
        when {
            gateHoldActive -> return playbackGateReadyPhaseEpochMs(vts).filter(::isMissing)
            fullTimelinePrimeActive -> {
                val rolling = playbackPrefetchPhaseEpochMs(vts)
                val missingTailFirst = allTimelinePhaseEpochMs(vts)
                    .filter(::isMissing)
                    .sortedByDescending { timelinePhaseIndexForSnappedMs(vts, it) }
                    .take(fullTimelineTailPhasesPerPrepTick)
                return (rolling + missingTailFirst).distinct()
            }
            else -> {
                val currentPhaseMs = timelinePhaseEpochMillis(Timeline.currentPhaseA)
                val rollingPhases = playbackPrefetchPhaseEpochMs(vts)
                return buildList {
                    currentPhaseMs?.let { add(it) }
                    for (phaseMs in rollingPhases) {
                        if (phaseMs != currentPhaseMs) add(phaseMs)
                    }
                }
            }
        }
    }

    private fun scheduleFullTimelineMvtPrefetch(
        layer: VectorTileLayer,
        vts: VectorTileSource,
        coords: List<TileCoord>,
    ) {
        if (!Timeline.isGloballyPlaying || coords.isEmpty()) return
        if (!playbackWarmupComplete) return
        if (playbackTimelineFullyPrimed && playbackWarmupComplete) return
        if (fullTimelineMvtPrefetchJob?.isActive == true) return
        val prepCoords = coords.toList()
        fullTimelineMvtPrefetchJob = layer.externalScope.launch(Dispatchers.Default) {
            val phasesTailFirst = allTimelinePhaseEpochMs(vts)
                .sortedByDescending { timelinePhaseIndexForSnappedMs(vts, it) }
            while (isActive && Timeline.isGloballyPlaying && !playbackTimelineFullyPrimed) {
                var requested = 0
                for (intervalMs in phasesTailFirst) {
                    for (coord in prepCoords) {
                        if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, intervalMs)) {
                            vts.requestTile(
                                coord.x,
                                coord.y,
                                coord.z,
                                intervalTime = java.util.Date(intervalMs),
                            )
                            requested++
                            if (requested >= fullTimelineMvtRequestsPerWave) break
                        }
                    }
                    if (requested >= fullTimelineMvtRequestsPerWave) break
                }
                if (requested == 0) break
                // Rule: parsed-heap-bound. See VectorFillLayerRenderer's equivalent comment.
                vts.trimParsedHeapForTimeline()
                delay(250)
            }
        }
    }

    private fun playbackPrepCoords(layer: VectorTileLayer, fallback: List<TileCoord>): List<TileCoord> {
        layer.refreshVisibleTileCoordsForVectorGl()
        val visible = layer.visibleTileCoordsForGlVectorPlayback()
        return when {
            visible.isNotEmpty() -> visible
            playbackStableCoords.isNotEmpty() -> playbackStableCoords
            fallback.isNotEmpty() -> fallback
            else -> emptyList()
        }
    }

    private fun vectorDataForSnappedPhase(
        vts: VectorTileSource,
        tilePayload: Any?,
        phaseMs: Long,
    ): VectorData? {
        val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
        return resolveVectorTileData(tilePayload, snappedMs, exactInterval = true) as? VectorData
    }

    private suspend fun buildPlaybackLineRefsForInterval(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        coords: List<TileCoord>,
        intervalMs: Long,
        strokeStyle: LineStrokeTriangulationStyle,
        opacity: Float,
    ): List<VectorPlaybackMeshRef> {
        if (coords.isEmpty()) return emptyList()
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        val refs = ArrayList<VectorPlaybackMeshRef>(coords.size)
        val addedInFlight = ArrayList<String>(coords.size)
        try {
            for (coord in coords) {
                if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) continue
                val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: continue
                var data = vectorDataForSnappedPhase(vts, cached.data, snappedMs)
                    ?: vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs)
                    ?: continue
                if (vectorDataHasNoFeatures(data)) {
                    data.markLayerMeshReady(vts, layer.id)
                    continue
                }
                val triKey = lineTriangulationKey(coord, data, layer.sourceLayer, strokeStyle.styleKey)
                if (!data.hasCpuGeometry() && data.cpuGeometryReleased && resolveLineMesh(vts, triKey) == null) {
                    data = vts.ensureTimeSeriesParsedAt(coord.z, coord.x, coord.y, snappedMs) ?: continue
                    if (vectorDataHasNoFeatures(data)) {
                        data.markLayerMeshReady(vts, layer.id)
                        continue
                    }
                }
                inFlightOutlineTriKeys.add(triKey)
                addedInFlight.add(triKey)
                val raw = triangulateLineMeshForPlayback(
                    vts = vts,
                    triKey = triKey,
                    data = data,
                    coord = coord,
                    sourceLayer = layer.sourceLayer,
                    strokeStyle = strokeStyle,
                    layerId = layer.id,
                )
                if (raw.isEmpty()) continue
                refs.add(VectorPlaybackMeshRef(coord, triKey, opacity))
            }
            return refs
        } finally {
            inFlightOutlineTriKeys.removeAll(addedInFlight.toSet())
        }
    }

    private fun schedulePlaybackFramePreparation(
        layer: VectorTileLayer,
        vts: VectorTileSource,
        coords: List<TileCoord>,
        strokeStyle: LineStrokeTriangulationStyle,
        opacity: Float,
    ) {
        if (!Timeline.isGloballyPlaying || coords.isEmpty()) return
        // Rule: dateline-world-copy. See VectorFillLayerRenderer's identical fix — must include
        // offset, not just z/x/y, or gaining/losing a world copy at wide zoomed-out antimeridian
        // views is never detected as a coords change.
        val coordsKey = coords.mapTo(HashSet(coords.size)) { "${it.z}/${it.x}/${it.y}/${it.offset}" }
        if (playbackFramePrepJob?.isActive == true) {
            if (coordsKey == playbackFramePrepCoordsKey) {
                pendingPlaybackPrepCoordsKey = coordsKey
                return
            }
            val now = SystemClock.elapsedRealtime()
            if (coordsKey != pendingPlaybackPrepCoordsKey) {
                pendingPlaybackPrepCoordsKey = coordsKey
                pendingPlaybackPrepCoordsKeyStableSinceMs = now
                return
            }
            if (now - pendingPlaybackPrepCoordsKeyStableSinceMs < PLAYBACK_PREP_COORDS_SETTLE_MS) return
            // Rule: pan-during-playback. See VectorFillLayerRenderer's identical restart logic/KDoc —
            // deliberately does NOT clear playbackLineRefsByIntervalMs (would blank the whole
            // timeline's content until rebuilt) and does NOT touch playbackWarmupComplete/
            // initialPlaybackWarmupSatisfied/the spinner latch (confirmed to freeze the timeline
            // clock for 30+ seconds if reset mid-playback). Bumps the generation instead. The
            // load-indicator flags below ARE safe to touch here — see panReprimeInProgress's KDoc.
            playbackFramePrepJob?.cancel()
            playbackFramePrepJob = null
            playbackPrepGeneration++
            playbackTimelineFullyPrimed = false
            panReprimeInProgress = true
            Timeline.setGlVectorFillLayerPlaybackReady(layer.id, false)
            Timeline.beginGlVectorFillPrefetchLoadUi()
        }
        playbackFramePrepCoordsKey = coordsKey
        pendingPlaybackPrepCoordsKey = coordsKey
        val prepCoords = coords.toList()
        val prepGeneration = playbackPrepGeneration
        playbackFramePrepJob = layer.externalScope.launch(Dispatchers.Default) {
            while (isActive && Timeline.isGloballyPlaying) {
                val gateHoldActive = !playbackWarmupComplete && playbackGateAnchorPhaseA >= 0
                val fullTimelinePrimeActive = playbackWarmupComplete && !playbackTimelineFullyPrimed
                val phases = phasesForPlaybackFramePrep(vts, gateHoldActive, fullTimelinePrimeActive, prepGeneration)
                val panLoadUiPhases =
                    if (panReprimeInProgress) playbackGateReadyPhaseEpochMs(vts).toHashSet() else emptySet()
                var builtAny = false
                for (phaseMs in phases) {
                    if (!isActive) break
                    val snappedMs = vts.snappedTimeSeriesIntervalMs(phaseMs)
                    if (playbackLineRefsByIntervalMs[snappedMs] == null ||
                        playbackLineRefsGeneration[snappedMs] != prepGeneration
                    ) {
                        for (coord in prepCoords) {
                            if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, snappedMs)) {
                                vts.requestTile(
                                    coord.x,
                                    coord.y,
                                    coord.z,
                                    intervalTime = java.util.Date(snappedMs),
                                    countsForGlFillLoadIndicator = gateHoldActive ||
                                        snappedMs in panLoadUiPhases,
                                )
                            }
                        }
                        val lineRefs = buildPlaybackLineRefsForInterval(
                            vts = vts,
                            layer = layer,
                            coords = prepCoords,
                            intervalMs = phaseMs,
                            strokeStyle = strokeStyle,
                            opacity = opacity,
                        )
                        if (prepCoords.all { coord ->
                                isPlaybackPhaseDrawable(
                                    vts,
                                    coord,
                                    snappedMs,
                                    strokeStyle.styleKey,
                                    layer.sourceLayer,
                                )
                            }
                        ) {
                            synchronized(playbackRefsLock) {
                                playbackLineRefsByIntervalMs[snappedMs] = lineRefs
                                playbackLineRefsGeneration[snappedMs] = prepGeneration
                                trimPlaybackMeshRefCache(playbackLineRefsByIntervalMs, maxPlaybackIntervalRefCacheSize())
                            }
                            builtAny = true
                        }
                    }
                }
                if (builtAny) {
                    (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                }
                // Rule: parsed-heap-bound. See VectorFillLayerRenderer's equivalent comment.
                val nowForTrim = SystemClock.elapsedRealtime()
                if (nowForTrim - lastParsedHeapTrimMs >= parsedHeapTrimIntervalMs) {
                    lastParsedHeapTrimMs = nowForTrim
                    vts.trimParsedHeapForTimeline()
                }
                if (panReprimeInProgress && isPlaybackGateReady(vts, prepCoords, prepGeneration)) {
                    panReprimeInProgress = false
                    Timeline.setGlVectorFillLayerPlaybackReady(layer.id, true)
                    if (!Timeline.isAnyGlVectorFillLayerAwaitingPlayback()) {
                        Timeline.endGlVectorFillPrefetchLoadUi()
                        (tileLayer?.mapController as? MapController)?.scheduleVectorFillPrefetchLoadComplete()
                    }
                }
                if (fullTimelinePrimeActive &&
                    isPlaybackTimelineFullyPrimed(
                        vts,
                        prepCoords,
                        strokeStyle.styleKey,
                        layer.sourceLayer,
                        prepGeneration,
                    )
                ) {
                    playbackTimelineFullyPrimed = true
                    fullTimelineMvtPrefetchJob?.cancel()
                    fullTimelineMvtPrefetchJob = null
                    Timeline.markPlaybackFullTimelinePrimed(layer.id)
                }
                delay(
                    when {
                        !playbackWarmupComplete -> if (builtAny) 4L else 12L
                        fullTimelinePrimeActive -> if (builtAny) 2L else 8L
                        builtAny -> 8L
                        // Rule: prep-loop-idle-backoff. See VectorFillLayerRenderer's identical KDoc —
                        // once fully primed and idle, there's no urgency to re-check every 16ms
                        // forever; a genuine viewport change is caught independently via job
                        // cancellation, not this loop's own polling cadence.
                        playbackTimelineFullyPrimed -> 500L
                        else -> 16L
                    },
                )
            }
        }
    }

    private fun playbackPrefetchPhaseEpochMs(vts: VectorTileSource): List<Long> =
        timelinePlaybackPrefetchEpochMillis(lookBehind = 2, lookAhead = 10)
            .map { vts.snappedTimeSeriesIntervalMs(it) }
            .distinct()

    private fun playbackGatePrefetchPhaseEpochMs(vts: VectorTileSource): List<Long> {
        val count = Timeline.timeStrings.size
        if (count == 0) return emptyList()
        val phaseA = playbackGateAnchorPhaseA.coerceIn(0, count - 1)
        val phaseB = playbackGateAnchorPhaseB.coerceIn(0, count - 1)
        val start = (min(phaseA, phaseB) - 2).coerceAtLeast(0)
        val end = (max(phaseA, phaseB) + 10).coerceAtMost(count - 1)
        return (start..end).mapNotNull { timelinePhaseEpochMillis(it) }
            .map { vts.snappedTimeSeriesIntervalMs(it) }
            .distinct()
    }

    private fun playbackGateHoldPrefetchPhaseEpochMs(vts: VectorTileSource): List<Long> =
        (playbackGatePrefetchPhaseEpochMs(vts) + playbackPrefetchPhaseEpochMs(vts)).distinct()

    private fun isPlaybackPhaseDrawable(
        vts: VectorTileSource,
        coord: TileCoord,
        phaseMs: Long,
        styleKey: Int,
        sourceLayer: String?,
    ): Boolean {
        if (vts.isTimeSeriesIntervalDownloading(coord.z, coord.x, coord.y, phaseMs)) return false
        if (vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, phaseMs)) {
            val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
            val loadedData = cached?.let { vectorDataForSnappedPhase(vts, it.data, phaseMs) }
            if (loadedData != null && vectorDataHasNoFeatures(loadedData)) {
                return true
            }
        }
        if (!vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, phaseMs)) return false
        val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true)
        val data = cached?.let { vectorDataForSnappedPhase(vts, it.data, phaseMs) }
        if (data != null) {
            val triKey = lineTriangulationKey(coord, data, sourceLayer, styleKey)
            if (triangulationCache.containsKey(triKey) || vts.hasOutlineTriangulationNative(triKey)) return true
        }
        val prefix = "${coord.z}/${coord.x}/${coord.y}|${sourceLayer ?: ""}|$styleKey|"
        return triangulationCache.keys.any { key -> key.startsWith(prefix) }
    }

    private fun isIntervalReadyForPlaybackDisplay(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        intervalMs: Long,
        styleKey: Int,
        sourceLayer: String?,
    ): Boolean {
        if (coords.isEmpty()) return true
        val snappedMs = vts.snappedTimeSeriesIntervalMs(intervalMs)
        if (!coords.all { coord ->
                isPlaybackPhaseDrawable(vts, coord, snappedMs, styleKey, sourceLayer)
            }
        ) {
            return false
        }
        return playbackLineRefsByIntervalMs.containsKey(snappedMs)
    }

    private fun isPlaybackPrefetchWindowDisplayReadyForPhases(
        vts: VectorTileSource,
        coords: List<TileCoord>,
        phases: List<Long>,
        styleKey: Int,
        sourceLayer: String?,
    ): Boolean {
        if (phases.isEmpty()) return true
        if (coords.isEmpty()) return false
        return phases.all { phaseMs ->
            isIntervalReadyForPlaybackDisplay(vts, coords, phaseMs, styleKey, sourceLayer)
        }
    }

    private fun ensureTimeSeriesWarmupTriangulation(
        vts: VectorTileSource,
        layer: VectorTileLayer,
        coords: List<TileCoord>,
        strokeStyle: LineStrokeTriangulationStyle,
        prefetchPhases: List<Long>,
        requestMissingTiles: Boolean,
    ) {
        if (requestMissingTiles && playbackGateAnchorPhaseA < 0 && warmupTilePrefetchJob?.isActive != true) {
            val prefetchCoords = coords.toList()
            val phasesForPrefetch = prefetchPhases
            warmupTilePrefetchJob = layer.externalScope.launch(Dispatchers.Default) {
                while (isActive) {
                    var requested = 0
                    // Rule: warmup-prefetch-starvation. See VectorFillLayerRenderer's identical fix —
                    // must iterate phase-major (outer) / coord-minor (inner). Coord-major lets one
                    // tile needing ~1000 phases consume the whole per-tick budget, starving every
                    // later tile in `prefetchCoords` until the first is 100% done.
                    outer@ for (phaseMs in phasesForPrefetch) {
                        for (coord in prefetchCoords) {
                            if (vts.hasTimeSeriesIntervalAt(coord.z, coord.x, coord.y, phaseMs)) continue
                            vts.requestTile(
                                coord.x,
                                coord.y,
                                coord.z,
                                intervalTime = java.util.Date(phaseMs),
                                countsForGlFillLoadIndicator = true,
                            )
                            requested++
                            if (requested >= 24) break@outer
                        }
                    }
                    if (requested == 0) break
                    delay(150)
                }
            }
        }
        // Rule: warmup-submit-pacing. See VectorFillLayerRenderer's identical fix/KDoc — caps new
        // background triangulation jobs started per scan tick so a cold warmup's allocation output
        // is spread across more 250ms ticks instead of front-loaded into one GC-pressuring burst.
        // Deferred candidates are simply picked up on the next tick, never dropped.
        var submitBudget = WARMUP_SUBMIT_BUDGET_PER_TICK
        for (coord in coords) {
            for (phaseMs in prefetchPhases) {
                if (submitBudget <= 0) break
                if (!vts.hasTimeSeriesDataLoadedAt(coord.z, coord.x, coord.y, phaseMs)) continue
                val cached = vts.findCachedVectorTileForNominalZxy(coord.z, coord.x, coord.y, true) ?: continue
                val data = vectorDataForSnappedPhase(vts, cached.data, phaseMs) ?: continue
                val triKey = lineTriangulationKey(coord, data, layer.sourceLayer, strokeStyle.styleKey)
                if (resolveLineMesh(vts, triKey) == null && data.hasCpuGeometry() && triangulationInProgress.add(triKey)) {
                    submitBudget--
                    val bgData = data
                    val bgCoord = coord
                    val bgSourceLayer = layer.sourceLayer
                    val bgStyle = strokeStyle
                    backgroundExecutor.submit {
                        try {
                            val computed = bgData.withGpuUpload {
                                triangulateLineOutlines(bgData, bgCoord, bgSourceLayer, bgStyle, vts, triKey)
                            }
                            if (computed.isNotEmpty()) {
                                triangulationCache[triKey] = computed
                                trimTriangulationCacheIfNeeded(vts)
                            }
                            bgData.markLayerMeshReady(vts, layer.id)
                            (tileLayer?.mapController as? MapboxMapController)?.requestRepaintCoalesced()
                        } finally {
                            triangulationInProgress.remove(triKey)
                        }
                    }
                } else if (resolveLineMesh(vts, triKey) != null) {
                    data.markLayerMeshReady(vts, layer.id)
                }
            }
        }
    }

    private fun compileShader(type: Int, src: String, label: String): Int {
        val s = GLES31.glCreateShader(type)
        GLES31.glShaderSource(s, src)
        GLES31.glCompileShader(s)
        val ok = IntArray(1)
        GLES31.glGetShaderiv(s, GLES31.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES31.glGetShaderInfoLog(s)
            if (log.isNotBlank()) {
                Log.e(VECTOR_LINE_TAG, "Shader compile failed ($label): $log")
            }
            GLES31.glDeleteShader(s)
            return 0
        }
        return s
    }

    internal fun invalidateTimelineMeshCache() {
        triangulationCache.clear()
        triangulationInProgress.clear()
        lastSuccessfulBatches = emptyList()
        lastSuccessfulDrawIntervalMs = null
        playbackStableCoords = emptyList()
        playbackStableCoordsUntilMs = 0L
        pausedBatchCount = 0
        wasGloballyPlaying = false
        lastPlaybackViewportTileKeys = emptySet()
        lastGloballyInactiveMs = 0L
        initialPlaybackWarmupSatisfied = false
        playbackWarmupComplete = true
        warmupTilePrefetchJob?.cancel()
        warmupTilePrefetchJob = null
        playbackFramePrepJob?.cancel()
        playbackFramePrepJob = null
        lastPlaybackFramePrepPhaseA = -1
        playbackFrozenBatches = emptyList()
        playbackFrozenIntervalMs = null
        previouslyPinnedOutlineKeys = emptySet()
        playbackGateOpenedAtMs = 0L
        playbackGateAnchorPhaseA = -1
        playbackGateAnchorPhaseB = -1
        playbackTimelineFullyPrimed = false
        fullTimelineMvtPrefetchJob?.cancel()
        fullTimelineMvtPrefetchJob = null
        synchronized(playbackRefsLock) { playbackLineRefsByIntervalMs.clear() }
    }

    fun releaseGl() {
        invalidateTimelineMeshCache()
        backgroundExecutor.shutdownNow()
        backgroundExecutor = Executors.newFixedThreadPool(LINE_TRIANGULATION_BUILD_THREADS)
        if (vbo != 0) {
            GLES31.glDeleteBuffers(1, intArrayOf(vbo), 0)
            vbo = 0
        }
        if (outlineGlProgram != 0) {
            GLES31.glDeleteProgram(outlineGlProgram)
            outlineGlProgram = 0
            uOutlineMvpLocation = -1
            uInvOverscaleLocation = -1
        }
    }

    override suspend fun update() {}
}
