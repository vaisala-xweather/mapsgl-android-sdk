package com.xweather.mapsgl.renderers

import com.xweather.mapsgl.layers.style.PaintStyle
import com.xweather.mapsgl.layers.tile.RenderContext
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.MapEventObserver
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.style.LayerPaint
import com.xweather.mapsgl.style.SampleLayerPaint
import kotlin.time.Duration

/**
 * Interface for a layer renderer.
 *
 * A layer renderer is responsible for rendering layer data based on the layer's paint style and configuration.
 * Therefore, most WebGL-related code will be contained within a class that implements this interface.
 */
interface LayerRenderContext<RenderableType> {
    var paintStyle: LayerPaint//PaintStyle
    var elapsedTime: Duration
    var renderables: List<RenderableType>
    var zoomLevel: Double
}

interface LayerRenderer<Context> : MapEventObserver {
    var id: String
    fun initialize(context: RenderContext<Any>)
    fun onAdd(tileLayer: TileLayer)
    fun setNeedsUpdate()
    fun setNeedsUpdate(force: Boolean)
    fun prerender(context: Context)
    //fun draw(texUnit: HashMap<String, Int>)
    fun draw(context: Context, texUnit: HashMap<String, Int>)
    fun draw(context: Context, texUnit: HashMap<String, Int>, camera: Camera)
}


