package com.xweather.mapsgl.style

import com.xweather.mapsgl.utils.convertUnits
import com.xweather.mapsgl.utils.unitPrecisionForSymbol
import java.text.NumberFormat
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeParseException
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.atan
import kotlin.math.ceil
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.log2
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Raised when an expression cannot be evaluated: an unknown operator, a failed type assertion, or
 * malformed arguments.
 *
 * MapsGL JS throws in the same places, and the message is the diagnostic — a filter that silently
 * evaluates to "no features" is far harder to explain than one that names its own mistake.
 */
class ExpressionEvaluationException(message: String) : IllegalArgumentException(message)

/**
 * Inputs an expression is evaluated against.
 *
 * @property properties Feature properties. Dotted keys (`report.cat`) walk nested maps.
 * @property zoom Current map zoom for `["zoom"]`. When null, falls back to a `$zoom` or `zoom`
 *   property, then 0 — the same lookup order MapsGL JS uses.
 * @property mapTimeSeconds Timeline playhead for `["map-time"]`, in **Unix seconds**. JS 1.9.4 made
 *   seconds the contract for every time operator; milliseconds here would compare three orders of
 *   magnitude off against a feature timestamp, and silently.
 * @property nowSeconds Wall clock for `["now"]`, in Unix seconds. Injectable so tests are not
 *   racing the clock.
 */
data class ExpressionContext(
    val properties: Map<String, Any?> = emptyMap(),
    val zoom: Double? = null,
    val mapTimeSeconds: Double = 0.0,
    val nowSeconds: () -> Double = { System.currentTimeMillis() / 1000.0 },
)

/**
 * The MapsGL expression evaluator: one implementation of the Mapbox-compatible expression language
 * for both paint values and filters, mirroring MapsGL JS `evaluateExpression`.
 *
 * Values are plain Kotlin: [Double] for numbers (JS has no integer type, and mixing `Int` and
 * `Double` would make `["==", 5, 5.0]` false), [String], [Boolean], [List], [Map] and null. A
 * missing property is null.
 *
 * Time operators return **Unix seconds**, matching JS 1.9.4.
 *
 * Supported operators:
 *
 * - Data: `literal`, `get`, `has`, `var`, `properties`, `zoom`, `coalesce`
 * - Comparison and logic: `==`, `!=`, `<`, `<=`, `>`, `>=`, `!`, `all`, `any`
 * - Types: `to-number`, `to-string`, `to-boolean`, `to-date`, `to-time`, `to-locale-string`,
 *   `to-unit`, `typeof`, `number`, `string`, `boolean`, `object`
 * - Math: `+`, `-`, `*`, `/`, `%`, `^`, `abs`, `ceil`, `floor`, `round`, `min`, `max`, `sqrt`,
 *   `ln`, `ln2`, `log2`, `log10`, `sin`, `cos`, `tan`, `asin`, `acos`, `atan`, `e`, `pi`
 * - Strings and arrays: `at`, `in`, `regex`, `index-of`, `length`, `slice`, `concat`, `downcase`,
 *   `upcase`
 * - Control flow: `step`, `interpolate`, `case`, `match`, `let`
 * - Time: `map-time` (and its aliases `time`, `mapTime`, `timeline`), `now`
 *
 * `format`, `geometry-type` and `interpolate-hcl` / `interpolate-lab` are not evaluated.
 */
object ExpressionEvaluator {

    /**
     * Evaluates [expression], or returns null when it cannot be evaluated.
     *
     * The GLES paint and filter paths fail closed rather than aborting a frame, so they take this
     * form; [evaluate] is for callers that want to see the failure.
     */
    fun evaluateOrNull(expression: Any?, context: ExpressionContext): Any? =
        try {
            evaluate(expression, context)
        } catch (e: ExpressionEvaluationException) {
            null
        }

    /**
     * Evaluates [expression] against [context].
     *
     * @throws ExpressionEvaluationException when the expression is unsupported or malformed.
     */
    fun evaluate(expression: Any?, context: ExpressionContext): Any? =
        eval(unwrap(expression), context, emptyMap())

    /**
     * Evaluates a filter to a boolean, using JS truthiness: a feature is kept when the result is
     * truthy. A filter that fails to evaluate drops the feature rather than admitting everything.
     */
    fun matches(filter: Any?, context: ExpressionContext): Boolean =
        try {
            truthy(evaluate(filter, context))
        } catch (e: ExpressionEvaluationException) {
            false
        }

    // ---- core ----

    private fun eval(expr: Any?, ctx: ExpressionContext, scope: Map<String, Any?>): Any? {
        if (expr !is List<*>) {
            // A bare "$name" reads a `let` binding, which is how JS lets a structured paint value
            // reference a binding without an expression array around it.
            if (expr is String && expr.startsWith("$")) return scope[expr.substring(1)]
            if (expr is Map<*, *>) return evalNestedObject(expr, ctx, scope)
            return normalizeNumber(expr)
        }
        if (expr.isEmpty()) return null

        val op = expr[0] as? String
            ?: throw ExpressionEvaluationException("expression operator must be a string, got ${expr[0]}")
        val argc = expr.size - 1

        return when (op) {
            // ---- data access ----
            ExpressionOperators.LITERAL -> expr.getOrNull(1)

            ExpressionOperators.GET -> {
                val bag = if (argc >= 2) eval(expr[2], ctx, scope) else ctx.properties
                resolveProperty(expr[1], bag)
            }

            ExpressionOperators.HAS -> {
                val bag = if (argc >= 2) eval(expr[2], ctx, scope) else ctx.properties
                val key = expr[1] as? String ?: return false
                (bag as? Map<*, *>)?.containsKey(key) == true
            }

            ExpressionOperators.VAR -> {
                val name = (expr[1] as? String) ?: jsString(eval(expr[1], ctx, scope))
                scope[name]
            }

            ExpressionOperators.PROPERTIES -> ctx.properties

            ExpressionOperators.ZOOM ->
                ctx.zoom
                    ?: asDoubleOrNull(ctx.properties["\$zoom"])
                    ?: asDoubleOrNull(ctx.properties["zoom"])
                    ?: 0.0

            ExpressionOperators.COALESCE -> {
                for (i in 1..argc) {
                    val v = eval(expr[i], ctx, scope)
                    if (v != null) return v
                }
                null
            }

            // ---- time ----
            // Every spelling resolves to the same playhead. JS deprecated `time`; Android also
            // accepts the `mapTime` / `timeline` spellings its own filters have used.
            ExpressionOperators.MAP_TIME,
            ExpressionOperators.TIME,
            ExpressionOperators.MAP_TIME_CAMEL,
            ExpressionOperators.TIMELINE,
            -> ctx.mapTimeSeconds

            ExpressionOperators.NOW -> ctx.nowSeconds()

            // ---- comparison and logic ----
            ExpressionOperators.EQ -> strictEquals(
                comparisonOperand(expr[1], ctx, scope, propertyShorthand = true),
                comparisonOperand(expr.getOrNull(2), ctx, scope, propertyShorthand = false),
            )

            ExpressionOperators.NEQ -> !strictEquals(
                comparisonOperand(expr[1], ctx, scope, propertyShorthand = true),
                comparisonOperand(expr.getOrNull(2), ctx, scope, propertyShorthand = false),
            )

            ExpressionOperators.LT -> compareOperands(expr, ctx, scope) { it < 0 }
            ExpressionOperators.LTE -> compareOperands(expr, ctx, scope) { it <= 0 }
            ExpressionOperators.GT -> compareOperands(expr, ctx, scope) { it > 0 }
            ExpressionOperators.GTE -> compareOperands(expr, ctx, scope) { it >= 0 }

            ExpressionOperators.NOT -> !truthy(eval(expr[1], ctx, scope))

            ExpressionOperators.ALL -> {
                for (i in 1..argc) if (!truthy(eval(expr[i], ctx, scope))) return false
                true
            }

            ExpressionOperators.ANY -> {
                for (i in 1..argc) if (truthy(eval(expr[i], ctx, scope))) return true
                false
            }

            // ---- type and coercion ----
            ExpressionOperators.TO_NUMBER -> {
                for (i in 1..argc) {
                    val v = eval(expr[i], ctx, scope)
                    // A date converts to seconds, not milliseconds — the 1.9.4 contract.
                    if (v is Date) return v.time / 1000.0
                    val n = jsNumber(v)
                    if (!n.isNaN()) return n
                }
                Double.NaN
            }

            ExpressionOperators.TO_STRING -> jsString(eval(expr[1], ctx, scope))

            ExpressionOperators.TO_DATE -> toDateOrNull(eval(expr[1], ctx, scope))

            ExpressionOperators.TO_TIME -> toDateOrNull(eval(expr[1], ctx, scope))?.let { it.time / 1000.0 }

            ExpressionOperators.TO_LOCALE_STRING -> {
                val value = eval(expr[1], ctx, scope)
                val tag = if (argc >= 2) jsString(eval(expr[2], ctx, scope)) else "en-US"
                val n = jsNumber(value)
                if (n.isNaN()) jsString(value) else localeNumber(n, tag)
            }

            ExpressionOperators.TO_UNIT -> evalToUnit(expr, ctx, scope)

            ExpressionOperators.TO_BOOLEAN -> truthy(eval(expr[1], ctx, scope))

            ExpressionOperators.TYPEOF -> jsTypeOf(eval(expr[1], ctx, scope))

            ExpressionOperators.NUMBER -> assertType(expr, ctx, scope, "number") {
                it is Double && !it.isNaN()
            }
            ExpressionOperators.STRING -> assertType(expr, ctx, scope, "string") { it is String }
            ExpressionOperators.BOOLEAN -> assertType(expr, ctx, scope, "boolean") { it is Boolean }
            ExpressionOperators.OBJECT -> assertType(expr, ctx, scope, "object") { it is Map<*, *> }

            // ---- math ----
            ExpressionOperators.ADD -> {
                // JS starts at 0 and uses `+`, so a string operand turns the rest into concatenation.
                var sum: Any? = 0.0
                for (i in 1..argc) sum = jsAdd(sum, eval(expr[i], ctx, scope))
                sum
            }

            ExpressionOperators.SUBTRACT -> {
                val a = jsNumber(eval(expr[1], ctx, scope))
                if (argc == 1) -a else a - jsNumber(eval(expr[2], ctx, scope))
            }

            ExpressionOperators.MOD ->
                jsNumber(eval(expr[1], ctx, scope)) % jsNumber(eval(expr[2], ctx, scope))

            ExpressionOperators.POW ->
                jsNumber(eval(expr[1], ctx, scope)).pow(jsNumber(eval(expr[2], ctx, scope)))

            ExpressionOperators.MULTIPLY ->
                jsNumber(eval(expr[1], ctx, scope)) * jsNumber(eval(expr[2], ctx, scope))

            ExpressionOperators.DIVIDE ->
                jsNumber(eval(expr[1], ctx, scope)) / jsNumber(eval(expr[2], ctx, scope))

            ExpressionOperators.ABS -> abs(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.CEIL -> ceil(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.FLOOR -> floor(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.ROUND -> jsRound(jsNumber(eval(expr[1], ctx, scope)))

            ExpressionOperators.MIN -> {
                if (argc == 0) return Double.POSITIVE_INFINITY
                var m = jsNumber(eval(expr[1], ctx, scope))
                for (i in 2..argc) {
                    val v = jsNumber(eval(expr[i], ctx, scope))
                    if (v < m) m = v
                }
                m
            }

            ExpressionOperators.MAX -> {
                if (argc == 0) return Double.NEGATIVE_INFINITY
                var m = jsNumber(eval(expr[1], ctx, scope))
                for (i in 2..argc) {
                    val v = jsNumber(eval(expr[i], ctx, scope))
                    if (v > m) m = v
                }
                m
            }

            ExpressionOperators.SQRT -> sqrt(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.LN -> ln(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.LN2 -> LN2
            ExpressionOperators.LOG2 -> log2(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.LOG10 -> log10(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.SIN -> sin(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.COS -> cos(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.TAN -> tan(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.ASIN -> asin(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.ACOS -> acos(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.ATAN -> atan(jsNumber(eval(expr[1], ctx, scope)))
            ExpressionOperators.E -> kotlin.math.E
            ExpressionOperators.PI -> PI

            // ---- string and array ----
            ExpressionOperators.AT -> {
                val index = jsNumber(eval(expr[1], ctx, scope))
                val arr = eval(expr[2], ctx, scope) as? List<*>
                    ?: throw ExpressionEvaluationException("at: second argument must be an array")
                arr.getOrNull(index.toInt())?.let { normalizeNumber(it) }
            }

            ExpressionOperators.IN -> {
                val needle = eval(expr[1], ctx, scope)
                when (val input = eval(expr[2], ctx, scope)) {
                    is String -> input.contains(jsString(needle))
                    is List<*> -> input.any { strictEquals(normalizeNumber(it), needle) }
                    else -> false
                }
            }

            ExpressionOperators.REGEX -> evalRegex(expr, ctx, scope)

            ExpressionOperators.INDEX_OF -> {
                val needle = eval(expr[1], ctx, scope)
                val input = eval(expr[2], ctx, scope)
                val from = if (argc >= 3) jsNumber(eval(expr[3], ctx, scope)).toInt() else 0
                when (input) {
                    is String -> input.indexOf(jsString(needle), from.coerceAtLeast(0)).toDouble()
                    is List<*> -> input.withIndex()
                        .firstOrNull { (i, v) -> i >= from && strictEquals(normalizeNumber(v), needle) }
                        ?.index?.toDouble() ?: -1.0
                    else -> -1.0
                }
            }

            ExpressionOperators.LENGTH -> when (val v = eval(expr[1], ctx, scope)) {
                is String -> v.length.toDouble()
                is List<*> -> v.size.toDouble()
                else -> 0.0
            }

            ExpressionOperators.SLICE -> evalSlice(expr, ctx, scope)

            ExpressionOperators.CONCAT -> buildString {
                for (i in 1..argc) append(jsString(eval(expr[i], ctx, scope)))
            }

            ExpressionOperators.DOWNCASE -> jsString(eval(expr[1], ctx, scope)).lowercase()
            ExpressionOperators.UPCASE -> jsString(eval(expr[1], ctx, scope)).uppercase()

            // ---- control flow ----
            ExpressionOperators.STEP -> evalStep(expr, ctx, scope)
            ExpressionOperators.INTERPOLATE -> evalInterpolate(expr, ctx, scope)
            ExpressionOperators.CASE -> evalCase(expr, ctx, scope)
            ExpressionOperators.MATCH -> evalMatch(expr, ctx, scope)
            ExpressionOperators.LET -> evalLet(expr, ctx, scope)

            else -> throw ExpressionEvaluationException("Unsupported expression: $op")
        }
    }

    /**
     * Evaluates expression arrays nested under the keys of a plain object, so a structured paint
     * value (`{ "width": ["var", "s"], "height": ["var", "s"] }`) can come out of a `let` instead of
     * needing an imperative callback. JS 1.9.1 added the same recursion.
     */
    private fun evalNestedObject(
        obj: Map<*, *>,
        ctx: ExpressionContext,
        scope: Map<String, Any?>,
    ): Map<String, Any?> {
        val out = LinkedHashMap<String, Any?>(obj.size)
        for ((k, v) in obj) {
            val key = k as? String ?: continue
            out[key] = when {
                isExpressionArray(v) -> eval(v, ctx, scope)
                v is Map<*, *> -> evalNestedObject(v, ctx, scope)
                else -> v
            }
        }
        return out
    }

    // ---- operator helpers ----

    private fun evalToUnit(expr: List<*>, ctx: ExpressionContext, scope: Map<String, Any?>): Any? {
        val argc = expr.size - 1
        val raw = eval(expr[1], ctx, scope) ?: return null
        val value = jsNumber(raw)
        if (value.isNaN()) return null

        val measurement = jsString(eval(expr[2], ctx, scope))
        val baseUnit = jsString(eval(expr[3], ctx, scope))
        val toUnit = if (argc >= 4) jsString(eval(expr[4], ctx, scope)) else baseUnit
        val precision = if (argc >= 5) {
            jsNumber(eval(expr[5], ctx, scope))
        } else {
            unitPrecisionForSymbol(toUnit).toDouble()
        }
        val places = if (precision.isNaN()) 0 else precision.toInt().coerceAtLeast(0)

        val converted = if (baseUnit == toUnit) value else convertUnits(measurement, value, baseUnit, toUnit)
        // A string, as in JS: `to-unit` is a formatter, and the trailing zeros are the point of it.
        return String.format(Locale.US, "%.${places}f", roundToPrecision(converted, places))
    }

    private fun evalRegex(expr: List<*>, ctx: ExpressionContext, scope: Map<String, Any?>): Boolean {
        val argc = expr.size - 1
        val pattern = eval(expr[1], ctx, scope) as? String ?: return false
        val hasFlags = argc >= 3
        val flags = if (hasFlags) eval(expr[2], ctx, scope) as? String else null
        val input = eval(expr[if (hasFlags) 3 else 2], ctx, scope) as? String ?: return false
        val regex = cachedRegex(pattern, flags) ?: return false
        // JS `RegExp.test` searches, so an unanchored pattern matches anywhere in the input.
        return regex.containsMatchIn(input)
    }

    private fun evalSlice(expr: List<*>, ctx: ExpressionContext, scope: Map<String, Any?>): Any {
        val argc = expr.size - 1
        val input = eval(expr[1], ctx, scope)
        val start = jsNumber(eval(expr[2], ctx, scope)).toInt()
        val end = if (argc >= 3) jsNumber(eval(expr[3], ctx, scope)).toInt() else null
        return when (input) {
            is String -> {
                val (from, to) = sliceBounds(input.length, start, end)
                input.substring(from, to)
            }
            is List<*> -> {
                val (from, to) = sliceBounds(input.size, start, end)
                input.subList(from, to)
            }
            else -> emptyList<Any?>()
        }
    }

    /** JS `Array.prototype.slice` bounds: a negative index counts from the end, and ranges clamp. */
    private fun sliceBounds(size: Int, start: Int, end: Int?): Pair<Int, Int> {
        val from = (if (start < 0) size + start else start).coerceIn(0, size)
        val to = (if (end == null) size else if (end < 0) size + end else end).coerceIn(from, size)
        return from to to
    }

    private fun evalStep(expr: List<*>, ctx: ExpressionContext, scope: Map<String, Any?>): Any? {
        val argc = expr.size - 1
        if (argc < 2) throw ExpressionEvaluationException("step: expected at least input and default output")
        if (argc > 2 && argc % 2 != 0) {
            throw ExpressionEvaluationException("step: expected stop_input/stop_output pairs")
        }
        val input = jsNumber(eval(expr[1], ctx, scope))
        if (input.isNaN()) throw ExpressionEvaluationException("step: input must evaluate to a number")

        var output = expr[2]
        if (argc == 2) return eval(output, ctx, scope)

        var previousStop = Double.NEGATIVE_INFINITY
        var i = 3
        while (i < expr.size) {
            val stop = asDoubleOrNull(expr[i])
                ?: throw ExpressionEvaluationException("step: stop inputs must be numeric literals")
            if (stop <= previousStop) {
                throw ExpressionEvaluationException("step: stop inputs must be strictly ascending")
            }
            if (input < stop) break
            output = expr.getOrNull(i + 1)
            previousStop = stop
            i += 2
        }
        return eval(output, ctx, scope)
    }

    private fun evalInterpolate(expr: List<*>, ctx: ExpressionContext, scope: Map<String, Any?>): Any? {
        val interpolation = expr[1] as? List<*>
            ?: throw ExpressionEvaluationException("interpolate: expected an interpolation type")
        val type = interpolation.getOrNull(0) as? String
        val base = asDoubleOrNull(interpolation.getOrNull(1)) ?: 1.0
        val input = jsNumber(eval(expr[2], ctx, scope))

        var i = 3
        while (i < expr.size - 2) {
            val t0 = jsNumber(normalizeNumber(expr[i]))
            val v0 = jsNumber(eval(expr[i + 1], ctx, scope))
            val t1 = jsNumber(normalizeNumber(expr[i + 2]))
            val v1 = jsNumber(eval(expr[i + 3], ctx, scope))
            if (input >= t0 && input < t1) {
                val ratio = (input - t0) / (t1 - t0)
                val interp = if (type == "exponential") ratio.pow(base) else ratio
                return v0 + (v1 - v0) * interp
            }
            i += 2
        }
        return eval(expr.last(), ctx, scope)
    }

    private fun evalCase(expr: List<*>, ctx: ExpressionContext, scope: Map<String, Any?>): Any? {
        var i = 1
        while (i < expr.size - 1) {
            if (truthy(eval(expr[i], ctx, scope))) return eval(expr[i + 1], ctx, scope)
            i += 2
        }
        return eval(expr.last(), ctx, scope)
    }

    private fun evalMatch(expr: List<*>, ctx: ExpressionContext, scope: Map<String, Any?>): Any? {
        val input = eval(expr[1], ctx, scope)
        var i = 2
        while (i < expr.size - 1) {
            val label = expr[i]
            val matched = if (label is List<*>) {
                label.any { strictEquals(normalizeNumber(it), input) }
            } else {
                strictEquals(normalizeNumber(label), input)
            }
            if (matched) return eval(expr[i + 1], ctx, scope)
            i += 2
        }
        return eval(expr.last(), ctx, scope)
    }

    private fun evalLet(expr: List<*>, ctx: ExpressionContext, scope: Map<String, Any?>): Any? {
        val tail = expr.size - 1
        if (tail < 1) {
            throw ExpressionEvaluationException("let: expected at least one argument (result expression)")
        }
        if (tail % 2 == 0) {
            throw ExpressionEvaluationException(
                "let: expected zero or more [name, value] pairs followed by one result expression",
            )
        }
        val inner = LinkedHashMap(scope)
        var i = 1
        while (i < expr.size - 1) {
            val name = expr[i] as? String
                ?: throw ExpressionEvaluationException("let: binding names must be strings")
            // Bind into the scope being built, so a later binding can read an earlier one.
            inner[name] = eval(expr[i + 1], ctx, inner)
            i += 2
        }
        return eval(expr.last(), ctx, inner)
    }

    private fun assertType(
        expr: List<*>,
        ctx: ExpressionContext,
        scope: Map<String, Any?>,
        name: String,
        predicate: (Any?) -> Boolean,
    ): Any? {
        for (i in 1..(expr.size - 1)) {
            val v = eval(expr[i], ctx, scope)
            if (predicate(v)) return v
        }
        throw ExpressionEvaluationException("$name assertion failed")
    }

    // ---- operand resolution ----

    /**
     * Resolves one side of a comparison.
     *
     * A bare string on the left is a property path, which is what makes `["==", "report.cat", "wind"]`
     * work; on the right it stays a literal, so the same expression compares against the text "wind".
     */
    private fun comparisonOperand(
        arg: Any?,
        ctx: ExpressionContext,
        scope: Map<String, Any?>,
        propertyShorthand: Boolean,
    ): Any? =
        if (propertyShorthand && arg is String && !arg.startsWith("$")) {
            resolveProperty(arg, ctx.properties)
        } else {
            eval(arg, ctx, scope)
        }

    private inline fun compareOperands(
        expr: List<*>,
        ctx: ExpressionContext,
        scope: Map<String, Any?>,
        accept: (Int) -> Boolean,
    ): Boolean {
        val a = comparisonOperand(expr[1], ctx, scope, propertyShorthand = true)
        val b = comparisonOperand(expr.getOrNull(2), ctx, scope, propertyShorthand = false)
        val order = compareValues(a, b) ?: return false
        return accept(order)
    }

    /** JS relational comparison: numeric when both sides are numbers, lexicographic for strings. */
    private fun compareValues(a: Any?, b: Any?): Int? {
        if (a is String && b is String) return a.compareTo(b)
        val x = jsNumber(a)
        val y = jsNumber(b)
        if (x.isNaN() || y.isNaN()) return null
        return x.compareTo(y)
    }

    /** JS `===`: no cross-type coercion, but every number is a double. */
    private fun strictEquals(a: Any?, b: Any?): Boolean {
        val x = normalizeNumber(a)
        val y = normalizeNumber(b)
        if (x is Double && y is Double) return x == y
        return x == y
    }

    /**
     * Reads [path] out of a property bag. A dotted path walks nested maps, which is how the weather
     * products address `report.cat` and `details.range.maxTimestamp`.
     */
    private fun resolveProperty(path: Any?, bag: Any?): Any? {
        val segments = when (path) {
            is String ->
                if (path.contains('.')) path.split('.') else return normalizeNumber(mapValue(bag, path))
            is List<*> -> path.mapNotNull { it as? String }
            else -> return null
        }
        var current: Any? = bag
        for (segment in segments) {
            current = mapValue(current, segment) ?: return null
        }
        return normalizeNumber(current)
    }

    private fun mapValue(bag: Any?, key: String): Any? = (bag as? Map<*, *>)?.get(key)

    // ---- JS value semantics ----

    /** JS truthiness: empty string, 0, NaN, null and false are falsy; everything else is truthy. */
    internal fun truthy(value: Any?): Boolean = when (value) {
        null -> false
        is Boolean -> value
        is String -> value.isNotEmpty()
        is Double -> value != 0.0 && !value.isNaN()
        is Number -> value.toDouble() != 0.0
        else -> true
    }

    /** Every JS number is a double, so `["==", 5, 5.0]` has to be true here too. */
    internal fun normalizeNumber(value: Any?): Any? = when (value) {
        is Double -> value
        is Number -> value.toDouble()
        else -> value
    }

    /** JS `Number(value)`: a numeric string parses, blank is 0, anything else is NaN. */
    internal fun jsNumber(value: Any?): Double = when (value) {
        null -> Double.NaN
        is Double -> value
        is Number -> value.toDouble()
        is Boolean -> if (value) 1.0 else 0.0
        is String -> if (value.isBlank()) 0.0 else value.trim().toDoubleOrNull() ?: Double.NaN
        is Date -> value.time.toDouble()
        else -> Double.NaN
    }

    /**
     * JS `String(value)`. The part that matters for labels is that a whole number prints without a
     * decimal point: Kotlin's `1.0.toString()` is `"1.0"` where JS gives `"1"`, so a concatenated
     * label would otherwise read "1.0 in" everywhere JS reads "1 in".
     */
    internal fun jsString(value: Any?): String = when (value) {
        null -> "null"
        is Double -> when {
            value.isNaN() -> "NaN"
            value == Double.POSITIVE_INFINITY -> "Infinity"
            value == Double.NEGATIVE_INFINITY -> "-Infinity"
            value == floor(value) && abs(value) < 1e21 -> value.toLong().toString()
            else -> value.toString()
        }
        is Float -> jsString(value.toDouble())
        is Number -> value.toString()
        is List<*> -> value.joinToString(",") { jsString(it) }
        else -> value.toString()
    }

    /** JS `typeof`. Kotlin has one null, so a missing property reads as `undefined`. */
    private fun jsTypeOf(value: Any?): String = when (value) {
        null -> "undefined"
        is Boolean -> "boolean"
        is Number -> "number"
        is String -> "string"
        else -> "object"
    }

    /** JS `+`: numeric until a string joins in, then concatenation for the rest. */
    private fun jsAdd(acc: Any?, value: Any?): Any? =
        if (acc is String || value is String) {
            jsString(acc) + jsString(value)
        } else {
            jsNumber(acc) + jsNumber(value)
        }

    /** JS `Math.round`: a half always goes up, including a negative half. */
    private fun jsRound(value: Double): Double = when {
        value.isNaN() || value.isInfinite() -> value
        else -> floor(value + 0.5)
    }

    private fun roundToPrecision(value: Double, precision: Int): Double {
        if (precision <= 0) return jsRound(value)
        val factor = 10.0.pow(precision)
        return jsRound(value * factor) / factor
    }

    private fun localeNumber(value: Double, languageTag: String): String =
        NumberFormat.getNumberInstance(Locale.forLanguageTag(languageTag)).format(value)

    private fun toDateOrNull(value: Any?): Date? = when (value) {
        null -> null
        is Date -> value
        is Number -> Date(value.toLong())
        is String -> parseDateString(value)
        else -> null
    }

    /** ISO-8601 first (what the APIs return), then a bare epoch in milliseconds. */
    private fun parseDateString(value: String): Date? =
        try {
            Date.from(Instant.parse(value))
        } catch (e: DateTimeParseException) {
            try {
                Date.from(LocalDateTime.parse(value).toInstant(ZoneOffset.UTC))
            } catch (e2: DateTimeParseException) {
                value.toLongOrNull()?.let { Date(it) }
            }
        }

    private fun asDoubleOrNull(value: Any?): Double? = (value as? Number)?.toDouble()

    private fun unwrap(value: Any?): Any? = if (value is Expression) value.raw else value

    /** An expression is a non-empty list whose head is a known operator name. */
    internal fun isExpressionArray(value: Any?): Boolean {
        val list = value as? List<*> ?: return false
        val head = list.firstOrNull() as? String ?: return false
        return head in ExpressionOperators.ALL_OPERATORS
    }

    // ---- regex cache ----

    private val regexCache = object : LinkedHashMap<String, Regex>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Regex>): Boolean =
            size > MAX_REGEX_CACHE_SIZE
    }

    private fun cachedRegex(pattern: String, flags: String?): Regex? {
        val key = "$pattern::${flags.orEmpty()}"
        synchronized(regexCache) { regexCache[key] }?.let { return it }

        val options = buildSet {
            if (flags?.contains('i') == true) add(RegexOption.IGNORE_CASE)
            if (flags?.contains('m') == true) add(RegexOption.MULTILINE)
            if (flags?.contains('s') == true) add(RegexOption.DOT_MATCHES_ALL)
        }
        val regex = try {
            Regex(pattern, options)
        } catch (e: IllegalArgumentException) {
            return null
        }
        synchronized(regexCache) { regexCache[key] = regex }
        return regex
    }

    private const val MAX_REGEX_CACHE_SIZE = 128
    private const val LN2 = 0.6931471805599453
}
