package com.xweather.mapsgl.style

import android.graphics.Bitmap
import android.opengl.GLES31
import android.opengl.GLUtils
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.core.graphics.createBitmap
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.SampleChannel
import kotlin.math.ceil
import kotlin.math.floor

const val TAG = "ColorLookupTable"

data class ColorEntry(
    val color: Int,
    val position: Double,
    val value: Double
)

/**
 * Color lookup table.
 *
 * @property stops A set of values to use as color stops in the scale. When stops are provided, then the scale will not interpolate intermediate colors between stop values.
 * @property range The value range for the scale.
 * @property interpolate Whether color values between the defined color stops should be interpolated. When enabled, colors will be linearly interpolated and appear more gradient-like. Otherwise, values in between color stops will use the next lowest color stop resulting in only the provided color stops being rendered.
 * @property interval Interval for which color stops are desired within the data range. This value must be in the same unit as the values provided in stops and the underlying data. If set to 0.0, then the color scale will be linearly interpolated between color stops to produce a smooth gradient.
 * @property roundDown Which way to round when interpolating colorstops. Default is false.
 * @constructor Create [ColorLookupTable]
 */
class ColorLookupTable(
    inputStops: List<Any>,
    val range: ClosedRange<Double>,
    val interpolate: Boolean = true,
    val interval: Double = 0.0,
    var roundDown: Boolean = false
) {

    var filteredStops = mutableListOf<ColorStop>()
    //var positions: List<Double> = emptyList()
    //    private set

    //var range: ClosedRange<Double> = range
    var normalized: Boolean = false
    val isGradient: Boolean
        get() = interval == 0.0

    var channel: SampleChannel? = null

    /**
     * When this LUT was built from [ColorMaskOptions], the raster band that holds the mask code
     * (Apple `maskBand` / JS mask `channel`).
     */
    var maskBand: ColorBand? = null

    /**
     * Discrete mask code for [maskBand] (Apple `maskValue` / JS mask `value`), e.g. radar ptype 1/2/3.
     */
    var maskValue: Int? = null

    //var scale: ColorScale
    val initialStops: List<ColorStop>

    init {

        if (inputStops[0] is ColorStop) {  // Only 1 list of colorstops
            //if(pr.ON)pr.p("ColorLookupTable", pr.radar, "detected NON radar!!!")
            initialStops = inputStops as List<ColorStop>
            //scale = ColorScale(/*stops.map { it.color.hashCode() }*/)

        } else { //multiple colorstops, used for ptype radar
            //if(pr.ON)pr.p("ColorLookupTable", pr.radar, "detected radar!!!") //prate radar
            //TODO: Logic to get started on p-rate
            initialStops = inputStops[0] as List<ColorStop>
            //scale = ColorScale(/*stops.map { it.color.hashCode() }*/)
        }
    }

    /** Applies [resolveRangeStartAnchor] to [filteredStops]. */
    private fun anchorStopAtRangeStart(inputStops: List<ColorStop>) {
        resolveRangeStartAnchor(inputStops, filteredStops, range.start, interpolate)
            ?.let { filteredStops.add(0, it) }
    }

    fun createColorLookupBitmap(width: Int, height: Int, inputStops: List<ColorStop> = initialStops): Bitmap {
        filteredStops.clear()
        var i = 0
        for (stop in inputStops) {
            if (stop.value >= range.start && stop.value <= range.endInclusive) {
                if (pr.ON) pr.p(TAG, pr.customColor, "${stop.value} ADDED. ${stop.color}")
                filteredStops.add(stop)
                //println(">>> ColorLookupTable createColorLookupBitmap() 80 ADDING stop ${stop}: from range: $range")
            }
            else {
                ///println(">>> ColorLookupTable createColorLookupBitmap() 90 excluding stop ${stop}: from range: $range")
            }
            i++
        }

        anchorStopAtRangeStart(inputStops)

        if (!interpolate && interval > 0.0) {
            val oldStops = filteredStops as List<ColorStop>
            val newStops: MutableList<ColorStop> = mutableListOf()

            var newVal = oldStops.first().value
            val count = oldStops.size
            var i = 0
            var dist1: Double
            var dist2: Double
            var totDist: Double
            //println(">>> ColorLookupTable createColorLookupBitmap() 100 range: $range")
            while (newVal <= range.endInclusive) {

                if (newVal <= oldStops.first().value) {
                    newStops.add(
                        ColorStop(
                            newVal,
                            Color(
                                oldStops.first().color.red,
                                oldStops.first().color.green,
                                oldStops.first().color.blue,
                                oldStops.first().color.alpha
                            )
                        )
                    )
                } else if (newVal >= oldStops.last().value) {
                    newStops.add(
                        ColorStop(
                            newVal,
                            Color(
                                oldStops.last().color.red,
                                oldStops.last().color.green,
                                oldStops.last().color.blue,
                                oldStops.last().color.alpha
                            )
                        )
                    )
                } else {
                    i = 0
                    while (i < count) {

                        if (newVal == inputStops[i].value) {
                            newStops.add(
                                ColorStop(
                                    newVal,
                                    Color(
                                        inputStops[i].color.red,
                                        inputStops[i].color.green,
                                        inputStops[i].color.blue,
                                        inputStops[i].color.alpha
                                    )
                                )
                            )
                        } else if (newVal > inputStops[i].value && newVal < inputStops[i + 1].value) {
                            // Takes the stop below, rather than blending toward the stop above.
                            //
                            // This branch only runs for `interpolate = false` with a non-zero
                            // `interval`, and blending here contradicted both settings: it turned a
                            // stepped scale back into a gradient, re-expressed as one stop per
                            // interval. A three-category frost scale came out as a smooth ramp, so
                            // a value well inside one category drew as the next category's colour.
                            // Matches the documented behaviour - "values in between color stops
                            // will use the next lowest color stop" - and the JS SDK.
                            newStops.add(
                                ColorStop(
                                    newVal,
                                    Color(
                                        inputStops[i].color.red,
                                        inputStops[i].color.green,
                                        inputStops[i].color.blue,
                                        inputStops[i].color.alpha
                                    )
                                )
                            )
                        } else {

                        }
                        i++
                    }
                }
                newVal += interval
            }
            println(">>>> ColorLookupTable createColorLookupBitmap() 60 seting filtered stops to value of newStops. range: $range")
            filteredStops = newStops
            //println("ColorLookupTable createColorLookupBitmap() colorlist now has ${filteredStops.size} items")

        } else if (interpolate && interval > 0.0 && filteredStops.size > 1) {
            // Interval with interpolation on is a band width through the blended ramp: each step
            // is `interval` wide and takes the color the smooth scale would have at that value.
            // Leaving interpolation off keeps the lower authored stop, which is the categorical
            // scale (frost and the like) and is handled above.
            val stepped = intervalBlendedStops(filteredStops)
            if (stepped.isNotEmpty()) filteredStops = stepped
        }
        pr.p(TAG, pr.customColor, "createColorLookupBitmap() 70 ")
        val bitmap = createBitmap(width, height)
        val pixels = IntArray(width)
        var stopCounter = 0;
        var pixelCounter = 0
        pr.p(TAG, pr.customColor, "createColorLookupBitmap() 75 ")
        if (!interpolate || interval > 0.0) { //flat color per stop, including interval steps
            if (false) { //equidistant color stops
                val stopLength = (width / filteredStops.count())
                for (stop in filteredStops) {
                    for (i in 0 until stopLength) {
                        pixels[pixelCounter] = stop.color.toArgb()
                        //println("Setting pixel to ${pixels[pc]}")
                        pixelCounter++

                    }
                    stopCounter++
                }
                while (pixelCounter < pixels.size) {
                    pixels[pixelCounter] = filteredStops.last().color.toArgb()
                    pixelCounter++
                }
            } else { //240709, trying to fix AQI CAT
                pr.p(TAG, pr.customColor, "createColorLookupBitmap() 80 ")
                val delta = range.endInclusive - range.start
                var s = 0
                var stopLength = 0

                for (stop in filteredStops) {
                    if (s <= filteredStops.size - 2)
                        stopLength = (((filteredStops[s + 1].value - filteredStops[s].value) / delta) * width).toInt()
                    else {
                        stopLength = width - pixelCounter

                    }
                    if (s == 0 && stopLength == 0) {
                        stopLength = 1
                    }
                    for (i in 0 until stopLength) {
                        pixels[pixelCounter] = stop.color.toArgb()
                        pixelCounter++

                    }
                    stopCounter++
                    s++
                }
                while (pixelCounter < pixels.size) { //fill out remaining bits
                    pixels[pixelCounter] = filteredStops.last().color.toArgb()
                    pixelCounter++
                }
            }
        } else if (false) { //gradient, equal spacing
            val stopLength = (width / filteredStops.count()) //fixme: this is imprecise....
            println(">>> ColorLookupTablefilteredStops count : ${filteredStops.count()}")
            var mult: Float
            var mult2: Float
            for ((stopCounter, stop) in filteredStops.withIndex()) {
                for (i in 0 until stopLength) {
                    if (stopCounter + 1 < filteredStops.count()) { //next stop exists to blend with
                        mult = (stopLength - i) / stopLength.toFloat()
                        mult2 = (i) / stopLength.toFloat()
                        pixels[pixelCounter] = Color(
                            stop.color.red * mult + (filteredStops[stopCounter + 1].color.red * mult2),
                            stop.color.green * mult + (filteredStops[stopCounter + 1].color.green * mult2),
                            stop.color.blue * mult + (filteredStops[stopCounter + 1].color.blue * mult2)
                        ).toArgb()
                    } else { //last stop, no blending with next
                        pixels[pixelCounter] = Color(stop.color.red, stop.color.green, stop.color.blue).toArgb()
                    }
                    pixelCounter++

                }
            }
        } else { //gradient, variable spacing
            //val stopLengthArray = IntArray(stops.count())
            var stopLength: Int
            var mult: Float
            var mult2: Float
            if (filteredStops.isNotEmpty()) {
                pixels.fill(filteredStops.first().color.toArgb())
            }
            //println("ColorLookupTable createColorLookupBitmap() p7 num filtered stops: ${filteredStops.count()}")
            val totalDelta: Double
            if (filteredStops.count() == inputStops.count()) {
                totalDelta = range.endInclusive - range.start// delta from range, 240709, when troubleshooting AQI
            } else { //for some reason, temp 24hr should use this... even though color stops are the same?
                totalDelta =
                    filteredStops[filteredStops.count() - 1].value - filteredStops.first().value// delta from colorstops, for winds
            }

            val n = filteredStops.size
            // Floor-based segment lengths often sum to << width when many stops are close; the old tail loop
            // then duplicated the last written texel (often the final purple stop) across most of the LUT,
            // so GL_LINEAR sampled purple for typical normalized values (full-screen purple overlay).
            val segmentLengths: IntArray = if (n < 2) {
                intArrayOf(width.coerceAtLeast(1))
            } else {
                val blendPixelBudget = (width - 1).coerceAtLeast(0)
                val raw = DoubleArray(n - 1) { i ->
                    val stopDelta = filteredStops[i + 1].value - filteredStops[i].value
                    (stopDelta / totalDelta) * blendPixelBudget
                }
                val lengths = IntArray(n) { idx ->
                    if (idx < n - 1) floor(raw[idx]).toInt() else 1
                }
                var remainder = width - lengths.sum()
                while (remainder > 0) {
                    val j = (0 until n - 1).maxByOrNull { raw[it] - lengths[it] }!!
                    lengths[j]++
                    remainder--
                }
                while (remainder < 0) {
                    val j = (0 until n - 1).maxByOrNull { lengths[it] - raw[it] }!!
                    if (lengths[j] > 0) lengths[j]--
                    remainder++
                }
                lengths
            }

            for ((stopCounter, stop) in filteredStops.withIndex()) {
                stopLength = segmentLengths[stopCounter]

                for (i in 0 until stopLength) {
                    if (roundDown) { //round down
                        if (stopCounter != 0) { //previous stop exists to blend with
                            mult = (i).toFloat() / stopLength.toFloat()
                            mult2 = (stopLength - i).toFloat() / stopLength.toFloat()
                            pixels[pixelCounter] = Color(
                                stop.color.red * mult + (filteredStops[stopCounter - 1].color.red * mult2),
                                stop.color.green * mult + (filteredStops[stopCounter - 1].color.green * mult2),
                                stop.color.blue * mult + (filteredStops[stopCounter - 1].color.blue * mult2),
                                stop.color.alpha * mult + (filteredStops[stopCounter - 1].color.alpha * mult2)
                            ).toArgb()
                        } else { //first stop, just use color for first stop
                            pixels[pixelCounter] =
                                Color(stop.color.red, stop.color.green, stop.color.blue, stop.color.alpha).toArgb()
                        }
                    } else {  //orig Round Up
                        if (stopCounter + 1 < filteredStops.count()) { //next stop exists to blend with
                            mult = (stopLength - i).toFloat() / stopLength.toFloat()
                            mult2 = (i).toFloat() / stopLength.toFloat()
                            pixels[pixelCounter] = Color(
                                stop.color.red * mult + (filteredStops[stopCounter + 1].color.red * mult2),
                                stop.color.green * mult + (filteredStops[stopCounter + 1].color.green * mult2),
                                stop.color.blue * mult + (filteredStops[stopCounter + 1].color.blue * mult2),
                                stop.color.alpha * mult + (filteredStops[stopCounter + 1].color.alpha * mult2)
                            ).toArgb()
                            //println("ColorLookup Wrote this color p7 ${pixels[pixelCounter]}")

                        } else { //last stop, no blending with next
                            if (pixelCounter < pixels.size) {
                                pixels[pixelCounter] = Color(
                                    stop.color.red,
                                    stop.color.green,
                                    stop.color.blue,
                                    stop.color.alpha
                                ).toArgb()
                            }
                        }
                    } //end roundUp
                    pixelCounter++
                    //if(pr.ON)pr.p(TAG,pr.radar,"stopLength: $stopLength    pixelCounter:$pixelCounter")
                }
            }
        }
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        return bitmap
    }

    /** One stop per [interval], colored by linear interpolation of [stops]. */
    private fun intervalBlendedStops(stops: List<ColorStop>): MutableList<ColorStop> {
        val result = mutableListOf<ColorStop>()
        if (stops.isEmpty() || interval <= 0.0) return result
        var value = stops.first().value
        val end = maxOf(range.endInclusive, stops.last().value)
        var guard = 0
        while (value <= end + interval * 1e-9 && guard < 100_000) {
            result.add(ColorStop(value, colorBlendedAt(stops, value)))
            value += interval
            guard++
        }
        return result
    }

    private fun colorBlendedAt(stops: List<ColorStop>, value: Double): Color {
        if (stops.size == 1 || value <= stops.first().value) return stops.first().color
        if (value >= stops.last().value) return stops.last().color
        var i = 0
        while (i < stops.lastIndex && stops[i + 1].value < value) i++
        val left = stops[i]
        val right = stops[i + 1]
        val span = right.value - left.value
        val t = if (span == 0.0) 0f else ((value - left.value) / span).toFloat()
        return Color(
            left.color.red + (right.color.red - left.color.red) * t,
            left.color.green + (right.color.green - left.color.green) * t,
            left.color.blue + (right.color.blue - left.color.blue) * t,
            left.color.alpha + (right.color.alpha - left.color.alpha) * t,
        )
    }

    companion object {

        /**
         * Width of the 1×N GPU color ramp bitmap for encoded tiles (temperature, etc.).
         * Must match `colorScaleRes` in `assets/shaders/sample.frag.combined.glsl` and
         * `sample-multiband.frag.glsl`.
         */
        const val GPU_COLOR_LUT_WIDTH = 1024

        fun bitmapToTextureHandle(
            bitmap: Bitmap,
            interpolate: Boolean = true,
        ): Int {
            val textureHandle = IntArray(1)
            GLES31.glGenTextures(1, textureHandle, 0)

            if (textureHandle[0] != 0) {
                bitmap.let {
                    GLES31.glBindTexture(GLES31.GL_TEXTURE_2D, textureHandle[0])
                    // Match release/1.5.0 / WebGL: LINEAR on the ramp when the scale is interpolated so the GPU
                    // smooths along the LUT. NEAREST when not interpolated (discrete steps). LINEAR can show a slight
                    // fringe transparent ↔ first opaque stop at ramp edges; NEAREST avoids that for stepped scales.
                    if (interpolate) {
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_LINEAR)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_LINEAR)
                    } else {
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MIN_FILTER, GLES31.GL_NEAREST)
                        GLES31.glTexParameteri(GLES31.GL_TEXTURE_2D, GLES31.GL_TEXTURE_MAG_FILTER, GLES31.GL_NEAREST)
                    }
                    GLUtils.texImage2D(GLES31.GL_TEXTURE_2D, 0, bitmap, 0)
                    bitmap.recycle()
                }
            }
            return textureHandle[0]
        }
    }
}

fun Double.roundedUpToMultiple(multiple: Double): Double {
    return ceil(this / multiple) * multiple
}

fun Double.roundedDownToMultiple(multiple: Double): Double {
    return floor(this / multiple) * multiple
}

/**
 * The stop to graft onto a colour scale's range floor, or `null` when the scale needs none.
 *
 * Stops outside the LUT's range are dropped, and a stop below the floor takes its colour with it.
 * That is a quiet way to lose a whole category: a scale anchored below the layer's data range - the
 * natural way to say "everything colder than this is one colour" - renders with its coldest colour
 * absent, and the band it should have painted shows the next colour up instead.
 *
 * Returns `null`, changing nothing, whenever [filteredStops] already covers the floor. That is the
 * usual shape of the built-in scales, whose range and stops are generally the same numbers, so they
 * are unaffected.
 *
 * Only the bottom of the range needs this. A stepped scale gives a value the stop at or below it,
 * so a stop above the ceiling can never be the answer for any value in range and dropping it is
 * correct.
 */
internal fun resolveRangeStartAnchor(
    inputStops: List<ColorStop>,
    filteredStops: List<ColorStop>,
    rangeStart: Double,
    interpolate: Boolean,
): ColorStop? {
    if (inputStops.isEmpty()) return null
    if (filteredStops.any { it.value <= rangeStart }) return null

    val below = inputStops.filter { it.value < rangeStart }.maxByOrNull { it.value } ?: return null
    val above = inputStops.filter { it.value > rangeStart }.minByOrNull { it.value }

    val color = if (interpolate && above != null) {
        val span = above.value - below.value
        val t = if (span > 0.0) ((rangeStart - below.value) / span).toFloat() else 0f
        Color(
            below.color.red + (above.color.red - below.color.red) * t,
            below.color.green + (above.color.green - below.color.green) * t,
            below.color.blue + (above.color.blue - below.color.blue) * t,
            below.color.alpha + (above.color.alpha - below.color.alpha) * t,
        )
    } else {
        below.color
    }
    return ColorStop(rangeStart, color)
}
