package com.xweather.mapsgl.style

/**
 * Rewrites pre-MapsGL JS 1.9.0 filter shorthand into the explicit expression form.
 *
 * **The SDK does not apply this automatically in 1.8.0.** Call [migrate] yourself on filters written
 * for MapsGL JS earlier than 1.9.0 before passing them to a layer.
 *
 * Before MapsGL JS 1.9.0 a filter could name a property directly — `['==', 'report.cat', 'wind']` —
 * and the evaluator would look it up. From 1.9.0 the operand must be an expression,
 * `['==', ['get', 'report.cat'], 'wind']`, and 1.9.1 added this migration so configurations written
 * against the old shape keep working.
 *
 * ## Why Android needs it even though it never had the shorthand
 *
 * The Android evaluator has always treated a bare string operand as a *literal*, so it already meets
 * the 1.9.0 contract and there is nothing here to migrate away from. The risk is the other direction:
 * layer configurations are shared between platforms, and a legacy one that JS silently migrates would,
 * on Android, compare a property's value against the literal text of its own name. That never matches,
 * so the features simply vanish with no error — the worst kind of divergence to debug.
 *
 * Running the same migration means a shared configuration loads identically on both.
 *
 * ## What it rewrites
 *
 * - `['time']`, `['timeline']` and `['mapTime']` → `['map-time']`, the canonical operator
 * - `['in', 'VTEC', 'SV.A', 'SV.W']` → `['in', ['get', 'VTEC'], ['literal', ['SV.A', 'SV.W']]]`
 * - `['==', 'report.cat', 'wind']` → `['==', ['get', 'report.cat'], 'wind']`, and the same for
 *   `!=`, `<`, `<=`, `>`, `>=`
 * - `all` / `any` / `not` recurse into their arguments
 *
 * Operands beginning with `$` are Mapbox scope names such as `$type` and are left alone. The
 * transform is idempotent: an already-migrated tree passes through unchanged.
 *
 * **Caution:** any bare string as the left operand of a comparison is treated as a property name,
 * so `['==', 'wind', ['get', 'report.cat']]` becomes `['==', ['get', 'wind'], …]`. Only migrate
 * filters that really use the legacy shorthand.
 */
public object LegacyFilterMigration {

    private val COMPARISON_OPS = setOf("==", "!=", "<", "<=", ">", ">=")

    /** Matches a bare key that is obviously a property name, e.g. `VTEC` or `POP_MAX`. */
    private val SCREAMING_CASE = Regex("^[A-Z][\\dA-Z_]*$")

    /**
     * Returns [filter] with any legacy shorthand rewritten, or the same instance when nothing needed
     * changing.
     */
    public fun migrate(filter: Expression?): Expression? {
        if (filter == null) return null
        // migrateValue only returns null for a null input, and raw is non-null here.
        val migrated = migrateValue(filter.raw) ?: return filter
        return if (migrated === filter.raw) filter else Expression(migrated)
    }

    /** True when [expr] still uses a pre-MapsGL JS 1.9.0 shape anywhere in its tree. */
    public fun isLegacy(expr: Any?): Boolean {
        val list = expr as? List<*> ?: return false
        if (list.isEmpty()) return false
        if (isLegacyIn(list) || isLegacyComparison(list)) return true
        return list.drop(1).any { isLegacy(it) }
    }

    private fun migrateValue(value: Any?): Any? =
        if (value is List<*>) migrateList(value) else value

    private fun migrateList(list: List<*>): Any? {
        if (list.isEmpty()) return list
        val op = list[0] as? String ?: return list
        val args = list.drop(1)

        // `['time']` is a deprecated alias and `['timeline']` was removed outright in JS; both mean
        // the timeline position, so both normalise to the canonical operator. Android's evaluators
        // still accept every spelling, so nothing that used them breaks — they just stop spreading.
        if (list.size == 1 && (op == "time" || op == "timeline" || op == "mapTime")) {
            return listOf("map-time")
        }

        if (op == "in" && isLegacyIn(list)) {
            val key = args[0] as String
            val candidates = args.drop(1)
            return listOf("in", listOf("get", key), listOf("literal", candidates))
        }

        if (op in COMPARISON_OPS && args.size >= 2) {
            val left = args[0]
            if (left is String && !left.startsWith("$")) {
                return listOf(op, listOf("get", left), migrateValue(args[1]))
            }
        }

        // Recurse into the arguments, returning the original list when none of them changed so a
        // modern filter is not reallocated on every pass.
        val migratedArgs = args.map { migrateValue(it) }
        val unchanged = migratedArgs.indices.all { migratedArgs[it] === args[it] }
        return if (unchanged) list else listOf(op) + migratedArgs
    }

    /**
     * The pre-1.9.0 variadic `in`: a bare key followed by plain candidates.
     *
     * A two-element form is ambiguous — `['in', 'a', 'b']` could be the new shape with a string needle
     * — so it only counts as legacy when the key looks like a property name: dotted, or SCREAMING_CASE.
     */
    private fun isLegacyIn(list: List<*>): Boolean {
        if (list.size < 3 || list[0] != "in") return false
        val key = list[1] as? String ?: return false
        if (key.startsWith("$")) return false
        val candidates = list.drop(2)
        if (candidates.any { it is List<*> }) return false
        if (list.size >= 4) return true
        return key.contains('.') || SCREAMING_CASE.matches(key)
    }

    /** A comparison whose left operand is a bare property name rather than an expression. */
    private fun isLegacyComparison(list: List<*>): Boolean {
        if (list.size < 3) return false
        val op = list[0] as? String ?: return false
        if (op !in COMPARISON_OPS) return false
        val left = list[1]
        return left is String && !left.startsWith("$")
    }
}
