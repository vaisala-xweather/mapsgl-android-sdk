package com.xweather.mapsgl.style

import androidx.compose.ui.graphics.Color

/**
 * Per-span formatting options for Mapbox `format` expressions built with [Expression.Companion.format].
 *
 * Serialized to a small JSON object (`font-scale`, `text-font`, `text-color`) alongside each text fragment.
 */
data class TextFormatOptions(
    var fontScale: Double? = null,
    var textFont: List<String>? = null,
    var textColor: Color? = null
) {
    /** JSON object with `font-scale`, `text-font`, and `text-color` when set. */
    fun toJSONObject(): Map<String, Any> {
        val obj = mutableMapOf<String, Any>()
        fontScale?.let { obj["font-scale"] = it }
        textFont?.let { obj["text-font"] = it }
        textColor?.let { obj["text-color"] = it.toRGBAString() }
        return obj
    }
}

/**
 * Mapbox **style expression** wrapper: a JSON-serializable tree (usually a [List] whose first
 * element is the operator) compatible with the Mapbox expression spec.
 *
 * Use the companion factories (`get`, `interpolate`, `match`, …) and wrap the result in
 * [StyleValue.Expression] for data-driven paint, or assign the expression to
 * [com.xweather.mapsgl.layers.spec.VectorLayerDescriptor.filter].
 *
 * **Where expressions run**
 * - Mapbox **native** style layers evaluate the serialized JSON (full Mapbox operator set).
 * - MapsGL **GLES** vector layers (`useGlRendering = true`) evaluate a documented subset on the
 *   Feature path for paint and layer filters. Unknown operators fail closed (no color / feature
 *   dropped) and may fall back from a narrower circle fast-path to the Feature evaluator.
 * - [zoom] is an input for GLES **paint** evaluation, not for **filters**.
 * - [mapTime] / [time] are handled by the map-time filter/reveal path, not the generic paint evaluator.
 *
 * Operators that GLES does **not** evaluate still serialize correctly for Mapbox native layers:
 * [format], `interpolate-hcl` / `interpolate-lab`, and [geometryType] in paint.
 *
 * @property raw Underlying value passed to [makeJSONObject] for style JSON or debugging.
 *
 * @see StyleValue.Expression
 * @see makeJSONObject
 */
data class Expression(val raw: Any) {
    /** JSON form of [raw] (`rgba(...)` strings, nested lists, etc.). */
    fun toJSONObject(): Any? = makeJSONObject(raw)

    /**
     * Factory helpers mirroring Mapbox expression operators. Each method returns a new [Expression]
     * node; nest them or wrap in [StyleValue.Expression] as needed.
     *
     * Unless a factory says otherwise, GLES Feature-path evaluation **does** run the operator for
     * fill/line/symbol/heatmap paint and for vector layer filters.
     */
    companion object {
        /**
         * `["geometry-type"]`. Serializes for Mapbox native layers. On GLES it resolves in vector
         * layer filters but not in paint evaluation.
         */
        val geometryType = listOf("geometry-type")

        /**
         * `["zoom"]` — current map zoom.
         *
         * GLES evaluates this for **paint** (color, number, string). Layer **filters** do not
         * receive a zoom input, so zoom-based filters are JSON-only (Mapbox native) on GLES.
         */
        var zoom = listOf("zoom")

        /**
         * Active map timeline position as Unix seconds (from the map controller), not wall clock.
         * iOS/JS `["map-time"]` parity. Used in vector filters; GLES applies it on the dedicated
         * map-time reveal path rather than the generic paint evaluator.
         */
        val mapTime = listOf("map-time")

        /**
         * Deprecated alias for [mapTime] — `["time"]`.
         *
         * MapsGL JS made `map-time` canonical in 1.9.x and left `time` as an alias that evaluates
         * identically. Android's evaluators accept it, so existing filters keep working. Prefer
         * [mapTime] in new code.
         */
        @Deprecated("Use mapTime; `time` is a deprecated alias.", ReplaceWith("mapTime"))
        val time = listOf("time")

        /**
         * Wall-clock time as Unix seconds — `["now"]`.
         *
         * Distinct from [mapTime], which follows the timeline playhead. Like map-time it is
         * re-evaluated at draw time, so a filter using it keeps up with the clock instead of being
         * baked in when the mesh is built.
         */
        val now = listOf("now")

        /** `["to-date", value]` — coerces to a date for comparison or arithmetic. */
        fun toDate(value: Any): Expression = Expression(listOf("to-date", makeJSONObject(value)))

        /**
         * `["to-time", value]` — a date, ISO string or epoch coerced to **Unix seconds**, the unit
         * every time operator agrees on.
         */
        fun toTime(value: Any): Expression = Expression(listOf("to-time", makeJSONObject(value)))

        /**
         * `["to-locale-string", value, locale?]` — a number formatted for [locale] (default
         * `en-US`), with digit grouping.
         */
        fun toLocaleString(value: Any, locale: String? = null): Expression = Expression(
            if (locale == null) {
                listOf("to-locale-string", makeJSONObject(value))
            } else {
                listOf("to-locale-string", makeJSONObject(value), locale)
            },
        )

        /**
         * `["to-unit", value, measurement, baseUnit, toUnit?, precision?]` — converts and formats
         * in one step, the way every MapsGL JS label does.
         *
         * @param measurement Conversion family, e.g. `"temperature"`, `"speed"`, `"precipitation"`.
         * @param baseUnit Unit [value] is already in.
         * @param toUnit Unit to display in; defaults to [baseUnit], which formats without converting.
         * @param precision Decimal places; defaults to the unit's own (two for `in`, `in/hr` and
         *   `inHg`, one for `cm`, zero otherwise).
         * @return A **string** expression — `to-unit` formats, so trailing zeros are preserved.
         */
        fun toUnit(
            value: Any,
            measurement: String,
            baseUnit: String,
            toUnit: String? = null,
            precision: Int? = null,
        ): Expression {
            val args = mutableListOf<Any?>("to-unit", makeJSONObject(value), measurement, baseUnit)
            if (toUnit != null || precision != null) args.add(toUnit ?: baseUnit)
            if (precision != null) args.add(precision)
            return Expression(args.toList())
        }

        /**
         * `["regex", pattern, flags?, input]` — true when [pattern] matches anywhere in [input],
         * like JS `RegExp.test`. Anchor the pattern (`^`, `$`) for a whole-string match.
         *
         * @param flags JS regex flags; `i`, `m` and `s` are honoured.
         */
        fun regex(pattern: String, input: Any, flags: String? = null): Expression = Expression(
            if (flags == null) {
                listOf("regex", pattern, makeJSONObject(input))
            } else {
                listOf("regex", pattern, flags, makeJSONObject(input))
            },
        )

        /** `["typeof", value]` — the JS type name: `string`, `number`, `boolean`, `object`, `undefined`. */
        fun typeOf(value: Any): Expression = Expression(listOf("typeof", makeJSONObject(value)))

        /** `["properties"]` — the whole property bag of the feature being evaluated. */
        val properties = listOf("properties")

        /**
         * `["get", property]` for a feature property. Dotted [property] (e.g. `"vals.0"`) is
         * expanded via [getPath] into nested `get` / `at` nodes.
         */
        fun get(property: String): Expression =
            if (property.contains('.')) getPath(property)
            else Expression(listOf("get", property))

        /**
         * Nested property access: `"a.b"` → `["get", "b", ["get", "a"]]`, and numeric segments
         * such as `"vals.0"` become `["at", 0, ["get", "vals"]]`.
         */
        fun getPath(path: String): Expression {
            val keys = path.split(".")
            return keys.fold(null as Expression?) { acc, key ->
                if (acc == null) Expression(listOf("get", key))
                else {
                    key.toIntOrNull()?.let { Expression(listOf("at", it, acc.raw)) }
                        ?: Expression(listOf("get", key, acc.raw))
                }
            } ?: get("")
        }

        /** `["literal", value]` — wrap a Kotlin value as an expression operand. */
        fun literal(value: Any): Expression = Expression(listOf("literal", value))

        /**
         * `["rgb", red, green, blue]` with channels in `0…255`. GLES evaluates this for fill color.
         */
        fun rgb(red: Any, green: Any, blue: Any): Expression =
            Expression(listOf("rgb", red, green, blue))

        /**
         * `["rgba", red, green, blue, alpha]` with RGB in `0…255` and [alpha] in `0…1`.
         * GLES evaluates this for fill color.
         */
        fun rgba(red: Any, green: Any, blue: Any, alpha: Any): Expression =
            Expression(listOf("rgba", red, green, blue, alpha))

        /** `["-", lhs, rhs]`. */
        fun subtract(lhs: Any, rhs: Any): Expression =
            Expression(listOf("-", lhs, rhs))

        /** Unary negate: `["-", 0, value]`. */
        fun subtract(value: Any): Expression = subtract(0, value)

        /** `["+", lhs, rhs]`. */
        fun add(lhs: Any, rhs: Any): Expression =
            Expression(listOf("+", lhs, rhs))

        /** `["*", lhs, rhs]`. */
        fun multiply(lhs: Any, rhs: Any): Expression =
            Expression(listOf("*", lhs, rhs))

        /** `["/", lhs, rhs]`. */
        fun divide(lhs: Any, rhs: Any): Expression =
            Expression(listOf("/", lhs, rhs))

        /** `["%", lhs, rhs]` (remainder). */
        fun mod(lhs: Any, rhs: Any): Expression =
            Expression(listOf("%", lhs, rhs))

        /** `["floor", value]`. */
        fun floor(value: Any): Expression =
            Expression(listOf("floor", value))

        /** `["ceil", value]`. */
        fun ceil(value: Any): Expression =
            Expression(listOf("ceil", value))

        /** `["round", value]`. */
        fun round(value: Any): Expression =
            Expression(listOf("round", value))

        /** `["abs", value]`. */
        fun abs(value: Any): Expression =
            Expression(listOf("abs", value))

        /** `["min", …values]`. */
        fun min(vararg values: Any): Expression =
            Expression(listOf("min") + values)

        /** `["max", …values]`. */
        fun max(vararg values: Any): Expression =
            Expression(listOf("max") + values)

        /** `["to-number", value]`. */
        fun toNumber(value: Any): Expression =
            Expression(listOf("to-number", value))

        /** `["to-string", value]`. */
        fun toString(value: Any): Expression =
            Expression(listOf("to-string", value))

        /**
         * `["to-boolean", value]`. Evaluated on GLES as well as by Mapbox native layers.
         */
        fun toBoolean(value: Any): Expression =
            Expression(listOf("to-boolean", value))

        // Comparison operands go through makeJSONObject so a nested Expression is flattened to its
        // raw list, the way regex has always treated its input.
        //
        // Without it `Expression.equals(Expression.get("VTEC"), "FA.W")` builds
        // `["==", Expression(raw=[get, VTEC]), "FA.W"]` -- an Expression object sitting inside the
        // raw list where an array belongs. Mapbox's own serialization happens to recover from that
        // via `toJSONObject`, so the style layer filters correctly, but MapsGL's internal evaluators
        // walk `raw` directly, do not unwrap an operand in value position, and quietly compare the
        // wrapper object instead of the property. A filter built this way then behaves differently
        // in the drawn layer than in feature queries, which is indistinguishable from the filter
        // being ignored.

        /**
         * `["==", lhs, rhs]`.
         *
         * Either operand may be a nested [Expression]; it is flattened to its raw list, so the
         * comparison behaves the same in the drawn layer and in feature queries. The other
         * comparison factories below do the same.
         */
        fun equals(lhs: Any, rhs: Any): Expression =
            Expression(listOf("==", makeJSONObject(lhs), makeJSONObject(rhs)))

        /** `["!=", lhs, rhs]`. */
        fun notEquals(lhs: Any, rhs: Any): Expression =
            Expression(listOf("!=", makeJSONObject(lhs), makeJSONObject(rhs)))

        /** `[">", lhs, rhs]`. */
        fun greaterThan(lhs: Any, rhs: Any): Expression =
            Expression(listOf(">", makeJSONObject(lhs), makeJSONObject(rhs)))

        /** `["<", lhs, rhs]`. */
        fun lessThan(lhs: Any, rhs: Any): Expression =
            Expression(listOf("<", makeJSONObject(lhs), makeJSONObject(rhs)))

        /** `[">=", lhs, rhs]`. */
        fun greaterThanOrEqual(lhs: Any, rhs: Any): Expression =
            Expression(listOf(">=", makeJSONObject(lhs), makeJSONObject(rhs)))

        /** `["<=", lhs, rhs]`. */
        fun lessThanOrEqual(lhs: Any, rhs: Any): Expression =
            Expression(listOf("<=", makeJSONObject(lhs), makeJSONObject(rhs)))

        /** `["all", …expressions]` — logical AND. */
        fun and(expressions: List<Any>): Expression =
            Expression(listOf("all") + expressions)

        /** `["any", …expressions]` — logical OR. */
        fun or(expressions: List<Any>): Expression =
            Expression(listOf("any") + expressions)

        /** `["!", expression]` — logical NOT. */
        fun not(expression: Any): Expression =
            Expression(listOf("!", expression))

        /**
         * `["step", input, output0, stop1, output1, …]`. The first [Step] is the base output
         * (its [Step.value] is ignored); later stops pair [Step.value] thresholds with outputs.
         */
        fun <T : Any> step(input: Any, stops: List<Step<T>>): Expression {
            val flattened = mutableListOf<Any?>()
            stops.forEachIndexed { index, stop ->
                if (index == 0) {
                    stop.resolvedResult()?.let { flattened.add(it) }
                } else {
                    flattened.add(stop.value)
                    stop.resolvedResult()?.let { flattened.add(it) }
                }
            }
            return Expression(listOf("step", input) + flattened)
        }

        /**
         * `["interpolate", interpolation, input, …stops]`.
         *
         * [interpolation] is typically `listOf("linear")`, `listOf("exponential", base)`, or
         * `listOf("cubic-bezier", x1, y1, x2, y2)`. GLES evaluates linear, exponential, and
         * cubic-bezier; `interpolate-hcl` / `interpolate-lab` serialize only.
         *
         * Prefer [interpolate], [interpolateExponential], or [interpolateCubicBezier] for the
         * common cases.
         */
        fun interpolate(interpolation: Any, input: Any, stops: List<Any>): Expression =
            Expression(listOf("interpolate", interpolation, input) + stops)

        /**
         * `["match", input, label, output, …, fallback]`. Each [Step.value] is a match label and
         * [Step.result] the output for that label.
         */
        fun match(input: Any, matches: List<Step<Any>>, fallback: Any?): Expression {
            val flattened = matches.flatMap { listOf(it.value, it.resolvedResult()) }
            return Expression(listOf("match", input) + flattened + listOf(fallback))
        }

        /**
         * `["case", cond1, out1, …, fallback]` (Mapbox `case`; named [switchCase] to avoid the
         * Kotlin keyword).
         */
        fun switchCase(conditionsAndResults: List<Case>, fallback: Any): Expression {
            val flattened = mutableListOf<Any?>()
            for (case in conditionsAndResults) {
                flattened.add(case.condition)
                flattened.add(case.result)
            }
            flattened.add(fallback)
            return Expression(listOf("case") + flattened)
        }

        /** `["coalesce", …expressions]` — first non-null result. */
        fun coalesce(expressions: List<Any>): Expression =
            Expression(listOf("coalesce") + expressions)

        /** `["length", input]` — string or array length. */
        fun length(input: Any): Expression =
            Expression(listOf("length", input))

        /** `["concat", …parts]` — string concatenation (also used to prefix `#` on hex colors). */
        fun concat(parts: List<Any>): Expression =
            Expression(listOf("concat") + parts)

        /** `["upcase", input]`. */
        fun upcase(input: Any): Expression =
            Expression(listOf("upcase", input))

        /** `["downcase", input]`. */
        fun downcase(input: Any): Expression =
            Expression(listOf("downcase", input))

        /** `["join", separator, …parts]`. */
        fun join(separator: String, parts: List<Any>): Expression =
            Expression(listOf("join", separator) + parts)

        /** `["slice", input, start]` or `["slice", input, start, end]`. */
        fun slice(input: Any, start: Int, end: Int? = null): Expression {
            val expr = mutableListOf<Any>("slice", input, start)
            if (end != null) expr.add(end)
            return Expression(expr)
        }

        /** `["at", index, array]` — element at [index]. */
        fun at(index: Int, array: Any): Expression =
            Expression(listOf("at", index, array))

        /**
         * Membership test serialized as `["match", value, item1, true, item2, true, …, false]`
         * (more widely supported as a Mapbox layer filter than `["in", …]`). GLES evaluates `match`.
         */
        fun contains(value: Any, array: List<String>): Expression {
            // ["match", input, label1, true, label2, true, ..., false] is more universally
            // supported by the Mapbox GL native engine than ["in", input, ["literal", [...]]].
            // Both are semantically equivalent as a boolean layer filter.
            val matchArgs = array.flatMap { listOf<Any>(it, true) }
            return Expression(listOf("match", value) + matchArgs + listOf(false))
        }

        /**
         * `["has", property]` on the feature, or `["has", property, obj]` when [obj] is set.
         * Dotted [property] is expanded via [hasPath].
         */
        fun has(property: String, obj: Any? = null): Expression {
            return if (property.contains('.')) {
                hasPath(property)
            } else {
                if (obj != null) Expression(listOf("has", property, obj))
                else Expression(listOf("has", property))
            }
        }

        /**
         * Nested `has`: `"a.b"` → `["has", "b", ["get", "a"]]`.
         */
        fun hasPath(property: String): Expression {
            val keys = property.split('.')
            val last = keys.lastOrNull() ?: return Expression(listOf("has", property))
            if (keys.size == 1) return Expression(listOf("has", last))
            val parentPath = keys.dropLast(1).joinToString(".")
            val parentObject = getPath(parentPath)
            return has(last, parentObject)
        }

        /**
         * `["index-of", search, array]`. Evaluated on GLES as well as by Mapbox native layers.
         */
        fun indexOf(search: Any, array: Any): Expression =
            Expression(listOf("index-of", search, array))

        /**
         * Linear `["interpolate", ["linear"], input, …stops]`. [ColorStop] entries expand to
         * value + `rgba(...)` string. GLES evaluates linear interpolation for color and number paint.
         */
        fun interpolate(input: Any, stops: List<Any>): Expression {
            val flattened = stops.flatMap {
                if (it is ColorStop) listOf(it.value, it.color.toRGBAString())
                else listOf(it)
            }
            return Expression(listOf("interpolate", listOf("linear"), input) + flattened)
        }

        /**
         * `["interpolate", ["exponential", base], input, …stops]`. GLES evaluates exponential
         * interpolation for color and number paint.
         */
        fun interpolateExponential(input: Any, base: Double, stops: List<Any>): Expression =
            Expression(listOf("interpolate", listOf("exponential", base), input) + stops)

        /**
         * `["interpolate", ["cubic-bezier", x1, y1, x2, y2], input, …stops]`.
         * [controlPoints] must be four numbers. GLES evaluates cubic-bezier interpolation.
         */
        fun interpolateCubicBezier(input: Any, controlPoints: List<Double>, stops: List<Any>): Expression =
            Expression(listOf("interpolate", listOf("cubic-bezier") + controlPoints, input) + stops)

        /**
         * Mapbox `["format", text, options, …]` for mixed-style labels.
         * Serializes for Mapbox native symbol layers; GLES Feature-path evaluation does not run
         * this operator.
         */
        fun format(parts: List<Pair<StyleValue<String>, TextFormatOptions>>): Expression {
            val formatted = mutableListOf<Any>("format")
            parts.forEach { (value, options) ->
                value.resolvedValue?.let { formatted.add(it) }
                formatted.add(options.toJSONObject())
            }
            return Expression(formatted)
        }

        /**
         * `["let", name1, value1, …, output]` — bind [Variable]s then evaluate [output].
         * Pair with [variable] inside [output]. GLES evaluates `let` / `var` on the Feature path.
         */
        fun bind(bindings: List<Variable>, output: Any): Expression {
            val expression = mutableListOf<Any>("let")
            bindings.forEach { variable ->
                expression.add(variable.key)
                makeJSONObject(variable.value)?.let { expression.add(it) }
            }
            makeJSONObject(output)?.let { expression.add(it) }
            return Expression(expression)
        }

        /** `["var", name]` — reference a name bound by [bind]. */
        fun variable(name: String): Expression =
            Expression(listOf("var", name))
    }

    /**
     * One stop in `step` (or similar) expressions: input threshold [value] and [result] output.
     *
     * @param value Stop key; first stop may use a default output via [resolvedResult] rules in [step].
     * @param result Literal or nested expression; JSON via [makeJSONObject].
     */
    data class Step<T>(val value: T?, val result: Any) {
        fun resolvedResult(): Any? = makeJSONObject(result)
    }

    /**
     * One branch in a `case` expression: boolean [condition] and [result] when true.
     */
    data class Case(
        val condition: Expression,
        val result: Any?
    )

    /**
     * Binding for `let`: [key] name and [value] bound expression or literal.
     */
    data class Variable(
        val key: String,
        val value: Any
    )
}