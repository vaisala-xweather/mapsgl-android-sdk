package com.xweather.mapsgl.style

import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.weather.toColor

/**
 * Parses and applies the key paths accepted by
 * [com.xweather.mapsgl.map.MapController.setPaintProperty], e.g. `"text[0].size"`.
 *
 * Kept free of Android and controller dependencies so the parsing and dispatch rules are directly
 * unit-testable; the caller is responsible for logging [WriteResult] and for invalidating the layer.
 *
 * ## Why an explicit dispatch rather than reflection
 *
 * Paint specs are plain Kotlin properties, so a reflective setter would be stripped or renamed by
 * R8 in release builds — failing exactly where it is hardest to diagnose, and silently. The `when`
 * below is verbose but type-safe, survives minification, and reports an unknown path instead of
 * quietly doing nothing. Adding a property is one branch.
 *
 * ## Supported paths
 *
 * - `text[n].size`
 * - `text[n].opacity`
 * - `text[n].color`
 * - `text[n].outlineColor`
 *
 * Values may be passed either as a ready [StyleValue] (so callers can supply a zoom expression) or
 * as a plain [Number] / [Color] / hex [String], which is wrapped into [StyleValue.Constant].
 */
internal object PaintPropertyWriter {

    /** One segment of a key path: a property name plus an optional array index. */
    internal data class Segment(val name: String, val index: Int?)

    /** Outcome of a write. Only [Applied] mutated anything. */
    internal sealed interface WriteResult {
        /** The property was written. */
        object Applied : WriteResult

        /** The key path was not syntactically valid. */
        data class BadPath(val path: String) : WriteResult

        /** The path parsed but names no property this writer supports on the given paint. */
        data class UnsupportedProperty(val path: String, val paintType: String) : WriteResult

        /** The path is supported but the supplied value could not be coerced to its type. */
        data class BadValue(val path: String, val expected: String) : WriteResult

        /** An array index in the path is outside the collection on this paint. */
        data class IndexOutOfRange(val path: String, val index: Int, val size: Int) : WriteResult
    }

    private val SEGMENT = Regex("""^([A-Za-z_][A-Za-z0-9_]*)(?:\[(\d+)])?$""")

    /**
     * Splits [path] on `.` and pulls out any `[n]` suffixes. Returns `null` when any segment is
     * malformed, so callers can distinguish a typo from an unsupported-but-well-formed path.
     */
    internal fun parse(path: String): List<Segment>? {
        if (path.isBlank()) return null
        val segments = ArrayList<Segment>()
        for (raw in path.split('.')) {
            val match = SEGMENT.matchEntire(raw.trim()) ?: return null
            val index = match.groupValues[2].takeIf { it.isNotEmpty() }?.toIntOrNull()
            segments.add(Segment(match.groupValues[1], index))
        }
        return segments
    }

    /** Applies [value] at [path] on [paint], mutating in place. */
    internal fun write(paint: LayerPaint, path: String, value: Any): WriteResult {
        val segments = parse(path) ?: return WriteResult.BadPath(path)
        return when (paint) {
            is SymbolLayerPaint -> writeSymbol(paint, path, segments, value)
            else -> WriteResult.UnsupportedProperty(path, paint::class.java.simpleName)
        }
    }

    private fun writeSymbol(
        paint: SymbolLayerPaint,
        path: String,
        segments: List<Segment>,
        value: Any,
    ): WriteResult {
        val head = segments.firstOrNull() ?: return WriteResult.BadPath(path)
        if (head.name != "text" || segments.size != 2) {
            return WriteResult.UnsupportedProperty(path, "SymbolLayerPaint")
        }

        // `text` is an array of specs (index 0 is the value label, 1 the place name), so an index is
        // required — `text.size` alone is ambiguous and is rejected rather than guessed at.
        val index = head.index ?: return WriteResult.BadPath(path)
        if (index !in paint.text.indices) {
            return WriteResult.IndexOutOfRange(path, index, paint.text.size)
        }

        // TextPaint fields are all `var`, so the element is mutated in place; the enclosing List is
        // never rebuilt. VectorSymbolLayerRenderer.symbolStyleCacheKey already folds `size`, `color`,
        // `outlineColor` and `opacity` into its hash, so the cached symbol batch is invalidated and
        // the meshes rebuild with the new glyph metrics on the next update.
        val text = paint.text[index]
        return when (segments[1].name) {
            "size" -> asDouble(value)?.let { text.size = it; WriteResult.Applied }
                ?: WriteResult.BadValue(path, "Number or StyleValue<Double>")

            "opacity" -> asDouble(value)?.let { text.opacity = it; WriteResult.Applied }
                ?: WriteResult.BadValue(path, "Number or StyleValue<Double>")

            "color" -> asColor(value)?.let { text.color = it; WriteResult.Applied }
                ?: WriteResult.BadValue(path, "Color, hex String or StyleValue<Color>")

            "outlineColor" -> asColor(value)?.let { text.outlineColor = it; WriteResult.Applied }
                ?: WriteResult.BadValue(path, "Color, hex String or StyleValue<Color>")

            else -> WriteResult.UnsupportedProperty(path, "SymbolLayerPaint")
        }
    }

    /** Accepts an existing [StyleValue] unchanged so expressions pass straight through. */
    @Suppress("UNCHECKED_CAST")
    private fun asDouble(value: Any): StyleValue<Double>? = when (value) {
        is StyleValue.Expression -> value as StyleValue<Double>
        is StyleValue.Constant<*> -> (value.value as? Number)?.let { StyleValue.Constant(it.toDouble()) }
        is Number -> StyleValue.Constant(value.toDouble())
        else -> null
    }

    @Suppress("UNCHECKED_CAST")
    private fun asColor(value: Any): StyleValue<Color>? = when (value) {
        is StyleValue.Expression -> value as StyleValue<Color>
        is StyleValue.Constant<*> -> when (val inner = value.value) {
            is Color -> StyleValue.Constant(inner)
            is String -> runCatching { StyleValue.Constant(toColor(inner)) }.getOrNull()
            else -> null
        }
        is Color -> StyleValue.Constant(value)
        // `toColor` throws on a malformed hex string; a bad value is reported, never propagated.
        is String -> runCatching { StyleValue.Constant(toColor(value)) }.getOrNull()
        else -> null
    }
}
