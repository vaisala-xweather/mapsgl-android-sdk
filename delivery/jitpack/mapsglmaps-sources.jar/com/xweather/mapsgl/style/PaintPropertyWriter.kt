package com.xweather.mapsgl.style

import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.math_type.BoundedRange
import com.xweather.mapsgl.weather.toColor

/**
 * Parses and applies the key paths accepted by
 * [com.xweather.mapsgl.map.MapController.setPaintProperty], e.g. `"text[0].size"`.
 *
 * Kept free of Android and controller dependencies so the parsing and dispatch rules are directly
 * unit-testable; the caller is responsible for logging [WriteResult] and for invalidating the layer.
 *
 * ## Why an explicit dispatch rather than reflection
 *
 * Paint specs are plain Kotlin properties, so a reflective setter would be stripped or renamed by
 * R8 in release builds — failing exactly where it is hardest to diagnose, and silently. The `when`
 * below is verbose but type-safe, survives minification, and reports an unknown path instead of
 * quietly doing nothing. Adding a property is one branch.
 *
 * ## Supported paths
 *
 * Symbol layers:
 *
 * - `text[n].size`
 * - `text[n].opacity`
 * - `text[n].color`
 * - `text[n].outlineColor`
 *
 * Sample and particle layers:
 *
 * - `sample.colorscale`
 *
 * Particle layers:
 *
 * - `sample.drawRange`, `sample.drawRange.min`, `sample.drawRange.max`
 * - `particle.density`, `particle.count`
 * - `particle.size`, `particle.speed`, `particle.trailsFade`, `particle.trails`
 *
 * Property names after the first segment are matched case-insensitively for the sample and particle
 * paths, so both the MapsGL JS spelling (`sample.colorscale`) and the Kotlin one
 * (`sample.colorScale`) resolve.
 *
 * Values may be passed either as a ready [StyleValue] (so callers can supply a zoom expression) or
 * as a plain [Number] / [Color] / hex [String], which is wrapped into [StyleValue.Constant].
 */
internal object PaintPropertyWriter {

    /** One segment of a key path: a property name plus an optional array index. */
    internal data class Segment(val name: String, val index: Int?)

    /** Outcome of a write. Only [Applied] mutated anything. */
    internal sealed interface WriteResult {
        /**
         * The property was written.
         *
         * @param needsPaintReset `true` when the value lives in GL state the renderer builds once
         * -- a colour lookup table, or the particle pool -- so marking the layer dirty is not
         * enough on its own and the caller must also raise
         * `TileLayerRenderer.resetPaint`. `false` for values read afresh every frame.
         */
        data class Applied(val needsPaintReset: Boolean = false) : WriteResult

        /** The key path was not syntactically valid. */
        data class BadPath(val path: String) : WriteResult

        /** The path parsed but names no property this writer supports on the given paint. */
        data class UnsupportedProperty(val path: String, val paintType: String) : WriteResult

        /** The path is supported but the supplied value could not be coerced to its type. */
        data class BadValue(val path: String, val expected: String) : WriteResult

        /** An array index in the path is outside the collection on this paint. */
        data class IndexOutOfRange(val path: String, val index: Int, val size: Int) : WriteResult
    }

    private val SEGMENT = Regex("""^([A-Za-z_][A-Za-z0-9_]*)(?:\[(\d+)])?$""")

    /**
     * Splits [path] on `.` and pulls out any `[n]` suffixes. Returns `null` when any segment is
     * malformed, so callers can distinguish a typo from an unsupported-but-well-formed path.
     */
    internal fun parse(path: String): List<Segment>? {
        if (path.isBlank()) return null
        val segments = ArrayList<Segment>()
        for (raw in path.split('.')) {
            val match = SEGMENT.matchEntire(raw.trim()) ?: return null
            val index = match.groupValues[2].takeIf { it.isNotEmpty() }?.toIntOrNull()
            segments.add(Segment(match.groupValues[1], index))
        }
        return segments
    }

    /** Applies [value] at [path] on [paint], mutating in place. */
    internal fun write(paint: LayerPaint, path: String, value: Any): WriteResult {
        val segments = parse(path) ?: return WriteResult.BadPath(path)
        return when (paint) {
            is SymbolLayerPaint -> writeSymbol(paint, path, segments, value)
            is ParticleLayerPaint -> writeParticle(paint, path, segments, value)
            is SampleLayerPaint -> writeSample(paint.sample, paint, path, segments, value)
            else -> WriteResult.UnsupportedProperty(path, paint::class.java.simpleName)
        }
    }

    private fun writeSymbol(
        paint: SymbolLayerPaint,
        path: String,
        segments: List<Segment>,
        value: Any,
    ): WriteResult {
        val head = segments.firstOrNull() ?: return WriteResult.BadPath(path)
        if (head.name != "text" || segments.size != 2) {
            return WriteResult.UnsupportedProperty(path, "SymbolLayerPaint")
        }

        // `text` is an array of specs (index 0 is the value label, 1 the place name), so an index is
        // required — `text.size` alone is ambiguous and is rejected rather than guessed at.
        val index = head.index ?: return WriteResult.BadPath(path)
        if (index !in paint.text.indices) {
            return WriteResult.IndexOutOfRange(path, index, paint.text.size)
        }

        // TextPaint fields are all `var`, so the element is mutated in place; the enclosing List is
        // never rebuilt. VectorSymbolLayerRenderer.symbolStyleCacheKey already folds `size`, `color`,
        // `outlineColor` and `opacity` into its hash, so the cached symbol batch is invalidated and
        // the meshes rebuild with the new glyph metrics on the next update.
        val text = paint.text[index]
        return when (segments[1].name) {
            "size" -> asDouble(value)?.let { text.size = it; WriteResult.Applied() }
                ?: WriteResult.BadValue(path, "Number or StyleValue<Double>")

            "opacity" -> asDouble(value)?.let { text.opacity = it; WriteResult.Applied() }
                ?: WriteResult.BadValue(path, "Number or StyleValue<Double>")

            "color" -> asColor(value)?.let { text.color = it; WriteResult.Applied() }
                ?: WriteResult.BadValue(path, "Color, hex String or StyleValue<Color>")

            "outlineColor" -> asColor(value)?.let { text.outlineColor = it; WriteResult.Applied() }
                ?: WriteResult.BadValue(path, "Color, hex String or StyleValue<Color>")

            else -> WriteResult.UnsupportedProperty(path, "SymbolLayerPaint")
        }
    }

    /**
     * `sample.colorscale` on a particle layer, plus the `particle.*` generation settings.
     *
     * The split between reset and no-reset is the whole point of [WriteResult.Applied]'s flag.
     * `ParticleRenderPass.render` reads `size`, `speed` and `trailsFade` every frame, so those take
     * effect on the next one. The colour scale lives in GL lookup tables and the density sizes a
     * buffer pool, and both are built when the program is created.
     */
    private fun writeParticle(
        paint: ParticleLayerPaint,
        path: String,
        segments: List<Segment>,
        value: Any,
    ): WriteResult {
        if (segments.any { it.index != null }) return WriteResult.BadPath(path)
        if (segments.size >= 2 && segments[0].name == "sample" &&
            segments[1].name.equals("drawRange", ignoreCase = true)
        ) {
            return writeParticleDrawRange(paint.sample, path, segments, value)
        }
        if (segments.size != 2) return WriteResult.UnsupportedProperty(path, "ParticleLayerPaint")
        val head = segments[0]

        if (head.name == "sample") {
            return writeSample(paint.sample, paint, path, segments, value)
        }
        if (head.name != "particle") {
            return WriteResult.UnsupportedProperty(path, "ParticleLayerPaint")
        }

        val particle = paint.particle
        return when (segments[1].name.lowercase()) {
            "density" -> asDensity(value)?.let {
                particle.density = it
                WriteResult.Applied(needsPaintReset = true)
            } ?: WriteResult.BadValue(path, "ParticleDensity or its name")

            "count" -> asInt(value)?.let {
                particle.count = it
                WriteResult.Applied(needsPaintReset = true)
            } ?: WriteResult.BadValue(path, "Int")

            "size" -> asSize(value)?.let { particle.size = it; WriteResult.Applied() }
                ?: WriteResult.BadValue(path, "Size or Number")

            "speed" -> asPlainDouble(value)?.let { particle.speed = it; WriteResult.Applied() }
                ?: WriteResult.BadValue(path, "Number")

            "trailsfade" -> asPlainDouble(value)?.let {
                particle.trailsFade = it
                WriteResult.Applied()
            } ?: WriteResult.BadValue(path, "Number")

            "trails" -> (value as? Boolean)?.let { particle.trails = it; WriteResult.Applied() }
                ?: WriteResult.BadValue(path, "Boolean")

            else -> WriteResult.UnsupportedProperty(path, "ParticleLayerPaint")
        }
    }

    /**
     * `sample.drawRange` on a particle layer, whole or one end at a time.
     *
     * - `sample.drawRange` takes a `ClosedRange<Double>`, including a [com.xweather.mapsgl.types.math_type.BoundedRange]
     *   with an open end.
     * - `sample.drawRange.min` / `sample.drawRange.max` take a number and keep the other end as it
     *   is, as the MapsGL JS paths of the same name do. With no range set yet, the other end is
     *   left open.
     *
     * Values are in the data's units (m/s for wind). The range is a discard window the particle
     * renderer sets up with the program, so the write asks for a paint reset.
     *
     * Particle layers only: a sample layer's draw range also feeds its colour lookup window, and
     * applying it live there is not covered by this path.
     */
    private fun writeParticleDrawRange(
        sample: SamplePaint,
        path: String,
        segments: List<Segment>,
        value: Any,
    ): WriteResult {
        val current = sample.drawRange
        val lower = (current as? BoundedRange)?.lowerBoundIfAvailable
            ?: current?.start?.takeIf { it.isFinite() }
        val upper = (current as? BoundedRange)?.upperBoundIfAvailable
            ?: current?.endInclusive?.takeIf { it.isFinite() }
        val range: ClosedRange<Double> = when (segments.size) {
            2 -> asDoubleRange(value) ?: return WriteResult.BadValue(path, "ClosedRange<Double>")
            3 -> {
                val bound = asPlainDouble(value) ?: return WriteResult.BadValue(path, "Number")
                when (segments[2].name.lowercase()) {
                    "min" -> if (upper != null) BoundedRange.of(bound, upper) else BoundedRange.atLeast(bound)
                    "max" -> if (lower != null) BoundedRange.of(lower, bound) else BoundedRange.atMost(bound)
                    else -> return WriteResult.UnsupportedProperty(path, "ParticleLayerPaint")
                }
            }
            else -> return WriteResult.UnsupportedProperty(path, "ParticleLayerPaint")
        }
        sample.drawRange = range
        return WriteResult.Applied(needsPaintReset = true)
    }

    /**
     * `sample.colorscale`, shared by sample and particle layers.
     *
     * Assigning [SamplePaint.colorScale] also emits the SDK's own `PAINT_CHANGE` event, which is
     * what keeps a bar legend in step - so this one write covers both the value and the
     * notification, and the caller only has to invalidate.
     */
    private fun writeSample(
        sample: SamplePaint,
        paint: LayerPaint,
        path: String,
        segments: List<Segment>,
        value: Any,
    ): WriteResult {
        if (segments.size != 2 || segments[0].name != "sample") {
            return WriteResult.UnsupportedProperty(path, paint::class.java.simpleName)
        }
        return when (segments[1].name.lowercase()) {
            "colorscale" -> (value as? ColorScaleOptions)?.let {
                sample.colorScale = it
                WriteResult.Applied(needsPaintReset = true)
            } ?: WriteResult.BadValue(path, "ColorScaleOptions")

            else -> WriteResult.UnsupportedProperty(path, paint::class.java.simpleName)
        }
    }

    private fun asInt(value: Any): Int? = when (value) {
        is StyleValue.Constant<*> -> (value.value as? Number)?.toInt()
        is Number -> value.toInt()
        else -> null
    }

    private fun asPlainDouble(value: Any): Double? = when (value) {
        is StyleValue.Constant<*> -> (value.value as? Number)?.toDouble()
        is Number -> value.toDouble()
        else -> null
    }

    /** A `ClosedRange` whose ends are Doubles; `min..max` of Doubles and [BoundedRange] both qualify. */
    @Suppress("UNCHECKED_CAST")
    private fun asDoubleRange(value: Any): ClosedRange<Double>? =
        (value as? ClosedRange<*>)?.takeIf { it.start is Double && it.endInclusive is Double }
            as ClosedRange<Double>?

    /** A single number squares, matching [Size]'s own one-argument constructor. */
    private fun asSize(value: Any): Size? = when (value) {
        is Size -> value
        is Number -> Size(value.toInt())
        else -> null
    }

    /** Accepts the enum or its name, so a value read from JSON or a preference works. */
    private fun asDensity(value: Any): ParticleDensity? = when (value) {
        is ParticleDensity -> value
        is String -> ParticleDensity.entries.firstOrNull { it.name.equals(value, ignoreCase = true) }
        else -> null
    }

    /** Accepts an existing [StyleValue] unchanged so expressions pass straight through. */
    @Suppress("UNCHECKED_CAST")
    private fun asDouble(value: Any): StyleValue<Double>? = when (value) {
        is StyleValue.Expression -> value as StyleValue<Double>
        is StyleValue.Constant<*> -> (value.value as? Number)?.let { StyleValue.Constant(it.toDouble()) }
        is Number -> StyleValue.Constant(value.toDouble())
        else -> null
    }

    @Suppress("UNCHECKED_CAST")
    private fun asColor(value: Any): StyleValue<Color>? = when (value) {
        is StyleValue.Expression -> value as StyleValue<Color>
        is StyleValue.Constant<*> -> when (val inner = value.value) {
            is Color -> StyleValue.Constant(inner)
            is String -> runCatching { StyleValue.Constant(toColor(inner)) }.getOrNull()
            else -> null
        }
        is Color -> StyleValue.Constant(value)
        // `toColor` throws on a malformed hex string; a bad value is reported, never propagated.
        is String -> runCatching { StyleValue.Constant(toColor(value)) }.getOrNull()
        else -> null
    }
}
