package com.xweather.mapsgl.style

/**
 * Every operator name [ExpressionEvaluator] understands, mirroring the MapsGL JS
 * `ExpressionOperator` registry.
 *
 * Named constants rather than bare strings so the evaluator, the time-dependence check and
 * [ExpressionEvaluator.isExpressionArray] cannot drift apart: a typo in one of them would show up
 * as an expression that silently stops matching rather than as a compile error.
 */
internal object ExpressionOperators {

    // Data access
    const val LITERAL = "literal"
    const val GET = "get"
    const val HAS = "has"
    const val VAR = "var"
    const val PROPERTIES = "properties"
    const val ZOOM = "zoom"
    const val COALESCE = "coalesce"

    // Comparison and logic
    const val EQ = "=="
    const val NEQ = "!="
    const val LT = "<"
    const val LTE = "<="
    const val GT = ">"
    const val GTE = ">="
    const val NOT = "!"
    const val ALL = "all"
    const val ANY = "any"

    // Type and coercion
    const val TO_NUMBER = "to-number"
    const val TO_STRING = "to-string"
    const val TO_BOOLEAN = "to-boolean"
    const val TO_DATE = "to-date"
    const val TO_TIME = "to-time"
    const val TO_LOCALE_STRING = "to-locale-string"
    const val TO_UNIT = "to-unit"
    const val TYPEOF = "typeof"
    const val NUMBER = "number"
    const val STRING = "string"
    const val BOOLEAN = "boolean"
    const val OBJECT = "object"

    // Math
    const val ADD = "+"
    const val SUBTRACT = "-"
    const val MULTIPLY = "*"
    const val DIVIDE = "/"
    const val MOD = "%"
    const val POW = "^"
    const val ABS = "abs"
    const val CEIL = "ceil"
    const val FLOOR = "floor"
    const val ROUND = "round"
    const val MIN = "min"
    const val MAX = "max"
    const val SQRT = "sqrt"
    const val LN = "ln"
    const val LN2 = "ln2"
    const val LOG2 = "log2"
    const val LOG10 = "log10"
    const val SIN = "sin"
    const val COS = "cos"
    const val TAN = "tan"
    const val ASIN = "asin"
    const val ACOS = "acos"
    const val ATAN = "atan"
    const val E = "e"
    const val PI = "pi"

    // String and array
    const val AT = "at"
    const val IN = "in"
    const val REGEX = "regex"
    const val INDEX_OF = "index-of"
    const val LENGTH = "length"
    const val SLICE = "slice"
    const val CONCAT = "concat"
    const val DOWNCASE = "downcase"
    const val UPCASE = "upcase"

    // Control flow
    const val STEP = "step"
    const val INTERPOLATE = "interpolate"
    const val CASE = "case"
    const val MATCH = "match"
    const val LET = "let"

    // Time. `map-time` is canonical; `time` is deprecated in JS, and the two camel/legacy spellings
    // are Android's own, kept working because existing app filters use them.
    const val MAP_TIME = "map-time"
    const val TIME = "time"
    const val MAP_TIME_CAMEL = "mapTime"
    const val TIMELINE = "timeline"
    const val NOW = "now"

    /**
     * Operators whose value changes between evaluations, so an expression containing one has to be
     * evaluated at draw time instead of being baked in when the mesh is built.
     */
    val TIME_DEPENDENT: Set<String> = setOf(MAP_TIME, TIME, MAP_TIME_CAMEL, TIMELINE, NOW)

    /** Every operator name, for deciding whether a list is an expression or a plain array. */
    val ALL_OPERATORS: Set<String> = setOf(
        LITERAL, GET, HAS, VAR, PROPERTIES, ZOOM, COALESCE,
        EQ, NEQ, LT, LTE, GT, GTE, NOT, ALL, ANY,
        TO_NUMBER, TO_STRING, TO_BOOLEAN, TO_DATE, TO_TIME, TO_LOCALE_STRING, TO_UNIT,
        TYPEOF, NUMBER, STRING, BOOLEAN, OBJECT,
        ADD, SUBTRACT, MULTIPLY, DIVIDE, MOD, POW,
        ABS, CEIL, FLOOR, ROUND, MIN, MAX, SQRT, LN, LN2, LOG2, LOG10,
        SIN, COS, TAN, ASIN, ACOS, ATAN, E, PI,
        AT, IN, REGEX, INDEX_OF, LENGTH, SLICE, CONCAT, DOWNCASE, UPCASE,
        STEP, INTERPOLATE, CASE, MATCH, LET,
        MAP_TIME, TIME, MAP_TIME_CAMEL, TIMELINE, NOW,
    )
}
