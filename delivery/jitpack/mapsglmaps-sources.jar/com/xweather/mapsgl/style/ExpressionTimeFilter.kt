package com.xweather.mapsgl.style

/**
 * Static/dynamic filter splitting for `map-time` animation (iOS `Expression+TimeFilter` parity).
 *
 * Vector filters are normally evaluated once when building a mesh. A `["map-time"]` /
 * `["time"]` clause must be re-evaluated every frame against the animation playhead. Split the
 * filter into:
 * - **static** — no map-time; applied when preparing geometry so time-dependent features stay
 *   resident in the mesh
 * - **dynamic** — map-time clauses; applied at draw time (CPU for symbols, GPU reveal for
 *   fill/line via baked `featureTime`)
 */
internal data class MapTimeFilterSplit(
    val staticFilter: Expression?,
    val dynamicFilter: Expression?,
)

/**
 * True if any node in the expression tree references `["map-time"]` or the `["time"]` alias
 * (also accepts legacy `"mapTime"` / `"timeline"` spellings used on Android).
 */
internal fun Expression.containsMapTime(): Boolean = rawContainsMapTime(raw)

/**
 * Splits this filter into a static part (no map-time) and a dynamic part (map-time clauses).
 *
 * A top-level `["all", …]` is partitioned clause-by-clause. Any other filter shape goes wholly
 * to one side based on whether it references map-time. Either side may be `null` when empty.
 */
internal fun Expression.splitOnMapTime(): MapTimeFilterSplit {
    val array = raw as? List<*>
    val op = array?.firstOrNull() as? String
    if (array == null || op != "all") {
        return if (containsMapTime()) {
            MapTimeFilterSplit(staticFilter = null, dynamicFilter = this)
        } else {
            MapTimeFilterSplit(staticFilter = this, dynamicFilter = null)
        }
    }

    val clauses = array.drop(1).filterNotNull()
    val dynamicClauses = clauses.filter { rawContainsMapTime(it) }
    val staticClauses = clauses.filter { !rawContainsMapTime(it) }

    val staticExpr: Expression? = when {
        staticClauses.isEmpty() -> null
        else -> Expression(listOf("all") + staticClauses.map { unwrapRaw(it) })
    }

    val dynamicExpr: Expression? = when (dynamicClauses.size) {
        0 -> null
        1 -> {
            val only = dynamicClauses[0]
            (only as? Expression) ?: Expression(unwrapRaw(only))
        }
        else -> Expression(listOf("all") + dynamicClauses.map { unwrapRaw(it) })
    }

    return MapTimeFilterSplit(staticFilter = staticExpr, dynamicFilter = dynamicExpr)
}

/**
 * First `["get", key]` property key in the tree. Used to find the feature property a map-time
 * clause compares against (e.g. `timestamp` in `["<=", ["get","timestamp"], ["map-time"]]`) so a
 * monotonic reveal can be baked into per-vertex time.
 */
internal fun Expression.firstGetKey(): String? = rawFirstGetKey(raw)

/**
 * True when this (dynamic) filter is a single monotonic reveal of the form
 * `prop <= map-time` / `map-time >= prop` (or `<` / `>` variants). Range windows and multi-clause
 * dynamic filters return false so callers fall back to full expression eval instead of GPU/CPU
 * `featureTime <= mapTime` compact.
 */
internal fun Expression.isMonotonicMapTimeReveal(): Boolean = rawIsMonotonicMapTimeReveal(raw)

private fun unwrapRaw(node: Any): Any = when (node) {
    is Expression -> node.raw
    else -> node
}

private fun rawContainsMapTime(raw: Any?): Boolean {
    when (raw) {
        is Expression -> return rawContainsMapTime(raw.raw)
        is List<*> -> {
            if (raw.isNotEmpty()) {
                when (raw[0] as? String) {
                    "map-time", "time", "mapTime", "timeline" -> return true
                }
            }
            return raw.any { rawContainsMapTime(it) }
        }
        else -> return false
    }
}

private fun rawFirstGetKey(raw: Any?): String? {
    when (raw) {
        is Expression -> return rawFirstGetKey(raw.raw)
        is List<*> -> {
            if (raw.size >= 2 && raw[0] == "get" && raw[1] is String) {
                // Flat key, including dotted paths ("details.range.minTimestamp").
                if (raw.size == 2 || raw.size == 3 && raw[2] == null) {
                    return raw[1] as String
                }
                // Nested getPath form: ["get", leaf, parentExpr] — rebuild dotted path when possible.
                val leaf = raw[1] as String
                val parentKey = rawFirstGetKey(raw.getOrNull(2))
                return if (parentKey != null) "$parentKey.$leaf" else leaf
            }
            for (element in raw) {
                rawFirstGetKey(element)?.let { return it }
            }
            return null
        }
        else -> return null
    }
}

private fun rawIsMapTimeOp(raw: Any?): Boolean {
    val list = when (raw) {
        is Expression -> raw.raw as? List<*>
        is List<*> -> raw
        else -> null
    } ?: return false
    if (list.isEmpty()) return false
    return when (list[0] as? String) {
        "map-time", "time", "mapTime", "timeline" -> list.size == 1
        else -> false
    }
}

private fun rawIsGet(raw: Any?): Boolean {
    val list = when (raw) {
        is Expression -> raw.raw as? List<*>
        is List<*> -> raw
        else -> null
    } ?: return false
    return list.isNotEmpty() && list[0] == "get"
}

private fun rawIsMonotonicMapTimeReveal(raw: Any?): Boolean {
    val list = when (raw) {
        is Expression -> raw.raw as? List<*>
        is List<*> -> raw
        else -> null
    } ?: return false
    if (list.isEmpty()) return false
    val op = list[0] as? String ?: return false
    // Top-level all with a single monotonic clause still counts.
    if (op == "all") {
        val clauses = list.drop(1)
        return clauses.size == 1 && rawIsMonotonicMapTimeReveal(clauses[0])
    }
    if (list.size != 3) return false
    val left = list[1]
    val right = list[2]
    return when (op) {
        "<=", "lt", "<", "lte" -> rawIsGet(left) && rawIsMapTimeOp(right)
        ">=", "gt", ">", "gte" -> rawIsMapTimeOp(left) && rawIsGet(right)
        else -> false
    }
}
