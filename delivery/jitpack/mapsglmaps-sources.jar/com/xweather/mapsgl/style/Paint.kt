package com.xweather.mapsgl.style

import LayerEvents
import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.layers.spec.LayerEventEmitter
import com.xweather.mapsgl.layers.spec.StyleJSON
import com.xweather.mapsgl.style.IconSize.Companion.JS_REFERENCE_WIDTH_PX
import com.xweather.mapsgl.types.Anchor
import com.xweather.mapsgl.types.AnchorOffset
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.ColorSampling
import com.xweather.mapsgl.types.DataQuality
import com.xweather.mapsgl.types.InterpolationMode
import com.xweather.mapsgl.types.SampleExpression
import com.xweather.mapsgl.types.Size
import com.xweather.mapsgl.types.TextJustification
import com.xweather.mapsgl.types.TextTransform

/**
 * Marker for paint models used in a single render pass (fill, stroke, sample, particle, …).
 *
 * Layer-level wrappers such as [FillLayerPaint] implement [LayerPaint] and hold one or more
 * [Paint] blocks. Host apps set these on layer descriptors before [com.xweather.mapsgl.map.MapController.addLayer].
 */
interface Paint

/**
 * How connected line segments meet at a vertex. Maps to Mapbox `line-join` and is serialized from
 * [StrokePaint.lineJoin] / [LineLayerPaint] via [StyleJSON].
 *
 * For GLES stencil line masks, the ribbon mesh builder uses this value to approximate the same join
 * behavior as Mapbox-style lines.
 *
 * @property value String emitted to style JSON (`"miter"`, `"round"`, `"bevel"`).
 *
 * @see StrokePaint.lineJoin
 * @see com.xweather.mapsgl.layers.spec.LineLayerDescriptor
 */
enum class LineJoin(val value: String) {
    /**
     * Sharp corner; outer edges extend until they meet. [StrokePaint.miterLimit] caps excessive spikes.
     */
    MITER("miter"),

    /**
     * Rounded fillet at the join (arc between segment directions).
     */
    ROUND("round"),

    /**
     * Chamfered corner: a straight cut across the outside corner.
     */
    BEVEL("bevel"),
}

/**
 * How the start and end of an open line string are terminated. Maps to Mapbox `line-cap` and is
 * serialized from [StrokePaint.lineCap] / [LineLayerPaint] via [StyleJSON].
 *
 * For GLES stencil line masks, the ribbon mesh builder uses this value for end caps.
 *
 * @property value String emitted to style JSON (`"butt"`, `"round"`, `"square"`).
 *
 * @see StrokePaint.lineCap
 * @see com.xweather.mapsgl.layers.spec.LineLayerDescriptor
 */
enum class LineCap(val value: String) {
    /**
     * Flat end flush with the segment endpoint (no extension beyond the vertex).
     */
    BUTT("butt"),

    /**
     * Semicircular cap centered on the endpoint.
     */
    ROUND("round"),

    /**
     * Flat end extended by half the line width beyond the endpoint (same as butt direction, longer stroke).
     */
    SQUARE("square"),
}

/**
 * Paint for raster/image tiles (PNG/JPEG). Opacity and other layer-level options live on
 * [RasterLayerPaint]; this block is the raster-specific slot.
 */
class RasterPaint : Paint


/**
 * Grid spacing in logical px from style/JS.
 *
 * Instanced GL gridded layers ([EncodedGridVectorTileSource]) combine device density with an internal spacing scale
 * when building placement so on-screen density matches [IconSize]-scaled icons; Mapbox symbol layout from
 * [GridLayerPaint.asStyleJSON] is unchanged.
 */
class GridPaint(var spacing: Double = 20.0) : Paint {}


/**
 * Paint for sampled encoded-grid values: interpolation, color mapping, draw range, and timeline
 * blending ([meld]). Used by [SampleLayerPaint], [ContourLayerPaint], and [ParticleLayerPaint].
 */
class SamplePaint(
    override var expression: SampleExpression = SampleExpression.NUMBER,
    override var channel: List<ColorBand> = listOf(ColorBand.red),
    override var quality: DataQuality = DataQuality.exact,
    override var interpolation: InterpolationMode = InterpolationMode.BICUBIC,
    override var smoothing: Float = 0.0f,
    override var offset: Float = 0.0f,
    override var drawRange: ClosedRange<Double>? = null,
    colorScale: ColorScaleOptions = ColorScaleOptions(),
    var multiband: Boolean = false,
    /**
     * Whether values should be linearly interpolated between the current and next timeline
     * intervals during animation (JS `paint.sample.meld`). When `false`, sampling and draw use
     * the current interval only (stepped). Default `true`.
     */
    var meld: Boolean = true,
    /**
     * Shader normalization max for encoded-grid sidecar symbols; when null, [colorScale].range end is used.
     */
    var encodedScalarNormMax: Double? = null,
    var eventEmitter: LayerEventEmitter? = null,
) : Paint, ColorSampling {

    override var colorScale: ColorScaleOptions = colorScale
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE", LayerEvents.SamplePaintChangeEvent(
                    property = "sample.colorscale", value = value
                )
            )
        }
}

/**
 * Isoline (contour) styling on top of [SamplePaint]: interval, major interval, line widths, and
 * value [offset] / [scale]. Used by [ContourLayerPaint].
 */
class ContourPaint(
    colorScale: ColorScaleOptions = ColorScaleOptions(),
    var multiband: Boolean = false,
    var meld: Boolean = true,
    var eventEmitter: LayerEventEmitter? = null,
    var interval: StyleValue<Double> = StyleValue.Constant(2.0),
    var majorInterval: StyleValue<Double> = StyleValue.Constant(10.0),
    var width: StyleValue<Double> = StyleValue.Constant(1.0),
    var majorWidth: StyleValue<Double> = StyleValue.Constant(3.0),
    var scale: StyleValue<Double> = StyleValue.Constant(1.0),
    /**
     * Added to the scaled sample value before isoline spacing (Apple/JS `contour.offset`).
     * Combined as `sampled * scale + offset`.
     */
    var offset: StyleValue<Double> = StyleValue.Constant(0.0),
) : Paint

/**
 * Animated particle field styling (kind, density, size, speed, trails). Used by [ParticleLayerPaint]
 * together with a [SamplePaint] that supplies the vector field.
 */
class ParticlePaint(
    // The visual type of the particle, such as `.circle` or `.arrow`.
    var kind: ParticleKind = ParticleKind.CIRCLE,
    var density: ParticleDensity = ParticleDensity.NORMAL,
    var count: Int = 0,
    /** The size of each individual particle. For wind particles, you only need to set one integer. For
     * wave and swell particles, you can set the width and height individually to create rectangular particles. **/
    var size: Size = Size(2),
    var speed: Double = 1.0,
    var trails: Boolean = true,
    var trailsFade: Double = 0.97,
    var dropRate: Double = 0.01,
    var dropRateBump: Double = 0.01
) : Paint


/**
 * Direction a [FillPaint.sortKey] orders features (Apple `SortDirection` / Mapbox `*-sort-key`).
 */
enum class SortDirection {
    /** Lower sort keys draw first so the highest key appears on top (Mapbox default). */
    ASCENDING,

    /** Higher sort keys draw first so the lowest key appears on top. */
    DESCENDING,
}

/**
 * Polygon fill color, optional pattern, opacity, and sort key. Used by [FillLayerPaint] and as the
 * fill block on [CircleLayerPaint] / [SymbolLayerPaint].
 */
class FillPaint(
    color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    /** Optional fill-pattern image id (`fill-pattern`). */
    var pattern: StyleValue<String>? = null,
    /** Fill alpha in `[0.0, 1.0]` (`fill-opacity`). */
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    /**
     * Feature property key used for draw order (Apple/JS `fill.sortKey`).
     * String form is a dotted property path (e.g. `"period.range.minTimestamp"`);
     * numeric [StyleValue] forms emit Mapbox `fill-sort-key` on the Style JSON path.
     */
    var sortKey: StyleValue<String>? = null,
    /** Ignored when [sortKey] is null. Default matches Mapbox ascending. */
    var sortDirection: SortDirection = SortDirection.ASCENDING,
    var eventEmitter: LayerEventEmitter? = null
) : Paint {

    /** Fill color (`fill-color`); may be a constant or a data-driven [StyleValue.Expression]. */
    var color: StyleValue<Color> = color
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE", LayerEvents.SamplePaintChangeEvent(
                    property = "fill.color", value = value
                )
            )
        }

    /**
     * Custom copy function to replicate data class behavior.
     * Use this to create a new instance with specific property changes.
     */
    fun copy(
        color: StyleValue<Color> = this.color,
        pattern: StyleValue<String>? = this.pattern,
        opacity: StyleValue<Double> = this.opacity,
        sortKey: StyleValue<String>? = this.sortKey,
        sortDirection: SortDirection = this.sortDirection,
        eventEmitter: LayerEventEmitter? = this.eventEmitter
    ): FillPaint {
        return FillPaint(
            color = color,
            pattern = pattern,
            opacity = opacity,
            sortKey = sortKey,
            sortDirection = sortDirection,
            eventEmitter = eventEmitter,
        )
    }
}

/**
 * Stroke style shared by line-capable paint types (for example [LineLayerPaint], [FillLayerPaint.stroke],
 * and [CircleLayerPaint.stroke]).
 *
 * On [FillLayerPaint], outline width is emitted on a companion `line` style layer (`{layerId}::stroke`)
 * because Mapbox fill layers have no width property. [thickness] of `0` maps to a thin ~0.5px line
 * (half of the old `fill-outline-color` edge). Larger values are scaled by [FillLayerPaint.OUTLINE_WIDTH_SCALE].
 *
 * Values are mapped to Mapbox-style line properties where applicable:
 * - [color] -> `line-color` (fill outlines use companion `::stroke` line layer)
 * - [opacity] -> `line-opacity`
 * - [thickness] -> `line-width` (fill outlines scaled by [FillLayerPaint.OUTLINE_WIDTH_SCALE])
 * - [lineJoin] -> `line-join`
 * - [lineCap] -> `line-cap`
 * - [miterLimit] -> `line-miter-limit`
 *
 * For GLES stencil line masks, [lineJoin], [lineCap], and [miterLimit] are also consumed by the ribbon
 * mesh builder to approximate Mapbox/JS line appearance.
 *
 * Example:
 * ```
 * val stroke = StrokePaint().apply {
 *     thickness = StyleValue.Constant(5.0)
 *     lineJoin = StyleValue.Constant(LineJoin.MITER)
 *     lineCap = StyleValue.Constant(LineCap.ROUND)
 *     miterLimit = StyleValue.Constant(2.0)
 * }
 * ```
 */
data class StrokePaint(
    /**
     * Stroke color.
     */
    var color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    /**
     * Stroke alpha in the range `[0.0, 1.0]`.
     */
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    /**
     * Stroke width in screen pixels.
     *
     * On [CircleLayerPaint], thickness is drawn **inset** from [CirclePaint.radius] (JS / Apple
     * parity): the ring occupies `[radius - thickness, radius]` and the fill disc shrinks to match,
     * so changing thickness does not change the circle's overall outer size. Mapbox Style JSON
     * emission subtracts thickness from `circle-radius` so the native path matches.
     */
    var thickness: StyleValue<Double> = StyleValue.Constant(1.0),
    /**
     * Join style used where connected line segments meet.
     */
    var lineJoin: StyleValue<LineJoin> = StyleValue.Constant(LineJoin.ROUND),
    /**
     * Cap style used at the start and end of open line strings.
     */
    var lineCap: StyleValue<LineCap> = StyleValue.Constant(LineCap.ROUND),
    /**
     * Mapbox-style `line-miter-limit` (ratio). Clamps miter extension for [LineJoin.MITER] on stencil ribbons
     * and is emitted to Mapbox layout when the line layer is not stencil-only.
     */
    var miterLimit: StyleValue<Double> = StyleValue.Constant(2.0),
) : Paint

/**
 * Circle disc styling. [radius] is the **outer** radius including an inset [StrokePaint] on
 * [CircleLayerPaint]. Used by [CircleLayerPaint.circle].
 */
class CirclePaint(
    color: StyleValue<Color> = StyleValue.Constant(Color.Red),
    /**
     * Total outer radius in screen points, stroke included (JS / Apple parity).
     *
     * A companion [StrokePaint.thickness] is drawn *inset* from this radius, so the rendered
     * diameter is always `2 * radius` and the filled disc spans `radius - thickness`. This differs
     * from Mapbox `circle-stroke-width`, which extends outside `circle-radius`.
     */
    var radius: StyleValue<Double> = StyleValue.Constant(6.0),
    /** Optional `circle-sort-key` for draw order. */
    var sortKey: StyleValue<Double>? = null,
    var eventEmitter: LayerEventEmitter? = null
) : Paint {

    /** Circle fill color (`circle-color`). */
    var color: StyleValue<Color> = color
        set(value) {
            field = value
            eventEmitter?.trigger(
                "PAINT_CHANGE", LayerEvents.SamplePaintChangeEvent(
                    property = "circle.color", value = value
                )
            )
        }

    /**
     * Custom copy function to replicate data class behavior.
     */
    fun copy(
        color: StyleValue<Color> = this.color,
        radius: StyleValue<Double> = this.radius,
        sortKey: StyleValue<Double>? = this.sortKey,
        eventEmitter: LayerEventEmitter? = this.eventEmitter
    ): CirclePaint {
        return CirclePaint(
            color = color, radius = radius, sortKey = sortKey, eventEmitter = eventEmitter
        )

    }
}

/**
 * Width and height in the same units as MapsGL JS `icon.size` — **pixel dimensions** for the laid-out symbol quad
 * (see web `SymbolStore.layoutIcon`: `w`/`h` from [PaintStyle.iconSize]).
 *
 * Instanced gridded renderers convert these to Mercator half-extents using
 * [GridLayerRenderer.mercatorHalfExtentsFromJsIconPixels] with [JS_REFERENCE_WIDTH_PX] (40px reference); width/height
 * are multiplied by device [android.util.DisplayMetrics.density] there so physical on-screen size scales with DPI.
 *
 * [innerWidth] / [innerHeight] are **relative to [JS_REFERENCE_WIDTH_PX]** for Mapbox `icon-size` in [GridLayerPaint.asStyleJSON].
 */
class IconSize(
    width: Float,
    height: Float,
) {
    var width: Float = width
    var height: Float = height

    val innerWidth: Float get() = width / JS_REFERENCE_WIDTH_PX
    val innerHeight: Float get() = height / JS_REFERENCE_WIDTH_PX

    companion object {
        /** Matches web default icon width (e.g. `conditions` wind arrow `size: { width: 40, height: 20 }`). */
        const val JS_REFERENCE_WIDTH_PX: Float = 40f
    }
}

/**
 * Icon atlas (parity with JS `icon.atlas` / Apple `IconAtlasPaint`: ordered ids and a data-value
 * [interval] used to pick an index via `floor(value / interval)`).
 *
 * For wind barbs the default ids are `mapsgl:wind-barb-0` … `mapsgl:wind-barb-100` in 5 kt steps and
 * [interval] is the bucket width in **m/s** (JS: `5 * 0.5144444`). Instanced GL barbs still draw
 * procedurally in [com.xweather.mapsgl.renderers.WindBarbInstancedRenderer]; keep [IconPaint.image]
 * consistent with these ids for any Mapbox symbol / tooling path.
 */
data class IconAtlas(
    val ids: List<String>,
    /**
     * Data-value step between consecutive atlas indices (JS / Apple `icon.atlas.interval`).
     * For wind barbs this is m/s per sprite (e.g. [WIND_BARB_INTERVAL]).
     */
    val interval: Double,
) {

    val image: StyleValue<String> = windBarbSpriteImageExpression(ids, interval)

    @Deprecated("Renamed to interval (Apple/JS icon.atlas.interval)", ReplaceWith("interval"))
    val intervalMs: Double get() = interval

    companion object {
        /** 1 kt → m/s (matches wind barb shader / JS `0.5144444`). */
        const val KNOTS_TO_MS_PER_KNOT: Double = 0.5144444

        /** JS / Apple `icon.atlas.interval`: 5 kt expressed in m/s (`5 * 0.5144444`). */
        const val WIND_BARB_INTERVAL: Double = 5.0 * KNOTS_TO_MS_PER_KNOT

        @Deprecated("Renamed to WIND_BARB_INTERVAL", ReplaceWith("WIND_BARB_INTERVAL"))
        const val WIND_BARB_INTERVAL_MS: Double = WIND_BARB_INTERVAL

        /**
         * Mapbox `icon-image` expression: concat [prefix from ids][0] with the knot suffix derived from feature
         * `speed` (m/s). [interval] is the bucket width in m/s (e.g. [WIND_BARB_INTERVAL]); knot step and clamp
         * come from the numeric suffixes in [ids].
         */
        fun windBarbSpriteImageExpression(ids: List<String>, interval: Double): StyleValue<String> {
            require(ids.isNotEmpty()) { "IconAtlas.ids must not be empty" }
            require(interval > 0.0) { "IconAtlas.interval must be positive" }
            val kts =
                ids.map { id ->
                    id.substringAfterLast('-').toDoubleOrNull()
                        ?: error("IconAtlas.ids entries must end with a numeric knot suffix: $id")
                }
            val ktStep =
                if (kts.size >= 2) {
                    kts[1] - kts[0]
                } else {
                    5.0
                }
            val maxKt = kts.maxOrNull() ?: 0.0
            val maxInner = (maxKt / ktStep).toInt().coerceAtLeast(0).toDouble()
            val prefix = ids[0].substringBeforeLast('-') + "-"
            return StyleValue.Expression(
                Expression.concat(
                    listOf(
                        Expression.literal(prefix),
                        Expression.toString(
                            Expression.multiply(
                                Expression.min(
                                    Expression.max(
                                        Expression.round(
                                            Expression.divide(
                                                Expression.toNumber(Expression.get("speed")),
                                                interval,
                                            ),
                                        ),
                                        0.0,
                                    ),
                                    maxInner,
                                ),
                                ktStep,
                            ),
                        ),
                    ),
                ),
            )
        }
    }
}

/**
 * Shared symbol placement options (Apple `SymbolPlacementPaint`).
 * Used by [IconPaint.placement] and [GridLayerPaint.symbol].
 *
 * @property allowOverlap Whether this symbol may overlap others (`icon-allow-overlap` / `text-allow-overlap`).
 * @property anchor Anchor relative to the feature (`icon-anchor` / `text-anchor`).
 * @property offset Pixel offset from the anchor (`icon-offset` / `text-offset`).
 * @property padding Extra collision padding in pixels.
 * @property rotation Rotation in degrees.
 * @property rotateWithMap When true, rotation tracks map bearing.
 * @property pitchWithMap When true, the symbol tilts with camera pitch.
 */
data class SymbolPlacementPaint(
    var allowOverlap: StyleValue<Boolean> = StyleValue.Constant(false),
    var anchor: StyleValue<Anchor> = StyleValue.Constant(Anchor.CENTER),
    var offset: StyleValue<AnchorOffset> = StyleValue.Constant(AnchorOffset()),
    var padding: StyleValue<Double> = StyleValue.Constant(0.0),
    var rotation: StyleValue<Double> = StyleValue.Constant(0.0),
    var rotateWithMap: Boolean = false,
    var pitchWithMap: Boolean = false,
)

/**
 * How an icon image is resolved (Apple `IconSourcePaint`).
 */
sealed class IconSourcePaint {
    /** No icon source configured. */
    data object None : IconSourcePaint()

    /** Registered sprite / image id. */
    data class Image(val image: StyleValue<String>) : IconSourcePaint()

    /** Built-in grid symbol type (e.g. `"arrow"`, `"wind-barb"`). */
    data class Type(val type: String) : IconSourcePaint()

    /** Atlas of ordered icon ids with a data-value [IconAtlas.interval]. */
    data class Atlas(val atlas: IconAtlas) : IconSourcePaint()
}

/**
 * Icon style options (Apple `IconPaint`). Prefer [placement] / [source] for new code; named
 * constructor parameters (`image`, `atlas`, `allowOverlap`, …) remain supported for existing call sites.
 */
class IconPaint(
    allowOverlap: StyleValue<Boolean> = StyleValue.Constant(true),
    image: StyleValue<String>? = null,
    size: StyleValue<Double>? = null,
    scale: StyleValue<Double>? = null,
    iconSize: IconSize? = null,
    atlas: IconAtlas? = null,
    type: String? = null,
    anchor: StyleValue<Anchor> = StyleValue.Constant(Anchor.CENTER),
    offset: StyleValue<AnchorOffset> = StyleValue.Constant(AnchorOffset()),
    padding: StyleValue<Double> = StyleValue.Constant(0.0),
    rotation: Double = 0.0,
    rotationUsesDataDirection: Boolean = false,
    spin: Boolean = false,
    spinDegreesPerSecond: Float = 180f,
    shader: String? = null,
    factor: StyleValue<Double>? = null,
    placement: SymbolPlacementPaint? = null,
    source: IconSourcePaint? = null,
) : Paint {

    /**
     * Placement shared with other symbol types (Apple `IconPaint.placement`).
     * Default `allowOverlap = true` preserves prior Android icon defaults.
     */
    var placement: SymbolPlacementPaint = placement ?: SymbolPlacementPaint(
        allowOverlap = allowOverlap,
        anchor = anchor,
        offset = offset,
        padding = padding,
        rotation = StyleValue.Constant(rotation),
    )

    /** Source used to resolve the icon image (Apple `IconPaint.source`). */
    var source: IconSourcePaint = source ?: when {
        atlas != null -> IconSourcePaint.Atlas(atlas)
        image != null -> IconSourcePaint.Image(image)
        type != null -> IconSourcePaint.Type(type)
        else -> IconSourcePaint.None
    }

    /**
     * Absolute icon size in screen points as a Mapbox-style scalar multiplier when [iconSize] is
     * unset (legacy). Prefer [iconSize] for pixel dimensions or [scale] for Mapbox `icon-size`.
     */
    var size: StyleValue<Double>? = size

    /**
     * Multiplier applied to the source sprite's native size (Apple/Mapbox `icon-size` / `scale`).
     * Ignored when [iconSize] is set. Takes precedence over [size] for Style JSON when both are set.
     */
    var scale: StyleValue<Double>? = scale

    /**
     * Optional width/height in JS icon pixels. Takes precedence over [size]/[scale] for instanced
     * wind / GLES layout when non-null.
     */
    var iconSize: IconSize? = iconSize

    /**
     * Constant rotation offset in degrees (e.g. `-90` for wind barb/arrow base tilt). When [rotationUsesDataDirection]
     * is true, Mapbox icon rotation is `dir + rotation` from encoded features.
     */
    var rotation: Double = rotation

    /**
     * When true, [rotationExpression] uses `dir + rotation` via `Expression.get("dir")`; when false, rotation is constant.
     */
    var rotationUsesDataDirection: Boolean = rotationUsesDataDirection

    /**
     * When true, the icon rotates continuously (adds `elapsedSeconds * spinDegreesPerSecond` to
     * [rotation] every frame) instead of holding a static rotation.
     */
    var spin: Boolean = spin

    /**
     * Rotation speed in degrees/second when [spin] is true. **Positive spins counter-clockwise on
     * screen**, which is the cyclonic direction in the northern hemisphere; [factor] flips it per
     * feature for southern-hemisphere storms.
     *
     * The default is `+180` even though the equivalent JS tropical shader hook reads
     * `symbolAngle += (time * -PI * 2.0) * 0.5 * factor` — i.e. -180 deg/s. The magnitude matches;
     * the sign does not, because the two renderers apply the rotation on opposite sides of the
     * matrix. JS does `pointPosition.xy *= rotationMatrix` (vector-times-matrix, so the transpose)
     * while [SYMBOL_VERT] does `rot * corner`. Copying the JS number verbatim therefore spun the
     * icons backwards, which is what this default used to do.
     */
    var spinDegreesPerSecond: Float = spinDegreesPerSecond

    /**
     * Custom GLSL fragment shader source (JS `paint.icon.shader`). Layer-level constant.
     */
    var shader: String? = shader

    /** Per-feature data value for custom [shader] as `v_factor` (JS `paint.icon.factor`). */
    var factor: StyleValue<Double>? = factor

    /** Whether icons can overlap other icons. */
    var allowOverlap: StyleValue<Boolean>
        get() = this.placement.allowOverlap
        set(value) {
            this.placement.allowOverlap = value
        }

    /** Positioning anchor of the icon. */
    var anchor: StyleValue<Anchor>
        get() = this.placement.anchor
        set(value) {
            this.placement.anchor = value
        }

    /** Offset of the icon from its anchor position. */
    var offset: StyleValue<AnchorOffset>
        get() = this.placement.offset
        set(value) {
            this.placement.offset = value
        }

    /** Padding around the icon. */
    var padding: StyleValue<Double>
        get() = this.placement.padding
        set(value) {
            this.placement.padding = value
        }

    /** Whether the icon rotates with map bearing (Apple `placement.rotateWithMap`). */
    var rotateWithMap: Boolean
        get() = this.placement.rotateWithMap
        set(value) {
            this.placement.rotateWithMap = value
        }

    /** Whether the icon pitches with the map (Apple `placement.pitchWithMap`). */
    var pitchWithMap: Boolean
        get() = this.placement.pitchWithMap
        set(value) {
            this.placement.pitchWithMap = value
        }

    /** The name of the image to display. */
    var image: StyleValue<String>?
        get() = (this.source as? IconSourcePaint.Image)?.image
        set(value) {
            this.source = value?.let { IconSourcePaint.Image(it) } ?: IconSourcePaint.None
        }

    /** Optional grid-only built-in symbol type (Apple `icon.type`). */
    var type: String?
        get() = (this.source as? IconSourcePaint.Type)?.type
        set(value) {
            this.source = value?.let { IconSourcePaint.Type(it) } ?: IconSourcePaint.None
        }

    /** Declarative atlas (JS / Apple `icon.atlas`). */
    var atlas: IconAtlas?
        get() = (this.source as? IconSourcePaint.Atlas)?.atlas
        set(value) {
            this.source = value?.let { IconSourcePaint.Atlas(it) } ?: IconSourcePaint.None
        }

    /** Mapbox `icon-size` value for Style JSON: [scale], else derived from [iconSize], else [size]. */
    fun resolvedIconSizeStyle(): StyleValue<Double>? =
        scale
            ?: iconSize?.let { sz ->
                StyleValue.Constant(
                    (kotlin.math.max(sz.width.toDouble(), sz.height.toDouble()) / IconSize.JS_REFERENCE_WIDTH_PX)
                        .coerceIn(0.05, 8.0),
                )
            }
            ?: size

    /**
     * Mapbox `icon-rotate` value, derived from [rotation] whenever read.
     */
    internal val rotationExpression: StyleValue<Double>
        get() =
            if (rotationUsesDataDirection) {
                StyleValue.Expression(
                    Expression.add(
                        Expression.toNumber(Expression.get("dir")),
                        rotation,
                    ),
                )
            } else {
                StyleValue.Constant(rotation)
            }

    /** Shallow copy for tests / paint mutation helpers (IconPaint is no longer a data class). */
    fun copy(
        allowOverlap: StyleValue<Boolean> = this.allowOverlap,
        image: StyleValue<String>? = this.image,
        size: StyleValue<Double>? = this.size,
        scale: StyleValue<Double>? = this.scale,
        iconSize: IconSize? = this.iconSize,
        atlas: IconAtlas? = this.atlas,
        type: String? = this.type,
        anchor: StyleValue<Anchor> = this.anchor,
        offset: StyleValue<AnchorOffset> = this.offset,
        padding: StyleValue<Double> = this.padding,
        rotation: Double = this.rotation,
        rotationUsesDataDirection: Boolean = this.rotationUsesDataDirection,
        spin: Boolean = this.spin,
        spinDegreesPerSecond: Float = this.spinDegreesPerSecond,
        shader: String? = this.shader,
        factor: StyleValue<Double>? = this.factor,
        rotateWithMap: Boolean = this.placement.rotateWithMap,
        pitchWithMap: Boolean = this.placement.pitchWithMap,
        source: IconSourcePaint = this.source,
    ): IconPaint =
        IconPaint(
            allowOverlap = allowOverlap,
            image = image,
            size = size,
            scale = scale,
            iconSize = iconSize,
            atlas = atlas,
            type = type,
            anchor = anchor,
            offset = offset,
            padding = padding,
            rotation = rotation,
            rotationUsesDataDirection = rotationUsesDataDirection,
            spin = spin,
            spinDegreesPerSecond = spinDegreesPerSecond,
            shader = shader,
            factor = factor,
            placement = SymbolPlacementPaint(
                allowOverlap = allowOverlap,
                anchor = anchor,
                offset = offset,
                padding = padding,
                rotation = this.placement.rotation,
                rotateWithMap = rotateWithMap,
                pitchWithMap = pitchWithMap,
            ),
            source = source,
        )
}

/**
 * Text styling for symbol layers (Mapbox `text-*` properties). Multiple [TextPaint] entries on
 * [SymbolLayerPaint.text] become stacked labels.
 *
 * @property allowOverlap `text-allow-overlap`.
 * @property value Label string or expression (`text-field`).
 * @property size Font size in pixels (`text-size`).
 * @property font Font stack (`text-font`).
 * @property weight Font weight hint (serialized where supported).
 * @property color `text-color`.
 * @property outlineColor Halo color (`text-halo-color`).
 * @property opacity `text-opacity`.
 * @property align `text-justify`.
 * @property transform `text-transform`.
 * @property anchor `text-anchor`.
 * @property offset `text-offset`.
 * @property padding Collision padding.
 * @property rotation `text-rotate`.
 * @property letterSpacing `text-letter-spacing`.
 * @property lineHeight `text-line-height`.
 * @property maxWidth `text-max-width`.
 */
data class TextPaint(
    var allowOverlap: StyleValue<Boolean> = StyleValue.Constant(false),
    var value: StyleValue<String>,
    var size: StyleValue<Double>? = null,
    var font: StyleValue<List<String>>? = null,
    var weight: StyleValue<String>? = null,
    var color: StyleValue<Color> = StyleValue.Constant(Color.Black),
    var outlineColor: StyleValue<Color>? = null,
    var opacity: StyleValue<Double> = StyleValue.Constant(1.0),
    var align: StyleValue<TextJustification> = StyleValue.Constant(TextJustification.CENTER),
    var transform: StyleValue<TextTransform> = StyleValue.Constant(TextTransform.NONE),
    var anchor: StyleValue<Anchor> = StyleValue.Constant(Anchor.CENTER),
    var offset: StyleValue<AnchorOffset> = StyleValue.Constant(AnchorOffset(0.0, 0.0)),
    var padding: StyleValue<Double> = StyleValue.Constant(0.0),
    var rotation: StyleValue<Double> = StyleValue.Constant(0.0),
    var letterSpacing: StyleValue<Double>? = null,
    var lineHeight: StyleValue<Double>? = null,
    var maxWidth: StyleValue<Double>? = null
) : Paint

/**
 * Heatmap kernel styling (Mapbox `heatmap-*`). Used by [HeatmapLayerPaint].
 *
 * @property color Color ramp vs heatmap density (`heatmap-color`).
 * @property intensity `heatmap-intensity`.
 * @property radius `heatmap-radius`.
 * @property weight Per-point weight (`heatmap-weight`).
 * @property blur Edge fade vs radius (Apple/JS `heatmap.blur`); GLES uses this as blur spread.
 */
data class HeatmapPaint(
    var color: StyleValue<Color> = StyleValue.Expression(
        Expression.interpolate(
            listOf("heatmap-density"), listOf(
                0.0 to "rgba(0, 0, 0, 0)",
                0.2 to "rgba(0, 0, 255, 0.2)",
                0.45 to "rgba(0, 255, 0, 0.5)",
                0.85 to "rgba(255, 255, 0, 1)",
                1.0 to "rgba(255, 0, 0, 1)"
            )
        )
    ),
    /** Apple/JS default `1`. */
    var intensity: StyleValue<Double> = StyleValue.Constant(1.0),
    /** Apple/JS default `10`. */
    var radius: StyleValue<Double> = StyleValue.Constant(10.0),
    /** Apple/JS default `1`. */
    var weight: StyleValue<Double> = StyleValue.Constant(1.0),
    /**
     * How much to fade out the edges of each point based on its radius (Apple/JS `heatmap.blur`).
     * Default `1.0` matches Apple 1.7.0. GLES uses this as the separable blur spread multiplier.
     */
    var blur: StyleValue<Double> = StyleValue.Constant(1.0),
) : Paint

/** Layer-level paint: [opacity] plus type-specific nested paint blocks. */
interface LayerPaint {
    var opacity: Float
}

/**
 * Vector (fill/line/circle/symbol/heatmap) paint that can emit Mapbox [StyleJSON] via [asStyleJSON].
 */
interface VectorLayerPaint : LayerPaint {
    fun asStyleJSON(id: String, source: String, sourceLayer: String? = null): StyleJSON
}

/**
 * Paint for [com.xweather.mapsgl.layers.spec.RasterLayerDescriptor].
 *
 * @property opacity Layer opacity.
 * @property raster Raster-specific options.
 */
data class RasterLayerPaint(
    override var opacity: Float = 1.0f, var raster: RasterPaint
) : LayerPaint

/**
 * Paint for [com.xweather.mapsgl.layers.spec.SampleLayerDescriptor] (encoded color field).
 */
data class SampleLayerPaint(
    override var opacity: Float = 1.0f, var sample: SamplePaint
) : LayerPaint

/**
 * Paint for [com.xweather.mapsgl.layers.spec.ContourLayerDescriptor]: sampled field plus isoline style.
 */
data class ContourLayerPaint(
    override var opacity: Float = 1.0f, var sample: SamplePaint, var contour: ContourPaint
) : LayerPaint {

    var interval: StyleValue<Double> = StyleValue.Constant(1.0)


}

/**
 * Paint for [com.xweather.mapsgl.layers.spec.ParticleLayerDescriptor]: sampled vector field plus particles.
 */
data class ParticleLayerPaint(
    override var opacity: Float = 1.0f, var sample: SamplePaint, var particle: ParticlePaint
) : LayerPaint

/**
 * Paint for [com.xweather.mapsgl.layers.spec.FillLayerDescriptor]: polygon fill plus optional outline stroke.
 */
data class FillLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint,
    /**
     * Optional outline (Apple `FillLayerPaint.stroke`). Default is a zero-thickness stroke that still
     * emits a thin companion outline for prior Android parity; set to `null` to skip the outline
     * entirely.
     */
    var stroke: StrokePaint? = StrokePaint(thickness = StyleValue.Constant(0.0)),
) : VectorLayerPaint {

    companion object {
        const val STROKE_OUTLINE_LAYER_SUFFIX = "::stroke"

        /** Visual scale applied to [StrokePaint.thickness] on fill polygon outlines. */
        const val OUTLINE_WIDTH_SCALE = 0.5

        /** Companion line width when [StrokePaint.thickness] is `0` (~half of Mapbox `fill-outline-color`). */
        private const val ZERO_THICKNESS_OUTLINE_LINE_WIDTH = 0.5

        fun strokeOutlineLayerId(fillLayerId: String): String = fillLayerId + STROKE_OUTLINE_LAYER_SUFFIX

        fun scaleOutlineThickness(thickness: StyleValue<Double>): StyleValue<Double> =
            when (thickness) {
                is StyleValue.Constant -> {
                    val scaled =
                        if (thickness.value <= 0.0) {
                            ZERO_THICKNESS_OUTLINE_LINE_WIDTH
                        } else {
                            thickness.value * OUTLINE_WIDTH_SCALE
                        }
                    StyleValue.Constant(scaled)
                }

                is StyleValue.Expression -> StyleValue.fromExpressionArray(
                    listOf("*", thickness.expression.toJSONObject() as Any, OUTLINE_WIDTH_SCALE),
                )
            }
    }

    /** Whether a companion Mapbox `line` outline layer should be registered. */
    fun usesStrokeLineLayer(): Boolean = stroke != null

    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.FILL, source, sourceLayer).apply {
            fillColor = fill.color
            fillOpacity = fill.opacity
            fillPattern = fill.pattern
            // Mapbox fill-sort-key is numeric; property-path sort is GLES-only via VectorFillSortDefaults.
            fill.sortKey?.constantValue?.toDoubleOrNull()?.let {
                fillSortKey = StyleValue.Constant(it)
            }
        }
    }

    /**
     * Mapbox `line` style for polygon boundaries (companion to the `fill` layer).
     * Returns null when [stroke] is unset.
     */
    fun strokeOutlineStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON? {
        val strokePaint = stroke ?: return null
        return StyleJSON(id, StyleJSON.LayerType.LINE, source, sourceLayer).apply {
            lineColor = strokePaint.color
            lineOpacity = strokePaint.opacity
            lineWidth = scaleOutlineThickness(strokePaint.thickness)
            lineJoin = strokePaint.lineJoin
            lineCap = strokePaint.lineCap
            lineMiterLimit = strokePaint.miterLimit
        }
    }
}

/**
 * Paint model for vector line layers.
 *
 * [LineLayerPaint] wraps [StrokePaint] and serializes to Mapbox-style `line-*` properties in
 * [asStyleJSON], including width, color, join/cap, and miter limit. This paint is used by
 * [com.xweather.mapsgl.layers.spec.LineLayerDescriptor] and is also read by GLES stencil mask
 * ribbon generation when a line layer is used as a mask source.
 *
 * @property opacity Layer-level opacity multiplier applied by the renderer.
 * @property stroke Stroke configuration (color, width, joins/caps, miter).
 */
data class LineLayerPaint(
    override var opacity: Float = 1.0f,
    var stroke: StrokePaint
) : VectorLayerPaint {
    /**
     * Converts this paint to a style JSON payload for a Mapbox `line` style layer.
     *
     * Maps [stroke] fields to:
     * - `line-color`
     * - `line-opacity`
     * - `line-width`
     * - `line-join`
     * - `line-cap`
     * - `line-miter-limit`
     */
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.LINE, source, sourceLayer).apply {
            lineColor = stroke.color
            lineOpacity = stroke.opacity
            lineWidth = stroke.thickness
            lineJoin = stroke.lineJoin
            lineCap = stroke.lineCap
            lineMiterLimit = stroke.miterLimit
        }
    }
}

/**
 * Paint for [com.xweather.mapsgl.layers.spec.CircleLayerDescriptor]: disc fill, inset stroke, and radius.
 */
data class CircleLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint = FillPaint(),
    var stroke: StrokePaint = StrokePaint(),
    var circle: CirclePaint
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.CIRCLE, source, sourceLayer).apply {
            circleColor = fill.color
            circleOpacity = fill.opacity
            // [CirclePaint.radius] is the total outer radius with the stroke inset, whereas Mapbox
            // places `circle-stroke-width` outside `circle-radius`. Emitting `radius - thickness`
            // makes the native layer's outer edge land at `radius` (JS / Apple parity).
            circleRadius = insetRadius(circle.radius, stroke.thickness)
            circleStrokeColor = stroke.color
            circleStrokeOpacity = stroke.opacity
            circleStrokeWidth = stroke.thickness
            circleSortKey = circle.sortKey
        }
    }

    companion object {
        /**
         * `max(0, radius - thickness)`, preserving expressions. Two constants fold immediately;
         * anything else becomes `["max", 0, ["-", radius, thickness]]` for Mapbox Style JSON.
         */
        fun insetRadius(
            radius: StyleValue<Double>,
            thickness: StyleValue<Double>,
        ): StyleValue<Double> {
            val rConst = radius.constantValue
            val tConst = thickness.constantValue
            if (rConst != null && tConst != null) {
                return StyleValue.Constant(kotlin.math.max(0.0, rConst - tConst))
            }
            val radiusOperand: Any = radius.expressionValue?.toJSONObject()
                ?: radius.constantValue
                ?: 0.0
            val thicknessOperand: Any = thickness.expressionValue?.toJSONObject()
                ?: thickness.constantValue
                ?: 0.0
            return StyleValue.fromExpressionArray(
                listOf("max", 0.0, listOf("-", radiusOperand, thicknessOperand)),
            )
        }
    }
}

/** MapsGL JS `symbol.rank`: feature property used to order symbols before placement / draw. */
data class SymbolRank(
    val property: String,
    val direction: SymbolRankDirection = SymbolRankDirection.ASC,
)

/** Sort direction for [SymbolRank.property] (JS `symbol.rank.direction`). */
enum class SymbolRankDirection {
    /** Lower property values place / draw first. */
    ASC,

    /** Higher property values place / draw first. */
    DESC,
}

/**
 * Paint for [com.xweather.mapsgl.layers.spec.SymbolLayerDescriptor]: icon, optional text list, fill/stroke, rank.
 */
data class SymbolLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint? = null,
    var stroke: StrokePaint? = null,
    var icon: IconPaint = IconPaint(),
    var text: List<TextPaint> = emptyList(),
    /** Optional rank for GLES symbol ordering (JS `symbol.rank`). */
    var rank: SymbolRank? = null,
    /**
     * When true (default, JS parity), icon and text instances tilt into the map plane with camera
     * pitch, geometrically re-projected like any other map content. When false, they stay flat and
     * screen-upright regardless of pitch. Shared between icon and text (JS `paint.symbol.pitchWithMap`).
     */
    var pitchWithMap: Boolean = true,
    /**
     * When true (default, JS parity), icon and text instances rotate to track the map's current
     * bearing. When false, they stay oriented to screen-north regardless of bearing. Shared between
     * icon and text (JS `paint.symbol.rotateWithMap`). Independent of [pitchWithMap] — all four
     * combinations are meaningful (e.g. tilts with pitch but stays north-up in rotation).
     */
    var rotateWithMap: Boolean = true,
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.SYMBOL, source, sourceLayer).apply {
            iconAllowOverlap = icon.allowOverlap
            iconAnchor = icon.anchor
            iconColor = fill?.color
            iconHaloColor = stroke?.color
            iconHaloWidth = stroke?.thickness
            iconImage = icon.image
            iconOffset = icon.offset
            iconOpacity = fill?.opacity
            iconPadding = icon.padding
            iconRotate = icon.rotationExpression
            iconSize = icon.resolvedIconSizeStyle()

            text.firstOrNull()?.let { baseText ->
                textField = if (text.size > 1) {
                    val baseSize = baseText.size?.resolvedValue as? Double ?: 12.0
                    val inputs = text.flatMap {
                        val size = (it.size?.resolvedValue as? Double) ?: 12.0
                        val scale = size / baseSize
                        listOf(
                            it.value to TextFormatOptions(fontScale = scale),
                            StyleValue.Constant("\n") to TextFormatOptions(fontScale = scale)
                        )
                    }
                    StyleValue.Expression(Expression.format(inputs))
                } else {
                    baseText.value
                }
                textAllowOverlap = baseText.allowOverlap
                textAnchor = baseText.anchor
                textColor = baseText.color
                textHaloColor = baseText.outlineColor
                textHaloBlur = StyleValue.Constant(0.5)
                textHaloWidth = stroke?.thickness ?: StyleValue.Constant(1.0)
                textJustify = baseText.align
                textLetterSpacing = baseText.letterSpacing
                textLineHeight = baseText.lineHeight
                textMaxWidth = baseText.maxWidth
                textOffset = baseText.offset
                textOpacity = baseText.opacity
                textPadding = baseText.padding
                textRotate = baseText.rotation
                textSize = baseText.size
                textTransform = baseText.transform
            }
        }
    }
}


/**
 * Paint for [com.xweather.mapsgl.layers.spec.GridLayerDescriptor]: sampled encoded values plus
 * instanced icons (arrows/barbs) at a grid spacing.
 */
data class GridLayerPaint(
    override var opacity: Float = 1.0f,
    var fill: FillPaint? = FillPaint(
        color = StyleValue.Expression(
            Expression.rgb(
                Expression.toNumber(Expression.get("shaderR")),
                Expression.toNumber(Expression.get("shaderG")),
                Expression.toNumber(Expression.get("shaderB")),
            ),
        ),
    ),
    var stroke: StrokePaint? = null,
    var icon: IconPaint = IconPaint(),
    var text: List<TextPaint> = emptyList(),
    /** Shared symbol placement (Apple `GridLayerPaint.symbol`); defaults sync from [icon.placement]. */
    var symbol: SymbolPlacementPaint = SymbolPlacementPaint(allowOverlap = StyleValue.Constant(true)),
    /**
     * Gridded / sidecar icon grid: step in **world pixels at zoom 0** (world width = 512px).
     * Consumed by [com.xweather.mapsgl.sources.EncodedGridVectorTileSource]; not emitted in Mapbox Style JSON.
     */
    var grid: GridPaint = GridPaint(spacing = 20.0),
    /**
     * Encoded-field color mapping for gridded/sidecar symbols ([SamplePaint.colorScale], optional [SamplePaint.encodedScalarNormMax]).
     * Not emitted in Mapbox Style JSON.
     */
    var sample: SamplePaint? = null,
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        // If halo thickness is a constant 0.0, omit halo-related style properties.
        // This lets Mapbox avoid extra halo/shader work instead of "drawing" a zero-width halo.
        val strokeThickness = stroke?.thickness
        val strokeThicknessConstant = strokeThickness?.constantValue
        val hasNonZeroHalo =
            stroke != null && (strokeThicknessConstant == null || kotlin.math.abs(strokeThicknessConstant) > 1e-9)

        return StyleJSON(id, StyleJSON.LayerType.SYMBOL, source, sourceLayer).apply {
            iconAllowOverlap = icon.allowOverlap
            iconAnchor = icon.anchor
            iconColor = fill?.color
            if (hasNonZeroHalo) {
                iconHaloColor = stroke?.color
                iconHaloWidth = stroke?.thickness
            }
            iconImage = icon.image
            iconOffset = icon.offset
            iconOpacity = fill?.opacity
            iconPadding = icon.padding
            iconRotate = icon.rotationExpression
            iconSize = icon.resolvedIconSizeStyle()

            text.firstOrNull()?.let { baseText ->
                textField = if (text.size > 1) {
                    val baseSize = baseText.size?.resolvedValue as? Double ?: 12.0
                    val inputs = text.flatMap {
                        val size = (it.size?.resolvedValue as? Double) ?: 12.0
                        val scale = size / baseSize
                        listOf(
                            it.value to TextFormatOptions(fontScale = scale),
                            StyleValue.Constant("\n") to TextFormatOptions(fontScale = scale)
                        )
                    }
                    StyleValue.Expression(Expression.format(inputs))
                } else {
                    baseText.value
                }
                textAllowOverlap = baseText.allowOverlap
                textAnchor = baseText.anchor
                textColor = baseText.color
                textHaloColor = baseText.outlineColor
                textHaloBlur = StyleValue.Constant(0.5)
                textHaloWidth =
                    if (hasNonZeroHalo) stroke?.thickness ?: StyleValue.Constant(1.0) else StyleValue.Constant(0.0)
                textJustify = baseText.align
                textLetterSpacing = baseText.letterSpacing
                textLineHeight = baseText.lineHeight
                textMaxWidth = baseText.maxWidth
                textOffset = baseText.offset
                textOpacity = baseText.opacity
                textPadding = baseText.padding
                textRotate = baseText.rotation
                textSize = baseText.size
                textTransform = baseText.transform
            }
        }
    }
}

/**
 * Paint for [com.xweather.mapsgl.layers.spec.HeatmapLayerDescriptor].
 */
data class HeatmapLayerPaint(
    override var opacity: Float = 1.0f, var heatmap: HeatmapPaint
) : VectorLayerPaint {
    override fun asStyleJSON(id: String, source: String, sourceLayer: String?): StyleJSON {
        return StyleJSON(id, StyleJSON.LayerType.HEATMAP, source, sourceLayer).apply {
            heatmapColor = heatmap.color
            heatmapIntensity = heatmap.intensity
            heatmapRadius = heatmap.radius
            heatmapOpacity = StyleValue.Constant(opacity.toDouble())
            heatmapWeight = heatmap.weight
            heatmapBlur = heatmap.blur
        }
    }
}

/**
 * JS `paint.sample.meld` — whether this layer's [SamplePaint] blends across timeline intervals.
 * Defaults to `true` when the paint has no sample block.
 */
fun LayerPaint.sampleMeldEnabled(): Boolean =
    when (this) {
        is SampleLayerPaint -> sample.meld
        is ContourLayerPaint -> sample.meld
        is ParticleLayerPaint -> sample.meld
        is GridLayerPaint -> sample?.meld ?: true
        else -> true
    }

/**
 * Timeline blend factor for sampling / draw. Returns `0` when [sampleMeldEnabled] is false
 * (JS: `sampleMeld() ? progress : 0`).
 */
fun LayerPaint.effectiveSampleMeldProgress(timelineMeld: Float): Float =
    if (sampleMeldEnabled()) timelineMeld.coerceIn(0f, 1f) else 0f

