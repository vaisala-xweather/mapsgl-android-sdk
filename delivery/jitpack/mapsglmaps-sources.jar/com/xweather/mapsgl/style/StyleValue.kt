package com.xweather.mapsgl.style

import androidx.compose.ui.graphics.Color
import com.xweather.mapsgl.style.Expression

data class Anchor(val rawValue: String)
data class AnchorOffset(val x: Double, val y: Double)
data class TextJustification(val rawValue: String)
data class TextTransform(val rawValue: String)

sealed class StyleColor {
    data class Color(val color: androidx.compose.ui.graphics.Color) : StyleColor()
    data class Hex(val hexString: String) : StyleColor()
    data class RGBA(val rgbaString: String) : StyleColor()

    fun toRGBAString(): String = when (this) {
        is Color -> color.toRGBAString()
        is Hex -> hexString
        is RGBA -> rgbaString
    }
}

fun Color.toRGBAString(): String {
    val a = this.alpha
    val r = (this.red * 255.0).toInt()
    val g = (this.green * 255.0).toInt()
    val b = (this.blue * 255.0).toInt()
    return "rgba($r,$g,$b,$a)"
}

//fun Int.toRGBAString(): String {
//    val a = Color.alpha(this) / 255f
//    val r = Color.red(this)
//    val g = Color.green(this)
//    val b = Color.blue(this)
//    return "rgba($r,$g,$b,$a)"
//}

sealed class StyleValue<out T> {
    data class Constant<T>(val value: T) : StyleValue<T>()
    data class Expression(val expression: com.xweather.mapsgl.style.Expression) : StyleValue<Nothing>()

    val constantValue: T?
        get() = (this as? Constant<T>)?.value

    val expressionValue: com.xweather.mapsgl.style.Expression?
        get() = (this as? Expression)?.expression

    val resolvedValue: Any?
        get() = when (this) {
            is Constant -> makeJSONObject(value)
            is Expression -> expression.toJSONObject()
        }

    companion object {
        fun <T> fromExpressionArray(array: List<Any>): StyleValue<T> = Expression(Expression(array))
    }
}

fun makeJSONObject(value: Any?): Any? = when (value) {
    is Expression -> value.toJSONObject()
    is Anchor -> value.rawValue
    is AnchorOffset -> listOf(value.x, value.y)
    // Support the public types used by IconPaint/TextPaint.
    // Without this, `com.xweather.mapsgl.types.Anchor.BOTTOM` etc. won't serialize to the
    // expected Mapbox `icon-anchor` / `text-anchor` string/offset and Mapbox falls back to center.
    is com.xweather.mapsgl.types.Anchor -> value.value
    is com.xweather.mapsgl.types.AnchorOffset -> listOf(value.x, value.y)
    is TextJustification -> value.rawValue
    is TextTransform -> value.rawValue
    is List<*> -> value.map { makeJSONObject(it) }
    is Map<*, *> -> value.entries.associate { (k, v) -> k.toString() to makeJSONObject(v) }
    is Color -> value.toRGBAString()
    is StyleColor -> when (value) {
        is StyleColor.Color -> value.color.toRGBAString()
        is StyleColor.Hex -> value.hexString
        is StyleColor.RGBA -> value.rgbaString
    }
//    is Int -> value.toRGBAString()
    else -> value
}