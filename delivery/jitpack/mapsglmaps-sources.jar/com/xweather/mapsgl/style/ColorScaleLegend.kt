package com.xweather.mapsgl.style


import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.xweather.mapsgl.anim.EasingCurve
import java.lang.Double.max
import kotlin.math.floor


/**
 * This is a direct adaptation of the swift version of ColorScale. I incorporated much of it
 * into my existing ColorScale. I will leave this here unused for a while in case I need any
 * more functions or variables from it in the course of adapting the Legend feature.
 */

/**
 * Defines a value/color pair for a `ColorScale`.
 */
data class ColorStopLegendDisabled(
    val value: Double,
    val color: Color
)

/**
 * A `ColorScale` maps numeric values to a color palette.
 */
class ColorScaleLegendDisabled {
    var colors: List<Color> = listOf(Color.White, Color.Black)
        private set

    var domain: List<Double> = listOf(0.0, 1.0)
        private set

    var stops: List<Double> = emptyList()
        private set

    var positions: List<Double> = listOf(0.0, 1.0)
        private set

    var range: ClosedRange<Double> = 0.0..1.0
        private set

    private var _cache: MutableMap<Int, Color> = mutableMapOf()

    constructor(colors: List<Color>, domain: List<Double>? = null, stops: List<Double>? = null) {
        setColors(colors)
        domain?.let { setDomain(it) }
        stops?.let { setStops(it) }
    }

    constructor(
        colorStops: List<ColorStop>,
        range: ClosedRange<Double>? = null,
        normalized: Boolean = false,
        positions: List<Double>? = null
    ) {
        var scaleStops = colorStops.toMutableList()

        if (range != null && scaleStops.isNotEmpty()) {
            val stopsInRange = scaleStops.withIndex()
                .filter { range.contains(it.value.value) }

            val newStops = stopsInRange.map { it.value }.toMutableList()

            stopsInRange.firstOrNull()?.let { start ->
                if (start.value.value != range.start) {
                    val offsetIdx = max(0.0, (start.index - 1).toDouble()).toInt()
                    newStops.add(0, ColorStop(range.start, scaleStops[offsetIdx].color))
                }
            }

            stopsInRange.lastOrNull()?.let { end ->
                if (end.value.value != range.endInclusive) {
                    val offsetIdx = minOf(end.index + 1, scaleStops.size - 1)
                    newStops.add(ColorStop(range.endInclusive, scaleStops[offsetIdx].color))
                }
            }

            if (normalized) {
                scaleStops = newStops.map { stop ->
                    val normalizedValue = lerp(range.start, range.endInclusive, stop.value)
                    ColorStop(normalizedValue, stop.color)
                }.toMutableList()
            } else {
                scaleStops = newStops
            }
        }

        setColors(scaleStops.map { it.color })
        setDomain(scaleStops.map { it.value })
        positions?.let { setPositions(it) }
    }

    constructor(options: ColorScaleOptions) : this(
        colorStops = colorStopsFromOptionsStops(options.stops),
        range = options.range,
        normalized = options.normalized,
        positions = options.positions
    )

    /**
     * Returns an array of equidistant colors.
     */
    fun colors(count: Int): List<Color> {
        if (count <= 0) return emptyList()
        val rangeMin = this.range.start
        val rangeMax = this.range.endInclusive

        if (count == 1) {
            return listOf(this.color(rangeMin + (rangeMax - rangeMin) * 0.5))
        }

        return (0 until count).map { index ->
            val t = index.toDouble() / (count - 1)
            val value = lerp(rangeMin, rangeMax, t)
            this.color(value)
        }
    }

    /**
     * Returns the color for the given value.
     */
    fun color(forValue: Double, bypassMap: Boolean = false): Color {
        if (this.colors.isEmpty()) {
            return Color.Transparent
        }

        val position = this.position(forValue, bypassMap).coerceIn(0.0, 1.0)
        val cacheKey = floor(position * 10000).toInt()
        _cache[cacheKey]?.let { return it }

        var resolvedColor = this.colors.last()
        for (index in this.positions.indices) {
            val current = this.positions[index]

            if (position <= current || index == this.positions.lastIndex) {
                resolvedColor = this.colors[index]
                break
            }

            val next = this.positions[index + 1]
            if (position > current && position < next) {
                val t = ((position - current) / (next - current)).toFloat()
                resolvedColor = lerp(this.colors[index], this.colors[index + 1], t)
                break
            }
        }
        _cache[cacheKey] = resolvedColor
        return resolvedColor
    }

    fun stopIndex(forValue: Double): Int {
        if (stops.isEmpty()) return 0
        if (forValue >= stops.last()) return stops.size - 1

        stops.indexOf(forValue).let { if (it != -1) return it }
        stops.indexOfFirst { forValue <= it }.let { if (it != -1) return max(it - 1.0, 0.0).toInt() }

        return 0
    }

    fun setColors(colors: List<Color>) {
        var adjustedColors = colors
        if (adjustedColors.isEmpty()) {
            adjustedColors = listOf(Color.White, Color.Black)
        } else if (adjustedColors.size == 1) {
            adjustedColors = listOf(adjustedColors.first(), adjustedColors.first())
        }
        this.colors = adjustedColors
        this.positions = defaultPositions(forCount = adjustedColors.size)
        this._cache.clear()
    }

    fun setDomain(domain: List<Double>) {
        if (domain.isEmpty()) return

        var sortedDomain = domain.sorted()
        var positions: List<Double>
        val min = sortedDomain.first()
        val max = sortedDomain.last()

        if (sortedDomain.size == 2) {
            positions = defaultPositions(forCount = this.colors.size)
        } else if (sortedDomain.size == this.colors.size) {
            val delta = max - min
            positions = if (delta == 0.0) {
                List(this.colors.size) { 0.0 }
            } else {
                sortedDomain.map { lerpInverse(min, max, it) }
            }
        } else {
            // In a real app, use a proper logger like Log.e()
            println("Error: Domain should match the number of colors set.")
            positions = defaultPositions(forCount = this.colors.size)
            sortedDomain = listOf(min, max)
        }
        this.positions = positions
        this.domain = sortedDomain
        this.range = min..max
        this._cache.clear()
    }

    fun setStops(count: Int) {
        val min = this.range.start
        val max = this.range.endInclusive
        if (count <= 0) {
            setStops(listOf(min, max))
            return
        }

        val limits = (0 until count).map { index ->
            val ratio = index.toDouble() / count
            min + ratio * (max - min)
        }.toMutableList()
        limits.add(max)
        setStops(limits)
    }

    fun setStops(stops: List<Double>) {
        if (stops.isEmpty()) return
        val sorted = stops.sorted()
        this.stops = sorted
        sorted.firstOrNull()?.let { min ->
            sorted.lastOrNull()?.let { max ->
                if (min != max) {
                    this.range = min..max
                }
            }
        }
        this._cache.clear()
    }

    fun setPositions(positions: List<Double>) {
        if (positions.size != this.colors.size) {
            println("Error: Total positions must match total colors.")
            return
        }
        this.positions = positions
        this._cache.clear()
    }

    fun position(forValue: Double, bypassMap: Boolean = false): Double {
        if (domain.size <= 1) return positions.firstOrNull() ?: 0.0

        val min = this.range.start
        val max = this.range.endInclusive
        var sample = forValue

        if (!bypassMap) {
            sample = when {
                stops.size > 2 -> stops[stopIndex(forValue)]
                max == min -> max
                else -> sample
            }
        }
        sample = sample.coerceIn(min, max)

        var evalDomain = this.domain
        if (evalDomain.size == 2 && positions.size > 2) {
            val a = evalDomain[0]
            val b = evalDomain[1]
            evalDomain = positions.indices.map { idx ->
                lerp(a, b, idx.toDouble() / (positions.size - 1))
            }
        }

        for (index in 0 until evalDomain.lastIndex) {
            val start = evalDomain[index]
            val end = evalDomain[index + 1]

            if (sample <= start) return positions[index]
            if (sample >= end && index == evalDomain.lastIndex - 1) return positions[index + 1]

            if (sample > start && sample < end) {
                val span = end - start
                if (span == 0.0) return positions[index]
                val t = (sample - start) / span
                return lerp(positions[index], positions[index + 1], t)
            }
        }

        return positions.lastOrNull() ?: 1.0
    }

    fun getColorRelative(position: Double): Color = color(position, bypassMap = true)

    fun scale(min: Double, max: Double) {
        val currentMin = this.range.start
        val currentMax = this.range.endInclusive
        val scaledDomain = this.domain.map { value ->
            lerp(min, max, lerpInverse(currentMin, currentMax, value))
        }
        setDomain(scaledDomain)
    }

    fun clone(): ColorScaleLegendDisabled {
        val scale = ColorScaleLegendDisabled(colors = this.colors)
        scale.setDomain(this.domain)
        if (this.stops.isNotEmpty()) {
            scale.setStops(this.stops)
        }
        scale.setPositions(this.positions)
        return scale
    }

    // NOTE: This getRamp function was already converted in a previous turn.
    // It is included here for completeness.
    fun getRamp(
        range: ClosedRange<Double>? = null,
        totalColors: Int = 0,
        interval: Double = 0.0,
        breaks: List<Double>? = null,
        interpolate: Boolean = true,
        normalized: Boolean = false,
        easing: EasingCurve? = null
    ): ColorRampResult {
        val scale = this.clone()
        val easingFunc = easing ?: { it }
        var min = range?.start ?: scale.range.start // Ensure min is Float
        var max = range?.endInclusive ?: scale.range.endInclusive // Ensure max is Float

        if (normalized) {
            min = range?.start ?: min
            max = range?.endInclusive ?: max
        }

        var calculatedBreaks: MutableList<Double> = mutableListOf()
        if (!interpolate) {
            calculatedBreaks.addAll(scale.domain)
        } else if (interval > 0 || !breaks.isNullOrEmpty()) {
            if (!breaks.isNullOrEmpty()) {
                calculatedBreaks.addAll(breaks)
            } else if (interval > 0) {
                var value = nearestInterval(min.toDouble(), interval, roundUp = true)
                if (min.toDouble() < value) {
                    calculatedBreaks.add(min.toDouble())
                }

                while (value <= max.toDouble()) {
                    calculatedBreaks.add(value)
                    value += interval
                }

                if ((calculatedBreaks.lastOrNull() ?: Double.POSITIVE_INFINITY) < max.toDouble()) {
                    calculatedBreaks.add(max.toDouble())
                }
            }
            if (calculatedBreaks.isNotEmpty()) {
                calculatedBreaks = calculatedBreaks.map { nearestInterval(it, 0.001) }.toMutableList()
            }
        }

        if (calculatedBreaks.isNotEmpty()) {
            scale.setStops(calculatedBreaks)
        }

        val entries = mutableListOf<ColorRampResult.Entry>()
        if (totalColors > 1) {
            for (index in 0 until totalColors) {
                val position = index.toDouble() / (totalColors - 1)
                val samplePosition = if (calculatedBreaks.isEmpty()) easingFunc(position) else position
                // Corrected Call #1
                val value = lerp(min.toDouble(), max.toDouble(), samplePosition)
                entries.add(ColorRampResult.Entry(value, scale.color(value), position))
            }
        } else {
            val samples: List<Double> = if (calculatedBreaks.size > 2) scale.stops else scale.domain
            for (sample in samples) {
                val color = scale.color(sample)
                val position = scale.position(sample)
                entries.add(ColorRampResult.Entry(sample, color, position))
            }
        }

        val stops = entries.filter { it.value >= min && it.value <= max }
        return ColorRampResult(
            stops = stops,
            valueForPosition = { position ->
                val eased = easingFunc(position)
                // Corrected Call #2
                lerp(min.toDouble(), max.toDouble(), eased)
            },
            positionForValue = { value ->
                this.position(forValue = value)
            }
        )
    }

    companion object {
        fun defaultPositions(forCount: Int): List<Double> {
            val safeCount = max(forCount.toDouble(), 2.0).toInt()
            val denominator = (safeCount - 1).toDouble()
            return (0 until safeCount).map { it.toDouble() / denominator }
        }

        fun lerpInverse(min: Double, max: Double, value: Double): Double {
            val delta = max - min
            return if (delta == 0.0) 0.0 else (value - min) / delta
        }

        fun nearestInterval(value: Double, interval: Double, roundUp: Boolean = false): Double {
            if (interval == 0.0) return value
            // Note: Swift's .rounded() is different from Kotlin's round().
            // This implementation matches the intended behavior.
            val adjusted = (value + interval / 2.0) / interval
            val rounded = if (roundUp) kotlin.math.ceil(adjusted) else floor(adjusted)
            return rounded * interval
        }
    }
}

// Helper functions for lerp on Double.
fun lerp(start: Double, stop: Double, fraction: Double): Double {
    return (1 - fraction) * start + fraction * stop
}

fun ClosedRange<Float>?.toDoubleRange(): ClosedRange<Double>? {
    return this?.let { it.start.toDouble()..it.endInclusive.toDouble() }
}