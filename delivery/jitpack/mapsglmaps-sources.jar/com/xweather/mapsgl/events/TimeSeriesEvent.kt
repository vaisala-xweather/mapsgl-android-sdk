package com.xweather.mapsgl.events

enum class TimeSeriesEvent(val value: String): Event {
    /** Triggered when the time series begins playback. */
    PLAY("play"),

    /** Triggered when the time series stops playback. */
    STOP("stop"),

    /**  */
    ADVANCE("advance"),

    /** Triggered when the time series advances the current time. */
    INTERVAL_ADVANCE("interval:advance"),

    /** Triggered when the current time interval advances. */
    DATA_ADVANCE("data:advance"),

    /** Triggered when the time series data changes. */
    DATA_CHANGE("data:change"),

    /** Triggered when the time series makes a data request before loading. */
    DATA_REQUEST("data:request"),

    /** Triggered when the time series data is ready, either to render or animate. */
    DATA_READY("data:ready"),

    /** Triggered when the data is removed from the time series. */
    DATA_REMOVE("data:remove"),

    /** Triggered when the time series begins requesting data. */
    LOAD_START("load:start"),

    /** Triggered when the time series has completed requesting data. */
    LOAD_COMPLETE("load:complete"),

    /** Triggered when the time series has loaded data for a single time interval. */
    LOAD_INTERVAL("load:interval"),

    /** Triggered when the time intervals change. */
    INTERVALS_CHANGE("intervals:change"),

    /** Triggered when the time series is invalidated. */
    INVALIDATE("invalidate");

    override fun toString(): String {
        return value
    }
}