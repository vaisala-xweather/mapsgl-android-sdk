package com.xweather.mapsgl.events

class MapControllerEvents {
    companion object {
        const val LAYER_ADDED = "layer:added" // in use
        const val LAYER_REMOVED = "layer:removed" // in use

        // Load progress/completion is NOT on this string bus. It is exposed from [MapController] as
        // `onLoadComplete` / `dlProgress` / `onLoadProgress` LiveData plus the `onLoadProgressValue`
        // Signal, and the data inspector is already refreshed from it directly (see the encoded
        // tile-load and vector-prefetch observers in MapController) -- so nothing needs to listen
        // for a "load:complete" event here.
        internal const val VISIBILITY_CHANGED = "visibility:changed" // in use
        internal const val VECTOR_LAYER_ADDED = "vectorLayer:added" // in use
    }
}