package com.xweather.mapsgl.events

import com.xweather.mapsgl.weather.AccessToken

/**
 *  AuthenticatorEvents.kt
 *
 *  @author Jason Suto 03/26/24
 */
object AuthenticatorEvents {
    data class Token(val token: AccessToken) : Event {
        companion object {
            const val id = "token"
        }
    }

    init {
        error("${this::class.simpleName} is used for namespace-style grouping only, and is not initializable.")
    }
}


