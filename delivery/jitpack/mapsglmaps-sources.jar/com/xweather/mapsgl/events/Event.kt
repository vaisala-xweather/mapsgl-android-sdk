package com.xweather.mapsgl.events

interface EventCustom {
    val id: String
}
