package com.xweather.mapsgl.mvt

import java.io.IOException

/** Thrown when tile bytes do not parse as a Mapbox Vector Tile. */
class MalformedMvtException(message: String) : IOException(message)

/**
 * Protobuf-free reader for Mapbox Vector Tile (MVT) 2.1 bytes.
 *
 * Replaces `no.ecc.vectortile.VectorTileDecoder` plus the `PruningVectorTileDecoder` that used to
 * sit alongside it in that package. Both depended on generated protobuf message classes, which
 * hard-require `com.google.protobuf:protobuf-java`; that jar defines the same class names as
 * `protobuf-javalite` and so fails dexing for any consumer app that uses javalite for its own
 * protos (github issue #37). The MVT schema is small and frozen by the spec, so reading the wire
 * format directly costs less than the dependency did.
 *
 * ## Behavioural parity
 *
 * Output is intended to be identical to the decoder it replaces, run with `autoScale = false`
 * (the only mode this SDK ever used). `MvtReaderParityTest` asserts that against the reference
 * implementation. In particular the polygon ring-grouping rule -- group rings by the sign of their
 * shoelace area, first non-degenerate ring establishes the exterior winding, zero-area rings
 * dropped -- is a direct port, because it decides which rings become holes, and getting it subtly
 * wrong would misrender polygons rather than fail loudly.
 *
 * Two intentional divergences, neither reachable from a valid tile:
 *
 *  - JTS validated rings in `createLinearRing` and threw for an unclosed ring or one with 1..3
 *    points. Those rings are already dropped here by the zero-area test that runs first (a ring
 *    with fewer than 4 points is degenerate or collinear, so its area is 0), so the validation
 *    never fired. This reader is simply permissive instead.
 *  - A `ClosePath` or `LineTo` arriving before any `MoveTo` threw NullPointerException in the
 *    reference. Here the former is ignored and the latter opens a ring.
 *
 * ## Allocation
 *
 * The old path went through generated protobuf messages, which materialised the whole tile as an
 * object tree before anything was read: a `List<Integer>` of boxed geometry commands per feature,
 * an attribute `HashMap` per feature, and layer-level key/value lists. A heap dump taken during
 * the playback burst attributed ~1.95M `HashMap$Node` + ~893k `UnmodifiableEntry` + ~1.26M
 * `String` to that. This reader streams the wire format instead and never boxes a geometry
 * command, and it keeps the attribute pruning `PruningVectorTileDecoder` added (see [decode]'s
 * `allowed` parameter), so tags no consumer declared never become map entries at all.
 *
 * [decode] is stateless and safe to call concurrently from the parse coroutines -- all cursor and
 * scratch state lives on a per-call [MvtParser].
 */
object MvtReader {

    /**
     * Per-layer attribute allowlist.
     *
     * Returning `null` for a layer means "this layer needs every attribute". Returning a set means
     * only those keys are materialised; a dot-notated MVT key such as `report.areaAC` is kept when
     * `report` is allowed, because `VectorTileSource` rebuilds those into nested dictionaries
     * after decode.
     */
    fun interface AllowedKeys {
        fun forLayer(layerName: String): Set<String>?
    }

    /**
     * Decodes every feature in [data], across all layers, in tile-local coordinates.
     *
     * [allowed] prunes attributes at decode time; pass `null` to keep every attribute on every
     * layer. Features come back in tile order (layer order, then feature order within a layer);
     * callers group them by [MvtFeature.layerName] themselves.
     *
     * @throws MalformedMvtException if the bytes are truncated or not MVT.
     */
    @JvmStatic
    @JvmOverloads
    @Throws(IOException::class)
    fun decode(data: ByteArray, allowed: AllowedKeys? = null): List<MvtFeature> =
        MvtParser(data).decodeTile(allowed)
}

// ---- Wire format ---------------------------------------------------------------------------
// Field numbers are fixed by the MVT 2.1 specification (vector_tile.proto) and can never change:
// a tile that renumbered them would not be an MVT tile.

private const val WIRE_VARINT = 0
private const val WIRE_FIXED64 = 1
private const val WIRE_LENGTH_DELIMITED = 2
private const val WIRE_START_GROUP = 3
private const val WIRE_END_GROUP = 4
private const val WIRE_FIXED32 = 5

private const val TILE_LAYERS = 3

private const val LAYER_NAME = 1
private const val LAYER_FEATURES = 2
private const val LAYER_KEYS = 3
private const val LAYER_VALUES = 4
private const val LAYER_EXTENT = 5

private const val FEATURE_ID = 1
private const val FEATURE_TAGS = 2
private const val FEATURE_TYPE = 3
private const val FEATURE_GEOMETRY = 4

private const val VALUE_STRING = 1
private const val VALUE_FLOAT = 2
private const val VALUE_DOUBLE = 3
private const val VALUE_INT = 4
private const val VALUE_UINT = 5
private const val VALUE_SINT = 6
private const val VALUE_BOOL = 7

/** `optional uint32 extent = 5 [default = 4096]` */
private const val DEFAULT_EXTENT = 4096

// GeomType enum values from the spec.
private const val GEOM_UNKNOWN = 0
private const val GEOM_POINT = 1
private const val GEOM_LINESTRING = 2
private const val GEOM_POLYGON = 3

// Geometry command ids from the spec.
private const val CMD_MOVE_TO = 1
private const val CMD_LINE_TO = 2
private const val CMD_CLOSE_PATH = 7

private val EMPTY_RINGS = emptyArray<MvtLineString>()

/**
 * One tile parse.
 *
 * Holds the read cursor and the scratch buffers reused across every feature in the tile, so no
 * state is shared between concurrent parses and no `ThreadLocal` lookup lands in the varint loop.
 */
private class MvtParser(private val data: ByteArray) {

    /** Read cursor. Every `read*` / `skip*` helper advances it. */
    private var pos = 0

    private val tagsBuf = IntBuf(32)
    private val geomBuf = IntBuf(256)

    fun decodeTile(allowed: MvtReader.AllowedKeys?): List<MvtFeature> {
        val out = ArrayList<MvtFeature>()
        val end = data.size
        pos = 0
        while (pos < end) {
            val tag = readVarint(end)
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7L).toInt()
            if (field == TILE_LAYERS && wire == WIRE_LENGTH_DELIMITED) {
                val len = readVarint(end).toInt()
                val layerStart = pos
                val layerEnd = checkedEnd(layerStart, len, end)
                decodeLayer(layerStart, layerEnd, allowed, out)
                pos = layerEnd
            } else {
                skipField(wire, end)
            }
        }
        return out
    }

    // ---- Layer -----------------------------------------------------------------------------

    /**
     * Reads one layer twice over the same byte range.
     *
     * The first pass collects name, extent, key table and value table while skipping feature
     * submessages; the second decodes features now that tags can be resolved. Two passes are
     * needed because the protobuf wire format does not guarantee field order, so a feature can
     * legally precede the key table it references -- the generated-message path hid this by
     * building the entire tile first. Skipping a feature is a length-delimited jump, so the first
     * pass costs a varint read per feature and nothing more.
     */
    private fun decodeLayer(
        start: Int,
        end: Int,
        allowed: MvtReader.AllowedKeys?,
        out: MutableList<MvtFeature>,
    ) {
        var name: String? = null
        var extent = DEFAULT_EXTENT
        val keys = ArrayList<String>()
        val values = ArrayList<Any?>()

        pos = start
        while (pos < end) {
            val tag = readVarint(end)
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7L).toInt()
            when {
                field == LAYER_NAME && wire == WIRE_LENGTH_DELIMITED -> name = readString(end)
                field == LAYER_KEYS && wire == WIRE_LENGTH_DELIMITED -> keys.add(readString(end))
                field == LAYER_VALUES && wire == WIRE_LENGTH_DELIMITED -> {
                    val len = readVarint(end).toInt()
                    val valueEnd = checkedEnd(pos, len, end)
                    values.add(decodeValue(valueEnd))
                    pos = valueEnd
                }

                field == LAYER_EXTENT && wire == WIRE_VARINT -> extent = readVarint(end).toInt()
                else -> skipField(wire, end)
            }
        }

        // A layer with no name cannot be addressed by any consumer: the reference decoder emitted
        // its features under a null layer name that nothing could ever match.
        val layerName = name ?: return

        // Resolve the allowlist once per layer against the key table, so the per-feature loop is
        // an array index rather than a string comparison per tag.
        val allowedForLayer = allowed?.forLayer(layerName)
        var keep: BooleanArray? = null
        if (allowedForLayer != null) {
            val k = BooleanArray(keys.size)
            for (i in keys.indices) {
                val key = keys[i]
                val dot = key.indexOf('.')
                k[i] = allowedForLayer.contains(if (dot < 0) key else key.substring(0, dot))
            }
            keep = k
        }

        pos = start
        while (pos < end) {
            val tag = readVarint(end)
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7L).toInt()
            if (field == LAYER_FEATURES && wire == WIRE_LENGTH_DELIMITED) {
                val len = readVarint(end).toInt()
                val featureEnd = checkedEnd(pos, len, end)
                out.add(decodeFeature(featureEnd, layerName, extent, keys, values, keep))
                pos = featureEnd
            } else {
                skipField(wire, end)
            }
        }
    }

    /**
     * Reads one `Tile.Value`, leaving [pos] anywhere inside it (the caller jumps to its end).
     *
     * The boxed types returned here are load-bearing: they reach app code through
     * `MapboxVectorFeature.attributesToJsonElement` and the renderers' `is Number` / `is String`
     * checks, and they match what the previous decoder produced field for field. Note `int_value`
     * and `uint_value` are 64-bit in the schema despite their names, so both box to [Long]. A
     * `Value` that sets none of its seven variants decodes to `null`, as before.
     */
    private fun decodeValue(end: Int): Any? {
        var result: Any? = null
        while (pos < end) {
            val tag = readVarint(end)
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7L).toInt()
            when {
                field == VALUE_STRING && wire == WIRE_LENGTH_DELIMITED -> result = readString(end)
                field == VALUE_FLOAT && wire == WIRE_FIXED32 ->
                    result = java.lang.Float.intBitsToFloat(readFixed32(end))

                field == VALUE_DOUBLE && wire == WIRE_FIXED64 ->
                    result = java.lang.Double.longBitsToDouble(readFixed64(end))

                field == VALUE_INT && wire == WIRE_VARINT -> result = readVarint(end)
                field == VALUE_UINT && wire == WIRE_VARINT -> result = readVarint(end)
                field == VALUE_SINT && wire == WIRE_VARINT -> {
                    val raw = readVarint(end)
                    result = (raw ushr 1) xor -(raw and 1L)
                }

                field == VALUE_BOOL && wire == WIRE_VARINT -> result = readVarint(end) != 0L
                else -> skipField(wire, end)
            }
        }
        return result
    }

    // ---- Feature ---------------------------------------------------------------------------

    private fun decodeFeature(
        end: Int,
        layerName: String,
        extent: Int,
        keys: List<String>,
        values: List<Any?>,
        keep: BooleanArray?,
    ): MvtFeature {
        var id = 0L
        var geomType = GEOM_UNKNOWN
        tagsBuf.clear()
        geomBuf.clear()

        while (pos < end) {
            val tag = readVarint(end)
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7L).toInt()
            when {
                field == FEATURE_ID && wire == WIRE_VARINT -> id = readVarint(end)
                field == FEATURE_TYPE && wire == WIRE_VARINT -> geomType = readVarint(end).toInt()

                // `tags` and `geometry` are declared packed, but the wire format permits a writer
                // to emit them unpacked, and permits a packed field to arrive as several chunks
                // that concatenate. Accept all three shapes; the protobuf runtime did.
                field == FEATURE_TAGS -> readPackedUInt32(wire, end, tagsBuf)
                field == FEATURE_GEOMETRY -> readPackedUInt32(wire, end, geomBuf)

                else -> skipField(wire, end)
            }
        }

        val attributes = buildAttributes(keys, values, keep)
        val geometry = decodeGeometry(geomType)
        return MvtFeature(layerName, extent, geometry, attributes, id)
    }

    /**
     * Materialises only the tags [keep] admits.
     *
     * The map is allocated lazily on the first surviving tag, so a feature whose every tag was
     * pruned costs no map at all -- that is the point of pruning, and the common case on dense
     * layers where a consumer declared two or three keys.
     */
    private fun buildAttributes(
        keys: List<String>,
        values: List<Any?>,
        keep: BooleanArray?,
    ): Map<String, Any?> {
        var attributes: HashMap<String, Any?>? = null
        val n = tagsBuf.size
        var i = 0
        while (i + 1 < n) {
            val keyIdx = tagsBuf[i]
            val valIdx = tagsBuf[i + 1]
            i += 2
            if (keyIdx < 0 || keyIdx >= keys.size) continue
            if (keep != null && !keep[keyIdx]) continue
            var map = attributes
            if (map == null) {
                map = HashMap(maxOf(2, n / 2))
                attributes = map
            }
            map[keys[keyIdx]] = if (valIdx >= 0 && valIdx < values.size) values[valIdx] else null
        }
        return attributes ?: emptyMap()
    }

    // ---- Geometry --------------------------------------------------------------------------

    /**
     * Walks the MVT command stream in [geomBuf] into a geometry.
     *
     * Direct port of `VectorTileDecoder.decodeGeometry` with `scale = 1` (the SDK always ran with
     * `autoScale = false`, so the division was always by 1). Command encoding: a header varint
     * carries the command id in its low 3 bits and a repeat count in the rest; `MoveTo` and
     * `LineTo` each consume a zigzag dx/dy pair per repeat, `ClosePath` consumes none and closes
     * the current ring by repeating its first vertex.
     *
     * The loop structure matters for termination: when a header decodes to a zero repeat count the
     * body is skipped entirely and the next iteration reads another header, which is what advances
     * the cursor. That mirrors the reference exactly -- do not add an `else` branch here.
     */
    private fun decodeGeometry(geomType: Int): MvtGeometry {
        val rings = ArrayList<ArrayList<MvtCoordinate>>()
        var coords: ArrayList<MvtCoordinate>? = null

        var x = 0
        var y = 0
        var length = 0
        var command = 0
        var i = 0
        val n = geomBuf.size

        while (i < n) {
            if (length <= 0) {
                length = geomBuf[i++]
                command = length and 0x7
                length = length shr 3
            }
            if (length > 0) {
                if (command == CMD_MOVE_TO) {
                    coords = ArrayList()
                    rings.add(coords)
                }
                if (command == CMD_CLOSE_PATH) {
                    // The reference threw NullPointerException when ClosePath preceded any
                    // MoveTo; ignore that command instead.
                    val current = coords
                    if (geomType != GEOM_POINT && current != null && current.isNotEmpty()) {
                        val first = current[0]
                        current.add(MvtCoordinate(first.x, first.y))
                    }
                    length--
                    continue
                }
                // The reference indexed past the end and threw; a truncated command stream just
                // ends the geometry here.
                if (i + 1 >= n) break
                val dx = zigZagDecode(geomBuf[i++])
                val dy = zigZagDecode(geomBuf[i++])
                length--
                x += dx
                y += dy
                var current = coords
                if (current == null) {
                    // A LineTo before any MoveTo has no ring to land in; the reference threw.
                    current = ArrayList()
                    coords = current
                    rings.add(current)
                }
                current.add(MvtCoordinate(x.toDouble(), y.toDouble()))
            }
        }

        return when (geomType) {
            GEOM_POINT -> buildPoints(rings)
            GEOM_LINESTRING -> buildLines(rings)
            GEOM_POLYGON -> buildPolygons(rings)
            else -> MvtEmptyGeometry
        }
    }

    private fun buildPoints(rings: List<List<MvtCoordinate>>): MvtGeometry {
        var total = 0
        for (r in rings) total += r.size
        if (total == 0) return MvtEmptyGeometry
        if (total == 1) {
            for (r in rings) if (r.isNotEmpty()) return MvtPoint(r[0].x, r[0].y)
        }
        val all = arrayOfNulls<MvtCoordinate>(total)
        var k = 0
        for (r in rings) for (c in r) all[k++] = c
        @Suppress("UNCHECKED_CAST")
        return MvtMultiPoint(all as Array<MvtCoordinate>)
    }

    private fun buildLines(rings: List<List<MvtCoordinate>>): MvtGeometry {
        val lines = ArrayList<MvtLineString>(rings.size)
        for (r in rings) {
            if (r.size <= 1) continue
            lines.add(MvtLineString(r.toTypedArray()))
        }
        return when (lines.size) {
            0 -> MvtEmptyGeometry
            1 -> lines[0]
            else -> MvtMultiLineString(lines.toTypedArray())
        }
    }

    /**
     * Groups rings into polygons by winding sign.
     *
     * The spec says a polygon feature is a flat sequence of rings in which each exterior ring
     * starts a new polygon and the rings following it are its holes, distinguished by opposite
     * winding. This mirrors the reference implementation including its quirks: the first
     * non-degenerate ring defines which sign counts as "exterior" (rather than trusting the
     * spec's clockwise convention), and zero-area rings are dropped before they can establish or
     * join a group.
     */
    private fun buildPolygons(rings: List<List<MvtCoordinate>>): MvtGeometry {
        val grouped = ArrayList<ArrayList<MvtLineString>>()
        var current: ArrayList<MvtLineString>? = null
        var exteriorIsCcw: Boolean? = null

        for (r in rings) {
            val ring = r.toTypedArray()
            val area = signedRingArea(ring)
            if (area == 0.0) continue
            val thisCcw = area < 0
            if (exteriorIsCcw == null) exteriorIsCcw = thisCcw
            if (exteriorIsCcw == thisCcw) {
                current?.let { grouped.add(it) }
                current = ArrayList()
            }
            current?.add(MvtLineString(ring))
        }
        current?.let { grouped.add(it) }

        val polygons = ArrayList<MvtPolygon>(grouped.size)
        for (g in grouped) {
            val holes = if (g.size > 1) Array(g.size - 1) { g[it + 1] } else EMPTY_RINGS
            polygons.add(MvtPolygon(g[0], holes))
        }

        return when (polygons.size) {
            0 -> MvtEmptyGeometry
            1 -> polygons[0]
            else -> MvtMultiPolygon(polygons.toTypedArray())
        }
    }

    /**
     * Signed shoelace area of a ring, negative for counter-clockwise.
     *
     * Port of `org.locationtech.jts.algorithm.Area.ofRingSigned`, keeping its translate-by-x0 form
     * and its summation order. Only the sign is consumed downstream, but the exact arithmetic
     * still matters: a ring whose true area is within rounding distance of zero must be classified
     * the way the reference classified it, or it moves between being a dropped degenerate and a
     * polygon-starting exterior.
     */
    private fun signedRingArea(ring: Array<MvtCoordinate>): Double {
        if (ring.size < 3) return 0.0
        var sum = 0.0
        val x0 = ring[0].x
        for (i in 1 until ring.size - 1) {
            val x = ring[i].x - x0
            val y1 = ring[i + 1].y
            val y2 = ring[i - 1].y
            sum += x * (y2 - y1)
        }
        return sum / 2.0
    }

    private fun zigZagDecode(n: Int): Int = (n shr 1) xor (-(n and 1))

    // ---- Wire primitives -------------------------------------------------------------------

    private fun readVarint(limit: Int): Long {
        var p = pos
        var result = 0L
        var shift = 0
        while (shift < 64) {
            if (p >= limit) throw MalformedMvtException("truncated varint at offset $p")
            val b = data[p++].toInt()
            result = result or ((b and 0x7F).toLong() shl shift)
            if (b and 0x80 == 0) {
                pos = p
                return result
            }
            shift += 7
        }
        throw MalformedMvtException("varint longer than 10 bytes at offset $pos")
    }

    private fun readString(limit: Int): String {
        val len = readVarint(limit).toInt()
        val end = checkedEnd(pos, len, limit)
        val s = String(data, pos, len, Charsets.UTF_8)
        pos = end
        return s
    }

    private fun readFixed32(limit: Int): Int {
        val p = pos
        if (p + 4 > limit) throw MalformedMvtException("truncated fixed32 at offset $p")
        pos = p + 4
        return (data[p].toInt() and 0xFF) or
            ((data[p + 1].toInt() and 0xFF) shl 8) or
            ((data[p + 2].toInt() and 0xFF) shl 16) or
            ((data[p + 3].toInt() and 0xFF) shl 24)
    }

    private fun readFixed64(limit: Int): Long {
        val p = pos
        if (p + 8 > limit) throw MalformedMvtException("truncated fixed64 at offset $p")
        pos = p + 8
        var v = 0L
        for (i in 7 downTo 0) v = (v shl 8) or (data[p + i].toLong() and 0xFF)
        return v
    }

    /**
     * Reads a `repeated uint32` field in either packed or unpacked form, appending to [into].
     *
     * Values are truncated to 32 bits exactly as protobuf's `readUInt32` did, so a value above
     * `Int.MAX_VALUE` wraps negative -- which is what the geometry command decoder and the tag
     * index bounds checks were already written against.
     */
    private fun readPackedUInt32(wire: Int, limit: Int, into: IntBuf) {
        when (wire) {
            WIRE_VARINT -> into.add(readVarint(limit).toInt())
            WIRE_LENGTH_DELIMITED -> {
                val len = readVarint(limit).toInt()
                val chunkEnd = checkedEnd(pos, len, limit)
                while (pos < chunkEnd) into.add(readVarint(chunkEnd).toInt())
                pos = chunkEnd
            }

            else -> skipField(wire, limit)
        }
    }

    private fun skipField(wire: Int, limit: Int) {
        when (wire) {
            WIRE_VARINT -> readVarint(limit)
            WIRE_FIXED64 -> pos = checkedEnd(pos, 8, limit)
            WIRE_LENGTH_DELIMITED -> {
                val len = readVarint(limit).toInt()
                pos = checkedEnd(pos, len, limit)
            }

            WIRE_FIXED32 -> pos = checkedEnd(pos, 4, limit)
            WIRE_START_GROUP, WIRE_END_GROUP ->
                throw MalformedMvtException("group wire type $wire is not valid in MVT")

            else -> throw MalformedMvtException("unknown wire type $wire at offset $pos")
        }
    }

    /** Bounds-checked `pos + len`, guarding a negative or overlong declared length. */
    private fun checkedEnd(from: Int, len: Int, limit: Int): Int {
        if (len < 0) throw MalformedMvtException("negative length $len at offset $from")
        val e = from + len
        if (e < from || e > limit) {
            throw MalformedMvtException("length $len at offset $from overruns limit $limit")
        }
        return e
    }
}

/** Minimal growable int array; avoids the boxed `List<Integer>` the protobuf path produced. */
private class IntBuf(initialCapacity: Int) {
    private var buf = IntArray(initialCapacity)
    var size = 0
        private set

    fun clear() {
        size = 0
    }

    fun add(value: Int) {
        if (size == buf.size) buf = buf.copyOf(if (buf.size == 0) 16 else buf.size * 2)
        buf[size++] = value
    }

    operator fun get(index: Int): Int = buf[index]
}
