package com.xweather.mapsgl.mvt

/**
 * One decoded feature from a Mapbox Vector Tile layer.
 *
 * Drop-in replacement for `no.ecc.vectortile.VectorTileDecoder.Feature`. The property names match
 * that type's Java getters exactly (`getLayerName` -> [layerName], `getExtent` -> [extent], and so
 * on) so the ~46 call sites that read these off a raw feature did not change when the decoder was
 * swapped.
 *
 * Two shape differences from the type it replaces, both deliberate:
 *
 *  - [geometry] is non-null. The old decoder also never returned null (it substituted an empty
 *    geometry collection), but Java platform types forced every Kotlin caller to null-check it
 *    anyway. [MvtEmptyGeometry] fills the same role with an honest type.
 *  - [attributes] is `Map<String, Any?>`. Values genuinely can be null -- an MVT `Value` message
 *    that sets none of its seven variants decodes to null, and the previous decoder stored that.
 *
 * Attribute maps are already pruned to the keys some consumer declared (see [MvtReader.decode]);
 * a feature whose tags were all pruned carries [emptyMap].
 */
class MvtFeature(
    @JvmField val layerName: String,
    @JvmField val extent: Int,
    @JvmField val geometry: MvtGeometry,
    @JvmField val attributes: Map<String, Any?>,
    @JvmField val id: Long,
) {
    /**
     * Identity equality, matching the type this replaces.
     *
     * `VectorTileDecoder.Feature` declared no `equals`/`hashCode`, and callers rely on that:
     * `VectorPolygonFillTriangulator` collects hit-test results into a `LinkedHashSet` and expects
     * two distinct features with identical geometry and attributes to both survive. Adding
     * structural equality here would silently collapse them.
     */

    override fun toString(): String =
        "MvtFeature(layer=$layerName, id=$id, geom=${geometry::class.java.simpleName}, " +
            "attrs=${attributes.size})"
}
