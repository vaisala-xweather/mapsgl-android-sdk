package com.xweather.mapsgl.mvt

/**
 * Minimal geometry model for decoded Mapbox Vector Tile features.
 *
 * Replaces the `org.locationtech.jts.geom` types the MVT decode path used to return. JTS was never
 * used for geometry *operations* here -- no predicates, no overlay, no spatial index, no WKT/WKB --
 * only as a typed container for tile-local coordinate rings that renderers immediately walk and
 * project themselves. That cost consumers a ~1.2 MB transitive jar, and came bundled with
 * `no.ecc.vectortile` -> `com.google.protobuf:protobuf-java`, which collides at dex time with any
 * app using `protobuf-javalite` (github issue #37).
 *
 * Member names deliberately mirror the JTS accessors they replace (`coordinates`, `numGeometries`,
 * `getGeometryN`, `exteriorRing`, `numInteriorRing`, `getInteriorRingN`, `envelopeInternal`) so the
 * renderer bodies that walk these objects did not have to change during the migration.
 *
 * Everything here is tile-local: coordinates are in the layer's own extent space (typically
 * 0..4095), not lon/lat. Callers project via `tileLocalXYToTileUv` / `tileLocalXYToLngLat`.
 */

/**
 * A 2-D tile-local coordinate.
 *
 * [equals] intentionally uses raw IEEE `==` on both components, matching
 * `org.locationtech.jts.geom.Coordinate.equals2D`. Ring-closure checks in the renderers
 * (`coords.first() == coords.last()`) depend on this exact semantic: a Kotlin `data class` would
 * instead box and use `Double.equals`, which treats `NaN == NaN` as true and `0.0 == -0.0` as
 * false -- the opposite of JTS on both counts.
 */
class MvtCoordinate(@JvmField val x: Double, @JvmField val y: Double) {

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is MvtCoordinate) return false
        return x == other.x && y == other.y
    }

    override fun hashCode(): Int {
        // Mirrors JTS Coordinate.hashCode(): 17/37 seed over the Double hash of each ordinate.
        var result = 17
        result = 37 * result + java.lang.Double.hashCode(x)
        result = 37 * result + java.lang.Double.hashCode(y)
        return result
    }

    override fun toString(): String = "($x, $y)"
}

/**
 * Axis-aligned bounds, the replacement for `org.locationtech.jts.geom.Envelope`.
 *
 * [isNull] marks the empty envelope (a geometry with no coordinates), matching the JTS convention
 * of a "null envelope" rather than a nullable return.
 */
class MvtEnvelope private constructor(
    @JvmField val minX: Double,
    @JvmField val minY: Double,
    @JvmField val maxX: Double,
    @JvmField val maxY: Double,
    @JvmField val isNull: Boolean,
) {
    companion object {
        @JvmField
        val NULL: MvtEnvelope = MvtEnvelope(0.0, 0.0, 0.0, 0.0, true)

        /** Builds the envelope covering [coords], or [NULL] when there are none. */
        fun of(coords: Array<MvtCoordinate>): MvtEnvelope {
            if (coords.isEmpty()) return NULL
            var minX = Double.POSITIVE_INFINITY
            var minY = Double.POSITIVE_INFINITY
            var maxX = Double.NEGATIVE_INFINITY
            var maxY = Double.NEGATIVE_INFINITY
            for (c in coords) {
                if (c.x < minX) minX = c.x
                if (c.x > maxX) maxX = c.x
                if (c.y < minY) minY = c.y
                if (c.y > maxY) maxY = c.y
            }
            return MvtEnvelope(minX, minY, maxX, maxY, false)
        }

        /** Union of the child envelopes, skipping null ones. */
        fun of(children: List<MvtGeometry>): MvtEnvelope {
            var minX = Double.POSITIVE_INFINITY
            var minY = Double.POSITIVE_INFINITY
            var maxX = Double.NEGATIVE_INFINITY
            var maxY = Double.NEGATIVE_INFINITY
            var any = false
            for (child in children) {
                val e = child.envelopeInternal
                if (e.isNull) continue
                any = true
                if (e.minX < minX) minX = e.minX
                if (e.maxX > maxX) maxX = e.maxX
                if (e.minY < minY) minY = e.minY
                if (e.maxY > maxY) maxY = e.maxY
            }
            return if (any) MvtEnvelope(minX, minY, maxX, maxY, false) else NULL
        }
    }
}

/** Base type for every decoded MVT geometry. */
sealed class MvtGeometry {

    /** Cached like JTS cached its own; hit-testing calls this per feature on every tap. */
    abstract val envelopeInternal: MvtEnvelope

    /** 1 for a single geometry, the child count for a multi-geometry, 0 for the empty one. */
    open val numGeometries: Int get() = 1

    /** Mirrors `Geometry.getGeometryN`: returns `this` for single geometries. */
    open fun getGeometryN(n: Int): MvtGeometry = this

    /** True when this geometry carries no coordinates. */
    abstract val isEmpty: Boolean
}

/** A single tile-local point. */
class MvtPoint(@JvmField val x: Double, @JvmField val y: Double) : MvtGeometry() {

    val coordinate: MvtCoordinate get() = MvtCoordinate(x, y)

    val coordinates: Array<MvtCoordinate> get() = arrayOf(MvtCoordinate(x, y))

    override val envelopeInternal: MvtEnvelope by lazy(LazyThreadSafetyMode.PUBLICATION) {
        MvtEnvelope.of(arrayOf(MvtCoordinate(x, y)))
    }

    override val isEmpty: Boolean get() = false
}

/**
 * An open or closed run of coordinates.
 *
 * MVT polygon rings use this same type. JTS modelled rings as a `LinearRing` subclass, but nothing
 * in this codebase distinguished the two -- rings and lines are both consumed through
 * [coordinates]. Ring closure is preserved exactly as decoded: the `ClosePath` command appends a
 * duplicate of the first vertex, and the renderers strip that trailing duplicate themselves.
 */
class MvtLineString(@JvmField val coordinates: Array<MvtCoordinate>) : MvtGeometry() {

    val numPoints: Int get() = coordinates.size

    override val envelopeInternal: MvtEnvelope by lazy(LazyThreadSafetyMode.PUBLICATION) {
        MvtEnvelope.of(coordinates)
    }

    override val isEmpty: Boolean get() = coordinates.isEmpty()
}

/**
 * A polygon: one exterior ring plus zero or more interior rings (holes).
 *
 * Ring winding is whatever [MvtGeometryDecoder] produced, which follows the MVT signed-area
 * convention. Renderers that need a specific orientation re-orient themselves.
 *
 * [envelopeInternal] delegates to the exterior ring: interior rings are contained within it by
 * definition, so the union would be identical. This matches what JTS computed for a `Polygon`.
 */
class MvtPolygon(
    @JvmField val exteriorRing: MvtLineString,
    @JvmField val interiorRings: Array<MvtLineString>,
) : MvtGeometry() {

    val numInteriorRing: Int get() = interiorRings.size

    fun getInteriorRingN(n: Int): MvtLineString = interiorRings[n]

    override val envelopeInternal: MvtEnvelope
        get() = exteriorRing.envelopeInternal

    override val isEmpty: Boolean get() = exteriorRing.isEmpty
}

/** Two or more points decoded from a single MVT feature. */
class MvtMultiPoint(@JvmField val coordinates: Array<MvtCoordinate>) : MvtGeometry() {

    override val numGeometries: Int get() = coordinates.size

    override fun getGeometryN(n: Int): MvtGeometry =
        MvtPoint(coordinates[n].x, coordinates[n].y)

    override val envelopeInternal: MvtEnvelope by lazy(LazyThreadSafetyMode.PUBLICATION) {
        MvtEnvelope.of(coordinates)
    }

    override val isEmpty: Boolean get() = coordinates.isEmpty()
}

/** Two or more linestrings decoded from a single MVT feature. */
class MvtMultiLineString(@JvmField val geometries: Array<MvtLineString>) : MvtGeometry() {

    override val numGeometries: Int get() = geometries.size

    override fun getGeometryN(n: Int): MvtGeometry = geometries[n]

    override val envelopeInternal: MvtEnvelope by lazy(LazyThreadSafetyMode.PUBLICATION) {
        MvtEnvelope.of(geometries.asList())
    }

    override val isEmpty: Boolean get() = geometries.isEmpty()
}

/** Two or more polygons decoded from a single MVT feature. */
class MvtMultiPolygon(@JvmField val geometries: Array<MvtPolygon>) : MvtGeometry() {

    override val numGeometries: Int get() = geometries.size

    override fun getGeometryN(n: Int): MvtGeometry = geometries[n]

    override val envelopeInternal: MvtEnvelope by lazy(LazyThreadSafetyMode.PUBLICATION) {
        MvtEnvelope.of(geometries.asList())
    }

    override val isEmpty: Boolean get() = geometries.isEmpty()
}

/**
 * The empty geometry.
 *
 * Stands in for `GeometryFactory.createGeometryCollection(new Geometry[0])`, which the previous
 * decoder returned for `UNKNOWN` geometry types and for features whose commands produced nothing.
 * Renderers reach this through their `when` fall-through and skip it; a shared instance avoids
 * allocating one per degenerate feature.
 */
object MvtEmptyGeometry : MvtGeometry() {
    override val envelopeInternal: MvtEnvelope get() = MvtEnvelope.NULL
    override val numGeometries: Int get() = 0
    override fun getGeometryN(n: Int): MvtGeometry = this
    override val isEmpty: Boolean get() = true
}
