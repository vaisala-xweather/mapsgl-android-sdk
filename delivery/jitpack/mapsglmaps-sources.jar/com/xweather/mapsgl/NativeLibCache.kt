package com.xweather.mapsgl
@Suppress("Dokka")
class NativeLibCache(val sourceID: String) {


    // --- Byte Array Cache ---

    /**
     * Stores a copy of the byte array in the native cache under the given key.
     * Replaces any existing data for the same key.
     * @param key The String key to store the data under.
     * @param byteArray The ByteArray data to store.
     */
    external fun putData(key: String, byteArray: ByteArray)

    /**
     * Retrieves a copy of the byte array from the native cache for the given key.
     * @param key The String key to look up.
     * @return The ByteArray data if found, otherwise null.
     */
    external fun getData(key: String): ByteArray?

    external fun getAllCachedKeys(): List<String>? // Or ArrayList<String>?


    /**
     * Checks if the native cache contains an entry for the given key.
     * @param key The String key to check.
     * @return True if the key exists in the cache, false otherwise.
     */
    external fun containsKey(key: String): Boolean

    /**
     * Removes the entry associated with the given key from the native cache.
     * Does nothing if the key is not found.
     * @param key The String key of the entry to remove.
     */
    external fun removeData(key: String)

    /**
     * Removes all entries from the native cache.
     */
    external fun clearCache()

    /**
     * Gets the current number of key-value pairs stored in the native cache.
     * @return The number of items in the cache as a Long.
     */
    external fun getCacheSize(): Long

    /**
     * Pads one `originalSize`×`originalSize` RGBA strip in native and returns the padded buffer (no global cache).
     * Radar vs non-radar rules match the former split/single native paths.
     */
    external fun padEncodedRgbaToPaddedByteArray(
        rgba: ByteArray,
        originalSize: Int,
        padding: Int,
        isRadar: Boolean,
    ): ByteArray?

    /**
     * Splits a decoded full RGBA buffer (one strip per interval, horizontal layout), pads each strip in native,
     * and returns one [ByteArray] per strip in order (no global cache).
     */
    external fun splitAndPadEncodedTilesToByteArrays(
        fullRgba: ByteArray,
        stripCount: Int,
        originalSize: Int,
        padding: Int,
        isRadar: Boolean,
    ): Array<ByteArray>?

    /**
     * Decodes PNG/JPEG/BMP/GIF (etc.) image bytes to packed RGBA using native [stb_image](https://github.com/nothings/stb).
     * Avoids `BitmapFactory` + `Bitmap.copyPixelsToBuffer` heap churn for encoded tiles.
     * Returns null if the image cannot be decoded.
     */
    external fun decodeImageBytesToRgba(imageBytes: ByteArray): ByteArray?

    // --- Namespaced, byte-budgeted LRU cache (rule: native-cache-budget) ---
    // Replaces the single unbounded map above for data namespaces where an unbounded native cache
    // risks unconstrained memory growth (MVT bytes, fill/outline/circle meshes). Each namespace is
    // independently byte-budgeted with LRU eviction and pin/unpin for the currently-needed working
    // set — see [com.xweather.mapsgl.NativeCacheBudget] for how the budgets are sized and split.

    /** Sets/replaces [namespace]'s byte budget, evicting immediately if now over it. */
    external fun configureNamespaceBudget(namespace: String, maxBytes: Long)

    external fun putNamespaced(namespace: String, key: String, byteArray: ByteArray)

    external fun getNamespaced(namespace: String, key: String): ByteArray?

    external fun containsKeyNamespaced(namespace: String, key: String): Boolean

    external fun removeNamespaced(namespace: String, key: String)

    /** Marks [key] as part of the currently-needed working set — preferred to survive eviction, but
     * not exempt from [namespace]'s byte budget if the pinned set alone exceeds it. */
    external fun pinNamespaced(namespace: String, key: String)

    external fun unpinNamespaced(namespace: String, key: String)

    /** Clears every pin in [namespace] (e.g. between playback sessions). */
    external fun unpinAllNamespaced(namespace: String)

    external fun clearNamespace(namespace: String)

    external fun getNamespaceCurrentBytes(namespace: String): Long

    external fun getNamespaceEntryCount(namespace: String): Long

    /**
     * Rule: zero-copy-gpu-upload (Phase 5). Returns a [java.nio.ByteBuffer] that directly wraps
     * this entry's memory inside the native cache — no copy, unlike [getNamespaced]'s `ByteArray`.
     * The returned buffer is only valid for reading; do not retain it past the matching
     * [releaseNamespacedDirect] call. Every non-null return MUST be paired with exactly one
     * [releaseNamespacedDirect] call for the same (namespace, key) once the caller is done reading
     * it (e.g. immediately after the GL upload call that consumes it) — until then the underlying
     * memory is guaranteed not to move or be freed, even if this entry is concurrently evicted,
     * replaced, or removed from the cache by another thread.
     */
    external fun getNamespacedDirect(namespace: String, key: String): java.nio.ByteBuffer?

    /** Releases one outstanding [getNamespacedDirect] checkout for (namespace, key). Safe to call
     * even if the entry no longer exists in the cache — see [getNamespacedDirect]'s KDoc. */
    external fun releaseNamespacedDirect(namespace: String, key: String)

    // --- Native fill triangulation (rule: native-fill-triangulation) ---

    /**
     * Triangulates a single polygon-with-holes already in tile-UV space (mirrors
     * `Earcut.earcut(flat.toDoubleArray(), holes, 2)`'s existing flat+hole-offset convention exactly
     * — [flatUv] is `[u0,v0,u1,v1,...]`, exterior ring first then holes in order, [holeIndices] are
     * VERTEX offsets (not coordinate offsets) where each hole ring starts). Runs earcut, clips every
     * output triangle to the `[0,1]` UV tile bounds, and colors every vertex with [rgba] — the exact
     * computation `VectorPolygonFillTriangulator.triangulatePolygonRaw`/`emitTriangleClipped` already
     * do in Kotlin, just off the JVM heap. Returns little-endian native-order float bytes, 6
     * floats/vertex `[u,v,r,g,b,a,featureTime]`, identical to [putFillTriangulationNative]'s existing encoding —
     * or null if the input is degenerate or triangulation produced no visible geometry.
     */
    external fun nativeTriangulateFillPolygon(
        flatUv: DoubleArray,
        holeIndices: IntArray,
        rgba: FloatArray,
    ): ByteArray?

    // --- Native outline (stroke-ribbon) triangulation (rule: native-outline-triangulation) ---

    /**
     * Triangulates one or more rings/polylines already in tile-UV space into stroke-ribbon quads —
     * mirrors `VectorPolygonFillTriangulator.emitOutlineSegment`'s exact per-segment 6-vertex quad
     * (no joins/miters/caps, matching the existing Kotlin behavior byte-for-byte) off the JVM heap.
     * [ringCoordsFlat] is `[u0,v0,u1,v1,...]` for every ring/line concatenated in order; [ringLengths]
     * is each ring/line's point count (not byte/coordinate count). [closed] is `true` for a polygon's
     * rings (exterior AND holes both get outlined and each ring wraps its own last point back to its
     * first — no cross-ring wrapping), `false` for an open polyline/multi-line (no wraparound
     * segment). [rgba] is resolved once per feature and baked into every emitted vertex via the same
     * bit-packing [VectorPolygonFillTriangulator.packColorFloat] uses. Returns little-endian
     * native-order float bytes, 8 floats/vertex `[cx,cy,nx,ny,packed_rgba,edge_dist,half_width_uv,featureTime]`,
     * identical to [putOutlineTriangulationNative]'s existing encoding — or null if every ring was
     * degenerate (fewer than 2 points, or all segments zero-length).
     */
    external fun nativeTriangulateOutlineRings(
        ringCoordsFlat: DoubleArray,
        ringLengths: IntArray,
        closed: Boolean,
        rgba: FloatArray,
        halfWidthUv: Float,
    ): ByteArray?

    // --- Test/Simple Integer Cache ---

    /**
     * Stores a single integer value in the native cache (for testing).
     * @param input The Int value to store.
     */
    external fun putInt(input: Int) // Keep only this one

    /**
     * Retrieves the single integer value stored in the native cache (for testing).
     * @return The stored Int value.
     */
    external fun getInt(): Int

    // --- Companion Object for Loading ---
    companion object {
        // Used to load the 'nativelib' library on application startup.
        init {
            try {
                System.loadLibrary("nativelib") // Use your actual library name here
            } catch (e: UnsatisfiedLinkError) {
                // Log error or handle cases where native lib might not be available
                // (e.g., running on an unsupported ABI)
                System.err.println("Failed to load native library 'nativelib': ${e.message}")
                // Consider throwing an exception or setting a flag
            }
        }
    }
}