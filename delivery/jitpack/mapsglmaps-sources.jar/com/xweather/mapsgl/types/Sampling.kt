package com.xweather.mapsgl.types

import com.xweather.mapsgl.style.ColorScaleOptions

// An interface that defines the set of properties required for sampling encoded data.
interface EncodedSampling {
    /** Determines how data should be sampled from the encoded data texture. **/
    var expression: SampleExpression
    /** Color band(s) to sample from the encoded data. If performing an expression operation, such as `.vector`, `.sum` or `.diff`, then two bands must be provided. **/
    var channel: List<ColorBand>
    /** Needed for Swift-style EncodedDataRenderer **/
//    var channel: SampleChannel
    /** Controls the data resolution that gets requested by the layer's data source and rendered to the map. Data will be interpolated when rendering to the map to ensure low resolution/quality data is still smooth. **/
    var quality: DataQuality
    /** Type of interpolation to perform on the data. **/
    var interpolation: InterpolationMode
    /** Amount of smoothing to apply on the data from `0` (no smoothing) to `1` (full smoothing). Increasing this value is useful for low resolution data sets or when higher detail is not desired or needed. **/
    var smoothing: Float
    /** Normalized amount to shift the interpolated sample values from `0` to `1`. This is typically used for expression operations like diff where interpolated values can be negative and you need to start values half way (`0.5`) between the `colorscale.range`. **/
    var offset: Float
    /** Limits the data range that should be rendered from the sampled data. If not provided, then the full data range provided by the associated data source will be rendered by default. **/
    var drawRange: ClosedRange<Double>?
}

// An interface that defines the properties required for mapping color values to encoded data.
interface ColorSampling : EncodedSampling {
    /** Color scale configuration to use when rendering encoded data.  **/
    var colorScale: ColorScaleOptions
}
