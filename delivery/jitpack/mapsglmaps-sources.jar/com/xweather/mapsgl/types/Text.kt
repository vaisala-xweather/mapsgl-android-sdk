package com.xweather.mapsgl.types

enum class TextJustification(val value: String) {
    LEFT("left"),
    CENTER("center"),
    RIGHT("right")
}

enum class TextTransform(val value: String) {
    NONE("none"),
    UPPERCASE("uppercase"),
    LOWERCASE("lowercase")
}