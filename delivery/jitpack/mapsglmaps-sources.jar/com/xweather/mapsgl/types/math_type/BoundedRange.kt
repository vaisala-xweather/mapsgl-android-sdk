package com.xweather.mapsgl.types.math_type

/**
 * A range with either end left open, for the places where "no bound" and "this bound" are different
 * answers.
 *
 * [com.xweather.mapsgl.style.SamplePaint.drawRange] is the motivating case. MapsGL JS writes
 * `drawRange: { max: 2.22 }` and means "clip nothing at the bottom"; a `ClosedRange<Double>` cannot
 * say that, so the caller has to invent a floor and hope it sits below whatever the layer reports.
 * The Apple SDK solves it with an `InclusiveBoundedRange` protocol whose two bounds are both
 * optional; this is the same idea in the form Kotlin allows.
 *
 * It **is** a `ClosedRange<Double>`, so it can be assigned anywhere one is expected and nothing
 * that already reads [start] / [endInclusive] has to change - an absent bound reads as infinite
 * there, which is the correct answer for a comparison. Code that cares which bounds were actually
 * given asks [lowerBoundIfAvailable] / [upperBoundIfAvailable] instead, and substitutes the layer's
 * own data range for the ones that were not.
 *
 * ```kotlin
 * paint.sample.drawRange = BoundedRange.atMost(2.22)   // JS: drawRange = { max: 2.22 }
 * paint.sample.drawRange = BoundedRange.atLeast(0.0)   // JS: drawRange = { min: 0 }
 * paint.sample.drawRange = -2.22..2.22                 // both ends, as before
 * ```
 */
class BoundedRange private constructor(
    /** The lower bound, or `null` when this range does not constrain the bottom. */
    val lowerBoundIfAvailable: Double?,
    /** The upper bound, or `null` when this range does not constrain the top. */
    val upperBoundIfAvailable: Double?,
) : ClosedRange<Double> {

    override val start: Double
        get() = lowerBoundIfAvailable ?: Double.NEGATIVE_INFINITY

    override val endInclusive: Double
        get() = upperBoundIfAvailable ?: Double.POSITIVE_INFINITY

    override fun toString(): String =
        "${lowerBoundIfAvailable?.toString() ?: ""}..${upperBoundIfAvailable?.toString() ?: ""}"

    override fun equals(other: Any?): Boolean =
        other is BoundedRange &&
            other.lowerBoundIfAvailable == lowerBoundIfAvailable &&
            other.upperBoundIfAvailable == upperBoundIfAvailable

    override fun hashCode(): Int =
        31 * (lowerBoundIfAvailable?.hashCode() ?: 0) + (upperBoundIfAvailable?.hashCode() ?: 0)

    companion object {
        /** Constrains the top only: values above [max] are out of range, nothing is clipped below. */
        fun atMost(max: Double) = BoundedRange(null, max)

        /** Constrains the bottom only: values below [min] are out of range, nothing is clipped above. */
        fun atLeast(min: Double) = BoundedRange(min, null)

        /** Constrains both ends, the same as `min..max`. */
        fun of(min: Double, max: Double) = BoundedRange(min, max)

        /** Constrains both ends from an existing range. */
        fun of(range: ClosedRange<Double>) = BoundedRange(range.start, range.endInclusive)
    }
}

/**
 * Fills in whichever ends of [drawRange] were left open from [dataRange], matching the MapsGL JS
 * `drawRange = { ...dataRange, ...paint.drawRange }` merge and the Apple SDK's
 * `drawRange?.lowerBoundIfAvailable ?? context.dataRange.lowerBound`.
 *
 * Returns `null` for a null [drawRange], because "no draw range" and "a draw range covering the
 * data" are different instructions: the first disables clipping outright.
 *
 * A plain `ClosedRange` is returned as it is, so nothing that already passes one changes behaviour.
 * The exception is a non-finite bound - `Double.NEGATIVE_INFINITY..2.22` is a legal `ClosedRange`
 * and expresses the same intent as [BoundedRange.atMost], so it is treated the same rather than
 * handed to a float uniform as an infinity.
 */
internal fun resolveDrawRange(
    drawRange: ClosedRange<Double>?,
    dataRange: ClosedRange<Double>,
): ClosedRange<Double>? {
    if (drawRange == null) return null

    // Returned as-is, the same object and not merely an equal one, whenever there is nothing to
    // substitute. Every range an existing app can express lands here - BoundedRange is new, and a
    // non-finite bound in a hand-written ClosedRange was never meaningful - so no caller written
    // against an earlier version of this SDK can be routed down a different path than before.
    if (drawRange !is BoundedRange && drawRange.start.isFinite() && drawRange.endInclusive.isFinite()) {
        return drawRange
    }

    val declaredLower = (drawRange as? BoundedRange)?.lowerBoundIfAvailable ?: drawRange.start
    val declaredUpper = (drawRange as? BoundedRange)?.upperBoundIfAvailable ?: drawRange.endInclusive

    val lower = if (declaredLower.isFinite()) declaredLower else dataRange.start
    val upper = if (declaredUpper.isFinite()) declaredUpper else dataRange.endInclusive
    return lower..upper
}
