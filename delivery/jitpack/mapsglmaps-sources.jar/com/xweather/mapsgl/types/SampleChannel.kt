package com.xweather.mapsgl.types

/**
 *  SampleChannel.kt
 *
 *
 *  @author Jason Suto 03/07/24
 */

enum class ColorBand(val rawValue: Int) {
    red(0),
    green(1),
    blue(2),
    alpha(3);

    companion object {
        fun fromRawValue(value: Int): ColorBand? {
            return entries.find { it.rawValue == value }
        }
    }
}

class SampleChannel(var rawValue: Int) {
    companion object {
        val red = SampleChannel(1 shl ColorBand.red.rawValue)
        val green = SampleChannel(1 shl ColorBand.green.rawValue)
        val blue = SampleChannel(1 shl ColorBand.blue.rawValue)
        val alpha = SampleChannel(1 shl ColorBand.alpha.rawValue)
    }

    constructor(colorBand: ColorBand) : this(1 shl colorBand.rawValue)

    val colorBands: List<ColorBand>
        get() {
            val bands = ArrayList<ColorBand>()
            if (contains(red)) bands.add(ColorBand.red)
            if (contains(green)) bands.add(ColorBand.green)
            if (contains(blue)) bands.add(ColorBand.blue)
            if (contains(alpha)) bands.add(ColorBand.alpha)
            return bands
        }

    private fun contains(channel: SampleChannel): Boolean {
        return (rawValue and channel.rawValue) != 0
    }
}