package com.xweather.mapsgl.types

/**
 * How encoded samples are interpolated across neighboring texels in [SamplePaint].
 */
enum class InterpolationMode {
    /** Nearest sample; no filtering. */
    NONE,
    /** Linear in 2D. */
    BILINEAR,
    /** Cubic in 2D (default for sample layers). */
    BICUBIC,
    /** Quadratic in 2D. */
    BIQUADRATIC
}