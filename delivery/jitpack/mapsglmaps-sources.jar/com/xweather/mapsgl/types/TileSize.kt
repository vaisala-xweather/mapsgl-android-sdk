package com.xweather.mapsgl.types

/**
 * Logical tile dimensions in pixels (typically 256 or 512).
 *
 * @property width Tile width in px; must be ≥ 0.
 * @property height Tile height in px; must be ≥ 0.
 */
data class TileSize(var width: Int, var height: Int) {
    init {
        require(width >= 0)
        require(height >= 0)
    }
}

/** Square [TileSize] with [size] × [size] pixels. */
fun TileSize(size: Int): TileSize {
    return TileSize(size,size)
}