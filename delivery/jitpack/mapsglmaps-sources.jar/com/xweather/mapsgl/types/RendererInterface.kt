package com.xweather.mapsgl.types

import com.xweather.mapsgl.Partial
import com.xweather.mapsgl.style.PaintStyleSpec

interface RendererSpecification {
    var paint: Partial<PaintStyleSpec>
}


