package com.xweather.mapsgl.types

/**
 * How a [SamplePaint] derives a scalar or vector from encoded raster bands.
 */
enum class SampleExpression {
    /** Value is a float sampled from a single band. **/
    NUMBER,
    /** Value is a vector sampled and calculated from two bands. **/
    VECTOR,
    /** Value is a float sampled and calculated as the sum of two bands. **/
    SUM,
    /** Value is a float sampled and calculated as the difference of two bands.**/
    DIFFERENCE,
    /** Value is a float sampled and calculated from the vector of two bands. **/
    ANGLE,
    /**
     * Direction (degrees) from encoded **green/blue** as wind-style u/v: each byte maps linearly to
     * `[-53.64, 53.64]` m/s span (`107.28` total), then `dir = atan2(u, -v)` in degrees — matches gridded
     * arrow sampling in [com.xweather.mapsgl.sources.EncodedGridVectorTileSource].
     */
    ENCODED_WIND_UV,
    /** Value is calculated using a custom shader chunk based on the encoded data. **/
    CUSTOM,
    NO_DATA
}
