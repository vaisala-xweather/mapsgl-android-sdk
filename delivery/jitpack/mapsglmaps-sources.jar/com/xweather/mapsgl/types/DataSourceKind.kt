package com.xweather.mapsgl.types

/**
 * Kind of data a [com.xweather.mapsgl.sources.source.spec.SourceDescriptor] provides.
 */
enum class DataSourceKind {
    RASTER,
    VECTOR,
    GEOJSON,
    ENCODED,
    AERIS_ENCODED,
    AERIS_VECTOR
}

@Deprecated("Use `DataSourceKind` instead.", ReplaceWith("DataSourceKind"))
typealias DataSourceType = DataSourceKind


