package com.xweather.mapsgl.types

/**
 *  DataSourceType.kt
 *
 *  Adapted from IOS version.
 *  @author Jason Suto on 01/08/24.
 */

enum class DataSourceKind {
    RASTER,
    VECTOR,
    GEOJSON,
    ENCODED,
    AERIS_ENCODED,
    AERIS_VECTOR
}

@Deprecated("Use `DataSourceKind` instead.", ReplaceWith("DataSourceKind"))
typealias DataSourceType = DataSourceKind


