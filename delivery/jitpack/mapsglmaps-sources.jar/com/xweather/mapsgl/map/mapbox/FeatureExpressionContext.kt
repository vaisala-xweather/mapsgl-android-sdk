package com.xweather.mapsgl.map.mapbox

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.ExpressionContext

/**
 * A feature's properties as the plain map [com.xweather.mapsgl.style.ExpressionEvaluator] reads,
 * without copying anything.
 *
 * Conversion is per key and on demand: a style usually touches one or two properties of a feature,
 * and eagerly walking every property tree of every feature in a tile would cost far more than the
 * expressions themselves. Nested objects come back wrapped the same way, so a dotted path walks the
 * original JSON.
 *
 * Numbers arrive as [Double] because that is what JS has, and mixing `Int` and `Double` would make
 * `["==", ["get", "priority"], 3]` depend on how the tile happened to encode the 3.
 */
internal class FeaturePropertyMap(private val json: JsonObject?) : AbstractMap<String, Any?>() {

    override val entries: Set<Map.Entry<String, Any?>>
        get() {
            val obj = json ?: return emptySet()
            // Only the `properties` operator needs the whole bag, so this stays off the hot path.
            return obj.keySet().mapTo(LinkedHashSet()) { key ->
                java.util.AbstractMap.SimpleImmutableEntry(key, convert(obj.get(key)))
            }
        }

    override fun containsKey(key: String): Boolean = json?.has(key) == true

    override fun get(key: String): Any? = json?.get(key)?.let { convert(it) }

    private fun convert(element: JsonElement?): Any? = when {
        element == null || element.isJsonNull -> null
        element.isJsonObject -> FeaturePropertyMap(element.asJsonObject)
        element.isJsonArray -> element.asJsonArray.map { convert(it) }
        element.isJsonPrimitive -> {
            val primitive = element.asJsonPrimitive
            when {
                primitive.isBoolean -> primitive.asBoolean
                primitive.isNumber -> primitive.asDouble
                else -> primitive.asString
            }
        }
        else -> null
    }
}

/**
 * Builds the evaluation context for [feature], with the timeline playhead wired to the same instant
 * the draw filters use, in Unix seconds.
 */
internal fun expressionContextFor(feature: Feature, zoom: Double? = null): ExpressionContext =
    ExpressionContext(
        properties = FeaturePropertyMap(feature.properties()),
        zoom = zoom,
        mapTimeSeconds = VectorDrawTime.currentMapTimeSeconds().toDouble(),
    )
