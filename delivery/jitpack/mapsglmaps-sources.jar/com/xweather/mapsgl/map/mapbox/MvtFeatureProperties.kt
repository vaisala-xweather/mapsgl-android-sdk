package com.xweather.mapsgl.map.mapbox

import com.google.gson.JsonElement
import com.mapbox.geojson.Feature

/**
 * Reads string-ish MVT properties after [Feature.getStringProperty], which can miss values depending
 * on how Gson built the GeoJSON properties object (see [GlStencilMaskTileCache] / stencil layer tag).
 */
internal fun mvtFeatureStringProperty(feature: Feature, key: String): String? {
    feature.getStringProperty(key)?.takeIf { it.isNotBlank() }?.let { return it }
    val p = feature.properties() ?: return null
    if (!p.has(key)) return null
    val e = p.get(key) ?: return null
    return gsonJsonPrimitiveToPlainString(e)
}

private fun gsonJsonPrimitiveToPlainString(e: JsonElement): String? =
    when {
        e.isJsonNull -> null
        e.isJsonPrimitive -> {
            val prim = e.asJsonPrimitive
            when {
                prim.isString -> prim.asString
                prim.isNumber -> prim.asNumber.toString()
                prim.isBoolean -> prim.asBoolean.toString()
                else -> prim.asString
            }
        }
        else -> null
    }
