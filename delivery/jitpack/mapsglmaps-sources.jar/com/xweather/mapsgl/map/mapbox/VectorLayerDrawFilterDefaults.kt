package com.xweather.mapsgl.map.mapbox

import com.xweather.mapsgl.style.Expression

/**
 * Built-in draw-filter overrides keyed by style layer id (matches JS weather configs).
 * Auto-generated [com.xweather.mapsgl.weather.groups.Tropical] omits `mapTime` filters; this fills
 * in `timestamp <= map-time` scrubbing for track lines and track-point icons so they reveal in
 * sync with the track geometry during playback.
 *
 * Current storm **position** markers, position icons, and **name** labels are **not** scrubbed —
 * matching JS tropical configs (`positionFilter` without `map-time`) / iOS
 * [com.xweather.mapsgl.weather.ignoresMapTimeFilter] for live markers so they stay visible for the
 * whole timeline.
 */
internal object VectorLayerDrawFilterDefaults {

    private val scrubbedFeatureTypes = setOf("trackPoint", "trackLine")

    private val mapTimeLteTimestamp =
        Expression.lessThanOrEqual(listOf("get", "timestamp"), listOf("map-time"))

    fun effectiveFilter(layerId: String?, baseFilter: Expression?): Expression? {
        if (layerId == null || !usesTimestampScrub(layerId, baseFilter)) return baseFilter
        if (VectorDrawTime.filterReferencesMapTime(baseFilter)) return baseFilter
        val static = baseFilter ?: return null
        return Expression.and(
            listOf(
                flattenExpression(static.raw),
                flattenExpression(mapTimeLteTimestamp.raw),
            ),
        )
    }

    fun referencesMapTime(layerId: String?, baseFilter: Expression?): Boolean {
        if (VectorDrawTime.filterReferencesMapTime(baseFilter)) return true
        if (layerId == null) return false
        return usesTimestampScrub(layerId, baseFilter)
    }

    private fun usesTimestampScrub(layerId: String, baseFilter: Expression?): Boolean {
        layerIdToScrubFeatureType(layerId)?.let { return it in scrubbedFeatureTypes }
        val featureType = extractFeatureTypeEquals(baseFilter) ?: return false
        // Live positions and name labels share featureType "position" but must not scrub.
        if (featureType == "position") return false
        return featureType in scrubbedFeatureTypes
    }

    private fun layerIdToScrubFeatureType(layerId: String): String? = when {
        layerId.contains("track") && layerId.endsWith(".line") -> "trackLine"
        layerId.contains("track") && (layerId.endsWith(".circle") || layerId.endsWith(".symbol")) -> "trackPoint"
        else -> null
    }

    @Suppress("UNCHECKED_CAST")
    private fun extractFeatureTypeEquals(filter: Expression?): String? {
        if (filter == null) return null
        val raw = flattenExpression(filter.raw)
        if (raw is List<*>) {
            if (raw.size >= 3 && raw[0] == "==" && raw[1] is List<*>) {
                val get = raw[1] as List<*>
                if (get.size >= 2 && get[0] == "get" && get[1] == "featureType" && raw[2] is String) {
                    return raw[2] as String
                }
            }
            if (raw.isNotEmpty() && raw[0] == "all") {
                for (i in 1 until raw.size) {
                    extractFeatureTypeEquals(Expression(raw[i]!!))?.let { return it }
                }
            }
        }
        return null
    }

    private fun flattenExpression(node: Any): Any = ExpressionFilterFlatten.flattenNode(node)!!
}
