package com.xweather.mapsgl.map.mapbox

import com.google.gson.JsonElement
import com.google.gson.JsonObject
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.Expression

/**
 * Minimal Mapbox-style filter evaluation for GLES vector feature selection.
 * Supports comparison, logical, `get`, `has`, `literal`, `in`, `match`, `let`/`var`,
 * `length`/`at`/`slice`/`join`, and timeline `mapTime`/`time`/`now`.
 */
internal object StencilMaskFilter {

    fun matches(feature: Feature, filter: Expression?): Boolean =
        matches(feature, filter, VectorDrawTime.currentMapTimeMillis())

    fun matches(feature: Feature, filter: Expression?, mapTimeMs: Long): Boolean {
        if (filter == null) return true
        val raw = ExpressionFilterFlatten.flattenNode(filter.raw) ?: return true
        return eval(raw, feature, mapTimeMs) == true
    }

    @Suppress("UNCHECKED_CAST")
    private fun eval(node: Any?, f: Feature, mapTimeMs: Long): Boolean? {
        when (node) {
            is Expression -> return eval(node.raw, f, mapTimeMs)
            is Boolean -> return node
            is List<*> -> {
                val list = node as List<Any?>
                if (list.isEmpty()) return null
                val op = list[0] as? String ?: return null
                // Rule: eval-op-when-must-return. This `when` computes the op's result as an
                // expression; without `return` here, everything except the branches with their own
                // inline `return` (all/any/!) had their result silently discarded, falling through to
                // `return null` below. That made every comparison op (==, !=, <, <=, >, >=, in) always
                // evaluate as unresolved, so e.g. `["==", ["get","featureType"], "position"]` always
                // failed regardless of the actual feature data.
                return when (op) {
                    "==" -> compareEq(list, f, mapTimeMs)
                    "!=" -> compareEq(list, f, mapTimeMs)?.let { !it }
                    "all" -> {
                        for (i in 1 until list.size) {
                            if (eval(list[i], f, mapTimeMs) != true) return false
                        }
                        true
                    }
                    "any" -> {
                        for (i in 1 until list.size) {
                            if (eval(list[i], f, mapTimeMs) == true) return true
                        }
                        false
                    }
                    "!" -> {
                        if (list.size < 2) return null
                        val inner = eval(list[1], f, mapTimeMs) ?: return null
                        !inner
                    }
                    "<", "lt" -> compareNumbers(list, f, mapTimeMs) { a, b -> a < b }
                    "<=", "lte" -> compareNumbers(list, f, mapTimeMs) { a, b -> a <= b }
                    ">", "gt" -> compareNumbers(list, f, mapTimeMs) { a, b -> a > b }
                    ">=", "gte" -> compareNumbers(list, f, mapTimeMs) { a, b -> a >= b }
                    "in" -> evalIn(list, f, mapTimeMs)
                    "match" -> evalMatch(list, f, mapTimeMs)
                    "has" -> evalHas(list, f, mapTimeMs)
                    "let" -> evalLet(list, f, mapTimeMs)
                    else -> null
                }
            }
        }
        return null
    }

    private fun compareEq(list: List<*>, f: Feature, mapTimeMs: Long): Boolean? {
        if (list.size < 3) return null
        val a = resolveCompareOperand(list[1], f, mapTimeMs, allowPropertyKey = true) ?: return false
        val b = resolveCompareOperand(list[2], f, mapTimeMs, allowPropertyKey = false) ?: return false
        return valuesEqual(a, b)
    }

    /** Mapbox shorthand: `["==", "featureType", "trackLine"]` is equivalent to `["==", ["get", "featureType"], "trackLine"]`. */
    private fun resolveCompareOperand(
        node: Any?,
        f: Feature,
        mapTimeMs: Long,
        allowPropertyKey: Boolean,
    ): Any? {
        if (allowPropertyKey && node is String && !node.startsWith("$")) {
            return featurePropertyAny(f, node)
        }
        return evalValue(node, f, mapTimeMs)
    }

    private fun compareNumbers(
        list: List<*>,
        f: Feature,
        mapTimeMs: Long,
        cmp: (Double, Double) -> Boolean,
    ): Boolean? {
        if (list.size < 3) return null
        val leftNode = list[1]
        val a = evalValueAsNumber(leftNode, f, mapTimeMs)
        val rightNode = list[2]
        val b = evalValueAsNumber(rightNode, f, mapTimeMs) ?: return null
        if (a == null) {
            // Missing timestamp: treat as earliest point so scrub reveals track progressively.
            if (isTimestampGet(leftNode)) return cmp(0.0, b)
            return null
        }
        return cmp(a, b)
    }

    /**
     * `["has", key]` or nested `["has", leaf, parentExpr]` from [Expression.has] / [Expression.hasPath].
     * Previously fell through to `else -> null`, so a `has` filter hid every feature.
     */
    private fun evalHas(list: List<*>, f: Feature, mapTimeMs: Long): Boolean? {
        if (list.size < 2) return null
        val key = list[1] as? String ?: return null
        if (list.size == 2) {
            val root = f.properties() ?: return false
            if (root.has(key) && !root.get(key).isJsonNull) return true
            if (key.contains('.')) {
                val el = getNestedJsonElement(root, key.split('.'))
                return el != null && !el.isJsonNull
            }
            return false
        }
        val parent = list[2]
        val parentPath = dottedGetPath(parent)
        if (parentPath != null) {
            val el = readPropertyJson(f, "$parentPath.$key")
            return el != null && !el.isJsonNull
        }
        val parentVal = evalValue(parent, f, mapTimeMs)
        if (parentVal is JsonObject) {
            return parentVal.has(key) && !parentVal.get(key).isJsonNull
        }
        return false
    }

    private fun evalIn(list: List<*>, f: Feature, mapTimeMs: Long): Boolean? {
        if (list.size < 3) return null
        val input = evalValue(list[1], f, mapTimeMs) ?: return false
        val candidates = mutableListOf<Any?>()
        val third = list[2]
        if (third is List<*> && third.isNotEmpty() && third[0] == "literal") {
            val literal = third.getOrNull(1)
            if (literal is List<*>) {
                candidates.addAll(literal)
            } else {
                candidates.add(literal)
            }
        } else {
            for (i in 2 until list.size) {
                candidates.add(evalValue(list[i], f, mapTimeMs))
            }
        }
        return candidates.any { valuesEqual(it, input) }
    }

    /**
     * Rule: match-op-support. `Expression.contains(...)` compiles to
     * `["match", input, label1, true, label2, true, ..., false]` (see Expression.kt's `contains`)
     * rather than `["in", ...]`, since `match` is more universally supported by the Mapbox GL
     * native engine. Without this case, `eval`'s `when(op)` fell to `else -> null` for every
     * `match` filter (e.g. tropical cyclone forecast-error-cone polygons filtered by
     * `Expression.contains(Expression.geometryType, listOf("Polygon", "MultiPolygon"))`),
     * rejecting every feature regardless of geometry type.
     */
    private fun evalMatch(list: List<*>, f: Feature, mapTimeMs: Long): Boolean? {
        if (list.size < 3) return null
        val input = evalValue(list[1], f, mapTimeMs)
        var i = 2
        while (i < list.size - 1) {
            val label = list[i]
            val isMatch = if (label is List<*>) {
                label.any { valuesEqual(it, input) }
            } else {
                valuesEqual(label, input)
            }
            if (isMatch) return evalValue(list[i + 1], f, mapTimeMs) as? Boolean
            i += 2
        }
        return evalValue(list.getOrNull(list.size - 1), f, mapTimeMs) as? Boolean
    }

    @Suppress("UNCHECKED_CAST")
    private fun evalValue(node: Any?, f: Feature, mapTimeMs: Long): Any? {
        when (node) {
            is Expression -> return evalValue(node.raw, f, mapTimeMs)
            is String, is Number, is Boolean -> return node
            is List<*> -> {
                val list = node as List<Any?>
                if (list.isEmpty()) return null
                when (list[0] as? String) {
                    "get" -> {
                        val key = list.getOrNull(1) as? String ?: return null
                        // Nested getPath form: ["get", leaf, parentExpr] — resolve parent then leaf,
                        // or rebuild a dotted path when parent is also a get chain.
                        val parent = list.getOrNull(2)
                        if (parent != null) {
                            val parentPath = dottedGetPath(parent)
                            if (parentPath != null) {
                                return featurePropertyAny(f, "$parentPath.$key")
                            }
                            val parentVal = evalValue(parent, f, mapTimeMs)
                            if (parentVal is JsonObject) {
                                val el = parentVal.get(key) ?: return null
                                if (!el.isJsonPrimitive) return null
                                val p = el.asJsonPrimitive
                                return when {
                                    p.isString -> p.asString
                                    p.isNumber -> normalizeEpochProperty(key, p.asDouble)
                                    p.isBoolean -> p.asBoolean
                                    else -> null
                                }
                            }
                            return null
                        }
                        return featurePropertyAny(f, key)
                    }
                    "literal" -> return list.getOrNull(1)
                    "mapTime", "map-time", "time", "timeline" -> return mapTimeMs / 1000.0
                    "now" -> return System.currentTimeMillis()
                    "geometry-type" -> return f.geometry()?.type()
                    "coalesce" -> {
                        for (i in 1 until list.size) {
                            val v = evalValue(list[i], f, mapTimeMs)
                            if (v != null) return v
                        }
                        return null
                    }
                    "var" -> {
                        val name = list.getOrNull(1) as? String ?: return null
                        return ExpressionLetScope.lookup(name)
                    }
                    "let" -> return evalLetValue(list, f, mapTimeMs)
                    "length" -> return evalLength(list, f, mapTimeMs)
                    "at" -> return evalAt(list, f, mapTimeMs)
                    "slice" -> return evalSlice(list, f, mapTimeMs)
                    "join" -> return evalJoin(list, f, mapTimeMs)
                }
            }
        }
        return null
    }

    private fun evalLet(list: List<*>, f: Feature, mapTimeMs: Long): Boolean? {
        if (list.size < 4) return null
        val bindings = LinkedHashMap<String, Any?>()
        return ExpressionLetScope.withScope(bindings) {
            var i = 1
            while (i + 1 < list.size - 1) {
                val name = list[i] as? String ?: return@withScope null
                bindings[name] = evalValue(list[i + 1], f, mapTimeMs)
                i += 2
            }
            eval(list.last(), f, mapTimeMs)
        }
    }

    private fun evalLetValue(list: List<*>, f: Feature, mapTimeMs: Long): Any? {
        if (list.size < 4) return null
        val bindings = LinkedHashMap<String, Any?>()
        return ExpressionLetScope.withScope(bindings) {
            var i = 1
            while (i + 1 < list.size - 1) {
                val name = list[i] as? String ?: return@withScope null
                bindings[name] = evalValue(list[i + 1], f, mapTimeMs)
                i += 2
            }
            evalValue(list.last(), f, mapTimeMs)
        }
    }

    private fun evalLength(list: List<*>, f: Feature, mapTimeMs: Long): Int? {
        val inner = list.getOrNull(1) ?: return null
        when (val v = evalValue(inner, f, mapTimeMs)) {
            is String -> return v.length
            is List<*> -> return v.size
        }
        return evalArray(inner, f, mapTimeMs)?.size
    }

    private fun evalAt(list: List<*>, f: Feature, mapTimeMs: Long): Any? {
        if (list.size < 3) return null
        val index = evalValueAsNumber(list[1], f, mapTimeMs)?.toInt() ?: return null
        if (index < 0) return null
        val arr = evalArray(list[2], f, mapTimeMs) ?: return null
        if (index >= arr.size) return null
        return arr[index]
    }

    private fun evalSlice(list: List<*>, f: Feature, mapTimeMs: Long): Any? {
        val arr = evalArray(list.getOrNull(1), f, mapTimeMs)
        if (arr != null) {
            val begin = evalValueAsNumber(list.getOrNull(2), f, mapTimeMs)?.toInt() ?: return null
            val end = if (list.size >= 4) {
                evalValueAsNumber(list[3], f, mapTimeMs)?.toInt() ?: return null
            } else {
                arr.size
            }
            val from = sliceIndex(begin, arr.size)
            val to = sliceIndex(end, arr.size).coerceAtLeast(from)
            return arr.subList(from, to.coerceAtMost(arr.size))
        }
        val s = evalValue(list.getOrNull(1), f, mapTimeMs) as? String ?: return null
        val begin = evalValueAsNumber(list.getOrNull(2), f, mapTimeMs)?.toInt() ?: return null
        val end = if (list.size >= 4) {
            evalValueAsNumber(list[3], f, mapTimeMs)?.toInt() ?: return null
        } else {
            s.length
        }
        val from = sliceIndex(begin, s.length)
        val to = sliceIndex(end, s.length).coerceAtLeast(from)
        if (from > s.length) return ""
        return s.substring(from, to.coerceAtMost(s.length))
    }

    private fun evalJoin(list: List<*>, f: Feature, mapTimeMs: Long): String? {
        if (list.size < 3) return null
        val asMapboxArray = evalArray(list[1], f, mapTimeMs)
        if (asMapboxArray != null && list.size == 3) {
            val sep = evalValue(list[2], f, mapTimeMs)?.toString() ?: return null
            val sb = StringBuilder()
            for (i in asMapboxArray.indices) {
                if (i > 0) sb.append(sep)
                sb.append(asMapboxArray[i]?.toString() ?: return null)
            }
            return sb.toString()
        }
        val sep = evalValue(list[1], f, mapTimeMs)?.toString() ?: return null
        val sb = StringBuilder()
        for (i in 2 until list.size) {
            if (i > 2) sb.append(sep)
            sb.append(evalValue(list[i], f, mapTimeMs)?.toString() ?: return null)
        }
        return sb.toString()
    }

    private fun sliceIndex(index: Int, size: Int): Int {
        if (index < 0) return (size + index).coerceAtLeast(0)
        return index.coerceAtMost(size)
    }

    private fun evalArray(node: Any?, f: Feature, mapTimeMs: Long): List<Any?>? {
        val raw = when (node) {
            is Expression -> node.raw
            else -> node
        }
        when (raw) {
            is List<*> -> {
                if (raw.isEmpty()) return null
                when (raw[0] as? String) {
                    "literal" -> {
                        val v = raw.getOrNull(1)
                        @Suppress("UNCHECKED_CAST")
                        return v as? List<*>
                    }
                    "get" -> {
                        val key = raw.getOrNull(1) as? String ?: return null
                        val parent = raw.getOrNull(2)
                        val path = if (parent != null) {
                            val parentPath = dottedGetPath(parent) ?: return null
                            "$parentPath.$key"
                        } else {
                            key
                        }
                        val el = readPropertyJson(f, path) ?: return null
                        if (!el.isJsonArray) return null
                        return jsonArrayToList(el.asJsonArray)
                    }
                    "var" -> {
                        val name = raw.getOrNull(1) as? String ?: return null
                        return when (val v = ExpressionLetScope.lookup(name)) {
                            is List<*> -> v
                            is com.google.gson.JsonArray -> jsonArrayToList(v)
                            else -> null
                        }
                    }
                    "slice" -> {
                        val v = evalSlice(raw, f, mapTimeMs)
                        @Suppress("UNCHECKED_CAST")
                        return v as? List<*>
                    }
                    "at" -> {
                        val item = evalAt(raw, f, mapTimeMs)
                        return item as? List<*>
                    }
                    else -> return null
                }
            }
            is com.google.gson.JsonArray -> return jsonArrayToList(raw)
            else -> return null
        }
    }

    private fun jsonArrayToList(arr: com.google.gson.JsonArray): List<Any?> {
        val out = ArrayList<Any?>(arr.size())
        for (el in arr) {
            out.add(
                when {
                    el.isJsonNull -> null
                    el.isJsonPrimitive -> {
                        val p = el.asJsonPrimitive
                        when {
                            p.isNumber -> p.asDouble
                            p.isString -> p.asString
                            p.isBoolean -> p.asBoolean
                            else -> null
                        }
                    }
                    el.isJsonArray -> jsonArrayToList(el.asJsonArray)
                    else -> el
                },
            )
        }
        return out
    }

    private fun evalValueAsNumber(node: Any?, f: Feature, mapTimeMs: Long): Double? {
        val value = evalValue(node, f, mapTimeMs) ?: return null
        val n = when (value) {
            is Number -> value.toDouble()
            is String -> value.toDoubleOrNull()
            else -> null
        } ?: return null
        return normalizeEpochSeconds(n, isTimestampGet(node))
    }

    private fun normalizeEpochSeconds(value: Double, isTimestamp: Boolean): Double {
        if (!isTimestamp) return value
        if (value > 1e11) return value / 1000.0
        return value
    }

    private fun isTimestampGet(node: Any?): Boolean {
        val raw = when (node) {
            is Expression -> node.raw
            else -> node
        }
        val list = raw as? List<*> ?: return false
        if (list.size < 2 || list[0] != "get") return false
        val key = list[1] as? String ?: return false
        return isEpochTimestampPropertyKey(key)
    }

    private fun featurePropertyAny(f: Feature, key: String): Any? {
        f.getStringProperty(key)?.let { return it }
        f.getNumberProperty(key)?.let { return normalizeEpochProperty(key, it.toDouble()) }
        f.getBooleanProperty(key)?.let { return it }
        val el = readPropertyJson(f, key) ?: return null
        if (el.isJsonNull) return null
        if (!el.isJsonPrimitive) return null
        val p = el.asJsonPrimitive
        return when {
            p.isString -> p.asString
            p.isNumber -> normalizeEpochProperty(key, p.asDouble)
            p.isBoolean -> p.asBoolean
            else -> null
        }
    }

    private fun readPropertyJson(f: Feature, key: String): JsonElement? {
        val root = f.properties() ?: return null
        if (root.has(key)) return root.get(key)
        if (key.contains('.')) return getNestedJsonElement(root, key.split('.'))
        return null
    }

    private fun getNestedJsonElement(root: JsonObject, keys: List<String>): JsonElement? {
        var cur: JsonElement = root
        for (segment in keys) {
            if (!cur.isJsonObject) return null
            val obj = cur.asJsonObject
            if (!obj.has(segment)) return null
            cur = obj.get(segment)!!
        }
        return cur
    }

    private fun normalizeEpochProperty(key: String, value: Double): Double {
        if (!isEpochTimestampPropertyKey(key)) return value
        if (value > 1e11) return value / 1000.0
        return value
    }

    /** `timestamp`, `*.timestamp`, `minTimestamp`, `details.range.maxTimestamp`, etc. */
    private fun isEpochTimestampPropertyKey(key: String): Boolean {
        val k = key.lowercase()
        return k == "timestamp" || k.endsWith("timestamp")
    }

    /** Rebuilds `details.range` from nested `["get","range",["get","details"]]`. */
    private fun dottedGetPath(node: Any?): String? {
        val raw = when (node) {
            is Expression -> node.raw
            else -> node
        }
        val list = raw as? List<*> ?: return null
        if (list.isEmpty() || list[0] != "get") return null
        val key = list.getOrNull(1) as? String ?: return null
        val parent = list.getOrNull(2) ?: return key
        val parentPath = dottedGetPath(parent) ?: return null
        return "$parentPath.$key"
    }

    private fun valuesEqual(a: Any?, b: Any?): Boolean {
        if (a == null || b == null) return a == null && b == null
        if (a is Number && b is Number) {
            return a.toDouble() == b.toDouble()
        }
        return a == b || a.toString() == b.toString()
    }
}
