package com.xweather.mapsgl.map.mapbox

import androidx.compose.ui.graphics.Color
import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.StyleValue

/**
 * Resolves [StyleValue] paint properties against MVT feature attributes for GLES vector drawing.
 * Supports constants and the expression shapes used by built-in weather vector layers.
 */
internal object VectorFeatureStyleResolver {

    fun resolveComposeColor(
        styleValue: StyleValue<*>,
        feature: Feature,
        default: Color = Color.White,
    ): Color {
        return when (styleValue) {
            is StyleValue.Constant -> (styleValue.value as? Color) ?: default
            is StyleValue.Expression -> evaluateColor(styleValue.expression.raw, feature) ?: default
        }
    }

    fun isConstantColor(styleValue: StyleValue<*>): Boolean = styleValue is StyleValue.Constant

    fun constantColor(styleValue: StyleValue<*>, default: Color = Color.White): Color =
        (styleValue as? StyleValue.Constant)?.value as? Color ?: default

    fun colorKey(color: Color): Int {
        val a = (color.alpha * 255f).toInt().coerceIn(0, 255)
        val r = (color.red * 255f).toInt().coerceIn(0, 255)
        val g = (color.green * 255f).toInt().coerceIn(0, 255)
        val b = (color.blue * 255f).toInt().coerceIn(0, 255)
        return (a shl 24) or (r shl 16) or (g shl 8) or b
    }

    fun colorFromKey(key: Int): Color {
        val a = ((key ushr 24) and 0xFF) / 255f
        val r = ((key ushr 16) and 0xFF) / 255f
        val g = ((key ushr 8) and 0xFF) / 255f
        val b = (key and 0xFF) / 255f
        return Color(r, g, b, a)
    }

    private fun unwrapExprNode(raw: Any?): Any? =
        when (raw) {
            is Expression -> raw.raw
            else -> raw
        }

    private fun evaluateColor(raw: Any, feature: Feature): Color? {
        return when (val node = unwrapExprNode(raw)) {
            is List<*> -> evaluateColorList(node, feature)
            is String -> parseColorString(node)
            else -> null
        }
    }

    private fun evaluateColorList(raw: List<*>, feature: Feature): Color? {
        if (raw.isEmpty()) return null
        return when (raw[0]) {
            "concat" -> {
                val sb = StringBuilder()
                for (i in 1 until raw.size) {
                    sb.append(evaluateToString(raw[i], feature) ?: "")
                }
                parseColorString(sb.toString())
            }

            "get" -> {
                val prop = raw.getOrNull(1) as? String ?: return null
                when (val v = featureProperty(feature, prop, raw.getOrNull(2))) {
                    is String -> parseColorString(v)
                    is Number -> null
                    else -> null
                }
            }

            "at" -> when (val v = jsonPrimitiveValue(resolveJsonNode(raw, feature))) {
                is String -> parseColorString(v)
                else -> null
            }

            "match" -> evaluateMatch(raw, feature)

            "case" -> evaluateCase(raw, feature)

            "coalesce" -> {
                for (i in 1 until raw.size) {
                    evaluateColor(raw[i]!!, feature)?.let { return it }
                }
                null
            }

            "literal" -> parseColorLiteral(raw.getOrNull(1))

            "rgb", "rgba" -> evaluateRgb(raw, feature)

            "upcase", "downcase" -> {
                val inner = raw.getOrNull(1) ?: return null
                val s = evaluateToString(inner, feature) ?: return null
                parseColorString(
                    when (raw[0]) {
                        "upcase" -> s.uppercase()
                        else -> s.lowercase()
                    },
                )
            }

            else -> null
        }
    }

    private fun evaluateMatch(raw: List<*>, feature: Feature): Color? {
        if (raw.size < 4) return null
        val input = evaluateToString(raw[1], feature) ?: return evaluateColor(raw.last()!!, feature)
        var i = 2
        while (i + 1 < raw.size) {
            val label = raw[i]?.toString()
            if (label != null && label == input) {
                return evaluateColor(raw[i + 1]!!, feature)
            }
            i += 2
        }
        return evaluateColor(raw.last()!!, feature)
    }

    private fun evaluateCase(raw: List<*>, feature: Feature): Color? {
        if (raw.size < 3) return null
        var i = 1
        while (i + 1 < raw.size) {
            if (evaluateToBoolean(raw[i], feature) == true) {
                return evaluateColor(raw[i + 1]!!, feature)
            }
            i += 2
        }
        return evaluateColor(raw.last()!!, feature)
    }

    private fun evaluateRgb(raw: List<*>, feature: Feature): Color? {
        val op = raw[0] as? String ?: return null
        val r = evaluateToNumber(raw.getOrNull(1), feature) ?: return null
        val g = evaluateToNumber(raw.getOrNull(2), feature) ?: return null
        val b = evaluateToNumber(raw.getOrNull(3), feature) ?: return null
        val a =
            if (op == "rgba") {
                evaluateToNumber(raw.getOrNull(4), feature) ?: 1.0
            } else {
                1.0
            }
        return Color(
            red = (r / 255.0).toFloat().coerceIn(0f, 1f),
            green = (g / 255.0).toFloat().coerceIn(0f, 1f),
            blue = (b / 255.0).toFloat().coerceIn(0f, 1f),
            alpha = a.toFloat().coerceIn(0f, 1f),
        )
    }

    private fun evaluateToString(raw: Any?, feature: Feature): String? {
        return when (val node = unwrapExprNode(raw)) {
            null -> null
            is String -> node
            is Number -> node.toString()
            is List<*> -> when (node.firstOrNull()) {
                "get" -> {
                    val prop = node.getOrNull(1) as? String ?: return null
                    featureProperty(feature, prop, node.getOrNull(2))?.toString()
                }

                "at" -> jsonPrimitiveValue(resolveJsonNode(node, feature))?.toString()

                "concat" -> {
                    val sb = StringBuilder()
                    for (i in 1 until node.size) {
                        sb.append(evaluateToString(node[i], feature) ?: "")
                    }
                    sb.toString()
                }

                "to-string" -> evaluateToString(node.getOrNull(1), feature)
                "literal" -> node.getOrNull(1)?.toString()
                "upcase" -> evaluateToString(node.getOrNull(1), feature)?.uppercase()
                "downcase" -> evaluateToString(node.getOrNull(1), feature)?.lowercase()
                else -> null
            }

            else -> node.toString()
        }
    }

    private fun evaluateToNumber(raw: Any?, feature: Feature): Double? {
        return when (val node = unwrapExprNode(raw)) {
            is Number -> node.toDouble()
            is String -> node.toDoubleOrNull()
            is List<*> -> when (node.firstOrNull()) {
                "to-number" -> evaluateToNumber(node.getOrNull(1), feature)
                "get" -> {
                    val prop = node.getOrNull(1) as? String ?: return null
                    when (val v = featureProperty(feature, prop, node.getOrNull(2))) {
                        is Number -> v.toDouble()
                        is String -> v.toDoubleOrNull()
                        else -> null
                    }
                }

                "literal" -> (node.getOrNull(1) as? Number)?.toDouble()
                else -> null
            }

            else -> null
        }
    }

    private fun evaluateToBoolean(raw: Any?, feature: Feature): Boolean? {
        return when (raw) {
            is Boolean -> raw
            is List<*> -> when (raw.firstOrNull()) {
                "to-boolean" -> evaluateToBoolean(raw.getOrNull(1), feature)
                "==", "!=" -> {
                    val lhs = evaluateToString(raw.getOrNull(1), feature)
                    val rhs = evaluateToString(raw.getOrNull(2), feature)
                    when (raw[0]) {
                        "==" -> lhs == rhs
                        else -> lhs != rhs
                    }
                }

                else -> null
            }

            else -> null
        }
    }

    /**
     * Resolves the container sub-expressions [com.xweather.mapsgl.style.Expression.getPath] emits:
     * `["get", key, parent]` for a named segment and `["at", index, parent]` for a numeric one.
     * `get("periods.0.category")` compiles to `["get", "category", ["at", 0, ["get", "periods"]]]`,
     * so without these the whole chain resolved to null.
     */
    private fun resolveJsonNode(raw: Any?, feature: Feature): com.google.gson.JsonElement? {
        val node = unwrapExprNode(raw) as? List<*> ?: return null
        if (node.isEmpty()) return null
        return when (node[0]) {
            "get" -> {
                val key = node.getOrNull(1) as? String ?: return null
                val parent = node.getOrNull(2)
                val container =
                    if (parent == null) feature.properties() else resolveJsonNode(parent, feature)
                val obj = container?.takeIf { it.isJsonObject }?.asJsonObject ?: return null
                if (!obj.has(key)) return null
                obj.get(key)
            }
            "at" -> {
                val index = (node.getOrNull(1) as? Number)?.toInt() ?: return null
                val container = resolveJsonNode(node.getOrNull(2), feature) ?: return null
                val arr = container.takeIf { it.isJsonArray }?.asJsonArray ?: return null
                if (index < 0 || index >= arr.size()) return null
                arr.get(index)
            }
            else -> null
        }
    }

    private fun jsonPrimitiveValue(element: com.google.gson.JsonElement?): Any? {
        if (element == null || element.isJsonNull) return null
        if (!element.isJsonPrimitive) return element.toString()
        val prim = element.asJsonPrimitive
        return when {
            prim.isString -> prim.asString
            prim.isNumber -> prim.asDouble
            prim.isBoolean -> prim.asBoolean
            else -> element.toString()
        }
    }

    private fun featureProperty(feature: Feature, key: String, nestedFrom: Any?): Any? {
        if (nestedFrom != null) {
            val container = resolveJsonNode(nestedFrom, feature) ?: return null
            val obj = container.takeIf { it.isJsonObject }?.asJsonObject ?: return null
            if (!obj.has(key)) return null
            return jsonPrimitiveValue(obj.get(key))
        }
        feature.getStringProperty(key)?.let { return it }
        feature.getNumberProperty(key)?.let { return it }
        feature.getBooleanProperty(key)?.let { return it }
        if (!key.contains('.')) return null
        // Numeric segments index arrays (`periods.0.category`). The old walk assumed every
        // intermediate node was an object and called `asJsonObject` on it, which returns null for
        // indexed paths at best and throws IllegalStateException on a JsonArray at worst.
        var current: com.google.gson.JsonElement = feature.properties() ?: return null
        val parts = key.split('.')
        for ((index, part) in parts.withIndex()) {
            val element = when {
                current.isJsonObject -> {
                    val obj = current.asJsonObject
                    if (!obj.has(part)) return null
                    obj.get(part)
                }
                current.isJsonArray -> {
                    val arr = current.asJsonArray
                    val i = part.toIntOrNull() ?: return null
                    if (i < 0 || i >= arr.size()) return null
                    arr.get(i)
                }
                else -> return null
            } ?: return null
            if (index == parts.lastIndex) {
                if (element.isJsonPrimitive) {
                    val prim = element.asJsonPrimitive
                    return when {
                        prim.isString -> prim.asString
                        prim.isNumber -> prim.asDouble
                        prim.isBoolean -> prim.asBoolean
                        else -> element.toString()
                    }
                }
                return element.toString()
            }
            current = element
        }
        return null
    }

    private fun parseColorLiteral(value: Any?): Color? {
        return when (value) {
            is String -> parseColorString(value)
            is List<*> -> {
                if (value.size < 3) return null
                val r = (value[0] as? Number)?.toDouble() ?: return null
                val g = (value[1] as? Number)?.toDouble() ?: return null
                val b = (value[2] as? Number)?.toDouble() ?: return null
                val a = (value.getOrNull(3) as? Number)?.toDouble() ?: 255.0
                Color(
                    red = (r / 255.0).toFloat().coerceIn(0f, 1f),
                    green = (g / 255.0).toFloat().coerceIn(0f, 1f),
                    blue = (b / 255.0).toFloat().coerceIn(0f, 1f),
                    alpha = (a / 255.0).toFloat().coerceIn(0f, 1f),
                )
            }

            else -> null
        }
    }

    private fun parseColorString(value: String): Color? {
        val trimmed = value.trim()
        if (trimmed.isEmpty()) return null
        return try {
            when {
                trimmed.startsWith("#") -> {
                    val cleanHex = trimmed.removePrefix("#")
                    val expanded =
                        when (cleanHex.length) {
                            3 -> cleanHex.map { "$it$it" }.joinToString("")
                            6, 8 -> cleanHex
                            else -> return null
                        }
                    val colorLong = expanded.toLong(16)
                    when (expanded.length) {
                        6 -> Color(colorLong or 0x00000000FF000000)
                        8 -> Color(colorLong)
                        else -> null
                    }
                }

                trimmed.startsWith("rgba", ignoreCase = true) -> {
                    val values = trimmed.substringAfter('(').substringBefore(')').split(',')
                    if (values.size < 4) return null
                    Color(
                        red = values[0].trim().toFloat() / 255f,
                        green = values[1].trim().toFloat() / 255f,
                        blue = values[2].trim().toFloat() / 255f,
                        alpha = values[3].trim().toFloat().coerceIn(0f, 1f),
                    )
                }

                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }
}
