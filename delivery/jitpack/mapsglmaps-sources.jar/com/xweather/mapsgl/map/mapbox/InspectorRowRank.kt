package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.mapbox.geojson.LineString
import com.mapbox.geojson.MultiLineString
import com.mapbox.geojson.MultiPoint
import com.mapbox.geojson.Point
import com.mapbox.maps.QueriedRenderedFeature

/**
 * Which sibling sub-layer of a composite gets to supply a shared data-inspector row.
 *
 * A composite is several layers over one source, queried separately, so a tap where they overlap
 * offers the same row several times over — see the collapse in
 * [MapboxMapController.queryFeatures]. Draw order decides which is offered first, and that puts the
 * line under a symbol ahead of the symbol itself, which is the wrong way round: the reader tapped
 * the icon.
 *
 * It is not merely cosmetic for tropical. A track line there is not an independent feature but a
 * segment synthesized between two track points, and it carries the *earlier* point's properties
 * (see `TropicalGeoJsonTransform.appendLineSegments`, matching the JS transform). A row sourced
 * from the segment therefore reports the advisory number *before* the one whose icon was tapped —
 * tapping the six fixes of a storm read 1,1,2,3,4,5 instead of 1,2,3,4,5,6.
 *
 * Ranking by how specific the geometry is to the tapped point fixes that generally, rather than by
 * special-casing tropical: a point is the thing under the finger, a line is what runs beneath it,
 * a fill is the region around it.
 */
internal object InspectorRowRank {

    const val POINT = 0
    const val LINE = 1
    const val AREA = 2

    /** No geometry to judge — ranks last, so anything identifiable wins over it. */
    const val UNKNOWN = 3

    /**
     * Best (lowest) rank among [features], which may hold either Mapbox
     * [QueriedRenderedFeature]s or plain GeoJSON [Feature]s depending on whether the layer draws
     * through Mapbox or through this SDK's own GL meshes. Anything else is ignored rather than
     * treated as a match.
     */
    fun rankOf(features: Any?): Int {
        val list = features as? List<*> ?: return UNKNOWN
        var best = UNKNOWN
        for (item in list) {
            val geometry = when (item) {
                is Feature -> item.geometry()
                is QueriedRenderedFeature -> item.queriedFeature.feature.geometry()
                else -> null
            } ?: continue
            val rank = when (geometry) {
                is Point, is MultiPoint -> POINT
                is LineString, is MultiLineString -> LINE
                else -> AREA
            }
            if (rank < best) best = rank
            if (best == POINT) return best
        }
        return best
    }
}
