package com.xweather.mapsgl.map.mapbox

import com.google.gson.JsonArray
import com.google.gson.JsonElement
import com.google.gson.JsonNull
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import com.google.gson.JsonPrimitive
import com.mapbox.geojson.*
import com.mapbox.geojson.Point as MBPoint
import com.mapbox.geojson.Polygon as MBPolygon
import com.mapbox.geojson.LineString as MBLineString
import com.mapbox.geojson.MultiPoint as MBMultiPoint
import com.mapbox.geojson.MultiPolygon as MBMultiPolygon
import com.mapbox.geojson.MultiLineString as MBMultiLineString
import com.mapbox.geojson.Geometry as MapboxGeometry
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.mvt.MvtFeature
import com.xweather.mapsgl.mvt.MvtLineString
import com.xweather.mapsgl.mvt.MvtMultiLineString
import com.xweather.mapsgl.mvt.MvtMultiPoint
import com.xweather.mapsgl.mvt.MvtMultiPolygon
import com.xweather.mapsgl.mvt.MvtPoint
import com.xweather.mapsgl.mvt.MvtPolygon

object MapboxVectorFeature {
    /** Shared, never-mutated placeholder geometry for [fromPropertiesOnly] — a single instance reused
     * across every call, never read by any caller of that function. */
    private val PLACEHOLDER_POINT: MapboxGeometry = MBPoint.fromLngLat(0.0, 0.0)

    /**
     * Rule: legend-properties-only-conversion. [from]'s geometry branch walks every ring vertex
     * through [tileLocalXYToLngLat] (boxing a `Pair<Double,Double>` per point) plus a full JTS-to-
     * Mapbox polygon rebuild and CW/CCW orientation pass — real cost that scales with vertex count,
     * not feature count. Callers that only read properties/id/sourceLayer off the result (e.g.
     * [com.xweather.mapsgl.layers.tile.VectorTileLayer.getVisibleFeatures], building legend swatches
     * from just `ADVISORY`/`COLOR`) never touch `.geometry()`, so building it at all is pure waste —
     * for a dense polygon dataset (thousands of small municipality-level shapes) this was measured to
     * be the dominant per-refresh allocator, not the property conversion. Skips geometry entirely by
     * reusing one shared placeholder point; never call `.geometry()` on the result.
     */
    fun fromPropertiesOnly(vtFeature: MvtFeature, attributes: Map<String, *>? = null): Feature {
        val geoJsonProps = attributesToJsonObject(attributes ?: vtFeature.attributes)
        return Feature.fromGeometry(PLACEHOLDER_POINT, geoJsonProps, vtFeature.id.toString())
    }

    fun from(coord: TileCoord, vtFeature: MvtFeature, attributes: Map<String, *>? = null): Feature {
        val geometry = vtFeature.geometry
        val featureProperties = attributes ?: vtFeature.attributes
        val extent = vtFeature.extent ?: 4096

        val mapboxGeometry: MapboxGeometry = when (geometry) {
            is MvtPoint -> {
                val (lon, lat) = tileLocalXYToLngLat(geometry.x, geometry.y, coord)
                MBPoint.fromLngLat(lon, lat)
            }
            is MvtMultiPoint -> MBMultiPoint.fromLngLats(
                geometry.coordinates.map {
                    val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                    MBPoint.fromLngLat(lon, lat)
                }
            )
            is MvtLineString -> MBLineString.fromLngLats(
                geometry.coordinates.map {
                    val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                    MBPoint.fromLngLat(lon, lat)
                }
            )
            is MvtMultiLineString -> MBMultiLineString.fromLineStrings(
                (0 until geometry.numGeometries).map { i ->
                    val line = geometry.getGeometryN(i) as MvtLineString
                    MBLineString.fromLngLats(
                        line.coordinates.map {
                            val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                            MBPoint.fromLngLat(lon, lat)
                        }
                    )
                }
            )
            is MvtPolygon -> {
                // Exterior ring
                val exterior = geometry.exteriorRing.coordinates.map {
                    val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                    MBPoint.fromLngLat(lon, lat)
                }.let { ring ->
                    // ensure closed
                    if (ring.isNotEmpty() && ring.first() != ring.last()) ring + ring.first() else ring
                }

                // Holes
                val holes: List<List<MBPoint>> = (0 until geometry.numInteriorRing).map { i ->
                    geometry.getInteriorRingN(i).coordinates.map {
                        val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord)
                        MBPoint.fromLngLat(lon, lat)
                    }.let { ring ->
                        // ensure closed
                        if (ring.isNotEmpty() && ring.first() != ring.last()) ring + ring.first() else ring
                    }
                }

                // (Optional) normalize orientation: outer CCW, holes CW
                fun isCW(r: List<MBPoint>): Boolean {
                    var s = 0.0
                    for (k in 0 until r.size - 1) {
                        val a = r[k];
                        val b = r[k + 1]
                        s += (b.longitude() - a.longitude()) * (b.latitude() + a.latitude())
                    }
                    return s > 0
                }

                val ext = if (isCW(exterior)) exterior.reversed() else exterior
                val holesOriented = holes.map { r -> if (isCW(r)) r else r.reversed() }

                MBPolygon.fromLngLats(listOf(ext) + holesOriented)
            }
            is MvtMultiPolygon -> {
                MBMultiPolygon.fromPolygons(
                    (0 until geometry.numGeometries).map { i ->
                        val jtsPoly = geometry.getGeometryN(i) as MvtPolygon

                        val exterior = jtsPoly.exteriorRing.coordinates.map {
                            val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord, extent)
                            MBPoint.fromLngLat(lon, lat)
                        }.let { ring ->
                            // ensure closed
                            if (ring.isNotEmpty() && ring.first() != ring.last()) ring + ring.first() else ring
                        }

                        val holes = (0 until jtsPoly.numInteriorRing).map { h ->
                            jtsPoly.getInteriorRingN(h).coordinates.map {
                                val (lon, lat) = tileLocalXYToLngLat(it.x, it.y, coord, extent)
                                MBPoint.fromLngLat(lon, lat)
                            }.let { ring ->
                                // ensure closed
                                if (ring.isNotEmpty() && ring.first() != ring.last()) ring + ring.first() else ring
                            }
                        }

                        MBPolygon.fromLngLats(listOf(exterior) + holes)
                    }
                )
            }
            else -> throw IllegalArgumentException(
                "Unsupported geometry type: ${geometry.javaClass.simpleName}"
            )
        }

        // Build GeoJSON properties directly from the (already dot-notation-nested) attribute map.
        // Previously this went attributes -> org.json JSONObject -> plain Kotlin Map -> Gson
        // reflective toJsonTree(); that reflective serialization measured as the single largest
        // per-feature cost for point-heavy tiles (lightning: up to ~38k features/tile). Writing
        // straight into JsonObject/JsonPrimitive avoids reflection and the extra org.json hop.
        val geoJsonProps = attributesToJsonObject(featureProperties)

        return Feature.fromGeometry(mapboxGeometry, geoJsonProps, vtFeature.id.toString())
    }

    private fun attributesToJsonObject(map: Map<*, *>): JsonObject {
        val obj = JsonObject()
        for ((key, value) in map) {
            obj.add(key.toString(), attributesToJsonElement(value))
        }
        return obj
    }

    private fun attributesToJsonArray(list: List<*>): JsonArray {
        val arr = JsonArray(list.size)
        for (item in list) arr.add(attributesToJsonElement(item))
        return arr
    }

    private fun attributesToJsonElement(value: Any?): JsonElement =
        when (value) {
            null -> JsonNull.INSTANCE
            is Map<*, *> -> attributesToJsonObject(value)
            is List<*> -> attributesToJsonArray(value)
            is String -> stringToJsonElement(value)
            is Boolean -> JsonPrimitive(value)
            is Number -> JsonPrimitive(value)
            is JsonElement -> value
            else -> JsonPrimitive(value.toString())
        }

    /**
     * MVT string attributes sometimes hold stringified JSON objects/arrays; sniff and parse them the
     * same way the old org.json path did, but straight to a [JsonElement] with no intermediate hop.
     */
    private fun stringToJsonElement(value: String): JsonElement {
        val trimmed = value.trim()
        val looksLikeJson =
            (trimmed.startsWith("{") && trimmed.endsWith("}")) ||
                (trimmed.startsWith("[") && trimmed.endsWith("]"))
        if (looksLikeJson) {
            try {
                return JsonParser.parseString(trimmed)
            } catch (e: Exception) {
                // Not actually valid JSON; fall through and keep it as a plain string.
            }
        }
        return JsonPrimitive(value)
    }

    // Helper function to convert tile local coordinates to geographic coordinates
    internal fun tileLocalXYToLngLat(x: Double, y: Double, coord: TileCoord, extent: Int = 4096): Pair<Double, Double> {
        val lon = (x / extent + coord.x) / (1 shl coord.z) * 360.0 - 180.0
        val n = Math.PI - 2.0 * Math.PI * (y / extent + coord.y) / (1 shl coord.z)
        val lat = Math.toDegrees(Math.atan(Math.sinh(n)))
        return Pair(lon, lat)
    }
}