package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.mapbox.geojson.LineString
import com.mapbox.geojson.MultiLineString

/**
 * Direct tropical track-line draw filter (parity with JS `tropical.ts` `trackLineFilter`).
 * Avoids brittle expression-tree evaluation for the auto-generated weather layer ids.
 */
internal object TropicalDrawFilter {

    fun isTropicalTrackLineLayer(layerId: String?): Boolean =
        layerId != null && layerId.startsWith("tropical.track") && layerId.endsWith(".line")

    fun passesTrackLine(feature: Feature, mapTimeMs: Long): Boolean {
        if (!passesTrackLineStatic(feature)) return false
        val mapTimeSec = mapTimeMs / 1000.0
        val ts = readTimestampSeconds(feature) ?: return true
        return ts <= mapTimeSec
    }

    /**
     * Static half of [passesTrackLine] for GPU map-time mesh prep: keep all timed track segments
     * in the mesh; the shader discards by baked `featureTime`.
     */
    fun passesTrackLineStatic(feature: Feature): Boolean {
        if (feature.getStringProperty("featureType") != "trackLine") return false
        return isLineGeometry(feature)
    }

    private fun isLineGeometry(feature: Feature): Boolean =
        feature.geometry() is LineString || feature.geometry() is MultiLineString

    private fun readTimestampSeconds(feature: Feature): Double? {
        feature.getNumberProperty("timestamp")?.let { return normalizeEpochSeconds(it.toDouble()) }
        feature.getStringProperty("timestamp")?.toDoubleOrNull()?.let { return normalizeEpochSeconds(it) }
        return null
    }

    private fun normalizeEpochSeconds(value: Double): Double =
        if (value > 1e11) value / 1000.0 else value
}
