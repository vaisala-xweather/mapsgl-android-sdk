package com.xweather.mapsgl.map.mapbox

import androidx.compose.ui.graphics.Color
import java.util.concurrent.ConcurrentHashMap

/**
 * Tracks per-color GLES mesh sub-layers (`{layerId}::c{argb}`) for data-driven vector paint.
 */
internal object VectorGeometryColorBuckets {

    private const val BUCKET_SUFFIX = "::c"

    private val bucketColors = ConcurrentHashMap<String, Color>()
    private val layerBuckets = ConcurrentHashMap<String, MutableSet<String>>()
    private val tileBuckets = ConcurrentHashMap<String, MutableSet<String>>()

    fun bucketId(layerId: String, colorKey: Int): String = "$layerId$BUCKET_SUFFIX${colorKey.toUInt()}"

    fun registerBucket(layerId: String, bucketId: String, color: Color) {
        bucketColors[bucketId] = color
        layerBuckets.computeIfAbsent(layerId) { ConcurrentHashMap.newKeySet() }.add(bucketId)
    }

    fun rememberTileBucket(layerId: String, coordHash: String, bucketId: String) {
        tileBuckets.computeIfAbsent(tileKey(layerId, coordHash)) { ConcurrentHashMap.newKeySet() }
            .add(bucketId)
    }

    fun bucketsFor(layerId: String): List<Pair<String, Color>> {
        val ids = layerBuckets[layerId] ?: return emptyList()
        return ids.mapNotNull { id -> bucketColors[id]?.let { id to it } }
    }

    fun hasBuckets(layerId: String): Boolean = !layerBuckets[layerId].isNullOrEmpty()

    fun bucketIdsForTile(layerId: String, coordHash: String): List<String> =
        tileBuckets[tileKey(layerId, coordHash)]?.toList() ?: emptyList()

    fun clearTileBuckets(
        controller: com.xweather.mapsgl.map.MapController?,
        layerId: String,
        coordHash: String,
    ) {
        val key = tileKey(layerId, coordHash)
        val ids = tileBuckets.remove(key) ?: return
        val normHash = normalizeStencilTileKey(coordHash)
        for (bucketId in ids) {
            controller?.glStencilMaskTileCache?.removeCustomMaskTile(bucketId, normHash)
            GlStencilMaskRendererHolder.renderer.releaseGpuForMaskLayerId(bucketId)
        }
        layerBuckets[layerId]?.removeAll(ids)
        for (bucketId in ids) {
            bucketColors.remove(bucketId)
        }
    }

    fun clearLayer(controller: com.xweather.mapsgl.map.MapController?, layerId: String) {
        val ids = layerBuckets.remove(layerId) ?: return
        tileBuckets.keys.removeIf { it.startsWith("$layerId\u0000") }
        for (bucketId in ids) {
            controller?.glStencilMaskTileCache?.clearCustomMaskKind(bucketId)
            GlStencilMaskRendererHolder.renderer.releaseGpuForMaskLayerId(bucketId)
            bucketColors.remove(bucketId)
        }
    }

    private fun tileKey(layerId: String, coordHash: String): String =
        "$layerId\u0000${normalizeStencilTileKey(coordHash)}"
}
