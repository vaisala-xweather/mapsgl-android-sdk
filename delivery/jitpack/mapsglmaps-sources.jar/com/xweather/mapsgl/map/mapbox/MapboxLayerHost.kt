package com.xweather.mapsgl.map.mapbox

import android.content.Context
import android.opengl.GLES31
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.mapbox.maps.BuildConfig
import com.mapbox.maps.CustomLayerHost
import com.mapbox.maps.CustomLayerRenderParameters
import com.mapbox.maps.logD
import com.mapbox.maps.logW
import com.xweather.mapsgl.gl.ParticleRenderPass
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.RenderPass.Companion
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.map.MapsGLLayerError
import com.xweather.mapsgl.util.MapsGLLog
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.VectorHeatmapLayerRenderer
import com.xweather.mapsgl.renderers.VectorSymbolLayerRenderer
import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.type
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileData

/**
 *  MapboxLayerHost.kt
 *
 *  @author Jason Suto 11/30/23.
 */
class MapboxLayerHost(
    private val context: Context,
    private val mapLayer: MapLayer<TileData, LayerRenderContext<Any>>, //private?
) : CustomLayerHost {

    companion object {
        private const val TAG = "MapboxLayerHost"
        private const val BYTES_PER_FLOAT = 4
        private var programInt = 0

        /**
         * Consecutive failures tolerated before the delayed retry. A driver that rejects a shader
         * outright fails identically every frame, so this bounds the immediate retry; a layer whose
         * first compile lost a setup-time race recovers on a later frame. See [renderDisabled].
         */
        private const val MAX_RENDER_FAILURES = 3

        /**
         * Pause after [MAX_RENDER_FAILURES] before one more shader compile. The PowerVR setup-time
         * race (XMAPSGLSDK-281) rejects `#version 310 es` during the first frames after map load
         * and accepts the same shader about 1.5s later. The three immediate attempts all land
         * inside that window, so the fourth compile waits this long instead of running on the
         * next frame.
         */
        private const val DELAYED_SHADER_RETRY_MS = 1_500L

        @Volatile
        private var glCapabilitiesLogged = false

        /** One line per process describing the GL context actually handed to us. */
        private fun logGlCapabilitiesOnce() {
            if (glCapabilitiesLogged) return
            glCapabilitiesLogged = true
            // Through MapsGLLog so it survives the release AAR's minification: no report on the
            // XMAPSGLSDK-281 race has yet said what the device actually advertised, and this is
            // one line per process.
            MapsGLLog.info(
                TAG,
                "GL context: version=" + GLES31.glGetString(GLES31.GL_VERSION) +
                    " vendor=" + GLES31.glGetString(GLES31.GL_VENDOR) +
                    " renderer=" + GLES31.glGetString(GLES31.GL_RENDERER) +
                    " glsl=" + GLES31.glGetString(GLES31.GL_SHADING_LANGUAGE_VERSION),
            )
        }

        private fun checkError(cmd: String? = null) {
            if (BuildConfig.DEBUG) {
                when (val error = GLES31.glGetError()) {
                    GLES31.GL_NO_ERROR -> {
                        logD(TAG, "$cmd -> no error")
                    }

                    GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM")
                    GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                    GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                    GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                    GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                    else -> throw RuntimeException("$cmd -> error in gl: $error")
                }
            }
        }
    }

    var id = mapLayer.id
    lateinit var camera: Camera
    var hashMap = hashMapOf<String, Int>()
    var needToBindTextures = false
    lateinit var currentTime: String
    lateinit var nextTime: String
    //private lateinit var copyMap: MutableMap<String, Tile<DataType>>



    init{
        if(pr.ON) pr.p("LHost", pr.lHost, "init() for ${mapLayer.id}")

    }

    private var _showLayer: Boolean = true
    var showLayer: Boolean
        get() = _showLayer
        set(value) {
            _showLayer = value
        }

    /**
     * Set once any Mapbox-invoked callback on this host has thrown.
     *
     * Mapbox calls [render] (and the other [CustomLayerHost] overrides) from its native render
     * loop. An exception that escapes back across that JNI boundary leaves a pending exception on
     * the native frame, and ART aborts the whole process on the next JNI call - the
     * `JNI DETECTED ERROR IN APPLICATION ... called with pending exception` abort in
     * XMAPSGLSDK-281. No application-level try/catch can intercept it, so a shader that will not
     * compile takes the host app down.
     *
     * Every override here therefore contains its own failures: the layer stops drawing and the
     * app keeps running. A failure is retried a bounded number of times first (see
     * [containFailure]) and, once given up on, reported to the host app through
     * [com.xweather.mapsgl.map.MapController.onLayerError]. Render failures get one more compile
     * [DELAYED_SHADER_RETRY_MS] after the third failure before that give-up.
     */
    @Volatile
    private var renderDisabled = false

    /** Consecutive [containFailure] failures so far; reset by the first clean pass. */
    @Volatile
    private var consecutiveFailures = 0

    /**
     * Set when the third render failure arms the delayed fourth compile. The next failure after
     * that is the give-up. Cleared if that fourth compile succeeds.
     */
    @Volatile
    private var delayedShaderRetryArmed = false

    /**
     * [SystemClock.elapsedRealtime] before which [render] skips work. Zero when no pause is armed.
     */
    @Volatile
    private var delayedShaderRetryAtElapsedMs = 0L

    /**
     * Runs [block] so that nothing thrown can reach Mapbox's native caller. See [renderDisabled].
     *
     * A failure is retried on later frames up to [MAX_RENDER_FAILURES]. The renderer is already
     * built for this: it only creates a GL program when the previous attempt left it null, so a
     * throwing attempt leaves no partial state and the next frame simply tries again. That matters
     * for the setup-time race in XMAPSGLSDK-281, where the same shader compiles cleanly a moment
     * later - without the retry, containment would turn that crash into a permanently dead layer.
     *
     * Those immediate retries all happen within the first few frames, which is still inside the
     * window where a PowerVR driver rejects the particle shaders. After the third render failure
     * the layer waits [DELAYED_SHADER_RETRY_MS] and compiles once more. The wait is not a sleep on
     * this thread: [render] returns, and a frame is requested when the pause ends. A shader the
     * driver still rejects on that fourth attempt is then given up on.
     */
    private fun containFailure(stage: String, block: () -> Unit) {
        try {
            block()
            if (consecutiveFailures != 0 || delayedShaderRetryArmed) {
                MapsGLLog.info(
                    TAG,
                    "MapsGL layer ${mapLayer.id} recovered after $consecutiveFailures failed $stage attempt(s)",
                )
                consecutiveFailures = 0
                delayedShaderRetryArmed = false
                delayedShaderRetryAtElapsedMs = 0L
            }
        } catch (t: Throwable) {
            val attempt = ++consecutiveFailures
            if (attempt >= MAX_RENDER_FAILURES && stage == "render" && !delayedShaderRetryArmed) {
                delayedShaderRetryArmed = true
                delayedShaderRetryAtElapsedMs =
                    SystemClock.elapsedRealtime() + DELAYED_SHADER_RETRY_MS
                val message = "$stage failed $attempt times; waiting ${DELAYED_SHADER_RETRY_MS}ms " +
                    "before one more shader compile. Last reason: ${t.message}"
                MapsGLLog.warn(TAG, "MapsGL layer ${mapLayer.id} $message")
                reportFailure(MapsGLLayerError.Reason.RENDER_FAILED, message, t)
                scheduleDelayedShaderRetry()
            } else if (attempt >= MAX_RENDER_FAILURES) {
                renderDisabled = true
                val message = "$stage failed $attempt times; layer disabled for the life of " +
                    "this map. Last reason: ${t.message}"
                MapsGLLog.error(TAG, "MapsGL layer ${mapLayer.id} $message", t)
                reportFailure(MapsGLLayerError.Reason.LAYER_DISABLED, message, t)
            } else {
                val message = "$stage attempt $attempt failed, will retry: ${t.message}"
                MapsGLLog.warn(TAG, "MapsGL layer ${mapLayer.id} $message")
                reportFailure(MapsGLLayerError.Reason.RENDER_FAILED, message, t)
            }
        }
    }

    /**
     * Asks Mapbox for a frame when the delayed compile is due. [com.mapbox.maps.MapboxMap.triggerRepaint]
     * is often dropped once the camera is idle, which would leave the fourth attempt with no [render]
     * call. [MapboxMapController.requestAnimatedFrame] is the path that still runs the custom layer.
     */
    private fun scheduleDelayedShaderRetry() {
        val controller = mapLayer.mapController as? MapboxMapController ?: return
        Handler(Looper.getMainLooper()).postDelayed({
            if (renderDisabled) return@postDelayed
            controller.requestAnimatedFrame()
        }, DELAYED_SHADER_RETRY_MS)
    }

    /**
     * Hands a contained failure to the host app through
     * [com.xweather.mapsgl.map.MapController.onLayerError]. The caller has already logged it.
     *
     * Reporting is the only way out of here: the exception cannot be rethrown - that is the abort
     * this class exists to prevent - so a layer that silently stops drawing is all the app would
     * otherwise get. The message carries whatever the driver said, which
     * [com.xweather.mapsgl.gl.ShaderUtils] puts into the exception for exactly this trip.
     */
    private fun reportFailure(
        reason: MapsGLLayerError.Reason,
        message: String,
        cause: Throwable,
    ) {
        // Never let reporting become its own failure: this runs inside a catch on the render
        // thread, and anything thrown here would escape to Mapbox's native caller.
        try {
            mapLayer.mapController?.reportLayerError(
                MapsGLLayerError(
                    reason = reason,
                    layerCode = (mapLayer as? TileLayer)?.code,
                    layerId = mapLayer.id,
                    message = message,
                    cause = cause,
                ),
            )
        } catch (t: Throwable) {
            MapsGLLog.warn(TAG, "MapsGL layer ${mapLayer.id} error report failed", t)
        }
    }

    fun setTexturesToBind(doBind: Boolean = true) {
        needToBindTextures = doBind
    }

    override fun initialize() = containFailure("initialize") {
        if(pr.ON) pr.p("LayerHost", pr.lHost, "initialize() for ${mapLayer.id}")
        logGlCapabilitiesOnce()
        mapLayer.source.tileCache.oneTimeCacheSetup()
    }


    override fun render(parameters: CustomLayerRenderParameters) {
        //if(pr.ON) pr.p(TAG, pr.dataPool, "render() showLayer: $showLayer  needToBindTextures:$needToBindTextures")
        if (renderDisabled) return
        val retryAt = delayedShaderRetryAtElapsedMs
        if (retryAt != 0L && SystemClock.elapsedRealtime() < retryAt) return
        containFailure("render") {
            // A data-query sample is hidden, but its pixels still have to reach the native cache
            // or the value labels stay blank. Bind those tiles and skip the color draw.
            val tileLayer = mapLayer as? TileLayer
            val keepSampleData = tileLayer != null && !tileLayer.visible && tileLayer.hasDependentLayers
            if (!_showLayer && !keepSampleData) return@containFailure
            CustomLayerMatrixBridge.pushToCameraSync(parameters)
            try {
                // Evictions can land off the GL thread; always flush GPU slot recycle even when
                // there is nothing new to upload this frame.
                mapLayer.source.tileCache.flushPendingGpuEvictions()
                if (needToBindTextures || keepSampleData) {
                    bindTextures(mapLayer.source.id)
                }
                if (_showLayer) {
                    mapLayer.prerender(1.0)
                    mapLayer.render(hashMap, camera)
                }
            } finally {
                CustomLayerMatrixBridge.clearCameraSync()
            }
        }

    }

     fun bindTextures(sourceId: String? = null) {
        hashMap = mapLayer.source.tileCache.bindTextures(sourceId)
        val tileLayer = mapLayer as? TileLayer
        if (mapLayer.source.tileCache.encodedBindsLastCall > 0 && tileLayer?.hasDependentLayers == true) {
            tileLayer.mapController?.notifyDataQuerySampledDataArrived(tileLayer.id)
        }
        //if(pr.ON) pr.p(TAG, pr.threadDL, "bindTextures() camera bounds is ${camera.bounds}")
        if(pr.ON) pr.p(TAG, pr.flicker, "bindTextures() size: ${mapLayer.source.tileCache.bindList.size}")
        val moreToBind = mapLayer.source.tileCache.bindList.isNotEmpty()
        setTexturesToBind(moreToBind)
        // bindTextures() only uploads up to maxBindsPerFrame tiles per call; when the map is idle,
        // Mapbox may not render again, so loading state (Timeline pending / progress UI) can stick
        // until the camera moves. Request another frame until the bind queue is drained.
        if (moreToBind) {
            mapLayer.mapController?.redraw()
        }
    }

    override fun contextLost() = containFailure("contextLost") {
        logW(TAG, "contextLost")
        programInt = 0
        VectorSymbolLayerRenderer.onGlContextLost()
        VectorHeatmapLayerRenderer.onGlContextLost()
        GlStencilMaskRendererHolder.renderer.onContextLost()
        RenderPass.notifyRasterQuadVbosContextLost()
    }

    override fun deinitialize() = containFailure("deinitialize") {
        val tileRenderer = (mapLayer as? TileLayer)?.tileLayerRenderer
        val heatmapRenderer = tileRenderer as? VectorHeatmapLayerRenderer
        heatmapRenderer?.releaseAllGl()
        heatmapRenderer?.shutdownBackgroundWork()

        // Particle layers pool their SSBOs on the render pass, and nothing else released them:
        // ParticleRenderPass.cleanupSSBO existed but had no caller. A layer that was removed and
        // re-added therefore leaked a whole ParticleTileBufferPool per add until glUseProgram
        // returned GL_OUT_OF_MEMORY, at which point the host disables the layer for the life of
        // the map. Freeing here mirrors what the heatmap renderer above already does, and this is
        // the right place for it: Mapbox calls deinitialize on the render thread when the custom
        // layer goes away, so the glDeleteBuffers inside have a current context.
        //
        // Safe if it ever runs on a layer that is still alive (context loss, surface recreation):
        // cleanupSSBO nulls the pool and ParticleRenderPass recreates it lazily on the next frame.
        if (tileRenderer?.renderpassInitialized == true) {
            (tileRenderer.renderPass as? ParticleRenderPass)?.cleanupSSBO()
        }
        if (programInt != 0) {
            // Disable vertex array
            //GLES31.glDisableVertexAttribArray(programPtr.positionHandle)
            //GLES31.glDisableVertexAttribArray(programPtr.colorHandle)
            //GLES31.glDeleteShader(vertexShader)
            //GLES31.glDeleteShader(fragmentShader)
            GLES31.glDeleteProgram(programInt)
            programInt = 0
        }
    }

    private fun checkCompileStatus(shader: Int) {
        if (BuildConfig.DEBUG) {
            val isCompiled = IntArray(1)
            GLES31.glGetShaderiv(shader, GLES31.GL_COMPILE_STATUS, isCompiled, 0)
            if (isCompiled[0] == GLES31.GL_FALSE) {
                val infoLog = GLES31.glGetShaderInfoLog(programInt)
                throw RuntimeException("checkCompileStatus error: $infoLog")
            }
        }
    }

    fun setLayerHostCamera(camera: Camera) {
        this.camera = camera
    }
}
