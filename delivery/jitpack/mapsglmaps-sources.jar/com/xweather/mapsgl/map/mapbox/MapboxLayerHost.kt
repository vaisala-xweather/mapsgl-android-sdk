package com.xweather.mapsgl.map.mapbox

import android.content.Context
import android.opengl.GLES31
import android.util.Log
import com.mapbox.maps.BuildConfig
import com.mapbox.maps.CustomLayerHost
import com.mapbox.maps.CustomLayerRenderParameters
import com.mapbox.maps.logD
import com.mapbox.maps.logW
import com.xweather.mapsgl.gl.RenderPass
import com.xweather.mapsgl.gl.RenderPass.Companion
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.MapLayer
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.gl.worldObjects.cameras.Camera
import com.xweather.mapsgl.renderers.LayerRenderContext
import com.xweather.mapsgl.renderers.VectorHeatmapLayerRenderer
import com.xweather.mapsgl.renderers.VectorSymbolLayerRenderer
import com.xweather.mapsgl.sources.DataType
import com.xweather.mapsgl.sources.type
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileData

/**
 *  MapboxLayerHost.kt
 *
 *  @author Jason Suto 11/30/23.
 */
class MapboxLayerHost(
    private val context: Context,
    private val mapLayer: MapLayer<TileData, LayerRenderContext<Any>>, //private?
) : CustomLayerHost {

    companion object {
        private const val TAG = "MapboxLayerHost"
        private const val BYTES_PER_FLOAT = 4
        private var programInt = 0

        /**
         * Consecutive failures tolerated before a layer is given up on. A driver that rejects a
         * shader outright fails identically every frame, so this bounds the retry; a layer whose
         * first compile lost a setup-time race recovers on a later frame. See [renderDisabled].
         */
        private const val MAX_RENDER_FAILURES = 3

        @Volatile
        private var glCapabilitiesLogged = false

        /** One line per process describing the GL context actually handed to us. */
        private fun logGlCapabilitiesOnce() {
            if (glCapabilitiesLogged) return
            glCapabilitiesLogged = true
            Log.i(
                TAG,
                "GL context: version=" + GLES31.glGetString(GLES31.GL_VERSION) +
                    " vendor=" + GLES31.glGetString(GLES31.GL_VENDOR) +
                    " renderer=" + GLES31.glGetString(GLES31.GL_RENDERER) +
                    " glsl=" + GLES31.glGetString(GLES31.GL_SHADING_LANGUAGE_VERSION),
            )
        }

        private fun checkError(cmd: String? = null) {
            if (BuildConfig.DEBUG) {
                when (val error = GLES31.glGetError()) {
                    GLES31.GL_NO_ERROR -> {
                        logD(TAG, "$cmd -> no error")
                    }

                    GLES31.GL_INVALID_ENUM -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_ENUM")
                    GLES31.GL_INVALID_VALUE -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_VALUE")
                    GLES31.GL_INVALID_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_OPERATION")
                    GLES31.GL_INVALID_FRAMEBUFFER_OPERATION -> throw RuntimeException("$cmd -> error in gl: GL_INVALID_FRAMEBUFFER_OPERATION")
                    GLES31.GL_OUT_OF_MEMORY -> throw RuntimeException("$cmd -> error in gl: GL_OUT_OF_MEMORY")
                    else -> throw RuntimeException("$cmd -> error in gl: $error")
                }
            }
        }
    }

    var id = mapLayer.id
    lateinit var camera: Camera
    var hashMap = hashMapOf<String, Int>()
    var needToBindTextures = false
    lateinit var currentTime: String
    lateinit var nextTime: String
    //private lateinit var copyMap: MutableMap<String, Tile<DataType>>



    init{
        if(pr.ON) pr.p("LHost", pr.lHost, "init() for ${mapLayer.id}")

    }

    private var _showLayer: Boolean = true
    var showLayer: Boolean
        get() = _showLayer
        set(value) {
            _showLayer = value
        }

    /**
     * Set once any Mapbox-invoked callback on this host has thrown.
     *
     * Mapbox calls [render] (and the other [CustomLayerHost] overrides) from its native render
     * loop. An exception that escapes back across that JNI boundary leaves a pending exception on
     * the native frame, and ART aborts the whole process on the next JNI call - the
     * `JNI DETECTED ERROR IN APPLICATION ... called with pending exception` abort in
     * XMAPSGLSDK-281. No application-level try/catch can intercept it, so a shader that will not
     * compile takes the host app down.
     *
     * Every override here therefore contains its own failures: the layer stops drawing and the
     * app keeps running. A failed layer is not retried, because the usual cause (a shader the
     * driver rejects) fails identically on every frame.
     */
    @Volatile
    private var renderDisabled = false

    /** Consecutive [containFailure] failures so far; reset by the first clean pass. */
    @Volatile
    private var consecutiveFailures = 0

    /**
     * Runs [block] so that nothing thrown can reach Mapbox's native caller. See [renderDisabled].
     *
     * A failure is retried on later frames up to [MAX_RENDER_FAILURES]. The renderer is already
     * built for this: it only creates a GL program when the previous attempt left it null, so a
     * throwing attempt leaves no partial state and the next frame simply tries again. That matters
     * for the setup-time race in XMAPSGLSDK-281, where the same shader compiles cleanly a moment
     * later - without the retry, containment would turn that crash into a permanently dead layer.
     * A shader the driver genuinely rejects fails every attempt and is then given up on.
     */
    private fun containFailure(stage: String, block: () -> Unit) {
        try {
            block()
            if (consecutiveFailures != 0) {
                Log.i(TAG, "MapsGL layer ${mapLayer.id} recovered after $consecutiveFailures failed $stage attempt(s)")
                consecutiveFailures = 0
            }
        } catch (t: Throwable) {
            val attempt = ++consecutiveFailures
            if (attempt >= MAX_RENDER_FAILURES) {
                renderDisabled = true
                Log.e(TAG, "MapsGL layer ${mapLayer.id} disabled after $attempt $stage failures", t)
            } else {
                Log.w(TAG, "MapsGL layer ${mapLayer.id} $stage attempt $attempt failed, will retry: ${t.message}")
            }
        }
    }

    fun setTexturesToBind(doBind: Boolean = true) {
        needToBindTextures = doBind
    }

    override fun initialize() = containFailure("initialize") {
        if(pr.ON) pr.p("LayerHost", pr.lHost, "initialize() for ${mapLayer.id}")
        logGlCapabilitiesOnce()
        mapLayer.source.tileCache.oneTimeCacheSetup()
    }


    override fun render(parameters: CustomLayerRenderParameters) {
        //if(pr.ON) pr.p(TAG, pr.dataPool, "render() showLayer: $showLayer  needToBindTextures:$needToBindTextures")
        if (renderDisabled) return
        containFailure("render") {
            if (!_showLayer) return@containFailure
            CustomLayerMatrixBridge.pushToCameraSync(parameters)
            try {
                // Evictions can land off the GL thread; always flush GPU slot recycle even when
                // there is nothing new to upload this frame.
                mapLayer.source.tileCache.flushPendingGpuEvictions()
                if (needToBindTextures) {
                    bindTextures(mapLayer.source.id)
                }
                mapLayer.prerender(1.0)
                mapLayer.render(hashMap, camera)
            } finally {
                CustomLayerMatrixBridge.clearCameraSync()
            }
        }

    }

     fun bindTextures(sourceId: String? = null) {
        hashMap = mapLayer.source.tileCache.bindTextures(sourceId)
        //if(pr.ON) pr.p(TAG, pr.threadDL, "bindTextures() camera bounds is ${camera.bounds}")
        if(pr.ON) pr.p(TAG, pr.flicker, "bindTextures() size: ${mapLayer.source.tileCache.bindList.size}")
        val moreToBind = mapLayer.source.tileCache.bindList.isNotEmpty()
        setTexturesToBind(moreToBind)
        // bindTextures() only uploads up to maxBindsPerFrame tiles per call; when the map is idle,
        // Mapbox may not render again, so loading state (Timeline pending / progress UI) can stick
        // until the camera moves. Request another frame until the bind queue is drained.
        if (moreToBind) {
            mapLayer.mapController?.redraw()
        }
    }

    override fun contextLost() = containFailure("contextLost") {
        logW(TAG, "contextLost")
        programInt = 0
        VectorSymbolLayerRenderer.onGlContextLost()
        VectorHeatmapLayerRenderer.onGlContextLost()
        GlStencilMaskRendererHolder.renderer.onContextLost()
        RenderPass.notifyRasterQuadVbosContextLost()
    }

    override fun deinitialize() = containFailure("deinitialize") {
        val heatmapRenderer =
            (mapLayer as? TileLayer)?.tileLayerRenderer as? VectorHeatmapLayerRenderer
        heatmapRenderer?.releaseAllGl()
        heatmapRenderer?.shutdownBackgroundWork()
        if (programInt != 0) {
            // Disable vertex array
            //GLES31.glDisableVertexAttribArray(programPtr.positionHandle)
            //GLES31.glDisableVertexAttribArray(programPtr.colorHandle)
            //GLES31.glDeleteShader(vertexShader)
            //GLES31.glDeleteShader(fragmentShader)
            GLES31.glDeleteProgram(programInt)
            programInt = 0
        }
    }

    private fun checkCompileStatus(shader: Int) {
        if (BuildConfig.DEBUG) {
            val isCompiled = IntArray(1)
            GLES31.glGetShaderiv(shader, GLES31.GL_COMPILE_STATUS, isCompiled, 0)
            if (isCompiled[0] == GLES31.GL_FALSE) {
                val infoLog = GLES31.glGetShaderInfoLog(programInt)
                throw RuntimeException("checkCompileStatus error: $infoLog")
            }
        }
    }

    fun setLayerHostCamera(camera: Camera) {
        this.camera = camera
    }
}
