package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.Expression
import com.xweather.mapsgl.style.containsMapTime
import com.xweather.mapsgl.style.firstGetKey
import com.xweather.mapsgl.style.isMonotonicMapTimeReveal
import com.xweather.mapsgl.style.splitOnMapTime
import kotlin.math.abs

/**
 * GPU map-time reveal helpers (iOS `vectorMapTimeEpoch` / `featureTime` parity).
 *
 * Fill/line meshes bake a per-vertex [featureTime]; the fragment shader discards when
 * `featureTime > mapTime`. Both values are offset by [EPOCH_SECONDS] so Float32 mantissa
 * precision stays usable for modern Unix timestamps.
 */
internal object VectorMapTime {
    /** Subtracted from Unix seconds before packing into Float vertex/uniform values. */
    const val EPOCH_SECONDS: Double = 1_700_000_000.0

    /**
     * Sentinel `featureTime` meaning "always visible" — `featureTime <= mapTime` always holds
     * when [mapTimeUniform] uses a finite playhead (or the default max float).
     */
    const val ALWAYS_VISIBLE: Float = -Float.MAX_VALUE

    /** Default uniform when the layer has no dynamic map-time filter (never hide). */
    const val NEVER_HIDE_UNIFORM: Float = Float.MAX_VALUE

    fun encodeFeatureTimeSeconds(unixSeconds: Double): Float =
        (unixSeconds - EPOCH_SECONDS).toFloat()

    fun mapTimeUniformSeconds(unixSeconds: Double): Float =
        (unixSeconds - EPOCH_SECONDS).toFloat()

    /**
     * Current playhead as a fragment uniform. When [hasDynamicMapTime] is false, returns
     * [NEVER_HIDE_UNIFORM] so every vertex passes the discard test.
     */
    fun currentMapTimeUniform(hasDynamicMapTime: Boolean): Float {
        if (!hasDynamicMapTime) return NEVER_HIDE_UNIFORM
        val seconds = VectorDrawTime.currentMapTimeMillis() / 1000.0
        return mapTimeUniformSeconds(seconds)
    }

    /**
     * Reads [revealKey] from [feature] and encodes it for GPU reveal. Missing / non-numeric
     * values become [ALWAYS_VISIBLE] (matches iOS bake fallback).
     *
     * Property access mirrors [StencilMaskFilter] / [TropicalDrawFilter]: Mapbox
     * [Feature.getNumberProperty] alone misses some encodings that still appear on
     * [Feature.properties], which made every vertex bake as always-visible and left tropical
     * tracks at full length.
     */
    fun featureTimeFromProperty(feature: Feature, revealKey: String?): Float {
        if (revealKey.isNullOrEmpty()) return ALWAYS_VISIBLE
        val seconds = readEpochSecondsProperty(feature, revealKey) ?: return ALWAYS_VISIBLE
        return encodeFeatureTimeSeconds(seconds)
    }

    /** Treat values that look like epoch milliseconds as seconds. */
    fun normalizeEpochSeconds(value: Double): Double? {
        if (!value.isFinite()) return null
        return if (abs(value) > 1e11) value / 1000.0 else value
    }

    private fun readEpochSecondsProperty(feature: Feature, key: String): Double? {
        feature.getNumberProperty(key)?.let { return normalizeEpochSeconds(it.toDouble()) }
        feature.getStringProperty(key)?.toDoubleOrNull()?.let { return normalizeEpochSeconds(it) }
        val el = readPropertyJson(feature, key) ?: return null
        if (!el.isJsonPrimitive) return null
        val p = el.asJsonPrimitive
        return when {
            p.isNumber -> normalizeEpochSeconds(p.asDouble)
            p.isString -> p.asString.toDoubleOrNull()?.let { normalizeEpochSeconds(it) }
            else -> null
        }
    }

    private fun readPropertyJson(feature: Feature, key: String): com.google.gson.JsonElement? {
        val root = feature.properties() ?: return null
        if (root.has(key)) return root.get(key)
        if (!key.contains('.')) return null
        var cur: com.google.gson.JsonElement = root
        for (segment in key.split('.')) {
            if (!cur.isJsonObject) return null
            val obj = cur.asJsonObject
            if (!obj.has(segment)) return null
            cur = obj.get(segment)!!
        }
        return cur
    }

    /**
     * Effective filter for mesh prep / CPU draw when GPU map-time reveal is active: static half
     * only (after tropical injection), so timestamp clauses are not applied on the CPU.
     */
    fun staticPrepFilter(layerId: String?, baseFilter: Expression?): Expression? {
        val effective = VectorLayerDrawFilterDefaults.effectiveFilter(layerId, baseFilter) ?: return null
        return effective.splitOnMapTime().staticFilter
    }

    /**
     * Property key to bake into fill/line vertices for monotonic `prop <= map-time` reveal, or
     * null when the layer does not use map-time filtering / cannot use monotonic GPU reveal
     * (e.g. convective range windows — those stay on full expression eval).
     */
    fun mapTimeRevealKey(layerId: String?, baseFilter: Expression?): String? {
        if (!VectorFeatureDrawFilter.referencesMapTime(layerId, baseFilter)) return null
        val effective = VectorLayerDrawFilterDefaults.effectiveFilter(layerId, baseFilter)
        val dynamic = effective?.splitOnMapTime()?.dynamicFilter
        if (dynamic != null && !dynamic.isMonotonicMapTimeReveal()) return null
        return dynamic?.firstGetKey() ?: "timestamp"
    }

    /**
     * True when point/fill layers can use baked `featureTime <= mapTime` compact instead of
     * re-evaluating the full dynamic filter each frame.
     */
    fun usesMonotonicMapTimeReveal(layerId: String?, baseFilter: Expression?): Boolean =
        mapTimeRevealKey(layerId, baseFilter) != null

    fun usesGpuMapTimeReveal(layerId: String?, baseFilter: Expression?): Boolean =
        usesMonotonicMapTimeReveal(layerId, baseFilter)

    fun filterHasDynamicMapTime(layerId: String?, baseFilter: Expression?): Boolean {
        val effective = VectorLayerDrawFilterDefaults.effectiveFilter(layerId, baseFilter)
        return effective?.containsMapTime() == true ||
            VectorLayerDrawFilterDefaults.referencesMapTime(layerId, baseFilter)
    }

    /**
     * True when an encoded [featureTime] should remain visible under [mapTimeUniform]
     * (`featureTime <= mapTime`). [ALWAYS_VISIBLE] always passes.
     */
    fun passesFeatureTime(featureTime: Float, mapTimeUniform: Float): Boolean {
        if (featureTime == ALWAYS_VISIBLE) return true
        if (mapTimeUniform == NEVER_HIDE_UNIFORM) return true
        return featureTime <= mapTimeUniform
    }

    /** Encoded featureTime for CPU symbol/circle/heatmap reveal (same property as GPU fill/line). */
    fun featureTimeForLayer(feature: Feature, layerId: String?, baseFilter: Expression?): Float {
        val key = mapTimeRevealKey(layerId, baseFilter) ?: return ALWAYS_VISIBLE
        return featureTimeFromProperty(feature, key)
    }
}
