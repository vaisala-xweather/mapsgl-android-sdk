package com.xweather.mapsgl.map.mapbox

import android.os.SystemClock
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.util.MapsGLDebug

/**
 * Throttled debug logging for GL vector timeline playback gate / prefetch (debug builds only).
 */
internal object VectorGlPlaybackDiagnostics {
    const val TAG = "VectorCirclePlayback"

    private var gateStartedMs: Long = 0L
    private var lastStatusMs: Long = 0L
    private const val STATUS_INTERVAL_MS = 2_000L

    fun onGateBegin(
        layerId: String,
        playbackZoom: Int,
        coords: List<TileCoord>,
        phaseCount: Int,
    ) {
        gateStartedMs = SystemClock.elapsedRealtime()
        lastStatusMs = 0L
        val coordSummary = coords.take(8).joinToString { "${it.z}/${it.x}/${it.y}" }
        val suffix = if (coords.size > 8) " (+${coords.size - 8} more)" else ""
        MapsGLDebug.logI(
            TAG,
            "gate BEGIN layer=$layerId phases=$phaseCount playbackZ=$playbackZoom coords=${coords.size} [$coordSummary$suffix]",
        )
    }

    fun logPrepTick(
        layerId: String,
        gateHold: Boolean,
        phasesAttempted: Int,
        refsPrimed: Int,
        totalPhases: Int,
        tilesRequested: Int,
        tilesParsed: Int,
        phaseBuildMs: Long,
        builtAny: Boolean,
        inFlightTiles: Int = 0,
        unparsedNative: Int = 0,
    ) {
        val elapsed = SystemClock.elapsedRealtime() - gateStartedMs
        MapsGLDebug.logD(
            TAG,
            "prep tick layer=$layerId gateHold=$gateHold phases=$phasesAttempted refs=$refsPrimed/$totalPhases " +
                "req=$tilesRequested parsed=$tilesParsed inFlight=$inFlightTiles unparsedNative=$unparsedNative " +
                "buildMs=$phaseBuildMs builtAny=$builtAny elapsed=${elapsed}ms",
        )
    }

    fun logGateStatusIfDue(
        layerId: String,
        refsPrimed: Int,
        totalPhases: Int,
        coords: List<TileCoord>,
        blockers: List<String>,
    ) {
        val now = SystemClock.elapsedRealtime()
        if (gateStartedMs <= 0L || now - lastStatusMs < STATUS_INTERVAL_MS) return
        lastStatusMs = now
        val elapsed = now - gateStartedMs
        val blockerText =
            if (blockers.isEmpty()) "none" else blockers.take(6).joinToString(" | ")
        MapsGLDebug.logI(
            TAG,
            "gate STATUS layer=$layerId refs=$refsPrimed/$totalPhases coords=${coords.size} " +
                "elapsed=${elapsed}ms blockers=$blockerText",
        )
    }

    fun onGateOpen(layerId: String) {
        val elapsed = if (gateStartedMs > 0L) SystemClock.elapsedRealtime() - gateStartedMs else 0L
        MapsGLDebug.logI(TAG, "gate OPEN layer=$layerId elapsed=${elapsed}ms")
        gateStartedMs = 0L
        lastStatusMs = 0L
    }

    fun logPhaseBuilt(layerId: String, snappedMs: Long, refCount: Int, elapsedMs: Long) {
        MapsGLDebug.logD(
            TAG,
            "phase BUILT layer=$layerId snappedMs=$snappedMs refs=$refCount elapsed=${elapsedMs}ms",
        )
    }

    fun logPrefetchWave(context: String, requested: Int, elapsedMs: Long, parsed: Int = 0) {
        if (requested <= 0 && parsed <= 0) return
        MapsGLDebug.logD(
            TAG,
            "prefetch $context requested=$requested parsed=$parsed elapsed=${elapsedMs}ms",
        )
    }

    fun logPhaseStoreBlocked(layerId: String, snappedMs: Long, blockers: List<String>) {
        if (blockers.isEmpty()) return
        MapsGLDebug.logD(
            TAG,
            "phase BLOCKED layer=$layerId snappedMs=$snappedMs ${blockers.take(4).joinToString(" | ")}",
        )
    }

    /** Rule: gate-hold-circuit-breaker — a layer's gate was forced open after never fully priming
     * within the timeout. See [com.xweather.mapsgl.renderers.VectorPlaybackGateController]'s
     * gate-hold-timeout constant for the rationale. */
    fun onGateForceOpened(layerId: String, timeoutMs: Long) {
        val elapsed = if (gateStartedMs > 0L) SystemClock.elapsedRealtime() - gateStartedMs else 0L
        MapsGLDebug.logW(
            TAG,
            "gate FORCE-OPEN layer=$layerId elapsed=${elapsed}ms timeout=${timeoutMs}ms — " +
                "gate never fully primed, forcing open to avoid blocking other layers; " +
                "this layer may show stale/incomplete content",
        )
        gateStartedMs = 0L
        lastStatusMs = 0L
    }
}
