package com.xweather.mapsgl.map.mapbox

import com.mapbox.geojson.Feature
import com.xweather.mapsgl.style.FillLayerPaint
import com.xweather.mapsgl.style.SortDirection
import com.xweather.mapsgl.sources.nestedDictionary
import com.xweather.mapsgl.mvt.MvtFeature

/**
 * Fill draw-order, matching JS `FillStore.sortFeatures` / Apple `FillPaint.sortKey`.
 *
 * The sort is declared on the layer paint -- [com.xweather.mapsgl.style.FillPaint.sortKey] and
 * [com.xweather.mapsgl.style.FillPaint.sortDirection] -- exactly as JS declares `fill.sort` on its
 * layer specs. That is the mechanism; a layer that declares a sort gets one, with no change here.
 */
internal object VectorFillSortDefaults {

    private const val PERIOD_MIN_TIMESTAMP = "period.range.minTimestamp"

    /**
     * Regeneration safety net, **not** the mechanism.
     *
     * The built-in threat layers declare their own sort in `Severe.kt`, but that file is
     * auto-generated from a tool outside this repo and the declaration is a hand edit. If a regen
     * drops it, these two layers keep nesting correctly instead of silently reverting to arbitrary
     * order. `ThreatFillSortSpecTest` fails in that case so the spec gets fixed rather than left
     * leaning on this table.
     *
     * Do not add layers here. Declare `sortKey`/`sortDirection` on the layer's paint instead --
     * anything added here works only for MapsGL's own layer ids and never for a consumer's.
     */
    fun sortKeyDescending(layerId: String?): String? =
        when (layerId) {
            "severe.hail.threats.fill",
            "severe.lightning.threats.fill",
            -> PERIOD_MIN_TIMESTAMP
            else -> null
        }

    internal fun propertyPath(paint: FillLayerPaint?, layerId: String?): String? {
        paint?.fill?.sortKey?.constantValue?.takeIf { it.isNotBlank() }?.let { return it }
        return sortKeyDescending(layerId)
    }

    internal fun descending(paint: FillLayerPaint?, layerId: String?): Boolean {
        val fromPaint = paint?.fill?.sortKey?.constantValue
        if (fromPaint != null) {
            return paint.fill.sortDirection == SortDirection.DESCENDING
        }
        return sortKeyDescending(layerId) != null
    }

    /**
     * JS parity: drop features missing the sort property when a property-path key is active, then
     * sort ascending or descending per [com.xweather.mapsgl.style.FillPaint.sortDirection]
     * (layer-id defaults are descending).
     */
    fun sortedFeaturesForFill(
        layerId: String?,
        features: List<Feature>,
        paint: FillLayerPaint? = null,
    ): List<Feature> {
        val key = propertyPath(paint, layerId) ?: return features
        val desc = descending(paint, layerId)
        val paired = features.mapNotNull { f ->
            val v = readEpochSeconds(f, key) ?: return@mapNotNull null
            f to v
        }
        return (if (desc) paired.sortedByDescending { it.second } else paired.sortedBy { it.second })
            .map { it.first }
    }

    fun sortedRawFeaturesForFill(
        layerId: String?,
        rawFeatures: List<MvtFeature>,
        paint: FillLayerPaint? = null,
    ): List<MvtFeature> {
        val key = propertyPath(paint, layerId) ?: return rawFeatures
        val desc = descending(paint, layerId)
        val paired = rawFeatures.mapNotNull { rf ->
            @Suppress("UNCHECKED_CAST")
            val attrs = nestedDictionary(rf.attributes as Map<String, Any>)
            val v = readEpochSecondsFromAttrs(attrs, key) ?: return@mapNotNull null
            rf to v
        }
        return (if (desc) paired.sortedByDescending { it.second } else paired.sortedBy { it.second })
            .map { it.first }
    }

    private fun readEpochSeconds(feature: Feature, dottedKey: String): Double? {
        feature.getNumberProperty(dottedKey)?.let {
            return VectorMapTime.normalizeEpochSeconds(it.toDouble())
        }
        val el = feature.properties()?.let { root ->
            if (root.has(dottedKey)) root.get(dottedKey)
            else nestedElement(root, dottedKey.split('.'))
        } ?: return null
        if (!el.isJsonPrimitive) return null
        val p = el.asJsonPrimitive
        return when {
            p.isNumber -> VectorMapTime.normalizeEpochSeconds(p.asDouble)
            p.isString -> p.asString.toDoubleOrNull()?.let { VectorMapTime.normalizeEpochSeconds(it) }
            else -> null
        }
    }

    private fun nestedElement(
        root: com.google.gson.JsonObject,
        keys: List<String>,
    ): com.google.gson.JsonElement? {
        var cur: com.google.gson.JsonElement = root
        for (segment in keys) {
            if (!cur.isJsonObject) return null
            val obj = cur.asJsonObject
            if (!obj.has(segment)) return null
            cur = obj.get(segment)!!
        }
        return cur
    }

    private fun readEpochSecondsFromAttrs(attrs: Map<String, Any>, dottedKey: String): Double? {
        attrs[dottedKey]?.let { return coerceEpoch(it) }
        val parts = dottedKey.split('.')
        var cur: Any? = attrs
        for (part in parts) {
            cur = when (cur) {
                is Map<*, *> -> cur[part]
                else -> return null
            }
        }
        return coerceEpoch(cur)
    }

    private fun coerceEpoch(value: Any?): Double? = when (value) {
        is Number -> VectorMapTime.normalizeEpochSeconds(value.toDouble())
        is String -> value.toDoubleOrNull()?.let { VectorMapTime.normalizeEpochSeconds(it) }
        else -> null
    }
}
