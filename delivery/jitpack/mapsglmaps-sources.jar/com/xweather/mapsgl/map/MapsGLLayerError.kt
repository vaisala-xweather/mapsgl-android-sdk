package com.xweather.mapsgl.map

/**
 * A layer that could not be added, or could not draw, reported on
 * [MapController.onLayerError] (and [MapController.onLayerErrorValue] for flow collectors).
 *
 * A weather layer failing never takes the host app down - see [MapController.reportLayerError] -
 * but until this callback existed the app had no way to learn it happened, so a missing layer was
 * indistinguishable from one that simply had no data. Observe this to fall back to another
 * product, drop the entry from a layer menu, or attach the driver's own words to a bug report.
 *
 * @property reason What kind of failure this is; see [Reason].
 * @property layerCode The weather layer code (e.g. `"wind-particles"`), when the failure is
 *   attributable to one; empty or null for layers added outside [MapController.addWeatherLayer].
 * @property layerId The layer's id in the map's layer stack, when it got as far as being added.
 * @property message Human-readable account of the failure. For a rejected shader this carries the
 *   driver's own info log, which is usually the only statement of what it objected to.
 * @property cause The underlying throwable, when there was one. Absent for a refusal, which is a
 *   decision rather than a failure.
 */
data class MapsGLLayerError(
    val reason: Reason,
    val layerCode: String?,
    val layerId: String?,
    val message: String,
    val cause: Throwable? = null,
) {
    /** The kinds of layer failure the SDK reports. */
    enum class Reason {
        /**
         * The layer was refused before being added because the device cannot render it - today
         * only the particle layers, which need OpenGL ES 3.1. `addWeatherLayer` returned null and
         * nothing was added. Ask [com.xweather.mapsgl.gl.GlCapabilities.supportsParticleLayers]
         * first to keep the option out of your own UI.
         */
        UNSUPPORTED_DEVICE,

        /**
         * The layer threw while rendering and will be tried again on a later frame. Transient
         * causes recover on their own (a shader that lost a setup-time race compiles cleanly a
         * moment later); a permanent one arrives again as [LAYER_DISABLED]. Usually worth logging
         * rather than reacting to.
         *
         * Also reported, once per run of failures, when the layer could not load its data - e.g. an
         * encoded source whose metadata request failed on a flaky network. The layer stays in the
         * stack without data, retries on its own and on the next camera move, and draws as soon as
         * a retry succeeds.
         */
        RENDER_FAILED,

        /**
         * The layer failed often enough to be given up on and will not draw again for the life of
         * this map. The layer is still in the stack but inert; remove it, or offer the user
         * another product.
         */
        LAYER_DISABLED,
    }

    /** One-line form suitable for a log or a bug report. */
    override fun toString(): String {
        val what = layerCode?.takeIf { it.isNotEmpty() } ?: layerId ?: "unknown layer"
        return "$reason $what: $message"
    }
}
