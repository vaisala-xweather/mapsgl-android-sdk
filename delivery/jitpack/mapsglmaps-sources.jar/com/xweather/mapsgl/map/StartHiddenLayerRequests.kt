package com.xweather.mapsgl.map

/**
 * Layer ids that must be created hidden, applied when the layer is inserted into the map.
 *
 * An encoded tile layer's Mapbox host is registered asynchronously, so the request can still be
 * pending when the app shows the layer — e.g. a data-query text layer auto-creates TEMPERATURES
 * hidden and the app then adds TEMPERATURES itself. Showing the layer cancels the request; left in
 * place, the deferred insert would hide the layer again and its color fill would never draw.
 */
internal class StartHiddenLayerRequests {
    private val ids = mutableSetOf<String>()

    /** Records that [id] must start hidden when it is inserted. */
    fun request(id: String) {
        ids.add(id)
    }

    /** Drops any pending request for [id], e.g. when its add failed. */
    fun cancel(id: String) {
        ids.remove(id)
    }

    /** A visibility change made before the insert. Only showing the layer overrides the request. */
    fun onVisibilityChanged(id: String, visible: Boolean) {
        if (visible) ids.remove(id)
    }

    /** Called once at insert: `true` if [id] must start hidden. Clears the request. */
    fun consume(id: String): Boolean = ids.remove(id)
}
