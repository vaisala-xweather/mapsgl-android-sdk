package com.xweather.mapsgl.error

// AuthenticationError definition
class AuthenticationError(
    val statusCode: Int,
    message: String
) : Error(message)