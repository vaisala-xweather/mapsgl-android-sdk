package com.xweather.mapsgl.data

class DataInspectorResult {
    var encodedTitles: MutableList<String> = mutableListOf()
    var encodedValues: MutableList<String> = mutableListOf()
    var encodedLayerIds: MutableList<String> = mutableListOf()
    var encodedRawValues: MutableList<Any> = mutableListOf()
    var vectorTitles: MutableList<String> = mutableListOf()
    var vectorValues: MutableList<String> = mutableListOf()
    var vectorLayerIds: MutableList<String> = mutableListOf()
    var vectorRawValues: MutableList<Any> = mutableListOf()

    var queriedFeatures: MutableList<com.xweather.mapsgl.layers.QueriedFeature> = mutableListOf()

    fun clearEncoded() {
        encodedTitles.clear()
        encodedValues.clear()
        encodedLayerIds.clear()
        encodedRawValues.clear()
        queriedFeatures.clear()
    }

    fun clearVector() {
        vectorTitles.clear()
        vectorValues.clear()
        queriedFeatures.clear()
        vectorLayerIds.clear()
        vectorRawValues.clear()
    }

    fun clearAll() {
        clearEncoded()
        clearVector()
    }

    fun print(message: String = "") {
        if (message != "") {
            println("DateInspectorResult print() called from $message")
        }
        println("Encoded Title ${encodedTitles}")
        println("Encoded Value ${encodedValues}")
        println("Vector Title ${vectorTitles}")
        println("Vector Value ${vectorValues}")

    }

    /*
        fun tqQueriedFeatureList() {
            val queriedList: MutableList<FeatureQueryResult> = mutableListOf()
            var i = 0
            for (item in encodedTitles) {

                var queriedFeature = QueriedFeature(feature = encodedValues[i], value = encodedValues[i])
                val fr = FeatureQueryResult(item, encodedValues[i])
                i++
                queriedList.add(fr)
            }
        }
    */


    fun toHashMap(): HashMap<String, List<Any>> {
        val returnHash: HashMap<String, List<Any>> = hashMapOf()

        for ((i, eTitle) in encodedLayerIds.withIndex()) {
            val value = encodedRawValues[i]

            returnHash[eTitle] = listOf(value)
        }

        for ((i, vTitle) in vectorTitles.withIndex()) {
            val value = vectorValues[i]
            returnHash[vTitle] = listOf(value)
        }

        return returnHash
    }


    override fun toString(): String {
        var returnString = ""
        var encodedFound = false
        for ((i, eTitle) in encodedTitles.withIndex()) {
            encodedFound = true
            if (i > 0) returnString += "\n"
            returnString += eTitle + ": " + encodedValues[i]
        }

        for ((i, vTitle) in vectorTitles.withIndex()) {
            if (i > 0) returnString += "\n"
            else if (encodedFound) returnString += "\n"
            returnString += vTitle + ": " + vectorValues[i]
        }

        return returnString
    }
}