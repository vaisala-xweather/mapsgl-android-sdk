package com.xweather.mapsgl.data

import java.util.Date

/**
 * A collection of grids keyed by their valid `Date` timestamps, enabling temporal interpolation.
 * Note: This type is date‑keyed (dictionary) rather than index‑based; the caller supplies ordering via `GriddedQueryOptions`.
 */
data class GriddedTimeSeriesValueData(
    val grids: Map<Date, GriddedValueData>
) {
    /**
     * Queries the time‑series at (x,y) and blends across two intervals when options are provided.
     * - Parameters:
     *   - x: Pixel X in the tile’s pixel space.
     *   - y: Pixel Y in the tile’s pixel space.
     *   - options: Options to use when performing the query, such as pixel and temporal interpolation.
     * - Returns: The blended value, or `nil` if no valid sample could be obtained.
     * - Discussion: The method looks up `current.date` and `next.date` inside `grids`, samples both using `interpolation`,
     *   and linearly interpolates the two results using `progress` in [0,1]. If only one side is valid, it returns that side.
     */
    fun query(x: Double, y: Double, options: GriddedQueryOptions): GriddedValueData.GriddedPoint? {
        if (grids.isEmpty()) return null

        val currentTargetDate: Date?
        val nextTargetDate: Date?
        val progress = options.progress

        if (options.current != null && options.next != null) {
            currentTargetDate = options.current!!.second // current.date
            nextTargetDate = options.next!!.second    // next.date
        } else {
            // When no filter is provided, default to the earliest available grid without temporal blending.
            // Ensure grids is not empty here (already checked, but good for local reasoning)
            val sortedKeys = grids.keys.sorted()
            if (sortedKeys.isEmpty()) return null // Should not happen if grids is not empty

            currentTargetDate = sortedKeys.first()
            nextTargetDate = currentTargetDate // No temporal blending, progress will be ignored or should be 0
        }

        // If either date is somehow still null (e.g. if options.current/next could be non-null but their .second is null)
        // This case should be handled by the structure of options.current being Pair<Int, Date>?
        if (currentTargetDate == null) return null // Or handle differently

        val v0 = grids[currentTargetDate]?.query(x = x, y = y, interpolation = options.interpolation)
        val v1 = if (nextTargetDate != null && nextTargetDate != currentTargetDate) {
            grids[nextTargetDate]?.query(x = x, y = y, interpolation = options.interpolation)
        } else {
            v0 // If nextDate is same as current, or null, use v0 for v1 to simplify blending logic
        }

        // Blend when both samples are valid; otherwise choose the valid side. If neither is valid, return null.
        return when {
            v0 != null && v1 != null -> v0.interpolatedTo(v1, t = progress)
            v0 != null -> v0
            v1 != null -> v1 // This case might only happen if progress=1 and v0 was null
            else -> null
        }
    }
}