package com.xweather.mapsgl.data

import com.xweather.mapsgl.anim.EventDispatcher
import com.xweather.mapsgl.events.Event
import com.xweather.mapsgl.events.TimeSeriesEvent
import kotlinx.coroutines.*
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

typealias Task<T> = suspend () -> T

data class QueueEventData(
    val queue: Queue<*>,
    val index: Int,
    val task: Task<*>,
    val result: Any?,
    val error: Throwable?
)

class QueueEvent(name: String, data: QueueEventData? = null) : Event

//open class Event(val name: String, val data: Any? = null)
/*
open class EventDispatcher {
    val eventFlow = MutableSharedFlow<Event>()

    fun trigger(event: Event) {
        eventFlow.tryEmit(event)
    }
}*/

class Queue<T>(options: QueueOptions = QueueOptionsImpl()) : EventDispatcher() {
    data class Progress(
        val total: Int,
        val completed: Int = 0,
        val failed: Int = 0,
        val cancelled: Int = 0
    ) {
        companion object {
            val zero: Progress = Progress(total = 0)
        }
    }

    private val tasks = ConcurrentLinkedQueue<Task<T>>()
    private val concurrency = options.concurrency.coerceAtLeast(1)
    private val autostart = options.autostart

    /**
     * One scope for the queue's lifetime. [start] previously built a fresh
     * `CoroutineScope(Dispatchers.Default)` on every drive, so each one leaked a scope that was
     * never cancelled.
     */
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Guards against two concurrent drain loops on the same queue. */
    private val draining = AtomicBoolean(false)

    @Volatile
    private var running = false

    /**
     * In-flight task count. This was previously never incremented, only decremented, so it went
     * negative on the first completion; `pending == 0` could then never hold again, [done] never
     * fired, [running] stayed `true` forever and [start] became a permanent no-op. The queue
     * accumulated every later [enqueue] without ever draining.
     */
    private val pending = AtomicInteger(0)
    private val index = AtomicInteger(-1)

    val length: Int get() = tasks.size
    val isRunning: Boolean get() = running
    val currentIndex: Int get() = index.get()
    val currentTask: Task<T>? get() = tasks.elementAtOrNull(index.get())
    val last: Task<T>? get() = tasks.last() // todo: maybe tasks.peek would be better?

    fun enqueue(vararg tasks: Task<T>): Queue<T> {
        this.tasks.addAll(tasks.toList())
        if (autostart) start()
        return this
    }
    /*
    fun dequeue(arg: Any?): Task<T>? = when (arg) {
        is Int -> dequeueByIndex(arg)
        is Task<*> -> dequeueByTask(arg as Task<T>)
        else -> dequeueByIndex(tasks.size -1) // Default: remove last if arg is not specified
    }
    */
    fun peek(): Task<T>? = tasks.peek()

    fun start() {
        scope.launch { drainNow() }
    }

    fun pause() = stop()
    fun resume() = start()
    fun stop() { running = false }


    fun cancel() {
        val wasRunning = running
        clear()
        if (wasRunning) trigger(QueueEvent("cancel"))
    }

    fun clear() {
        stop()
        pending.set(0)
        index.set(-1)
        tasks.clear()
    }


    /*
    private fun dequeueByIndex(index: Int): Task<T>? = tasks.removeAt(index)

    private fun dequeueByTask(task: Task<T>): Task<T>? {
        val index = tasks.indexOf(task)
        return if (index != -1) dequeueByIndex(index) else null
    }*/

    /**
     * Drains this queue to empty, suspending until it is. Safe to call concurrently: the second
     * caller returns immediately because a drain is already in flight.
     *
     * Used by [QueueCollection] to run its queues one after another. [EventDispatcher.on] is a
     * stub that registers nothing, so a completion *event* cannot drive that hand-off.
     */
    internal suspend fun drainNow() {
        if (!draining.compareAndSet(false, true)) return
        running = true
        try {
            drainLoop()
        } finally {
            draining.set(false)
        }
    }

    /**
     * Polls and runs tasks until the queue is empty or [stop] is called.
     *
     * The previous implementation ran **exactly one** task per drive and left the redrive
     * commented out (`//else if (running) run()`), which — together with the never-incremented
     * `pending` above — is why a queue executed a single task for its entire lifetime and then
     * grew without bound. A soak heap dump on 2026-08-24 found 2.65M retained task closures
     * (~179MB) in this state.
     *
     * At most one task is in flight per drain, which is no more concurrency than the old code ever
     * reached, so this cannot introduce a thundering herd of requests.
     */
    private suspend fun drainLoop() {
        var triggerStartEvent = true
        while (running) {
            if (pending.get() >= concurrency) return

            val task = tasks.poll()
            if (task == null) {
                if (pending.get() == 0) done()
                return
            }

            if (triggerStartEvent) {
                trigger(QueueEvent("start"))
                triggerStartEvent = false
            }

            val i = index.incrementAndGet()
            pending.incrementAndGet()
            try {
                val result = withContext(Dispatchers.IO) { task() }
                trigger(QueueEvent("task:complete", QueueEventData(this@Queue, i, task, result, null)))
            } catch (e: Throwable) {
                trigger(QueueEvent("error", QueueEventData(this@Queue, i, task, null, e)))
            } finally {
                pending.decrementAndGet()
            }
        }
    }

    private fun done() {
        if (!running) return
        running = false
        trigger(QueueEvent("complete"))
    }

    private val listeners = mutableMapOf<TimeSeriesEvent, MutableList<(Event) -> Unit>>()


}

//data class QueueOptionsImpl(override val concurrency: Int = Int.MAX_VALUE, override val autostart: Boolean = false) : QueueOptions