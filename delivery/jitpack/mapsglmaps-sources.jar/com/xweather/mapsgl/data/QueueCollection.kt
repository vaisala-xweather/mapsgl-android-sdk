package com.xweather.mapsgl.data

import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.TimeSeriesEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow

//class QueueEvent(name: String, data: Map<String, Any?>? = null) : Event(name, data)

//open class Event(val name: String, val data: Any? = null)

/*
open class EventDispatcher {
    val eventFlow = MutableSharedFlow<Event>()

    fun trigger(event: Event) {
        eventFlow.tryEmit(event)
    }

    fun <T : Event> on(eventName: String, listener: (T) -> Unit) {
        //Implementation using eventFlow and filterIsInstance for this listener to be called.
        //See next example for a basic implementation
    }

    fun <T : Event> off(eventName: String, listener: (T) -> Unit) {
        //Implementation for removing a listener
    }
}*/

class QueueCollection<T>(private val options: QueueOptions = QueueOptionsImpl()) : EventDispatcher() {
    private val queues = mutableListOf<Queue<T>>()

    /** One scope for the collection's lifetime, rather than a fresh leaked one per drive. */
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile
    private var running = false
    private var index = -1

    val length: Int get() = synchronized(queues) { queues.size }
    val isRunning: Boolean get() = running

    // `queues` is pushed to from loader coroutines while the drive loop pops from it, so every
    // access is guarded. Torn reads of shared collections on this path have caused real crashes.
    fun push(queue: Queue<T>) { synchronized(queues) { queues.add(queue) } }
    fun unshift(queue: Queue<T>) { synchronized(queues) { queues.add(0, queue) } }

    fun start() {
        if (running) return
        run()
    }

    fun pause() { running = false }
    fun resume() = start()
    fun stop() = pause()


    fun cancel() {
        val wasRunning = running
        clear()
        if (wasRunning) trigger(QueueEvent("cancel"))
    }

    fun clear() {
        index = -1
        stop()
        synchronized(queues) {
            queues.forEach { it.clear() }
            queues.clear()
        }
    }

    /**
     * Runs the collection's queues one after another until none are left.
     *
     * This used to pop a single queue, call [Queue.start] on it and return. Advancing to the next
     * queue was only reachable from [next], which in turn was only called from the commented-out
     * `onQueueComplete` handler below — so a collection drained at most one queue, ever, and every
     * queue pushed afterwards was retained untouched. Combined with the fact that nothing ever
     * called `start()` on the background collection at all, this was a large part of the 2.65M
     * retained task closures found in the 2026-08-24 soak heap dump.
     *
     * [EventDispatcher.on] registers nothing (it returns `this`), so the hand-off cannot be
     * event-driven; [Queue.drainNow] is awaited directly instead. Queues run sequentially, which
     * is what the original chunk ordering assumes.
     */
    private fun run() = scope.launch {
        val triggerStartEvent = !running
        running = true

        if (triggerStartEvent) trigger(TimeSeriesEvent.LOAD_START)//("start", mapOf("index" to index)))

        while (running) {
            val queue = synchronized(queues) { if (queues.isEmpty()) null else queues.removeAt(0) } ?: break
            index++
            queue.drainNow()
        }

        done()
    }

    /*
    private fun onQueueStart(e: QueueEvent) {
        trigger(QueueEvent("queue:start", mapOf("queue" to e.target, "index" to index)))
    }

    private fun onQueueComplete(e: QueueEvent) {
        if (!running) return
        val queue = e.target as Queue<T>
        queue.off("start", ::onQueueStart)
        queue.off("complete", ::onQueueComplete)
        queue.off("error", ::onQueueError)
        trigger(QueueEvent("queue:complete", mapOf("queue" to queue, "index" to index)))
        next()
    }

    private fun onQueueError(e: QueueEvent) {
        trigger(QueueEvent("queue:error", mapOf("queue" to e.target, "index" to index)))
    }
    */
    private fun next() {
        if (queues.isEmpty()) done() else if (running) run()
    }

    private fun done() {
        stop()
        trigger(QueueEvent("complete"))
    }

}


interface QueueOptions {
    val concurrency: Int
    val autostart: Boolean
}


data class QueueOptionsImpl(override val concurrency: Int = Int.MAX_VALUE, override val autostart: Boolean = false) : QueueOptions