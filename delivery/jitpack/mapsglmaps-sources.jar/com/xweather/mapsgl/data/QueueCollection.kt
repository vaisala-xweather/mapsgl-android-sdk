package com.xweather.mapsgl.data

import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.TimeSeriesEvent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow

//class QueueEvent(name: String, data: Map<String, Any?>? = null) : Event(name, data)

//open class Event(val name: String, val data: Any? = null)

/*
open class EventDispatcher {
    val eventFlow = MutableSharedFlow<Event>()

    fun trigger(event: Event) {
        eventFlow.tryEmit(event)
    }

    fun <T : Event> on(eventName: String, listener: (T) -> Unit) {
        //Implementation using eventFlow and filterIsInstance for this listener to be called.
        //See next example for a basic implementation
    }

    fun <T : Event> off(eventName: String, listener: (T) -> Unit) {
        //Implementation for removing a listener
    }
}*/

class QueueCollection<T>(private val options: QueueOptions = QueueOptionsImpl()) : EventDispatcher() {
    private val queues = mutableListOf<Queue<T>>()
    private var running = false
    private var index = -1

    val length: Int get() = queues.size
    val isRunning: Boolean get() = running

    fun push(queue: Queue<T>) { queues.add(queue) }
    fun unshift(queue: Queue<T>) { queues.add(0, queue) }

    fun start() {
        if (running) return
        run()
    }

    fun pause() { running = false }
    fun resume() = start()
    fun stop() = pause()


    fun cancel() {
        val wasRunning = running
        clear()
        if (wasRunning) trigger(QueueEvent("cancel"))
    }

    fun clear() {
        index = -1
        stop()
        queues.forEach { it.clear() }
        queues.clear()
    }

    private fun run() = CoroutineScope(Dispatchers.Default).launch {
        val triggerStartEvent = !running
        running = true

        if (queues.isEmpty()) {
            done()
            return@launch
        }

        index++

        if (triggerStartEvent) trigger(TimeSeriesEvent.LOAD_START)//("start", mapOf("index" to index)))

        val queue = queues.removeAt(0)
        //queue.on("start") { event -> onQueueStart(event as QueueEvent) }
        //queue.on("complete") { event -> onQueueComplete(event as QueueEvent) }
        //queue. on("error") { event -> onQueueError(event as QueueEvent) }
        queue.start()
    }

    /*
    private fun onQueueStart(e: QueueEvent) {
        trigger(QueueEvent("queue:start", mapOf("queue" to e.target, "index" to index)))
    }

    private fun onQueueComplete(e: QueueEvent) {
        if (!running) return
        val queue = e.target as Queue<T>
        queue.off("start", ::onQueueStart)
        queue.off("complete", ::onQueueComplete)
        queue.off("error", ::onQueueError)
        trigger(QueueEvent("queue:complete", mapOf("queue" to queue, "index" to index)))
        next()
    }

    private fun onQueueError(e: QueueEvent) {
        trigger(QueueEvent("queue:error", mapOf("queue" to e.target, "index" to index)))
    }
    */
    private fun next() {
        if (queues.isEmpty()) done() else if (running) run()
    }

    private fun done() {
        stop()
        trigger(QueueEvent("complete"))
    }

}


interface QueueOptions {
    val concurrency: Int
    val autostart: Boolean
}


data class QueueOptionsImpl(override val concurrency: Int = Int.MAX_VALUE, override val autostart: Boolean = false) : QueueOptions