package com.xweather.mapsgl.data.series

import java.util.*
import kotlin.collections.HashMap
import kotlin.collections.MutableList
import kotlin.collections.set
import kotlin.math.abs

// Data is stored in a time series by Date.getTime() converted to a string
typealias TimeIntervalKey = String

typealias TimeInterval = Long

/**
 * A type that represents a time range.
 */

data class TimeRange(
    /**
     * The start of the time range.
     */
    val start: Date,

    /**
     * The end of the time range.
     */
    val end: Date
)

/**
 * A class that represents a time series data entry.
 * @internal
 */
class TimeSeriesEntry<Data>(
    /**
     * The data associated with the time series entry.
     */
    var data: Data?
) {
    /**
     * The index of the time series entry.
     */
    var index = -1

    /**
     * The index of the current time series entry.
     */
    var current = -1

    /**
     * The index of the next time series entry that contains data.
     */
    var next = -1
}

/**
 * @internal
 */
typealias SeriesData<Data> = HashMap<TimeIntervalKey, TimeSeriesEntry<Data>>

/**
 * A class that represents a time series of data.
 * @internal
 */
class TimeSeries<Data>(data: HashMap<TimeIntervalKey, Data /*TimeSeriesAnimatorData*/>? = null) {
    private val _data: SeriesData</*TimeSeriesAnimator*/Data> = HashMap()
    private val _intervals: MutableList<TimeInterval> = mutableListOf()

    init {
        setData(data)
    }

    /**
     * The time intervals for the time series.
     */
    val intervals: MutableList<TimeInterval>
        get() = _intervals.toMutableList()

    /**
     * The number of entries in the time series.
     * @readonly
     */
    val count: Int
        get() = _data.size

    /**
     * The number of entries in the time series that contain valid data.
     * @readonly
     */
    val validCount: Int
        get() = _data.values.count { it.data != null }

    /**
     * The time range covered by the time series.
     * @readonly
     */
    val timeRange: TimeRange
        get() {
            if (_intervals.isEmpty()) {
                return TimeRange(Date(0), Date(0))
            }
            return TimeRange(Date(_intervals[0]), Date(_intervals.last()))
        }

    /** The data associated with the time series.   */
    val data: SeriesData</*TimeSeriesAnimator*/Data>
        get() = HashMap(_data)

    /** Sets the data for the time series.
     * @remarks
     * The data is expected to be an object where the keys are the time intervals and the values are the data
     * associated with the time intervals. Each entry is then converted into the appropriate `TimeSeriesEntry` type.
     * @param data - The data to set for the time series.   */
    fun setData(data: HashMap<TimeIntervalKey, /*TimeSeriesAnimator*/Data>?) {
        _data.clear()
        data?.let {
            it.forEach { (key, value) ->
                _data[key] = TimeSeriesEntry(value)
            }
        }
        _generateIntervalsFromData()
    }

    fun setDataAny(data: HashMap<String, /*TimeSeriesAnimator*/Any>?) {
        _data.clear()
        data?.let {
            it.forEach { (key, value) ->
                _data[key] = TimeSeriesEntry(value as Data)
            }
        }
        _generateIntervalsFromData()
    }

    //    HashMap<String, Any>

    fun appendData(data: SeriesData</*TimeSeriesAnimator*/Data>) {
        data.forEach { (interval, entry) ->
            _data[interval] = entry
        }
        _generateIntervalsFromData()
    }

    /** Sets the data for the specified time interval in the time series.
     * @param interval - The time interval to set the data for.
     * @param data - The data to set for the time interval.
     * @param createIfMissing - Whether to create the time interval if it doesn't exist in the time series. Default
     * is `false`.  */
    fun setDataForInterval(interval: TimeInterval, data: Data?, createIfMissing: Boolean = false) {
        val entry = _data[interval.toString()]
        if (entry != null) {
            entry.data = data// as Data /*TimeSeriesAnimatorData*/
        } else if (createIfMissing) {
            appendData(hashMapOf(interval.toString() to TimeSeriesEntry(data)))
        } else {
            println(
                "[MapsGL] Cannot set time series data for interval $interval because it does not exist and `createIfMissing` is false."
            )
        }
    }

    /** Returns whether the time series contains data for the specified time interval.
     * @param interval - The time interval to check for data.
     * @param checkValid - unused
     * @returns True if the time series contains data for the specified time interval, otherwise false.     */
    fun hasDataForInterval(interval: TimeInterval, checkValid: Boolean = false): Boolean {
        if (_data.isEmpty()) {
            return false
        }
        return _data[interval.toString()] != null
    }

    /**
     * Returns the time series entry for the specified interval if exists.
     * @param interval - The time interval to get the entry for.
     * @returns
     */
    fun entryForInterval(interval: TimeInterval): TimeSeriesEntry</*TimeSeriesAnimator*/Data>? {
        return _data[interval.toString()]
    }

    /**
     * Returns the data associated with the specified interval in the time series.
     * @param interval - The time interval to get the data for.
     * @returns The data associated with the specified interval.
     */
    fun dataForInterval(interval: TimeInterval): /*TimeSeriesAnimator*/Data? {
        return dataForTimeInterval(interval)
    }

    /**
     * Returns the data associated with the specified time interval in the time series.
     * @param interval - The time interval to get the data for.
     * @returns The data associated with the specified time interval.
     */
    fun dataForTimeInterval(interval: TimeInterval): Data? {
        return _data[interval.toString()]?.data
    }

    /**
     * Returns the data associated with the specified index in the time series.
     * @param index - The index of the data to return.
     * @returns The data associated with the specified index.
     */
    fun dataAtIndex(index: Int): /*TimeSeriesAnimator*/Data? {
        val keys = _data.keys.toList()
        if (index in 0 until keys.size) {
            return _data[keys[index]]?.data
        }
        return null
    }

    /**
     * Returns the time interval at the specified index in the time series.
     * @param index - The index of the time interval to return.
     * @returns The time interval at the specified index.
     */
    fun intervalAtIndex(index: Int): TimeInterval? {
        if (index in 0 until _intervals.size) {
            return _intervals[index]
        }
        return null
    }

    /**
     * Returns the time intervals within the specified range for the time series.
     * If `includeStops` is true, then the start and end values will be allowed in the returned
     * set of time intervals. Default is `true`.
     * @param start - The start of the time range.
     * @param end - The end of the time range.
     * @param includeStops - Whether to include the start and end values in the returned set of time intervals.
     * @returns An array of time intervals within the specified range.
     */
    fun intervalsInRange(start: Date, end: Date, includeStops: Boolean = true): MutableList<TimeInterval> {
        return _intervals.filter { interval ->
            if (includeStops) {
                interval >= start.time && interval <= end.time
            } else {
                interval > start.time && interval < end.time
            }
        }.toMutableList()
    }

    /**
     * Returns the interval closest to the provided date within the time series.
     * @param date - The date to find the closest interval to.
     * @returns An object containing the closest interval and its index in the time series.
     */
    fun closestInterval(date: Date): Pair<TimeInterval?, Int> {
        if (_intervals.isEmpty()) {
            return Pair(null, -1)
        }
        val t = date.time
        var closest = _intervals[0]
        var closestIndex = 0
        var delta = abs(t - closest)

        // Find the closest interval to the provided `time` that isn't greater than `time`
        // but is also greater than our last time (so we don't go backwards)
        _intervals.forEachIndexed { i, interval ->
            val tt = interval
            val tdelta = t - tt

            // Only allow intervals equal to or less than the requested time and that
            // have valid data associated with their time interval
            if (tdelta in 0..delta) {
                delta = tdelta
                closest = interval
                closestIndex = i
                // foundData = true;
            }
        }
        return Pair(closest, closestIndex)
    }

    /**
     * Returns an array of time intervals that do not have data associated with them based on the passed array of
     * intervals. If no intervals are provided, then the current intervals for the time series are used.
     * @param intervals - The time intervals to check for data. If no intervals are provided, then the current
     * intervals for the time series are used.
     * @returns An array of time intervals that do not have data associated with them.
     */
    fun intervalsNeedingData(intervals: List<TimeInterval> = this.intervals): List<TimeInterval> {
        return intervals.filter { interval ->
            !hasDataForInterval(interval)
        }
    }

    /**
     * Removes the time interval and associated data from the time series.
     * @param interval - The time interval to remove from the time series.
     */
    fun removeInterval(interval: TimeInterval) {
        _data.remove(interval.toString())
        _generateIntervalsFromData()
    }

    /**
     * Clears the data associated with the time series.
     */
    fun invalidate() {
        _data.clear()
    }

    private fun _generateIntervalsFromData() {
        // Since data is being set directly, we need to also update the step intervals we have
        // data for based on the time keys
        _intervals.clear()
        _intervals.addAll(_data.keys.map { it.toLong() }.sorted())
    }

    // Snapshot code ================================================================================

    val points: List<TimeSeriesPoint>

    init {

        // Sort the incoming points by timestamp during initialization
        this.points = mutableListOf()// incomingPoints.sortedBy { it.timestamp }
    }

    /**
     * Returns a snapshot of the points. Since 'points' is already a read-only List
     * and represents the sorted state, we can return it directly.
     * If true snapshot semantics (a new list instance) are strictly needed,
     * one could use 'points.toList()', but it's often not necessary if 'points'
     * itself is an immutable view.
     */
    fun snapshot(): List<TimeSeriesPoint> {
        return points // Returns the read-only, sorted list
        // Or for a new list instance: return points.toList()
    }

    /**
     * Returns the number of points in the collection.
     * Can also be a property.
     */
    fun count(): Int {
        return points.size
    }

    // Alternative: 'count' as a property
    val size: Int
        get() = points.size


}

data class TimeSeriesPoint(
    val timestamp: Date,
    val value: Value // 'Value' should be your actual type for the value
)

// --- Example Usage (assuming Value is Double for this example) ---
typealias Value = Double? // Making Value nullable as well, if that's the case for the property

/**
 * @internal
 */
typealias AnyTimeSeries = TimeSeries<Data>