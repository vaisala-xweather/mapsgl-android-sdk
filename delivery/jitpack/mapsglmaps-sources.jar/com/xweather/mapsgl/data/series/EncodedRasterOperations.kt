package com.xweather.mapsgl.data.series

import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Per-pixel folding of an encoded raster time series into a single aggregated raster.
 *
 * This is what backs the `*-accum`, `*-max` and `*-min` weather layers. Where an ordinary sample
 * layer draws one interval at a time, an operation layer walks every interval in the series and
 * combines them pixel by pixel — summing precipitation to get an accumulation, or taking the running
 * maximum to get a period high.
 *
 * Ported from the MapsGL JS `utils/operations` module so results match across platforms.
 *
 * ## Precision
 *
 * Encoded values arrive as 8-bit bands, and a value may be spread across several bands to buy extra
 * range (sleet and ice spread one value across `rgb`). Folding in the encoded domain would requantise
 * on every interval and drift badly over a long series, so [fold] decodes each interval to the real
 * data domain, accumulates in [DoubleArray] precision, and re-encodes only at the end of each step.
 *
 * ## Saturation
 *
 * Without [OperationContext.remappedDataRange] the accumulated value is re-encoded into the *source*
 * range, so a long enough series clamps at that maximum. That is deliberate and matches JS, where the
 * remapped range is currently commented out for the accumulation layers.
 */
internal object EncodedRasterOperations {

    /** How consecutive intervals are combined. */
    public enum class Operation {
        /** Running total. Precipitation accumulation and similar. */
        SUM,

        /** Running mean over the number of intervals folded. */
        AVERAGE,

        /** Running maximum. */
        MAX,

        /** Running minimum. */
        MIN,
    }

    /** Inclusive real-world range an encoded band maps onto. */
    public data class DataRange(val min: Double, val max: Double) {
        val delta: Double get() = max - min
    }

    /**
     * Everything a fold needs that does not change between intervals.
     *
     * @property operation How to combine consecutive intervals.
     * @property dataRange The real-world range the source bands decode against.
     * @property bandsPerValue How many consecutive bands one value is spread across: 1 for a plain
     * single-band product, 3 for a value encoded across `rgb`.
     * @property remappedDataRange Range to encode the *result* into, when the aggregate needs more
     * headroom than the source range. Null re-encodes into [dataRange], which clamps.
     * @property valueMultiplier Scale applied to each interval's decoded value before it is combined,
     * for products whose interval step is not one unit.
     */
    public data class OperationContext(
        val operation: Operation,
        val dataRange: DataRange,
        val bandsPerValue: Int = 1,
        val remappedDataRange: DataRange? = null,
        val valueMultiplier: Double = 1.0,
    ) {
        /** The range results are encoded into. */
        val outputRange: DataRange get() = remappedDataRange ?: dataRange

        init {
            require(bandsPerValue in 1..4) { "bandsPerValue must be 1..4, was $bandsPerValue" }
        }
    }

    /**
     * Running state for one tile across a fold. Allocate once per tile, then feed intervals in
     * chronological order.
     *
     * @property pixelCount Number of pixels in the padded tile.
     */
    public class Accumulator(
        public val pixelCount: Int,
        private val context: OperationContext,
    ) {
        /** Accumulated value per pixel, in the real data domain. */
        private val values = DoubleArray(pixelCount)

        /** Number of intervals folded so far, needed for [Operation.AVERAGE]. */
        public var intervalCount: Int = 0
            private set

        private var seeded = false

        /**
         * Folds one interval's padded RGBA bytes into the running state.
         *
         * Intervals must arrive in chronological order. Anything that fails to decode is skipped
         * rather than treated as zero, so a missing interval does not pull an average down or reset a
         * running minimum.
         *
         * @param weight Multiplies this interval's contribution. See [timeWeight].
         */
        public fun add(rawData: ByteArray, weight: Double = 1.0) {
            if (rawData.size < pixelCount * 4) return
            val bands = context.bandsPerValue
            val multiplier = context.valueMultiplier * weight
            for (n in 0 until pixelCount) {
                val decoded = decodePixelValue(rawData, n, bands, context.dataRange)
                val value = when (context.operation) {
                    // A rate times elapsed hours is a quantity, so weighting is the whole point of a
                    // sum. A weighted maximum is not a meaningful number, so the extremes take the
                    // value as it stands.
                    Operation.SUM, Operation.AVERAGE -> decoded * multiplier
                    Operation.MAX, Operation.MIN -> decoded * context.valueMultiplier
                }
                values[n] =
                    if (!seeded) {
                        value
                    } else {
                        when (context.operation) {
                            Operation.SUM, Operation.AVERAGE -> values[n] + value
                            Operation.MAX -> max(values[n], value)
                            Operation.MIN -> min(values[n], value)
                        }
                    }
            }
            seeded = true
            intervalCount++
        }

        /** Writes the running aggregate into [target], which must be a padded RGBA buffer. */
        public fun encodeInto(target: ByteArray) {
            if (target.size < pixelCount * 4) return
            val bands = context.bandsPerValue
            val range = context.outputRange
            val divisor = if (context.operation == Operation.AVERAGE && intervalCount > 0) {
                intervalCount.toDouble()
            } else {
                1.0
            }
            val encoded = IntArray(bands)
            for (n in 0 until pixelCount) {
                encodePixelValue(values[n] / divisor, range, bands, encoded)
                val offset = n * 4
                for (b in 0 until bands) {
                    target[offset + b] = encoded[b].toByte()
                }
                target[offset + 3] = 255.toByte()
            }
        }

        /**
         * Encodes the aggregate into a fresh padded RGBA buffer.
         *
         * Alpha is pinned to 255: it never carries data, matching the encoding every other platform
         * uses for these products.
         */
        public fun encode(): ByteArray = ByteArray(pixelCount * 4).also { encodeInto(it) }
    }

    /** One interval of a tile's series: when it is valid for, and its padded RGBA bytes. */
    public data class IntervalData(
        val timeMillis: Long,
        val rawData: ByteArray,
    ) {
        // Identity semantics: rawData is a mutable buffer rewritten in place by foldSeries.
        override fun equals(other: Any?): Boolean = this === other

        override fun hashCode(): Int = System.identityHashCode(this)
    }

    /**
     * Elapsed hours between consecutive intervals, used to weight a rate into a quantity.
     *
     * Deltas of a second or less are treated as unweighted: those keys are interval *indices* rather
     * than real timestamps, so there is no duration to scale by.
     */
    internal fun timeWeight(previousMillis: Long, currentMillis: Long): Double {
        val delta = currentMillis - previousMillis
        return if (delta > 1000L) delta / 3_600_000.0 else 1.0
    }

    /**
     * Folds a tile's whole series, rewriting **each interval in place** with the aggregate up to and
     * including that interval.
     *
     * This is what makes an accumulation layer animate: the series stays a series, and frame `n` holds
     * the running total through frame `n`, so scrubbing the timeline watches the accumulation build
     * rather than jumping to a single final figure.
     *
     * @param intervals The tile's intervals; sorted chronologically here, so callers need not.
     * @return How many intervals were folded.
     */
    public fun foldSeries(
        intervals: List<IntervalData>,
        pixelCount: Int,
        context: OperationContext,
    ): Int {
        if (intervals.isEmpty()) return 0
        val ordered = intervals.sortedBy { it.timeMillis }
        val accumulator = Accumulator(pixelCount, context)
        var previousMillis: Long? = null
        for (entry in ordered) {
            val weight = previousMillis?.let { timeWeight(it, entry.timeMillis) } ?: 1.0
            accumulator.add(entry.rawData, weight)
            // Write the running aggregate back over this interval's own pixels.
            accumulator.encodeInto(entry.rawData)
            previousMillis = entry.timeMillis
        }
        return accumulator.intervalCount
    }

    /**
     * Folds a whole series in one call.
     *
     * @param intervals Padded RGBA buffers in chronological order.
     * @return The aggregated raster, or null when [intervals] is empty.
     */
    public fun fold(
        intervals: List<ByteArray>,
        pixelCount: Int,
        context: OperationContext,
    ): ByteArray? {
        if (intervals.isEmpty()) return null
        val accumulator = Accumulator(pixelCount, context)
        for (interval in intervals) {
            accumulator.add(interval)
        }
        if (accumulator.intervalCount == 0) return null
        return accumulator.encode()
    }

    /**
     * Decodes one pixel's value, summing across the bands it is spread over.
     *
     * A value spread across `n` bands uses the total of those bands against a maximum of `n * 255`,
     * which is the inverse of [encodePixelValue].
     */
    public fun decodePixelValue(
        rawData: ByteArray,
        pixelIndex: Int,
        bandsPerValue: Int,
        dataRange: DataRange,
    ): Double {
        val offset = pixelIndex * 4
        var total = 0
        for (b in 0 until bandsPerValue) {
            total += rawData[offset + b].toInt() and 0xFF
        }
        val position = total.toDouble() / (255.0 * bandsPerValue)
        return dataRange.min + dataRange.delta * position
    }

    /**
     * Encodes a value into [bandsPerValue] consecutive bands, filling each to 255 before spilling into
     * the next. Values outside [dataRange] clamp.
     *
     * @param out Reused output buffer; must hold at least [bandsPerValue] entries.
     */
    public fun encodePixelValue(
        value: Double,
        dataRange: DataRange,
        bandsPerValue: Int,
        out: IntArray,
    ) {
        val clamped = min(max(value, dataRange.min), dataRange.max)
        val position = if (dataRange.delta > 0) (clamped - dataRange.min) / dataRange.delta else 0.0
        var remaining = (position * 255.0 * bandsPerValue).roundToInt()
        for (b in 0 until bandsPerValue) {
            val bandValue = min(255, remaining)
            out[b] = bandValue
            remaining = max(0, remaining - 255)
        }
    }
}
