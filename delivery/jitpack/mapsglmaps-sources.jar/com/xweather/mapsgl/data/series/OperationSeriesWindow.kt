package com.xweather.mapsgl.data.series

/**
 * The intervals of a sorted series that fall inside the timeline window, both ends inclusive.
 *
 * An operation layer folds only these. A null bound leaves that side open, which is what a source
 * whose window is not yet known gets: the whole series, as before.
 *
 * @param intervals (request string, epoch millis) pairs, in any order; the result keeps that order.
 */
internal fun <T> foldWindow(
    intervals: List<Pair<T, Long>>,
    startMillis: Long?,
    endMillis: Long?,
): List<Pair<T, Long>> {
    if (startMillis == null && endMillis == null) return intervals
    return intervals.filter { (_, millis) ->
        (startMillis == null || millis >= startMillis) && (endMillis == null || millis <= endMillis)
    }
}
