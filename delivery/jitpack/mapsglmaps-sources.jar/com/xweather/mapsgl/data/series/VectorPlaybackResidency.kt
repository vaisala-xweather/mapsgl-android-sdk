package com.xweather.mapsgl.data.series

import kotlin.math.ceil

/**
 * iOS [TiledTimeSeriesDataProvider] interval LRU: capacity is 1.5× the visible tile count so
 * playback can still evict coords that have left the viewport without dropping on-screen tiles.
 */
internal fun intervalLruCapacityForVisibleTiles(visibleCount: Int): Int =
    ceil(visibleCount.coerceAtLeast(0) * 1.5).toInt().coerceAtLeast(1)

/**
 * iOS `pruneOrphanedRenderables`: off-screen coords keep only the current and next animation
 * dates so a pan-back can draw immediately. Visible tiles keep native MVT and GPU meshes for
 * the full timeline; CPU Feature lists are consumed after GPU upload.
 */
internal fun offscreenParsedIntervalKeepSet(currentMs: Long?, nextMs: Long?): Set<Long> {
    if (currentMs == null && nextMs == null) return emptySet()
    return buildSet {
        if (currentMs != null) add(currentMs)
        if (nextMs != null) add(nextMs)
    }
}
