package com.xweather.mapsgl.data.series

import com.xweather.mapsgl.sources.VectorData
import com.xweather.mapsgl.tiles.TileData

/**
 * Time-series container for vector tile data per interval (MapsGL JS parity).
 * One spatial tile holds many parsed [VectorData] snapshots keyed by epoch milliseconds so
 * timeline animation can swap frames without re-fetching or re-parsing MVT bytes.
 */
class VectorTimeSeriesData(
    validIntervals: List<TimeInterval> = emptyList(),
) : TileData {
    val series: TimeSeries<VectorData> = TimeSeries()
    private var _validIntervals: List<TimeInterval> = validIntervals.sorted()

    val validIntervals: List<TimeInterval>
        get() = _validIntervals

    val count: Int
        get() = series.count

    val validCount: Int
        get() = series.validCount

    fun setValidIntervals(intervals: List<TimeInterval>) {
        _validIntervals = intervals.sorted()
    }

    fun getData(interval: TimeInterval): VectorData? =
        series.dataForTimeInterval(interval)

    fun setData(interval: TimeInterval, data: VectorData) {
        series.setDataForInterval(interval, data, createIfMissing = true)
    }

    fun hasDataForInterval(interval: TimeInterval): Boolean =
        getData(interval) != null

    /**
     * Closest loaded interval at or before [interval] (keeps previous frame visible while the
     * next interval loads), matching JS [TimeSeriesData.getDataClosestToInterval].
     */
    fun getDataClosestToInterval(interval: TimeInterval): VectorData? {
        val withData = series.intervals.filter { t ->
            t <= interval && hasDataForInterval(t)
        }
        if (withData.isNotEmpty()) {
            return getData(withData.max())
        }
        // interval is before all stored data — show nothing (JS SDK parity).
        return null
    }

    fun intervalsNeedingData(intervals: List<TimeInterval> = _validIntervals): List<TimeInterval> =
        intervals.filter { !hasDataForInterval(it) }

    fun removeData(interval: TimeInterval) {
        series.removeInterval(interval)
    }

    /**
     * Drops every loaded interval not in [keep]. Off-screen tiles use this to retain only
     * current+next (iOS `pruneIntervals`); visible tiles pass the full timeline keep-set.
     */
    fun retainOnlyIntervals(keep: Set<TimeInterval>): Int {
        if (keep.isEmpty()) return 0
        var removed = 0
        for (interval in series.intervals.toList()) {
            if (interval in keep) continue
            removeData(interval)
            removed++
        }
        return removed
    }

    override fun init(byteArrayOf: ByteArray) {
        // Vector snapshots are built from parsed MVT bytes, not raw tile payloads.
    }
}
