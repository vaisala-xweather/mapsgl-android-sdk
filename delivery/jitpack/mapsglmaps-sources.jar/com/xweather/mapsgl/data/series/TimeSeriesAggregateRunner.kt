package com.xweather.mapsgl.data.series

import com.xweather.mapsgl.util.MapsGLDebug
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap

/**
 * Keeps an operation layer's tiles showing the correct running aggregate as their series fills in.
 *
 * An operation layer (`*-accum`, `*-max`, `*-min`) does not draw one interval at a time. Every frame
 * has to hold the aggregate *through* that frame, so each interval's pixels depend on every earlier
 * interval of the same tile.
 *
 * ## Why it folds once, in order
 *
 * The obvious design — keep each interval's decoded pixels so the fold can be recomputed whenever
 * something arrives late — costs a padded tile per interval per tile. At 528 x 528 x 4 bytes that is
 * 1.06 MB each, so nine tiles of a twelve-interval series is 115 MB and sixteen tiles of a
 * twenty-four-interval series is over 400 MB. That is not a working set an Android host app can carry.
 *
 * So each interval is folded exactly once, in timestamp order, into a running [DoubleArray]
 * accumulator held per tile — about 2.1 MB per tile regardless of series length. A pending interval
 * holds a *reference* to the buffer the decoder already allocated, not a copy, so buffering costs
 * nothing extra.
 *
 * ## The series is declared, and folded from the front
 *
 * [beginSeries] is told exactly which intervals a tile's aggregate is built from, before any arrive, so
 * completeness is known rather than guessed.
 *
 * An interval folds as soon as every interval *before* it has folded — not when the whole series has
 * landed. Waiting for the whole series pins every padded buffer in it: sixteen tiles of a twenty-four
 * interval series is over 400 MB of 528x528x4 byte arrays, which is what exhausted a 512 MB heap in
 * testing. Folding from the front releases each buffer as it is consumed, so with chronological
 * requests almost nothing is ever pending.
 *
 * Re-declaring a different set resets the tile, which is what a timeline range change needs.
 *
 * [seriesTimeoutMillis] is the floor: if the next interval never arrives, the fold steps over it rather
 * than stalling the tile forever.
 *
 * ## Bounded retention
 *
 * Each tracked tile holds one double per pixel, about 2.1 MB. Tiles are capped at
 * [maxTrackedTiles] and evicted least-recently-used, because relying on callers to release as tiles
 * leave the cache did not survive contact with a user panning around: the release hook existed and was
 * never wired up, and the accumulators grew without bound.
 *
 * ## Threading
 *
 * Tile decode runs on a background dispatcher, so per-tile state is concurrent and each tile's fold is
 * serialised on its own entry.
 */
internal class TimeSeriesAggregateRunner(
    private val context: EncodedRasterOperations.OperationContext,
    private val pixelCount: Int,
    private val seriesTimeoutMillis: Long = DEFAULT_SERIES_TIMEOUT_MILLIS,
    private val clock: () -> Long = System::currentTimeMillis,
    /**
     * Called for each interval as it folds, on the folding thread.
     *
     * A fold rewrites that interval's buffer, so anything already uploaded to the GPU has to be
     * re-bound. Only the interval that folded changes — earlier frames keep the totals they were
     * given — so this reports them one at a time rather than invalidating the whole tile.
     */
    private val onIntervalFolded: ((TileKey, Long) -> Unit)? = null,
    /**
     * A declared interval arrived after the fold had already stepped past it. The runner will not
     * restart the accumulator from that raw buffer — that rebound a one-interval total over a
     * running max and is the mid-timeline pulse. The source should refetch the series oldest-first
     * and leave the current GPU frames alone until each interval is folded again.
     */
    private val onLateInterval: ((TileKey) -> Unit)? = null,
    /** Hard cap on tracked tiles; each holds one double per pixel. */
    private val maxTrackedTiles: Int = DEFAULT_MAX_TRACKED_TILES,
) {

    public companion object {
        /**
         * How long the first fold waits for the rest of the series before going with what it has.
         *
         * Generous, because the cost of waiting is a frame that briefly shows no accumulation, while
         * folding early strands every interval still in flight. A viewport of tiles fetching a full
         * series takes well over a few seconds, and five was short enough to fire mid-fetch.
         */
        public const val DEFAULT_SERIES_TIMEOUT_MILLIS: Long = 20_000L


        /**
         * Tiles retained before the least-recently-used is dropped.
         *
         * A viewport is rarely more than a dozen or so tiles; at about 2.1 MB of accumulator each this
         * caps retention near 50 MB however far someone pans.
         */
        public const val DEFAULT_MAX_TRACKED_TILES: Int = 24

        private const val TAG = "TimeSeriesAggregateRunner"
    }

    /** Identifies one tile of one source. Spatial only — a tile's intervals share a key. */
    public data class TileKey(val sourceId: String, val coordHash: String)

    private class PendingInterval(
        /** The decoder's own buffer. Read for its value, then rewritten with the aggregate. */
        val buffer: ByteArray,
        val arrivedAtMillis: Long,
    )

    private class TileSeries(
        val key: TileKey,
        pixelCount: Int,
        context: EncodedRasterOperations.OperationContext,
    ) {
        val accumulator = EncodedRasterOperations.Accumulator(pixelCount, context)

        /** Arrivals not yet eligible to fold, by interval time. */
        val pending = TreeMap<Long, PendingInterval>()

        /** Timestamp of the most recently folded interval; nothing earlier can be placed after it. */
        var lastFoldedMillis: Long? = null

        var foldedCount: Int = 0

        var droppedCount: Int = 0

        /** Interval times already folded, so a re-delivery can be told from a genuine loss. */
        val foldedTimes = HashSet<Long>()

        /** Re-deliveries of intervals already in the aggregate. Harmless; counted separately. */
        var duplicateCount: Int = 0

        /** Exactly which intervals this aggregate is built from, as declared by [beginSeries]. */
        var expectedTimes: Set<Long> = emptySet()

        /** The same intervals in order; the fold walks this from the front. */
        var expectedOrder: List<Long> = emptyList()

        /** How far along [expectedOrder] the fold has reached. */
        var cursor: Int = 0

        /** When the first interval turned up. */
        var firstArrivalMillis: Long? = null

        /**
         * When an interval last turned up, which is what the completion timeout measures from.
         *
         * Measuring from the first arrival cuts off a series that is still legitimately arriving: the
         * whole series is fetched in chunks, so a long one is often still in flight well past the
         * timeout, and stepping the cursor over intervals that are merely late folds a permanent
         * partial aggregate. Measured from the last arrival the timeout means what it is for - nothing
         * is coming any more - and a steadily arriving series is never cut off midway.
         *
         * Only intervals the series has not seen before count. The provider re-delivers intervals a
         * tile already holds, continuously, and letting those stamp this would keep it permanently
         * fresh: the timeout would never fire and a tile missing one interval would never fold at all.
         */
        var lastArrivalMillis: Long? = null

        /** True once the initial ordered pass has run; later arrivals then append. */
        var initialFoldDone: Boolean = false
    }

    /**
     * Tracked tiles, least-recently-used first out.
     *
     * Bounded on purpose: each entry holds a per-pixel accumulator, and the earlier design left them to
     * a release hook that nothing called, so panning around grew the heap until it died. Every access
     * synchronizes on this map.
     */
    private val tiles = object : LinkedHashMap<TileKey, TileSeries>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<TileKey, TileSeries>): Boolean =
            size > maxTrackedTiles
    }

    private fun seriesFor(key: TileKey): TileSeries = synchronized(tiles) {
        tiles.getOrPut(key) { TileSeries(key, pixelCount, context) }
    }

    private fun seriesOrNull(key: TileKey): TileSeries? = synchronized(tiles) { tiles[key] }

    private fun snapshotSeries(): List<TileSeries> = synchronized(tiles) { tiles.values.toList() }

    /**
     * Registers one decoded interval.
     *
     * The interval is held for the settle window, then folded in timestamp order. [buffer] is
     * rewritten in place with the aggregate through that interval when it folds, so the caller keeps
     * using the same array — but it is *not* rewritten during this call unless the window has already
     * passed.
     *
     * @return The number of intervals folded as a result of this call, which may be zero while the
     * arrival is still settling, or several when it unblocks queued ones.
     */
    public fun submit(
        key: TileKey,
        timeMillis: Long,
        buffer: ByteArray,
    ): Int {
        if (buffer.size < pixelCount * 4) return 0
        val series = seriesFor(key)
        return synchronized(series) {
            if (series.firstArrivalMillis == null) series.firstArrivalMillis = clock()
            val lastFolded = series.lastFoldedMillis
            if (lastFolded != null && timeMillis <= lastFolded) {
                if (timeMillis in series.foldedTimes) {
                    // Already in the aggregate. The provider re-requests a series it has drawn, so this
                    // is the common case and is harmless: ignoring it is what stops double counting.
                    series.duplicateCount++
                } else {
                    // Never folded, and its slot has passed. Restarting the accumulator from this
                    // raw buffer used to be the repair — and it rebound a one-interval total over
                    // a running max, which is the pulse at mid-timeline. Keep the current fold on
                    // screen; the source refetches oldest-first and replaces each frame only after
                    // that interval has been folded again.
                    series.droppedCount++
                    MapsGLDebug.logW(
                        TAG,
                        "Interval $timeMillis for ${key.coordHash} arrived after the fold reached " +
                            "$lastFolded and was never folded; keeping the current aggregate",
                    )
                    onLateInterval?.invoke(key)
                    return@synchronized 0
                }
                return@synchronized 0
            }
            if (!series.pending.containsKey(timeMillis)) series.lastArrivalMillis = clock()
            series.pending[timeMillis] = PendingInterval(buffer, clock())
            drainEligible(series)
        }
    }

    /**
     * Declares the intervals a tile's aggregate is built from, before they arrive.
     *
     * Call this when starting a tile's aggregate. Declaring a *different* set resets the tile — its
     * accumulator, its fold position and anything still pending — which is what a timeline range change
     * needs, since the series being drawn is no longer the one that was folded.
     *
     * Re-declaring the same set is a no-op, so a caller can call it on every pass without restarting
     * work that is already under way.
     *
     * Growing the set at the **end** (same prefix, more later hours) is also not a reset: a running
     * max can accept a newer interval without dropping what it already holds. Resetting there is the
     * flash at “now” / mid-timeline, when the product publishes one more valid time and every tile
     * rebuilds from a single raw hour.
     *
     * @return true when the tile was reset.
     */
    public fun beginSeries(key: TileKey, expectedTimes: Collection<Long>): Boolean {
        val declared = expectedTimes.toSet()
        val series = seriesFor(key)
        return synchronized(series) {
            if (series.expectedTimes == declared) return@synchronized false
            val neu = declared.sorted()
            val old = series.expectedOrder
            if (old.isNotEmpty() && neu.size >= old.size && neu.subList(0, old.size) == old) {
                series.expectedTimes = declared
                series.expectedOrder = neu
                return@synchronized false
            }
            synchronized(tiles) { tiles.put(key, TileSeries(key, pixelCount, context).also {
                it.expectedTimes = declared
                it.expectedOrder = neu
            }) }
            true
        }
    }

    /**
     * Folds anything whose settle window has expired, across every tile.
     *
     * [submit] drains as a side effect, so this only matters for the tail of a series: the last
     * interval to arrive has nothing following it to trigger a drain. Call it from whatever already
     * ticks — a frame callback or the timeline — so the final frame does not sit unfolded.
     *
     * @return Total intervals folded.
     */
    public fun flushExpired(): Int {
        var folded = 0
        for (series in snapshotSeries()) {
            synchronized(series) { folded += drainEligible(series) }
        }
        return folded
    }

    /**
     * Folds every pending interval regardless of its settle window, for when the series is known to be
     * complete and waiting buys nothing.
     *
     * @return Total intervals folded.
     */
    public fun flushAll(): Int {
        var folded = 0
        for (series in snapshotSeries()) {
            synchronized(series) { folded += drain(series, ignoreSettle = true) }
        }
        return folded
    }

    /** Caller holds the series lock. */
    private fun drainEligible(series: TileSeries): Int = drain(series, ignoreSettle = false)

    /**
     * Folds pending intervals in timestamp order while they are eligible.
     *
     * Stops at the first ineligible entry rather than skipping it: folding a later interval first
     * would strand the earlier one, which is exactly the out-of-order case the window exists to avoid.
     */
    private fun drain(series: TileSeries, ignoreSettle: Boolean): Int {
        if (series.pending.isEmpty()) return 0
        var folded = 0

        while (true) {
            val next = nextFoldable(series, ignoreSettle) ?: break
            val interval = series.pending.remove(next) ?: break

            val previous = series.lastFoldedMillis
            val weight = previous?.let { EncodedRasterOperations.timeWeight(it, next) } ?: 1.0
            series.accumulator.add(interval.buffer, weight)
            // Rewrite the decoder's buffer with the aggregate through this interval. Dropping the
            // pending entry above is what lets the buffer be reclaimed once the tile cache is done.
            series.accumulator.encodeInto(interval.buffer)

            series.lastFoldedMillis = next
            series.foldedTimes.add(next)
            series.foldedCount++
            folded++
            onIntervalFolded?.invoke(series.key, next)
        }
        if (folded > 0) series.initialFoldDone = true
        return folded
    }

    /**
     * The next interval that may be folded: the earliest declared one not yet folded, once it has
     * arrived.
     *
     * Returns null while that interval is still outstanding, which is what keeps the aggregate in
     * order — except past [seriesTimeoutMillis], where the cursor steps over a interval that is not
     * coming rather than stalling the tile indefinitely.
     */
    private fun nextFoldable(series: TileSeries, ignoreSettle: Boolean): Long? {
        val order = series.expectedOrder
        if (order.isEmpty()) {
            // Nothing declared: fall back to draining in timestamp order.
            return series.pending.firstEntry()?.key
        }
        val expired = ignoreSettle ||
            (series.lastArrivalMillis?.let { clock() - it >= seriesTimeoutMillis } ?: false)

        while (series.cursor < order.size) {
            val candidate = order[series.cursor]
            if (series.pending.containsKey(candidate)) {
                series.cursor++
                return candidate
            }
            if (candidate in series.foldedTimes) {
                series.cursor++
                continue
            }
            if (!expired) return null
            // Timed out waiting for this one; step over it so the rest of the series can still fold.
            series.cursor++
        }
        // Past the declared set: anything newer than the fold position appends.
        val first = series.pending.firstEntry()?.key ?: return null
        val last = series.lastFoldedMillis
        return if (last == null || first > last) first else null
    }

    /**
     * Whether the first ordered pass can run: either the tile has every interval the layer expects, or
     * the series has had long enough to turn up.
     *
     * Folding before the series is complete is what loses contributions, because the scrub-driven
     * request order delivers earlier intervals after later ones.
     */
    private fun readyForInitialFold(series: TileSeries): Boolean {
        val latest = series.lastArrivalMillis ?: return false
        val expected = series.expectedTimes
        // Every declared interval present: fold now, arrival order irrelevant.
        if (expected.isNotEmpty() && series.pending.keys.containsAll(expected)) return true
        // Otherwise only the floor, so a series missing an interval still draws eventually.
        return clock() - latest >= seriesTimeoutMillis
    }

    /** True when this tile has any folded or pending interval. */
    public fun tracks(key: TileKey): Boolean = synchronized(tiles) { tiles.containsKey(key) }

    /**
     * Whether [timeMillis] is already in this tile's aggregate.
     *
     * A caller needs this because [submit] cannot repair a re-delivery. The buffer contract is that
     * an interval's bytes are rewritten in place with the aggregate through that interval, but a
     * second delivery of an interval already folded is refused outright — folding it twice would
     * double-count — so its buffer is left holding whatever it arrived with. When the provider
     * re-decodes the tile, that is the raw single interval, and drawing it shows one interval's own
     * value in a frame that should hold the running result.
     *
     * The runner cannot fix that itself: the accumulator holds state through the *latest* folded
     * interval only, so there is nothing to reconstruct an earlier frame from, and keeping a
     * snapshot per interval is the per-interval memory cost this design exists to avoid. So the
     * caller asks before binding, and restores the folded pixels it already has.
     */
    public fun hasFolded(key: TileKey, timeMillis: Long): Boolean {
        val series = seriesOrNull(key) ?: return false
        return synchronized(series) { timeMillis in series.foldedTimes }
    }

    /** How many intervals have been folded into this tile's aggregate. */
    public fun foldedCount(key: TileKey): Int {
        val series = seriesOrNull(key) ?: return 0
        return synchronized(series) { series.foldedCount }
    }

    /** How many arrivals are waiting out the settle window. */
    public fun pendingCount(key: TileKey): Int {
        val series = tiles[key] ?: return 0
        return synchronized(series) { series.pending.size }
    }

    /**
     * Arrivals genuinely lost: earlier than the fold reached, and never folded. These are the ones that
     * make an aggregate under-count.
     */
    public fun droppedCount(key: TileKey): Int {
        val series = seriesOrNull(key) ?: return 0
        return synchronized(series) { series.droppedCount }
    }

    /** Re-deliveries of intervals already folded. Harmless, and expected whenever a series is re-requested. */
    public fun duplicateCount(key: TileKey): Int {
        val series = seriesOrNull(key) ?: return 0
        return synchronized(series) { series.duplicateCount }
    }

    /** Drops one tile's accumulator. Call when the tile leaves the cache. */
    public fun release(key: TileKey) {
        synchronized(tiles) { tiles.remove(key) }
    }

    /** Drops every tile belonging to [sourceId]. Call when the layer is removed. */
    public fun clearSource(sourceId: String) {
        synchronized(tiles) { tiles.keys.removeAll { it.sourceId == sourceId } }
    }

    /** Drops everything. */
    public fun clear() {
        synchronized(tiles) { tiles.clear() }
    }

    /** Tiles currently retained, for diagnostics and memory reporting. */
    public val trackedTileCount: Int get() = synchronized(tiles) { tiles.size }

    /** Approximate retained bytes: one double per pixel per tracked tile. */
    public val retainedBytes: Long get() = synchronized(tiles) { tiles.size.toLong() * pixelCount * 8L }
}
