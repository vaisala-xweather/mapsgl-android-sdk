package com.xweather.mapsgl.data.series

import com.xweather.mapsgl.anim.AnimationOptions
import com.xweather.mapsgl.anim.AnimationState
import com.xweather.mapsgl.anim.TimeAnimation
import com.xweather.mapsgl.anim.TimeAnimationOptions
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.layers.tile.TimeClampMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Instant
import java.util.Date
import kotlin.time.Duration.Companion.milliseconds

/** Defines the mode used when evaluating a layer's data based on time. Layers that aren't time-specific
 * should use a value of `none`. */
class TimeSeriesMode{
    companion object{
        /** The time series data is not time-specific and should be displayed at any time. */
        const val none = "none"

        /** The time series data is time-specific but can be displayed at any time. */
        const val any = "any"

        /** The time series data is time-specific and should be displayed at valid time intervals.*/
        const val interval = "interval"
    }
}

/** @suppress **/
interface TimeSeriesState {
    var position: Float
    var interval: TimeInterval
    var nextInterval: TimeInterval
    var intervalPosition: Float
    var index: Int
    var nextIndex: Int
}

/** @suppress **/
open class TimeSeriesAnimatorData {
    var loading: Boolean = false
    var valid: Boolean = false
}

/** @suppress **/
class Data: TimeSeriesAnimatorData() {}

/** @suppress **/
class TimeSeriesAnimator<Data : TimeSeriesAnimatorData>(
    series: TimeSeries<Data>,
    provider: TimeSeriesDataProvider<TileLayer>?,
    opts: TimeSeriesAnimatorOptions
) : EventDispatcher() {

    private var _updateEntriesStateDebouncedJob: Job? = null
    var series: TimeSeries<Data>
    var enabled = true

    /** The mode used when evaluating a layer's data based on time.  */
    var clamp = TimeClampMode.NONE

    private var _animation: TimeAnimation
    private var _provider: TimeSeriesDataProvider<TileLayer>?
    lateinit var _timeRange: TimeRange

    private var _lastAdvanceTime: Long = 0 //Long?
    private var _intervalState: TSIntervalState

    private var _debouncedLoadDataJob: Job? = null

    /** The identifier of the animation. */
    val id: String
        get() = _animation.id

    /** The data provider used to load data for the time series.
     * @readonly
     */
    val provider: TimeSeriesDataProvider<TileLayer>?
        get() {
            return this._provider;
        }

    val timeRange: TimeRange
        get() {
            if (_timeRange != null) {
                return _timeRange!!
            }
            return series.timeRange
        }

    /** The current time interval and index in the time series.
     *  * @readonly     */
    val currentInterval: TimeSeriesIntervalItem
        get() = TimeSeriesIntervalItem(interval = _intervalState.time.current.interval, index = _intervalState.time.current.index)

    /** Total number of time intervals in the time series.    * @readonly
     */
    val totalIntervals: Int
        get() = series.intervals?.size ?: 0


    /** The current position of the animation in the range of [0..1].
     * @readonly     */
    val position: Double
        get() = animation?.position ?: 0.0

    /** The current state of the animation.
     * @readonly     */
    val state: AnimationState
        get() {
            if (this.provider!=null) {
                if (this.provider!!.isLoading) {
                    return AnimationState.loading;
                }

                if (this.animation.state == AnimationState.initial && this.hasData) {
                    return AnimationState.ready;
                }
            }
            return this._animation.state
        }

    /** The animation instance being used to animate the time series.
     * @readonly  */
    val animation: TimeAnimation
        get() {
            return this._animation
        }

    /**
     * Indicates if the time series has data.
     * @readonly
     */
    val hasData: Boolean
        get() {
            return isNotEmpty(this.series.data)
        }

    fun isNotEmpty(value: Any?): Boolean {
        return when (value) {
            is String -> value.isNotEmpty()
            is Collection<*> -> value.isNotEmpty()
            else -> false // Or throw an exception if you want to be stricter.
        }
    }

    init{
        val mode = opts.mode ?: TimeClampMode.NONE
        this._animation = opts.animation
        this.series = series
        this.clamp = mode

        this._provider = provider
        val   initialInterval = this._animation.start.time
        this._intervalState = TSIntervalState(
            TSTime(
                TimeSeriesIntervalItem(initialInterval, -1),
                TimeSeriesIntervalItem(initialInterval, -1)
            ),
            TSData(
                TimeSeriesIntervalItem(initialInterval, -1),
                TimeSeriesIntervalItem(initialInterval, -1)
            )
        )
    }


    /** Indicates if the animator is currently animating.  */
    val isAnimating: Boolean
        get() = animation.isAnimating

    /** Indicates if the animator is currently paused.  */
    val isPaused: Boolean
        get() = animation.isPaused

    /** Indicates if the animator is currently active (animating or paused).   */
    val isActive: Boolean
        get() = isAnimating || isPaused

    /** Returns whether the animator should show data for the specified date based on the animator's clamp mode and
     * time range.
     * @remarks
     * If the animator's animation is a `TimeAnimation`, then the clamp mode will be used to determine if the animator
     * should show data for the specified date. If the clamp mode is set to `TimeClampMode.range`, then the time range
     * will be used to determine if the animator should show data for the specified date. If the clamp mode is set to
     * `TimeClampMode.past` or `TimeClampMode.future`, then the animator will only show data for the specified date if
     * the date is within the past or future, respectively.
     * If the animator's animation is not a `TimeAnimation` or its clamp mode is set to `TimeClampMode.none`, then the
     * animator will always show data for the specified date.
     * @param date - The date to check if the animator should show data for.
     * @returns True if the animator should show data for the specified date, otherwise false.     */
    fun canShowForDate(date: Date = this.animation.currentDate): Boolean {

        if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate($date) (animation is TimeAnimation)? ${(animation is TimeAnimation)} }")

        if (animation is TimeAnimation) {

            val now = animation.referenceDate.time

            val current = date.time
            val clamp = this.clamp

            if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate() now:$now  current:$current  clamp:$clamp")

            if (clamp == TimeClampMode.NONE) {
                if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate()  (clamp == TimeClampMode.NONE) return true")
                return true
            }

            if (clamp == TimeClampMode.RANGE) {
                if (_timeRange == null && (series.intervals?.isEmpty() ?: true)) {
                    if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate() return false S")
                    return false
                }

                val fromValue = _timeRange.start.time
                val toValue = _timeRange.end.time
                if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate() return A")
                return (current in fromValue..toValue)
            }

            if (clamp == TimeClampMode.PAST && !animation.containsPast) {
                if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate() return B")
                return false
            }

            if (clamp == TimeClampMode.FUTURE && !animation.containsFuture) {
                if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate() return C")
                return false
            }

            if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate() return D")
            return (
                    (clamp == TimeClampMode.PAST && current <= now) ||
                            (clamp == TimeClampMode.FUTURE && current > now)
                    )
        }
        if (pr.ON) pr.p("TimeSeriesAnimator", pr.layerToAnimation, "canShowForDate() return E")
        return true
    }

    /** Requests data for the time series from the data provider for the specified time intervals.
     * @param intervals - The time intervals to request data for.    */
    fun loadDataForIntervals(intervals: MutableList<TimeInterval>) {
        provider?.setNeedsUpdate()
        _debouncedLoadData(intervals)
    }

    private fun _debouncedLoadData(intervals: MutableList<Long>) {
        _debouncedLoadDataJob?.cancel()
        _debouncedLoadDataJob = CoroutineScope(Dispatchers.Main).launch {
            delay(100.milliseconds)
            _provider?.loadData(intervals)
        }
    }

    /**
     * The relative position between the current and next time intervals in the range of [0..1].
     * @remarks
     * If the current time interval is the same as the next time interval or the next interval is missing data, then
     * the relative position will be 0. If the current time interval is missing data and the next interval has data,
     * then the relative position will be 1. Otherwise, the relative position will be the progress between the current
     * and next time intervals.
     * @readonly
     */
    val relativePosition: Double
        get() {
            val currentTime = _intervalState.data.current.interval
            val currentIndex = _intervalState.data.current.index
            val nextTime = _intervalState.data.next.interval
            val nextIndex = _intervalState.data.next.index

            val intervals = series.intervals
            val firstInterval = intervals?.firstOrNull()
            val currentInterval = intervals?.getOrNull(currentIndex)
            val nextInterval = intervals?.getOrNull(nextIndex)

            val isCurrentValid = currentInterval?.let { series.dataForInterval(it)?.valid == true } ?: false
            val isNextValid = nextInterval?.let { series.dataForInterval(it)?.valid == true} ?: false


            if (currentIndex == nextIndex || nextInterval == null || isNextValid == false) {
                return 0.0
            }
            if (isCurrentValid == false && isNextValid) {
                return 1.0
            }
            if (isCurrentValid && isNextValid == false) {
                return 0.0
            }

            // If current timeline date is less than the first interval in the series, then the relative position
            // should be 0 since we aren't in between time intervals.
            if (animation.currentDate.time.let { firstInterval?.let { it as Long }?.let { it2 ->  it < it2  }  } == true ) {
                return 0.0
            }
            // calculate the progress within the current interval
            val progress = (animation.currentDate.time.toDouble().minus(currentTime as Long) ?: 0.0 ) / ((nextInterval as? Long ?:0) - (currentTime as? Long ?: 0) )

            return kotlin.math.max(0.0, kotlin.math.min(1.0, progress))
        }


    /** Indicates if the animator has data for the current time interval.
     * @returns True if the animator has data for the current time interval, otherwise false.    */
    fun hasDataForCurrentInterval(): Boolean {
        val interval = _intervalState.data.current.interval
        return hasDataForInterval(interval, true)
    }

    /** Indicates if the animator has data for the specified date.
     * @param date - The date to check if the animator has data for.
     * @param checkValid - If true, then the animator will only return true if the data for the specified date is valid.
     * @returns True if the animator has data for the specified date, otherwise false.     */
    fun hasDataForDate(date: Date, checkValid: Boolean = animation.isActive): Boolean {
        return hasDataForInterval(date.getTime(), checkValid)
    }

    /** Indicates if the animator has data for the specified time interval.
     * @param interval - The time interval to check if the animator has data for.
     * @param checkValid - If true, then the animator will only return true if the data for the specified interval is
     * valid.
     * @returns True if the animator has data for the specified time interval, otherwise false.     */
    fun hasDataForInterval(interval: TimeInterval, checkValid: Boolean = animation.isActive): Boolean {
        if (series.data.isEmpty()) {
            return false
        }

        val data = series.dataForInterval(interval)

        // If animation is active, then we check and make sure `valid` is true since we only want to include
        // that interval if all tiles have data. otherwise return true if it's a valid interval in the series.
        if (checkValid) {
            return data?.valid == true
        }
        return data != null
    }
    /**
     * Indicates if the animator needs data for the specified date based on the animator's clamp mode and if data is
     * already available for the date.
     * @param date -
     * @returns
     */
    fun needsDataForDate(date: Date): Boolean {
        //val now = Date.now().toDouble()
        val now = Date.from(Instant.now()).time.toDouble()
        val current = date.getTime().toDouble()
        val from = this.timeRange.start.getTime().toDouble()
        val to = this.timeRange.end.getTime().toDouble()
        val clamp = this.clamp

        if (clamp == TimeClampMode.RANGE
            && (from == null || to == null || (current < from || current > to))) {
            return false
        }

        if (clamp == TimeClampMode.PAST && current > now) {
            return false
        }
        if (clamp == TimeClampMode.FUTURE && current < now) {
            return false
        }

        return !hasDataForDate(date)
    }

    /** Returns the position for the specified time within the animation time series in the range of [0..1].
     * @param time - The time to calculate the position for.     */
    fun positionForTime(time: Date): Double {
        return ((time.time - animation.start.time) / animation.deltaTime).toDouble()
    }

    /** Loads all data required for the time series even if the animation is not currently active.
     * @remarks
     * This method is useful when you want to load all data for the time series at once, such as preloading the data
     * before starting the animation.     */
    fun loadData() {
        loadDataIfNeeded(false, true)
    }

    /** Requests data for the time series from the data provider if needed.
     * @remarks
     * If the animation is active (playing or paused), then the animator will request data for the full range of times
     * in the time series. Otherwise, the animator will only request data for the animation's current date.
     * @param debounced - If true, then the load request will be debounced to prevent multiple requests from being
     * made in quick succession.
     * @param useTimeRange - If true, then the animator will request data for the full time range of the time series
     * even if the animation is not currently active.     */
    fun loadDataIfNeeded(debounced: Boolean = false, useTimeRange: Boolean = false) {
        val animation = this.animation

        // Reduce seriesData times to those within the timeline range
        val startDate = Date(animation.start.getTime())
        val endDate = Date(animation.end.getTime())
        val timesInRange = this.series.intervalsInRange(startDate, endDate)

        // If animation is active (playing or paused), then we need the full range of times in the animation
        // otherwise we only need data for the timeline's current date
        val closestInterval = this.series.closestInterval(animation.currentDate).first //was .interval
            ?: animation.currentDate.getTime()
        val neededIntervals = if (animation.isActive || useTimeRange) timesInRange else mutableListOf(closestInterval)

        if (debounced) {
            debouncedLoadData(neededIntervals)
        } else {
            CoroutineScope(Dispatchers.Main).launch {
                _provider?.loadData(neededIntervals)
            }
        }
        // This block commented out in javascript version:
        //  Check if we need to flag the provider as needing an update based on the needed intervals
        // and if we currently have data for each interval
        //   var needsUpdate = false;
        //  neededIntervals.forEach { interval ->
        //    val intervalData = this.series.dataForInterval(interval)
        //       if (intervalData != null) {
        //           if (intervalData.valid == false && intervalData.loading == false) {
        //               needsUpdate = true;
        //         }
        //          intervalData.loading = true
        //      }
        //  }

        // if (needsUpdate) {
        //    this.provider.invalidate();
        //   this.provider.setNeedsUpdate();
        //    // if (this.provider.isDirty) {
        //     //     console.log('loadDataIfNeeded', this.id, 'needsUpdate', needsUpdate, 'neededIntervals', neededIntervals);
        //     // }
        //     this.loadData(neededIntervals);
        // }
    }

    /*
    private fun _debouncedLoadData(intervals: Array<TimeInterval>) {
        _debouncedLoadDataJob?.cancel() // Cancel any existing job

        _debouncedLoadDataJob = CoroutineScope(Dispatchers.Main).launch {
            delay(100.milliseconds) // Wait for the debounce delay
            _provider?.loadData(intervals)
        }
    }*/

    /** Debounced load data function **/
    private fun debouncedLoadData(neededIntervals : MutableList<TimeInterval>){
        CoroutineScope(Dispatchers.Main).launch {
            _provider?.loadData(neededIntervals)
        }

    }

    private fun eventPayload(): Map<String, Any?> {
        val currentInterval = _intervalState.time.current.interval
        val currentIndex = _intervalState.time.current.index
        val nextIndex = kotlin.math.min(totalIntervals - 1, currentIndex + 1)
        val nextInterval = series.intervals.getOrNull(nextIndex)
        return mapOf(
            "animator" to this,
            "position" to this.position,
            "date" to animation?.currentDate,
            "interval" to currentInterval,
            "nextInterval" to nextInterval,
            "dataInterval" to _intervalState.data.current.interval,
            "nextDataInterval" to _intervalState.data.next.interval,
            "index" to currentIndex,
            "nextIndex" to nextIndex,
            "dataIndex" to  _intervalState.data.current.index,
            "nextDataIndex" to _intervalState.data.next.index,
            "totalIntervals" to totalIntervals,
            "intervalPosition" to this.relativePosition,
            "data" to series.dataForInterval(currentInterval)

        )
    }

    /** Updates the state of the time series entries.   */
    fun updateEntryState() {
        _updateEntriesStateDebounced()
    }

    private fun _updateEntriesStateDebounced() {
        _updateEntriesStateDebouncedJob?.cancel() // Cancel any existing job
        _updateEntriesStateDebouncedJob = CoroutineScope(Dispatchers.Main).launch {
            delay(10.milliseconds) // Wait for the debounce delay
            _updateEntriesState()
        }
    }
    /**
     * Updates the state of the time series entries based on what data is currently available.
     * @remarks
     * This method is called when the data provider has loaded data and is responsible for updating the valid state and
     * current and next interval indexes for each entry in time series data for time intervals that have data.
     * @internal
     */
    private fun _updateEntriesState() {
        if (series.intervals.isEmpty()) return

        val validTimes = series.intervals
        val seriesData:SeriesData<Data> = series.data as HashMap<TimeIntervalKey, TimeSeriesEntry<Data>> //?: mutableMapOf()

        if (_provider != null) {
            val dataIntervalState = _provider!!.dataStateForIntervals(validTimes)
            dataIntervalState.forEach { (interval, isValid) ->
                val item = seriesData[interval]
                item?.data?.let {
                    (it ).valid = isValid
                }
            }
        }
        validTimes.forEachIndexed { index: Int, interval:TimeInterval ->
            val item = seriesData[interval.toString()]
            item?.index = index

            if (item?.data?.let { (it /*as TimeSeriesDataItem*/).valid } == true) {
                item.current = index

                // find next index with data
                for (i in validTimes.size - 1 downTo index + 1) {
                    val itemAtIndex = series.dataForInterval(validTimes[i])
                    if(itemAtIndex?.valid == true){
                        item.next = i
                    }
                }
                // if no next interval found at an index higher than the current index, then just set
                // the next index as the same as the current one
                if (item.next == -1 || item.next < item.current) {
                    item.next = item.current
                }
            } else {
                item?.current = -1
                item?.next = -1
            }
        }
        handleAdvance()
    }

    private fun handleAdvance() {
        val lastInterval = _intervalState.time.current.interval
        val (closestInterval, index) = series.closestInterval(animation.currentDate)

        if (animation.currentDate.time != _lastAdvanceTime) {
            triggerAny(TimeSeriesEvent.ADVANCE, eventPayload())
            _lastAdvanceTime = animation.currentDate.time
        }

        if ((series.data.isEmpty())) return

        if (lastInterval == null || closestInterval != lastInterval) {
            _intervalState.time.current = TimeSeriesIntervalItem(closestInterval!!, index)
            triggerAny(TimeSeriesEvent.INTERVAL_ADVANCE, eventPayload())
        }


        if (closestInterval!=null && series.hasDataForInterval(closestInterval)) {
            val item = series.entryForInterval(closestInterval)
            val nextIndex = item!!.next
            val nextTime = series.intervalAtIndex(nextIndex)

            if (index != _intervalState.data.current.index
                || (_intervalState.data.next.index == -1 /*&& isNotNil(nextIndex)*/)
            ) {
                _intervalState.data.current = _intervalState.time.current
                _intervalState.data.next = TimeSeriesIntervalItem(nextTime!!, nextIndex)

                triggerAny(TimeSeriesEvent.DATA_ADVANCE, eventPayload())
            }
        }
    }




}


/** @internal */
class TimeSeriesIntervalItem(val interval:TimeInterval = 0, val index: Int = 0)  {}
class TSIntervalState(val time: TSTime, val data: TSData) {}
class TSTime(var current: TimeSeriesIntervalItem, val next: TimeSeriesIntervalItem) {}
class TSData(var current: TimeSeriesIntervalItem, var next: TimeSeriesIntervalItem) {}

/** Options for configuring a `TimeSeriesAnimator`.
 * @internal
 */
class TimeSeriesAnimatorOptions(passedMode: TimeClampMode/*, passedAnimation: TimeAnimation*/) : TimeAnimationOptions() {
    /** The mode used when evaluating a layer's data based on time.   */
    override var mode: TimeClampMode = passedMode

    /** The animation instance to use for animating the time series. If not provided, a new instance will be created.*/
    var animation: TimeAnimation = TimeAnimation(TimeAnimation.PartialTimeAnimationOptions(Date(System.currentTimeMillis() - (24 * 3600 * 1000L)) ,Date(),true, AnimationOptions()))

    init{
        //println("TimeSeriesAnimator TimeSeriesAnimatorOptions() created")

    }
}
