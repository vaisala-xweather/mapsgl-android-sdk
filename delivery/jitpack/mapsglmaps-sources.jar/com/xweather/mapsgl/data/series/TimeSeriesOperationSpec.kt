package com.xweather.mapsgl.data.series

/**
 * Declares that a source's intervals should be folded into a running aggregate rather than drawn one
 * at a time — what turns a rate product into an `*-accum` layer, or a conditions product into
 * `*-max` / `*-min`.
 *
 * The real-world range comes from the source's own datasets at runtime, so it is not repeated here.
 *
 * @property operation How consecutive intervals combine.
 * @property bandsPerValue How many consecutive bands one value is spread across. Must match the
 * layer's sample channel: 1 for a single-band product, 3 for a value encoded across `rgb`.
 * @property remappedDataRange Range to encode the aggregate into when the total needs more headroom
 * than a single interval. Null re-encodes into the source range, which clamps once the accumulation
 * reaches the top of it.
 */
internal data class TimeSeriesOperationSpec(
    val operation: EncodedRasterOperations.Operation,
    val bandsPerValue: Int = 1,
    val remappedDataRange: EncodedRasterOperations.DataRange? = null,
)
