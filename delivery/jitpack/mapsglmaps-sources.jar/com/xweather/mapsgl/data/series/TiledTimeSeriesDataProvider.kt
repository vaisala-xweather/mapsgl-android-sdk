package com.xweather.mapsgl.data.series

import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.data.EncodedTileData
import com.xweather.mapsgl.data.Queue
import com.xweather.mapsgl.data.QueueCollection
import com.xweather.mapsgl.events.TimeSeriesEvent
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.TileLayer
import com.xweather.mapsgl.sources.VectorTileSource
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileBounds
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.utils.LRUCache
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.LocalDateTime
import java.time.ZoneOffset
import java.util.Date
import kotlin.math.ceil
import kotlin.math.floor

private const val TAG = "TiledTimeSeriesDataProvider"

const val MAX_REQUEST_INTERVALS = 6;

data class TileInterval(val coord: TileCoord, val intervals: List<TimeInterval>)
typealias TileIntervalsArray = MutableList<TileInterval>

/**
 * Breaks up the intervals into smaller chunks for the requests.
 * @param coordsToRequest - Set of tile coordinates and their data intervals to request.
 * @param maxIntervalsPerRequest - The maximum number of intervals to request per tile which determines the chunk size.
 */
fun createTileIntervalChunks(
    coordsToRequest: MutableList<TileInterval>,
    maxIntervalsPerRequest: Int,
    interleaved: Boolean
): MutableList<MutableList<TileInterval>> {
    val tasks = mutableListOf<MutableList<TileInterval>>()

    coordsToRequest.forEach { (coord, intervals) ->
        val maxIntervals = maxIntervalsPerRequest.coerceAtMost(intervals.size)
        val chunks = mutableListOf<MutableList<TimeInterval>>()
        val totalChunks = ceil(intervals.size.toDouble() / maxIntervals).toInt()

        if (totalChunks > 1) {
            var n = 0
            for (i in intervals.indices) {
                if (chunks.size <= n) {
                    chunks.add(mutableListOf())
                }
                chunks[n].add(intervals[i])

                if (interleaved) {
                    n = (n + 1) % totalChunks
                } else if (chunks[n].size == maxIntervals) {
                    n++
                }
            }
        } else {
            chunks.add(intervals.toMutableList())
        }

        chunks.forEachIndexed { chunkIndex, chunkIntervals ->
            if (tasks.size <= chunkIndex) {
                tasks.addAll(List(chunkIndex - tasks.size + 1) { mutableListOf() }) //Fill in missing indices
            }
            tasks[chunkIndex].add(TileInterval(coord, chunkIntervals))
        }
    }
    return tasks
}

/**
 * Sorts an array of tile interval chunks so that we load those in the middle of each chunk first.
 * @param chunks - The chunks to sort.
 */
fun sortedIntervalChunks(chunks: List<List<TileInterval>>): List<List<TileInterval>> {
    val indexOrder = chunks.indices.toList()

    val sortedIndexOrder = if (chunks.size > 2) {
        indexOrder.sortedWith(compareBy { chunks[it].size / 2.0 })
    } else {
        indexOrder
    }

    return sortedIndexOrder.map { chunks[it] }
}

class Queues(val primary: Queue<Any>, val background: QueueCollection<Any>) {}

/** A `TimeSeriesDataProvider` class that handles loading and configuring time series data for tile layers.
 *
 * This class is designed to work with tile-based data sources and is optimized for loading time series data for
 * individual tiles and tile intervals. It queues requests into a primary queue and a background queue collection so
 * that the primary queue can load the first chunk of data, which is the minimal amount of data required to begin
 * animating. Then the background queue can continue loading the rest of the data in smaller chunks to fill in the gaps
 * while the animation is already playing.
 * @internal
 */
class TiledTimeSeriesDataProvider(override val layer: TileLayer) : TimeSeriesDataProvider<TileLayer>(layer) {

    lateinit var _visibleTileCoords: List<TileCoord>

    //var _intervalTileCache: MutableMap<String, Tile<DataType>> = mutableMapOf();
    lateinit var _intervalTileCache: LRUCache<String, Tile<TileData>>

    lateinit var _visibleTileBounds: TileBounds;
    var _lastIntervals: MutableList<TimeInterval> = mutableListOf()
    /** Spatial `hashShort` of [_visibleTileCoords]; interval-LRU [LRUCache.canEvict] uses this. */
    private var _visibleSpatialKeys: Set<String> = emptySet()

    var queues = Queues(Queue(), QueueCollection())

    /**
     * Rule: loadData-single-flight. [loadData] can be invoked by several independent triggers in
     * quick succession — e.g. the timeline date-range panel's -1 day/+1 day buttons fire
     * AnimationEvent.range_change on every tap with no debounce, and each call requests every
     * interval in the (fresh) range via `useTimeRange = true`. `_isDirty` alone doesn't prevent
     * these from overlapping: it's cleared synchronously early in the method, before the actual
     * per-tile request dispatch loop below runs, so a second call arriving while the first is still
     * dispatching sees `_isDirty` already false and *should* bail — but a THIRD rapid tap can still
     * re-mark it dirty (the `intervals.size != _lastIntervals.size` check at the top fires again
     * whenever the range genuinely changed) and start a second full dispatch pass while the first is
     * still draining. Confirmed live this could leave a data-dense region (e.g. all of Europe) with
     * most tiles never loading after 2-3 rapid range-change taps — concurrent passes flooded
     * VectorTileSource's shared in-flight-request cap with duplicate work, so requests genuinely
     * still missing kept getting rejected rather than queued. Serializing the whole method body
     * ensures each range change gets one clean, uncontested pass before the next begins.
     */
    private val loadDataMutex = Mutex()

    fun jTest() {


    }


    override fun dataStateForIntervals(intervals: MutableList<TimeInterval>): Map<String, Boolean> {
        if (!::_visibleTileCoords.isInitialized) return emptyMap()

        val visibleCoords = this._visibleTileCoords
        val state: MutableMap<String, Boolean> = mutableMapOf()
        val missingData: MutableMap<String, TimeInterval?> = mutableMapOf()

        if (visibleCoords.isNotEmpty()) {
            for (interval in intervals) {
                var missingIntervalData = false
                for (coord in visibleCoords) {
                    val lookupCoord = when (val vts = layer.source as? VectorTileSource) {
                        null -> coord
                        else -> if (vts.isTimeSeriesSource) {
                            vts.spatialTileCoord(coord.x, coord.y, coord.z)
                        } else {
                            coord
                        }
                    }
                    val tileData = layer.source.getTileData(lookupCoord)
                    if (tileData is VectorTimeSeriesData) {
                        if (!tileData.hasDataForInterval(interval)) {
                            missingIntervalData = true
                            missingData[lookupCoord.hash()] = interval
                        }
                        continue
                    }
                    if ((tileData is EncodedTileData || tileData is BitmapTimeSeriesData<*>)
                    /*&& tileData.series?.hasDataForInterval(interval) == false*/
                    ) {
                        missingIntervalData = true;
                        //if (missingData.containsKey(coord.hash())) { missingData[coord.hash()] = null }
                        missingData[coord.hash()] = interval
                    }
                }
                state[interval.toString()] = !missingIntervalData;
            }
        }

        return state;
    }


    fun loadDataOld(intervals: Array<TimeInterval>) {
        TODO("Not yet implemented")
    }


    /**
     * Updates the visible tile coordinates and bounds for the layer.
     */
    private fun _updateVisibleTileCoordsState() {
        val reported = layer.getVisibleTileCoords()
        // Bound the visible set at the source. `getVisibleTileBounds` intermittently reports a
        // latitude extent that does not shrink with zoom (~39% of the globe at every zoom level),
        // producing thousands of tile rows for one screen — 12659 tiles measured against a real
        // viewport of ~8. Everything downstream is O(visible): calculateMissingTileIntervals does a
        // cache lookup per coord on the main thread, which is where the ANR trace lands. Capping
        // dispatch alone was not enough because that loop runs first.
        _visibleTileCoords = if (reported.size <= MAX_VISIBLE_TILES) {
            reported
        } else {
            val cx = reported.sumOf { it.x.toDouble() } / reported.size
            val cy = reported.sumOf { it.y.toDouble() } / reported.size
            if (_visibleClampLog++ % 200L == 0L) {
                android.util.Log.w(
                    TAG,
                    "visible tile set reported ${reported.size}; clamping to the " +
                        "$MAX_VISIBLE_TILES nearest the centre (logged 1 in 200)"
                )
            }
            reported.sortedBy { c ->
                val dx = c.x - cx
                val dy = c.y - cy
                dx * dx + dy * dy
            }.take(MAX_VISIBLE_TILES)
        }
        _visibleSpatialKeys = _visibleTileCoords.mapTo(HashSet()) { it.hashShort() }
        if (_visibleTileCoords.isEmpty()) return
        _visibleTileBounds = TileBounds.fromCoords(_visibleTileCoords)
    }


    override suspend fun loadData(requestedIntervals: MutableList<TimeInterval>) = loadDataMutex.withLock {
        // Keep only the slots this layer's source can actually serve. Availability is per-source:
        // cadence and history depth differ per layer (alerts ~2.1 days at a 3-6min cadence;
        // encoded conditions far deeper), so the timeline's slots must be snapped onto *this*
        // source's valid times. A slot with no snap target here was never a needed interval for this
        // layer — requesting it yields a server error and it then stays pending forever, so progress
        // never reaches 100% and readiness gating never lets the layer animate.
        val vts = layer.source as? VectorTileSource
        val intervals: MutableList<TimeInterval> = if (vts == null) {
            requestedIntervals
        } else {
            val kept = requestedIntervals.filterTo(mutableListOf()) { vts.resolvedIntervalOrNull(it) != null }
            val dropped = requestedIntervals.size - kept.size
            if (dropped > 0 && _unavailableIntervalLog++ % 50L == 0L) {
                MapsGLDebug.logW(
                    TAG,
                    "loadData: ${layer.source.id} cannot serve $dropped of ${requestedIntervals.size} " +
                        "timeline slots (outside its published range); not requesting or awaiting them " +
                        "(1 in 50)"
                )
            }
            if (kept.isEmpty()) return@withLock
            kept
        }

        if (intervals.size != this._lastIntervals.size) {
            this.setNeedsUpdate();
        }

        if (!this.isDirty || (intervals.isEmpty())) {
            // console.warn('TiledTimeSeriesDataProvider.loadData', 'no intervals or not dirty', intervals.length, this.isDirty);
            return@withLock;
        }

        this._updateVisibleTileCoordsState()
        if (!::_visibleTileCoords.isInitialized || this._visibleTileCoords.isEmpty()) return@withLock

        ensureIntervalCache()

        this._lastIntervals = intervals

        evictOffscreenTiles()

        // Iterate through tile coords and determine which intervals data is missing for.
        val allCoordsToRequest = this.calculateMissingTileIntervals(intervals);

        // Bound the work one pass can dispatch. `requestTiles` launches a coroutine per tile and
        // this runs on the main thread, so a pathological viewport (transient bad latitude bounds
        // have produced 3000+ tile rows for a single screen) hangs the UI outright and takes the
        // heap with it. This is a throttle rather than a drop: the surplus stays needed, dirty is
        // left set, and the next pass picks it up.
        val overBudget = allCoordsToRequest.size > MAX_COORDS_PER_PASS
        val coordsToRequest = if (overBudget) {
            android.util.Log.w(
                TAG,
                "loadData: viewport wants ${allCoordsToRequest.size} tiles, capping at " +
                    "$MAX_COORDS_PER_PASS this pass (remainder deferred, not dropped)"
            )
            allCoordsToRequest.subList(0, MAX_COORDS_PER_PASS).toMutableList()
        } else {
            allCoordsToRequest
        }
        if (coordsToRequest.size == 0) {
            // this.onReady();
            // console.warn('TiledTimeSeriesDataProvider.loadData', 'no missing data', intervals.length, this._visibleTileCoords.length, coordsToRequest.length);
            return@withLock;
        }

        // console.log('TiledTimeSeriesDataProvider.loadData', 'needed', intervals.length, 'request', coordsToRequest.length, coordsToRequest);
        trigger(
            TimeSeriesEvent.DATA_REQUEST,
            intervals,
            0
        ) //extra variable 0 to avoid signature clash after type erasure.


        // Clear queues from a previous pass only for encoded/raster series. Vector time-series
        // tiles accumulate intervals per spatial key; canceling in-flight MVT downloads during
        // playback left random intervals blank and non-deterministic on loop.
        val isVectorTimeSeries = (layer.source as? VectorTileSource)?.isTimeSeriesSource == true
        if (!isVectorTimeSeries) {
            this.invalidate()
        }
        // Only clear dirty when the whole viewport was dispatched; otherwise the deferred
        // remainder would never be requested.
        this._isDirty = overBudget
        // this._pending.clear();

        // Break up the intervals into smaller chunks for the requests.
        val taskChunks =
            createTileIntervalChunks(coordsToRequest, this.maxIntervalsPerRequest, this.interleaveRequests);
        if (taskChunks.isEmpty()) {
            // this.onReady(); //commented out in js version
            return@withLock;
        }

        // Put the first chunk into the primary queue to load the minimal amount of data required to begin animating.
        val primaryTaskChunk = taskChunks.shift()

        // NOTE: this loop stays on the caller's thread (Dispatchers.Main, via
        // TimeSeriesAnimator.loadDataIfNeeded) on purpose for now. Moving it to Dispatchers.Default
        // does remove the ANR's proximate cause — the main thread launching a coroutine per tile —
        // but measured *worse* overall: the UI thread's slowness was acting as an unintended
        // throttle on dispatch, and without it the heap climbed 133MB -> 277MB by cycle 2 of the
        // alerts+temperature soak. Doing this properly needs an explicit concurrency bound on
        // dispatch, not just a thread change.
        if (primaryTaskChunk != null) {
            for (tileInterval in primaryTaskChunk) {
                enqueueTileRequestIfNeeded(queues.primary, tileInterval.coord, tileInterval.intervals)
            }
        }

        // Put the rest of the chunks into a background queue, sorted starting from the middle out to fill in the data
        // gaps relatively evenly if interleaving is enabled. Otherwise, loading will be in the order of the chunks.

        val sortedTaskChunks = if (interleaveRequests) sortedIntervalChunks(taskChunks) else taskChunks

        for (taskChunk in sortedTaskChunks) {
            val tempQueue = Queue<Any>()
            for (tileInterval in taskChunk) {
                enqueueTileRequestIfNeeded(tempQueue, tileInterval.coord, tileInterval.intervals)
            }
            this.queues.background.push(tempQueue)
        }

        this.queues.primary.start();
        // Nothing ever started the background collection, so every chunk queue pushed above was
        // retained and never run. Its tasks only publish already-issued requests, so draining them
        // costs nothing; leaving them queued cost ~179MB of closures in the 2026-08-24 soak.
        this.queues.background.start();
    }

    fun <T> MutableList<T>.shift(): T? {
        if (this.isEmpty()) {
            return null
        }
        return this.removeAt(0)
    }

    override fun invalidate() {
        super.invalidate();
        this.queues.primary.cancel();
        this.queues.background.cancel();
        // Cancelled requests will never reach the clearing site, so drop their marks rather than
        // waiting out the TTL and stalling the next pass.
        this.layer.source.tileManager.clearAllRequestsInFlight()
    }

    /**
     * Calculates the intervals that are missing data for each visible tile.
     * @param intervals - The time intervals to check for missing data.
     * @returns An array of tile coordinates and their missing intervals.
     */
    private fun calculateMissingTileIntervals(intervals: MutableList<TimeInterval>): TileIntervalsArray {
        val source = this.layer.source;
        val neededIntervals: MutableList<TimeInterval> = intervals;
        val visibleCoords = this._visibleTileCoords;
        val coordsToRequest: TileIntervalsArray = mutableListOf()

        for (coord in visibleCoords) {
            val lookupCoord = when (val vts = source as? VectorTileSource) {
                null -> coord
                else -> if (vts.isTimeSeriesSource) vts.spatialTileCoord(coord.x, coord.y, coord.z) else coord
            }
            val tileData = source.getTileData(lookupCoord)
            ensureIntervalCache()
            _intervalTileCache.get(coord.hash()) // this bumps up the item's age in LRU cache if exists

            if (tileData == null) { // No data exists yet for this tile, so we need all intervals

                val requestedCoords = TileInterval(coord, intervals = neededIntervals)
                coordsToRequest.add(requestedCoords)
            } else if (tileData is EncodedTileData || tileData is BitmapTimeSeriesData<*>) {
                val missingIntervals =
                    (tileData as BitmapTimeSeriesData<*>).series.intervalsNeedingData(neededIntervals)
                val missingIntervalsToDownload: MutableList<TimeInterval> = mutableListOf()
                for (missingInterval in missingIntervals) {
                    val isPending = source.tileManager.isPending(coord, missingInterval.toInt())
                    if (!isPending) {
                        missingIntervalsToDownload.add(missingInterval)
                    } else {
                        //don't add item
                    }
                }
                if (missingIntervalsToDownload.size > 0) {
                    coordsToRequest.add(TileInterval(coord, intervals = missingIntervalsToDownload))
                }
            } else if (tileData is VectorTimeSeriesData) {
                val missingIntervals = tileData.intervalsNeedingData(neededIntervals)
                val missingIntervalsToDownload: MutableList<TimeInterval> = mutableListOf()
                for (missingInterval in missingIntervals) {
                    val isPending = source.tileManager.isPending(coord, missingInterval.toInt())
                    if (!isPending) {
                        missingIntervalsToDownload.add(missingInterval)
                    }
                }
                if (missingIntervalsToDownload.isNotEmpty()) {
                    coordsToRequest.add(TileInterval(coord, intervals = missingIntervalsToDownload))
                }
            } else if ((source as? VectorTileSource)?.isTimeSeriesSource == true) {
                coordsToRequest.add(TileInterval(coord, intervals = neededIntervals))
            } else {
                coordsToRequest.add(TileInterval(coord, intervals = intervals))
            }
        }
        return coordsToRequest;
    }

    /**
     * Adds a tile request to a queue if needed based on the intervals that are missing data for the tile.
     * @param queue - The queue to add the request to.
     * @param coord - The tile coordinate to request data for.
     * @param intervals - The time intervals to request data for.
     */
    companion object {
        /**
         * Most tiles one [loadData] pass will dispatch requests for. Normal viewports measured at
         * 18-104 tiles; pathological ones (transient bad latitude bounds during a zoom animation)
         * at 794-50630. Chosen well clear of legitimate use so it only ever clamps the anomaly,
         * and it logs when it does.
         */
        private const val MAX_COORDS_PER_PASS = 512


        /**
         * Most tiles this provider will treat as visible in one pass. Real viewports measure ~8
         * tiles (cols=2 rows=4); pathological ones have reported 12659. Bounds every downstream
         * O(visible) loop, including the per-coord cache lookups in [calculateMissingTileIntervals].
         */
        private const val MAX_VISIBLE_TILES = 256
    }

    /** Rate-limiter for the visible-set clamp warning, which otherwise fires many times per second. */
    private var _visibleClampLog: Long = 0

    /** Rate-limiter for the unavailable-interval warning. */
    private var _unavailableIntervalLog: Long = 0


    /**
     * Frees vector tiles for viewports that are no longer visible.
     *
     * Driven from [loadData] rather than `TileLayer.requestVisibleTiles`, because `onMove`
     * deliberately skips that path while the timeline plays — which is exactly when panning
     * accumulates tiles. Measured before this ran: 199 tiles retained against 18 visible, and a heap
     * dump attributed 276MB of `byte[]` (62% of the heap) to that payload. The bound the playback
     * rules imply is ~30 intervals x the onscreen tiles, which is ~25MB.
     *
     * [_visibleTileCoords] is trustworthy now that `getVisibleTileBounds` clamps the latitude span;
     * an earlier attempt centred a cap on a stale, huge span and kept the wrong rows, so genuinely
     * visible tiles were evicted and the layer never finished loading.
     *
     * Vector time-series follows iOS: keep the spatial tile, prune parsed intervals off-screen to
     * current+next ([VectorTileSource.pruneOffscreenParsedIntervals]), and let the interval LRU
     * (1.5× visible) drop tracking for coords that have left the viewport. Encoded/raster still
     * fully evicts off-screen cache entries.
     */
    private fun evictOffscreenTiles() {
        if (!::_visibleTileCoords.isInitialized) return
        val coords = _visibleTileCoords
        if (coords.isEmpty()) return

        val viewportKeySet = coords.mapTo(HashSet()) { it.hashShort() }
        // Protect zoom ancestors: determinePartial falls back to these coarser tiles while the new
        // zoom's exact tiles download, so evicting them turns "blurry parent" into a hard blank.
        val protectedAncestors = HashSet<String>()
        for (coord in coords) {
            var az = coord.z
            var ax = coord.x
            var ay = coord.y
            while (az > 0) {
                az -= 1
                ax = Math.floorDiv(ax, 2)
                ay = Math.floorDiv(ay, 2)
                protectedAncestors.add("0:$az/$ax/$ay")
            }
        }
        val vectorSource = layer.source as? VectorTileSource
        if (vectorSource != null && vectorSource.isTimeSeriesSource) {
            ensureIntervalCache()
            vectorSource.pruneOffscreenParsedIntervals(viewportKeySet, protectedAncestors)
            return
        }
        vectorSource?.evictTilesOutsideViewport(viewportKeySet, protectedAncestors)
    }

    private suspend fun enqueueTileRequestIfNeeded(queue: Queue<Any>, coord: TileCoord, intervals: List<TimeInterval>) {
        // Suppress intervals whose request is already outstanding. The old filter consulted
        // `tileManager.pending`, which nothing ever wrote to, and truncated epoch-ms Longs via
        // `toInt()`; it therefore never suppressed anything and every pass re-requested the same
        // intervals. See TileRequestManager._inFlight.
        val tileManager = this.layer.source.tileManager
        val nowMs = System.currentTimeMillis()
        // Derive the key once, not once per interval: hashShort() builds a String each call.
        val coordKey = coord.hashShort()
        val neededIntervals = intervals.filter { t -> !tileManager.isRequestInFlight(coordKey, t, nowMs) }
        if (pr.ON) pr.p(TAG, pr.partDL2512, "enqueueTileRequestIfNeeded() calling requestTiles with null intervals")
        if (neededIntervals.isNotEmpty()) {
            tileManager.markRequestsInFlight(coordKey, neededIntervals, nowMs)

            // Built only when there is actually something to request. This runs on the main thread
            // (loadData is dispatched to Dispatchers.Main) and LocalDateTime.now() plus toString()
            // is not free; once the in-flight filter began suppressing most calls, paying it
            // unconditionally made it the top main-thread cost in an ANR trace.
            val currentDateTime = LocalDateTime.now(ZoneOffset.UTC)
            val formattedDateTime =
                currentDateTime.toString().substring(0, 19) + "Z" // Looks like 2024-04-15T19:57:07.951703

            val requestedTile = layer.source.requestTiles(
                coord,
                TileRequestOptions(
                    //may also need isRadar here...
                    intervals = neededIntervals.map { t -> Date(t) },
                    reload = true,
                    checkPending = false,
                ),
                formattedDateTime,
                true,
                null,
            )

            onLoadProgress(neededIntervals.map { t -> Date(t) }) //FIXME: does this need to be done after enqueue?

            queue.enqueue(
                { requestedTile }
            )
        }
    }

    /** This is commented out in js version  **/
    //fun hasPendingRequest(coord: TileCoord, interval: TimeInterval): Boolean {
    //   val isSourcePending = this.layer.source.tileManager.pending    .isPending(coord, interval);
    //   val isLocalPending = this._pending.isPending(coord, interval);
    //   return isSourcePending || isLocalPending;
    //}

    /**
     * Sets up the LRU cache for restricting how much time series data is cached at once to restrict how much time
     * series data is cached at once to prevent excessive memory usage when animating data. This allows tiles no longer
     * visible and removed from the LRU cache to purge their time series data and WebGL textures from the cache.
     * @param capacity - The maximum number of tiles to cache at once.
     */

    private fun ensureIntervalCache() {
        val cap = intervalLruCapacityForVisibleTiles(
            if (::_visibleTileCoords.isInitialized) _visibleTileCoords.size else 0,
        )
        if (!::_intervalTileCache.isInitialized) {
            setupCache(cap)
        } else if (_intervalTileCache.capacity != cap) {
            _intervalTileCache.capacity = cap
            _intervalTileCache.evictDownToCapacity()
        }
    }

    private fun setupCache(capacity: Int) {
        val roundedCapacity = Math.ceil(capacity.toDouble()).toInt() //Kotlin does not have Math.ceil for Int

        _intervalTileCache = LRUCache<String, Tile<TileData>>(
            capacity = roundedCapacity,
            ttl = 0,
            onRemove = { _, value: Tile<TileData> ->
                if (::_visibleTileBounds.isInitialized && !_visibleTileBounds.contains(value.coord)) {
                    trigger(TimeSeriesEvent.DATA_REMOVE, mapOf("tile" to value))
                    val vts = layer.source as? VectorTileSource
                    if (vts != null && vts.isTimeSeriesSource) {
                        val keep = vts.playbackOffscreenKeepSnappedMs()
                        if (keep.isNotEmpty()) {
                            vts.pruneParsedIntervalsRetaining(
                                vts.spatialTileCoord(value.coord.x, value.coord.y, value.coord.z),
                                keep,
                            )
                        }
                    }
                }
            },
            canEvict = { _, value: Tile<TileData> ->
                value.coord.hashShort() !in _visibleSpatialKeys
            },
        )
    }


    // Source event handlers

    private fun onSourceLoadStart(): Unit {}

    private fun onSourceLoadComplete(): Unit {}

    private fun onSourceTileLoadStart(tile: Tile<TileData>? = null) {
        if (!::_visibleTileBounds.isInitialized) {
            _updateVisibleTileCoordsState()
        }

        // Set up LRU cache with a capacity slightly larger than the number of visible tiles since the capacity will
        // vary depending on map viewport size.
        ensureIntervalCache()

        // Only cache tiles that are within the current visible bounds which prevents tiles loaded before the cache
        // was cleared from being added to the cache if they aren't within the visible bounds.
        if (tile != null &&
            ::_visibleTileBounds.isInitialized &&
            this._visibleTileBounds.contains(tile.coord)
        ) {
            this._intervalTileCache[tile.coord.hash()] = tile
        }
    }

    private fun onSourceTileLoad(tile: Any? = null): Unit {
        // this.onLoadProgress([]); //commented out in js version
    }

    override fun dispose() {
        this.invalidate()

        val source = this.layer.source;
        val lambda = { _: String -> onSourceLoadStart() }

        //TODO: get .off() function working
        //source.eventDispatcher.off(DataSourceEvents.LoadStart(), lambda.toString())
        //source.eventDispatcher.off(DataSourceEvents.LoadComplete(), onSourceLoadComplete())
        //source.eventDispatcher.off(DataSourceEvents.TileLoadStart(), onSourceTileLoadStart())
        //source.eventDispatcher.off(DataSourceEvents.TileLoad(), onSourceTileLoad())


    }

    /**
     * Sorts an array of tile interval chunks so that we load those in the middle of each chunk first.
     * @param chunks - The chunks to sort.
     */
    fun sortedIntervalChunks(chunks: List<MutableList<MutableList<TileInterval>>>): List<MutableList<MutableList<TileInterval>>> {
        var indexOrder = chunks.mapIndexed { index, _ -> index }.toMutableList()

        if (chunks.size > 2) {
            fun <T> sortByMidpoint(out: MutableList<T>, arr: List<T>) {
                if (arr.size < 3) {
                    arr.forEach { v -> out.add(v) }
                    return
                }

                val mid = floor(arr.size.toDouble() / 2).toInt()
                out.add(arr[mid])
                sortByMidpoint(out, arr.subList(0, mid))
                sortByMidpoint(out, arr.subList(mid + 1, arr.size))
            }

            val sorted = mutableListOf<Int>()
            sortByMidpoint(sorted, indexOrder)
            indexOrder = sorted
        }
        return indexOrder.map { index -> chunks[index] }
    }

}

