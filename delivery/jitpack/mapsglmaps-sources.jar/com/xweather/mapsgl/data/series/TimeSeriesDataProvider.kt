package com.xweather.mapsgl.data.series

import com.xweather.mapsgl.anim.EventDispatcher
import com.xweather.mapsgl.events.TimeSeriesEvent
import java.util.Date

/** A helper class that performs remote data loading requests for data required by a `TimeSeriesAnimator` instance.
 * An instance of this class must provide a `loader` function which is responsible for performing the data request and
 * preparing it for the requested time intervals from the series.
 * @internal */
abstract class TimeSeriesDataProvider<TileLayer>(open val layer: TileLayer): EventDispatcher() {
    /** The maximum number of time intervals to request data for in a single request. Requests will be split into
     * multiple requests if the number of intervals needed exceeds this value.  */
    var maxIntervalsPerRequest = 1

    /** Whether to interleave (stagger) requests for multiple time intervals. */
    var interleaveRequests = true
    var _isDirty = true
    private var _loading = false
    private var _loaded = false

    var jPendingCount: Int = 0
    var jIsLoading: Boolean = false

    val isLoading: Boolean
        get() = _loading

    val hasLoaded: Boolean
        get() = _loaded

    val isReady: Boolean
        get() = !this.isLoading && this.hasLoaded

    val isDirty: Boolean
        get() = _isDirty





    /** Marks the data provider as needing an update, which will trigger a new data request on the next update cycle. */
    fun setNeedsUpdate() {
        this._isDirty = true
    }

    /** Returns a map of time intervals to a boolean value indicating whether the data for the interval is available as
     * determined by the data provider.
     * @remarks
     * This method should be implemented by subclasses to determine the state of the data for the given intervals based on
     * the data provider's internal data implementation and requirements.
     * @param intervals - The time intervals to check for data availability.   */
    abstract fun dataStateForIntervals(intervals: MutableList<TimeInterval>): Map<String, Boolean>

    /** Loads the data for the specified time intervals.
     * @param intervals - The time intervals to load data for. */
    abstract suspend fun loadData(intervals: MutableList<TimeInterval> = mutableListOf()) //used in TimeSeriesAnimator
    //abstract suspend fun loadData(intervals: MutableList<TimeInterval> = mutableListOf())

    /** Resets the state of the data provider, marking it as dirty and clearing any loaded data or existing requests. */
    open fun invalidate() {
        this._isDirty = false
        this._loading = false
        this._loaded = false
    }

    /** Called when the data provider is about to start loading data for a set of time intervals.
     * @param intervals - The time intervals that are about to be loaded.  */
    fun onLoadStart(intervals: Array<Date>) {
        // console.log('TimeSeriesDataProvider.onLoadStart');
        this._loading = true;
        this.triggerDatesArray(TimeSeriesEvent.LOAD_START.toString(),  intervals );
    }

    /** Called when the data provider has made progress loading data for a set of time intervals.
     * @param intervals - The time intervals that have been loaded so far. */
    protected fun onLoadProgress(intervals: List<Date>) {
        // console.log('TimeSeriesDataProvider.onLoadProgress', [...intervals]);
        this.triggerDatesList(TimeSeriesEvent.LOAD_INTERVAL.toString(), intervals) //TODO: Make sure the passed data is handled in trigger()
    }

    /** Called when the data provider has completed loading data for a set of time intervals.  */
    protected fun onLoadComplete() {
        this._loading = false
        this._loaded = true
        this.trigger(TimeSeriesEvent.LOAD_COMPLETE)
    }

    /** Called when all data has been loaded and is ready to be used by the animator.  */
    protected fun onReady() {
        this._isDirty = false
        // this._isDirty = false;
        this.trigger(TimeSeriesEvent.DATA_READY)
    }

    open fun dispose() {
        // clean up any resources
    }

}