package com.xweather.mapsgl

import androidx.lifecycle.Lifecycle

interface Promise<T> {
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    fun finally(onfinally: (() -> Unit)?): Promise<T>
}

/**
 * Make all properties in T optional
 */
typealias Partial<T> = Map<String, T?>


interface AbortController {
    val signal: AbortSignal
    fun abort(reason: Any?)
}

// from https://github.com/microsoft/TypeScript/blob/38da7c600c83e7b31193a62495239a0fe478cb67/lib/lib.webworker.d.ts#L633 until moved to separate lib
/** A controller object that allows you to abort one or more DOM requests as and when desired. */
interface AbortSignal : EventTarget {
    val aborted: Boolean
    val reason: Any
    var onabort: ((event: Lifecycle.Event) -> Any)?
    fun throwIfAborted()
}

interface EventTarget {
    fun addEventListener(type: String, callback: (Lifecycle.Event) -> Unit, options: AddEventListenerOptions? = null)
}

interface AddEventListenerOptions {
    var capture: Boolean?
    var passive: Boolean?
    var once: Boolean?
    var signal: AbortSignal?
}
