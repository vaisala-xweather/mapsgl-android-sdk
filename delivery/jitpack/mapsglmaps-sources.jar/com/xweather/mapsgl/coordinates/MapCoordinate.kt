package com.xweather.mapsgl.coordinates

import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.tan

val tag = "MapCoordinate"

/**
 * MapCoordinate.kt
 *
 * Adapted from IOS version
 *
 *  A 2D coordinate on a map or the world, in one of many `CoordinateSpace`s or zoom levels of some.
 *  Not intended to represent a `zoomLevel` as a 3rd dimension— this is where on the 2D map you are, with any `CoordinateSpace` zoom levels already figured in.
 *  (Any potential 3rd dimension would be altitude.)
 *
 * @author Jason Suto 12/22/23
 *
 */
data class MapCoordinate<Space : MapCoordinateSpace>(
    val value: MapCoordinateValue,
    val space: Space
) {
    private val TAG = "MapCoordinate"

    fun <ToSpace : MapCoordinateSpace> converted(space: ToSpace): MapCoordinate<ToSpace> {
        // Used in TileLayer.getvisibleTileBounds()
        val xTile = ((value.x + 180) / 360 * (1 shl space.zoomLevel.toInt()))
        val yTile = ((1 - ln(tan(Math.toRadians(value.y)) + 1 / cos(Math.toRadians(value.y))) / Math.PI)
                * .5 * (1 shl space.zoomLevel.toInt()))

        return MapCoordinate<ToSpace>(MapCoordinate(LatLon(yTile, xTile), space).value, space)
    }

    fun <ToSpace : MapCoordinateSpace> convertedTo(space: ToSpace): MapCoordinate<ToSpace> {
        val xTile = ((value.x + 180) / 360 * (1 shl space.zoomLevel.toInt()))
        val yTile = ((1 - ln(tan(Math.toRadians(value.y)) + 1 / cos(Math.toRadians(value.y))) / Math.PI)
                * .5 * (1 shl space.zoomLevel.toInt()))
        return MapCoordinate(MapCoordinate(LatLon(yTile, xTile), space).value, space)

        error("Not implemented")
    }

    fun getMapTile(lat: Double, long: Double, zoomLevel: Int): String {
        val xTile = ((long + 180) / 360 * (1 shl zoomLevel)).toInt()
        val yTile =
            ((1 - ln(tan(Math.toRadians(lat)) + 1 / cos(Math.toRadians(lat))) / Math.PI) / 2 * (1 shl zoomLevel)).toInt()
        return "https://maps.example.com/${zoomLevel}/${xTile}/${yTile}.png"
    }

}

typealias CoordinateValue = MapCoordinateValue
typealias MapTile2 = MapTileCoordinateSpace
typealias UnitMercator = UnitWebMercatorCoordinateSpace
typealias LatitudeLongitude = LatitudeLongitudeCoordinateSpace
typealias GoogleMercator = GoogleWebMercatorCoordinateSpace
typealias MapboxMercator = MapboxWebMercatorCoordinateSpace

fun MapCoordinate<LatitudeLongitudeCoordinateSpace>.converted(space: MapboxMercator): MapCoordinate<MapboxWebMercatorCoordinateSpace> {
    return this.converted(UnitWebMercatorCoordinateSpace()).converted(space)
}

fun MapCoordinate<MapboxWebMercatorCoordinateSpace>.converted(space: LatitudeLongitudeCoordinateSpace): MapCoordinate<LatitudeLongitudeCoordinateSpace> {
    return this.converted(UnitWebMercatorCoordinateSpace()).converted(space)
}


