/**
 * MapCoordinateSpace.kt
 *  @author Jason Suto on 12/21/23.
 */
//
//  MapCoordinateSpace.swift
//
//
//  Created by Jason Suto on 12/21/23.
//

package com.xweather.mapsgl.coordinates

import kotlin.math.pow

typealias MapTile = MapTileCoordinateSpace

interface MapCoordinateValue {
    val x: Scalar
    val y: Scalar
}

typealias Scalar = Double

data class LatLon(
    val latitude: Double,
    val longitude: Double
) : MapCoordinateValue {
    override val x: Scalar
        get() = longitude
    override val y: Scalar
        get() = latitude
}

data class SIMD2<T>(
    override val x: Double,
    override val y: Double
) : MapCoordinateValue

interface MapCoordinateSpace {
    val tileSize: Double
        get() = 23.0
    val zoomLevel: Double
        get() = 23.0
    val worldSize: Double
}

data class LatitudeLongitudeCoordinateSpace(
    override val tileSize: Double = 256.0,
    override val zoomLevel: Double = 0.0
) : MapCoordinateSpace {

    override val worldSize: Double
        get() = tileSize
}

data class MapTileCoordinateSpace(
    override val tileSize: Double = 256.0,
    override val zoomLevel: Double
) : MapCoordinateSpace {
    override val worldSize: Double
        get() = 2.0.pow(zoomLevel) * tileSize //TODO: Check exp works same as ios exp2
}

data class UnitWebMercatorCoordinateSpace(
    override val tileSize: Double = 1.0,
    override val zoomLevel: Double = 0.0
) : MapCoordinateSpace {
    override val worldSize: Double
        get() = tileSize
}

data class GoogleWebMercatorCoordinateSpace(
    override val tileSize: Double = 256.0,
    override val zoomLevel: Double = 0.0
) : MapCoordinateSpace {

    var testInt = 0
    override val worldSize: Double
        get() = tileSize
}

data class MapboxWebMercatorCoordinateSpace(
    override val tileSize: Double = 512.0,
    override val zoomLevel: Double
) : MapCoordinateSpace {
    override val worldSize: Double
        get() = 2.0.pow(zoomLevel) * tileSize //TODO: Check 2.0.pow()  works same as ios exp2()
}