package com.xweather.mapsgl.controls

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.ContextCompat
import com.mapbox.geojson.Point
import com.mapbox.maps.ScreenCoordinate
import com.xweather.mapsgl.data.DataInspectorResult
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.layers.tile.EncodedTileLayer
import com.xweather.mapsgl.layers.tile.VectorTileLayer
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.map.mapbox.MapboxMapController
import com.xweather.mapsgl.views.GridLayoutDivider
import com.xweather.mapsglmaps.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

/** Popover-style bubble that presents title/value metadata and can point at a map feature.
 *
 * Callers populate the callout with ``CalloutDataEntry`` instances via ``configure(title:entries:)``
 * and position it relative to a target using ``layout(pointingAt:within:placement:preferredMaxWidth:)``.
 **/
@Suppress("Dokka")
class CalloutView(val controller: MapController) {
    internal val TAG = "CalloutView"
    val mapView = controller.mapView
    val view: ConstraintLayout = createPopupLayout(mapView.context)
    /** Parent for [view]; usually the [MapView]'s parent so legends drawn on the activity root do not cover the callout. */
    internal var calloutHost: ViewGroup = mapView
    private var hostOffsetX = 0f
    private var hostOffsetY = 0f
    private val gridDivider: GridLayoutDivider = GridLayoutDivider(mapView.context)
    private lateinit var outerView: LinearLayout
    private lateinit var coordTextView: TextView
    private lateinit var dataRow: LinearLayout
    private lateinit var downArrow: View
    private lateinit var upArrow: View
    private lateinit var rootLayout: ConstraintLayout
    private lateinit var contentContainer: LinearLayout
    private lateinit var gridLayout: GridLayout
    private var xOffset = 0f
    private var yOffset = 0f
    private var finalVis = true
    private var dataColorInt = 0
    private val topBackgroundDrawable: GradientDrawable
    private val bottomBackgroundDrawable: GradientDrawable
    private var active = false
    private var onlyCoords = true
    private var emptyResultStreak: Int = 0
    private val emptyResultStreakToHideData: Int = 2
    // If we have no encoded layers at query-time, clear immediately (no hysteresis).
    private var forceHideOnEmptyOnce: Boolean = false
    private var calcWidth = 0
    private var lastX = 0f
    private var lastY = 0f
    private var lastViewX = -999f
    private var lastViewY = -999f
    private var maxWidth = 320
    private var coordWidth = 190
    internal var flickerVis = View.VISIBLE
    internal var coordinate: ScreenCoordinate? = null
    private var lastPoint: Point? = null
    internal var currentPoint: Point? = null
    private val keepOnScreen = true

    /**
     * When the anchor pixel leaves [mapView] bounds, [moveView] either invokes [dismissDueToOffScreenAction]
     * (when `true`, the default: full dismiss via [DataInspectorControl]) or hides the bubble with
     * [View.INVISIBLE] while leaving the inspector logically active (`false`, legacy).
     */
    internal var cancelCalloutWhenAnchorOffScreen: Boolean = true

    /**
     * Called on the main thread from [moveView] when the anchor is outside [mapView] and
     * [cancelCalloutWhenAnchorOffScreen] is `true`. Wired by [DataInspectorControl] to clear the callout
     * without turning off inspector mode.
     */
    internal var dismissDueToOffScreenAction: (() -> Unit)? = null

    private var inspectorQueryJob: Job? = null
    private var inspectorQueryGeneration: Int = 0

    /// Radius applied to the bubble's rounded corners.
    private val cornerRadius = 16f
    private var coordBottomRadius = 0f
    var moved = false

    // Reused across applyGridData / moveView to avoid per-frame allocations during camera drag.
    private val dedupEncodedTitles = mutableListOf<String>()
    private val dedupEncodedValues = mutableListOf<String>()
    private val seenEncoded = HashSet<String>()
    private val dedupVectorTitles = mutableListOf<String>()
    private val dedupVectorValues = mutableListOf<String>()
    private val seenVector = HashSet<String>()
    private val topCornerRadiiScratch = FloatArray(8)
    private val bottomCornerRadiiScratch = FloatArray(8)

    /** Re-pin the arrow tip when grid rows change height (grow up/down from anchor, not from center). */
    private val bubbleLayoutChangeListener =
        View.OnLayoutChangeListener { _, top, _, bottom, _, oldTop, _, _, oldBottom ->
            if (!isActive() || (bottom - top) == (oldBottom - oldTop)) return@OnLayoutChangeListener
            reanchorToLastPixel()
        }

    init {
        upArrow.visibility = View.GONE

        topBackgroundDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadii = floatArrayOf(
                cornerRadius, cornerRadius, cornerRadius, cornerRadius,
                coordBottomRadius, coordBottomRadius, coordBottomRadius, coordBottomRadius
            )
        }

        bottomBackgroundDrawable = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, cornerRadius, cornerRadius, cornerRadius, cornerRadius)
        }

        coordTextView.background = topBackgroundDrawable
        dataRow.background = bottomBackgroundDrawable
        setDataTextViewColor(Color.WHITE)
        view.addOnLayoutChangeListener(bubbleLayoutChangeListener)
    }

    /** Height of the full bubble for anchoring; uses measured height before first layout pass. */
    private fun effectiveBubbleHeight(): Int {
        if (view.height > 0) return view.height
        val maxW = if (onlyCoords) coordWidth else maxWidth
        val wSpec = View.MeasureSpec.makeMeasureSpec(maxW, View.MeasureSpec.AT_MOST)
        val hSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        view.measure(wSpec, hSpec)
        return view.measuredHeight.coerceAtLeast(1)
    }

    /** Keeps the arrow tip on [lastViewX]/[lastViewY] after async data rows change bubble height. */
    private fun reanchorToLastPixel() {
        if (!isActive() || lastViewX < 0f || lastViewY < 0f) return
        if (view.width > 0 && view.height > 0) {
            moveView(lastViewX, lastViewY)
        } else {
            view.post {
                if (isActive()) moveView(lastViewX, lastViewY)
            }
        }
    }

    fun isActive(): Boolean {
        return active
    }

    internal fun attachToHost(host: ViewGroup) {
        calloutHost = host
        refreshHostOffset()
    }

    /** Maps Mapbox pixel coords (relative to [mapView]) into [calloutHost] space. */
    internal fun refreshHostOffset() {
        if (calloutHost === mapView) {
            hostOffsetX = 0f
            hostOffsetY = 0f
            return
        }
        val mapLoc = IntArray(2)
        val hostLoc = IntArray(2)
        mapView.getLocationInWindow(mapLoc)
        calloutHost.getLocationInWindow(hostLoc)
        hostOffsetX = (mapLoc[0] - hostLoc[0]).toFloat()
        hostOffsetY = (mapLoc[1] - hostLoc[1]).toFloat()
    }

    fun show(
        point: Point,
        diResult: DataInspectorResult,
        at: ScreenCoordinate? = null,
        updateData: Boolean = true
    ) {

        active = true
        currentPoint = point
        setCoordText(currentPoint!!)
        moved = lastPoint != currentPoint
        lastPoint = point
        // Avoid toggling view visibility during playback updates (it causes rapid flicker).
        // We'll keep the callout visible and only update its text/value content.

        if (updateData) {
            // Offload encoded tile queries off the main thread (they can be expensive),
            // then update the UI when the query completes.
            val screenCoordinate = at ?: mapView.mapboxMap.pixelForCoordinate(currentPoint!!)
            val shouldReposition = moved || view.width <= 0 || view.height <= 0
            updateDataAsync(
                diResult,
                screenCoordinate,
                shouldReposition,
                spatialMove = moved,
                cancelInFlight = true,
            )
        }
        if (!updateData) {
            updateGridData(diResult)
            finalizeLayoutAndMove(at ?: mapView.mapboxMap.pixelForCoordinate(currentPoint!!))
        }
    }

    /**
     * @param spatialMove true when the inspector point changed on the map (new tap/drag).
     *   Empty-result hysteresis is only for the same map point while the timeline updates;
     *   skipping [applyGridData] on a new tap would leave stale precip text for one frame.
     */
    fun updateGridData(dIResult: DataInspectorResult, spatialMove: Boolean = false) {
        if (!isActive()) return

        if (dIResult.encodedTitles.isEmpty() && dIResult.vectorTitles.isEmpty()) {
            if (forceHideOnEmptyOnce) {
                emptyResultStreak = 0
                forceHideOnEmptyOnce = false
                onlyCoords = true
                dataRow.visibility = View.GONE
                setCoordMode(onlyCoords)
                applyGridData(dIResult)
                return
            }
            emptyResultStreak++
            // If encoded queries temporarily return no values while the timeline is moving,
            // we don't want to constantly toggle the whole callout layout.
            if (!onlyCoords && emptyResultStreak < emptyResultStreakToHideData && !spatialMove) {
                return
            }
            onlyCoords = true
            dataRow.visibility = View.GONE
        } else {
            emptyResultStreak = 0
            forceHideOnEmptyOnce = false
            onlyCoords = false
            dataRow.visibility = View.VISIBLE
        }
        setCoordMode(onlyCoords)
        // Apply the data to the views immediately.
        applyGridData(dIResult)
        reanchorToLastPixel()
    }

    /** True when the white encoded/vector grid is stacked under the coordinate header. */
    private fun hasDataSection(): Boolean =
        dataRow.visibility == View.VISIBLE && !onlyCoords

    /**
     * Coordinate bar is fully rounded only when it is the sole callout content; when data rows
     * are visible its bottom edge must be square so it meets the data panel flush.
     */
    private fun applyCoordHeaderCornerRadii() {
        val bottomR = if (hasDataSection()) 0f else cornerRadius
        coordBottomRadius = bottomR
        val s = topCornerRadiiScratch
        s[0] = cornerRadius
        s[1] = cornerRadius
        s[2] = cornerRadius
        s[3] = cornerRadius
        s[4] = bottomR
        s[5] = bottomR
        s[6] = bottomR
        s[7] = bottomR
        topBackgroundDrawable.cornerRadii = s
    }

    private fun applyGridData(dIResult: DataInspectorResult) {
        // Dedupe by displayed title+value (wind fill/particles/barbs/arrows share one "Winds" row).
        dedupEncodedTitles.clear()
        dedupEncodedValues.clear()
        seenEncoded.clear()
        for (i in dIResult.encodedLayerIds.indices) {
            if (i >= dIResult.encodedTitles.size || i >= dIResult.encodedValues.size) continue
            val title = dIResult.encodedTitles[i]
            val value = dIResult.encodedValues[i]

            val rowKey = "$title\u0000$value"
            if (!seenEncoded.add(rowKey)) continue
            dedupEncodedTitles.add(title)
            dedupEncodedValues.add(value)
        }

        dedupVectorTitles.clear()
        dedupVectorValues.clear()
        seenVector.clear()
        for (i in dIResult.vectorLayerIds.indices) {
            if (i >= dIResult.vectorTitles.size || i >= dIResult.vectorValues.size) continue
            val title = dIResult.vectorTitles[i]
            val value = dIResult.vectorValues[i]
            val rowKey = "$title\u0000$value"
            if (!seenVector.add(rowKey)) continue
            dedupVectorTitles.add(title)
            dedupVectorValues.add(value)
        }

        val encCount = dedupEncodedTitles.size
        val vecCount = dedupVectorTitles.size
        val newRowCount = encCount + vecCount
        val currentChildCount = gridLayout.childCount
        val currentRowCount = currentChildCount / 2

        for (i in 0 until newRowCount) {
            val name: String
            val value: String
            if (i < encCount) {
                name = dedupEncodedTitles[i]
                value = dedupEncodedValues[i]
            } else {
                val vi = i - encCount
                name = dedupVectorTitles[vi]
                value = dedupVectorValues[vi]
            }
            val nameIndex = i * 2
            val valueIndex = i * 2 + 1
            if (i < currentRowCount) {
                (gridLayout.getChildAt(nameIndex) as? TextView)?.text = name
                (gridLayout.getChildAt(valueIndex) as? TextView)?.text = value
            } else {
                val nameTextView = createTitleTextView(name)
                val valueTextView = createValueTextView(value)
                gridLayout.addView(nameTextView)
                gridLayout.addView(valueTextView)
            }
        }

        if (newRowCount < currentRowCount) {
            val startIndexToRemove = newRowCount * 2
            val countToRemove = currentChildCount - startIndexToRemove
            if (countToRemove > 0) {
                gridLayout.removeViews(startIndexToRemove, countToRemove)
            }
        }
    }

    internal fun update(dIResult: DataInspectorResult, updateData: Boolean = true) {
        if (!isActive()) return

        if (lastPoint == null) {
            return
        }
        currentPoint = lastPoint
        if (!updateData) {
            if (pr.ON) pr.p(TAG, pr.dIAnimation, "update() refresh layout only")
            updateGridData(dIResult)
            finalizeLayoutAndMove(mapView.mapboxMap.pixelForCoordinate(currentPoint!!))
            return
        }
        if (pr.ON) pr.p(TAG, pr.dIAnimation, "update() timeline encoded refresh (no cancel)")
        val screenCoordinate = mapView.mapboxMap.pixelForCoordinate(currentPoint!!)
        updateDataAsync(
            dIResult,
            screenCoordinate,
            shouldReposition = false,
            spatialMove = false,
            cancelInFlight = false,
        )
    }

    /** Resets move/empty-state tracking so the next [show] is treated as a new map tap. */
    fun prepareForSpatialTap() {
        lastPoint = null
        emptyResultStreak = 0
        forceHideOnEmptyOnce = false
        flickerVis = View.VISIBLE

    }

    private fun updateData() {
        val relevantLayers = controller.layers.values.filter {
            it.visible && !it.id.startsWith("mas")
        }

        val vectorList = relevantLayers.filterIsInstance<VectorTileLayer>()
        if (vectorList.isNotEmpty()) {
            if (controller is MapboxMapController) {
                MainScope().launch {
                    try {
                        controller.queryFeatures(currentPoint!!, vectorList)
                    } catch (e: Exception) {
                        println("Failed to query vector features, $e")
                    }
                }
            }

        } else if (controller is MapboxMapController) {
            controller.dataInspector.dIResult.clearVector()
        }

        val encodedList = relevantLayers.filterIsInstance<EncodedTileLayer>()
        controller.query(currentPoint!!, encodedList)
    }

    private fun updateDataAsync(diResult: DataInspectorResult, screenCoordinate: ScreenCoordinate) {
        updateDataAsync(diResult, screenCoordinate, shouldReposition = true, spatialMove = false)
    }

    private fun updateDataAsync(
        diResult: DataInspectorResult,
        screenCoordinate: ScreenCoordinate,
        shouldReposition: Boolean,
        spatialMove: Boolean = false,
        cancelInFlight: Boolean = true,
    ) {
        if (!cancelInFlight && inspectorQueryJob?.isActive == true) {
            return
        }
        if (cancelInFlight) {
            inspectorQueryJob?.cancel()
            inspectorQueryGeneration++
        }
        val generation = inspectorQueryGeneration

        inspectorQueryJob = MainScope().launch {
            // Gather the layer lists on main quickly (cheap filter).
            val relevantLayers = controller.layers.values.filter {
                it.visible && !it.id.startsWith("mas")
            }
            val vectorList = relevantLayers.filterIsInstance<VectorTileLayer>()
            val encodedList = relevantLayers.filterIsInstance<EncodedTileLayer>()

            // Vector queries may need map/controller access; keep as-is (still on this coroutine).
            if (vectorList.isNotEmpty() && controller is MapboxMapController) {
                try {
                    controller.queryFeatures(currentPoint!!, vectorList)
                } catch (e: Exception) {
                    println("Failed to query vector features, $e")
                }
            } else if (controller is MapboxMapController) {
                controller.dataInspector.dIResult.clearVector()
            }

            // Encoded queries are the heavy part; run them off the main thread.
            if (encodedList.isNotEmpty()) {
                withContext(Dispatchers.Default) {
                    controller.query(currentPoint!!, encodedList)
                }
            } else {
                // If no encoded layers are currently visible, ensure we clear out any
                // previously-queried encoded values so removed/hidden layers disappear.
                forceHideOnEmptyOnce = true
                diResult.clearEncoded()
            }

            // If a newer query has been started, don't apply this result.
            if (generation != inspectorQueryGeneration) return@launch

            // Now update the UI on the main thread with the mutated `diResult`.
            updateGridData(diResult, spatialMove)
            if (shouldReposition) {
                finalizeLayoutAndMove(screenCoordinate)
            } else {
                view.visibility = View.VISIBLE
            }
        }
    }

    private fun finalizeLayoutAndMove(screenCoordinate: ScreenCoordinate) {
        // Attach a ONE-TIME listener that fires when the layout is complete.
        if (onlyCoords) { // If only coords, simplified logic
            view.visibility = View.VISIBLE
            // If already laid out, move synchronously. Deferring with post() stacks stale closures when
            // callers (e.g. camera) reposition every frame and fight with explicit move().
            if (view.width > 0 && view.height > 0) {
                moveView(screenCoordinate.x.toFloat(), screenCoordinate.y.toFloat())
            } else {
                view.post {
                    moveView(screenCoordinate.x.toFloat(), screenCoordinate.y.toFloat())
                }
            }
        } else {
            // If already measured, avoid repeatedly adding global layout listeners.
            if (view.width > 0 && view.height > 0) {
                moveView(screenCoordinate.x.toFloat(), screenCoordinate.y.toFloat())
                view.visibility = View.VISIBLE
            } else {
                view.viewTreeObserver.addOnGlobalLayoutListener(object :
                    ViewTreeObserver.OnGlobalLayoutListener {
                    override fun onGlobalLayout() {
                        // One-time operation, remove immediately to avoid leaks.
                        view.viewTreeObserver.removeOnGlobalLayoutListener(this)
                        moveView(screenCoordinate.x.toFloat(), screenCoordinate.y.toFloat())
                        view.visibility = View.VISIBLE
                    }
                })
            }
        }
    }

    /**
     * Repositions the callout bubble for the anchor at (`inputX`, `inputY`) in **map view** pixels,
     * or the last stored anchor if arguments are omitted.
     *
     * If the anchor lies outside `0..<mapView.width` × `0..<mapView.height`:
     * - When [cancelCalloutWhenAnchorOffScreen] is `true`, runs [dismissDueToOffScreenAction] and returns early.
     * - Otherwise sets the view to [View.INVISIBLE] but keeps [isActive] for timeline-driven updates.
     *
     * @param inputX Anchor X in map view space; default `-999f` means reuse [lastViewX].
     * @param inputY Anchor Y in map view space; default `-999f` means reuse [lastViewY].
     */
    fun moveView(inputX: Float = -999f, inputY: Float = -999f) {

        if (!isActive()) return

        val x: Float = inputX.takeIf { it != -999f } ?: lastViewX
        val y: Float = inputY.takeIf { it != -999f } ?: lastViewY

        if (x.isNaN() || y.isNaN() || lastViewX == -999f && inputX == -999f) {
            return
        }

        refreshHostOffset()

        lastViewX = x
        lastViewY = y

        if (pr.ON) pr.p(TAG, pr.flickerFix, "moveView() x: $x, y:$y")

        calcWidth = when {
            view.width > 0 -> view.width
            onlyCoords -> coordWidth
            else -> maxWidth
        }

        val mapH = mapView.height
        val onScreen = x >= 0 && x < mapView.width && y >= 0 && y < mapH
        if (onScreen) {
            finalVis = true
            xOffset = 0f
            val bubbleH = effectiveBubbleHeight()
            // Down arrow: pin y is the bottom tip — grow upward (ty = y - height).
            // Up arrow: pin y is the top tip — grow downward (ty = y).
            // Use <= so we never enter down-arrow mode with ty < 0 when y == bubbleH.
            val pinAtTop = keepOnScreen && y <= bubbleH
            yOffset = if (pinAtTop) 0f else -bubbleH.toFloat()
            coordBottomRadius = if (hasDataSection()) 0f else cornerRadius

            if (pinAtTop) { // y too close to top of screen
                upArrow.x = (calcWidth / 2f - (downArrow.width / 2))
                upArrow.visibility = View.VISIBLE
                downArrow.visibility = View.GONE

                if (keepOnScreen && (x + (calcWidth / 2)) > mapView.width) { // bottom Right
                    xOffset = mapView.width - (x + calcWidth / 2)
                    upArrow.x -= xOffset

                    if (upArrow.x > (calcWidth - (cornerRadius + upArrow.width))) {
                        applyTopCornerRadiiUpArrowBottomRight()
                    } else {
                        normalizeTop()
                    }

                } else if (keepOnScreen && x - (calcWidth / 2) < 0) { // bottomLeft
                    xOffset = -(x - (calcWidth / 2))
                    upArrow.x -= xOffset

                    if (upArrow.x < cornerRadius) {
                        applyTopCornerRadiiUpArrowBottomLeft()
                    } else {
                        normalizeTop()
                    }
                } else {
                    normalizeTop()
                }
            } else { // down arrow — anchor at bottom of bubble
                downArrow.x = (calcWidth / 2f - (downArrow.width / 2))
                upArrow.visibility = View.GONE
                downArrow.visibility = View.VISIBLE
                normalizeTop()

                if (keepOnScreen && (x + (calcWidth / 2)) > mapView.width) { // bottom Right
                    xOffset = mapView.width - (x + calcWidth / 2)
                    downArrow.x -= xOffset

                    if (onlyCoords) {
                        if (downArrow.x > (calcWidth - (cornerRadius + downArrow.width))) {
                            fillBottomRightStyleRadii(downArrow.x, calcWidth, roundedTop = true, targetTop = true)
                        }
                    } else {
                        if (downArrow.x > (calcWidth - (cornerRadius + downArrow.width))) {
                            fillBottomRightStyleRadii(downArrow.x, calcWidth, roundedTop = false, targetTop = false)
                        } else {
                            defaultBottomRadius()
                        }
                        setDataTextViewColor(Color.WHITE)
                    }
                } else if (keepOnScreen && x - (calcWidth / 2) < 0) { // bottomLeft

                    xOffset = -(x - (calcWidth / 2))
                    downArrow.x -= xOffset

                    if (onlyCoords) {
                        if (downArrow.x < cornerRadius) {
                            fillBottomLeftStyleRadii(downArrow.x, roundedTop = true, targetTop = true)
                        }
                    } else {
                        if (downArrow.x < cornerRadius) {
                            fillBottomLeftStyleRadii(downArrow.x, roundedTop = false, targetTop = false)
                        } else {
                            defaultBottomRadius()
                        }
                        setDataTextViewColor(Color.WHITE)
                    }
                } else {
                    defaultBottomRadius()
                }
            }

            view.translationX = x - (calcWidth / 2) + xOffset + hostOffsetX
            val ty = y + yOffset
            // Do not clamp ty: the bubble must extend past the MapView top when panned up, and when
            // hosted on the activity root it must not be clipped at the MapView bottom (timeline edge).
            view.translationY = ty + hostOffsetY
        } else { // anchor pixel off map
            if (cancelCalloutWhenAnchorOffScreen) {
                dismissDueToOffScreenAction?.invoke()
                return
            }
            // hide visually but stay active for timeline refresh
            finalVis = false
        }

        if (finalVis && flickerVis == View.VISIBLE) {
            view.visibility = View.VISIBLE
        } else {
            if (pr.ON) pr.p(TAG, pr.flickerFix, "moveView() set to Invisible")
            view.visibility = View.INVISIBLE
        }
        lastX = x
        lastY = y
    }

    fun setActive(isActive: Boolean = true) {
        active = isActive

        if (active) {
            outerView.visibility = View.VISIBLE

        } else {
            outerView.visibility = View.GONE
        }
    }

    /**
     * Cancels the coroutine that loads encoded/query data for the inspector popup, if any.
     * Used when [hide] runs or when the callout is dismissed after panning off-screen.
     */
    internal fun cancelInFlightInspectorQuery() {
        inspectorQueryJob?.cancel()
        inspectorQueryJob = null
    }

    /**
     * Clears anchor pixel and geographic state after an off-screen dismiss ([DataInspectorControl.cancelCalloutWhenOffScreen])
     * so the next [show] does not reuse stale coordinates.
     */
    internal fun resetAfterOffScreenDismiss() {
        lastViewX = -999f
        lastViewY = -999f
        lastX = 0f
        lastY = 0f
        lastPoint = null
        currentPoint = null
        moved = false
    }

    private fun fillBottomLeftStyleRadii(downArrowX: Float, roundedTop: Boolean, targetTop: Boolean) {
        val topRadius = if (roundedTop) cornerRadius else 0f
        val s = if (targetTop) topCornerRadiiScratch else bottomCornerRadiiScratch
        s[0] = topRadius
        s[1] = topRadius
        s[2] = topRadius
        s[3] = topRadius
        s[4] = cornerRadius
        s[5] = cornerRadius
        s[6] = downArrowX
        s[7] = cornerRadius
        if (targetTop) topBackgroundDrawable.cornerRadii = s else bottomBackgroundDrawable.cornerRadii = s
    }

    private fun fillBottomRightStyleRadii(downArrowX: Float, width: Int, roundedTop: Boolean, targetTop: Boolean) {
        val topRadius = if (roundedTop) cornerRadius else 0f
        val s = if (targetTop) topCornerRadiiScratch else bottomCornerRadiiScratch
        s[0] = topRadius
        s[1] = topRadius
        s[2] = topRadius
        s[3] = topRadius
        s[4] = width - (downArrowX + 23)
        s[5] = cornerRadius
        s[6] = cornerRadius
        s[7] = cornerRadius
        if (targetTop) topBackgroundDrawable.cornerRadii = s else bottomBackgroundDrawable.cornerRadii = s
    }

    private fun defaultBottomRadius() {
        val s = bottomCornerRadiiScratch
        s[0] = 0f
        s[1] = 0f
        s[2] = 0f
        s[3] = 0f
        s[4] = cornerRadius
        s[5] = cornerRadius
        s[6] = cornerRadius
        s[7] = cornerRadius
        bottomBackgroundDrawable.cornerRadii = s
    }

    private fun normalizeTop() {
        val s = topCornerRadiiScratch
        s[0] = cornerRadius
        s[1] = cornerRadius
        s[2] = cornerRadius
        s[3] = cornerRadius
        s[4] = coordBottomRadius
        s[5] = coordBottomRadius
        s[6] = coordBottomRadius
        s[7] = coordBottomRadius
        topBackgroundDrawable.cornerRadii = s
    }

    private fun applyTopCornerRadiiUpArrowBottomRight() {
        val s = topCornerRadiiScratch
        s[0] = cornerRadius
        s[1] = cornerRadius
        s[2] = calcWidth - (upArrow.x + cornerRadius)
        s[3] = cornerRadius
        s[4] = coordBottomRadius
        s[5] = coordBottomRadius
        s[6] = coordBottomRadius
        s[7] = coordBottomRadius
        topBackgroundDrawable.cornerRadii = s
    }

    private fun applyTopCornerRadiiUpArrowBottomLeft() {
        val s = topCornerRadiiScratch
        s[0] = upArrow.x
        s[1] = cornerRadius
        s[2] = cornerRadius
        s[3] = cornerRadius
        s[4] = coordBottomRadius
        s[5] = coordBottomRadius
        s[6] = coordBottomRadius
        s[7] = coordBottomRadius
        topBackgroundDrawable.cornerRadii = s
    }

    private fun hexToColorInt(hexColorString: String): Int {
        try {
            @ColorInt val colorInt: Int = Color.parseColor(hexColorString)
            return colorInt
        } catch (e: IllegalArgumentException) {
            println("Error: Invalid color string '$hexColorString'. ${e.message}")
            return 0 // Or throw the exception, or return a default color
        }
    }

    private fun doubleTo3DigitString(number: Double, useLocale: Locale = Locale.US): String {
        return String.format(useLocale, "%.3f", number)
    }

    private fun createTitleTextView(text: String): TextView {
        return TextView(gridLayout.context).apply {
            layoutParams = GridLayout.LayoutParams().apply {
                topMargin = 1.toPx()
            }

            this.text = text
            setTextColor(ContextCompat.getColor(context, R.color.black))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(4.toPx(), 2.toPx(), 30.toPx(), 2.toPx())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            maxWidth = 130.toPx()
        }
    }

    private fun createValueTextView(text: String): TextView {
        return TextView(gridLayout.context).apply {
            layoutParams = GridLayout.LayoutParams().apply {
                topMargin = 1.toPx()
            }

            this.text = text
            setTextColor(ContextCompat.getColor(context, R.color.black))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(4.toPx(), 2.toPx(), 4.toPx(), 2.toPx())
            gravity = Gravity.CENTER_VERTICAL or Gravity.START
            maxWidth = 210.toPx()
        }
    }

    private fun Int.toPx(): Int = (this * view.context.resources.displayMetrics.density).toInt()

    private fun setCoordText(point: Point) {
        val coordText = "${doubleTo3DigitString(point.latitude())}, ${doubleTo3DigitString(point.longitude())}"
        this.coordTextView.text = coordText
    }

    private fun setCoordMode(onlyCoords: Boolean) {
        if (onlyCoords) {
            topBackgroundDrawable.setColor(Color.WHITE)
            coordTextView.gravity = Gravity.CENTER_HORIZONTAL
            coordTextView.setTextColor(Color.BLACK)
            coordTextView.maxWidth = 400

        } else {
            topBackgroundDrawable.setColor(hexToColorInt("#29ABE2"))
            coordTextView.gravity = Gravity.START
            coordTextView.setTextColor(Color.WHITE)
        }
        applyCoordHeaderCornerRadii()
    }

    private fun setDataTextViewColor(color: Int) {
        dataColorInt = color
        bottomBackgroundDrawable.setColor(color) // Initial color
    }

    private fun createPopupLayout(context: Context): ConstraintLayout {
        fun Int.toPx(): Int = (this * context.resources.displayMetrics.density).toInt()

        rootLayout = ConstraintLayout(context).apply {
            id = View.generateViewId()
            layoutParams = ConstraintLayout.LayoutParams(
                ConstraintLayout.LayoutParams.WRAP_CONTENT,
                ConstraintLayout.LayoutParams.WRAP_CONTENT
            )
        }

        outerView = LinearLayout(context).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        upArrow = View(context).apply {
            id = View.generateViewId() // Use R.id.up_arrow
            layoutParams = LinearLayout.LayoutParams(10.toPx(), 10.toPx())
            background = ContextCompat.getDrawable(context, R.drawable.up_arrow)
        }

        contentContainer = LinearLayout(context).apply {
            id = View.generateViewId() // Use R.id.content_container
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.VERTICAL
        }

        coordTextView = TextView(context).apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setTextColor(Color.WHITE)
            setPadding(8.toPx(), 2.toPx(), 6.toPx(), 2.toPx())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
        }

        dataRow = object : LinearLayout(context) {
            override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
                val newWidthMeasureSpec = MeasureSpec.makeMeasureSpec(320.toPx(), MeasureSpec.AT_MOST)
                super.onMeasure(newWidthMeasureSpec, heightMeasureSpec)
            }
        }.apply {
            id = View.generateViewId()
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            orientation = LinearLayout.HORIZONTAL
            setPadding(4.toPx(), (-2).toPx(), (4).toPx(), (0).toPx())
            setBackgroundColor(Color.WHITE)
            gravity = Gravity.TOP
        }


        // In createPopupLayout(), replace the original gridLayout creation with this:
        gridLayout = object : GridLayout(context) {
            override fun dispatchDraw(canvas: Canvas) {
                // First, let the GridLayout draw its children (the TextViews)
                super.dispatchDraw(canvas)
                // Now, draw our custom dividers on top of the children
                gridDivider.draw(canvas, this)
            }
        }.apply {
            columnCount = 2
            // It's good practice to disable clipping to padding so dividers can draw
            // into the padding area if needed, ensuring they span the full width.
            clipToPadding = false
        }

        downArrow = View(context).apply {
            id = View.generateViewId() // Use R.id.down_arrow
            layoutParams = LinearLayout.LayoutParams(10.toPx(), 10.toPx()).apply {
                topMargin = (-1).toPx() // layout_marginTop = -1dp
            }
            background = ContextCompat.getDrawable(context, R.drawable.down_arrow)
        }

        //dataRow.addView(layerNameTextView)
        //dataRow.addView(dataValueTextView)

        dataRow.addView(gridLayout)
        contentContainer.addView(coordTextView)
        contentContainer.addView(dataRow)
        outerView.addView(upArrow)
        outerView.addView(contentContainer)
        outerView.addView(downArrow)
        rootLayout.addView(outerView)

        val constraintSet = ConstraintSet()
        constraintSet.clone(rootLayout)
        constraintSet.connect(outerView.id, ConstraintSet.START, ConstraintSet.PARENT_ID, ConstraintSet.START)
        constraintSet.connect(outerView.id, ConstraintSet.END, ConstraintSet.PARENT_ID, ConstraintSet.END)
        constraintSet.connect(outerView.id, ConstraintSet.TOP, ConstraintSet.PARENT_ID, ConstraintSet.TOP)
        constraintSet.connect(outerView.id, ConstraintSet.BOTTOM, ConstraintSet.PARENT_ID, ConstraintSet.BOTTOM)
        constraintSet.applyTo(rootLayout)

        return rootLayout
    }
}