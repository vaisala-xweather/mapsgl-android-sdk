package com.xweather.mapsgl.controls.legend

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.GradientDrawable
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import androidx.compose.ui.graphics.toArgb
import androidx.core.view.children
import androidx.core.view.isGone
import androidx.core.view.isNotEmpty
import androidx.core.view.marginBottom
import androidx.core.view.marginLeft
import androidx.core.view.marginRight
import androidx.core.view.marginTop
import kotlin.math.max

/**
 * A custom view that hosts a vertical stack of legend views.
 */
class LegendContainerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    private val dividers = mutableMapOf<String, View>()
    private var legendTitleColor: Int = Color.WHITE
    private var radiusSize = 8 // Radius in DP

    init {
        orientation = VERTICAL

        // FIX: Use the custom method to set the background so it supports rounded corners from the start
        setBackgroundColor(androidx.compose.ui.graphics.Color.White)

        val vertPadding = (4 * resources.displayMetrics.density).toInt()
        val horizontalPadding = (6 * resources.displayMetrics.density).toInt()
        setPadding(horizontalPadding, vertPadding, horizontalPadding, vertPadding)
    }

    /**
     * FIX: Use GradientDrawable to support rounded corners.
     */
    fun setBackgroundColor(color: androidx.compose.ui.graphics.Color) {
        val backgroundDrawable = GradientDrawable()
        backgroundDrawable.setColor(color.toArgb())
        val cornerRadius = radiusSize * resources.displayMetrics.density
        backgroundDrawable.cornerRadius = cornerRadius
        this.background = backgroundDrawable
    }

    fun add(legendView: LegendView) {
        val legendId = legendView.legendId ?: return

        if (visibility == GONE) {
            visibility = VISIBLE
        }

        if (isNotEmpty()) {
            val separator = createSeparator() // Restore use of helper
            dividers[legendId] = separator
            addView(separator)
        }

        legendView.legend?.titleColorValue = androidx.compose.ui.graphics.Color(legendTitleColor)

        // Ensure the tag is set so updateLegend can find it
        legendView.tag = legendId
        addView(legendView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))
    }

    fun remove(legendView: LegendView) {
        val legendId = legendView.legendId ?: run {
            removeView(legendView)
            return
        }

        dividers[legendId]?.let { divider ->
            removeView(divider)
            dividers.remove(legendId)
        }

        removeView(legendView)

        if (childCount > 0 && getChildAt(0) is SeparatorView) {
            removeViewAt(0)
        }
    }

    /**
     * Restored helper method to create a separator with consistent layout params.
     */
    fun createSeparator(): View {
        val separator = SeparatorView(context)
        val separatorLayoutParams = LayoutParams(
            LayoutParams.MATCH_PARENT,
            (2 * resources.displayMetrics.density).toInt() // 2dp height for the view container
        )
        val verticalMargin = (4 * resources.displayMetrics.density).toInt()
        separatorLayoutParams.topMargin = verticalMargin
        separatorLayoutParams.bottomMargin = verticalMargin
        separator.layoutParams = separatorLayoutParams
        return separator
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val availableWidth = MeasureSpec.getSize(widthMeasureSpec)
        var totalHeight = paddingTop + paddingBottom
        var maxWidth = 0

        val containedWidthSpec = MeasureSpec.makeMeasureSpec(
            availableWidth - paddingLeft - paddingRight,
            MeasureSpec.getMode(widthMeasureSpec)
        )

        for (child in children) {
            if (child.isGone) continue
            measureChildWithMargins(child, containedWidthSpec, 0, heightMeasureSpec, totalHeight)
            totalHeight += child.measuredHeight + child.marginTop + child.marginBottom
            maxWidth = max(maxWidth, child.measuredWidth + child.marginLeft + child.marginRight)
        }

        maxWidth += paddingLeft + paddingRight
        setMeasuredDimension(maxWidth, totalHeight)

        // FIX: Compare totalHeight (Pixels) against the radius in Pixels
        val radiusPx = radiusSize * resources.displayMetrics.density
        if (totalHeight <= radiusPx * 2) {
            visibility = INVISIBLE
        } else {
            visibility = VISIBLE
        }
    }

    fun updateLegend(legend: Legend) {
        val legendViewToUpdate = findViewWithTag<LegendView>(legend.id)
        legendViewToUpdate?.setLegend(legend)
    }
}

private class SeparatorView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val paint = Paint().apply {
        color = Color.DKGRAY
        strokeWidth = (2 * resources.displayMetrics.density) // The line thickness
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val y = height / 2f
        canvas.drawLine(0f, y, width.toFloat(), y, paint)
    }
}