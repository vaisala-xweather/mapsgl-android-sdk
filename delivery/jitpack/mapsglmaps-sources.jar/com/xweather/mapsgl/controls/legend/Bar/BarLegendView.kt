package com.xweather.mapsgl.controls.legend.bar

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.text.TextPaint
import android.util.AttributeSet
import android.view.View
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.core.graphics.withSave
import com.xweather.mapsgl.extensions.Dimension
import com.xweather.mapsgl.extensions.Measurement
import com.xweather.mapsgl.extensions.UnitLength
import com.xweather.mapsgl.extensions.UnitTemperatureDelta
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MeasurementUnits
import com.xweather.mapsgl.style.ColorRampResult
import com.xweather.mapsgl.style.ColorScale
import com.xweather.mapsgl.style.colorStopsFromOptionsStops
import kotlin.math.roundToInt


/**
 * A custom Android View that draws a color bar legend.
 *
 * This is the direct Kotlin/Android View equivalent of the Swift `BarLegendView`.
 * It handles all drawing of the color ramp, ticks, and labels programmatically onto a Canvas.
 */
class BarLegendView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private lateinit var legend: BarLegend<*>
    private val collisionPadding = 8

    // Reusable Paint objects for drawing
    private val barPaint = Paint()
    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)
    private val textStrokePaint = TextPaint(Paint.ANTI_ALIAS_FLAG)

    // A helper class to manage label layout and avoid collisions
    private data class LabelItemLayout(
        var value: Double,
        var label: String,
        var position: Double // Normalized position (0.0 to 1.0)
    )

    init {
        // This view will be drawing its own content.
        setWillNotDraw(false)
        // Make the view's background transparent by default.
        setBackgroundColor(Color.TRANSPARENT)
    }

    fun setLegend(legend: BarLegend<*>) {
        //legend.currentUnits
        this.legend = legend

        // When the legend data changes, invalidate the view to trigger a remeasure and redraw.
        requestLayout() // To recalculate intrinsicContentSize
        invalidate()    // To trigger onDraw
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        // Perform calculations using Double for consistency
        val itemsHeight = legend.items.sumOf { dpToPx(it.height.value).toDouble() }
        val marginsHeight = dpToPx(((legend.items.size - 1).coerceAtLeast(0) * BarLegendDefaults.barMargins.value))

        // Convert the final result to Int for resolveSize
        val desiredHeight = (itemsHeight + marginsHeight).toInt()

        val height = resolveSize(desiredHeight, heightMeasureSpec)
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), height)
    }


    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        var currentY = 0f
        val marginPx = dpToPx(BarLegendDefaults.barMargins.value.toFloat())

        for (item in legend.items) {
            val scaledHeight = dpToPx(item.height.value)
            val barRect = RectF(0f, currentY, width.toFloat(), currentY + scaledHeight)

            drawBarItem(canvas, item, barRect)

            currentY += scaledHeight + marginPx
        }
    }

    private fun drawBarItem(canvas: Canvas, item: BarLegendItem<out Dimension>, rect: RectF) {
        val colorScaleOptions = item.colorScaleOptions
        val colorScale = item.colorScale
        val flatStops = colorStopsFromOptionsStops(colorScaleOptions.stops)

        //260126 colorScaleOptions.range was null and crashing in the filteredStops block.
        if (colorScaleOptions.range == null && flatStops.isNotEmpty()) {
            colorScaleOptions.range =
                flatStops.first().value..flatStops.last().value
        }

        // Never call [ColorScale.setStops] with value-only lists here: it replaces [_breaks] without
        // rebuilding the parallel [colors] list from [ColorStop]s, so knot colors slide onto wrong
        // segments (e.g. magenta mid-bar on precip legends).

        val ramp = colorScale.getRamp(
            range = colorScaleOptions.range,
            totalColors = width, //min(width, 500), // Limit samples to avoid performance issues
            interval = colorScaleOptions.interval,
            interpolate = colorScaleOptions.interpolate,
            normalized = colorScaleOptions.normalized,
            easing = legend.resample
        )

        drawBarBackground(canvas, item, ramp, rect)
        val labels = calculateLabelValues(item, colorScale, ramp)
        drawBarLabels(canvas, item, labels, rect)
    }

    private fun drawBarBackground(canvas: Canvas, item: BarLegendItem<*>, ramp: ColorRampResult, rect: RectF) {
        // 1. Setup a paint for the solid white background
        val backgroundPaint = Paint().apply {
            color = Color.WHITE
            style = Paint.Style.FILL
        }

        canvas.withSave {
            // 2. If the bar is rounded, we must clip the white background too
            if (item.rounded) {
                val cornerRadius = rect.height() / 2f
                val path = android.graphics.Path().apply {
                    addRoundRect(rect, cornerRadius, cornerRadius, android.graphics.Path.Direction.CW)
                }
                clipPath(path)
            }

            // 3. Draw the solid white background first
            canvas.drawRect(rect, backgroundPaint)

            // 4. Draw the color ramp (existing logic)
            val colors = ramp.stops.map { it.color.toArgb() }
            if (colors.isEmpty() || rect.width() <= 0) return

            // Float edges (no per-segment int rounding): integer left rounding left gaps under a
            // pill clip so the left cap looked square; contiguous rects fill the rounded clip evenly.
            val n = colors.size.coerceAtLeast(1)
            val segmentWidth = rect.width() / n
            for ((index, color) in colors.withIndex()) {
                barPaint.color = color
                val left = rect.left + segmentWidth * index
                val right = if (index == n - 1) rect.right else rect.left + segmentWidth * (index + 1)
                canvas.drawRect(left, rect.top, right, rect.bottom, barPaint)
            }
        }
    }

    private fun drawBarLabels(canvas: Canvas, item: BarLegendItem<*>, labels: List<LabelItemLayout>, rect: RectF) {
        val placement = item.labels.placement
        val labelFont = legend.labelFont
        textPaint.typeface = android.graphics.Typeface.create(labelFont, android.graphics.Typeface.BOLD)
        textPaint.textSize = legend.labelFontSize.value * resources.displayMetrics.density
        textPaint.color = legend.labelColor.toArgb()

        val paddingPx = 15.dp.value

        val lineHeight = textPaint.fontMetrics.descent - textPaint.fontMetrics.ascent
        val labelY = when (placement) {
            BarLegendLabels.Placement.TOP -> rect.top - textPaint.fontMetrics.ascent
            BarLegendLabels.Placement.MIDDLE -> rect.centerY() - (textPaint.fontMetrics.ascent + textPaint.fontMetrics.descent) / 2f
            BarLegendLabels.Placement.BOTTOM -> rect.bottom - textPaint.fontMetrics.descent
        }

        val drawnLabelBounds = mutableListOf<RectF>()
        for (label in labels.sortedBy { it.position }) {
            val textWidth = textPaint.measureText(label.label)
            val tempPosition = if (legend.resample != null) {
                /*legend.resample!!.invoke*/(label.position)
            } else {
                label.position
            }

            var posX = (tempPosition * rect.width() - (textWidth / 2f)).toFloat()

            //Apply padding to the clamping bounds
            val leftBound = rect.left + paddingPx
            val rightBound = rect.right - paddingPx

            posX = posX.coerceIn(leftBound, rightBound - textWidth)

            // Collision detection — use RectF.intersects, not intersect(): intersect() mutates
            // stored rects in drawnLabelBounds and breaks overlap checks for later labels.
            val labelRect =
                RectF(posX - collisionPadding, labelY - lineHeight, posX + textWidth + collisionPadding, labelY)
            val overlapsPrior = drawnLabelBounds.any { prior ->
                RectF.intersects(prior, labelRect)
            }
            if (overlapsPrior) {
                continue
            }

            drawText(canvas, item, label.label, posX, labelY)
            drawnLabelBounds.add(labelRect)
        }
    }

    private fun drawText(canvas: Canvas, item: BarLegendItem<*>, text: String, x: Float, y: Float) {
        // Setup for stroke and shadow
        textStrokePaint.set(textPaint) // Copy base properties
        textStrokePaint.typeface = textPaint.typeface
        textStrokePaint.style = Paint.Style.STROKE
        textStrokePaint.strokeWidth = dpToPx(item.labels.textStroke.width)
        textStrokePaint.strokeJoin = Paint.Join.ROUND
        textStrokePaint.color = item.labels.textStroke.color.toArgb()

        // Apply shadow
        val shadow = item.labels.textShadow
        textStrokePaint.setShadowLayer(
            shadow.blurRadius,
            shadow.offset.x,
            shadow.offset.y,
            shadow.color.toArgb()
        )

        // 1. Draw the stroked/shadowed text
        canvas.drawText(text, x, y, textStrokePaint)

        // 2. Draw the filled text on top
        canvas.drawText(text, x, y, textPaint)
    }

    private fun calculateLabelValues(
        item: BarLegendItem<out Dimension>,
        colorScale: ColorScale,
        ramp: ColorRampResult,
    ): List<LabelItemLayout> {

        val labelValues = item.labels.values
        val unit = item.labels.currentUnits ?: return listOf()
        val currentUnits = legend.currentUnits ?: unit
        val mode: Int
        var min = 0.0
        var max = 0.0
        
        // Case 1: Use explicit labels and positions if specified.
        if (labelValues is BarLegendLabels.Values.FromLabels<*>) {
            if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() case 1")
            val labels = labelValues.accessor(legend.currentUnits)

            if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() labels: $labels")
            return labels.map { (value, label) ->
                val baseValue = if (item.labels.normalized) {
                    ramp.valueForPosition(value)
                } else {
                    value
                }

                LabelItemLayout(value, label, value)
            }
        }

        val baseValues = mutableListOf<Double>()

        // Determine the base values from which to generate labels
        when (labelValues) {
            // Case 2: Use explicitly provided values.
            is BarLegendLabels.Values.FromValues<*> -> {
                mode = 2
                if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() case 2")
                // Execute the accessor function to get the list of values
                var explicitValues = labelValues.accessor(legend.currentUnits)

                if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() explicit val: $explicitValues")

                if (item.labels.normalized) {
                    if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "     case 2 NORMALIZED")
                    explicitValues = explicitValues.map { ramp.valueForPosition(it) }.toMutableList()
                } else {
                    if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "     case 2 NOT NORMALIZED")
                }
                baseValues.addAll(explicitValues)
            }

            // Case 3: Generate labels at a specified interval.
            is BarLegendLabels.Values.Every -> {
                mode = 3
                val range = colorScale.range
                val minMeasurement = Measurement(range.start, unit).converted(currentUnits)
                val maxMeasurement = Measurement(range.endInclusive, unit).converted(currentUnits)
                min = minMeasurement.value
                max = maxMeasurement.value

                if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() case 3")

                if (pr.ON) pr.p(
                    "BarLegendView",
                    pr.colorBarNum,
                    "calculateLabelValues() colorScale.range: ${colorScale.range}"
                )

                if (pr.ON) pr.p(
                    "BarLegendView",
                    pr.colorBarNum,
                    "calculateLabelValues() unit: $unit, cUnits: $currentUnits "
                )
                if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() min: $min, max: $max ")
                if (pr.ON) pr.p(
                    "BarLegendView",
                    pr.colorBarNum,
                    "calculateLabelValues() colorScale.range.endInclusive: ${colorScale.range.endInclusive} "
                )

                val increment = labelValues.accessor(currentUnits)
                if (increment <= 0) return emptyList()

                val generatedValues = mutableSetOf<Double>()

                if (range.contains(0.0)) {
                    generatedValues.add(0.0)
                }

                // Generate positive values starting from 0 upwards
                var upwardValue = increment
                if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() uWVal:$upwardValue   max:$max")
                while (upwardValue <= max) {
                    generatedValues.add(upwardValue)
                    upwardValue += increment
                }
                if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() 150")
                // Generate negative values starting from 0 downwards
                var downwardValue = -increment
                while (downwardValue >= min) {
                    generatedValues.add(downwardValue)
                    downwardValue -= increment
                }
                if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() 200")
                val filteredBaseValues = generatedValues.filter { it in min..max }
                baseValues.addAll(filteredBaseValues.sorted())
            }

            // Case 4: If not interpolated, use the scale stops directly.
            else -> {
                mode = 4
                if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() case 4")
                if (!item.colorScaleOptions.interpolate) {
                    val stopValues = colorStopsFromOptionsStops(item.colorScaleOptions.stops).map { it.value }
                    baseValues.addAll(stopValues)
                }
                // Optional: If interpolated but no other rule, you could default to ramp stops
                // else {
                //     baseValues.addAll(ramp.stops.map { it.value })
                // }
            }
        }

        val labelItemLayoutList = baseValues.mapIndexed { index, baseValue ->
            val roundedValue = baseValue.roundToInt()

            //val label: String = if (index == 0) "$roundedValue${currentUnits.symbol ?: ""}" else "$roundedValue"
            val isDelta = currentUnits is UnitTemperatureDelta
            val sign = if (isDelta && roundedValue > 0) "+" else ""

            // Format the label with the optional sign and symbol
            val label: String = if (index == 0) {
                "$sign$roundedValue${currentUnits.symbol ?: ""}"
            } else {
                "$sign$roundedValue"
            }

            var tempValue = baseValue

            if (item.labels.currentUnits == MeasurementUnits.METRIC.snowfall) {
                if (currentUnits is UnitLength.Inches) {
                    tempValue *= .02
                } else {
                    tempValue *= .01
                }
            }
            val position: Double = if (mode == 3) {
                lerpPosition(tempValue, min, max)
            } else {
                lerpPosition(tempValue, ramp)
            }

            LabelItemLayout(
                value = baseValue,
                label = label,
                position
            )
        }

        if (pr.ON) pr.p("BarLegendView", pr.colorBarNum, "calculateLabelValues() returning ${labelItemLayoutList} ")
        return labelItemLayoutList.toList()

    }

    private fun lerpPosition(forValue: Double, ramp: ColorRampResult): Double {
        val stops = ramp.stops
        if (stops.isEmpty()) return 0.0

        // Find the segment where the value falls
        val index = stops.indexOfFirst { it.value >= forValue }.let {
            if (it == -1) stops.size - 2 else it - 1
        }.coerceAtLeast(0)

        val start = stops[index]
        val end = stops.getOrElse(index + 1) { start }

        val range = end.value - start.value
        if (range == 0.0) {
            return start.position
        }

        // Calculate the interpolation factor (t) within the segment
        val t = ((forValue - start.value) / range).coerceIn(0.0, 1.0)

        // Interpolate the position
        return start.position + t * (end.position - start.position)
    }

    /**
     * Calculates the normalized position (0.0 to 1.0) of a value within a simple min/max range.
     *
     * @param forValue The value to find the position for.
     * @param min The minimum value of the range (corresponds to position 0.0).
     * @param max The maximum value of the range (corresponds to position 1.0).
     * @return A Double between 0.0 and 1.0 representing the normalized position.
     */
    private fun lerpPosition(forValue: Double, min: Double, max: Double): Double {
        val range = max - min

        // Avoid division by zero if min and max are the same.
        if (range == 0.0) {
            return if (forValue >= max) 1.0 else 0.0
        }

        // Calculate the normalized position 't'
        val t = (forValue - min) / range

        // Coerce the result to be within the [0.0, 1.0] bounds to handle out-of-range values gracefully.
        return t.coerceIn(0.0, 1.0)
    }

    private fun dpToPx(dp: Float): Float {
        return dp * resources.displayMetrics.density
    }
}
