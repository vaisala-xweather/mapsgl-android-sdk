package com.xweather.mapsgl.controls.legend.bar

import com.xweather.mapsgl.extensions.Dimension

/**
 * Collapses a bar legend's bars into one when every bar would draw the same thing.
 *
 * The radar legend draws one bar per precipitation type - rain, mix, snow - each coloured from its
 * own band of the layer's paint. A custom scale that gives every band the same stops, range and
 * interval turns that into three identical bars stacked on top of each other, which reads as three
 * different things when it is one. In that case the legend shows a single bar.
 *
 * The bar keeps only the labels every bar shares: the radar bars read "Light / RAIN / Heavy",
 * "Light / MIX / Heavy" and "Light / SNOW / Heavy", so the single bar reads "Light / Heavy". The
 * legend's own title is untouched.
 *
 * Bars that differ in any way, or a legend with fewer than two bars, come back unchanged. The caller
 * rebuilds from the legend's template on every sync, so a scale that stops being uniform gets all its
 * bars back.
 */
internal fun <U : Dimension> collapseIdenticalBars(items: List<BarLegendItem<U>>): List<BarLegendItem<U>> {
    if (items.size < 2) return items
    val first = items.first()
    val allSame = items.all {
        it.colorScaleOptions == first.colorScaleOptions &&
            it.height == first.height &&
            it.rounded == first.rounded &&
            it.margins == first.margins
    }
    if (!allSame) return items
    return listOf(first.copy(labels = sharedLabels(items)))
}

/**
 * [BarLegendItem.labels] for the collapsed bar: the first bar's, with a [BarLegendLabels.Values.FromLabels]
 * list narrowed to the entries - same position, same text - that appear on every bar. Any other kind
 * of values is kept as the first bar had it.
 */
private fun <U : Dimension> sharedLabels(items: List<BarLegendItem<U>>): BarLegendLabels<U> {
    val first = items.first().labels
    val accessors = items.map { (it.labels.values as? BarLegendLabels.Values.FromLabels<U>)?.accessor }
    if (accessors.any { it == null }) return first
    val shared = BarLegendLabels.Values.FromLabels<U> { units ->
        val lists = accessors.map { it!!(units) }
        lists.first().filter { entry -> lists.all { entry in it } }
    }
    return first.copy(values = shared)
}
