package com.xweather.mapsgl.controls.legend.Point

import android.graphics.Color
import androidx.core.graphics.toColorInt
import com.mapbox.maps.QueriedFeature
import com.xweather.mapsgl.gl.extensions.pr
import java.util.Locale

/**
 * Resolves queried map features into legend items for a PointLegend.
 */
interface PointLegendFeatureResolver {

    /**
     * Produces legend items representing the provided feature collection.
     *
     * @param features Features currently visible for the associated layer.
     * @return A list of legend items that should be displayed on the associated PointLegend.
     */
    fun resolve(features: List<QueriedFeature>): List<PointLegendItem>
    fun resolveGL(features: List<com.xweather.mapsgl.layers.QueriedFeature>): List<PointLegendItem>
}

/**
 * A concrete implementation of [PointLegendFeatureResolver] specifically for weather alerts.
 *
 * It extracts advisory names and colors from feature properties, creating a unique,
 * sorted list of legend items.
 */
class AlertsLegendItemResolver : PointLegendFeatureResolver {

    override fun resolve(features: List<QueriedFeature>): List<PointLegendItem> {
        val pointItems = mutableListOf<PointLegendItem>()
        val advisoriesSeen = mutableSetOf<String>()

        if (pr.ON) pr.p("PointLegendFeatureResolver", pr.pLegendR, "resolve() entered")

        features.forEach { feature ->

            if (pr.ON) pr.p("PointLegendFeatureResolver", pr.pLegendR, "resolve() feature $feature")

            val properties = feature.feature.properties() ?: return@forEach
            val name = properties.get("ADVISORY")?.asString
            val colorString = properties.get("COLOR")?.asString

            if (name != null && colorString != null && !advisoriesSeen.contains(name)) {
                // Ensure the hex string starts with '#' and parse it to an Android color Int
                val colorHex = if (colorString.startsWith("#")) colorString else "#$colorString"
                val colorInt = try {
                    colorHex.toColorInt()
                } catch (e: IllegalArgumentException) {
                    return@forEach // If color parsing fails, skip this item
                }

                // Create the legend item with the parsed color and formatted label
                pointItems.add(
                    PointLegendItem(
                        color = colorInt,
                        label = name.lowercase(Locale.getDefault()).replaceFirstChar {
                            if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
                        }
                    )
                )
                advisoriesSeen.add(name)
            }
        }
        // Return the list of items sorted alphabetically by label
        return pointItems.sortedBy { it.label }
    }

    override fun resolveGL(features: List<com.xweather.mapsgl.layers.QueriedFeature>): List<PointLegendItem> {
        val pointItems = mutableListOf<PointLegendItem>()
        val advisoriesSeen = mutableSetOf<String>()


        features.forEach { feature ->

            if (pr.ON) pr.p("PointLegendFeatureResolver", pr.pLegendR, "resolve() feature $feature")

            val properties = feature.properties
            val name = properties["ADVISORY"].toString()
            val colorString = properties["COLOR"].toString()

            if (name != null && colorString != null && !advisoriesSeen.contains(name)) {
                // Ensure the hex string starts with '#' and parse it to an Android color Int
                val colorHex = if (colorString.startsWith("#")) colorString else "#$colorString"
                val colorInt = try {
                    colorHex.toColorInt()
                } catch (e: IllegalArgumentException) {
                    return@forEach // If color parsing fails, skip this item
                }

                // Create the legend item with the parsed color and formatted label
                pointItems.add(
                    PointLegendItem(
                        color = colorInt,
                        label = name.lowercase(Locale.getDefault())
                            .split(" ")
                            .joinToString(" ") { word ->
                                word.replaceFirstChar {
                                    if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
                                }
                            }
                    )
                )
                if (pr.ON) pr.p(
                    "PointLegendFeatureResolver", pr.pLegendR,
                    "resolve() added ${
                        name.lowercase(Locale.getDefault()).replaceFirstChar {
                            if (it.isLowerCase()) it.titlecase(Locale.getDefault()) else it.toString()
                        }
                    }, color: $colorInt"
                )
                advisoriesSeen.add(name)
            }
        }

        if (pointItems.size == 0) {
            pointItems.add(
                PointLegendItem(
                    color = Color.TRANSPARENT,
                    label = "",
                    emptyItem = true
                )
            )
        }

        return pointItems.sortedBy { it.label }

    }

}

