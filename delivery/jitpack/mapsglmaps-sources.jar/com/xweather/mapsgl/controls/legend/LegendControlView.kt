package com.xweather.mapsgl.controls.legend

import android.content.Context
import android.util.AttributeSet
import android.widget.FrameLayout

/**
 * The main view that contains and manages the legend UI components.
 *
 * This is the Android equivalent of the Swift `LegendControlView` and its internal
 * `UIViewRepresentable`. It acts as a bridge between a data source (a "Host")
 * and the actual UI container for legends (`LegendContainerView`).
 *
 * It is a `FrameLayout` so it can cleanly host the `LegendContainerView` and manage
 * its lifecycle.
 */
class LegendControlView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    // Internal container that holds the stack of individual legend views.
    private var legendContainerView: LegendContainerView? = null

    // The coordinator manages the logic of adding/removing legends from the UI.
    private var coordinator: LegendControl.Coordinator? = null

    /**
     * Sets up the view by providing a `Host`. The Host is an interface that the
     * map controller or another data provider implements to supply legend data.
     *
     * @param mapControllerProvider A lambda function that returns an instance of `LegendControl.Host`.
     *                                This is the source from which the control will get its data.
     */
    fun setup(mapControllerProvider: () -> LegendControl.Host?) {
        // If a coordinator already exists, tear it down to avoid multiple listeners.
        coordinator?.teardown()
        coordinator = LegendControl.Coordinator(mapControllerProvider).also {
            tryInstall(it)
        }
    }

    /**
     * Tries to install the legend UI if the coordinator can successfully connect to a host.
     */
    private fun tryInstall(coordinator: LegendControl.Coordinator) {

        // `tryInstall` returns a `LegendControl` instance if successful.
        val legendControl = coordinator.tryInstall()
        if (legendControl != null) {
            // A new container was created, so add it to this view.
            legendControl.containerView?.let { setLegendContainerView(it) }
        } else {
            // Failed to install, likely because the host was null.
            removeLegendContainerView()
        }
    }

    /**
     * Adds the `LegendContainerView` to this `FrameLayout`.
     */
    private fun setLegendContainerView(newContainer: LegendContainerView) {
        if (newContainer === this.legendContainerView) {
            return // It's already the current view.
        }

        removeLegendContainerView() // Remove the old one first.

        this.legendContainerView = newContainer
        // Add the view to this FrameLayout with default MATCH_PARENT parameters.
        addView(newContainer, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    /**
     * Removes the `LegendContainerView` from this `FrameLayout`.
     */
    private fun removeLegendContainerView() {
        legendContainerView?.let {
            removeView(it)
        }
        legendContainerView = null
    }

    /**
     * Cleans up resources when the view is detached from the window.
     * This is the Android equivalent of `dismantleUIView`.
     */
    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        removeLegendContainerView()
        coordinator?.teardown()
        coordinator = null
    }
}
