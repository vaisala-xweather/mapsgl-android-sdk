package com.xweather.mapsgl.extensions

import kotlin.math.pow

// --- Base Measurement Infrastructure (recreating parts of Swift's Foundation) ---

/**
 * A `UnitConverter` provides the mechanism to convert between different units of the same dimension.
 */
abstract class UnitConverter {
    abstract fun baseUnitValue(fromValue: Double): Double
    abstract fun value(fromBaseUnitValue: Double): Double
}

/**
 * A linear converter that applies a coefficient (and optionally a constant) for conversion.
 * Formula: y = m * x + b
 */
class UnitConverterLinear(val coefficient: Double, val constant: Double = 0.0) : UnitConverter() {
    override fun baseUnitValue(fromValue: Double): Double {
        return fromValue * coefficient + constant
    }

    override fun value(fromBaseUnitValue: Double): Double {
        return (fromBaseUnitValue - constant) / coefficient
    }
}

/**
 * A `Dimension` is a base class for a specific type of unit, like length or temperature.
 */
abstract class Dimension(open val symbol: String, open val converter: UnitConverter) {
    // This would be abstract in a more complete implementation, but static companion objects make it tricky.
    // Each subclass will define its own `baseUnit`.
}

/**
 * A `Measurement` holds a value in a specific unit.
 *
 * @param UnitType The type of unit (e.g., UnitTemperature, UnitSpeed).
 * @param value The numerical value of the measurement.
 * @param unit The unit of the measurement.
 */
// Add the 'out' keyword before UnitType
data class Measurement<out UnitType : Dimension>(val value: Double, val unit: UnitType) :
    Comparable<Measurement<@UnsafeVariance UnitType>> {

    companion object;

    /**
     * Converts this measurement to a different unit of the same dimension.
     * The `to` parameter is marked with `@UnsafeVariance` because it's in an "in" position,
     * but we know our usage is safe as we only read from it for conversion.
     */
    fun converted(to: @UnsafeVariance UnitType): Measurement<UnitType> {

        // if (unit == to) {
        //val baseValue = unit.converter.baseUnitValue(fromValue = this.value)
        //convertedValue = to.converter.value(fromBaseUnitValue = baseValue)

        val convertedValue: Double = to.converter.value(fromBaseUnitValue = this.value)

        //  } else {
        //     val baseValue = unit.converter.baseUnitValue(fromValue = this.value)
        //     convertedValue = to.converter.value(fromBaseUnitValue = baseValue) / unit.converter.baseUnitValue(1.0)
        //  }

        //val convertedValue = unit.converter.baseUnitValue(this.value)

        return Measurement(convertedValue, to)
    }

    /**
     * Compares this measurement to another measurement, enabling sorting and range operations.
     * The `other` parameter uses `in` variance. This allows a Measurement<Celsius> to be
     * compared with a Measurement<Temperature>, which is required for the `Comparable` contract.
     */
    override fun compareTo(other: Measurement<@UnsafeVariance UnitType>): Int { // REMOVED 'override'
        // We must cast `other` to a type `converted` can understand.
        // The cast is safe due to the logic of the Comparable interface.
        @Suppress("UNCHECKED_CAST") val otherMeasurement = other as Measurement<UnitType>

        // Convert the other measurement to the same unit as `this`.
        val convertedOther = otherMeasurement.converted(to = this.unit)

        // The compiler is still confused by the type of 'convertedOther'.
        // We use .let to scope the comparison and clarify our intent.
        return convertedOther.let { this.value.compareTo(it.value) }
    }
}

// --- Generic ClosedRange<Measurement<...>> Extensions ---

/**
 * Returns a `ClosedRange<Double>` with just the numeric values from a range of Measurements.
 */
fun <UnitType : Dimension> ClosedRange<Measurement<UnitType>>.values(): ClosedRange<Double> {
    return this.start.value..this.endInclusive.value
}

/**
 * Returns numeric bounds converted to the specified unit first.
 */
fun <UnitType : Dimension> ClosedRange<Measurement<UnitType>>.values(convertedTo: UnitType): ClosedRange<Double> {
    val low = this.start.converted(to = convertedTo).value
    val high = this.endInclusive.converted(to = convertedTo).value
    return low..high
}

/**
 * Creates a new `ClosedRange<Measurement<UnitType>>` from a numeric range using the same unit type as this range.
 */
fun <UnitType : Dimension> ClosedRange<Measurement<UnitType>>.replacingValues(values: ClosedRange<Double>): ClosedRange<Measurement<UnitType>> {
    val unit = this.start.unit
    val lower = Measurement(value = values.start, unit = unit)
    val upper = Measurement(value = values.endInclusive, unit = unit)
    return lower..upper
}

// --- UnitTemperature ---

sealed class UnitTemperature(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val celsius = Celsius()
        val fahrenheit = Fahrenheit()
        val none = None()
        //val kelvin = Kelvin()
        //fun baseUnit() = celsius
    }

    class Celsius : UnitTemperature("°C", UnitConverterLinear(1.0, 0.0))
    class Fahrenheit : UnitTemperature("°F", UnitConverterLinear(0.5555555555555556, -17.77777777777778))
    class Kelvin : UnitTemperature("K", UnitConverterLinear(1.0, -273.15))
    class None : UnitTemperature("", UnitConverterLinear(1.0, 0.0))
}


sealed class UnitTemperatureDelta(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val celsius = Celsius()
        val fahrenheit = Fahrenheit()
    }

    class Celsius : UnitTemperatureDelta("°C", UnitConverterLinear(1.0, 0.0))

    //class Fahrenheit : UnitTemperatureDelta("°F", UnitConverterLinear(0.5555555555555556, -17.77777777777778))
    class Fahrenheit : UnitTemperatureDelta("°F", UnitConverterLinear(0.5555555555555556, 0.0))
}

/**
 * Creates a ClosedRange of Temperature Measurements in Celsius from a Double range.
 */
fun celsiusRange(range: ClosedRange<Double>): ClosedRange<Measurement<UnitTemperature.Celsius>> {
    return Measurement.celsius(range.start)..Measurement.celsius(range.endInclusive)
}

/**
 * Creates a ClosedRange of Temperature Measurements in Fahrenheit from a Double range.
 */
fun fahrenheitRange(range: ClosedRange<Double>): ClosedRange<Measurement<UnitTemperature.Fahrenheit>> {
    return Measurement.fahrenheit(range.start)..Measurement.fahrenheit(range.endInclusive)
}

// --- UnitConcentrationMass ---

sealed class UnitConcentrationMass(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val microgramsPerCubicMeter = MicrogramsPerCubicMeter()
        val none = None()

        // Defining the base unit (usually kg/m³ for mass concentration)
        fun baseUnit() = microgramsPerCubicMeter

    }

    //class MicrogramsPerCubicMeter : UnitConcentrationMass("µg/m³", UnitConverterLinear(1e-9))
    class MicrogramsPerCubicMeter : UnitConcentrationMass(" µg/m³", UnitConverterLinear(1.0))
    class None : UnitConcentrationMass("", UnitConverterLinear(1.0))
}

// Extension to Measurement Companion for easy instantiation
fun Measurement.Companion.microgramsPerCubicMeter(value: Double) =
    Measurement(value, UnitConcentrationMass.microgramsPerCubicMeter)

sealed class UnitHeightDifference(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val feet = Feet()
        val meters = Meters()
        val none = None()
    }

    class Meters : UnitHeightDifference(" m", UnitConverterLinear(1.0))
    class Feet : UnitHeightDifference(" ft", UnitConverterLinear(.3))
    class None : UnitHeightDifference("", UnitConverterLinear(1.0))
}

sealed class UnitHeight(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val feet = Feet()
        val meters = Meters()
        val none = None()
    }

    class Meters : UnitHeight(" m", UnitConverterLinear(1.0))
    class Feet : UnitHeight(" ft", UnitConverterLinear(.3048))
    class None : UnitHeight("", UnitConverterLinear(1.0))
}

sealed class UnitSpeed(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        private const val INCHES_TO_METERS_COEFFICIENT = 0.0254

        val metersPerSecond = MetersPerSecond()
        val milesPerHour = MilesPerHour()
        val knots = Knots()
        val millimetersPerSecond = MillimetersPerSecond()
        val millimetersPerHour = MillimetersPerHour()
        val kilometersPerHour = KilometersPerHour()
        val inchesPerSecond = InchesPerSecond()
        val inchesPerHour = InchesPerHour()
        val none = None()
        fun baseUnit() = kilometersPerHour
    }

    class MetersPerSecond : UnitSpeed("m/s", UnitConverterLinear(1.0))
    class MilesPerHour : UnitSpeed(" mph", UnitConverterLinear(0.44704))
    class Knots : UnitSpeed("kn", UnitConverterLinear(0.514444))
    class MillimetersPerSecond : UnitSpeed("mm/s", UnitConverterLinear(0.001))
    class MillimetersPerHour : UnitSpeed("mm/h", UnitConverterLinear(0.001 / 3600.0))
    class None : UnitSpeed("", UnitConverterLinear(1.0))

    //class KilometersPerHour : UnitSpeed("km/h", UnitConverterLinear(0.000001 / 3600.0))
    class KilometersPerHour : UnitSpeed(" km/h", UnitConverterLinear(.277778))
    class InchesPerSecond : UnitSpeed("in/s", UnitConverterLinear(INCHES_TO_METERS_COEFFICIENT))
    class InchesPerHour : UnitSpeed("in/h", UnitConverterLinear(INCHES_TO_METERS_COEFFICIENT / 3600.0))
}

fun Measurement.Companion.knots(value: Double) = Measurement(value, UnitSpeed.knots)
fun Measurement.Companion.milesPerHour(value: Double) = Measurement(value, UnitSpeed.milesPerHour)
fun Measurement.Companion.metersPerSecond(value: Double) = Measurement(value, UnitSpeed.metersPerSecond)
fun Measurement.Companion.celsius(value: Double) = Measurement(value, UnitTemperature.celsius)
fun Measurement.Companion.fahrenheit(value: Double) = Measurement(value, UnitTemperature.fahrenheit)
fun Measurement.Companion.centimeters(value: Double) = Measurement(value, UnitLength.centimeters)
fun Measurement.Companion.inches(value: Double) = Measurement(value, UnitLength.inches)

/**
 * Marshall-Palmer formula for conversion of dBZ to rainfall rate in mm/h.
 */
fun Measurement.Companion.fromDBZ(dbzValue: Double): Measurement<UnitSpeed> {
    val value = (10.0.pow(dbzValue / 10.0) / 200.0).pow(0.625)
    return Measurement(value, UnitSpeed.millimetersPerHour)
}

sealed class UnitLength(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        private const val INCHES_TO_METERS_COEFFICIENT = 0.0254

        val metersPerSecond = MetersPerSecond()
        val centimeters = Centimeters()
        val millimeters = Millimeters()
        val kilometers = Kilometers()
        val miles = Miles()
        val inches = Inches()
        val meters = Meters()
        val feet = Feet()
        val none = None()

        fun baseUnit() = metersPerSecond
    }

    class None : UnitLength("", UnitConverterLinear(1.0))
    class Centimeters : UnitLength(" cm", UnitConverterLinear(.01))
    class Millimeters : UnitLength(" mm", UnitConverterLinear(.001))
    class Inches : UnitLength(" in", UnitConverterLinear(.0254))
    class MetersPerSecond : UnitSpeed("m/s", UnitConverterLinear(1.0))
    class Kilometers : UnitLength(" km", UnitConverterLinear(1000.0))
    class Miles : UnitLength(" mi", UnitConverterLinear(1609.34))
    class Feet : UnitLength(" ft", UnitConverterLinear(0.3048))
    class Meters : UnitLength(" m", UnitConverterLinear(1.0))

}


sealed class UnitPressure(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        private const val INCHES_TO_METERS_COEFFICIENT = 0.0254

        val millibars = Millibars()
        val inchesOfMercury = InchesOfMercury()
        fun baseUnit() = millibars
    }

    class None : UnitLength("", UnitConverterLinear(1.0))
    class Millibars : UnitPressure("mb", UnitConverterLinear(20.0))
    class InchesOfMercury : UnitPressure("inHg", UnitConverterLinear(1.0))

}


// --- UnitRadarReflectivity ---

sealed class UnitRadarReflectivity(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val decibelRelativeToZ = DecibelRelativeToZ()
        val dbz = decibelRelativeToZ // Alias
        val none = None()
        fun baseUnit() = decibelRelativeToZ

    }

    class DecibelRelativeToZ : UnitRadarReflectivity("dBZ", UnitConverterLinear(1.0))
    class None : UnitRadarReflectivity("", UnitConverterLinear(1.0))
}

fun Measurement.Companion.dbz(value: Double) = Measurement(value, UnitRadarReflectivity.dbz)

fun Measurement<UnitRadarReflectivity>.toUnitSpeed(targetUnit: UnitSpeed): Measurement<UnitSpeed> {
    val dbzValue = this.converted(to = UnitRadarReflectivity.dbz).value
    return Measurement.fromDBZ(dbzValue).converted(to = targetUnit)
}

// --- Double conversion helper ---

/**
 * Converts a Double from one unit to another of the same dimension.
 */
fun <T : Dimension> Double.convert(from: T, to: T): Double {
    return Measurement(this, from).converted(to).value
}

// --- UnitProportion ---

sealed class UnitProportion(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val decimalProportion = DecimalProportion()
        val percent = Percent()
        val permille = Permille()
        val permyriad = Permyriad()
        val percentmille = Percentmille()
        val none = None()

        fun baseUnit() = decimalProportion
    }

    class DecimalProportion : UnitProportion("", UnitConverterLinear(1.0))
    class Percent : UnitProportion("%", UnitConverterLinear(1.00))
    class Permille : UnitProportion("‰", UnitConverterLinear(0.001))
    class Permyriad : UnitProportion("‱", UnitConverterLinear(0.0001))
    class Percentmille : UnitProportion("pcm", UnitConverterLinear(0.00001))
    class None : UnitProportion("", UnitConverterLinear(1.0))
}


sealed class UnitNone(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val none = None()
    }

    class None : UnitProportion("", UnitConverterLinear(1.0))
}

sealed class UnitDuration(symbol: String, converter: UnitConverter) : Dimension(symbol, converter) {
    companion object {
        val decimalProportion = DecimalProportion()
        val minute = Minute()
        val none = None()

        fun baseUnit() = decimalProportion
    }

    class DecimalProportion : UnitProportion("", UnitConverterLinear(1.0))
    class Minute : UnitDuration(" min", UnitConverterLinear(1.0))
    class None : UnitDuration("", UnitConverterLinear(1.0))
}

fun Measurement.Companion.decimalProportion(value: Double) = Measurement(value, UnitProportion.decimalProportion)
fun Measurement.Companion.percent(value: Double) = Measurement(value, UnitProportion.percent)

/**
 * Creates a ClosedRange of Proportion Measurements from a Double range representing a decimal proportion (e.g., 0.0 to 1.0).
 */
fun decimalProportionRange(range: ClosedRange<Double>): ClosedRange<Measurement<UnitProportion.DecimalProportion>> {
    return Measurement.decimalProportion(range.start)..Measurement.decimalProportion(range.endInclusive)
}

/**
 * Creates a ClosedRange of Proportion Measurements from a Double range representing percentages (e.g., 0.0 to 100.0).
 */
fun percentRange(range: ClosedRange<Double>): ClosedRange<Measurement<UnitProportion.Percent>> {
    return Measurement.percent(range.start)..Measurement.percent(range.endInclusive)
}

