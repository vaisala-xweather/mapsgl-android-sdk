package com.xweather.mapsgl.sources

import android.graphics.Bitmap
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.util.Date
import kotlin.coroutines.cancellation.CancellationException

/**
 * ImageTileSource.kt
 *
 *   Adapted from IOS version
 *   @author by Jason Suto on 11/30/23.
 */

class ImageTileSource(
    override val id: String,
    private val typeString: String,
    val authenticator: XweatherAuthenticator?
) : TileSource<TileData>() {

    class MetadataSchema : SourceMetadataSchema() {
        init {
            maxZoom = 21.0f
            startDate = Date(System.currentTimeMillis() - (60 * 60 * 1000 * 24 * 3))
            endDate = Date(System.currentTimeMillis() + (60 * 60 * 1000 * 24 * 1))
        }
    }

    companion object {
        //TODO: Does having api event in companion object interfere when there a re multiple image tile sources?
        val _apiEvent = MutableLiveData<RasterTileApiEvent>(RasterTileApiEvent.Success(null))
        val apiEvent: LiveData<RasterTileApiEvent> = _apiEvent
        private var key: String = ""
        private val mapPrefixURL = "$mapsGLServer/tile"

        fun setKey(id: String?, secret: String?) {
            key = "${id}_${secret}"
        }

        /** Padding either side of the timeline range when picking frames from metadata. */
        private const val RANGE_PAD_MS = 60L * 60L * 1000L

        /** How long a failed metadata fetch is left before the next attempt. */
        private const val METADATA_RETRY_MS = 30_000L
    }

    override var timeRange: ClosedRange<Date>? = null
    private var isStale = false
    private val TAG = "ImageTileSource"
    override val kind: DataSourceKind = DataSourceKind.RASTER
    override fun addConsumer(consumer: DataSourceConsumer) {}
    override fun removeConsumer(layerId: String) {}
    override var tileManager: TileRequestManager<TileData> = TileRequestManager(this)
    override var tileCache: TileCache<DataType> = TileCache()

    init {
        maxZoom = 7.0f
    }

    override fun appendTileUrlVariables(coord: TileCoord, vars: MutableMap<String, Any>) {
        authenticator?.appendTileCredentialVariables(vars)
    }

    /** Serialises [fetchMetadata]: range changes and the tile pyramid can ask at the same moment. */
    private val metadataMutex = Mutex()

    /** When the last metadata fetch failed, so a dead endpoint is not re-hit on every tile pass. */
    private var metadataFailedAtMs = 0L

    /**
     * Loads this raster product's frame times and registers them as the source's valid times.
     *
     * Until this existed an image raster had no valid times at all, so the tile pyramid fell back to
     * a single frame from twelve hours ago (see `TilePyramid.ensureStaticRasterLayerTimeline`) and
     * held it for the whole animation: satellite never moved with the timeline, in any app.
     *
     * The Raster Maps metadata endpoint (`/{accessKey}/{code}.json`) lists every available frame as
     * `files[].timestamp`, in seconds. Frames inside the timeline range (padded an hour either side,
     * so the first and last slots have a frame to snap to) become the source's `timeDates`; the
     * timeline maps its own slots onto them per layer, as it does for encoded sources, which keeps
     * the frame count bounded however frequent the product's frames are.
     *
     * A failed fetch is not an error for the layer: it keeps the single-frame fallback, and the next
     * attempt waits `METADATA_RETRY_MS`.
     */
    override suspend fun fetchMetadata(startDate: Date?, endDate: Date?): Result<Unit> {
        val url = metadataURL ?: return Result.success(Unit)
        return metadataMutex.withLock {
            if (metaDataNeeded < 1) return@withLock Result.success(Unit)
            if (System.currentTimeMillis() - metadataFailedAtMs < METADATA_RETRY_MS) {
                return@withLock Result.success(Unit)
            }

            val times = try {
                val response = URLRequest(url).apply { method = "GET" }.execute()
                val json = response.data as? JSONObject
                    ?: throw IllegalStateException("metadata was not JSON (HTTP ${response.statusCode})")
                frameDates(frameTimestamps(json), startDate, endDate)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                metadataFailedAtMs = System.currentTimeMillis()
                MapsGLDebug.logW(TAG, "Raster metadata for $id failed; keeping a single frame: ${e.message}")
                return@withLock Result.success(Unit)
            }

            if (times.isEmpty()) {
                // Nothing in range: leave the single-frame fallback in place rather than an empty
                // timeline, which would draw nothing at all.
                metaDataNeeded = 0
                return@withLock Result.success(Unit)
            }

            // LayerTimeline is read on the main thread by the animation target; mutating it from IO
            // is how the encoded path once crashed (see SourceMetadata.load).
            withContext(Dispatchers.Main) {
                val layerTimeline = Timeline.sourceTimeHash.getOrPut(id) { LayerTimeline(id) }
                layerTimeline.timeDates = times.toMutableList()
                Timeline.datesToStringsAndLongs(id)
            }
            metaDataNeeded = 0
            Result.success(Unit)
        }
    }

    /**
     * `["2026-09-29T13:09:52Z"]` to `20260929130952`, the Raster Maps `{time}` path segment.
     *
     * [intervalToURLTime] drops the minutes and seconds, which was harmless while an image raster
     * only ever drew one frame. With real frame times from [fetchMetadata] it would send every frame
     * inside an hour to the same URL, so each would draw the same image; the API resolves an exact
     * frame time to that frame and any other time to the nearest one. Falls back to
     * [intervalToURLTime] for a string without seconds.
     */
    internal fun rasterUrlTime(interval: String): String {
        val iso = interval.trim().removePrefix("[").removeSuffix("]").trim('"')
        if (iso.length < 19) return intervalToURLTime(interval)
        val digits = iso.substring(0, 19).filter { it.isDigit() }
        return if (digits.length == 14) digits else intervalToURLTime(interval)
    }

    /** `files[].timestamp`, in seconds, as listed; entries without one are skipped. */
    private fun frameTimestamps(json: JSONObject): List<Long> {
        val files = json.optJSONArray("files") ?: return emptyList()
        return (0 until files.length()).mapNotNull { i ->
            files.optJSONObject(i)?.optLong("timestamp", 0L)?.takeIf { it > 0L }
        }
    }

    /** Frames (timestamps in seconds) inside the range padded by [RANGE_PAD_MS], oldest first. */
    internal fun frameDates(timestampsSec: List<Long>, startDate: Date?, endDate: Date?): List<Date> {
        val fromMs = startDate?.time?.minus(RANGE_PAD_MS) ?: Long.MIN_VALUE
        val toMs = endDate?.time?.plus(RANGE_PAD_MS) ?: Long.MAX_VALUE
        return timestampsSec
            .filter { it > 0L }
            .map { it * 1000L }
            .filter { it in fromMs..toMs }
            .distinct()
            .sorted()
            .map { Date(it) }
    }

    /**
     *  Called from [TilePyramid].requestTiles(),
     *  This will eventually initiate the download of bitmaps.
     *
     */
    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?,
        trackDownloadProgress: Boolean,
    ): Any {
        val urlDate = rasterUrlTime(currentDate)
        val tileUrl = makeTileURL(coord, mutableMapOf("time" to urlDate))
        val urlRequest = URLRequest(tileUrl.toString())

        prepareTileRequest(urlRequest, coord.time)

        if (tileCache.pendingCount == 0) {
            trigger(DataSourceEvents.LoadStart(sourceID = id))
            _shouldTriggerLoadCompleteEvent = true
        }

        coord.time = currentDate
        val tile = tileCache[coord] ?: TileType(coord).also { newTile ->
            newTile.time = currentDate
            newTile.coordHash = coord.hash()
            tileCache.updateTile(newTile, coord)
        }

        // don't fetch the tile if it's currently pending or if it's in a failed state and we aren't reloading
        if (options.checkPending) {
            if (!shouldRequestTile(tile, options.reload)) {
                return RequestTileSuccess.AlreadyExists()
            }
        }

        tileCache.setPending(true, tile)
        tile.state = TileState.Loading

        trigger(DataSourceEvents.TileLoadStart(id, tile))

        val tileResponse = try {
            loadTrackedTile(coord, urlRequest) { tileManager.loadTile(coord, urlRequest) }
        } catch (e: CancellationException) {
            releaseFailedRasterTile(tile)
            throw e
        } catch (e: Exception) {
            releaseFailedRasterTile(tile)
            MapsGLDebug.logE(TAG, "Raster tile request failed for $id ${coord.hashShort()}", e)
            return RequestTileSuccess.alreadyExists
        }

        // `as ByteArray` on a null/other payload threw here, and the only caller
        // ([TilePyramid.requestTilesForDownload]'s raster branch) logs that exception solely behind
        // an inactive [pr] flag — so a failed raster fetch vanished with no trace, leaving the tile
        // pending forever. Fail explicitly and loudly instead.
        val data = tileResponse?.data as? ByteArray
        if (data == null) {
            releaseFailedRasterTile(tile)
            MapsGLDebug.logW(
                TAG,
                "Raster tile for $id ${coord.hashShort()} returned no image bytes " +
                    "(payload=${tileResponse?.data?.javaClass?.simpleName ?: "null"})",
            )
            return RequestTileSuccess.alreadyExists
        }

        try {
            val parsedBMP = parseTile(tile, data, tileResponse.headers)
            onTileLoaded(tile, parsedBMP)
        } catch (e: CancellationException) {
            releaseFailedRasterTile(tile)
            throw e
        } catch (e: Exception) {
            releaseFailedRasterTile(tile)
            MapsGLDebug.logE(TAG, "Raster tile decode failed for $id ${coord.hashShort()} (${data.size} bytes)", e)
            return RequestTileSuccess.alreadyExists
        }
        tile.state = TileState.Ready

        return RequestTileSuccess.alreadyExists //Todo: This should be returning RequestTileSuccess<TileData>
    }

    /**
     * Clears the pending mark and returns [tile] to [TileState.Initial] after a failed fetch/decode.
     *
     * Resetting to `Initial` matters: [shouldRequestTile] only re-requests tiles in that state, so
     * leaving a failure as `Loading` (or marking it `Failed`) would permanently wedge that coord for
     * the rest of the session instead of letting the next viewport refresh retry it. Clearing pending
     * also lets [TileCache.pendingCount] reach zero so the load indicator can finish.
     */
    private fun releaseFailedRasterTile(tile: TileType) {
        tileCache.setPending(false, tile)
        tile.state = TileState.Initial
    }

    fun prepareTileRequest(request: URLRequest, timeString: String?) {
        //fixme: Is it inefficient to do this for each tile? is optimization worth the effort?
        request.method = "GET"
        request.headers["Content-Type"] = "application/json"
        request.headers["Access-Control-Request-Headers"] = "x-data-set-locs"
        val jsonArray = JsonArray()

        for (encodedDataset in datasets) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("dataSetId", encodedDataset.code)

            if (encodedDataset.timeOffset == null) {
                jsonObject.addProperty("validTimes", timeString)
            } else { // TimeOffsets like in 1 and 24 hr time change
                val newTime = adjustDateBySeconds(timeString!!, encodedDataset.timeOffset!!.seconds)
                jsonObject.addProperty("validTimes", newTime)
            }
            jsonObject.addProperty("outputMin", 0)
            jsonObject.addProperty("outputMax", 255)
            jsonObject.addProperty("dataMin", encodedDataset.dataRange.start)
            jsonObject.addProperty("dataMax", encodedDataset.dataRange.endInclusive)
            jsonArray.add(jsonObject)
        }
        request.body = jsonArray.toString()//.replace("\"[[\\", "[").replace("\\\"]]\"","\"]")
    }

    /** Puts the data in tile.data and updates tilecache */
    private fun onTileLoaded(tile: TileType, data: Any) {

        if (pr.ON) pr.p(
            TAG,
            pr.tileReceived,
            "onTileLoaded() tile.coordHash: ${tile.coordHash}, data is null? ${data == null}   tile.data is null? ${tile.data == null}"
        )

        isStale = tileCache.isStale(tile)
        if (!isStale) {
            tileCache.setPending(false, tile)
        }

        val newTile = Tile<DataType>(TileCoord(tile.coord.x, tile.coord.y, tile.coord.z, time = tile.time))

        newTile.data = data as Bitmap

        newTile.state = TileState.Ready
        if (isStale) {
            tileCache.setStale(false, newTile)
            //trigger(DataSourceEvents.TileDiscard(sourceID = id, tile = tile))
            return
        }
        if (pr.ON) pr.p(
            TAG,
            pr.tileReceived,
            "onTileLoaded() about to update tile ${newTile.coordHash}, data is null? ${newTile.data == null}"
        )
        tileCache.updateTile(newTile)

        // Queue the GPU upload *after* storing the tile, never before. [requestTiles] inserts a
        // placeholder under this same coord hash, so [TileCache.updateTile] here is a *replace* —
        // and [LRUCache.set] invokes onRemove for the value it replaces, under the same key.
        // TileCache's onRemove drops that key from [TileCache.bindList]. Enqueuing first therefore
        // had the store itself delete the queue entry, so raster tiles (satellite geocolor,
        // infrared, …) downloaded and decoded fine but were never uploaded and never drew.
        tileCache.withBindListLock {
            tileCache.bindList.add(newTile.coordHash)
        }

        val pendingTileCount = tileCache.pendingCount

        if (pendingTileCount == 0 && _shouldTriggerLoadCompleteEvent) {
            //println("$TAG onTileLoaded() triggering for $id")
            trigger(DataSourceEvents.LoadComplete(sourceID = id))
            _apiEvent.value = RasterTileApiEvent.Reload(true)
            _shouldTriggerLoadCompleteEvent = false
        }
    }
}

/**
 *  This will be merged with DataSourceEvents
 *
 *
 */
// was sealed, not compatible with certain versions of java
// https://stackoverflow.com/questions/73453524/what-is-causing-this-error-com-android-tools-r8-internal-nc-sealed-classes-are
open class RasterTileApiEvent {
    class Reload(var reloadNeeded: Boolean) : RasterTileApiEvent()
    class Success(var bitmapList: MutableList<BitmapPackage>?) : RasterTileApiEvent()
    class Error(val msg: String) : RasterTileApiEvent()
}

/**
 *  This is used for the early demo, will not be used in the
 *  final product
 *
 */
class BitmapPackage(val bitmap: Bitmap, val texNum: Int, val id: String)
