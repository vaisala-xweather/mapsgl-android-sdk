package com.xweather.mapsgl.sources

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import com.mapbox.common.Task
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.types.ColorBand
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.SampleChannel
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.weather.EncodedDataset
import com.xweather.mapsgl.weather.XweatherAuthenticator
import java.net.URL
import java.time.OffsetDateTime
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter
import java.util.Date

typealias DatasetType = EncodedDataset

/**
 *  EncodedTileSource.kt
 *
 *  Adapted from IOS version
 *
 *  @author Suto on 01/08/23.
 *
 */
open class EncodedTileSource(override val id: String, open var authenticator: XweatherAuthenticator? = null) :
    TileSource<DataType>() {

    companion object {
        /** Thread-safe (unlike [java.text.SimpleDateFormat]); avoids ICU/Currency races under concurrency. */
        private val validTimesIsoUtcFormatter: DateTimeFormatter =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ssXXX").withZone(ZoneOffset.UTC)
    }

    class MetadataSchema : SourceMetadataSchema()

    override val kind: DataSourceKind = DataSourceKind.ENCODED
    override var timeRange: ClosedRange<Date>?
        get() = TODO("Not yet implemented")
        set(value) {}

    override fun addConsumer(consumer: DataSourceConsumer) {
        TODO("Not yet implemented")
    }

    override fun removeConsumer(layerId: String) {
        TODO("Not yet implemented")
    }

    val type: String
        get() = TODO("Not yet implemented")

    override var datasets: List<DatasetType>
        get() = metadata.data.datasets
        set(value) {
            metadata.data.datasets = value
        }

    override val isEncoded: Boolean = true
    val requests = HashMap<String, Task>()
    override var tileManager: TileRequestManager<DataType> = TileRequestManager()
    override val tileCache: TileCache<DataType>
        get() = TODO("Not yet implemented")
    val shouldTriggerLoadCompleteEvent: Boolean = false

    init {
        metadata = SourceMetadata(MetadataSchema(), null)
        tileSize = TileSize(256)
    }

    override fun appendTileUrlVariables(coord: TileCoord, vars: MutableMap<String, Any>) {
        authenticator?.appendTileCredentialVariables(vars)
    }

    override fun getMetadataURL(): URL? {
        return metadataURL?.let { URL(it) }
    }

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?
    ): Any {
        TODO("Not yet implemented")
    }

    fun getMetadata(band: ColorBand): DatasetType? {
        return metadata.data.datasets.firstOrNull { dataset ->
            dataset.band == band
        }
    }

    fun getMetadata(band: Int): DatasetType? {
        return metadata.data.datasets.firstOrNull { dataset ->
            (dataset.band?.rawValue ?: 5) == band
        }
    }

    /**
     * Returns the metadata for the specified channel, if available.
     */
    fun metadata(forChannel: SampleChannel): EncodedDataset? {
        for (band in forChannel.colorBands) {
            val dataset = metadata.data.datasets.firstOrNull { it.band == band }
            if (dataset != null) {
                return dataset
            }
        }
        return null
    }

    /** Returns the data range for the specified channel. **/
    fun dataRange(channel: SampleChannel): ClosedRange<Double> {
        val metadata = metadata(channel)
        return if (metadata != null) {
            dataRange(metadata)
        } else {
            0.0..1.0
        }
    }

    private fun dataRange(dataset: EncodedDataset): ClosedRange<Double> {
        val rangeMin = dataset.dataRange.start
        val rangeMax = dataset.dataRange.endInclusive
        return rangeMin..rangeMax
    }

    fun getDataRange(band: ColorBand): ClosedRange<Double> {
        val metadata = getMetadata(band)
        return getDataRange(metadata!!)
        //return metadata?.let { getDataRange(it) } ?: 0.0..1.0
    }

    fun getDataRange(band: Int): ClosedRange<Double> {
        val metadata = getMetadata(band)
        return getDataRange(metadata!!)
        //return metadata?.let { getDataRange(it) } ?: 0.0..1.0
    }


    private fun getDataRange(dataset: EncodedDataset): ClosedRange<Double> {
        val rangeMin = dataset.dataRange.start
        val rangeMax = dataset.dataRange.endInclusive
        return rangeMin..rangeMax
    }

    open fun prepareTileRequest(request: URLRequest, timeString: String?) {
        // implementation
    }

    fun prepareTileRequest(request: URLRequest, timeString: String?, intervals: List<String>?) {
        request.method = "POST"
        request.headers["Content-Type"] = "application/json"
        request.headers["Access-Control-Request-Headers"] = "x-data-set-locs"

        if (MapController.packageName != null) {
            //request.headers["Referer"] = "com.wrongcompany.wrongproject"
            //request.headers["Referer"] = MapController.packageName!!
            if (pr.ON) pr.p(TAG, pr.bundleID, "prepareTileRequest() Referer: ${request.headers["Referer"]}")
        }

        authenticator?.credentials?.let { credentials ->
            request.setAuthorization("Bearer ${credentials.accessToken}")
        }

        var validTimeStrings = intervals
        if (validTimeStrings == null) {
            timeString?.let {
                validTimeStrings = listOf(timeString)
            }
        }

        val jsonArray = JsonArray()
        for (encodedDataset in datasets) {
            val jsonObject = JsonObject()
            jsonObject.addProperty("dataSetId", encodedDataset.code)

            // Convert date strings to Date objects.
            // TODO: remove this once all valid time dates are stored as Date instead of strings
            val timeOffsetSeconds = encodedDataset.timeOffset?.seconds ?: 0f
            val intervalsDates: List<Date>? = validTimeStrings?.map {
                var offset = OffsetDateTime.parse(it.substring(2, it.length - 2))
                if (timeOffsetSeconds != 0f) {
                    offset = offset.plusSeconds(timeOffsetSeconds.toLong())
                }
                Date.from(offset.toInstant())
            }

            // Format intervalsDates from Date into ISO date strings required by the MapsGL server
            val vTimeStrings = intervalsDates?.map { validTimesIsoUtcFormatter.format(it.toInstant()) }
            //println("prepareTileRequest: ${intervals?.map { "--$it--" }}, ${validTimeStrings}")

            val jsonValidTimes = JsonArray()
            vTimeStrings?.forEach {
                jsonValidTimes.add(it)
            }

            jsonObject.addProperty("outputMin", 0)
            jsonObject.addProperty("outputMax", 255)
            jsonObject.addProperty("dataMin", encodedDataset.dataRange.start)
            jsonObject.addProperty("dataMax", encodedDataset.dataRange.endInclusive)
            jsonObject.add("validTimes", jsonValidTimes)
            jsonArray.add(jsonObject)

            //println("EncodedTileSource prepareTileRequest: found noData: ${encodedDataset.noData}")
            encodedDataset.noData?.let {
                jsonObject.addProperty("outputMin", it + 1)
                jsonObject.addProperty("outputNoDataValue", encodedDataset.noData)
            }
        }
        request.body = jsonArray.toString()
        //println("REQUEST BODY: ${request.body}")
        if (pr.ON) pr.p(TAG, pr.mInterval, "requestBody: ${request.body}")
    }

    fun cleanup() {
        if (pr.ON) pr.p(TAG, pr.i13, "onRemove() detected EncodedTileLayer, calling cleanup on cache")
        tileCache.cleanup()
    }

}