package com.xweather.mapsgl.sources

import VariableObserver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.SystemClock
import androidx.lifecycle.Observer
import com.xweather.mapsgl.anim.LayerTimeline
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.anim.TileResponse
import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.TileList
import com.xweather.mapsgl.events.DataSourceEvents
import com.xweather.mapsgl.events.trigger
import com.xweather.mapsgl.gl.extensions.pr
import com.xweather.mapsgl.map.MapController
import com.xweather.mapsgl.network.Urls.Companion.mapsGLServer
import com.xweather.mapsgl.sources.data.EncodedData
import com.xweather.mapsgl.sources.data.EncodedTimeSeriesData
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.data.EncodedTileData
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileQuadrant
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.layers.tile.LoadFailureRetry
import com.xweather.mapsgl.util.MapsGLDebug
import com.xweather.mapsgl.types.DataSourceConsumer
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.data.series.EncodedRasterOperations
import com.xweather.mapsgl.data.series.TimeSeriesAggregateRunner
import com.xweather.mapsgl.data.series.TimeSeriesOperationSpec
import com.xweather.mapsgl.data.series.foldWindow
import com.xweather.mapsgl.sources.transformers.TileDataTransformers
import com.xweather.mapsgl.sources.transformers.TileTransformData
import com.xweather.mapsgl.sources.transformers.TransformerId
import com.xweather.mapsgl.weather.XweatherAuthenticator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.cancelChildren
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.coroutineContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URL
import java.nio.ByteBuffer
import java.time.OffsetDateTime
import java.time.format.DateTimeParseException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.roundToInt

@Suppress("Dokka")
data class RequestOptions(
    val dataSetId: String,
    val dataMin: Double,
    val dataMax: Double,
    val outputMin: Double,
    val outputMax: Double,
    val outputNoDataValue: Double? = null,
    val validTimes: MutableList<Date>? = null
)

const val TAG = "XWeatherEncodedTileSource"
private const val BYTESIZE = 4
/** Radar source ids — passed as [isRadar] to native padding helpers. */
private const val RADAR_ENCODED_ID = "radar_REFC_PTYPESMPL_REFC_ARCHIVE"
private const val RADAR_ENCODED_ID_LEGACY = "radar_REFC_PRATE_PTYPESMPL"

/** Request interval strings are an ISO time wrapped as `["<iso>"]`; see [TileSource.intervalToIsoPathTime]. */
private const val INTERVAL_WRAPPER_PREFIX = "[\""
private const val INTERVAL_WRAPPER_SUFFIX = "\"]"

/**
 * Marks [XweatherEncodedTileSource.requestTiles] calls that belong to
 * [XweatherEncodedTileSource.requestAggregateSeries].
 *
 * MapsGL JS never lets the animator request intervals for an operation layer
 * (`TimeSeriesAnimator.loadDataIfNeeded` returns when `operation.type !== 'none'`;
 * `shouldRequestTile` also refuses while the worker is loading). The worker loads every
 * valid time, folds once, and playback only indexes those frames. Android's animation path
 * still asked for the playhead hour, which re-decoded raw pixels at “now” and is the 12:33
 * drop on a running max.
 */
private class OperationAggregateFetch(
    val packedOut: AtomicReference<ByteArray?>? = null,
    val representativeOut: AtomicReference<TileType?>? = null,
) : AbstractCoroutineContextElement(OperationAggregateFetch) {
    companion object Key : CoroutineContext.Key<OperationAggregateFetch>
}

private fun isRadarEncodedSourceId(id: String): Boolean =
    id == RADAR_ENCODED_ID || id == RADAR_ENCODED_ID_LEGACY
var outstandingReq = 0

/**
 *  XweatherEncodedTileSource.kt
 *
 *  A subclass of `EncodedTileSource` that is used to request and process encoded tile data from the MapsGL server.
 *
 *  Based  on the IOS version.
 *  @author Jason Suto 01/08/24
 *
 */

@Suppress("Dokka")
class XweatherEncodedTileSource(
    override var id: String,
    override var authenticator: XweatherAuthenticator?
) : EncodedTileSource("XweatherEncodedTileSource") {

    private val mapPrefixURL = "${mapsGLServer}/tile"
    private val tileByteArraySize = 1048576

    var isStale = false

    enum class Error {
        InvalidData
    }

    companion object {
        var s = 0
        var d = 0
        var stride = 0
        var paddingXByteSize = 0

        // Fixed pool avoids Dispatchers.Default.limitedParallelism, which requires a newer
        // kotlinx-coroutines than some host apps resolve (NoSuchMethodError on older coroutines).
        private val tileProcessingDispatcher =
            Executors.newFixedThreadPool(2) { r ->
                Thread(r, "mapsgl-encoded-tile").apply { isDaemon = true }
            }.asCoroutineDispatcher()
        // Comma-separated "z/x/y" weather tiles to trace end-to-end.
        private const val WEATHER_DEBUG_TARGETS = "6/19/21,6/19/22,6/20/21,6/20/22,6/19/23,6/20/23"
    }


    override var kind: DataSourceKind = DataSourceKind.AERIS_ENCODED
//    override lateinit var bounds: MapBounds<LatitudeLongitude>
//    override val TileSource<DataType>.bounds: LatLonBounds
//        get() {
//            return this.bounds
//        }

    override var tileCache: TileCache<DataType> = TileCache(sourceID = id)
    override var datasets: List<DatasetType> = listOf()
    override val isEncoded: Boolean = true

    /**
     * Client-side transform for derived products, copied from
     * [com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor.transformerId]. Null for
     * ordinary sources, which skip the transform step entirely.
     */
    var transformerId: TransformerId? = null

    /**
     * Folds this source's intervals into a running aggregate, copied from
     * [com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor.operation]. Null for ordinary
     * sources, which skip the whole aggregation path.
     */
    internal var operationSpec: TimeSeriesOperationSpec? = null
        set(value) {
            field = value
            // Opts the timeline out of progressive coarse playback: the pass-2 upgrade delivers
            // intervals behind the fold position, which forces a full aggregate rebuild per tile.
            if (value != null) {
                Timeline.foldedSourceIds.add(id)
                // The grid is usually chosen before this layer exists, so the guard in
                // generateHourlyIntervals has already missed; promote an active coarse grid now.
                Timeline.promoteToFullGridForFoldedSource()
                // No world or overview levels for a folded source. Those tiles are kept so the
                // renderer has something coarse to fall back on while a zoom level loads, and
                // `RenderPass.determinePartial` walks ancestors down to z0 to find one. For an
                // ordinary layer that is a blurrier version of the same field. For a fold it is a
                // different aggregate: computed over a whole-world tile at its own resolution, and
                // re-declared independently of the tiles on screen - measured still holding a
                // 37-interval fold while the z2 tiles had re-folded to 61. Drawing no data is
                // honest where drawing that is not.
                tileCache._persistentLevelCount = 0
            } else {
                Timeline.foldedSourceIds.remove(id)
                tileCache._persistentLevelCount = 2
            }
        }

    /**
     * Range this source's tiles decode against when its operation re-encodes into a wider range than
     * the datasets' own, or null when they decode against the datasets as usual.
     *
     * The fold writes a total such as `precip-accum` into `remappedDataRange`, so reading it against
     * the hourly dataset range scales every value down by the ratio of the two: the data inspector
     * reported a quarter of the real precipitation total (XMAPSGLSDK-444). Drawing is unaffected,
     * because the colour lookup is built over the colorscale range. MapsGL JS declares the same range
     * as the layer's paint `dataRange`.
     */
    internal val foldedDecodeRange: ClosedRange<Double>?
        get() = operationSpec?.remappedDataRange?.let { it.min..it.max }

    /**
     * Built on first use, once [datasets] has been populated by
     * [com.xweather.mapsgl.map.MapController.addSource] — the real-world range the fold decodes
     * against comes from the datasets, not the descriptor.
     */
    private val operationRunner: TimeSeriesAggregateRunner? by lazy {
        val spec = operationSpec
        val folded = datasets.firstOrNull()
        // A value spread across bands spans the first band's minimum to the last band's maximum
        // (handoff B4.5). The bands of a split-range pack each cover a slice, so the first band's
        // own range alone would decode the whole value into a third of it.
        val lastBand = spec?.let { datasets.getOrNull(it.bandsPerValue - 1) } ?: folded
        val range = folded?.dataRange?.let { first ->
            first.start..(lastBand?.dataRange?.endInclusive ?: first.endInclusive)
        }
        if (spec == null || folded == null || range == null) {
            null
        } else {
            val dimension = size + padding * 2
            TimeSeriesAggregateRunner(
                EncodedRasterOperations.OperationContext(
                    operation = spec.operation,
                    dataRange = EncodedRasterOperations.DataRange(range.start, range.endInclusive),
                    bandsPerValue = spec.bandsPerValue,
                    remappedDataRange = spec.remappedDataRange,
                ),
                pixelCount = dimension * dimension,
                onIntervalFolded = { key, millis ->
                    if (!suppressFoldRebind.get()) {
                        blendFoldedEdges(key.coordHash, listOf(millis))
                        rebindFoldedInterval(key, millis)
                    }
                },
                onLateInterval = ::relaunchAggregateAfterLateInterval,
            )
        }
    }

    /**
     * Interval time to tile, per spatial coordinate, for operation sources only.
     *
     * A fold rewrites the interval's pixels after the tile may already be on the GPU, so the tile has
     * to be found again and re-bound. Keyed by epoch millis to match what the runner reports.
     */
    private val operationTiles =
        ConcurrentHashMap<String, ConcurrentHashMap<Long, TileType>>()

    /** Scope for the delayed tail flush; cancelled with the source via [clearOperationState]. */
    private val operationScope = CoroutineScope(SupervisorJob() + tileProcessingDispatcher)

    /**
     * Caps how many tiles may be in an aggregate HTTP/fold step at once.
     *
     * The fold itself is cheap (~2 MB of accumulator per tile). The heap spike is holding every
     * interval of every visible tile decoded at once — 14 tiles × ~37 intervals × ~1 MB is what
     * OOM'd `decodeImageBytesToRgba` at hourly zoom (XMAPSGLSDK-313). Three in-flight tiles is
     * enough for a pan to start new ground without waiting out leftover series; [aggregateDecodePermits]
     * still keeps only one decoded chunk on the Java heap. The tile permit is released between
     * chunks so a newly visible tile can cut in.
     */
    private val aggregatePermits = Semaphore(3)

    /**
     * Only one decoded padded chunk may live on the Java heap at a time.
     *
     * HTTP can overlap a fold — that is only compressed PNG bytes. Decode and fold share this
     * permit so the next chunk is not expanded until the current one has been promoted off-heap.
     */
    private val aggregateDecodePermits = Semaphore(1)

    /** In-flight [requestAggregateSeries] jobs, keyed by spatial hash, so a pan can cancel leftovers. */
    private val aggregateJobs = ConcurrentHashMap<String, Job>()

    /**
     * Spatial keys the camera still wants. Null until the first viewport sync, so the opening
     * load is not treated as already off-screen.
     */
    @Volatile
    private var wantedSpatialKeys: Set<String>? = null

    @Volatile
    private var wantedVisibleKeys: Set<String>? = null

    /**
     * Series already requested per spatial key, identified by the interval set.
     *
     * An aggregate fetches a tile's whole series in one go, so it must be requested once and not again
     * until the series itself changes. Without this the provider — which dispatches continuously during
     * playback — re-fetched every tile's entire series on every pass, which saturated the network and
     * the decode queue and hung the app on play.
     */
    private val aggregateRequested = ConcurrentHashMap<String, Int>()

    /**
     * Series that already ran to completion for a spatial key, including a server that
     * returned nothing. Without this, every later requestTiles() relaunched the same
     * 404 series and the per-interval retry held the only permit for minutes.
     */
    private val aggregateCompleted = ConcurrentHashMap<String, Int>()

    /** Guards against stacking one delayed flush per arriving interval. */
    private val operationFlushScheduled = java.util.concurrent.atomic.AtomicBoolean(false)

    /**
     * [foldAssembledSeries] blends neighbors before the first upload. [submit] still fires
     * [TimeSeriesAggregateRunner.onIntervalFolded] mid-fold; binding then would put the
     * unblended pad on the GPU and the later rebind is a no-op if the hash is already queued.
     */
    private val suppressFoldRebind = java.util.concurrent.atomic.AtomicBoolean(false)

    private var requestCount = 0
    var pendingRequestedTiles: MutableList<String> = mutableListOf()
    private val size = DataPool.originalSize
    private val padding = DataPool.padding
    val metadataObserver = VariableObserver()

    lateinit var passedObserver: Observer<String>
    private val dateFormatter: SimpleDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault())
    private val paddingManager = PaddingManager(size, padding, tileCache, id)

    val threadSafeTileMap = ConcurrentHashMap<String, Tile<DataType>>()
    val threadSafeIntervalMap = ConcurrentHashMap<String, List<String>?>()
    private val onEncodedTileReadyListeners = mutableListOf<(TileCoord) -> Unit>()

    private fun weatherDebugMatches(coord: TileCoord): Boolean {
        if (WEATHER_DEBUG_TARGETS.isEmpty()) return false
        val key = "${coord.z}/${coord.x}/${coord.y}"
        return WEATHER_DEBUG_TARGETS.split(',').any { it.trim() == key }
    }

    init {
        metadata = SourceMetadata(ImageTileSource.MetadataSchema(), URL(mapsGLServer))
        isReady = false
    }

    private val layerId: String
        get() {
            return this.metadataObserver.layerId
        }

    override fun getMetadataURL(): URL? {
        var urlString = metadataURL ?: return null
        val datasetString = "&data-set-ids=${datasets.joinToString("&data-set-ids=") { it.code }}"

        if (pr.ON) pr.p(
            TAG,
            pr.metadata,
            "getMetadataURL() metadata.data.startDate: ${metadata.data.startDate}, metadata.data.endDate: ${metadata.data.endDate}"
        )

        val beginString = dateFormatter.format(metadata.data.startDate.time)
        val endString = dateFormatter.format(metadata.data.endDate.time)
        urlString = urlString.replace("&{datasets}", datasetString)
        urlString = urlString.replace("{startDate}", beginString).replace("{endDate}", endString)
        if (pr.ON) pr.p(TAG, pr.metadata, "getMetadataURL() returning $urlString ")
        return URL(urlString)
    }

    fun setObserver(observer: Observer<String>, layerID: String) {
        metadataObserver.observeVariableAndQuit(observer, layerID)
        passedObserver = observer
    }

    /**
     * Backoff after a failed metadata fetch. While the source has no metadata, the map polls this
     * on every rendered frame (`onMoveNoMove`), so without a cooldown an offline device sent a
     * fresh metadata request per frame.
     */
    private val metadataFailureBackoff = LoadFailureRetry(maxRetries = Int.MAX_VALUE)

    /** Elapsed-realtime before which [fetchMetadata] fails fast instead of hitting the network. */
    @Volatile
    private var metadataRetryNotBeforeMs = 0L

    /**
     * Timeline start/end (epoch ms) of the last successful metadata fetch, before the six-hour
     * widening in [fetchMetadataOnce]. An operation layer folds only the valid times inside it.
     */
    @Volatile
    private var foldWindowRange: Pair<Long?, Long?>? = null

    /**
     * Never throws for a load failure: the result reaches `TilePyramid` and `TileLayer` on the main
     * dispatcher, where an escaped exception kills the host app. [SourceMetadata.load] rethrows
     * [com.xweather.mapsgl.error.AuthenticationError] (a [java.lang.Error]), so this catches
     * [Throwable]. Cancellation still propagates.
     */
    override suspend fun fetchMetadata(startDate: Date?, endDate: Date?): Result<Unit> {
        val now = SystemClock.elapsedRealtime()
        if (now < metadataRetryNotBeforeMs) {
            return Result.failure(
                IllegalStateException("Metadata for $id unavailable; retrying in ${metadataRetryNotBeforeMs - now}ms")
            )
        }
        val result = try {
            fetchMetadataOnce(startDate, endDate)
        } catch (e: CancellationException) {
            throw e
        } catch (t: Throwable) {
            MapsGLDebug.logW(TAG, "fetchMetadata failed for $id", t)
            Result.failure(t)
        }
        synchronized(metadataFailureBackoff) {
            if (result.isSuccess) {
                metadataFailureBackoff.onSuccess()
                metadataRetryNotBeforeMs = 0L
                foldWindowRange = Pair(startDate?.time, endDate?.time)
            } else {
                val delayMs = metadataFailureBackoff.onFailure().retryDelayMs ?: LoadFailureRetry.MAX_DELAY_MS
                metadataRetryNotBeforeMs = SystemClock.elapsedRealtime() + delayMs
            }
        }
        return result
    }

    private suspend fun fetchMetadataOnce(startDate: Date?, endDate: Date?): Result<Unit> {
        authenticator?.authenticate()

        if (startDate != null) {
            metadata.data.startDate = Date(startDate.time - 6 * 3600 * 1000)
        }
        if (endDate != null) {
            metadata.data.endDate = Date(endDate.time + 6 * 3600 * 1000)
        } else {
        }

        val url =
            getMetadataURL() ?: return Result.failure(IllegalStateException("Metadata URL could not be generated."))
        val request = URLRequest(url.toString())

        request.setHeader("Referer", MapController.packageName!!)
        authenticator?.credentials?.let { credentials ->
            request.setAuthorization("Bearer ${credentials.accessToken}")
        }

        val success = withContext(Dispatchers.IO) {
            if (Timeline.sourceTimeHash[id] == null) {
                Timeline.sourceTimeHash[id] = LayerTimeline(id)
            }

            val loaded = metadata.load(request, metadataObserver.layerId, id)
            minZoom = metadata.data.minZoom
            maxZoom = metadata.data.maxZoom
            if (loaded) {
                metaDataNeeded--
            }
            loaded
        }

        if (!success) {
            return Result.failure(IllegalStateException("Metadata load did not complete for $id"))
        }

        if (metaDataNeeded == 0) {
            metadataObserver.updateVariable(metadataObserver.layerId)
        }

        return Result.success(Unit)
    }

    @Synchronized
    fun addOnEncodedTileReadyListener(listener: (TileCoord) -> Unit) {
        onEncodedTileReadyListeners.add(listener)
    }

    @Synchronized
    private fun notifyEncodedTileReady(coord: TileCoord) {
        if (onEncodedTileReadyListeners.isEmpty()) return
        val listenersSnapshot = onEncodedTileReadyListeners.toList()
        for (listener in listenersSnapshot) {
            runCatching { listener(coord) }
        }
    }

    /** Test function to detect color format of image **/
    fun getImageColorFormat(imageBytes: ByteArray): Bitmap.Config? {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size, options)
        return options.outConfig
    }

    private fun removeTrackedPendingInterval(
        coord: TileCoord,
        interval: String,
        trackDownloadProgress: Boolean,
    ) {
        if (trackDownloadProgress) {
            TileList.pendingList.remove(this.id, coord.hashShort(), interval)
        }
        // Always clear the per-interval eviction guard set in requestTiles(), regardless of
        // trackDownloadProgress — this is a correctness/eviction-safety concern, not UI progress.
        val intervalHash = TileCoord(coord.x, coord.y, coord.z, 0, interval).hash()
        tileCache._pending.remove(intervalHash)
        tileCache._pendingTime.remove(intervalHash)
        tileCache._requestedTiles.remove(intervalHash)
        // Must clear the MapsGL load-session key. Previously only [TilePyramid]'s
        // invokeOnCompletion did this on every job end (including success), which raced
        // in-flight downloads; success must clear here so the 100s watchdog is not stuck.
        Timeline.removePendingEncodedDownload(id, intervalHash)
    }

    private fun removeTrackedPendingEncoded(intervalHash: String, trackDownloadProgress: Boolean) {
        if (trackDownloadProgress) {
            Timeline.removePendingEncodedDownload(id, intervalHash)
        }
    }

    /** Makes [requestTiles]' satisfied-check and pending claim one step; see its use there. */
    private val requestClaimLock = Any()

    override suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>?,
        trackDownloadProgress: Boolean,
    ): Any { // Return type might need adjustment if you expect specific results
        // An aggregating layer needs its whole series, oldest first, and it needs it whether or not
        // anything is playing. The provider hook that used to start that fetch sits in
        // `TiledTimeSeriesDataProvider.enqueueTileRequestIfNeeded`, which this path never reaches -
        // measured at zero calls while the ordinary animation path asked for 192 single intervals.
        // So the series is claimed here, from the request path that does run. `requestAggregateSeries`
        // claims the coord before issuing its own chunked requests, so those re-enter this check
        // already claimed and fall through rather than recursing.
        // Re-fetch when the series itself changes, not merely when this tile has never been claimed.
        // Extending the timeline grows the product's valid times - measured 37 to 61 on a one-day
        // extension - and a claim keyed only on "seen before" left the tile folding the old series
        // while the animator played the new one, so the added intervals drew raw and the running
        // maximum appeared to pulse again.
        if (operationSpec != null && aggregateRequested[coord.hashShort()] != currentSeriesId()) {
            launchAggregateSeries(coord, currentDate)
        }
        // MapsGL JS: the animator does not load intervals for an operation source. Only the
        // aggregate runner's own chunked requests (tagged [OperationAggregateFetch]) may hit the
        // network. A playhead fetch of the current hour is the raw re-decode at “now”.
        if (operationSpec != null && coroutineContext[OperationAggregateFetch] == null) {
            val intervalList = intervals.orEmpty()
            for (interval in intervalList) {
                val lookupCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                val hash = lookupCoord.hash()
                // The aggregator owns these tiles. Leaving animator pending keys around
                // (often a `Z` wrapper for the same instant the fold stored as `+00:00`)
                // pins the load indicator below 100% and is how a playhead hour stays
                // "in flight" forever.
                Timeline.removePendingEncodedDownload(id, hash)
                tileCache._requestedTiles.remove(hash)
            }
            return RequestTileSuccess.alreadyExists
        }
        //if (pr.ON) pr.p(TAG, pr.tileReq, "requestTiles() entered  ${layerId}")

        // ownerMapSessionId is stamped in [MapController.addSource]; fall back to the active
        // session so tiles are not discarded when the field was not set (regression guard).
        val requestSession =
            ownerMapSessionId.takeIf { it != 0L } ?: Timeline.mapSessionId

        val urlTime = intervalToIsoPathTime(currentDate)
        val tileUrl = makeTileURL(coord, mutableMapOf("time" to urlTime))
        if (weatherDebugMatches(coord)) {
            MapsGLDebug.trace("[WeatherDebug][Fetch] request start key=${coord.z}/${coord.x}/${coord.y} time=$currentDate intervals=${intervals?.size ?: 0}")
        }
        val urlRequest = URLRequest(tileUrl.toString()).apply {
            // Prevent "loading forever" by bounding per-tile HTTP time.
            // When this trips, requestTiles() will fall into the failure path and
            // remove the tile interval from TileList.pendingList so animation can continue.
            connectTimeoutMs = 20_000
            readTimeoutMs = 20_000
        }
        prepareTileRequest(urlRequest, coord.time, intervals) // Sets body based on intervals

        val intervalList = intervals.orEmpty()
        // Interval keys this call marked pending in the claim below; released if setup throws
        // before the download's own try/catch takes over their cleanup.
        var claimedKeys: List<String> = emptyList()
        if (intervalList.isNotEmpty()) {
            // Check and claim under one lock. Scrub, refresh and playback waves each launch their
            // own job for the same tile×interval; with the pending keys set only later, in the
            // download try block, two jobs could both miss the check and both hit the network.
            val allSatisfied = synchronized(requestClaimLock) {
                val satisfied = intervalList.all { interval ->
                    val lookupCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                    val hash = lookupCoord.hash()
                    tileCache._pending.containsKey(hash) ||
                        tileCache.hasBindableEncodedPixels(hash) ||
                        intervalAlreadyFolded(coord, interval)
                }
                if (!satisfied) {
                    val placeholder = TileType(TileCoord(coord.x, coord.y, coord.z, 0, intervalList.first()))
                    claimedKeys = intervalList.mapNotNull { interval ->
                        val hash = TileCoord(coord.x, coord.y, coord.z, 0, interval).hash()
                        if (tileCache._pending.containsKey(hash)) {
                            null
                        } else {
                            tileCache.setPendingKey(true, hash, placeholder)
                            hash
                        }
                    }
                }
                satisfied
            }
            if (allSatisfied) {
                // Drop Timeline pending only for intervals that are actually drawable. If another
                // job still owns `_pending`, leave the Timeline key so the load session can finish
                // when that job completes.
                for (interval in intervalList) {
                    val lookupCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                    val hash = lookupCoord.hash()
                    if (tileCache.hasBindableEncodedPixels(hash)) {
                        Timeline.removePendingEncodedDownload(id, hash)
                        tileCache._requestedTiles.remove(hash)
                    }
                }
                return RequestTileSuccess.alreadyExists
            }
        }

        fun markReady(interval: String) {
            if (requestSession != Timeline.mapSessionId) return
            TileList.readyList.add(this.id, coord.hashShort(), interval, requestSession)
        }

        /** Only claim ready when decode produced bindable pixels for this interval. */
        fun markReadyIfPixelsPresent(interval: String) {
            val hash = TileCoord(coord.x, coord.y, coord.z, 0, interval).hash()
            if (tileCache.hasBindableEncodedPixels(hash)) {
                markReady(interval)
            }
        }

        // --- Tile Cache and State Logic (seems mostly okay) ---
        // Set correct time on coord for cache lookup if multiple intervals are passed
        val primaryLookupTime = intervals?.firstOrNull() ?: coord.time ?: "" // Use first interval or original time
        val coordForLookup = (TileCoord(coord.x, coord.y, coord.z))  // Use a copy for lookup key
        coordForLookup.time = primaryLookupTime
        // Get or create the tile representing this batch (maybe use first interval time?)


        val representativeTile = try {
            val tile = tileCache[coordForLookup] ?: TileType(coordForLookup).also { newTile ->
                newTile.isEncoded = true
                newTile.coordHash = coordForLookup.hash()
                tileCache.updateTile(newTile, coordForLookup) // Update cache with the representative tile
            }

            // Set pending *before* starting the load operation for this representative coord/interval list
            tileCache.setPending(true, tile)
            tile.state = TileState.Loading
            if (trackDownloadProgress) {
                trigger(DataSourceEvents.TileLoadStart(id, tile))
            }
            tile
        } catch (t: Throwable) {
            // Nothing below runs, so nothing else would release the claim.
            for (key in claimedKeys) {
                tileCache._pending.remove(key)
                tileCache._pendingTime.remove(key)
            }
            throw t
        }

        if (pr.ON && pr.tileRequest.active) pr.p(TAG, pr.tileRequest, "requestTiles() req ${coord.hashShort()} intv: $intervals")

        var keepTrack = 0

        val tileResponse: TileResponse? = try {
            if (intervals != null) {
                for (interval in intervals) {
                    if (trackDownloadProgress) {
                        TileList.requestedList.add(this.id, coord.hashShort(), interval)
                        TileList.pendingList.add(this.id, coord.hashShort(), interval)
                        Timeline.currentDLCount++
                    }
                    // Protects this specific interval against concurrent eviction for the whole
                    // download+decode window, not just the representative tile's own hash — cleared
                    // in removeTrackedPendingInterval() once this interval's own tile is bound (or
                    // the batch fails).
                    val intervalHash = TileCoord(coord.x, coord.y, coord.z, 0, interval).hash()
                    tileCache.setPendingKey(true, intervalHash, representativeTile)
                    if (pr.ON) pr.p(TAG, pr.tileReq, "cordHash:${coord.hashShort()}    ${interval}")
                }
            }



            requestCount++
            pendingRequestedTiles.add(coord.hash())
            keepTrack = requestCount
            loadTrackedTile(coord, urlRequest) { tileManager.loadTile(coord, urlRequest) }
        } catch (e: Exception) {
            if (weatherDebugMatches(coord)) {
                MapsGLDebug.trace("[WeatherDebug][Fetch] request exception key=${coord.z}/${coord.x}/${coord.y} err=${e.message}")
            }
            MapsGLDebug.logE(TAG, "loadTile failed for ${coord.hashShort()}", e)
            //println("XweatherEncodedTileSource requestTiles() failed for ${coord.hashShort()}")
            requestCount--
            pendingRequestedTiles.remove(coord.hash())

            // Remove pending entries for the whole multi-interval batch.
            // Then retry each interval individually so other intervals can still load.
            val intervalList = intervals.orEmpty()
            for (interval in intervalList) {
                removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
            }

            tileCache.setPending(false, representativeTile) // Ensure representative pending is cleared
            representativeTile.state = TileState.Failed // Mark as failed (sub-interval successes may override)

            // CancellationException signals coroutine cancellation (e.g. controller shutdown).
            // Pending state is already cleaned up above; re-throw so the coroutine machinery
            // can propagate the cancellation instead of falling into the retry loop and
            // stamping phantom TileList entries against the new session's mapSessionId.
            if (e is CancellationException) throw e

            // Non-time-series / unexpected call path: keep timeline bookkeeping consistent.
            if (intervalList.isEmpty()) {
                removeTrackedPendingEncoded(coord.hash(), trackDownloadProgress)
                return RequestTileSuccess.alreadyExists
            }

            for (interval in intervalList) {
                val retryIntervalHash = TileCoord(coord.x, coord.y, coord.z, 0, interval).hash()
                tileCache.setPendingKey(true, retryIntervalHash, representativeTile)
                try {
                    val singleUrlRequest = URLRequest(tileUrl.toString()).apply {
                        connectTimeoutMs = 20_000
                        readTimeoutMs = 20_000
                    }
                    prepareTileRequest(singleUrlRequest, coord.time, listOf(interval))

                    val singleResponse = loadTrackedTile(coord, singleUrlRequest) {
                        tileManager.loadTile(coord, singleUrlRequest)
                    }
                    if (singleResponse != null) {
                        val packed = singleResponse.data as? ByteArray
                        singleResponse.data = 0
                        try {
                            onTileLoaded(representativeTile, listOf(interval), 1, packed)
                        } finally {
                            tileCache.setPendingKey(false, retryIntervalHash, representativeTile)
                            markReadyIfPixelsPresent(interval)
                        }
                    } else {
                        if (trackDownloadProgress) {
                            TileList.failedList.add(this.id, coord.hashShort(), interval)
                        }
                        val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                        removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                        tileCache.setPendingKey(false, retryIntervalHash, representativeTile)
                    }
                } catch (e2: Exception) {
                    tileCache.setPendingKey(false, retryIntervalHash, representativeTile)
                    if (e2 is CancellationException) throw e2
                    if (trackDownloadProgress) {
                        TileList.failedList.add(this.id, coord.hashShort(), interval)
                    }
                    val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                    removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                    MapsGLDebug.logW(TAG, "Single-interval retry failed for ${intervalCoord.hash()}", e2)
                }
            }

            // We already retried per-interval in the catch block; skip the shared tileResponse-null failure path.
            return RequestTileSuccess.alreadyExists
        }

        // --- Process the result ---
        if (tileResponse != null) {
            if (requestSession != Timeline.mapSessionId) {
                requestCount--
                pendingRequestedTiles.remove(coord.hash())
                tileCache.setPending(false, representativeTile)
                for (interval in intervalList) {
                    removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
                }
                return RequestTileSuccess.alreadyExists
            }
            if (weatherDebugMatches(coord)) {
                MapsGLDebug.trace("[WeatherDebug][Fetch] response ok key=${coord.z}/${coord.x}/${coord.y}")
            }
            if (pr.ON) {
                pr.p(TAG, pr.receivedEnc, "recieved enc data: ${tileResponse.headers}")
            }
            requestCount--
            pendingRequestedTiles.remove(coord.hash())

            //if(pr.ON) pr.p(TAG, pr.tileRequestActual, "requestTiles() actually received ${tileResponse.headers.values}")
            if (pr.ON) pr.p(TAG, pr.tileRequestActual, "requestTiles() requestCount:     $requestCount     $keepTrack")

            // Keep packed bytes local — never share via representativeTile.data across concurrent
            // multi-/single-interval requests for the same z/x/y (caused 8MB↔1MB size mismatches).
            val packedBytes = tileResponse.data as? ByteArray
            tileResponse.data = 0
            // coordHash looks like 0:0/0/0/["2025-04-30T14:00:00Z"]

            val hold = coroutineContext[OperationAggregateFetch]
            if (hold?.packedOut != null) {
                // Leave interval pending keys until the runner decodes this chunk. Clearing them
                // here would hide the load indicator while the padded buffers were still unbuilt.
                hold.packedOut.set(packedBytes)
                hold.representativeOut?.set(representativeTile)
            } else if (Timeline.movedOnTileLoaded) {
                for (interval in intervals!!) {
                    removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
                    // Deferred path: pixels land later via threadSafeTileMap — do not claim ready yet.
                }
                if (packedBytes != null) {
                    representativeTile.data = packedBytes
                }
                threadSafeTileMap[representativeTile.coordHash] = representativeTile
                threadSafeIntervalMap[representativeTile.coordHash] = intervals
            } else {
                try {
                    onTileLoaded(representativeTile, intervals, 1, packedBytes)
                } finally {
                    for (interval in intervals!!) {
                        removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
                        markReadyIfPixelsPresent(interval)
                    }
                }
            }

            // onTileLoaded should handle setting state to Ready and clearing pending
        } else {
            if (weatherDebugMatches(coord)) {
                MapsGLDebug.trace("[WeatherDebug][Fetch] response null key=${coord.z}/${coord.x}/${coord.y}")
            }
            // Failure already logged (e.g., timeout inside URLRequest/URLConnection).
            // IMPORTANT: clear representative tile "pending" state too, otherwise
            // checkDownloadStatus() can keep waiting even though TileList.pendingList
            // has already been updated.
            requestCount--
            tileCache.setPending(false, representativeTile)
            representativeTile.state = TileState.Failed

            val intervalListNull = intervals.orEmpty()

            // Remove pending for the whole multi-interval batch.
            // Then retry each interval individually so other intervals can still load.
            for (interval in intervalListNull) {
                removeTrackedPendingInterval(coord, interval, trackDownloadProgress)
            }

            if (intervalListNull.isEmpty()) {
                removeTrackedPendingEncoded(coord.hash(), trackDownloadProgress)
                pendingRequestedTiles.remove(coord.hash())
                return RequestTileSuccess.alreadyExists
            }

            if (coroutineContext[OperationAggregateFetch] != null) {
                // A folded series asks for a whole chunk. Retrying each hour after a null
                // batch (ocean / uncovered 404s) held the only aggregate permit for minutes
                // and starved the tiles that actually had data.
                pendingRequestedTiles.remove(coord.hash())
                MapsGLDebug.logW(TAG, "TileResponse was null for ${coord.hash()}, load failed.")
                return RequestTileSuccess.alreadyExists
            }

            for (interval in intervalListNull) {
                // If the batch failed, we only bother retrying when there are multiple intervals.
                if (intervalListNull.size == 1) {
                    if (trackDownloadProgress) {
                        TileList.failedList.add(this.id, coord.hashShort(), interval)
                    }
                    val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                    removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                    continue
                }

                val retryIntervalHash = TileCoord(coord.x, coord.y, coord.z, 0, interval).hash()
                tileCache.setPendingKey(true, retryIntervalHash, representativeTile)
                try {
                    val singleUrlRequest = URLRequest(tileUrl.toString()).apply {
                        connectTimeoutMs = 20_000
                        readTimeoutMs = 20_000
                    }
                    prepareTileRequest(singleUrlRequest, coord.time, listOf(interval))

                    val singleResponse = loadTrackedTile(coord, singleUrlRequest) {
                        tileManager.loadTile(coord, singleUrlRequest)
                    }
                    if (singleResponse != null) {
                        val packed = singleResponse.data as? ByteArray
                        singleResponse.data = 0
                        try {
                            onTileLoaded(representativeTile, listOf(interval), 1, packed)
                        } finally {
                            tileCache.setPendingKey(false, retryIntervalHash, representativeTile)
                            markReadyIfPixelsPresent(interval)
                        }
                    } else {
                        if (trackDownloadProgress) {
                            TileList.failedList.add(this.id, coord.hashShort(), interval)
                        }
                        val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                        removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                        tileCache.setPendingKey(false, retryIntervalHash, representativeTile)
                    }
                } catch (e2: Exception) {
                    tileCache.setPendingKey(false, retryIntervalHash, representativeTile)
                    if (e2 is CancellationException) throw e2
                    if (trackDownloadProgress) {
                        TileList.failedList.add(this.id, coord.hashShort(), interval)
                    }
                    val intervalCoord = TileCoord(coord.x, coord.y, coord.z, 0, interval)
                    removeTrackedPendingEncoded(intervalCoord.hash(), trackDownloadProgress)
                    MapsGLDebug.logW(TAG, "Single-interval retry failed for ${intervalCoord.hash()}", e2)
                }
            }

            pendingRequestedTiles.remove(coord.hash())
            MapsGLDebug.logW(TAG, "TileResponse was null for ${coord.hash()}, load failed.")
        }
        if (pr.ON) pr.p(TAG, pr.dataPool, "XWeatherEncodedTileSource requestTiles() exited")
        return RequestTileSuccess.alreadyExists // Placeholder, adjust as needed
    }

    /**
     * Rewrites one padded interval strip in place when this source is a derived product.
     *
     * A no-op unless [transformerId] is set, so ordinary sources pay only a null check per interval.
     */
    private fun applyTransformer(tile: TileType) {
        val transformer = transformerId ?: return
        val padded = tile.encodedData?.paddedData ?: return
        TileDataTransformers.forId(transformer).transform(
            TileTransformData(padded, size, padding),
            datasets,
        )
    }

    /**
     * Epoch millis for a request interval string.
     *
     * The string is an ISO offset timestamp wrapped in two characters at each end (`["…"]`), the same
     * shape [EncodedTileSource.prepareTileRequest] unwraps when it builds the request body.
     *
     * @return null when the string cannot be parsed, which skips aggregation for that interval rather
     * than folding it into the wrong position.
     */
    private fun intervalAlreadyFolded(coord: TileCoord, interval: String): Boolean {
        val runner = operationRunner ?: return false
        val millis = intervalEpochMillis(interval) ?: return false
        return runner.hasFolded(TimeSeriesAggregateRunner.TileKey(id, coord.hashShort()), millis)
    }

    private fun intervalEpochMillis(interval: String): Long? {
        if (interval.length < 5) return null
        return try {
            OffsetDateTime.parse(interval.substring(2, interval.length - 2)).toInstant().toEpochMilli()
        } catch (e: DateTimeParseException) {
            MapsGLDebug.logW(TAG, "Unparseable interval for aggregation: $interval", e)
            null
        }
    }

    /**
     * What [submitToOperation] decided about a just-decoded interval.
     *
     * A running max must never upload a raw interval: that is the pulse. [BINDABLE] means the
     * pixels are already the fold (or this is not an operation source). [HOLD] keeps the buffer for
     * the chronological fold and leaves any existing GPU texture alone. [DISCARD] is a re-decode
     * whose folded pixels are gone — do not replace the cache entry with raw.
     */
    private enum class OperationPixelState { BINDABLE, HOLD, DISCARD }

    /**
     * Folds a newly decoded interval into its tile's running aggregate and re-binds the frames the
     * fold changed.
     *
     * A no-op unless [operationSpec] is set. Runs after the transformer, so a derived product is
     * accumulated from derived values rather than raw source bands.
     */
    private fun submitToOperation(tile: TileType, interval: String): OperationPixelState {
        val runner = operationRunner ?: return OperationPixelState.BINDABLE
        val padded = tile.encodedData?.paddedData ?: return OperationPixelState.HOLD
        val millis = intervalEpochMillis(interval) ?: return OperationPixelState.HOLD

        val spatialKey = tile.coord.hashShort()
        val key = TimeSeriesAggregateRunner.TileKey(id, spatialKey)

        val byInterval = operationTiles.getOrPut(spatialKey) { ConcurrentHashMap() }

        if (runner.hasFolded(key, millis)) {
            // A re-decode of an interval already in the aggregate. Every decode allocates a fresh
            // tile and a fresh padded buffer, so this one carries the interval's *raw* pixels; the
            // runner refuses to fold it again (that would double-count) and therefore does not
            // rewrite it either. Binding it as-is draws one interval's own value in a frame that
            // holds the running result -- seen on device as an operation layer whose values pulse
            // on frames behind the playhead.
            //
            // The tile this one replaces still holds the folded pixels for this interval, so copy
            // them across before it is dropped.
            val previous = byInterval[millis]
            // [TileCache] moves a tile's padded bytes to the native cache once it has been bound and
            // nulls the Java reference, so the folded pixels are usually *not* on the tile any more -
            // they are in native under the cache's own key. Reading only the Java field made this
            // frame draw its raw interval instead of the running total, which on a running maximum is
            // a visible drop that recovers on the next pass: the layer pulses, most often just after
            // the current time where the newest intervals keep being re-fetched.
            val foldedPixels = listOfNotNull(previous?.coordHash, tile.coordHash)
                .distinct()
                .firstNotNullOfOrNull { hash ->
                    tileCache.nativeCache.getData("${tileCache.sourceID}$hash")
                }
                ?: previous?.encodedData?.paddedData
            if (foldedPixels != null && foldedPixels !== padded && foldedPixels.size == padded.size) {
                foldedPixels.copyInto(padded)
            } else if (foldedPixels == null) {
                // Gone from Java and native. Restarting the aggregate here is the flash at “now”:
                // playback re-asks the current hour, restore misses, and the running max drops to
                // one raw interval then climbs back. Keep the GPU fold; do not bind this decode.
                MapsGLDebug.logW(
                    TAG,
                    "Re-decoded interval $millis for $spatialKey is folded but its pixels were " +
                        "reclaimed; keeping the current aggregate",
                )
                tile.holdBindUntilFolded = true
                return OperationPixelState.DISCARD
            }
            tile.holdBindUntilFolded = false
            byInterval[millis] = tile
            return OperationPixelState.BINDABLE
        }

        // Arrival does not fold. MapsGL JS awaits every chunk, assembles the whole ordered series and
        // folds it once (see TimeSeriesAggregateRunner.run: `await Promise.all(...)` then the fold);
        // folding as tiles happen to arrive is what made the aggregate depend on network order. That
        // dependence is what the cursor, the settle timeout and rebuild-on-late-arrival all existed to
        // paper over, and it still showed: a running maximum measured 129 -> 121 -> 121 -> 129 at the
        // interval on the current time, which a fold over a complete series cannot produce.
        //
        // Do not bind this raw interval either. Playback asks around the playhead, so these pixels
        // land and upload before the chronological fold has rewritten them — a max layer that draws
        // the current hour pulses on every tile the fold has not reached yet, usually the side of
        // the screen whose series is still in flight.
        tile.holdBindUntilFolded = true
        byInterval[millis] = tile
        return OperationPixelState.HOLD
    }

    /**
     * Re-binds the one interval whose pixels a fold just rewrote.
     *
     * Called by the runner on the folding thread.
     */
    /**
     * A late interval cannot be spliced into a fold that has already passed it. Drop the claim so
     * the next request refetches oldest-first. Leave GPU textures alone — they still hold the last
     * good running result until each interval is folded again.
     */
    private fun relaunchAggregateAfterLateInterval(key: TimeSeriesAggregateRunner.TileKey) {
        if ((operationRunner?.foldedCount(key) ?: 0) > 0) return
        val spatialKey = key.coordHash
        val sample = operationTiles[spatialKey]?.values?.firstOrNull() ?: return
        aggregateRequested.remove(spatialKey)
        operationRunner?.release(key)
        launchAggregateSeries(sample.coord, sample.time)
    }

    private fun rebindFoldedInterval(key: TimeSeriesAggregateRunner.TileKey, timeMillis: Long) {
        val tile = operationTiles[key.coordHash]?.get(timeMillis) ?: return
        rebindFoldedTile(tile)
    }

    private fun rebindFoldedTile(tile: TileType) {
        tile.needsBind = true
        tileCache.withBindListLock {
            if (!tileCache.bindList.contains(tile.coordHash)) {
                tileCache.bindList.add(tile.coordHash)
                tileCache.updateTile(tile)
            }
        }
    }

    private fun restorePadded(tile: TileType): ByteArray? {
        val encoded = tile.encodedData ?: return null
        encoded.paddedData?.let { return it }
        val restored = tileCache.nativeCache.getData("${tileCache.sourceID}${tile.coordHash}")
            ?: return null
        encoded.paddedData = restored
        return restored
    }

    /**
     * Copies each folded interval's interior edge into its neighbors' pads, and vice versa.
     *
     * Matches MapsGL JS `EncodedTileSource.onTileLoaded`, which backfills after `setData`.
     * A neighbor still on HOLD is skipped; that tile blends this one when it folds.
     */
    private fun blendFoldedEdges(spatialKey: String, times: List<Long>) {
        val byInterval = operationTiles[spatialKey] ?: return
        for (millis in times) {
            val tile = byInterval[millis] ?: continue
            if (tile.holdBindUntilFolded) continue
            if (restorePadded(tile) == null) continue
            for ((_, neighborCoord) in tile.coord.getNeighbors()) {
                val neighbor = operationTiles[neighborCoord.normalize().hashShort()]?.get(millis)
                    ?: continue
                if (neighbor.holdBindUntilFolded) continue
                if (restorePadded(neighbor) == null) continue
                fillEdge(tile, neighbor, replaceExisting = true)
                fillEdge(neighbor, tile, replaceExisting = true)
                rebindFoldedTile(neighbor)
            }
        }
    }

    /**
     * Makes sure the tail of a series folds.
     *
     * Submitting drains whatever has settled, so a series arriving steadily folds itself. The last
     * interval has nothing behind it to trigger that drain, and would otherwise sit in the queue
     * showing its own raw value instead of the final total. One delayed pass covers it, and the flag
     * keeps a busy tile from queuing one per interval.
     */
    private fun scheduleOperationFlush() {
        val runner = operationRunner ?: return
        if (!operationFlushScheduled.compareAndSet(false, true)) return
        operationScope.launch {
            try {
                delay(TimeSeriesAggregateRunner.DEFAULT_SERIES_TIMEOUT_MILLIS + 250L)
                runner.flushExpired()
            } finally {
                operationFlushScheduled.set(false)
            }
        }
    }

    /**
     * Starts a tile's aggregate off the caller's thread.
     *
     * The provider dispatches on the main thread, and an aggregate issues several chunked requests in
     * sequence, so it must not be awaited there — that is the ANR the surrounding code already warns
     * about, multiplied by the chunk count.
     *
     * [aggregatePermits] lets three tiles fetch at once; [aggregateDecodePermits] still
     * decodes one chunk at a time. The same spatial key is launched once. Off-screen work
     * stops after the current chunk via [setWantedAggregateTiles], so a leftover series
     * does not hold a tile permit until the end.
     */
    internal fun launchAggregateSeries(coord: TileCoord, currentDate: String) {
        if (operationRunner == null) return
        val spatialKey = coord.hashShort()
        val seriesId = currentSeriesId()
        if (aggregateCompleted[spatialKey] == seriesId) return
        if (aggregateRequested[spatialKey] == seriesId) return
        aggregateJobs[spatialKey]?.cancel()
        aggregateRequested[spatialKey] = seriesId
        Timeline.addPendingEncodedDownload(id, spatialKey)
        val job = operationScope.launch {
            try {
                if (requestAggregateSeries(coord, currentDate)) {
                    aggregateCompleted[spatialKey] = seriesId
                    Timeline.removePendingEncodedDownload(id, spatialKey)
                }
            } catch (e: CancellationException) {
                aggregateRequested.remove(spatialKey, seriesId)
                throw e
            }
        }
        aggregateJobs[spatialKey] = job
        job.invokeOnCompletion { cause ->
            aggregateJobs.remove(spatialKey, job)
            if (cause == null) {
                aggregateCompleted.putIfAbsent(spatialKey, seriesId)
                Timeline.removePendingEncodedDownload(id, spatialKey)
            }
        }
    }

    /**
     * Records the spatial keys the camera is fetching now.
     *
     * An in-flight chunk is left to finish — cancelling mid-HTTP left pending download keys
     * and the load spinner ran forever. The next chunk checks [isAggregateWanted] and stops.
     */
    internal fun setWantedAggregateTiles(visible: Set<String>, ancestors: Set<String> = emptySet()) {
        if (operationRunner == null) return
        if (visible.isEmpty()) return
        val keep = HashSet<String>(visible.size + ancestors.size)
        keep.addAll(visible)
        keep.addAll(ancestors)
        val previous = wantedVisibleKeys
        wantedSpatialKeys = keep
        wantedVisibleKeys = HashSet(visible)
        if (previous != null) {
            for (spatial in previous) {
                if (spatial !in visible) {
                    Timeline.removePendingEncodedDownload(id, spatial)
                }
            }
        }
        for (spatial in visible) {
            if (isTileSeriesFinished(spatial)) {
                Timeline.removePendingEncodedDownload(id, spatial)
            } else {
                Timeline.addPendingEncodedDownload(id, spatial)
            }
        }
    }

    private fun isAggregateWanted(spatialKey: String): Boolean {
        val wanted = wantedSpatialKeys ?: return true
        return spatialKey in wanted
    }

    /** True when a wanted viewport tile has not yet folded the current series. */
    internal fun hasUnreadyWantedTiles(): Boolean {
        val visible = wantedVisibleKeys ?: return aggregateJobs.values.any { it.isActive }
        return visible.any { !isTileSeriesFinished(it) }
    }

    /** True when this tile has folded the series, or already tried and the server had nothing. */
    private fun isTileSeriesFinished(spatialKey: String): Boolean {
        if (isTileSeriesReady(spatialKey)) return true
        return aggregateCompleted[spatialKey] == currentSeriesId()
    }

    /** True when this tile has folded every interval in the current series. */
    private fun isTileSeriesReady(spatialKey: String): Boolean {
        val runner = operationRunner ?: return false
        val intervals = seriesIntervals()
        if (intervals.isEmpty()) return false
        val key = TimeSeriesAggregateRunner.TileKey(id, spatialKey)
        return intervals.all { runner.hasFolded(key, it.second) }
    }

    private fun releaseAggregateState(spatialKey: String) {
        operationRunner?.release(TimeSeriesAggregateRunner.TileKey(id, spatialKey))
        operationTiles.remove(spatialKey)
        aggregateRequested.remove(spatialKey)
        aggregateCompleted.remove(spatialKey)
        Timeline.removePendingEncodedDownload(id, spatialKey)
        Timeline.clearOperationTile(id, spatialKey)
    }

    private fun cancelAndReleaseAggregate(spatialKey: String) {
        aggregateJobs.remove(spatialKey)?.cancel()
        releaseAggregateState(spatialKey)
    }

    /**
     * Folds the given times oldest first — usually one chronological chunk, not the whole series.
     *
     * The runner still applies the fold interval by interval. Submitting in declared order with
     * nothing outstanding means its cursor never waits, its settle timeout never fires and no
     * arrival can land behind the fold position. The ordering machinery becomes inert rather than
     * load-bearing.
     *
     * A tile already bound has had its padded bytes moved to the native cache and its Java reference
     * nulled, so the buffer is restored from there before folding and handed back to the tile, which
     * is what lets the fold rewrite pixels the renderer will pick up on the next bind.
     */
    private fun foldAssembledSeries(key: TimeSeriesAggregateRunner.TileKey, spatialKey: String, times: List<Long>) {
        // This folds the intervals registered here, which is the set just decoded. A series change
        // evicts the tile's cached intervals first (see the reset branch above), so that set is the
        // whole series rather than only the intervals added by the change - without it the pass
        // restarted the accumulator partway and the running maximum dropped across the junction.
        val runner = operationRunner ?: return
        val byInterval = operationTiles[spatialKey] ?: return
        var folded = 0
        suppressFoldRebind.set(true)
        try {
        for (millis in times.sorted()) {
            val tile = byInterval[millis] ?: continue
            val encoded = tile.encodedData ?: continue
            val padded = encoded.paddedData
                ?: tileCache.nativeCache.getData("${tileCache.sourceID}${tile.coordHash}")?.also {
                    encoded.paddedData = it
                }
                ?: continue
            folded += runner.submit(key, millis, padded)
            if (runner.hasFolded(key, millis)) {
                tile.holdBindUntilFolded = false
            }
        }
        // JS EncodedTileSource.onTileLoaded backfills neighbors after every setData.
        // Android skipped fillEdge while HOLD and never ran it on the folded pixels, so
        // the pad still held each tile's own edge clone — a hard cut on a running max.
        if (folded > 0) {
            blendFoldedEdges(spatialKey, times)
            for (millis in times) {
                if (runner.hasFolded(key, millis)) {
                    rebindFoldedInterval(key, millis)
                }
            }
        }
        } finally {
            suppressFoldRebind.set(false)
        }
    }

    /**
     * Copies just-folded interval pixels into the native cache and drops the Java reference.
     *
     * Bind does the same move, but only after the renderer has a texture slot — too late for a
     * series still being assembled. After the fold has rewritten the buffer, nothing on the Java
     * heap still needs it: the next fold restore reads it back from native, and bind does too.
     */
    private fun promoteFoldedPixelsOffHeap(spatialKey: String, times: List<Long>) {
        val byInterval = operationTiles[spatialKey] ?: return
        for (millis in times) {
            val tile = byInterval[millis] ?: continue
            val encoded = tile.encodedData ?: continue
            val padded = encoded.paddedData ?: continue
            tileCache.nativeCache.putData("${tileCache.sourceID}${tile.coordHash}", padded)
            encoded.paddedData = null
        }
    }

    /**
     * Identity of the series this layer should currently be folding.
     *
     * Derived from the raw valid-time strings rather than parsed millis so it is cheap enough to ask
     * on every tile request, and so it changes exactly when the set of intervals changes - which is
     * what extending the timeline does.
     */
    private fun currentSeriesId(): Int = Timeline.validTimesList[layerId]?.hashCode() ?: 0

    /**
     * Chronologically sorted valid times this layer folds, as (request string, epoch millis).
     *
     * Only the times inside the timeline window. Metadata is fetched six hours wider on each side
     * (see [fetchMetadataOnce]), which gives ordinary layers neighbours to animate into at the
     * edges, but a fold must not take those in: a running maximum would start the window already
     * holding the previous evening, and a sum would add six hours that are not on the timeline.
     * MapsGL JS folds the window's own valid times.
     */
    private fun seriesIntervals(): List<Pair<String, Long>> {
        val times = Timeline.validTimesList[layerId]?.toList() ?: return emptyList()
        val window = foldWindowRange
        return foldWindow(parseSeriesIntervals(times), window?.first, window?.second)
    }

    private fun parseSeriesIntervals(times: List<String>): List<Pair<String, Long>> {
        return times.mapNotNull { iso ->
            val millis = try {
                OffsetDateTime.parse(iso).toInstant().toEpochMilli()
            } catch (e: DateTimeParseException) {
                MapsGLDebug.logW(TAG, "Unparseable valid time for aggregation: $iso", e)
                null
            }
            millis?.let { INTERVAL_WRAPPER_PREFIX + iso + INTERVAL_WRAPPER_SUFFIX to it }
        }.sortedBy { it.second }
    }

    /**
     * Requests everything a tile's aggregate needs, in chronological order.
     *
     * An aggregating layer cannot use the ordinary per-interval request path. That path asks for
     * intervals around the playhead, so scrubbing delivers them out of order, and an interval that
     * arrives before its predecessors has no slot in a running total. This declares the whole series to
     * the runner up front and then fetches it itself, oldest first, which is what MapsGL JS does when it
     * hands its worker a sorted interval list instead of letting the animation drive.
     *
     * Requests are chunked because the tile API accepts at most 25 dataset-intervals per call.
     * Each chunk is folded and promoted off the Java heap before the next is *decoded*, so a
     * 37-interval series never holds more than one chunk of decoded buffers at a time. The next
     * chunk's HTTP starts during that fold — only compressed bytes overlap.
     *
     * @return true when requests were issued; false when the series is unknown or already in flight.
     */
    internal suspend fun requestAggregateSeries(coord: TileCoord, currentDate: String): Boolean {
        val runner = operationRunner ?: return false
        val intervals = seriesIntervals()
        if (intervals.isEmpty()) return false

        val spatialKey = coord.hashShort()
        val times = intervals.map { it.second }
        val seriesId = currentSeriesId()

        // Claim this series for this tile. Losing the race, or finding the same series already claimed,
        // means the fetch is done or under way — the provider asks again on every pass and the whole
        // point of an aggregate is that it is fetched once.
        val key = TimeSeriesAggregateRunner.TileKey(id, spatialKey)
        val reset = runner.beginSeries(key, times)
        if (reset) {
            // The range moved, so anything still arriving belongs to the series just replaced.
            operationTiles.remove(spatialKey)
            // And the cached intervals hold folded pixels, which cannot be folded again. Drop them so
            // the requests below decode the whole series raw, the way the JS worker reloads every
            // chunk for an aggregate rather than topping up the intervals it is missing.
            tileCache.evictTileSeries(spatialKey)
            Timeline.recordOperationTile(id, spatialKey, seriesId, 0)
        } else {
            Timeline.recordOperationSeries(id, spatialKey, seriesId)
        }
        // Same prefix with extra later hours: fetch only what is not already folded. Re-requesting
        // the whole series at “now” is what dropped the running max.
        val toFetch = if (reset) {
            intervals
        } else {
            intervals.filter { !runner.hasFolded(key, it.second) }
        }
        if (toFetch.isEmpty()) {
            aggregateCompleted[spatialKey] = seriesId
            Timeline.removePendingEncodedDownload(id, spatialKey)
            return true
        }

        val perChunk = (25 / datasets.size.coerceAtLeast(1)).coerceAtLeast(1)
        // A short first strip decodes fast enough to put something on screen; later chunks
        // stay at the API max. The renderer now draws that prefix instead of waiting for now.
        val firstPaint = minOf(8, perChunk)
        val chunks = if (toFetch.size <= firstPaint) {
            listOf(toFetch)
        } else {
            listOf(toFetch.take(firstPaint)) + toFetch.drop(firstPaint).chunked(perChunk)
        }
        var holdingPermit = false
        val finished = try {
            supervisorScope {
                suspend fun fetchPacked(chunk: List<Pair<String, Long>>): Pair<ByteArray?, TileType?> {
                    val packedOut = AtomicReference<ByteArray?>(null)
                    val tileOut = AtomicReference<TileType?>(null)
                    withContext(OperationAggregateFetch(packedOut, tileOut)) {
                        requestTiles(
                            coord,
                            TileRequestOptions(reload = true, checkPending = false),
                            currentDate,
                            false,
                            chunk.map { it.first },
                            false,
                        )
                    }
                    return packedOut.get() to tileOut.get()
                }

                fun releaseChunkPending(chunk: List<Pair<String, Long>>, representative: TileType?) {
                    for (interval in chunk.map { it.first }) {
                        removeTrackedPendingInterval(coord, interval, false)
                    }
                    representative?.let { tileCache.setPending(false, it) }
                }

                var prefetch: Deferred<Pair<ByteArray?, TileType?>>? = null
                var prefetchChunk: List<Pair<String, Long>>? = null

                suspend fun awaitAndDropPrefetch() {
                    val job = prefetch ?: return
                    val heldChunk = prefetchChunk
                    prefetch = null
                    prefetchChunk = null
                    val result = try {
                        job.await()
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Throwable) {
                        null
                    }
                    if (heldChunk != null) {
                        releaseChunkPending(heldChunk, result?.second)
                    }
                }

                for ((index, chunk) in chunks.withIndex()) {
                    coroutineContext.ensureActive()
                    if (!isAggregateWanted(spatialKey)) {
                        awaitAndDropPrefetch()
                        releaseAggregateState(spatialKey)
                        return@supervisorScope false
                    }
                    aggregatePermits.acquire()
                    holdingPermit = true
                    Timeline.addPendingEncodedDownload(id, spatialKey)

                    val (packed, representative) = if (prefetch != null && prefetchChunk === chunk) {
                        val result = try {
                            prefetch!!.await()
                        } catch (e: CancellationException) {
                            throw e
                        } catch (_: Throwable) {
                            fetchPacked(chunk)
                        }
                        prefetch = null
                        prefetchChunk = null
                        result
                    } else {
                        if (prefetch != null) awaitAndDropPrefetch()
                        fetchPacked(chunk)
                    }

                    // Overlap the next chunk's HTTP with this fold. Decode waits for
                    // [aggregateDecodePermits] so two padded chunks never sit on the heap.
                    if (index < chunks.lastIndex && isAggregateWanted(spatialKey)) {
                        val next = chunks[index + 1]
                        prefetchChunk = next
                        prefetch = async { fetchPacked(next) }
                    }

                    aggregateDecodePermits.acquire()
                    try {
                        if (packed != null && representative != null) {
                            try {
                                onTileLoaded(representative, chunk.map { it.first }, 1, packed)
                            } finally {
                                for (interval in chunk.map { it.first }) {
                                    removeTrackedPendingInterval(coord, interval, false)
                                }
                            }
                        }
                        // Fold this prefix now so the just-decoded padded buffers can leave the Java heap
                        // before the next chunk is decoded. Waiting for the whole series pinned every
                        // interval at once (~1 MB each) and is what OOM'd decodeImageBytesToRgba at
                        // hourly zoom (XMAPSGLSDK-313). Oldest-first fetch keeps the fold chronological,
                        // which is the constraint the pulse bug actually needed — not "fold only once".
                        val chunkTimes = chunk.map { it.second }
                        foldAssembledSeries(key, spatialKey, chunkTimes)
                        Timeline.recordOperationFoldedCount(id, spatialKey, runner.foldedCount(key))
                        promoteFoldedPixelsOffHeap(spatialKey, chunkTimes)
                    } finally {
                        aggregateDecodePermits.release()
                    }

                    // Let a newly visible tile start its first chunk instead of waiting out the rest
                    // of this series. Memory is still one decoded chunk at a time.
                    if (index < chunks.lastIndex) {
                        aggregatePermits.release()
                        holdingPermit = false
                        yield()
                    }
                }

                awaitAndDropPrefetch()
                // Only after the last chunk: a mid-series flush can step the cursor past intervals
                // that are still in flight, and the next chunk then rebuilds from the junction —
                // a running max that drops at ~50% of a two-day hourly series (chunk size 25 of ~48).
                scheduleOperationFlush()
                true
            }
        } catch (e: Throwable) {
            // Let a failed fetch be retried on a later pass rather than leaving the tile blank forever.
            // Keep the pending key — this tile is not ready, so the load indicator stays.
            aggregateRequested.remove(spatialKey)
            throw e
        } finally {
            if (holdingPermit) aggregatePermits.release()
        }
        if (finished) {
            aggregateCompleted[spatialKey] = seriesId
            Timeline.removePendingEncodedDownload(id, spatialKey)
        }
        return finished
    }

    /** Drops retained aggregation pixels for one spatial coordinate. */
    internal fun releaseOperationTile(coord: TileCoord) {
        if (operationRunner == null) return
        cancelAndReleaseAggregate(coord.hashShort())
    }

    /**
     * Drops every retained aggregation pixel for this source. Call when the layer goes away or the
     * timeline range changes enough that the existing series is no longer the one being drawn.
     */
    internal fun clearOperationState() {
        Timeline.foldedSourceIds.remove(id)
        // Drop any queued tail flush first: it would otherwise fold into an accumulator that is about
        // to be discarded, and re-bind tiles that are on their way out.
        operationScope.coroutineContext[Job]?.cancelChildren()
        operationFlushScheduled.set(false)
        val pendingKeys = HashSet<String>()
        wantedSpatialKeys?.let { pendingKeys.addAll(it) }
        wantedVisibleKeys?.let { pendingKeys.addAll(it) }
        pendingKeys.addAll(aggregateRequested.keys)
        pendingKeys.addAll(aggregateCompleted.keys)
        pendingKeys.addAll(operationTiles.keys)
        for (spatial in pendingKeys) {
            Timeline.removePendingEncodedDownload(id, spatial)
        }
        aggregateJobs.clear()
        wantedSpatialKeys = null
        wantedVisibleKeys = null
        operationRunner?.clearSource(id)
        operationTiles.clear()
        aggregateRequested.clear()
        aggregateCompleted.clear()
        Timeline.clearOperationTiles(id)
    }

    private fun convertBitmapToByteArray(bitmap: Bitmap): ByteArray? {
        val byteBuffer = ByteBuffer.allocate(bitmap.byteCount)
        bitmap.copyPixelsToBuffer(byteBuffer)
        byteBuffer.rewind()
        //bitmap.recycle()
        return byteBuffer.array()
    }

    private fun moveBitmapToByteArray(bitmap: Bitmap): ByteArray {
        bitmap.copyPixelsToBuffer(DataPool.byteBuffer)
        DataPool.byteBuffer.rewind()
        //bitmap.recycle()
        return DataPool.byteBuffer.array()
    }


    /**
     * Backfills the edges of the tile with its neighbors' data and vice versa.
     * This mirrors the logic found in the JavaScript SDK for seamless tile stitching.
     *
     * @param imageBytes Packed encoded strip bytes for this request only. Prefer this over
     * [tile.data] so concurrent downloads for the same z/x/y cannot swap buffers mid-decode.
     */
    suspend fun onTileLoaded(
        tile: TileType,
        intervals: List<String>?,
        mode: Int,
        imageBytes: ByteArray? = null,
    ) {
        if (pr.ON) pr.p(
            TAG,
            pr.backfillEdge,
            "onTileLoaded() entered for  ${tile.coordHash}  }"
        )
        // 1. First, perform the standard loading logic (decoding, data chunking, etc.)
        // Note: If you renamed your original function to onTileLoadedOrig, call that first.
        // onTileLoadedOrig(tile, intervals, mode)

        Timeline.totalDownloads++

        // The last layer on this source was removed while the tile was downloading.
        if (isUnconsumed()) {
            tile.data = null
            tileCache.setPending(false, tile)
            return
        }

        isStale = tileCache.isStale(tile)
        if (isStale) {
            tileCache.setStale(false, tile)
            //trigger(DataSourceEvents.TileDiscard(sourceID = id, tile = tile))
            if (pr.ON) pr.p(TAG, pr.flicker, "onTileLoaded() begining, STALE: ${tile.coordHash}")
            return
        }

        // Stay pending until the decode below has produced pixels (or given up). For a
        // single-interval request the representative's hash is that interval's own pending key,
        // and clearing it here, before the decode suspends onto another dispatcher, let a wave
        // launched meanwhile see the interval as neither pending nor bindable and download it again.
        try {
            withContext(tileProcessingDispatcher) {
                val doEdgeBlending = true
                val rawBytes = imageBytes ?: (tile.data as? ByteArray)
                if (rawBytes == null || rawBytes.isEmpty()) {
                    // Cancelled / failed HTTP often leaves data null; the old non-null cast aborted the
                    // whole pan refresh job and left the new viewport empty during playback.
                    MapsGLDebug.logW(
                        TAG,
                        "onTileLoaded skipped ${tile.coordHash}: missing image bytes (cancelled or failed fetch)",
                    )
                    return@withContext
                }
                // Drop any shared pointer so later overlapping requests cannot see these bytes.
                tile.data = null
                if (weatherDebugMatches(tile.coord)) {
                    MapsGLDebug.trace("[WeatherDebug][Decode] begin key=${tile.coord.z}/${tile.coord.x}/${tile.coord.y} rawBytes=${rawBytes.size} intervals=${intervals?.size ?: 0}")
                }
                val tempMultiIntervalByteArray: ByteArray = if (DataPool.bigImageEnabled) {
                    val bitmap = parseTile(tile, rawBytes, null)
                    try {
                        moveBitmapToByteArray(bitmap)
                    } finally {
                        bitmap.recycle()
                    }
                } else {
                    tileCache.nativeCache.decodeImageBytesToRgba(rawBytes)
                        ?: run {
                            val bitmap = parseTile(tile, rawBytes, null)
                            try {
                                convertBitmapToByteArray(bitmap)
                                    ?: throw IllegalArgumentException("Invalid image data (bitmap decode)")
                            } finally {
                                bitmap.recycle()
                            }
                        }
                }
                if (weatherDebugMatches(tile.coord)) {
                    MapsGLDebug.trace("[WeatherDebug][Decode] rgba ready key=${tile.coord.z}/${tile.coord.x}/${tile.coord.y} bytes=${tempMultiIntervalByteArray.size}")
                }

                if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() intervals are null?: ${intervals == null}")

                if (intervals != null) {
                    // Make a list of missing intervals
                    val missingIntervalHash: HashMap<Int, String> = hashMapOf()
                    if ((tempMultiIntervalByteArray.size / intervals.size) != tileByteArraySize) {
                        for ((missingIndex, interval) in intervals.withIndex()) {
                            // if (!Timeline.sourceTimeHash[id]?.timeStrings?.contains(interval.substring(2,interval.length - 2))!!) // need to test this
                            if (!Timeline.validTimesList[layerId]!!.contains(interval.substring(2, interval.length - 2))) {
                                missingIntervalHash[missingIndex] = interval
                            }
                        }
                    }

                    val useNativeSplitPad =
                        missingIntervalHash.isEmpty() &&
                            intervals.isNotEmpty()

                    val stripBytes = DataPool.originalSize.toLong() * DataPool.originalSize * 4L
                    val expectedPackedBytes = intervals.size.toLong() * stripBytes
                    var packedForSplit = tempMultiIntervalByteArray
                    var intervalsForSplit = intervals
                    if (useNativeSplitPad &&
                        tempMultiIntervalByteArray.size.toLong() != expectedPackedBytes
                    ) {
                        val got = tempMultiIntervalByteArray.size.toLong()
                        when {
                            // Multi-strip body arrived with a single-interval request — take strip 0.
                            intervals.size == 1 && got > stripBytes && got % stripBytes == 0L -> {
                                packedForSplit = tempMultiIntervalByteArray.copyOfRange(0, stripBytes.toInt())
                            }
                            // Fewer strips than requested — accept what we have; mark the rest missing.
                            got > 0 && got % stripBytes == 0L && got < expectedPackedBytes -> {
                                val available = (got / stripBytes).toInt()
                                intervalsForSplit = intervals.take(available)
                                packedForSplit = tempMultiIntervalByteArray
                                MapsGLDebug.logW(
                                    TAG,
                                    "onTileLoaded partial pack ${tile.coordHash}: got $got expected $expectedPackedBytes; using $available/${intervals.size} strips",
                                )
                            }
                            else -> {
                                MapsGLDebug.logW(
                                    TAG,
                                    "onTileLoaded skipped $id tile=${tile.coordHash}: size mismatch " +
                                        "got $got expected $expectedPackedBytes",
                                )
                                return@withContext
                            }
                        }
                    }

                    val paddedStripsOrNull: Array<ByteArray>? = if (useNativeSplitPad) {
                        tileCache.nativeCache.splitAndPadEncodedTilesToByteArrays(
                            packedForSplit,
                            intervalsForSplit.size,
                            DataPool.originalSize,
                            padding,
                            isRadarEncodedSourceId(id),
                        ).also { strips ->
                            if (strips == null) {
                                MapsGLDebug.logW(
                                    TAG,
                                    "native split+pad returned null for $id tile=${tile.coordHash}",
                                )
                            }
                        }
                    } else {
                        null
                    }
                    val nativeSplitOk = paddedStripsOrNull != null

                    // ...or while it was decoding: nothing would ever bind these strips.
                    if (isUnconsumed()) return@withContext

                    val dataHash: HashMap<Int, ByteArray?> = hashMapOf()
                    var offset = 0
                    for ((i, interval) in intervalsForSplit.withIndex()) {
                        val newTile = Tile<DataType>(TileCoord(tile.coord.x, tile.coord.y, tile.coord.z, time = interval))
                        //if (pr.ON) pr.p(TAG, pr.validTimes, "   onTileLoaded() checking i:$i vs missingHash keys: ${missingIntervalHash.keys} " )
                        if (missingIntervalHash.containsKey(i)) {
                            if (pr.ON) pr.p(TAG, pr.tileReceived, "onTileLoaded() identified missing index $i, skipping", 2)
                            offset++
                        } else {
                            newTile.isEncoded = true
                            newTile.time = interval
                            newTile.state = TileState.Processing
                            if (nativeSplitOk) {
                                newTile.encodedData = EncodedData(
                                    byteArrayOf(),
                                    doEdgeBlending,
                                    padding,
                                    id,
                                    deferPadToNativePipeline = true,
                                )
                                newTile.encodedData!!.paddedData = paddedStripsOrNull!![i]
                            } else {
                                newTile.data = getByteArrayChunkWidth(
                                    packedForSplit,
                                    intervalsForSplit.size - missingIntervalHash.size,
                                    i - offset
                                )
                                dataHash[i - offset] = newTile.data as ByteArray
                            }
                            val nativeChunkReady =
                                nativeSplitOk && newTile.encodedData?.paddedData != null
                            val kotlinChunkReady = !nativeSplitOk && newTile.data != null
                            if (nativeChunkReady || kotlinChunkReady) {
                                if (!nativeSplitOk) {
                                    newTile.encodedData = encodePaddedViaNativeCache(
                                        newTile.data as ByteArray,
                                        newTile.coordHash,
                                        doEdgeBlending,
                                    )
                                    newTile.data = null
                                }
                                // Derive before blending: edge backfill copies pixels between neighbours,
                                // so both sides must already hold derived values or the seams carry raw
                                // rate/type/temperature bands into a derived tile.
                                applyTransformer(newTile)
                                // Accumulate from derived values, so the transform has to have run first.
                                val operationPixels = submitToOperation(newTile, interval)
                                if (operationPixels == OperationPixelState.DISCARD) {
                                    continue
                                }
                                if (operationPixels == OperationPixelState.HOLD) {
                                    // Keep the raw buffer for the chronological fold; do not upload it
                                    // and do not backfill neighbours from it.
                                    tileCache.updateTile(newTile)
                                    continue
                                }
                                if (doEdgeBlending) {
                                    val neighbors = newTile.coord.getNeighbors()
                                    neighbors.forEach { (quadrant, neighborCoord) ->

                                        // Normalize coordinates to handle world wraparound (x < 0 or x > max)
                                        val normalizedCoord = neighborCoord.normalize()

                                        // Check if the neighbor tile exists in our cache
                                        val neighborTile = tileCache[normalizedCoord]

                                        if (neighborTile?.encodedData?.paddedData == null) {
                                            if (pr.ON) pr.p(TAG, pr.edgeBlend, "onTileLoaded() neighbor paddedData is null")


                                            if (pr.ON) pr.p(
                                                TAG,
                                                pr.edgeBlend,
                                                " onTileLoaded() trying to GET: ${id}${tile.coordHash}"
                                            )
                                            neighborTile?.encodedData?.paddedData =
                                                tileCache.nativeCache.getData("${id}${neighborTile?.coordHash}")

                                            if (pr.ON) pr.p(
                                                TAG,
                                                pr.edgeBlend,
                                                "onTileLoaded()  found n padTile in cache? ${neighborTile?.encodedData?.paddedData != null}"
                                            )
                                        }

                                        if (neighborTile != null &&
                                            !neighborTile.holdBindUntilFolded &&
                                            neighborTile.encodedData?.paddedData != null
                                        ) {

                                            if (pr.ON) pr.p(
                                                TAG,
                                                pr.edgeBlend,
                                                "     onTileLoaded() quad:$quadrant  neighborCoord: $neighborCoord",
                                            )

                                            // Perform the bidirectional backfill
                                            fillEdge(newTile, neighborTile) //this one works?
                                            fillEdge(neighborTile, newTile) //does not work

                                            // Flag that textures need re-binding since pixels changed
                                            newTile.needsBind = true
                                            neighborTile.needsBind = true
                                            if (pr.ON) pr.p(
                                                TAG,
                                                pr.backfillEdge,
                                                "      onTileLoaded() t.needs: ${newTile.needsBind} n.needs: ${neighborTile.needsBind}"
                                            )

                                            publishQueryablePixels(neighborTile)
                                            tileCache.withBindListLock {
                                                if (!tileCache.bindList.contains(neighborTile.coordHash)) {
                                                    tileCache.bindList.add(neighborTile.coordHash)
                                                    tileCache.updateTile(neighborTile)
                                                    neighborTile.state = TileState.Ready
                                                }
                                            }
                                        } else {
                                            if (pr.ON) pr.p(
                                                TAG,
                                                pr.backfillEdge,
                                                "onTileLoaded() $quadrant null... ordinal ${quadrant.ordinal}"
                                            )
                                            if (quadrant == TileQuadrant.TopCenter) {
                                                //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padUP")
                                                paddingManager.padUp(newTile)
                                            } else if (quadrant == TileQuadrant.BottomCenter) {
                                                //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padDOWN")
                                                paddingManager.padDown(newTile)
                                            } else if (quadrant == TileQuadrant.MiddleLeft) {
                                                //if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padLEFT")
                                                paddingManager.padLeft(newTile)
                                            } else if (quadrant == TileQuadrant.MiddleRight) {
                                                // if (pr.ON) pr.p(TAG, pr.backfillEdge, "onTileLoaded() padRIGHT")
                                                paddingManager.padRight(newTile)
                                            }
                                            newTile.needsBind = true

                                        }
                                    }
                                }
                                newTile.needsBind = true
                                publishQueryablePixels(newTile)
                                tileCache.withBindListLock {
                                    if (!tileCache.bindList.contains(newTile.coordHash)) {
                                        tileCache.bindList.add(newTile.coordHash)
                                    }
                                }
                                tileCache.updateTile(newTile)
                                newTile.state = TileState.Ready
                                notifyEncodedTileReady(newTile.coord)

                            } else {
                            } // end if (nativeChunkReady || kotlinChunkReady)
                        }
                    }

                    // Account for missing intervals
                    for (key in missingIntervalHash.keys) {
                        if (pr.ON) pr.p(
                            TAG,
                            pr.validTimes2,
                            "onTileLoaded() at the end, need to construct data for  missing index $key  -   ${missingIntervalHash[key]}",
                            2
                        )
                        val newTile =
                            Tile<DataType>(TileCoord(tile.coord.x, tile.coord.y, tile.coord.z, time = intervals[key]))
                        newTile.isEncoded = true
                        newTile.time = intervals[key]
                        newTile.state = TileState.Processing

                        if (key != 0 && key != intervals.size - 1) { // blend if possible
                            if (pr.ON) pr.p(TAG, pr.validTimes2, "onTileLoaded() at the end, interval is not endpoint..", 2)
                            if (dataHash[key - 1] != null && dataHash[key + 1] != null) {
                                if (pr.ON) pr.p(
                                    TAG,
                                    pr.validTimes2,
                                    "onTileLoaded() found needed data for blending, sizes ${dataHash[key - 1]!!.size} and ${dataHash[key + 1]!!.size}: ",
                                    2
                                )
                                newTile.data = blendByteArrays(dataHash[key - 1]!!, dataHash[key + 1]!!)
                            }
                        } else if (key == 0) {
                            newTile.data = dataHash[1]
                        } else { //key at last interval
                            newTile.data = dataHash[key - 1]
                        }

                        try {
                            if (operationSpec != null) {
                                // A gap frame is a blend of neighbouring raw strips, not a fold.
                                continue
                            }
                            newTile.encodedData = encodePaddedViaNativeCache(
                                newTile.data as ByteArray,
                                newTile.coordHash,
                                doEdgeBlending,
                            )
                            if (doEdgeBlending) {
                                paddingManager.blendEdges(newTile, tileCache, 2)
                            }
                            // Same as the non-gap path above: without bindList, [bindTextures] never
                            // uploads these synthetic intervals and the layer freezes at the last
                            // fully-bound frame while the timeline clock keeps advancing (common on
                            // multi-day ranges that cross data holes).
                            newTile.needsBind = true
                            publishQueryablePixels(newTile)
                            tileCache.withBindListLock {
                                if (!tileCache.bindList.contains(newTile.coordHash)) {
                                    tileCache.bindList.add(newTile.coordHash)
                                }
                            }
                            tileCache.updateTile(newTile)
                            newTile.state = TileState.Ready
                            notifyEncodedTileReady(newTile.coord)
                            newTile.data = null
                        } catch (e: NullPointerException) {
                            MapsGLDebug.logE(
                                "XWeatherEncodedTileSource",
                                "onTileLoaded() newTile.data was null for ${newTile.coordHash}"
                            )
                        }

                    }

                    dataHash.clear()
                } // end intervls != null
                else { // intervals == null
                    if (pr.ON) pr.p(
                        TAG,
                        pr.backfillEdge,
                        "onTileLoaded() about to loop through intervals data, but intervals are null!!}"
                    )
                    tile.encodedData = encodePaddedViaNativeCache(
                        tempMultiIntervalByteArray,
                        tile.coordHash,
                        doEdgeBlending,
                    )
                    tile.state = TileState.Processing

                    if (doEdgeBlending) {
                        paddingManager.blendEdges(tile, tileCache, 3)
                    }
                    tile.data = null
                    tile.state = TileState.Ready
                    tile.needsBind = true
                    publishQueryablePixels(tile)
                    tileCache.withBindListLock {
                        if (!tileCache.bindList.contains(tile.coordHash)) {
                            tileCache.bindList.add(tile.coordHash)
                        }
                    }
                    tileCache.updateTile(tile)
                    notifyEncodedTileReady(tile.coord)

                    if (tileCache.pendingCount == 0 && _shouldTriggerLoadCompleteEvent) {
                        if (pr.ON) pr.p(TAG, pr.groupTrigger, "groupTrigger LoadComplete for id: $id")
                        ImageTileSource._apiEvent.value = RasterTileApiEvent.Reload(true) //this is needed
                        //trigger(DataSourceEvents.LoadComplete(sourceID = id))
                        //_shouldTriggerLoadCompleteEvent = false
                    }

                    if (tileCache.pendingCount == 0) {
                        if (pr.ON) {
                            pr.p(TAG, pr.downloadsDone, "tileCache.pendingCount: 0")
                        }
                    } else if (pr.ON) {
                        pr.p(TAG, pr.downloadsDone, "tileCache.pendingCount: ${tileCache.pendingCount}")
                    }
                }

                if (pr.ON) pr.p(TAG, pr.flicker, " onTileLoaded() B tileCache.bindlist.size: ${tileCache.bindList.size}")
            }
        } finally {
            if (pr.ON) pr.p(TAG, pr.flicker, "onTileLoaded() end, removing from _pending: ${tile.coordHash} ")
            tileCache.setPending(false, tile) // 'tile' here is the representative tile passed in
        }
    }

    /**
     * Handles the coordinate math and wrapping for a single edge backfill.
     * This version correctly handles Zoom 1 and world wraparound.
     */
    private fun fillEdge(destTile: TileType, sourceTile: TileType, replaceExisting: Boolean = false) {
        val destCoord = destTile.coord
        val sourceCoord = sourceTile.coord

        val initialDx = sourceCoord.x - destCoord.x
        val dy = sourceCoord.y - destCoord.y
        val dim = 1 shl destCoord.z

        // Case: Same tile (usually Zoom 0 world tile)
        if (initialDx == 0 && dy == 0) {
            if (destCoord.z == 0) {
                val destData = destTile.encodedData
                val sourceData = sourceTile.encodedData
                if (destData != null && sourceData != null) {
                    destData.backfillEdge(sourceData, -1, 0, replaceExisting)
                    destData.backfillEdge(sourceData, 1, 0, replaceExisting)
                }
            }
            return
        }

        val destData = destTile.encodedData ?: return
        val sourceData = sourceTile.encodedData ?: return

        // 1. Check Direct Neighbor (Distance must be 1)
        if (Math.abs(initialDx) <= 1 && Math.abs(dy) <= 1) {
            destData.backfillEdge(sourceData, initialDx, dy, replaceExisting)
        }

        // 2. Check Wraparound Neighbor (Distance must be dim - 1)
        // At Z=1, dim=2, so dim-1 is 1. This means the same tile is both
        // a direct neighbor and a wraparound neighbor.
        if (dim > 1 && Math.abs(dy) <= 1) {
            var wrapDx = initialDx

            if (initialDx == 1 - dim) {
                // Source is 0, Dest is 1 (Z=1) or Source is 0, Dest is Max
                wrapDx = 1
                destData.backfillEdge(sourceData, wrapDx, dy, replaceExisting)
                if (pr.ON) pr.p(TAG, pr.wrapFix, "Wraparound Right Edge applied")
            } else if (initialDx == dim - 1) {
                // Source is 1, Dest is 0 (Z=1) or Source is Max, Dest is 0
                wrapDx = -1
                destData.backfillEdge(sourceData, wrapDx, dy, replaceExisting)
                if (pr.ON) pr.p(TAG, pr.wrapFix, "Wraparound Left Edge applied")
            }
        }
    }

    /**
     * Pads one `originalSize`×`originalSize` RGBA strip in native and returns deferred [EncodedData] (no cache hop).
     */
    /**
     * Value labels read the native cache, which otherwise is filled only when a texture is uploaded.
     * A hidden data-query sample does not draw, so that upload can be skipped or fail and the number
     * never appears. Copy the decoded pixels as soon as the tile is ready to bind.
     */
    private fun publishQueryablePixels(tile: TileType) {
        if (!tileCache.publishPixelsForQuery) return
        val padded = tile.encodedData?.paddedData ?: return
        val key = "${tileCache.sourceID}${tile.coordHash}"
        tileCache.nativeCache.putData(key, padded)
    }

    private fun encodePaddedViaNativeCache(
        rgba: ByteArray,
        coordKeySuffix: String,
        doEdgeBlendingArg: Boolean,
    ): EncodedData {
        val expected = DataPool.originalSize * DataPool.originalSize * 4
        require(rgba.size == expected) {
            "encodePaddedViaNativeCache: expected $expected bytes, got ${rgba.size} (id=$id suffix=$coordKeySuffix)"
        }
        val padded = tileCache.nativeCache.padEncodedRgbaToPaddedByteArray(
            rgba,
            DataPool.originalSize,
            padding,
            isRadarEncodedSourceId(id),
        ) ?: error("native pad failed id=$id suffix=$coordKeySuffix")
        return EncodedData(
            byteArrayOf(),
            doEdgeBlendingArg,
            padding,
            id,
            deferPadToNativePipeline = true,
        ).also { it.paddedData = padded }
    }

    private fun getByteArrayChunkWidth(
        bitmapData: ByteArray,
        imageWidth: Int,
        chunkIndex: Int,
        bytesPerPixel: Int = 4
    ): ByteArray {

        val bytesPerRow = (imageWidth * 512) * bytesPerPixel

        val imageHeight = 512 // bitmapData.size / bytesPerRow
        val chunkWidth = 512

        val outputChunkBytesPerRow = chunkWidth * bytesPerPixel
        val outputChunkSize = outputChunkBytesPerRow * imageHeight
        val outputChunkData = ByteArray(outputChunkSize)

        // Calculate the starting X offset (in bytes) within each row for the desired chunk
        val chunkStartXOffsetBytes = chunkIndex * chunkWidth * bytesPerPixel

        // Copy the relevant segment from each row of the input data to the output data
        for (y in 0 until imageHeight) {
            // Start index of the current row in the input buffer
            val inputRowStartIndex = y * bytesPerRow
            // Start index of the segment to copy within the current input row
            val inputSegmentStartIndex = inputRowStartIndex + chunkStartXOffsetBytes
            // Start index of the current row in the output buffer
            val outputRowStartIndex = y * outputChunkBytesPerRow

            System.arraycopy(
                bitmapData,         // Source array
                inputSegmentStartIndex, // Start position in source
                outputChunkData,    // Destination array
                outputRowStartIndex,  // Start position in destination
                outputChunkBytesPerRow // Number of bytes to copy
            )
        }
        return outputChunkData
    }

    // Layers drawing from this source. A source outlives its layers (an app may register it once with
    // addSource and add and remove layers on it), so the last removal does not unregister it; it stops
    // the work nobody will draw and frees what that work holds (see [releaseUnconsumed]).
    private val consumerLayerIds: MutableSet<String> = java.util.concurrent.ConcurrentHashMap.newKeySet()
    @Volatile private var everConsumed = false

    override fun addConsumer(consumer: DataSourceConsumer) {
        consumerLayerIds.add(consumer.layerId)
        everConsumed = true
    }

    /**
     * Removes a consumer. When it was the last one, releases the source's downloads, decoded pixels
     * and fold state: with no layer left, a decoded tile is never bound, so its pixels would otherwise
     * stay on the Java heap (~1.1 MB per tile per interval) for the life of the map.
     * @param layerId Id of the layer whose consumer registration is dropped.
     */
    override fun removeConsumer(layerId: String) {
        if (!consumerLayerIds.remove(layerId)) return
        if (consumerLayerIds.isEmpty()) releaseUnconsumed()
    }

    /** True once every layer that used this source has been removed; late decodes are then dropped. */
    private fun isUnconsumed(): Boolean = everConsumed && consumerLayerIds.isEmpty()

    private fun releaseUnconsumed() {
        cancelInFlightHttpOutside(emptySet())
        clearOperationState()
        tileCache.releaseAll()
        Timeline.releasePendingEncodedDownloadsFor(id)
    }

    fun extractValidTimes(jsonString: String): List<String> {
        val validTimesList = mutableListOf<String>()

        try {
            // 1. Parse the top-level JSON array (e.g., [[...]])
            val topLevelArray = JSONArray(jsonString)

            // 2. Get the inner JSON array (e.g., [{...}, {...}, ...])
            //    We assume the structure always has the inner array at index 0.
            if (topLevelArray.length() > 0) {
                val innerArray = topLevelArray.getJSONArray(0)

                // 3. Get the first JSON object from the inner array
                //    We assume the validTimes are in the first object.
                if (innerArray.length() > 0) {
                    val firstObject: JSONObject = innerArray.getJSONObject(0)

                    // 4. Get the "validTimes" JSON array from the object
                    if (firstObject.has("validTimes")) { // Check if the key exists
                        val timesArray: JSONArray = firstObject.getJSONArray("validTimes")

                        // 5. Iterate through the times array and add strings to our list
                        for (i in 0 until timesArray.length()) {
                            val timeString: String = timesArray.getString(i)
                            validTimesList.add(timeString)
                        }
                    } else {
                        MapsGLDebug.trace("Warning: 'validTimes' key not found in the first object.")
                    }
                } else {
                    MapsGLDebug.trace("Warning: Inner array is empty.")
                }
            } else {
                MapsGLDebug.trace("Warning: Top-level array is empty.")
            }

        } catch (e: JSONException) {
            // Handle potential errors during JSON parsing (e.g., invalid format)
            MapsGLDebug.trace("Error parsing JSON string: ${e.message}")
            e.printStackTrace()
            // Return empty list on error
            return emptyList()
        }

        return validTimesList
    }

    private fun blendByteArrays(
        byteArray1: ByteArray,
        byteArray2: ByteArray,
        blendFactor: Float = 0.5f // Default to a 50% blend
    ): ByteArray {

        // 1. Input Validation
        if (byteArray1.size != byteArray2.size) {
            throw IllegalArgumentException(
                "Input byte arrays must have the same size. " +
                    "byteArray1 size: ${byteArray1.size}, byteArray2 size: ${byteArray2.size}"
            )
        }

        // Ensure blendFactor is within the valid range [0.0, 1.0]
        val clampedBlendFactor = blendFactor.coerceIn(0.0f, 1.0f)
        val baseFactor = 1.0f - clampedBlendFactor

        val size = byteArray1.size
        val result = ByteArray(size) // Create the output array

        // 2. Iterate and Blend Each Byte
        for (i in 0 until size) {
            // Get bytes and treat them as unsigned integers (0-255) for calculation
            val byte1Unsigned = byteArray1[i].toInt() and 0xFF
            val byte2Unsigned = byteArray2[i].toInt() and 0xFF

            // Perform linear interpolation using floating-point math
            val blendedValueFloat = (byte1Unsigned * baseFactor) + (byte2Unsigned * clampedBlendFactor)

            // Round, clamp to valid byte range (0-255), and convert back to Byte
            val blendedByteValue = blendedValueFloat
                .roundToInt()       // Round to nearest integer
                .coerceIn(0, 255) // Clamp to unsigned byte range
                .toByte()           // Convert back to signed Byte type

            result[i] = blendedByteValue
        }
        // 3. Return the Result
        return result
    }
}

typealias DataType = EncodedTimeSeriesData
