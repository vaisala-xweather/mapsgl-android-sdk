package com.xweather.mapsgl.sources

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.session.MediaSession
import com.xweather.mapsgl.Authenticator
import com.xweather.mapsgl.anim.TileRequestManager
import com.xweather.mapsgl.anim.TileRequestOptions
import com.xweather.mapsgl.coordinates.LatLonBounds
import com.xweather.mapsgl.events.EventDispatcher
import com.xweather.mapsgl.sources.ImageTileSource.Companion._apiEvent
import com.xweather.mapsgl.tiles.Tile
import com.xweather.mapsgl.tiles.TileCache
import com.xweather.mapsgl.tiles.TileCoord
import com.xweather.mapsgl.tiles.TileData
import com.xweather.mapsgl.tiles.TileState
import com.xweather.mapsgl.types.Headers
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.types.URLRequest
import com.xweather.mapsgl.utils.replaceVars
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL
import java.net.URLEncoder
import java.time.OffsetDateTime
import java.time.format.DateTimeFormatter
import java.time.format.DateTimeParseException
import java.util.Date
import kotlin.math.abs

typealias MetadataType = SourceMetadataSchema
typealias TileType = Tile<DataType>

/**
 * Base [DataSource] for **tiled** products: URL templates, zoom range, metadata, and a [TileRequestManager].
 *
 * Subtypes fetch raster PNGs, MVT bytes, or encoded grids. Layers use the shared tile cache and valid-time
 * metadata to request [Tile] instances for the current viewport and timeline.
 *
 * @param DataType Parsed tile payload (raster bitmap, encoded buffer, decoded features, …).
 */
abstract class TileSource<DataType : TileData> : DataSource {
    /** [com.xweather.mapsgl.map.MapController.mapSessionId] that owns in-flight / ready tile bookkeeping. */
    var ownerMapSessionId: Long = 0L

    lateinit var metadata: SourceMetadata<MetadataType>
    var tileSize: TileSize = TileSize(512)
    var minZoom = 0f
    var maxZoom = 21f
    var bounds: LatLonBounds? = null
    var tileURL: String? = null
    var metadataURL: String? = null
    open var tileManager: TileRequestManager<DataType> = TileRequestManager(this as TileSource<TileData>)

    private val inFlightHttpLock = Any()
    private val inFlightHttp = HashMap<String, MutableList<URLRequest>>()

    internal fun trackInFlightHttp(spatialKey: String, request: URLRequest) {
        synchronized(inFlightHttpLock) {
            inFlightHttp.getOrPut(spatialKey) { mutableListOf() }.add(request)
        }
    }

    internal fun untrackInFlightHttp(spatialKey: String, request: URLRequest) {
        synchronized(inFlightHttpLock) {
            val list = inFlightHttp[spatialKey] ?: return
            list.remove(request)
            if (list.isEmpty()) inFlightHttp.remove(spatialKey)
        }
    }

    /** Drops the in-flight transfer for one spatial tile (`hashShort()`). */
    internal fun cancelInFlightHttpFor(spatialKey: String) {
        val dropping = synchronized(inFlightHttpLock) {
            inFlightHttp.remove(spatialKey)?.toList().orEmpty()
        }
        dropping.forEach { it.cancel() }
    }

    /**
     * Stops downloads for tiles that are no longer in [keepSpatialKeys]. Keys are [TileCoord.hashShort].
     * Ancestors the camera is still using as a fallback belong in the keep set.
     */
    fun cancelInFlightHttpOutside(keepSpatialKeys: Set<String>) {
        val dropping = synchronized(inFlightHttpLock) {
            val keys = inFlightHttp.keys.filter { it !in keepSpatialKeys }
            keys.flatMap { key -> inFlightHttp.remove(key)?.toList().orEmpty() }
        }
        dropping.forEach { it.cancel() }
    }

    internal suspend fun <T> loadTrackedTile(
        coord: TileCoord,
        request: URLRequest,
        block: suspend () -> T,
    ): T {
        val key = coord.hashShort()
        trackInFlightHttp(key, request)
        try {
            return block()
        } finally {
            untrackInFlightHttp(key, request)
        }
    }
    var _shouldTriggerLoadCompleteEvent: Boolean = false
    abstract val tileCache: TileCache<com.xweather.mapsgl.sources.DataType>
    var metaDataNeeded: Int = 1
    val animTileList: MutableList<String> = mutableListOf()
    private var animTileCount: Int = 0
    override var isReady: Boolean = true
    var isLoading: Boolean = false
    open val isEncoded: Boolean = false
    open var datasets: List<DatasetType> = listOf()
    private val numericFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss")
    override val eventDispatcher = EventDispatcher()

    open fun contains(coord: TileCoord): Boolean {
        TODO("Not yet implemented")
    }

    fun onTileError(tile: TileType, error: Error) {
        tileCache.setPending(false, tile)
        tile.state = TileState.Failed
    }

    fun shouldRequestTile(tile: TileType, reload: Boolean): Boolean {
        if (tile.state == TileState.Initial) {
            return true
        } else {
            return false
        }
    }

    open fun getMetadataURL(): URL? {
        //No metadata for image tiles.
        return null
    }

    fun onLoadFailed() {
        println("$TAG onLoadFailed()")
        _apiEvent.value = RasterTileApiEvent.Error("failed to load")
    }

    fun addToAnimationQueue(inputString: String) {
        animTileList.add(inputString)
        animTileCount++
    }

    fun removeFromAnimationQueue(inputString: String) {
        animTileList.remove(inputString)
        animTileCount--
    }

    /**
     * Extra query parameters appended to every tile request from this source.
     *
     * MapsGL JS's `data.params`, which `WeatherLayerProvider` forwards from a layer's overrides into
     * the source configuration. On Android it is copied from the descriptor's `params` when the
     * source is added, for [com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor],
     * [com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor] and
     * [com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor]. For a weather layer, set it
     * in `addWeatherLayer`'s `configure` lambda:
     *
     * ```kotlin
     * mapController.addWeatherLayer(LayerCode.RADAR) { config ->
     *     val source = (config as? WeatherLayerConfiguration<*, *>)?.source
     *     (source as? EncodedSourceDescriptor)?.params = mapOf("model" to "hrrr")
     * }
     * ```
     *
     * Empty by default, and an empty map composes the exact URL it always did.
     */
    open var params: Map<String, String> = emptyMap()

    fun makeTileURL(coord: TileCoord, variables: Map<String, Any>?): URL {
        val vars = variables?.toMutableMap() ?: mutableMapOf()
        vars["x"] = coord.x
        vars["y"] = coord.y
        vars["z"] = coord.z
        vars["s"] = abs((coord.x + coord.y) % 4) + 1
        vars["width"] = tileSize.width
        vars["height"] = tileSize.height
        appendTileUrlVariables(coord, vars)

        val urlString = tileURL?.replaceVars(vars)
            ?: throw IllegalStateException("tileURL is null for source")

        return URL(appendParams(urlString))
    }

    /**
     * Appends [params] as query parameters to an already-composed URL.
     *
     * Joins with `&` when the template already carries a query string -- most MapsGL tile templates
     * do, since credentials arrive that way -- and with `?` otherwise. Keys and values are
     * URL-encoded, so a param value may contain `&`, `=` or spaces without corrupting the request.
     */
    protected fun appendParams(urlString: String): String {
        if (params.isEmpty()) return urlString
        val query = params.entries.joinToString("&") { (key, value) ->
            "${URLEncoder.encode(key, "UTF-8")}=${URLEncoder.encode(value, "UTF-8")}"
        }
        val separator = if (urlString.contains('?')) "&" else "?"
        return "$urlString$separator$query"
    }

    /**
     * Subclasses with an [com.xweather.mapsgl.weather.XweatherAuthenticator] merge credential template variables here.
     */
    protected open fun appendTileUrlVariables(coord: TileCoord, vars: MutableMap<String, Any>) = Unit

    abstract suspend fun requestTiles(
        coord: TileCoord,
        options: TileRequestOptions,
        currentDate: String,
        fromAnimation: Boolean,
        intervals: List<String>? = null,
        /** When false, skips [com.xweather.mapsgl.data.TileList.pendingList] and download progress UI. */
        trackDownloadProgress: Boolean = true,
    ): Any

    /** Returns the metadata for the source, which can be loaded from a remote source.
     *
     * Some data sources require additional metadata to be loaded before tiles can be requested,
     * such as additional information about the data, time information, min/max zoom levels, etc.
     * If the source does not require metadata, this method will return an empty object. */
    open suspend fun fetchMetadata(startDate: Date?, endDate: Date?): Result<Unit> {
        return Result.success(Unit)
    }

    suspend fun parseTile(tile: TileType, data: ByteArray, headers: Headers?): Bitmap {
        return withContext(Dispatchers.IO) {
            BitmapFactory.decodeByteArray(data, 0, data.size) ?: throw IllegalArgumentException("Invalid image data")
        }
    }

    open fun getTileData(coord: TileCoord): Any? {
        val tile = this.tileCache[coord];
        return tile?.data;
    }

    /** Used  by prepareTileRequest() to increment or decremnet the time
     * and reformate it for sources with time offets
     **/
    fun adjustDateBySeconds(dateString: String, offsetSeconds: Long): String? {
        return try {
            val offsetDateTime = OffsetDateTime.parse(dateString.substring(2, dateString.length - 2))
            val adjustedDateTime = offsetDateTime.plusSeconds(offsetSeconds)
            "[\"${adjustedDateTime.format(DateTimeFormatter.ISO_OFFSET_DATE_TIME)}\"]"
            //newTime = "[\"${newTime}\"]"
        } catch (e: Exception) {
            // Handle parsing exceptions (e.g., invalid date format)
            //println("Error parsing date string: ${e.message}")
            null
        }
    }

    /**
     * Plain ISO-8601 for URL path `{time}` segments (encoded tile GET).
     * Cache keys and POST `validTimes` still use bracketed `["…"]` strings.
     */
    fun intervalToIsoPathTime(intervalTime: String): String {
        val trimmed = intervalTime.trim()
        if (trimmed.startsWith("[\"") && trimmed.endsWith("\"]")) {
            return trimmed.substring(2, trimmed.length - 2)
        }
        if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
            return trimmed.removeSurrounding("[", "]").trim('"')
        }
        return trimmed
    }

    /** convert from [\"2025-04-22T03:49:31Z\"] to 20250422030000 **/
    fun intervalToURLTime(intervalTime: String): String {
        return "${intervalTime.substring(2, 6)}${intervalTime.substring(7, 9)}${
            intervalTime.substring(
                10,
                12
            )
        }${intervalTime.substring(13, 15)}0000"
    }

    /** Convert from  ["2025-03-26T14:00:00+00:00"] to 20250326140000 for Image Tiles**/
    private fun convertIsoStringToNumeric(isoString: String): String? {
        return try {
            // 1. Remove the square brackets and quotes:
            val cleanedString = isoString.removeSurrounding("[", "]").removeSurrounding("\"", "\"")
            // 2. Parse the ISO 8601 time string using OffsetDateTime:
            val offsetDateTime = OffsetDateTime.parse(cleanedString)
            // 3. Format the OffsetDateTime to the desired numeric format:
            offsetDateTime.format(numericFormatter)

        } catch (e: DateTimeParseException) {
            println("Error parsing ISO string '$isoString': ${e.message}")
            null // Or throw an exception or return a default value
        } catch (e: Exception) {
            println("Error: ${e.message}")
            null
        }
    }
}


val TileSource<DataType>.tileSize: TileSize
    get() = this.metadata.data.tileSize

val TileSource<DataType>.minZoom: Float
    get() = this.metadata.data.minZoom

val TileSource<DataType>.maxZoom: Float
    get() = this.metadata.data.maxZoom

val TileSource<DataType>.tiles: TileCache<DataType>
    get() = this.tileCache

val TileSource<DataType>.needsMetadata: Boolean
    get() = this.metadata.url != null && !this.metadata.hasLoaded

val TileSource<DataType>.isReady: Boolean
    get() = this.metaDataNeeded < 1 || this.metadata.hasLoaded


fun <DataType : TileData> TileSource<DataType>.init(id: String, authenticator: Authenticator<MediaSession.Token>?) {
    this.init(id, authenticator)
}

fun <DataType : TileData> TileSource<DataType>.contains(coord: TileCoord): Boolean {
    return this.tileCache.contains(coord)
}

fun <DataType : TileData> TileSource<DataType>.shouldRequestTile(tile: TileType, reload: Boolean): Boolean {

    val cachedTile = this.tileCache[tile.coord] ?: return true
    if (cachedTile.state == TileState.Initial || (cachedTile.state == TileState.Failed && reload)) {
        return true
    }
    return false
}