package com.xweather.mapsgl.sources.transformers

import com.xweather.mapsgl.weather.EncodedDataset
import kotlin.math.max
import kotlin.math.min

/**
 * Per-pixel transforms applied to a decoded encoded tile before it reaches the renderer.
 *
 * Some weather products are not served as their own dataset. They are derived on the client from a
 * pack of source datasets: the tile request asks for precipitation rate, precipitation type and
 * temperature, and a transformer rewrites those three bands into the single derived value the layer
 * actually draws. Sleet and ice accumulation work this way.
 *
 * A transformer runs once per interval strip, on the *padded* pixel data, before edge blending, so
 * neighbouring tiles blend already-derived values rather than raw source bands.
 *
 * Mirrors the MapsGL JS worker transformers. JS resolves a [TransformerId] against a static registry
 * inside the worker bundle rather than serializing a closure. [TileDataTransformers.forId] resolves
 * an id to its implementation.
 */
public enum class TransformerId {
    /** Derived sleet accumulation. See [SleetTransformer]. */
    SLEET,

    /** Derived ice accumulation. See [IceTransformer]. */
    ICE,
}

/**
 * Pixel data handed to a [TileDataTransformer].
 *
 * @property rawData Padded RGBA bytes for one interval, modified in place.
 * @property dimension Tile edge length in pixels, excluding padding.
 * @property padding Padding applied to each edge, so the real edge length is
 * `dimension + padding * 2`.
 */
public data class TileTransformData(
    val rawData: ByteArray,
    val dimension: Int,
    val padding: Int,
) {
    /** Edge length of [rawData] in pixels, padding included. */
    val paddedDimension: Int get() = dimension + padding * 2

    // Identity semantics: rawData is a mutable buffer, so structural equality would be misleading
    // and would also walk the whole tile on every comparison.
    override fun equals(other: Any?): Boolean = this === other

    override fun hashCode(): Int = System.identityHashCode(this)
}

/** Rewrites one interval's decoded pixels in place. */
public fun interface TileDataTransformer {
    /**
     * Rewrites [data] in place.
     *
     * @param data The padded RGBA bytes to transform.
     * @param datasets The datasets that were requested for the tile, in band order, so a
     * transformer can read each band's real-world range.
     */
    public fun transform(
        data: TileTransformData,
        datasets: List<EncodedDataset>,
    )
}

/** Resolves a [TransformerId] to its implementation. */
public object TileDataTransformers {
    /**
     * The transformer registered for [id].
     *
     * @param id Which derived product to transform into.
     * @return The shared transformer instance for [id].
     */
    public fun forId(id: TransformerId): TileDataTransformer =
        when (id) {
            TransformerId.SLEET -> SleetTransformer
            TransformerId.ICE -> IceTransformer
        }
}

/**
 * Shared shape of the derived-accumulation transformers.
 *
 * Input bands are `R` = precipitation rate, `G` = precipitation type, `B` = temperature. The output
 * is a single accumulation value spread across `RGB` so the sample renderer recovers roughly 10 bits
 * of precision from three 8-bit bands, with `A` pinned to 255.
 *
 * The alpha channel is deliberately not used to carry data. That matches JS, where writing data into
 * alpha perturbs the RGB values on some browsers, and it keeps the encoding identical across
 * platforms for shared layer configurations.
 */
private inline fun transformAccumulation(
    data: TileTransformData,
    datasets: List<EncodedDataset>,
    accumulate: (precipMMPerHour: Double, tempC: Double, precipType: Int) -> Double,
) {
    val dim = data.paddedDimension
    val pixels = dim * dim
    val raw = data.rawData
    if (raw.size < pixels * 4) return
    if (datasets.size < 3) return

    // Band 0 carries the rate; its maximum defines both the input and the output scale, so a derived
    // value re-encodes into the same range the layer's drawRange and colorscale are expressed in.
    val rateMax = datasets[0].dataRange.endInclusive
    val tempMin = datasets[2].dataRange.start
    val tempMax = datasets[2].dataRange.endInclusive
    if (rateMax <= 0.0) return

    for (i in 0 until pixels) {
        val offset = i * 4
        val r = raw[offset].toInt() and 0xFF
        val g = raw[offset + 1].toInt() and 0xFF
        val b = raw[offset + 2].toInt() and 0xFF

        val precipMMRate = rateMax * (r / 255.0)
        // The models express rate in mm/sec; the accumulation formulas are defined per hour.
        val precipMMPerHour = precipMMRate * 3600.0
        val tempC = tempMin + (tempMax - tempMin) * (b / 255.0)

        // Back to mm/sec, then normalised against the same range the source was encoded in.
        var value = accumulate(precipMMPerHour, tempC, g) / 3600.0
        value /= rateMax
        value = min(max(value, 0.0), 1.0)

        // Spread across three bands: each holds up to 255, the next takes the remainder.
        var remaining = (value * 3 * 255).toInt()
        for (band in 0 until 3) {
            val bandValue = min(255, remaining)
            raw[offset + band] = bandValue.toByte()
            remaining -= bandValue
        }
        raw[offset + 3] = 255.toByte()
    }
}

/** Precipitation type codes used by the derived accumulation transformers. */
private object PrecipType {
    const val FREEZING_RAIN = 3
    const val MIXED_ICE = 4
    const val ICE_PELLETS = 8
    const val FREEZING_DRIZZLE = 12
}

/**
 * Temperature weighting shared by both accumulation models.
 *
 * Accumulation is at full rate at or below [MIN_TEMP_C] and tapers to zero at [MAX_TEMP_C]; the
 * caller decides what happens outside that window.
 */
private const val MIN_TEMP_C = -4.0
private const val MAX_TEMP_C = 2.0

private fun temperatureFactor(tempC: Double): Double =
    when {
        tempC >= 0 && tempC <= MAX_TEMP_C -> 1 - (tempC / MAX_TEMP_C)
        tempC < 0 && tempC >= MIN_TEMP_C -> min(max(1 + (tempC / -MIN_TEMP_C), 0.0), 1.0)
        else -> 1.0
    }

/**
 * Derives sleet accumulation from precipitation rate, type and surface temperature, using a
 * simplified FRAM (Forecasting Rain and Accumulation Model) approach.
 *
 * Only ice-pellet precipitation contributes. Note that sleet, unlike [IceTransformer], accumulates at
 * full rate outside the temperature window rather than being cut off — pellets that have already
 * frozen aloft still land.
 */
public object SleetTransformer : TileDataTransformer {
    override fun transform(
        data: TileTransformData,
        datasets: List<EncodedDataset>,
    ) {
        transformAccumulation(data, datasets) { precipMMPerHour, tempC, precipType ->
            if (precipType != PrecipType.ICE_PELLETS || precipMMPerHour <= 0) {
                0.0
            } else {
                precipMMPerHour * temperatureFactor(tempC)
            }
        }
    }
}

/**
 * Derives ice accumulation from precipitation rate, type and surface temperature, using a simplified
 * FRAM (Forecasting Rain and Accumulation Model) approach.
 *
 * Freezing rain, mixed ice and freezing drizzle contribute. Outside the -4 °C to 2 °C window nothing
 * accumulates: too warm and it runs off, too cold and it falls as pellets rather than glazing.
 */
public object IceTransformer : TileDataTransformer {
    override fun transform(
        data: TileTransformData,
        datasets: List<EncodedDataset>,
    ) {
        transformAccumulation(data, datasets) { precipMMPerHour, tempC, precipType ->
            val isIceType =
                precipType == PrecipType.FREEZING_RAIN ||
                    precipType == PrecipType.MIXED_ICE ||
                    precipType == PrecipType.FREEZING_DRIZZLE
            when {
                !isIceType || precipMMPerHour <= 0 -> 0.0
                tempC > MAX_TEMP_C || tempC < MIN_TEMP_C -> 0.0
                else -> precipMMPerHour * temperatureFactor(tempC)
            }
        }
    }
}
