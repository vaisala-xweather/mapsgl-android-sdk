package com.xweather.mapsgl.sources

import com.xweather.mapsgl.map.mapbox.VectorPolygonFillTriangulator

/** Parse modes a mesh fingerprint can be computed in. */
internal const val MESH_MODE_RAW = "raw"
internal const val MESH_MODE_FEAT = "feat"

/**
 * Stable mesh-cache fingerprint + mode tag for [VectorData], including after CPU geometry was
 * released (iOS consume-after-upload). Callers must invoke this before dropping Features so the
 * first computation is remembered.
 *
 * "Stable" means the answer identifies the tile's **content**, not how that content currently
 * happens to be stored. The distinction matters because a tile can carry both a raw and a feature
 * fingerprint: it is parsed raw first, and re-parsed into Features as soon as a consumer needs them,
 * which is exactly what setting a layer filter triggers. Its CPU geometry is then released and
 * restored repeatedly as meshes are uploaded and re-requested.
 *
 * The released branch used to prefer the raw memo whenever one existed. A tile that had since moved
 * to feature mode therefore answered `feat` while its Features were resident and `raw` once they
 * were released — two fingerprints for one unchanged tile, alternating frame to frame. Every mesh
 * cache lookup missed, so the tile re-parsed and re-triangulated forever, and a mesh stored under
 * one of the two keys was never the key the next frame asked for. That is what left a layer's
 * previous geometry on screen when a filter excluded everything in view (XMAPSGLSDK-319): the empty
 * mesh was cached, just never found again.
 *
 * [VectorData.rememberedMeshMode] fixes which memo the released branch reads, so release and restore
 * no longer change the answer.
 */
internal fun VectorData.meshModeFingerprint(sourceLayer: String?): Pair<Int, String> {
    // A fingerprint, once taken, holds for the life of this data. Released geometry is restored by
    // re-parsing the same tile bytes, and the restored Features hash differently from the first parse
    // even though the tile is unchanged. Recomputing then changed the mesh key at every pan or zoom
    // end: each tile missed its cached mesh, re-triangulated, and blinked out until it finished.
    val raw = rawFeatures
    if (raw != null) {
        val fp = rememberedRawFingerprint()
            ?: VectorPolygonFillTriangulator.meshCacheFingerprintRaw(raw, validTime.time)
        rememberRawFingerprint(fp)
        rememberMeshMode(MESH_MODE_RAW)
        return fp to MESH_MODE_RAW
    }
    if (hasCpuGeometry()) {
        val fp = rememberedFeatFingerprint(sourceLayer)
            ?: VectorPolygonFillTriangulator.meshCacheFingerprint(features, validTime.time, sourceLayer)
        rememberFeatFingerprint(sourceLayer, fp)
        rememberMeshMode(MESH_MODE_FEAT)
        return fp to MESH_MODE_FEAT
    }
    if (cpuGeometryReleased) {
        // The mode the tile was last actually in decides, not whichever memo is non-null. Falling
        // back to "whatever exists" is only for a tile released before it ever reported a mode.
        val preferred = when (rememberedMeshMode()) {
            MESH_MODE_FEAT -> rememberedFeatFingerprint(sourceLayer)?.let { it to MESH_MODE_FEAT }
            MESH_MODE_RAW -> rememberedRawFingerprint()?.let { it to MESH_MODE_RAW }
            else -> null
        }
        if (preferred != null) return preferred
        rememberedRawFingerprint()?.let { return it to MESH_MODE_RAW }
        rememberedFeatFingerprint(sourceLayer)?.let { return it to MESH_MODE_FEAT }
    }
    val fp = VectorPolygonFillTriangulator.meshCacheFingerprint(features, validTime.time, sourceLayer)
    return fp to MESH_MODE_FEAT
}

/** Retain CPU Features while [block] triangulates. Does not consume — sibling consumers may still need them. */
internal inline fun <T> VectorData.withGpuUpload(block: () -> T): T {
    val tracked = hasCpuGeometry()
    if (tracked) beginGpuUpload()
    try {
        return block()
    } finally {
        if (tracked) endGpuUploadAndMaybeRelease()
    }
}

internal fun VectorData.markLayerMeshReady(vts: VectorTileSource, layerId: String?) {
    if (layerId.isNullOrEmpty()) return
    noteLayerMeshReady(layerId, vts.glMeshConsumerLayerIds())
}
