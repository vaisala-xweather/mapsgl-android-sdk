package com.xweather.mapsgl.sources

import com.xweather.mapsgl.map.mapbox.VectorPolygonFillTriangulator

/**
 * Stable mesh-cache fingerprint + mode tag for [VectorData], including after CPU geometry was
 * released (iOS consume-after-upload). Callers must invoke this before dropping Features so the
 * first computation is remembered.
 */
internal fun VectorData.meshModeFingerprint(sourceLayer: String?): Pair<Int, String> {
    val raw = rawFeatures
    if (raw != null) {
        val fp = VectorPolygonFillTriangulator.meshCacheFingerprintRaw(raw, validTime.time)
        rememberRawFingerprint(fp)
        return fp to "raw"
    }
    if (hasCpuGeometry()) {
        val fp = VectorPolygonFillTriangulator.meshCacheFingerprint(features, validTime.time, sourceLayer)
        rememberFeatFingerprint(sourceLayer, fp)
        return fp to "feat"
    }
    if (cpuGeometryReleased) {
        rememberedRawFingerprint()?.let { return it to "raw" }
        val stored = rememberedFeatFingerprint(sourceLayer)
        if (stored != null) return stored to "feat"
    }
    val fp = VectorPolygonFillTriangulator.meshCacheFingerprint(features, validTime.time, sourceLayer)
    return fp to "feat"
}

/** Retain CPU Features while [block] triangulates. Does not consume — sibling consumers may still need them. */
internal inline fun <T> VectorData.withGpuUpload(block: () -> T): T {
    val tracked = hasCpuGeometry()
    if (tracked) beginGpuUpload()
    try {
        return block()
    } finally {
        if (tracked) endGpuUploadAndMaybeRelease()
    }
}

internal fun VectorData.markLayerMeshReady(vts: VectorTileSource, layerId: String?) {
    if (layerId.isNullOrEmpty()) return
    noteLayerMeshReady(layerId, vts.glMeshConsumerLayerIds())
}
