package com.xweather.mapsgl.sources

import com.xweather.mapsgl.anim.Timeline
import com.xweather.mapsgl.data.series.TimeInterval
import com.xweather.mapsgl.data.series.VectorTimeSeriesData
import com.xweather.mapsgl.utils.parseDateArrayFromString

/**
 * Epoch millis for global timeline phase [phaseIndex].
 * Vector tile interval keys use [java.util.Date.getTime] (ms); [Timeline.timeLongs] stores seconds.
 */
fun timelinePhaseEpochMillis(phaseIndex: Int): Long? {
    if (phaseIndex < 0) return null
    Timeline.timeDates.getOrNull(phaseIndex)?.time?.let { return it }
    val timeString = Timeline.timeStrings.getOrNull(phaseIndex) ?: return null
    return runCatching { parseDateArrayFromString(timeString).first().time }.getOrNull()
}

/** Intervals to prefetch around the active playback phase pair (epoch ms). */
fun timelinePlaybackPrefetchEpochMillis(lookBehind: Int = 2, lookAhead: Int = 10): List<Long> {
    val count = Timeline.timeStrings.size
    if (count == 0) return emptyList()
    val phaseA = Timeline.currentPhaseA.coerceIn(0, count - 1)
    val phaseB = Timeline.currentPhaseB.coerceIn(0, count - 1)
    val start = (minOf(phaseA, phaseB) - lookBehind).coerceAtLeast(0)
    val end = (maxOf(phaseA, phaseB) + lookAhead).coerceAtMost(count - 1)
    return (start..end).mapNotNull { timelinePhaseEpochMillis(it) }.distinct()
}

/**
 * Resolves the [VectorData] to draw or query from tile cache data that may be a static
 * [VectorData] or a [VectorTimeSeriesData] container (MapsGL JS `resolveVectorTileData`).
 */
fun resolveVectorTileData(
    tileData: Any?,
    interval: TimeInterval?,
    exactInterval: Boolean = true,
): VectorData? {
    if (tileData == null) return null
    if (tileData is VectorData) return tileData
    if (tileData is VectorTimeSeriesData) {
        if (interval != null) {
            return if (exactInterval) {
                tileData.getData(interval)
            } else {
                tileData.getData(interval) ?: tileData.getDataClosestToInterval(interval)
            }
        }
        if (exactInterval) return null
        val intervals = tileData.validIntervals
        return if (intervals.isNotEmpty()) tileData.getData(intervals.first()) else null
    }
    return null
}
