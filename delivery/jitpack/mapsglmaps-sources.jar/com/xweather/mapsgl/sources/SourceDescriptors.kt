package com.xweather.mapsgl.sources

/**
 * Public entry types for configuring tile/geo sources passed to
 * [com.xweather.mapsgl.map.MapController.addSource].
 *
 * Canonical definitions live in [com.xweather.mapsgl.sources.source.spec]; these typealiases
 * let host apps import everything from `com.xweather.mapsgl.sources` if preferred.
 *
 * For vector sources added with [VectorSourceDescriptor], cast the result of
 * [com.xweather.mapsgl.map.MapController.getSource] to [VectorTileSource] to adjust
 * [com.xweather.mapsgl.sources.TileSource.tileURL], zoom bounds, or call [VectorTileSource.invalidate].
 *
 * For GeoJSON sources added with [GeoJSONSourceDescriptor], cast [com.xweather.mapsgl.map.MapController.getSource]
 * to [GeoJSONSource] to set [GeoJSONSource.url], [GeoJSONSource.data], or call [GeoJSONSource.invalidate].
 */
typealias SourceDescriptor = com.xweather.mapsgl.sources.source.spec.SourceDescriptor

typealias ImageSourceDescriptor = com.xweather.mapsgl.sources.source.spec.ImageSourceDescriptor

typealias EncodedSourceDescriptor = com.xweather.mapsgl.sources.source.spec.EncodedSourceDescriptor

typealias XweatherEncodedSourceDescriptor = com.xweather.mapsgl.sources.source.spec.XweatherEncodedSourceDescriptor

typealias VectorSourceDescriptor = com.xweather.mapsgl.sources.source.spec.VectorSourceDescriptor

typealias GeoJSONSourceDescriptor = com.xweather.mapsgl.sources.source.spec.GeoJSONSourceDescriptor
