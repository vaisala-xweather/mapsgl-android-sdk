package com.xweather.mapsgl.sources.source.spec

import com.mapbox.geojson.FeatureCollection
import com.xweather.mapsgl.weather.XweatherAuthenticator
import com.xweather.mapsgl.coordinates.LatLonBounds
import com.xweather.mapsgl.types.DataSourceKind
import com.xweather.mapsgl.types.TileSize
import com.xweather.mapsgl.data.series.TimeSeriesOperationSpec
import com.xweather.mapsgl.sources.transformers.TransformerId
import com.xweather.mapsgl.weather.EncodedDataset

/**
 * Declarative configuration for a data source before it is registered on a [com.xweather.mapsgl.map.MapController].
 *
 * Implementations describe tile URLs, metadata, bounds, and optional authentication. The controller’s
 * [com.xweather.mapsgl.map.MapController.addSource] turns a descriptor into a live
 * [com.xweather.mapsgl.sources.DataSource].
 *
 * @property id Stable id used as the Mapbox style source id and MapsGL registry key.
 * @property kind Discriminator matching [com.xweather.mapsgl.sources.DataSource.kind] after registration.
 *
 * @see com.xweather.mapsgl.map.MapController.addSource
 */
interface SourceDescriptor {
    val id: String
    val kind: DataSourceKind
}

/** @deprecated Use [SourceDescriptor.kind] instead. */
val SourceDescriptor.type: DataSourceKind
    @Deprecated("Use `kind` instead.")
    get() = kind

/**
 * Raster or image-tile source (PNG/JPEG tiles, satellite, etc.).
 *
 * @property url Tile URL template with `{z}`, `{x}`, `{y}` and optional time/subdomain tokens per product docs.
 * @property metadataUrl Endpoint for tile metadata / valid times when applicable.
 * @property minZoom Lowest zoom level served (optional).
 * @property maxZoom Highest zoom level served (optional).
 * @property bounds Geographic limits for the source, if any.
 * @property tileSize Logical tile size in px (often 256 or 512).
 * @property attribution Attribution string for the map.
 * @property authenticator Optional per-source signing; when null, [com.xweather.mapsgl.map.MapController] may apply
 *   the shared [com.xweather.mapsgl.weather.WeatherService.authenticator].
 */
data class ImageSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.RASTER

    // Declared in the class body rather than the primary constructor, the rule from XMAPSGLSDK-285:
    // a new constructor parameter on a published data class changes the generated constructor, its
    // default bridge, `copy` and `componentN`.
    /**
     * Extra query parameters appended to every tile request from this source.
     *
     * MapsGL JS's `data.params`. Empty by default, so a descriptor that does not set it composes
     * exactly the URL it always did.
     */
    var params: Map<String, String> = emptyMap()
}

/**
 * MapsGL **encoded** grid source (multi-band numeric tiles consumed by sample/contour/particle layers).
 *
 * @property datasets Band definitions and decoding hints; required for encoded pipelines.
 *
 * Other fields match [ImageSourceDescriptor] semantics for URLs, zoom, bounds, and auth.
 *
 * @see com.xweather.mapsgl.sources.EncodedTileSource
 */
data class EncodedSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
    var datasets: List<EncodedDataset>? = null
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.ENCODED

    // Declared in the class body rather than the primary constructor, the rule from XMAPSGLSDK-285:
    // a new constructor parameter on a published data class changes the generated constructor, its
    // default bridge, `copy` and `componentN`.
    /**
     * Extra query parameters appended to every tile request from this source.
     *
     * MapsGL JS's `data.params`. Empty by default, so a descriptor that does not set it composes
     * exactly the URL it always did.
     */
    var params: Map<String, String> = emptyMap()

    // Declared in the class body rather than the primary constructor on purpose. This is a data class
    // in a minified, published artifact, so a new constructor parameter would change the generated
    // constructor and its synthetic default bridge, change the `copy` signatures and add a
    // `component10` — each a `NoSuchMethodError` for an app linking an older AAR without recompiling.
    /**
     * Client-side transform applied to each decoded tile before it is rendered, for products that are
     * derived from a pack of source datasets rather than served directly. Null for ordinary sources.
     *
     * Not part of data-class equality: two descriptors for the same datasets are the same source
     * regardless of how they are post-processed, and a data-class `copy()` does not carry it over.
     */
    var transformerId: TransformerId? = null

    /**
     * Folds this source's intervals into a running aggregate instead of drawing them individually —
     * accumulation and period max/min layers. Null for an ordinary source, which is the common case.
     *
     * In the class body for the same binary-compatibility reason as [transformerId].
     *
     * A source carrying an operation must not be shared with a layer that wants the raw intervals:
     * the fold rewrites the decoded pixels in place, so both layers would draw the aggregate. Give the
     * aggregated layer its own source id.
     */
    internal var operation: TimeSeriesOperationSpec? = null
}

/**
 * Legacy Aeris-style encoded source kind; same shape as [EncodedSourceDescriptor] with nullable fields.
 *
 * Prefer [EncodedSourceDescriptor] for new code unless a product still reports [DataSourceKind.AERIS_ENCODED].
 */
data class XweatherEncodedSourceDescriptor(
    override val id: String,
    var url: String?,
    var metadataUrl: String?,
    var minZoom: Float?,
    var maxZoom: Float?,
    var bounds: LatLonBounds?,
    var tileSize: TileSize?,
    var attribution: String?,
    var authenticator: XweatherAuthenticator?,
    var datasets: List<EncodedDataset>?
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.AERIS_ENCODED

    // Declared in the class body rather than the primary constructor, the rule from XMAPSGLSDK-285:
    // a new constructor parameter on a published data class changes the generated constructor, its
    // default bridge, `copy` and `componentN`.
    /**
     * Extra query parameters for requests from this source (MapsGL JS's `data.params`).
     *
     * Currently not applied: [com.xweather.mapsgl.map.MapController.addSource] does not read this
     * property, so setting it has no effect.
     */
    var params: Map<String, String> = emptyMap()
}

/**
 * @param url Tile URL template. Always includes `{z}`, `{x}`, `{y}`; `{s}` is a subdomain index (1–4), see [com.xweather.mapsgl.sources.TileSource.makeTileURL].
 * If [authenticator] is an [com.xweather.mapsgl.weather.XweatherAuthenticator] (for example [com.xweather.mapsgl.weather.WeatherService.authenticator]),
 * these placeholders are also merged each request: `{accessKey}` (client id + `_` + secret), `{clientId}`, `{clientSecret}`,
 * and the documentation segment `[CLIENT_ID]_[CLIENT_SECRET]`.
 * When [authenticator] is null, [com.xweather.mapsgl.map.MapController.addSource] uses the controller's
 * [com.xweather.mapsgl.weather.WeatherService.authenticator] automatically.
 *
 * **Time in the path (Aeris / AMP-style vector tiles):** use a `{time::…}` token so each tile request uses
 * [com.xweather.mapsgl.sources.VectorTileSource.validTime] (driven by the map timeline), the same pattern as
 * `WeatherService.vectorTileURLPathTemplate` (`/{accessKey}/{code}/{z}/{x}/{y}/{time::utc:format[yyyyMMddhhmm00]}.pbf`).
 * That expands to a **14-digit** UTC offset (`yyyyMMddHHmm` plus a literal `00` suffix from the format string).
 * A hand-written **12-digit** segment (e.g. `202603061110`) is usually not the same offset the API expects and often yields
 * `missing_resource_error`. Use `…/0.pbf` only when the product docs say that offset selects the correct tiles.
 */
data class VectorSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.VECTOR

    // Declared in the class body rather than the primary constructor, the rule from XMAPSGLSDK-285:
    // a new constructor parameter on a published data class changes the generated constructor, its
    // default bridge, `copy` and `componentN`.
    /**
     * Extra query parameters appended to every tile request from this source.
     *
     * MapsGL JS's `data.params`. Empty by default, so a descriptor that does not set it composes
     * exactly the URL it always did.
     */
    var params: Map<String, String> = emptyMap()
}

/**
 * Configuration for a GeoJSON-backed source. At runtime, [com.xweather.mapsgl.map.MapController.addSource]
 * creates a [com.xweather.mapsgl.sources.GeoJSONSource]; use [com.xweather.mapsgl.map.MapController.getSource] and cast
 * to that type to set [com.xweather.mapsgl.sources.GeoJSONSource.data] or adjust [com.xweather.mapsgl.sources.GeoJSONSource.url]
 * after registration.
 *
 * **Provide GeoJSON in one of four ways:**
 * 1. [data] — inline features assigned on the descriptor before [com.xweather.mapsgl.map.MapController.addSource].
 * 2. [bundledAssetPath] — path under the host app's `src/main/assets/` (loaded on [com.xweather.mapsgl.map.MapController.addSource]).
 * 3. Assign [com.xweather.mapsgl.sources.GeoJSONSource.data] after addSource (inline JSON via [com.mapbox.geojson.FeatureCollection.fromJson],
 *    or an asset path via [com.xweather.mapsgl.sources.GeoJSONSource.parseJsonOrAsset]).
 * 4. [url] — remote GeoJSON endpoint template.
 */
data class GeoJSONSourceDescriptor(
    override val id: String,
    var url: String? = null,
    var metadataUrl: String? = null,
    var minZoom: Float? = null,
    var maxZoom: Float? = null,
    var bounds: LatLonBounds? = null,
    var tileSize: TileSize? = null,
    var attribution: String? = null,
    var authenticator: XweatherAuthenticator? = null,
    /**
     * Optional Android asset path packaged under `src/main/assets/` (app or MapsGL SDK AAR).
     * When set, [com.xweather.mapsgl.map.MapController.addSource] loads the GeoJSON into
     * [com.xweather.mapsgl.sources.GeoJSONSource.data] automatically.
     */
    var bundledAssetPath: String? = null,
) : SourceDescriptor {
    override val kind: DataSourceKind
        get() = DataSourceKind.GEOJSON

    // Declared in the class body rather than the primary constructor, the rule from XMAPSGLSDK-285:
    // a new constructor parameter on a published data class changes the generated constructor, its
    // default bridge, `copy` and `componentN`.
    /**
     * Extra query parameters for requests from this source (MapsGL JS's `data.params`).
     *
     * Currently not applied: [com.xweather.mapsgl.map.MapController.addSource] does not read this
     * property, so setting it has no effect.
     */
    var params: Map<String, String> = emptyMap()

    // Declared in the class body rather than the primary constructor so that adding it did not
    // change the generated constructor, `copy`, `componentN`, or `equals`/`hashCode` signatures —
    // apps compiled against an earlier AAR keep working without recompiling.
    /**
     * Inline GeoJSON features supplied up front, applied to
     * [com.xweather.mapsgl.sources.GeoJSONSource.data] when [com.xweather.mapsgl.map.MapController.addSource]
     * creates the source. Use this when the features are already in hand:
     *
     * ```kotlin
     * val source = GeoJSONSourceDescriptor(id = "country-region")
     * source.data = FeatureCollection.fromJson(geoJsonString)
     * controller.addSource(source)
     * ```
     *
     * Takes precedence over [bundledAssetPath] when both are set. Leave `null` to drive the source
     * from [url], from [bundledAssetPath], or by assigning
     * [com.xweather.mapsgl.sources.GeoJSONSource.data] after the source is added.
     *
     * Excluded from data-class equality: two descriptors differing only in [data] compare equal.
     */
    var data: FeatureCollection? = null

    /**
     * In-memory GeoJSON only — assign [data] before [com.xweather.mapsgl.map.MapController.addSource],
     * or [com.xweather.mapsgl.sources.GeoJSONSource.data] after it.
     * Prefer this constructor over default-arg `GeoJSONSourceDescriptor(id = …)` when linking against a minified AAR.
     */
    constructor(id: String) : this(
        id = id,
        url = null,
        metadataUrl = null,
        minZoom = null,
        maxZoom = null,
        bounds = null,
        tileSize = null,
        attribution = null,
        authenticator = null,
        bundledAssetPath = null,
    )

    /**
     * Loads GeoJSON from [bundledAssetPath] under the host app's `src/main/assets/` when the source is added.
     * Example: `GeoJSONSourceDescriptor("countries", "geojson/conus.geojson")`.
     */
    constructor(id: String, bundledAssetPath: String) : this(
        id = id,
        url = null,
        metadataUrl = null,
        minZoom = null,
        maxZoom = null,
        bounds = null,
        tileSize = null,
        attribution = null,
        authenticator = null,
        bundledAssetPath = bundledAssetPath,
    )
}